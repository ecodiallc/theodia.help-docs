---
title: إنشاء مواردك الخاصة
level: advanced
categories: resources
summary: كيفية إنشاء أجبيات وتفاسير وكتب وتمارين روحية ومعاجم مخصصة واستيرادها إلى Theodia.
---

# إنشاء مواردك الخاصة

يدعم Theodia الموارد المخصصة بتنسيق Unique Bible App. كل مورد عبارة عن ملف SQLite بهيكلية جدول محددة. يمكنك إنشاء هذه الملفات على جهاز كمبيوتر واستيرادها إلى التطبيق.

## أنواع الملفات والجداول المطلوبة

### الأجبية (`.bible`)

ملف الكتاب المقدس هو قاعدة بيانات SQLite تحتوي على جدول واحد على الأقل من هذه الجداول:

- **`Verses`** — الأعمدة: `Book` (عدد صحيح، 1-66)، `Chapter` (عدد صحيح)، `Verse` (عدد صحيح)، `Scripture` (نص)
- **`Bible`** — الأعمدة: `Book` (عدد صحيح)، `Chapter` (عدد صحيح)، `Verse` (عدد صحيح)، `Scripture` (نص)

يمكنك أيضاً تضمين جدول **`Details`** مع أعمدة بيانات وصفية مثل `Description`، و`Abbreviation`، و`Version`.

مثال SQL:

```sql
-- جدول النص الرئيسي
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- جدول البيانات الوصفية الاختياري
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### التفاسير (`.commentary`)

تأتي التفاسير في ثلاثة أنواع: **كتاب**، **إصحاح**، و**آية**. يتحدد النوع بالـ **أول حرف من اسم الملف**.

#### تفاسير كتابية — يبدأ اسم الملف بحرف `b`

التفسير الكتابي يغطي كتاباً كاملاً من الكتاب المقدس في مدخل واحد. يحتاج جدول `Commentary` إلى عمودي `Book` و`Scripture` (أو `Content`). لا حاجة لعمودي `Chapter` أو `Verse`.

- **`Commentary`** — الأعمدة: `Book` (عدد صحيح)، `Scripture` (نص) أو `Content` (نص)

مثال SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

مثال اسم ملف: `bMyCommentary.commentary`

#### تفاسير إصحاحية — يبدأ اسم الملف بحرف `c`

التفسير الإصحاحي يغطي كل إصحاح من كتاب الكتاب المقدس.

- **`Commentary`** — الأعمدة: `Book` (عدد صحيح)، `Chapter` (عدد صحيح)، `Scripture` (نص) أو `Content` (نص)

مثال SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

مثال اسم ملف: `cMyCommentary.commentary`

#### تفاسير آية — يبدأ اسم الملف بحرف `v`

التفسير الآية يغطي آيات فردية. يحتاج جدول `Commentary` إلى أعمدة `Book`، `Chapter`، `Verse`، و`Scripture` (أو `Content`).

- **`Commentary`** — الأعمدة: `Book` (عدد صحيح)، `Chapter` (عدد صحيح)، `Verse` (عدد صحيح)، `Scripture` (نص) أو `Content` (نص)

مثال SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

مثال اسم ملف: `vMyCommentary.commentary`

### الكتب (`.book`)

ملف الكتاب هو قاعدة بيانات SQLite بجدول `Reference`.

- **`Reference`** — الأعمدة: `id` (عدد صحيح)، `Chapter` (نص)، `Content` (نص)

كل صف هو فصل واحد. العمود `Chapter` هو عنوان الفصل. العمود `Content` هو نص الفصل، ويمكن أن يتضمن HTML (`<b>`، `<i>`، `<br>`، وما إلى ذلك).

مثال SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

يمكنك أيضاً إنشاء كتب من ملفات Markdown. يستطيع التطبيق استيراد ملفات `.md` حيث يكون `#` عنوان الكتاب و`##` يحدد الفصول. يُحوّل Markdown إلى HTML تلقائياً.

### التمارين الروحية (`.devotional`)

ملف التمارين الروحية هو قاعدة بيانات SQLite بجدول `devotional`.

- **`devotional`** — الأعمدة: `month` (عدد صحيح، 1-12)، `day` (عدد صحيح، 1-31)، `devotion` (نص)

كل صف هو قراءة يوم واحد. يبحث التطبيق عن المدخل حسب الشهر واليوم الحاليين.

مثال SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### المعاجم (`.lexicon`)

ملف المعجم هو قاعدة بيانات SQLite بجدول `Lexicon`.

- **`Lexicon`** — الأعمدة: `Topic` (نص، رقم Strong's)، `Definition` (نص، مدخل المعجم)

يحتوي العمود `Topic` على رقم Strong's (على سبيل المثال، `G1161` أو `H7225`). يحتوي العمود `Definition` على نص المدخل الكامل، ويمكن أن يتضمن HTML.

مثال SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

تُشغّل المعاجم أداة معلومات الكلمة. عندما تضغط كلمة في كتاب تفاضلي، يبحث التطبيق عن رقم Strong's في المعاجم المثبتة.

## إنشاء ملف على جهاز الكمبيوتر

1. ثبّت محرر SQLite (DB Browser for SQLite، أو SQLiteStudio، أو أداة سطر الأوامر `sqlite3`).
2. أنشئ ملف قاعدة بيانات جديد.
3. أنشئ الجدول المطلوب وأدخل بياناتك.
4. احفظ الملف بالامتداد الصحيح (`.bible`، `.commentary`، `.book`، `.devotional`، أو `.lexicon`).

## الاستيراد إلى Theodia

1. انقل الملف إلى جهازك (AirDrop، أو بريد إلكتروني، أو تخزين سحابي، أو USB).
2. افتح **Theodia**.
3. انتقل إلى **الإعدادات** → **إدارة الموارد**.
4. اضغط **استيراد من ملف**.
5. اختر ملفك.

يتحقق التطبيق من صحة الملف (يفحص الجدول المطلوب)، وينسخه إلى مجلد بيانات التطبيق، ويُفعّله تلقائياً. إذا كان الملف غير صالح، تظهر رسالة خطأ تشرح المشكلة.

## القيود

- لا يمكنك استبدال الموارد المدمجة. إذا حاولت استيراد ملف بنفس اسم إنجيل أو تفسير أو كتاب مدمج، يفشل الاستيراد.
- ملفات الكتاب المقدس تحتاج إلى جدول `Verses` أو `Bible`. إذا لم يوجد أي منهما، يفشل الاستيراد.
- ملفات التفاسير تحتاج إلى جدول `Commentary`.
  - التفاسير الكتابية تحتاج إلى عمودي `Book` و`Scripture` (أو `Content`).
  - التفاسير الإصحاحية تحتاج إلى أعمدة `Book`، `Chapter`، و`Scripture` (أو `Content`).
  - التفاسير الآية تحتاج إلى أعمدة `Book`، `Chapter`، `Verse`، و`Scripture` (أو `Content`).
- ملفات الكتب تحتاج إلى جدول `Reference`.
- ملفات المعاجم تحتاج إلى جدول `Lexicon`.
- ملفات التمارين الروحية تحتاج إلى جدول `devotional`.

## نصائح

- حافظ على أحجام الملفات معقولة. قد تتسبب ملفات SQLite الكبيرة جداً في مشاكل ذاكرة على الأجهزة القديمة.
- اختبر ملفك على جهاز كمبيوتر أولاً. افتحه في متصفح SQLite ونفّذ `SELECT * FROM` الجدول المطلوب للتحقق من صحة البيانات.
- للأجبية، تأكد من أن عمود `Book` يستخدم أرقاماً (1 = التكوين، 66 = الرؤيا).
- للتفاسير، يمكنك استخدام إما `Scripture` أو `Content` كعمود نص التفسير.
- للكتب، يُعرض HTML في العمود `Content` عند القراءة. احتفظ ببساطته: `<b>`، `<i>`، `<br>`، و`<hr>` آمنة.

## أين تجد موارد موجودة

يمكن لـ Theodia قراءة الموارد من مشروع [Unique Bible App](https://github.com/eliranwong/UniqueBible). تتوفر العديد من الأجبيات والتفاسير والكتب وغيرها بالتنسيق الصحيح لـ SQLite. راجع دليل [الحصول على موارد إضافية](theodia://help/getting-core-files) لمعرفة كيفية العثور عليها وإضافتها.
