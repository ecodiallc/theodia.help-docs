---
title: AI ফিচারসমূহ
categories: ai
level: advanced
summary: থিওডিয়ার AI কী কী করতে পারে — শ্লোক-ভিত্তিক অধ্যয়ন থেকে সার্মন প্রস্তুতি, মূল ভাষা অন্বেষণ ও হাতমুক্ত নেভিগেশন।
---

# AI ফিচারসমূহ

> **মোড:** AI সহায়কের জন্য **স্কলার** মোড প্রয়োজন। **Settings** → **App User Mode**-এ মোড বদলান।

থিওডিয়ার AI সহায়ক, থিওফিলাস, একটি সাধারণ চ্যাটবট নয়। এটি একজন অধ্যয়ন সঙ্গী যা আপনার সঙ্গে বাইবেল পড়তে, কমেন্টারি খুঁজে বের করতে, শাস্ত্র সার্চ করতে, নোট পরিচালনা করতে, এবং অ্যাপ নেভিগেট করতে পারে — সব ভয়েস বা টেক্সটে।

থিওফিলাস প্রথমবার AI এন্ডপয়েন্টে ডেটা পাঠানোর আগে, অ্যাপ একটি সম্মতি প্রম্পট দেখায়, যেখানে কী পাঠানো হয় তা ব্যাখ্যা করা থাকে এবং আপনার অনুমতি চাওয়া হয়। আপনি যেকোনো সময় **Settings → AI Assistant → Remote AI Data Sharing**-এ সেই অনুমতি বদলাতে বা প্রত্যাহার করতে পারেন।

## AI Verse Chat: একটি শ্লোক গভীরে পড়ুন

**AI Verse Chat** থিওডিয়ার AI অভিজ্ঞতার হৃদয়। আপনি যখন যেকোনো অধ্যায় পড়ছেন, একটি শ্লোক নম্বর ট্যাপ করুন (বা শ্লোক টেক্সট লং-প্রেস করুন) এবং **AI Commentary** বাছুন। সেই শ্লোকটি আগে থেকেই লোড করা একটি চ্যাট প্যানেল খোলে। AI ঠিক কী পড়ছেন তা জানে এবং আপনার সঙ্গে তা অন্বেষণ করতে প্রস্তুত।

### এক-ট্যাপ স্টার্টার

কী জিজ্ঞাসা করবেন নিশ্চিত নন? প্যানেল আটটি তাৎক্ষণিক স্টার্টার দেখায়:

- **Explain this verse** — অর্থ ও তাত্পর্যের একটি পরিষ্কার, চিন্তাশীল বিশ্লেষণ পান।
- **Original language** — ইংরেজি টেক্সটের পিছনের গ্রিক বা হিব্রু শব্দ, ট্রান্সলিটারেশন ও লেক্সিক্যাল সংজ্ঞা দেখুন।
- **Historical context** — শ্লোকের আশেপাশের সংস্কৃতি, রাজনীতি ও ঘটনা সম্পর্কে জানুন।
- **Textual context** — দেখুন শ্লোকটি পার্শ্ববর্তী অনুচ্ছেদ, অধ্যায় ও বইরের মধ্যে কীভাবে ফিট করে।
- **Main themes** — বাইবেলিক্যাল থিওলজিতে এই শ্লোক যে বড় ধারণা যোগ করে, তা আবিষ্কার করুন।
- **Apply to my life** — আজই যা করতে পারেন এমন ব্যবহারিক, ব্যক্তিগত প্রয়োগ পান।
- **Generate a prayer** — শ্লোকের ভাষা ও সত্যের ভিত্তিতে একটি প্রার্থনা তৈরি করুন।
- **Generate a sermon outline** — ভূমিকা ও উপসংহারসহ তিন-দফা রূপরেখা, প্রচারের জন্য প্রস্তুত।

যেকোনো স্টার্টার ট্যাপ করুন এবং AI তাৎক্ষণিকভাবে শুরু করে। আপনি নিজের প্রশ্নে পরবর্তী প্রশ্ন করতে, স্পষ্টীকরণ চাইতে, বা কথোপকথন নতুন দিকে ঘুরাতে পারেন।

### প্রকৃত কথোপকথনের মতো ফলো-আপ

চ্যাটের শেষ কয়েকটি বার্তা AI মনে রাখে, তাই প্রাকৃতিকভাবে গভীরে যেতে পারেন:

- "এটা সহজভাবে বলুন।"
- "এখানে মূল গ্রিক কী বলে?"
- "এই শ্লোকের সঙ্গে সংযুক্ত ক্রস-রেফারেন্স দেখান।"
- "এই শ্লোক তিনটি ভিন্ন অনুবাদে তুলনা করুন।"
- "আধুনিক কর্মস্থলে এটা কেমন দেখাবে?"
- "একজন অভিভাবকের জন্য আরও তিনটি প্রয়োগ দিন।"

কথোপকথন ওই শ্লোকের সঙ্গে জুড়ে থাকে, তাই প্রতিটি উত্তর আপনি যে টেক্সট পড়ছেন, তার ভিত্তিতে নির্ভরযোগ্য।

### যেকোনো বাইবেল রেফারেন্স ট্যাপ করুন

AI যখন অন্য কোনো শ্লোক উল্লেখ করে — উদাহরণস্বরূপ, "This mirrors Romans 8:28" — রেফারেন্সটি একটি **ট্যাপযোগ্য লিংক** হিসেবে দেখায়। ট্যাপ করুন এবং অ্যাপ বাইবেল রিডারে সেই প্যাসেজে চলে যায়। আপনি কথোপকথন ছাড়াই রেফারেন্সের শৃঙ্খল অন্বেষণ করতে পারেন।

## ভার্স চ্যাটের বাইরে AI যা করতে পারে

থিওফিলাস থিওডিয়ার সম্পূর্ণ কন্টেন্ট অ্যাক্সেস করতে পারে — বাইবেল, কমেন্টারি, লেক্সিকন, ডিকশনারি, বই, ডিভোশনাল, আপনার নোট, বুকমার্ক ও হাইলাইট। এর অর্থ ব্যবহারিকভাবে কী:

### শাস্ত্র পড়ুন ও নেভিগেট করুন

- **যেকোনো শ্লোক বা অধ্যায় পড়ুন** — "Read John 3:16 in the WEB" বা "Read Psalm 23 aloud."
- **রিডারে প্যাসেজ খুলুন** — "Take me to Genesis 1" বা "Open Romans 8:28."
- **সंস্করণ তুলনা করুন** — "Show me John 3:16 in all my Bibles."
- **বাইবেল সার্চ করুন** — "Find verses about forgiveness" বা "Search for 'peace that passes understanding.'"
- **ক্রস-রেফারেন্স পান** — "What other verses relate to Isaiah 53:5?"
- **সেকশন হেডিং পড়ুন** — "What are the subheadings in Matthew 5?"

### মূল ভাষা অন্বেষণ করুন

- **লেক্সিকন লুকআপ** — "What does the Greek word 'agape' mean in John 3:16?" বা "Look up Strong's G26."
- **মর্ফোলজি** — "Parse the Greek verbs in Romans 8:28" বা "What does morphology code V-PAI-3S mean?"
- **Word Info** — AI অ্যাপে একই শব্দ-প্রতি-শব্দ বিশ্লেষণ দেখতে পারে — ট্রান্সলিটারেশন, গ্লস, গ্রামার ও Strong's নম্বর।

### কমেন্টারি ও স্টাডি বই পড়ুন

- **শ্লোক কমেন্টারি** — "What does Matthew Henry say about Ephesians 2:8?"
- **অধ্যায় কমেন্টারি** — "Give me the chapter overview for Romans 8."
- **বই কমেন্টারি** — "Summarize the book-level commentary on Revelation."
- **স্টাডি বই** — "Read me a chapter from Hymn Lyrics English" বা "Search my books for 'patience.'"
- **ডিভোশনাল** — "Read today's devotional" বা "Find a devotional about anxiety."

### ডিকশনারি সার্চ করুন

- "Who was Melchizedek?"
- "What does the Bible dictionary say about Gilgal?"
- "Look up 'propitiation' in Easton's."

### অধ্যয়ন জীবন পরিচালনা করুন

AI আপনার ব্যক্তিগত ডেটার ওপর কাজ করতে পারে — সবসময় আপনার ডিভাইসে লোক্যালভাবে সংরক্ষিত:

- **বুকমার্ক** — "Bookmark this verse in my Sermon Prep folder" বা "List my bookmarks."
- **হাইলাইট** — "Highlight John 3:16 in yellow" বা "Show me all my highlights."
- **নোট** — "Create a Bible note on this verse" বা "Read my notes for Genesis 1."
- **স্টাডি নোট** — "Save this conversation as a study note" বা "Create a new study notebook called Romans Study."
- **ফোল্ডার** — "Create a folder called Morning Devotion" বা "Move my John 3:16 bookmark to the Prayer folder."

### অ্যাপ সেটিংস বদলান

- "Switch to dark mode."
- "Make the BSB my default Bible."
- "Turn on parallel Bibles with the NET."
- "Increase the font size."

### জোরে পড়ুন

- "Read Psalm 23 aloud" — AI যেকোনো প্যাসেজ, বই বা নোটের জন্য টেক্সট-টু-স্পিচ চালু করতে পারে।
- "Stop reading" — যেকোনো সময় TTS থামান।

## কথোপকথন সংরক্ষণ করুন

প্রতিটি AI ভার্স চ্যাট সংরক্ষণ করা যায়। চ্যাট প্যানেলের মেনু ট্যাপ করে বাছুন:

- **Save as Bible Note** — সম্পূর্ণ কথোপকথন বাইবেল রিডারের ওই শ্লোক নোটে যোগ করে।
- **Save as Study Note** — কথোপকথন আপনার Study Notes বইতে সংরক্ষিত হয় পরে রেফারেন্সের জন্য।

এটি একটি দ্রুত AI অন্বেষণকে স্থায়ী অধ্যয়ন উপাদানে বদলে দেয়, যা আপনি পুনরায় দেখতে, সম্পাদনা করতে বা সার্মন থেকে তৈরি করতে পারেন।

## সম্পূর্ণ AI ট্যাব

ভার্স চ্যাট প্যানেলের বাইরে, থিওডিয়ার নিচের নেভিগেশনে একটি ডেডিকেটেড **AI** ট্যাব আছে। এটি একটি মুক্ত-ফর্ম চ্যাট যেখানে আপনি যেকোনো কিছু জিজ্ঞাসা করতে পারেন — কোনো শ্লোক আগে থেকে নির্বাচিত নয়। এটি ব্যবহার করুন:

- সম্পূর্ণ বাইবেল জুড়ে থিম্যাটিক স্টাডি
- সার্মন গবেষণা ও রূপরেখা
- বইয়ের মধ্যে ধর্মতাত্ত্বিক থিমের তুলনা
- প্রতিদিনের ভক্তি ও প্রার্থনা প্রম্পট
- বাইবেল ট্রিভিয়া ও পড়ার পরিকল্পনা
- অ্যাপ হেল্প — "How do parallel Bibles work?"

আপনার কথোপকথন স্বয়ংক্রিয়ভাবে সংরক্ষিত হয়। আপনি পুরোনো চ্যাটে ফিরতে, নতুন শুরু করতে ও পুরোনো থ্রেড মুছে ফেলতে পারেন।

## শুরু করার আইডিয়া

AI ব্যবহার করার এখানে কিছু উত্তেজনাপূর্ণ উপায়। একটি বাছুন এবং আজই চেষ্টা করুন।

**ব্যক্তিগত বৃদ্ধি**

- "Explain Philippians 4:6–7 and give me a prayer for when I feel anxious."
- "What does the Bible say about rest? Find me five verses and explain each."

**পারিবারিক ও প্যারেন্টিং**

- "How should Ephesians 6:4 guide modern parenting? Give me three practical rules."
- "Find verses about raising children and read them aloud to me."

**সার্মন ও শিক্ষকতা প্রস্তুতি**

- "Outline a 25-minute sermon on Romans 8:28 with an introduction, three points, and a conclusion."
- "What do my commentaries say about the 'armor of God' in Ephesians 6?"
- "Compare the Sermon on the Mount in Matthew with Luke's version. What are the differences?"

**মূল ভাষার অধ্যয়ন**

- "Show me the morphology for every word in John 1:1."
- "What is the difference between 'agape' and 'philia' in the New Testament?"

**ভক্তির গভীরতা**

- "Read today's devotional and connect it to a verse in Psalms."
- "Give me a seven-day devotional outline on the fruit of the Spirit."

**ক্রস-রেফারেন্স শৃঙ্খল**

- "Start with Isaiah 53:5 and trace the 'wounds' and 'healing' theme through the New Testament."
- "Where does the concept of 'covenant' appear from Genesis to Hebrews?"

**স্মৃতি ও পর্যালোচনা**

- "Quiz me on the books of the Bible in order."
- "Create a study note summarizing the main point of every chapter in Romans."

## কয়েকটি গুরুত্বপূর্ণ নোট

- AI একটি **হাতিয়ার**, বাইবেল বা পাস্টোরাল গাইডেন্সের বিকল্প নয়। সর্বদা তার উত্তর শাস্ত্রের সঙ্গে তুলনা করুন।
- আপনি যখন AI ব্যবহার করেন, আপনার প্রশ্ন ইন্টারনেটের মাধ্যমে প্রোভাইডারের সার্ভারে যায়। বেশিরভাগ প্রোভাইডার আপনার ডেটার ওপর ট্রেন করে না, কিন্তু টেক্সট আপনার ডিভাইস ছেড়ে যায়।
- AI ভুল করতে পারে। কমেন্টারি, লেক্সিকন ও বাইবেল টেক্সট ব্যবহার করুন আপনার চূড়ান্ত কর্তৃপক্ষ হিসেবে।

## সারাংশ

থিওডিয়ার AI বাইবেল অধ্যয়নকে দ্রুততর, গভীরতর ও বেশি ব্যক্তিগত করতে ডিজাইন করা। কোনো বিভ্রান্তিকর শ্লোকের এক-বাক্য ব্যাখ্যা, সম্পূর্ণ সার্মন রূপরেখা, গ্রিক শব্দ অধ্যয়ন, বা সমগ্র বাইবেল জুড়ে ক্রস-রেফারেন্স শৃঙ্খল — যাই চাই, থিওফিলাস সাহায্যের জন্য প্রস্তুত। একটি শ্লোক ট্যাপ করুন, একটি প্রশ্ন জিজ্ঞাসা করুন, এবং দেখুন কথোপকথন কোথায় নিয়ে যায়।
