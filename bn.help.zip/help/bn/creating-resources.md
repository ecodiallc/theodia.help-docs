---
title: নিজের রিসোর্স তৈরি
level: advanced
categories: resources
summary: কাস্টম বাইবেল, কমেন্টারি, বই, ভক্তি-পাঠ, ও লেক্সিকন কীভাবে তৈরি করে Theodia-তে ইম্পোর্ট করবেন।
---

# নিজের রিসোর্স তৈরি

Theodia Unique Bible App ফরম্যাটে কাস্টম রিসোর্স সমর্থন করে। প্রতিটি রিসোর্স একটি SQLite ফাইল যার নির্দিষ্ট টেবিল স্ট্রাকচার আছে। আপনি এই ফাইলগুলি কম্পিউটারে তৈরি করে অ্যাপে ইম্পোর্ট করতে পারেন।

## ফাইল টাইপ ও প্রয়োজনীয় টেবিল

### বাইবেল (`.bible`)

বাইবেল ফাইল একটি SQLite ডেটাবেস যাতে অন্তত একটি টেবিল থাকে:

- **`Verses`** — কলাম: `Book` (ইন্টিজার, 1-66), `Chapter` (ইন্টিজার), `Verse` (ইন্টিজার), `Scripture` (টেক্সট)
- **`Bible`** — কলাম: `Book` (ইন্টিজার), `Chapter` (ইন্টিজার), `Verse` (ইন্টিজার), `Scripture` (টেক্সট)

আপনি একটি **`Details`** টেবিল যোগ করতে পারেন যাতে `Description`, `Abbreviation`, `Version`-এর মতো মেটাডেটা কলাম থাকে।

উদাহরণ SQL:

```sql
-- Main text table
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- Optional metadata table
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### কমেন্টারি (`.commentary`)

কমেন্টারি তিন ধরনের হয়: **বই**, **অধ্যায়**, ও **পদ**। ফাইলনামের **প্রথম অক্ষর** দ্বারা ধরন নির্ধারিত হয়।

#### বই কমেন্টারি — ফাইলনাম `b` দিয়ে শুরু

একটি বই কমেন্টারি একটি বাইবেল বইয়ের পুরো অধ্যায়েককে একটি এন্ট্রিতে কভার করে। `Commentary` টেবিলে `Book` ও `Scripture` (বা `Content`) কলাম লাগে। `Chapter` বা `Verse` কলাম লাগে না।

- **`Commentary`** — কলাম: `Book` (ইন্টিজার), `Scripture` (টেক্সট) বা `Content` (টেক্সট)

উদাহরণ SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

ফাইলনাম উদাহরণ: `bMyCommentary.commentary`

#### অধ্যায় কমেন্টারি — ফাইলনাম `c` দিয়ে শুরু

একটি অধ্যায় কমেন্টারি একটি বাইবেল বইয়ের প্রতিটি অধ্যায় কভার করে।

- **`Commentary`** — কলাম: `Book` (ইন্টিজার), `Chapter` (ইন্টিজার), `Scripture` (টেক্সট) বা `Content` (টেক্সট)

উদাহরণ SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

ফাইলনাম উদাহরণ: `cMyCommentary.commentary`

#### পদ কমেন্টারি — ফাইলনাম `v` দিয়ে শুরু

একটি পদ কমেন্টারি পৃথক পদ কভার করে। `Commentary` টেবিলে `Book`, `Chapter`, `Verse`, ও `Scripture` (বা `Content`) কলাম লাগে।

- **`Commentary`** — কলাম: `Book` (ইন্টিজার), `Chapter` (ইন্টিজার), `Verse` (ইন্টিজার), `Scripture` (টেক্সট) বা `Content` (টেক্সট)

উদাহরণ SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

ফাইলনাম উদাহরণ: `vMyCommentary.commentary`

### বই (`.book`)

একটি বই ফাইল একটি SQLite ডেটাবেস যাতে `Reference` টেবিল থাকে।

- **`Reference`** — কলাম: `id` (ইন্টিজার), `Chapter` (টেক্সট), `Content` (টেক্সট)

প্রতিটি সারি একটি অধ্যায়। `Chapter` কলাম অধ্যায়ের শিরোনাম। `Content` কলাম অধ্যায়ের মূল অংশ, যা HTML (`<b>`, `<i>`, `<br>`, ইত্যাদি) ধারণ করতে পারে।

উদাহরণ SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

Markdown ফাইল থেকেও বই তৈরি করতে পারেন। অ্যাপ `.md` ফাইল ইম্পোর্ট করতে পারে যেখানে `#` বইয়ের শিরোনাম এবং `##` অধ্যায় চিহ্নিত করে। Markdown স্বয়ংক্রিয়ভাবে HTML-এ রূপান্তরিত হয়।

### ভক্তি-পাঠ (`.devotional`)

একটি ভক্তি-পাঠ ফাইল একটি SQLite ডেটাবেস যাতে `devotional` টেবিল থাকে।

- **`devotional`** — কলাম: `month` (ইন্টিজার, 1-12), `day` (ইন্টিজার, 1-31), `devotion` (টেক্সট)

প্রতিটি সারি একটি দিনের পাঠ। অ্যাপ আজকের মাস ও দিন দিয়ে এন্ট্রি খুঁজে।

উদাহরণ SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### লেক্সিকন (`.lexicon`)

একটি লেক্সিকন ফাইল একটি SQLite ডেটাবেস যাতে `Lexicon` টেবিল থাকে।

- **`Lexicon`** — কলাম: `Topic` (টেক্সট, Strong's সংখ্যা), `Definition` (টেক্সট, লেক্সিকন এন্ট্রি)

`Topic` কলামে Strong's সংখ্যা থাকে (উদাহরণ, `G1161` বা `H7225`)। `Definition` কলামে পূর্ণ এন্ট্রি টেক্সট থাকে, যা HTML ধারণ করতে পারে।

উদাহরণ SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

লেক্সিকন ওয়ার্ড ইনফো সরঞ্জামকে চালিত করে। আপনি একটি ইন্টারলিনিয়ার বাইবেলে একটি শব্দ ট্যাপ করলে অ্যাপ ইনস্টল করা লেক্সিকনগুলিতে Strong's সংখ্যা খোঁজে।

## কম্পিউটারে ফাইল তৈরি

1. একটি SQLite এডিটর ইনস্টল করুন (DB Browser for SQLite, SQLiteStudio, বা `sqlite3` কমান্ড-লাইন টুল)।
2. একটি নতুন ডেটাবেস ফাইল তৈরি করুন।
3. প্রয়োজনীয় টেবিল তৈরি করে আপনার ডেটা ইনসার্ট করুন।
4. সঠিক এক্সটেনশন (`.bible`, `.commentary`, `.book`, `.devotional`, বা `.lexicon`) দিয়ে ফাইল সংরক্ষণ করুন।

## Theodia-তে ইম্পোর্ট

1. ফাইল ডিভাইসে ট্রান্সফার করুন (AirDrop, ইমেইল, ক্লাউড স্টোরেজ, বা USB)।
2. **Theodia** খুলুন।
3. **সেটিংস** → **সংসাধন পরিচালনা**-তে যান।
4. **ফাইল থেকে ইম্পোর্ট** ট্যাপ করুন।
5. আপনার ফাইল বেছে নিন।

অ্যাপ ফাইল যাচাই করে (প্রয়োজনীয় টেবিল পরীক্ষা করে), তা অ্যাপের ডেটা ফোল্ডারে কপি করে, ও স্বয়ংক্রিয়ভাবে চালু করে। ফাইল অবৈধ হলে কী ভুল হয়েছে তা জানানো একটি ত্রুটি বার্তা দেখাবে।

## সীমাবদ্ধতা

- বিল্ট-ইন রিসোর্স ওভাররাইট করতে পারবেন না। আপনি বিল্ট-ইন বাইবেল, কমেন্টারি, বা বইয়ের নামে একই নামের ফাইল ইম্পোর্ট করলে ইম্পোর্ট ব্যর্থ হবে।
- বাইবেল ফাইলে `Verses` বা `Bible` টেবিল লাগে। কোনোটি না থাকলে ইম্পোর্ট ব্যর্থ।
- কমেন্টারি ফাইলে `Commentary` টেবিল লাগে।
  - বই কমেন্টারিতে `Book` ও `Scripture` (বা `Content`) কলাম লাগে।
  - অধ্যায় কমেন্টারিতে `Book`, `Chapter`, ও `Scripture` (বা `Content`) কলাম লাগে।
  - পদ কমেন্টারিতে `Book`, `Chapter`, `Verse`, ও `Scripture` (বা `Content`) কলাম লাগে।
- বই ফাইলে `Reference` টেবিল লাগে।
- লেক্সিকন ফাইলে `Lexicon` টেবিল লাগে।
- ভক্তি-পাঠ ফাইলে `devotional` টেবিল লাগে।

## টিপস

- ফাইলের আকার যুক্তিসঙ্গত রাখুন। খুব বড় SQLite ফাইল পুরোনো ডিভাইসে মেমরি সমস্যা তৈরি করতে পারে।
- আগে কম্পিউটারে ফাইল পরীক্ষা করুন। SQLite ব্রাউজারে খুলুন ও প্রয়োজনীয় টেবিলে `SELECT * FROM` চালিয়ে ডেটা ঠিক আছে কিনা দেখুন।
- বাইবেলের জন্য, `Book` কলাম অবশ্যই সংখ্যা ব্যবহার করবে (1 = Genesis, 66 = Revelation)।
- কমেন্টারিতে আপনি কমেন্টারি টেক্সট কলাম হিসেবে `Scripture` বা `Content` যেকোনোটি ব্যবহার করতে পারেন।
- বইয়ে HTML `Content` কলামে থাকলে পড়ার সময় রেন্ডার হয়। সরল রাখুন: `<b>`, `<i>`, `<br>`, ও `<hr>` নিরাপদ।

## বিদ্যমান রিসোর্স কোথায় পাবেন

Theodia [Unique Bible App](https://github.com/eliranwong/UniqueBible) প্রজেক্টের রিসোর্স পড়তে পারে। সঠিক SQLite ফরম্যাটে অনেক বাইবেল, কমেন্টারি, বই, ও অন্য রিসোর্স সেখানে আছে। সেগুলি কীভাবে খুঁজবেন ও যোগ করবেন তা [অতিরিক্ত সংসাধন পাওয়া](theodia://help/getting-core-files) গাইডে দেখুন।