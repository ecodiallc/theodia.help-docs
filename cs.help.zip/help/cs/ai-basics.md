---
title: Základy AI
level: advanced
categories: ai
summary: Jak používat AIho asistenta k porozumění veršům.
---

# Základy AI

> **Režim:** AI asistent vyžaduje režim **Scholar** (Badatel). Režim můžete přepnout v **Nastavení** → **Režim aplikace**.

Theodia má AI asistenta. Může vám pomoci porozumět verši, odpovědět na otázku nebo probrat biblické téma.

## Jak zapnout AI

AI je ve výchozím nastavení vypnutá. Zapnete ji takto:

1. Otevřete **Nastavení**.
2. Klepněte na **AI asistent**.
3. Klepnutím na přepínač ji zapněte.

## Jak AI otevřít

Klepněte na záložku **AI** ve spodní části obrazovky. Otevře se okno chatu.

## Jak položit otázku

Klepněte na pole dole. Napište svou otázku. Klepněte na **Odeslat**.

Něco, co se můžete zeptat:

- „Co znamená Jan 3:16?“
- „Pověz mi o knize Římanům.“
- „Co je ovoce Ducha?“
- „Porovnej Kázání na hoře v Matouši a Lukášovi.“

## Jak se ptát na konkrétní verš

1. Otevřete kapitolu.
2. Klepněte na verš, čímž zobrazíte nabídku verše.
3. Klepněte na **AI komentář**.

Verš se pošle AI. Panel AI se otevře s předvyplněným veršem. Můžete přidat otázku, například „Co to znamená?“ nebo „Jak mám tohle uplatnit?“

## Důležité věci, které je dobré vědět

- AI je nástroj, ne člověk. Může se mýlit.
- Odpovědi AI si vždy ověřujte proti samotné Bibli.
- AI může potřebovat internet. Offline nefunguje.
- Když AI používáte, vaše otázky, kontext verše a váš API klíč se odesílají na koncový bod, který si zvolíte. Při prvním použití aplikace požádá o váš souhlas a přesně ukáže, co se odesílá. Tento souhlas můžete později změnit nebo odvolat v **Nastavení → AI asistent → Sdílení dat se vzdálenou AI**.
- V některých regionech, například v sestavení App Store pro pevninskou Čínu, AI asistent není k dispozici. V tomto sestavení jsou dostupné pouze offline funkce Bible.

## Jak spravovat konverzace

Obrazovka AI uchovává seznam minulých konverzací. Ze seznamu můžete otevřít starou konverzaci, začít novou nebo smazat takovou, kterou už nepotřebujete.

## Jděte s AI hlouběji

Tato stránka pokrývá základy. AI v Theodii umí mnohem víc než jen chatovat. Kam pokračovat:

- **[Funkce AI](theodia://help/ai-features)** — Objevte vše, co Theophilus umí: studium verše jedním klepnutím v řečtině a hebrejštině, řetězce křížových odkazů, osnovy kázání, generování modliteb, morfologii původních jazyků, vyhledávání ve slovnících a ovládání aplikace bez rukou. Toto je průvodce, který vám ukáže, jak z AI udělat plnohodnotného studijního partnera.
- **[Lepší AI prompty](theodia://help/ai-prompts)** — Naučte se umění ptát se tak, abyste dostali bohaté a přesné odpovědi. Pár úprav formulace otázky může zásadně prohloubit odpovědi AI.
- **[Výběr AI modelu](theodia://help/choosing-a-model)** — Ne všechny AI modely jsou rovnocenné. Zjistěte, které modely podporují vestavěné nástroje Theodie (jako otevírání veršů a hledání v Písmu) a které z AI udělají skutečného asistenta pro studium Bible bez použití rukou.
- **[GitHub Models](theodia://help/github-models)** — Doporučený bezplatný poskytovatel pro Theodii. Získejte bezplatný API klíč s účtem GitHub a ptejte se v rámci štědrého denního limitu. Žádná platební karta, žádné předplatné.
- **[API klíče a náklady](theodia://help/ai-keys-and-costs)** — Pochopte, jak fungují ceny API u jednotlivých poskytovatelů, a jak udržet náklady blízko nuly.
