---
title: Funkce AI
categories: ai
level: advanced
summary: Objevte vše, co AI v Theodii umí — od studia verš po verši až po přípravu kázání, zkoumání původních jazyků a ovládání bez rukou.
---

# Funkce AI

> **Režim:** AI asistent vyžaduje režim **Scholar** (Badatel). Režim můžete přepnout v **Nastavení** → **Režim aplikace**.

AI asistent Theodie, Theophilus, není jen chatbot. Je to studijní partner, který může číst Bibli spolu s vámi, vyhledávat v komentářích, prohledávat Písmo, spravovat vaše poznámky a dokonce ovládat aplikaci — vše hlasem nebo textem.

Než Theophilus poprvé pošle data na AI koncový bod, aplikace zobrazí dotaz na souhlas, který vysvětluje, co se odesílá, a žádá o vaše povolení. Toto povolení můžete kdykoli změnit nebo odvolat v **Nastavení → AI asistent → Sdílení dat se vzdálenou AI**.

## AI chat ke verši: Prostudujte jeden verš do hloubky

**AI chat ke verši** je srdcem zážitku s AI v Theodii. Když čtete libovolnou kapitolu, klepněte na číslo verše (nebo dlouze stiskněte text verše) a zvolte **AI komentář**. Otevře se chat panel s tímto veršem už načteným. AI přesně ví, co čtete, a je připravena to s vámi prozkoumat.

### Spouštěče na jedno klepnutí

Nevíte, co se zeptat? Panel ukazuje osm okamžitých spouštěčů:

- **Vysvětli tento verš** — Získejte jasný a promyšlený rozbor významu a důležitosti.
- **Původní jazyk** — Uvidíte řecká a hebrejská slova, transliterace a lexikální definice za anglickým textem.
- **Historický kontext** — Dozvíte se o kultuře, politice a událostech kolem verše.
- **Textový kontext** — Uvidíte, jak verš zapadá do odstavce, kapitoly a knihy kolem něj.
- **Hlavní témata** — Objevte velké myšlenky, které tento verš přináší do biblické teologie.
- **Uplatni v mém životě** — Získejte praktické, osobní aplikace, se kterými můžete dnes něco udělat.
- **Vygeneruj modlitbu** — Proměňte verš v modlitbu podle jeho jazyka a pravd.
- **Vygeneruj osnovu kázání** — Získejte tříbodovou osnovu s úvodem a závěrem, připravenou ke kázání.

Klepněte na libovolný spouštěč a AI ihned začne. Můžete pokračovat vlastními otázkami, žádat o vysvětlení nebo konverzaci nasměrovat jinam.

### Pokračujte jako v opravdové konverzaci

AI si pamatuje posledních pár zpráv v chatu, takže se můžete přirozeně dotírat hlouběji:

- „Můžeš to říct jednodušeji?“
- „Co tady říká původní řečtina?“
- „Ukaž mi křížové odkazy, které se k tomu vážou.“
- „Porovnej tento verš ve třech různých překladech.“
- „Jak by to vypadalo v moderním zaměstnání?“
- „Dej mi tři další aplikace pro rodiče.“

Konverzace zůstává připojená k verši, takže každá odpověď je ukotvena v textu, který čtete.

### Klepněte na jakýkoli biblický odkaz

Když AI zmíní jiný verš — například „To odpovídá Římanům 8:28“ — odkaz se zobrazí jako **klepnutelný odkaz**. Klepněte na něj a aplikace přeskočí na toto místo v čtečce Bible. Řetězec odkazů můžete prozkoumat, aniž byste konverzaci opustili.

## Co AI umí mimo chat ke verši

Theophilus má přístup ke kompletnímu obsahu Theodie — Biblím, komentářům, lexikonům, slovníkům, knihám, bohoslužebným čtením, vašim poznámkám, záložkám a zvýrazněním. Co to v praxi znamená.

### Čtěte a navigujte v Písmu

- **Čtěte jakýkoli verš nebo kapitolu** — „Přečti Jan 3:16 ve WEB“ nebo „Čti žalm 23 nahlas.“
- **Otevírejte místa v čtečce** — „Zaveď mě do Genesis 1“ nebo „Otevři Římanům 8:28.“
- **Porovnávejte verze** — „Ukaž mi Jan 3:16 ve všech mých Biblích.“
- **Hledejte v Bibli** — „Najdi verše o odpuštění“ nebo „Hledej ‚pokoj převyšující veškeré smyslení'.“
- **Získejte křížové odkazy** — „Které jiné verše se vztahují k Izajáši 53:5?“
- **Čtěte nadpisy oddílů** — „Jaké jsou podnadpisy v Matouši 5?“

### Zkoumejte původní jazyky

- **Vyhledávání v lexikonech** — „Co znamená řecké slovo ‚agape' v Janu 3:16?“ nebo „Vyhledej Strongovo G26.“
- **Morfologie** — „Rozparsuj řecké slovesa v Římanům 8:28“ nebo „Co znamená morfologický kód V-PAI-3S?“
- **Info o slově** — AI vidí stejné rozdělení po slovech, jaké vidíte v aplikaci — transliterace, význam, gramatika a Strongova čísla.

### Čtěte komentáře a studijní knihy

- **Komentář ke verši** — „Co říká Matthew Henry k Efezským 2:8?“
- **Komentář ke kapitole** — „Dej mi přehled kapitoly pro Římanům 8.“
- **Komentář ke knize** — „Shrň komentář na úrovni knihy o Zjevení.“
- **Studijní knihy** — „Přečti mi kapitolu z Hymn Lyrics English“ nebo „Prohledej moje knihy na ‚trpělivost'.“
- **Bohoslužebná čtení** — „Přečti dnešní bohoslužebné čtení“ nebo „Najdi bohoslužebné čtení o úzkosti.“

### Hledejte ve slovnících

- „Kdo byl Melchisedech?“
- „Co říká biblický slovník o Gilgalu?“
- „Vyhledej ‚propiciace' v Eastonovi.“

### Spravujte svůj studijní život

AI může pracovat s vašimi osobními daty — ta jsou vždy uložena lokálně na vašem zařízení:

- **Záložky** — „Přidej tento verš do záložek ve složce Příprava kázání“ nebo „Vypiš moje záložky.“
- **Zvýraznění** — „Zvýrazni Jan 3:16 žlutě“ nebo „Ukaž všechna moje zvýraznění.“
- **Poznámky** — „Vytvoř k tomuto verši poznámku“ nebo „Přečti mé poznámky k Genesis 1.“
- **Studijní poznámky** — „Ulož tuto konverzaci jako studijní poznámku“ nebo „Vytvoř nový studijní sešit s názvem Studium Římanů.“
- **Složky** — „Vytvoř složku s názvem Ranní bohoslužba“ nebo „Přesuň mou záložku na Jan 3:16 do složky Modlitba.“

### Měňte nastavení aplikace

- „Přepni do tmavého režimu.“
- „Nastav BSB jako mou výchozí Bibli.“
- „Zapni paralelní Bible s NET.“
- „Zvětši velikost písma.“

### Čtěte nahlas

- „Čti žalm 23 nahlas“ — AI může spustit převod textu na řeč pro jakékoliv místo, knihu nebo poznámku.
- „Přestaň číst“ — Kdykoli pozastavte TTS.

## Uložte si své konverzace

Každý AI chat ke verši lze uložit. Klepněte na nabídku v chat panelu a zvolte:

- **Uložit jako poznámku k Bibli** — Připojí celou konverzaci k poznámce verše v čtečce Bible.
- **Uložit jako studijní poznámku** — Uloží konverzaci do vašeho sešitu studijních poznámek pro pozdější použití.

Tím se z rychlého prozkoumání pomocí AI stane trvalý studijní materiál, ke kterému se můžete vracet, upravovat ho nebo z něj stavět kázání.

## Celá záložka AI

Kromě panelu chatu ke verši má Theodia samostatnou záložku **AI** ve spodní navigaci. To je volný chat, kde se můžete zeptat na cokoliv — bez předvybraného verše. Použijte ji pro:

- Tematická studia napříč celou Bibli
- Výzkum a osnovy kázání
- Porovnávání teologických témat mezi knihami
- Denní bohoslužbu a podněty k modlitbě
- Biblické kvízy a plány čtení
- Nápovědu k aplikaci — „Jak fungují paralelní Bible?“

Vaše konverzace se ukládají automaticky. Můžete se vracet k minulým chatům, začínat nové a mazat staré vlákna.

## Nápady, jak začít

Tady je pár vzrušujících způsobů, jak AI použít. Vyberte si jeden a vyzkoušejte ho dnes.

**Osobní růst**

- „Vysvětli Filipanům 4:6–7 a dej mi modlitbu na chvíle, když cítím úzkost.“
- „Co říká Bible o odpočinku? Najdi mi pět veršů a každý vysvětli.“

**Rodina a výchova dětí**

- „Jak by měly Efezským 6:4 vést moderní rodiče? Dej mi tři praktická pravidla.“
- „Najdi verše o výchově dětí a přečti mi je nahlas.“

**Příprava kázání a výuky**

- „Vytvoř osnovu 25minutového kázání na Římanům 8:28 s úvodem, třemi body a závěrem.“
- „Co říkají mé komentáře o ‚boží zbroi' v Efezským 6?“
- „Porovnej Kázání na hoře v Matouši s Lukášovou verzí. V čem se liší?“

**Studium původních jazyků**

- „Ukaž mi morfologii pro každé slovo v Janu 1:1.“
- „Jaký je rozdíl mezi ‚agape' a ‚philia' v Novém zákoně?“

**Hloubka bohoslužebních čtení**

- „Přečti dnešní bohoslužebné čtení a spoj ho s veršem v žalmech.“
- „Vytvoř sedmidenní osnovu bohoslužebných čtení na ovoce Ducha.“

**Řetězce křížových odkazů**

- „Začni u Izaiáše 53:5 a sleduj téma ‚rány' a ‚uzdravení' napříč Novým zákonem.“
- „Kde se koncept ‚smlouvy' objevuje od Genesis až po Židům?“

**Zapamatování a opakování**

- „Otestuj mě na knihy Bible v pořadí.“
- „Vytvoř studijní poznámku shrnující hlavní myšlenku každé kapitoly Římanů.“

## Několik důležitých poznámek

- AI je **nástroj**, nikoli náhrada Bible nebo duchovního vedení. Její odpovědi vždy porovnávejte s samotným Písmem.
- Když AI používáte, vaše otázky putují po internetu na servery poskytovatele. Většina poskytovatelů na vašich datech netrénuje své modely, ale text opouští vaše zařízení.
- AI se může mýlit. Používejte komentáře, lexikony a samotný biblický text jako konečnou autoritu.

## Shrnutí

AI v Theodii je navržena tak, aby studium Bible bylo rychlejší, hlubší a osobnější. Ať chcete jedno-větné vysvětlení nesrozumitelného verše, kompletní osnovu kázání, studium řeckého slova nebo řetězec křížových odkazů napříč celou Bibli, Theophilus je připraven pomoci. Klepněte na verš, položte otázku a uvidíte, kam konverzace povede.
