---
title: API klíče a náklady
level: advanced
categories: ai
summary: Proč potřebujete API klíč, jak ho získat a co obvykle stojí používání vzdáleného AI modelu.
---

# API klíče a náklady

> **Režim:** AI asistent vyžaduje režim **Scholar** (Badatel). Režim můžete přepnout v **Nastavení** → **Režim aplikace**.

AI asistent se připojuje ke vzdáleným AI modelům. Pokud chcete nějaký použít, potřebujete API klíč. Tato stránka vysvětluje proč, jak ho získat a co obvykle stojí.

## Proč potřebujete API klíč

Vzdálený AI model běží na serveru na internetu. API klíč je jako heslo, které serveru říká: „Tento člověk smí pokládat otázky.“ Bez něj server neodpoví.

Aplikace neposkytuje vestavěný klíč. Musíte si vytvořit vlastní účet u poskytovatele a vložit svůj klíč do aplikace.

## Jak získat API klíč

1. Otevřete v Theodii **Nastavení**.
2. Klepněte na **AI asistent**.
3. Zvolte **Vzdálený model**.
4. Vyberte poskytovatele ze seznamu, nebo zvolte **Vlastní** a zadejte základní URL.
5. Klepněte na odkaz na stránku klíčů poskytovatele. Pokud účet nemáte, vytvořte si ho.
6. Na stránkách poskytovatele si vygenerujte nový API klíč.
7. Zkopírujte klíč a vložte ho do Theodie.
8. Klepněte na **Otestovat připojení**, abyste ověřili, že funguje.

## Podporovaní poskytovatelé

Theodia se může připojit ke každému poskytovateli, který používá OpenAI-kompatibilní API. Tito mají v aplikaci přednastavené odkazy:

- **GitHub Models** — github.com/marketplace/models (bezplatný denní limit, doporučeno)
- **OpenAI** — platform.openai.com
- **OpenRouter** — openrouter.ai
- **Anthropic** — console.anthropic.com
- **Groq** — console.groq.com
- **Mistral** — console.mistral.ai
- **Together AI** — api.together.xyz

Můžete také použít **vlastní** základní URL, pokud provozujete vlastní server nebo používáte jinou službu.

## Kolik to stojí?

Většina poskytovatelů účtuje podle **tokenů**. Token je zhruba slovo nebo část slova. Platíte za tokeny, které pošlete (vaši otázku), plus za tokeny, které AI pošle zpět (odpověď).

### Typické ceny

Ceny se mění, ale zde je přibližný přehled ke polovině roku 2026:

- **Malé rychlé modely** (jako levnější koncové body třídy GPT-3.5) stojí zlomek centu za tisíc tokenů.
- **Modely střední třídy** (jako GPT-4o nebo Claude Sonnet) obvykle stojí několik centů za tisíc tokenů.
- **Velké modely pro uvažování** (jako GPT-4.5 nebo Claude Opus) mohou stát deset až dvacet centů za tisíc tokenů.

Typická biblická otázka v Theodii může spotřebovat celkem od několika stovek do pár tisíc tokenů. To znamená, že většina otázek stojí **méně než cent až pár centů**.

### Tipy, jak udržet náklady nízké

- Začněte levnějším modelem. Většina biblických otázek nepotřebuje nejdražší model.
- Použijte Groq nebo OpenRouter, pokud chcete vyzkoušet různé modely a porovnat ceny.
- Sledujte svůj panel využití na stránkách poskytovatele.

## GitHub Models

[GitHub Models](https://github.com/marketplace/models) nabízí bezplatnou úroveň bez nutnosti předplatného. Stačí bezplatný účet GitHub a osobní přístupový token s povolením číst modely.

**Jak to nastavit:**

1. Přejděte na [github.com/settings/tokens](https://github.com/settings/tokens) a vytvořte **Personal access token (classic)**.
2. Dejte mu rozsah `models:read` (nebo prostě vyberte oprávnění pro modely).
3. V Theodii zvolte jako poskytovatele **GitHub Models** a vložte svůj token.

**Modely bezplatné úrovně:**

- `openai/gpt-4.1-nano` — **15 požadavků za minutu, 150 požadavků za den**
- `openai/gpt-4.1-mini` — **15 požadavků za minutu, 150 požadavků za den**
- `openai/gpt-4.1` — **10 požadavků za minutu, 50 požadavků za den**
- `openai/gpt-4o` — **10 požadavků za minutu, 50 požadavků za den**

Tyto limity se obnovují denně a pro pravidelné studium Bible stačí.

Kompletní průvodce krok za krokem s obrázky najdete v samostatném průvodci [GitHub Models](theodia://help/github-models).

## Poznámka o soukromí

Když používáte vzdálený AI model, aplikace nejprve zobrazí dotaz na souhlas, který vysvětluje, co se odesílá: vaše zprávy, kontext verše nebo kapitoly, volání nástrojů a jejich výsledky, název nastaveného modelu a váš API klíč v hlavičce požadavku. Požadavek jde přímo na koncový bod, který jste nastavili, ne přes Theodii. Většina poskytovatelů nepoužívá vaše data k trénování svých modelů, ale text opouští vaše zařízení. Povolení můžete kdykoli změnit nebo odvolat v **Nastavení → AI asistent → Sdílení dat se vzdálenou AI**.

## Shrnutí

- K používání AI asistenta potřebujete API klíč.
- Vytvořte si účet u poskytovatele, vygenerujte klíč a vložte ho do Theodie.
- Většina otázek stojí pár centů nebo méně.
