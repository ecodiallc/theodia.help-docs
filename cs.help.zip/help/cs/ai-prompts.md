---
title: Lepší AI prompty
level: advanced
categories: ai
summary: Jak se AI asistenta ptát tak, abyste dostali dobré odpovědi.
---

# Lepší AI prompty

> **Režim:** AI asistent vyžaduje režim **Scholar** (Badatel). Režim můžete přepnout v **Nastavení** → **Režim aplikace**.

„Prompt“ je otázka nebo pokyn, který dáváte AI. Lepší prompty dostávají lepší odpovědi. Tento průvodce vám ukáže jak.

## Buďte konkrétní

Špatně: „Pověz mi o lásce.“
Lépe: „V 1. Korintským 13, jaký druh lásky popisuje Pavel a čím se liší od romantické lásky?“

Čím více podrobností dáte, tím užitečnější je odpověď.

## Dejte kontext

Špatně: „Co znamená tento verš?“
Lépe: „Čtu Římanům 8 s malou skupinou. Co v této kapitole znamená ‚žádné odsouzení' a jak to souvisí se zbytkem kapitoly?“

Kontext pomáhá AI přizpůsobit odpověď vaší situaci.

## Ptejte se na jednu věc najednou

Špatně: „Pověz mi o modlitbě, víře a uzdravení.“
Lépe: „Nejprve mi pověz o modlitbě. Potom se zeptám na víru.“

Pokládání otázek po jedné udržuje odpovědi zaměřené.

## Požádejte AI, aby přijala roli

Můžete požádat AI, aby odpovídala v určitém tónu. Například:

- „Odpovídej, jako bys učil nového křesťana.“
- „Odpovídej jako biblický badatel.“
- „Odpovídej desetiletému dítěti.“

AI přizpůsobí odpověď roli.

## Používejte doplňující otázky

Pokud první odpověď není úplně správná, zeptejte se doplňující otázkou:

- „Můžeš to říct jednodušeji?“
- „Můžeš mi dát příklad?“
- „Co říká původní řečtina?“
- „Kde jinde v Bibli se tohle objevuje?“

Dobrá konverzace je dvojsměrná. AI si pamatuje posledních pár zpráv.

## Kontrolujte odpovědi AI

AI se může mýlit. Je to nástroj, ne učitel.

- Porovnejte odpověď AI s verši, na které odkazuje.
- Použijte komentáře a lexikony v aplikaci pro druhý názor.
- Pokud je odpověď o učení, zeptejte se pastora nebo důvěryhodného přítele.

## Běžné vzory promptů

Tady je pár, které fungují dobře:

- „Vysvětli mi tento verš, jako bych byl nový křesťan.“
- „Jaký je hlavní smysl této kapitoly v jedné větě?“
- „Vypiš tři aplikace pro můj každodenní život z tohoto místa.“
- „Na jaké otázky bych se měl ptát u tohoto verše, než ho budu kázat?“
