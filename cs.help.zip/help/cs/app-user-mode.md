---
title: Režim aplikace
level: beginner
categories: [user-mode]
summary: Vyberte si mezi režimy Čtenář, Standard a Badatel a ovládněte, které funkce jsou v aplikaci dostupné.
---

# Režim aplikace

Theodia nabízí tři uživatelské režimy, které určují, které funkce vidíte. Zvolte ten, který odpovídá tomu, jak chcete aplikaci používat.

## Čtenář

Nejjednodušší režim. Režim Čtenář je pro čtení Bible bez rozptylování.

- Čtěte jakýkoli překlad Bible
- Používejte režim Soustředění pro čisté čtení na celou obrazovku
- Navigujte knihy a kapitoly
- Žádné studijní nástroje, žádná AI, žádné záložky, žádná zvýraznění

Režim Čtenář je ideální, pokud chcete, aby Theodia působila jako čistá digitální Bible bez ničeho navíc.

## Standard

Režim Standard přidává každodenní funkce pro osobní studium Bible.

Vše z režimu Čtenář, plus:

- Záložky, zvýraznění a poznámky
- Převod textu na řeč
- Čtečka režimu Studium s nabídkou verše
- Paralelní Bible
- Zadávání příkazů
- Vyhledávání v Bibli
- Denní bohoslužebná čtení a vestavěné knihy

Režim Standard je správná volba pro většinu uživatelů, kteří chtějí číst, značkovat a prohledávat Bibli bez pokročilých studijních nástrojů.

## Badatel

Plnohodnotný režim. Režim Badatel odemkne každý nástroj v Theodii pro hluboké studium Bible.

Vše z režimu Standard, plus:

- Komentáře a lexikony
- Křížové odkazy
- Biblický slovník
- Info o slově (vyhledávání Strongových čísel)
- AI asistent a AI komentář
- Nabídka spouštěče

Režim Badatel je určen pro pastory, seminaristy a každého, kdo chce nástroje pro původní jazyky a studijní pomůcky poháněné AI.

## Jak přepnout režim

1. Otevřete **Nastavení**.
2. Klepněte na **Režim aplikace**.
3. Zvolte **Čtenář**, **Standard** nebo **Badatel**.

Změna se projeví okamžitě. Nabídky a tlačítka, ke kterým nemáte ve svém aktuálním režimu přístup, jsou skryté.

## Výběr režimu

- **Čtenář** — Chcete jen číst Bibli, nic víc.
- **Standard** — Chcete záložky, zvýraznění, poznámky, vyhledávání a bohoslužebná čtení.
- **Badatel** — Chcete všechny studijní nástroje, včetně AI, komentářů a lexikonů.

Režim můžete kdykoli přepnout. Vaše záložky, zvýraznění a poznámky se při změně režimu nikdy nemažou; jsou jen skryté, dokud se nevrátíte do režimu, který je podporuje.
