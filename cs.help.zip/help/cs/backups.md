---
title: Zálohování dat
level: everyday
categories: settings
summary: Jak uložit a obnovit své poznámky, zvýraznění, záložky a tajemství.
---

# Zálohování dat

Vaše poznámky, zvýraznění, záložky a nastavení jsou uloženy na vašem zařízení. Pokud telefon ztratíte, koupíte nový nebo aplikaci odinstalujete, tato data mohou být ztracena. Tento průvodce vám ukáže, jak je zálohovat.

## Jak otevřít nastavení zálohování

1. Otevřete **Nastavení**.
2. Klepněte na **Záloha aplikace**.

## Jak vytvořit zálohu aplikace

1. Otevřete **Nastavení**.
2. Klepněte na **Záloha aplikace**.
3. Klepněte na **Vytvořit zálohu aplikace**.
4. Vyberte složku na vašem zařízení, kam soubor uložíte. Můžete zvolit i cloudový disk.
5. Aplikace vytvoří jeden soubor se všemi vašimi daty. Soubor končí `.zip`.

## Jak často zálohovat

Zálohu vytvořte:

- Poté, co jste napsali hodně poznámek.
- Před aktualizací operačního systému vašeho zařízení.
- Před odinstalováním aplikace nebo výměnou telefonu.

Dobrým zvykem je jedna záloha měsíčně. Někteří lidé zálohují každý týden.

## Jak obnovit ze zálohy aplikace

1. Otevřete **Nastavení**.
2. Klepněte na **Záloha aplikace**.
3. Klepněte na **Obnovit ze zálohy aplikace**.
4. Vyberte záložní soubor `.zip`.
5. Pro každý typ dat (poznámky, zvýraznění, záložky atd.) zvolte, zda zachováte to, co je na zařízení, nahradíte to zálohou, nebo to přeskočíte.
6. Klepněte na **Obnovit**.

Aplikace nahradí vaše data daty ze zálohy. To zahrnuje:

- Poznámky
- Zvýraznění
- Záložky
- Složky záložek
- Nastavení (téma, velikost písma, jazyk)

## Záloha tajemství

Vaše **Záloha aplikace** **nezahrnuje** citlivá tajemství, jako je váš AI API klíč nebo GitHub token. Pro jejich samostatné zálohování použijte **Zálohu tajemství**.

### Uložení zálohy tajemství

1. Otevřete **Nastavení**.
2. Klepněte na **Záloha aplikace**.
3. V části **Záloha tajemství** klepněte na **Uložit zálohu tajemství**.
4. Zadejte silné heslo a potvrďte ho.
5. Aplikace zašifruje vaše tajemství a zašifrovaný soubor sdílí. Uložte ho na bezpečné místo.

### Obnovení zálohy tajemství

1. Otevřete **Nastavení**.
2. Klepněte na **Záloha aplikace**.
3. V části **Záloha tajemství** klepněte na **Obnovit zálohu tajemství**.
4. Vyberte zašifrovaný soubor zálohy tajemství.
5. Zadejte stejné heslo, které jste použili při ukládání.
6. Vaše tajemství se obnoví.

> **Důležité:** Pokud heslo zapomenete, tajemství nelze obnovit. Reset neexistuje.

## Co je dobré vědět

- Obnovení **nahradí** kategorie, které si vyberete. Cokoliv, co jste po záloze přidali, se pro tyto kategorie ztratí.
- Záloha aplikace je jeden soubor `.zip`. Uložte ho na bezpečné místo.
- Soubor můžete kopírovat, přesouvat nebo uložit v jakékoli cloudové službě.
- Zálohy aplikace nezahrnují samotné překlady Bible. Ty lze znovu stáhnout z **Nastavení** → **Spravovat zdroje**.
- Zálohy tajemství jsou šifrovány vaším heslem. Zvolte si heslo, které si zapamatujete.

## Tipy

Pokud máte více než jedno zařízení, můžete zkopírovat záložní soubor na každé zařízení a obnovit ho. Vaše data budou na obou stejná.
