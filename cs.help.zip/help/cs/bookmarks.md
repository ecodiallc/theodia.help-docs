---
title: Ukládání veršů do záložek
level: everyday
categories: [annotate, read]
summary: Jak si uložit verše, abyste je mohli znovu najít.
---

# Ukládání veršů do záložek

> **Režim:** Záložky jsou dostupné v režimu **Standard** a **Badatel**. Režim Soustředění je určen jen pro čisté čtení bez rozptylování. Režim můžete přepnout v **Nastavení** → **Režim aplikace**.

Záložka uloží verš nebo kapitolu knihy, abyste je mohli znovu najít. Záložky jsou jako papírové záložky v knize.

## Jak uložit verš do záložek

1. Otevřete verš.
2. Klepněte na verš, čímž zobrazíte nabídku.
3. V nabídce klepněte na **Záložka**. Ikona hvězdičky označí verš jako uložený.

Značka na ikoně znamená, že verš je nyní v záložkách.

## Jak uložit kapitolu knihy do záložek

Při čtení knihy (ne Bible) můžete uložit celou kapitolu:

1. Otevřete kapitolu.
2. Klepněte na ikonu **Záložka** nahoře na obrazovce.

## Jak vidět své záložky

Klepněte na záložku **Záložky** dole. Uvidíte seznam všech uložených veršů a kapitol knih.

## Jak odebrat záložku

- **Jeden verš:** Otevřete verš. Klepněte na verš, potom znovu klepněte na ikonu **Záložka**. Značka zmizí.
- **Ze seznamu:** V záložce **Záložky** dlouze stiskněte záložku. Zobrazí se malá nabídka. Klepněte na **Smazat**. (Můžete také klepnout na malé tlačítko × na řádku.)

## Uspořádání do složek

Záložky můžete ukládat do složek. Například můžete mít složku s názvem „Příprava kázání“ a další s názvem „Povzbuzení“.

Vytvoření složky:

1. Otevřete záložku **Záložky**.
2. Nahoře klepněte na **Spravovat složky**.
3. Nahoře v seznamu složek klepněte na **+ Vytvořit složku**.
4. Zadejte název a klepněte na **Uložit**.

Dvě složky se stejným názvem vytvořit nelze. Pokud název už existuje, zobrazí se chyba uvnitř pole pro vytvoření složky, takže název můžete změnit a zkusit to znovu.

Uložení záložky do složky:

1. V záložce **Záložky** dlouze stiskněte záložku.
2. Klepněte na **Uložit do složky**.
3. Vyberte složku a potom klepněte na **Hotovo**.

## Import záložek

Záložky můžete do Theodie přenést z jiných aplikací a souborů.

Přejděte na **Nastavení** → **Záložky** → **Importovat záložky**. Zvolte **Importovat ze souboru** nebo vložte obsah ze schránky. Aplikace formát rozpozná automaticky.

### Podporované formáty

**Nativní export JSON** — Formát používaný vlastní funkcí exportu Theodie. Zachovává složky a data vytvoření.

**Netscape Bookmark HTML** — Formát, který při exportu záložek používají Chrome, Firefox a Safari. Složky se zachovají.

**CSV** — Tabulka se sloupci. Aplikace hledá sloupce `url` a `folder` (nebo `href` / `category`). Příklad:

```csv
url,folder
/bible/KJV/John/3,Favorites
/bible/KJV/Genesis/1,Sermon Prep
```

**Prostý text** — Každý řádek je buď biblický odkaz, URL aplikace, nebo pokyn pro složku. Příklad:

```
folder: Favorites
John 3:16
Genesis 1:1
folder: Sermon Prep
Matthew 5:1
```

- Řádky začínající na `folder: <název>` nastaví aktivní složku pro všechny následující záložky.
- Biblické odkazy jako `John 3:16` se převedou na záložky ve vaší výchozí Bibli.
- URL aplikace jako `/bible/KJV/John/3#v3_16` nebo `/book/MyBook/1` se importují přímo.
- Řádky začínající na `#` nebo `//` se považují za komentáře a přeskočí se.

### Tipy pro import

- Duplicitní záložky se automaticky přeskočí.
- Externí URL (například odkazy na BibleGateway) se tam, kde to jde, převedou na záložky aplikace.
- Pokud složka z importovaného souboru už existuje, záložky se umístí do existující složky.

## Tipy

- Stejný verš můžete uložit do záložek v mnoha překladech. Všechny se objeví v seznamu.
- Záložky zůstávají na vašem zařízení. Nesynchronizují se do cloudu.
- Jak je udržet v bezpečí, popisuje průvodce [Zálohování dat](theodia://help/backups).

## Záložky v PDF

PDF mají vlastní záložky, které se uchovávají odděleně od záložek Bible. Při čtení PDF klepněte na tlačítko **Záložka** v liště čtečky, uložte aktuální stránku, dejte jí název a později se na ni můžete vrátit. Každé PDF má vlastní seznam — viz [PDF](theodia://help/pdfs).
