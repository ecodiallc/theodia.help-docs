---
title: Výběr AI modelu
level: advanced
categories: ai
summary: Jak vybrat model, který dobře spolupracuje s vestavěnými nástroji a schopnostmi Theodie.
---

# Výběr AI modelu

> **Režim:** AI asistent vyžaduje režim **Scholar** (Badatel). Režim můžete přepnout v **Nastavení** → **Režim aplikace**.

Ne každý AI model funguje v Theodii stejně. Nejlepší zážitek přináší model, který podporuje **volání nástrojů** — schopnost AI používat vestavěné funkce Theodie, jako je vyhledávání biblických veršů, hledání, čtení komentářů a ovládání aplikace.

## Co je volání nástrojů?

Když se zeptáte AI v Theodii, může udělat víc, než jen mluvit. Umí také **jednat**. Například:

- Řeknete: „Ukaž mi Jan 3:16 v ESV.“ AI zavolá nástroj, který otevře tento verš v čtečce.
- Řeknete: „Co říkají mé komentáře o Římanům 8:28?“ AI zavolá nástroj, který načte obsah komentáře.
- Řeknete: „Ulož tento verš do záložek.“ AI zavolá nástroj, který záložku vytvoří.

Modely, které nepodporují volání nástrojů, vám mohou dát jen textové odpovědi. Nemohou nic vyhledat, nikam se navigovat ani v aplikaci nic změnit.

## Které modely podporují nástroje?

### Vzdálené modely

Většina moderních vzdálených modelů od velkých poskytovatelů podporuje volání nástrojů kompatibilní s OpenAI. Obecně:

- **Velké modely** (jako GPT-4o, Claude Sonnet/Opus, Gemini Pro) zvládají nástroje spolehlivě a dokážou v jedné konverzaci řetězit víc volání nástrojů. Názvy poskytovatelů a ID modelů se v aplikaci zobrazují pro přehlednost; skutečnou službou, ke které se připojujete, je ta, jejíž koncový bod a klíč nastavíte.
- **Menší nebo levnější modely** nástroje podporovat mohou, ale jsou méně spolehlivé. Mohou volání nástroje ignorovat nebo ho nesprávně naformátovat.
- **Velmi staré nebo specializované modely** často nástroje nepodporují vůbec.

Pokud si nejste jisti, model v Theodii vyzkoušejte. Požádejte ho: „Ukaž mi Genesis 1:1“ nebo „Prohledej Bibli na verše o lásce.“ Pokud se verš otevře nebo se objeví výsledky hledání, volání nástrojů funguje.

## Doporučené modely pro Theodii

Tohle jsou dobré volby, které vyvažují cenu, kvalitu a podporu nástrojů:

- **OpenAI GPT-4o** — výborná podpora nástrojů, rychlý, dobře zvládá složité vícekrokové otázky.
- **Anthropic Claude Sonnet / Opus** — velmi spolehlivé používání nástrojů, skvělé pro dlouhá místa a podrobné studium.
- **Groq** (různé modely) — rychlá inference, často zdarma nebo velmi levné, podpora nástrojů se liší podle modelu.
- **OpenRouter** — umožňuje vyzkoušet mnoho modelů z jednoho účtu. Hledejte modely, které ve svých schopnostech uvádějí „function calling“ nebo „tools“.
- **[GitHub Models](theodia://help/github-models)** — doporučený bezplatný poskytovatel. Přístup k modelům OpenAI, Anthropic a dalším přes váš GitHub účet se štědrým denním bezplatným limitem. Používá ID modelů ve stylu `openai/gpt-4o`.

## Modelům se vyhněte

- **Modely čistě pro dokončování textu** (jako základní GPT-3 nebo syrová LLaMA bez instrukčního ladění) obvykle nástroje nepodporují.
- **Modely jen pro obrázky nebo vizuální modely** zaměřené na obrázky spíše než text mohou chybět podpora nástrojů.
- **Extrémně malé modely** pod 1 miliardu parametrů nejspíš nástroje nepoužijí správně, i když API tvrdí, že je podporují.

## Jak otestovat podporu nástrojů

Theodia kontroluje podporu nástrojů automaticky. Poté, co model nastavíte v **Nastavení → AI asistent**, klepněte na **Otestovat připojení**. Jakmile připojení uspěje, aplikace odešle druhý požadavek s ukázkovou definicí nástroje. Uvidíte jeden ze dvou výsledků:

- **✓ Nástroje podporovány** — Model přijímá volání nástrojů a může používat vestavěné funkce Theodie.
- **✗ Nástroje nepodporovány** — Model požadavek na nástroj odmítne. Bude odpovídat pouze textem a nemůže za vás otevírat verše, hledat ani spravovat záložky.

Pokud uvidíte „Nástroje nepodporovány“, model může stále fungovat jako obyčejný textový chat asistent, ale integrovaný zážitek bez použití rukou vám unikne.

Můžete to ověřit i ručně, když požádáte AI o něco udělat:

- „Ukaž mi Matouše 5:3 v KJV.“ — Měl by otevřít verš v čtečce.
- „Co říká lexikon o slově ‚agape' v Janu 3:16?“ — Měl by vrátit data z lexikonu.
- „Prohledej Bibli na verše o odpuštění.“ — Měly by se vrátit výsledky hledání.
- „Přidej Markovi 12:30 do záložek.“ — Měla by se vytvořit záložka.

Pokud vám AI dá textový popis místo toho, aby věc skutečně udělala, model se s nástroji potýká, i když aplikace ohlásila podporu.

## Co když můj model nástroje nepodporuje?

Stále ho můžete používat. AI bude odpovídat textem a verše si můžete vyhledat, hledat a ovládat aplikaci ručně sami. Ale unikne vám integrovaný zážitek bez použití rukou, který dělá Theodii mocnou.

## Shrnutí

- Pro nejlepší zážitek s Theodií zvolte model s podporou **volání nástrojů / function calling**.
- **Velké vzdálené modely** zvládají nástroje nejspolehlivěji.
- Jakýkoli model vyzkoušejte jednoduchými příkazy jako „Ukaž mi Genesis 1:1“, abyste ověřili podporu nástrojů.
