---
title: Výběr překladu Bible
level: beginner
categories: [read, study]
summary: Jednoduchý průvodce výběrem správného překladu pro vás.
---

# Výběr překladu Bible

Biblický „překlad“ je úsilí jednoho člověka vyjádřit Bibli slovy, kterým rozumíte. Různé překlady zní různě. Některé jsou slovo za slovem. Některé myšlenku za myšlenkou. Špatná volba neexistuje. Zvolte ten, který vám čte nejlépe.

## Dva hlavní styly

**Překlady slovo za slovem** se snaží zachovat stejná slova jako původní jazyky (hebrejština a řečtina). Čtou se hůře, ale působí blíž ke zdroji. Příklady: KJV, WEB.

**Překlady myšlenku za myšlenkou** se snaží přenést význam originálu do slov, která lidé používají dnes. Čtou se snadněji. Příklady: BSB, UST.

## Několik oblíbených překladů

- **KJV (King James Version).** Staroanglický styl. Milovaný mnoha čtenáři.
- **WEB (World English Bible).** Slovo za slovem. Moderní veřejná doména v angličtině.
- **BSB (Berean Standard Bible).** Myšlenku za myšlenkou. Snadné čtení.
- **UST (unfoldingWord Simplified Text).** Myšlenku za myšlenkou. Používá jednoduchou, srozumitelnou angličtinu.

## Jak jeden vyzkoušet

Můžete si nainstalovat tolik překladů, kolik chcete. Přečtěte stejný verš ve dvou nebo třech. Uvidíte, který vám pomůže nejvíc.

## Jak porovnat

Otevřete kapitolu a klepnutím na název překladu nahoře přepnete. Funkce **Porovnat** (viz průvodce [Porovnávání překladů](theodia://help/compare-translations)) ukazuje dva překlady vedle sebe.
