---
title: Příkazy
level: everyday
categories: [layout, study]
summary: Zadávání příkazů vám umožní přeskočit na libovolnou funkci krátkým příkazem. Naučte se podporované formáty a příklady.
---

# Příkazy

Pole **Příkaz** vám umožní přeskočit do téměř jakékoli části Theodie krátkým pokynem. Můžete ho použít ze záložky Domů nebo z **Nabídky spouštěče** (ikona **▼** v hlavičce).

## Jak to funguje

1. Klepněte na pole Příkaz.
2. Zadejte příkaz.
3. Klepněte na klávesu pro odeslání na klávesnici.

Aplikace přečte příkaz a zavede vás rovnou na správnou obrazovku.

## Žádná lomítková předpona

Příkazy **nepoužívají** předponu `/`. Zadávají se jako prostý text:

```
john 3:16
search love
backup
```

Pokud napíšete `/settings`, úvodní `/` z něj udělá nerozpoznaný příkaz.

## Biblické odkazy

Zadejte jakýkoli biblický odkaz a otevře se v čtečce.

```
psalms 23
john 3:16
matthew 5:1
1 cor 15:10
```

Názvy knih se najdou podle plného názvu nebo zkratky. V neuvedených jazycích rozhraní můžete názvy knih psát i v aktivním jazyce.

## Hledání

```
search abraham
search love
search faith not works
```

## Záložky, porovnání, komentář, křížové odkazy a info o slově

```
bookmark john 3:16
compare genesis 1:1
commentary john 1
aicommentary eph 2:8
xref 1 cor 15:10
word info john 1:1
```

Tyto příkazy otevřou pojmenovaný nástroj pro zadané místo.

## Lexikon

Zadejte Strongovo číslo a otevře se položka lexikonu.

```
g1161
h7225
```

## Bohoslužebná čtení

```
devotional
devotional smith
devotional daily
```

Bez názvu toto otevře seznam bohoslužebných čtení.

## Zkratky navigace

```
notes
highlights
bookmarks
flashcards
playlist
theoscript
resources
read john 3:16
```

Tyto příkazy skočí přímo na pojmenovanou obrazovku nebo otevřou místo v čtečce.

## Přepnutí překladu

Zadejte zkratku překladu a přepnete na něj.

```
kjv
web
trlit
ohgb
```

Na obrazovce čtečky se překlad vystřídá na místě. Kdekoliv jinde se otevře překlad na vašem posledním místě.

## Lokalizované příkazové slovesa

Veřejná příkazová slovesa lze psát v jazyce aktivního rozhraní **nebo** v angličtině. Angličtina vždy funguje jako záložní varianta. Skryté příkazy (zkratky nastavení, instalační příkazy, velikonoční vajíčka) zachovávají pouze anglickou syntaxi.

## Nápověda

Zadejte `help` nebo `commands` do pole Příkaz, kdykoli otevřete aplikaci reference příkazů.
