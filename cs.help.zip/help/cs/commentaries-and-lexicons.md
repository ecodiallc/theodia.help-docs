---
title: Komentáře a lexikony
level: everyday
categories: study
summary: Jak vyhledat významy slov a číst studijní poznámky.
---

# Komentáře a lexikony

> **Režim:** Komentáře a lexikony vyžadují režim **Scholar** (Badatel). Režim můžete přepnout v **Nastavení** → **Režim aplikace**.

Theodia obsahuje dva studijní nástroje: **komentáře** a **lexikony**. Pomáhají vám porozumět Bibli hlouběji.

## Co je komentář?

Komentář je kniha studijních poznámek napsaná biblickým badatelem. U daného verše vám komentář říká pozadí, význam a jak verš zapadá do zbytku Bible.

## Co je lexikon?

Lexikon je slovník biblických slov. Říká vám původní hebrejské nebo řecké slovo, co znamená a jak se v Bibli používá.

## Jak otevřít komentář

1. Otevřete kapitolu.
2. Klepněte na verš.
3. Klepněte na **Komentář**.

Otevře se panel. Ukazuje poznámky biblického badatele o tomto verši.

## Jak otevřít lexikon

1. Otevřete kapitolu v Bibli, která obsahuje Strongova čísla.
2. Klepněte na Strongovo číslo ve verši (například G1234 nebo H1234).
3. Otevře se panel s původním hebrejským nebo řeckým slovem, jeho významem a dalšími verši, které slovo používají.

Strongova čísla se v textu verše zobrazují jinou barvou, takže vyčnívají z běžných slov.

## Zvolit jiný komentář

Komentář se volí z rozbalovacího seznamu nahoře na panelu komentáře samotném. Otevřete panel, potom klepněte na rozbalovací seznam a uvidíte nainstalované komentáře. Vyberte jiný.

## Zvolit jiný lexikon

Lexikon se volí z rozbalovacího seznamu nahoře na panelu lexikonu. Otevřete panel, potom klepněte na rozbalovací seznam a uvidíte nainstalované lexikony. Vyberte jiný.

## Vestavěné zdroje

Theodia přichází s vestavěnou sadou komentářů a lexikonů. Ty jsou součástí aplikace a fungují offline. Další komentáře a lexikony nelze instalovat ani stahovat samostatně.

## Kdy je použít

- **Komentáře** jsou dobré, když je verš těžké pochopit. Poznámky vám dodají pozadí.
- **Lexikony** jsou dobré pro studium slov. Řeknou vám přesný význam slova v původním jazyce.

## Tipy

Pokud má verš poznámku, kterou si chcete ponechat, pořiďte snímek obrazovky nebo zkopírujte text do poznámky. (Viz průvodce [Psání poznámek](theodia://help/notes).)

## Biblický slovník v prostém jazyce

Pro definice biblických slov a pojmů v angličtině (smlouva, smíření, farizeové a tak dále) Theodia obsahuje také nástroj Biblický slovník. Otevřete ho z nabídky verše klepnutím na **Slovník** (📖). Liší se od lexikonu: lexikony vysvětlují původní hebrejská a řecká slova, zatímco slovník vysvětluje anglické slovo prostým jazykem. Jak ho používat, popisuje průvodce [Biblický slovník](theodia://help/dictionary).
