---
title: Časté problémy
level: everyday
categories: trouble
summary: Rychlé opravy problémů, na které můžete narazit.
---

# Časté problémy

Tento průvodce pokrývá problémy, na které lidé narážejí nejčastěji. Pokud váš problém není tady, viz průvodce [Kde klást otázky](theodia://help/getting-more-help).

## Aplikace je pomalá

1. Zavřete ostatní aplikace běžící na pozadí.
2. Restartujte aplikaci.
3. Restartujte zařízení.

## Nemohu najít překlad Bible

1. Otevřete **Nastavení** → **Spravovat zdroje** a podívejte se, co je nainstalováno.
2. Pokud překlad tam není, klepněte na **Instalovat z GitHub**.
3. V modálním okně stahování klepněte na záložku **Bible** (nebo **Globální Bible**) a vyberte požadovaný překlad.
4. Klepněte na **Instalovat vybrané** a počkejte na dokončení stahování.
5. Ke stažení nového překladu potřebujete internet.

## Moje poznámky nebo záložky zmizely

1. Zkontrolujte, že se díváte na správnou záložku. Poznámky jsou na záložce **Poznámky**. Záložky jsou na záložce **Záložky**.
2. Pokud jste nedávno obnovili zálohu, mohla nahradit vaše data. Zkontrolujte datum zálohy.
3. Pokud jste aplikaci odinstalovali a nainstalovali znovu, vaše data byla ztracena. Příště si nejdřív udělejte zálohu.

## Hledání nenachází verše

1. Zkontrolujte, že jste slovo napsali správně.
2. Zkuste kratší slovo. „Láska“ najde víc veršů než „milující“.
3. Zkontrolujte, že máte nainstalovaný správný překlad Bible. Hledání funguje jen v překladech, které máte.

## Čtení nahlas nefunguje

1. Zkontrolujte, že hlasitost vašeho zařízení je zvýšená.
2. Zkontrolujte, že aplikace smí používat reproduktor.
3. Zkuste jiný překlad. Některé překlady fungují s čtením nahlas lépe než jiné.
4. Podrobný kontrolní seznam najdete v průvodci [Čtení nahlas](theodia://help/tts).

## Aplikace se neustále hroutí

1. Restartujte aplikaci.
2. Restartujte zařízení.
3. Pokud problém pokračuje, nahlaste ho prosím. Viz průvodce [Kde klást otázky](theodia://help/getting-more-help).

## Chci aplikaci odinstalovat

Theodia můžete odinstalovat jako jakoukoli jinou aplikaci. Než tak uděláte, udělejte zálohu svých dat. Po odinstalování jsou data na zařízení pryč.

## Pořád uvízlí?

Viz průvodce [Kde klást otázky](theodia://help/getting-more-help). Najdete tam odkazy k nahlášení problému a k otázce komunitě.

Průvodce si můžete prohledávat i z hlavní obrazovky **Nápověda a průvodci**. Napište slovo jako `notifications`, `search` nebo `bookmarks` a najdete odpovídajícího průvodce.
