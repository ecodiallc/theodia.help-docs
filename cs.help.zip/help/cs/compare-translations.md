---
title: Porovnávání překladů
level: everyday
categories: [read, study]
summary: Jak vidět stejný verš v každém nainstalovaném překladu.
---

# Porovnávání překladů

> **Režim:** Nástroj Porovnat je dostupný v režimu **Standard** a **Badatel**. Režim Soustředění je určen jen pro čisté čtení bez rozptylování. Režim můžete přepnout v **Nastavení** → **Režim aplikace**.

Nástroj **Porovnat** ukazuje jeden verš v každém nainstalovaném překladu Bible, vše v jednom panelu. Je užitečný, když chcete vidět, jak různí překladatelé zacházejí s těžkým veršem, nebo když si vybíráte překlad a chcete vidět stejný verš v každém z nich.

## Jak otevřít Porovnat

1. Otevřete kapitolu v libovolném překladu.
2. Klepněte na verš, čímž zobrazíte nabídku verše.
3. Klepněte na **Porovnat** (⇄).

Otevře se panel. Hlavička ukazuje odkaz (například „Jan 3:16 — Porovnat“). Panel vypíše stejný verš v každém nainstalovaném překladu. Váš aktuální překlad je vypsán první; ostatní jsou seřazeny abecedně.

## Jak panel vypadá

Panel je **svislý seznam**, nikoli sloupce vedle sebe. Každý řádek je jeden překlad:

- **Název překladu** (například „KJV“) je nahoře na řádku. Je klepnutelný.
- **Text verše** je pod názvem.

Projděte panel, abyste viděli všechny překlady. Zobrazí se zde každý překlad nainstalovaný na vašem zařízení. Pokud překlad danou knihu nebo verš nemá, vynechá se.

## Jak přečíst verš v jiném překladu

Klepněte na název překladu na řádku. Panel Porovnat se zavře a stejná kapitola se otevře se zvoleným veršem v tomto překladu. To je nejrychlejší cesta, jak z porovnání rovnou přejít ke čtení konkrétního překladu.

## Jak zavřít Porovnat

- **Na telefonu:** klepněte na X vpravo nahoře na panelu.
- **Na tabletu:** klepněte na X v hlavičce panelu, nebo klepněte mimo panel.

Vrátíte se zpět na zobrazení kapitoly ve vašem původním překladu.

## Kdy Porovnat použít

- **Výběr překladu.** Otevřete verš, který znáte dobře ve vašem aktuálním překladu, a pak Porovnat, abyste ho viděli v ostatních. Rozdíly vyniknou.
- **Těžké verše.** Verš, který je v jednom překladu matoucí, je v jiném často jasnější.
- **Studium slov.** Podívejte se, jak různí překladatelé zacházejí s klíčovým slovem nebo frází.

Pro srovnání celé kapitoly ve více překladech najednou na první pohled použijte místo toho **paralelní zobrazení**. Jak ho zapnout, popisuje průvodce [Režim Studium](theodia://help/study-mode).
