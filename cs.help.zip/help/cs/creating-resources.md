---
title: Tvorba vlastních zdrojů
level: advanced
categories: resources
summary: Jak vytvořit vlastní Bible, komentáře, knihy, bohoslužebná čtení a lexikony a importovat je do Theodie.
---

# Tvorba vlastních zdrojů

Theodia podporuje vlastní zdroje ve formátu Unique Bible App. Každý zdroj je SQLite soubor s určitou strukturou tabulek. Tyto soubory můžete vytvořit na počítači a importovat do aplikace.

## Typy souborů a požadované tabulky

### Bible (`.bible`)

Biblický soubor je SQLite databáze s alespoň jednou z těchto tabulek:

- **`Verses`** — sloupce: `Book` (celé číslo, 1-66), `Chapter` (celé číslo), `Verse` (celé číslo), `Scripture` (text)
- **`Bible`** — sloupce: `Book` (celé číslo), `Chapter` (celé číslo), `Verse` (celé číslo), `Scripture` (text)

Můžete přidat i tabulku **`Details`** s metadatovými sloupci, jako jsou `Description`, `Abbreviation` a `Version`.

Příklad SQL:

```sql
-- Main text table
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- Optional metadata table
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### Komentáře (`.commentary`)

Komentáře přicházejí ve třech typech: **kniha**, **kapitola** a **verš**. Typ určuje **první písmeno názvu souboru**.

#### Knižní komentáře — název souboru začíná na `b`

Knižní komentář pokrývá celou knihu Bible v jedné položce. Tabulka `Commentary` potřebuje sloupce `Book` a `Scripture` (nebo `Content`). Sloupce `Chapter` nebo `Verse` nejsou potřeba.

- **`Commentary`** — sloupce: `Book` (celé číslo), `Scripture` (text) nebo `Content` (text)

Příklad SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

Příklad názvu souboru: `bMyCommentary.commentary`

#### Komentáře ke kapitolám — název souboru začíná na `c`

Komentář ke kapitolám pokrývá každou kapitolu biblické knihy.

- **`Commentary`** — sloupce: `Book` (celé číslo), `Chapter` (celé číslo), `Scripture` (text) nebo `Content` (text)

Příklad SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

Příklad názvu souboru: `cMyCommentary.commentary`

#### Komentáře k veršům — název souboru začíná na `v`

Komentář k veršům pokrývá jednotlivé verše. Tabulka `Commentary` potřebuje sloupce `Book`, `Chapter`, `Verse` a `Scripture` (nebo `Content`).

- **`Commentary`** — sloupce: `Book` (celé číslo), `Chapter` (celé číslo), `Verse` (celé číslo), `Scripture` (text) nebo `Content` (text)

Příklad SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

Příklad názvu souboru: `vMyCommentary.commentary`

### Knihy (`.book`)

Soubor knihy je SQLite databáze s tabulkou `Reference`.

- **`Reference`** — sloupce: `id` (celé číslo), `Chapter` (text), `Content` (text)

Každý řádek je jedna kapitola. Sloupec `Chapter` je název kapitoly. Sloupec `Content` je tělo kapitoly, které může obsahovat HTML (`<b>`, `<i>`, `<br>` atd.).

Příklad SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

Knihy můžete vytvářet i ze souborů Markdown. Aplikace umí importovat `.md` soubory, kde `#` je název knihy a `##` označuje kapitoly. Markdown se automaticky převede na HTML.

### Bohoslužebná čtení (`.devotional`)

Soubor bohoslužebného čtení je SQLite databáze s tabulkou `devotional`.

- **`devotional`** — sloupce: `month` (celé číslo, 1-12), `day` (celé číslo, 1-31), `devotion` (text)

Každý řádek je čtení na jeden den. Aplikace vyhledá položku podle dnešního měsíce a dne.

Příklad SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### Lexikony (`.lexicon`)

Soubor lexikonu je SQLite databáze s tabulkou `Lexicon`.

- **`Lexicon`** — sloupce: `Topic` (text, Strongovo číslo), `Definition` (text, položka lexikonu)

Sloupec `Topic` obsahuje Strongovo číslo (například `G1161` nebo `H7225`). Sloupec `Definition` obsahuje plný text položky, který může obsahovat HTML.

Příklad SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

Lexikony pohánějí nástroj Info o slově. Když klepnete na slovo v interlineární Bibli, aplikace vyhledá Strongovo číslo v nainstalovaných lexikonech.

## Vytvoření souboru na počítači

1. Nainstalujte editor SQLite (DB Browser for SQLite, SQLiteStudio, nebo nástroj `sqlite3` pro příkazovou řádku).
2. Vytvořte nový databázový soubor.
3. Vytvořte požadovanou tabulku a vložte svá data.
4. Uložte soubor se správnou příponou (`.bible`, `.commentary`, `.book`, `.devotional` nebo `.lexicon`).

## Import do Theodie

1. Přeneste soubor do svého zařízení (AirDrop, e-mail, cloudové úložiště nebo USB).
2. Otevřete **Theodii**.
3. Přejděte na **Nastavení** → **Spravovat zdroje**.
4. Klepněte na **Importovat ze souboru**.
5. Vyberte svůj soubor.

Aplikace soubor zvaliduje (zkontroluje požadovanou tabulku), zkopíruje ho do datové složky aplikace a automaticky ho povolí. Pokud je soubor neplatný, uvidíte chybovou zprávu vysvětlující, co je špatně.

## Omezení

- Vestavěné zdroje nelze přepsat. Pokud se pokusíte importovat soubor se stejným názvem jako vestavěná Bible, komentář nebo kniha, import selže.
- Biblické soubory potřebují tabulku `Verses` nebo `Bible`. Pokud žádná neexistuje, import selže.
- Soubory komentářů potřebují tabulku `Commentary`.
  - Knižní komentáře potřebují sloupce `Book` a `Scripture` (nebo `Content`).
  - Komentáře ke kapitolám potřebují sloupce `Book`, `Chapter` a `Scripture` (nebo `Content`).
  - Komentáře k veršům potřebují sloupce `Book`, `Chapter`, `Verse` a `Scripture` (nebo `Content`).
- Soubory knih potřebují tabulku `Reference`.
- Soubory lexikonů potřebují tabulku `Lexicon`.
- Soubory bohoslužebných čtení potřebují tabulku `devotional`.

## Tipy

- Udržujte velikosti souborů rozumné. Velmi velké SQLite soubory mohou způsobit problémy s pamětí na starších zařízeních.
- Soubor si nejdřív vyzkoušejte na počítači. Otevřete ho v SQLite prohlížeči a spusťte `SELECT * FROM` požadované tabulky, abyste ověřili, že data vypadají správně.
- Pro Bible se ujistěte, že sloupec `Book` používá čísla (1 = Genesis, 66 = Zjevení).
- Pro komentáře můžete jako sloupec textu komentáře použít `Scripture` nebo `Content`.
- Pro knihy se HTML ve sloupci `Content` při čtení vykresluje. Udržujte to jednoduché: `<b>`, `<i>`, `<br>` a `<hr>` jsou bezpečné.

## Kde najít existující zdroje

Theodia umí číst zdroje z projektu [Unique Bible App](https://github.com/eliranwong/UniqueBible). Mnoho Biblí, komentářů, knih a dalších zdrojů je tam dostupných ve správném formátu SQLite. Jak je najít a přidat, popisuje průvodce [Získání dalších zdrojů](theodia://help/getting-core-files).
