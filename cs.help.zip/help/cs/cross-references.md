---
title: Křížové odkazy
level: everyday
categories: study
summary: Jak najít verše, které se vážou k tomu, který čtete.
---

# Křížové odkazy

> **Režim:** Křížové odkazy jsou dostupné v režimu **Standard** a **Badatel**. Režim Soustředění je určen jen pro čisté čtení bez rozptylování. Režim můžete přepnout v **Nastavení** → **Režim aplikace**.

„Křížový odkaz“ je jiný verš, který mluví o témtéž jako verš, který čtete. Panel křížových odkazů vám ukáže, které verše v Bibli se navzájem propojují.

## Jak otevřít křížové odkazy

1. Otevřete kapitolu.
2. Klepněte na verš, čímž zobrazíte nabídku verše.
3. Klepněte na **Křížové odkazy**.

Otevře se panel. Ukazuje seznam dalších veršů, které se vážou k tomu, na který jste klepnuli.

## Jak číst seznam

Každý řádek je jeden propojený verš. Vidíte:

- Knihu, kapitolu a verš.
- Krátký náhled textu verše.
- Skóre ukazující, jak silné spojení je.

## Jak přeskočit na propojený verš

Klepněte na libovolný řádek. Aplikace vám daný verš otevře. Až skončíte, klepněte na tlačítko zpět a vraťte se.

## Co znamená skóre

Skóre vám říká, jak úzce jsou verše propojeny. Vysoké skóre znamená silné, přímé spojení. Nízké skóre znamená volnější.

## Použití křížových odkazů ke studiu

Křížové odkazy jsou užitečné pro:

- **Studium slov.** Podívejte se, jak Bible používá slovo na různých místech.
- **Studium témat.** Sledujte téma, jako „láska“ nebo „smlouva“, napříč Písmem.
- **Přípravu kázání.** Najděte podpůrné verše rychle.

## Tipy

Křížové odkazy fungují nejlépe s překladem slovo za slovem, jako je WEB.
