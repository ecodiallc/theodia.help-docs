---
title: Denní bohoslužebná čtení
level: everyday
categories: [content, read]
summary: Jak si denně přečíst krátké bohoslužebné čtení.
---

# Denní bohoslužebná čtení

Bohoslužebné čtení je krátké čtení na jeden den. Často má verš, krátkou myšlenku a otázku k zamyšlení. Theodia přichází s malou knihovnou bohoslužebných čtení.

## Jak otevřít bohoslužebné čtení

1. Klepněte na záložku **Bohoslužebná čtení** dole na obrazovce.
2. Uvidíte seznam bohoslužebných čtení nainstalovaných na vašem zařízení.
3. Klepněte na jedno a otevřete ho.

## Jak číst bohoslužebné čtení

1. Otevřete bohoslužebné čtení.
2. Projděte se čtením posouváním.
3. Tlačítka nahoře slouží k:
   - Klepnutím na **datum** přeskočíte na jiný den.
   - Klepnutím na **hvězdičku** uložíte den do záložek.
   - Klepnutím na **reproduktor** si ho přečtete nahlas (pokud to vaše zařízení podporuje). Jak zvolit hlas, popisuje průvodce [Čtení nahlas](theodia://help/tts).
   - Klepnutím na **Předchozí** nebo **Další** přejdete na den předchozí nebo následující.

## Jak uložit verš z bohoslužebného čtení

1. Otevřete bohoslužebné čtení.
2. Klepněte na verš.
3. Klepněte na **Záložka** nebo **Zvýraznit**.

Verš se uloží do vašich Záložek nebo Zvýraznění.

## Jak napsat poznámku k bohoslužebnému čtení

1. Otevřete bohoslužebné čtení.
2. Klepněte na verš.
3. Klepněte na **Poznámka**. Napište svou úvahu nebo modlitbu. Klepněte na **Uložit**.

Poznámka se objeví na vaší záložce Poznámky.

## Tipy

- Bohoslužebná čtení nepotřebují internet. Fungují offline.
- Pokud byste chtěli víc bohoslužebných čtení, podívejte se na průvodce [Získání dalších zdrojů z GitHub](theodia://help/getting-core-files).
