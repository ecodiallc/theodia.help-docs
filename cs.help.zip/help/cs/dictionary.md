---
title: Biblický slovník
level: everyday
categories: study
summary: Vyhledejte biblická slova a pojmy v nainstalovaných slovních zdrojích. Otevřete ho z nabídky verše nebo z položky lexikonu, potom klepněte na libovolné slovo a uvidíte stejné slovo v každém slovníku.
---

# Biblický slovník

> **Režim:** Biblický slovník vyžaduje režim **Scholar** (Badatel). Režim můžete přepnout v **Nastavení** → **Režim aplikace**.

Nástroj Biblický slovník vyhledá slovo nebo frázi v každém nainstalovaném slovním zdroji. Je užitečný, když chcete definici biblického slova prostým jazykem, popis osoby nebo místa, nebo krátký článek o teologickém pojmu.

Biblický slovník se liší od nástroje **Info o slově**, který vyhledává původní hebrejské nebo řecké slovo za veršem. Slovník čte **anglické** slovo, na které klepnete, a ukáže vám, co o něm říkají vaše nainstalované slovníky. Pro poznámky k překladu Bible slovo po slovu viz průvodce [Komentáře a lexikony](theodia://help/commentaries-and-lexicons).

## Jak otevřít slovník

Slovník lze otevřít dvěma způsoby.

### Z nabídky verše

1. Otevřete kapitolu v [režimu Studium](theodia://help/study-mode).
2. Klepněte na verš a otevřete nabídku verše.
3. Klepněte na **Slovník** (📖).

Otevře se panel s názvem podle odkazu verše (například „Jan 3:16“). Text verše je nahoře a každé slovo je klepnutelné. Pod veršem je pruh s čipy ukazující každý nainstalovaný slovník. Pod tím je definice, která je prázdná, dokud neklepnete na slovo.

### Z položky lexikonu

Když čtete položku lexikonu v panelu Info o slově, některé položky obsahují modré odkazy na související články slovníku. Klepněte na kterýkoli z těchto odkazů. Lexikon se zavře a slovník se otevře na daném článku. Toto je nejrychlejší cesta, jak z řeckého nebo hebrejského slova přejít k vysvětlení jeho významu prostým jazykem.

## Jak funguje zobrazení verše

Když otevřete slovník z nabídky verše, verš se objeví nahoře na panelu jako seznam klepnutelných slov. Běžná anglická slova jako „the,“ „and,“ „of,“ „to“ a „a“ nejsou klepnutelná. Všechna ostatní slova jsou. Každé klepnutelné slovo je obarvené a tučné, takže vyčnívá ze zbytku verše.

Klepněte na libovolné slovo ve verši. Theodia prohledá každý nainstalovaný slovník na přesnou shodu tohoto slova. Pruh s čipy dole se aktualizuje a ukáže, které slovníky mají položku: slovníky, které pro dané slovo položku nemají, jsou ztlumené. První slovník s položkou se vybere automaticky a jeho definice se objeví pod pruhem s čipy.

Slovo, na které jste klepnuli, je zvýrazněné v textu verše nahoře na panelu, takže vždy víte, co vyhledáváte.

## Přepínání mezi slovníky

Každý nainstalovaný slovník je zobrazen jako malý čip pod veršem. Po klepnutí na slovo:

- Čip s **plnou barvou** — tento slovník má položku pro slovo, na které jste klepnuli. Klepněte na něj a přepnete na definici tohoto slovníku.
- **Ztlumený** čip — tento slovník nemá pro dané slovo položku. Je zobrazen zašedle, takže na první pohled vidíte, které slovníky slovo pokrývají, a čip nejde klepnout.

Vybraný slovník je zvýrazněný. Klepněte na jakýkoli jiný plný čip a přečtěte totéž slovo v tomto slovníku. Definice pod ním se aktualizuje okamžitě.

Pokud slovo existuje jen v jednom z vašich nainstalovaných slovníků, je plný jen ten jeden čip a ostatní jsou ztlumené.

## Co panel ukazuje

Panel slovníku má tři části, shora dolů:

- **Verš** — verš, ze kterého jste slovník otevřeli. Slova jsou klepnutelná a slovo, na které jste naposledy klepnuli, je zvýrazněné.
- **Pruh s čipy** — každý nainstalovaný slovník. Plný znamená „má položku pro klepnuté slovo.“ Ztlumený znamená „pro dané slovo žádnou položku nemá.“
- **Definice** — článek ze zvoleného slovníku. Prostý text formátovaný odstavci a nadpisy. Interní odkazy na jiné položky slovníku jsou klepnutelné; klepnutím na některý z nich se položka otevře ve slovníku.

## Co se stane, když se nenajde žádná položka

Pokud klepnete na slovo, které žádný z vašich nainstalovaných slovníků nepokrývá, panel ukáže místo definice krátkou zprávu „žádné položky nenalezeny“. To je běžné u velmi obvyklých slov jako „rok“ nebo „přijít“, která nejsou zcela biblicko-teologická, i když se po celé Bibli objevují. Zkuste specifičtější slovo, nebo místo toho použijte nástroj Info o slově v lexikonu, který pracuje s podkladovým řeckým a hebrejským textem.

## Co se stane, když není nainstalován žádný slovník

Slovník potřebuje k užitečnosti alespoň jeden soubor slovníkového zdroje. Theodia jeden dodává. Pokud jste ho odstranili nebo provozujete vlastní instalaci bez slovníků, zobrazení verše se stále objeví a slova zůstávají klepnutelná, ale pruh s čipy je prázdný a každé hledání vrátí „žádné položky nenalezeny“.

Další slovníky nelze instalovat samostatně.

## Tipy

- Slovník hledá **přesné shody slov**. Klepnutí na „láska“ najde položky s názvem „láska“, ale ne „miloval“ nebo „milující“. Pro vyhledání souvisejícího tvaru použijte nástroj Info o slově na řecké nebo hebrejské slovo.
- Pruh s čipy je stejný na telefonech i tabletech. Na tabletu se slovník otevře jako boční panel vedle kapitoly; na telefonu se otevře jako modální okno na celou obrazovku. Obě mají stejné třídílné rozvržení.
- Klepnutí na slovo v jiném verši otevře nový verš v panelu. Vaše předchozí volba se vymaže. Klepněte na slovo v novém verši a zahajte nové vyhledávání.
- Některé položky slovníků odkazují na totéž slovo v jiném slovníku. Klepněte na tyto interní odkazy a sledujte stopu napříč všemi nainstalovanými slovníky.

## Rozdíly mezi Slovníkem a Info o slově

Oba nástroje se otevírají z nabídky verše, ale dělají různé věci:

- **Slovník** (📖) čte anglické slovo, na které klepnete, a najde ho ve vašich nainstalovaných anglických slovnících. Je to správný nástroj pro definice biblicko-teologických slov prostým jazykem, jako „smlouva“, „smíření“ nebo „farizeus“.
- **Info o slově** (?) čte původní řecké nebo hebrejské slovo za veršem a najde ho ve vašich nainstalovaných lexikonech. Je to správný nástroj pro seriózní studium slov, hledání každého místa užití řeckého slova a čtení definic v původním jazyce.

Když si nejste jisti, začněte slovníkem. Pokud se chcete ponořit do původního jazyka, přepněte na Info o slově. Kompletního průchodu nástrojem Info o slově se týká průvodce [Komentáře a lexikony](theodia://help/commentaries-and-lexicons).

## Související průvodci

- Průvodce [Režim Studium](theodia://help/study-mode) podrobně vysvětluje nabídku verše a místo nástroje Slovník (📖) vedle Záložky, Zvýraznit, Říkat, Porovnat, Křížové odkazy, AI komentář, Info o slově a Poznámky.
- Průvodce [Komentáře a lexikony](theodia://help/commentaries-and-lexicons) pokrývá Info o slově a lexikony původních jazyků.
- Průvodce [Co jsou zdroje?](theodia://help/what-are-resources) vysvětluje různé druhy souborů, které Theodia používá, včetně slovníkových zdrojů.
- Průvodce [Časté problémy](theodia://help/common-problems) má opravy pro prázdné výsledky a další potíže se slovníkem.
