---
title: Encyklopedie
level: everyday
categories: study
summary: Jak vyhledávat v encyklopedických článcích a procházet referenční díla.
---

# Encyklopedie

Theodia obsahuje vestavěnou **Encyklopedii** pro vyhledávání článků, osob, míst a témat souvisejících s Biblí. Aplikace přichází s vestavěným dílem _Kitto's Illustrated Commentary_ (KIT) a další encyklopedie si můžete stáhnout z repozitáře.

## Co je encyklopedie v Theodii?

Encyklopedie je referenční dílo složené z krátkých článků. Každý článek pokrývá osobu, místo, událost nebo biblické téma. Na rozdíl od komentáře, který vysvětluje konkrétní verš, článek encyklopedie vysvětluje samotné téma.

## Jak otevřít Encyklopedii

1. Klepněte na **Encyklopedie** v dolní liště.
2. Zvolte encyklopedii z řady zkratek nahoře.
3. Zadejte téma, osobu nebo místo do vyhledávacího pole.

Hledání vyžaduje alespoň **3 znaky**, než se objeví výsledky a návrhy automatického doplňování.

## Čtení článku

- Na **telefonu** klepněte na jakýkoli výsledek a článek se otevře na nové obrazovce.
- Na **tabletě** se článek otevře v panelu vpravo, zatímco seznam zůstává vlevo.

## Výběr encyklopedií

Klepněte na čip se zkratkou (například **KIT**) a přepnete na tuto encyklopedii. Chcete-li hledat ve více než jedné encyklopedii najednou, použijte záložku **Hledat** a jako režim hledání zvolte **Encyklopedie**.

## Jak získat další encyklopedie

1. Otevřete **Nastavení**.
2. Klepněte na **Spravovat zdroje**.
3. Klepněte na **Instalovat z GitHub**.
4. Vyberte záložku **Encyklopedie**.
5. Klepněte na tlačítko stahování vedle požadované encyklopedie.

Encyklopedie se stahují z encyklopedického GitHub repozitáře Theodie a instalují se automaticky. Nainstalované encyklopedie se objeví na obrazovce Encyklopedie i v Hledání.

Encyklopedii můžete nainstalovat i z lokálního souboru: v **Spravovat zdroje** klepněte na **Instalovat lokální soubor** a zvolte soubor `.encyclopedia`. Soubor se zkopíruje do složky encyklopedií aplikace a přidá se do sdíleného indexu vyhledávání.

## Dlouhý stisk pro plný název

Na obrazovce Hledání ukazují čipy encyklopedií krátké zkratky. Dlouze stiskněte čip a uvidíte plný název encyklopedie.

## Kdy Encyklopedii použít

- Vyhledejte osobu, místo nebo téma před čtením místa nebo během něj.
- Získejte pozadí k biblickému slovu nebo pojmu, který zahrnuje mnoho veršů.
- Čtěte vedle komentáře pro hlubší studium.
