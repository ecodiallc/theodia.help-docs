---
title: Externí klávesové zkratky
level: everyday
categories: [tablet, settings]
summary: Kompletní reference klávesových zkratek pro iPad s připojenou externí klávesnicí.
---

# ⌨️ Externí klávesové zkratky

Pokud používáte Theodii na iPadu s externí klávesnicí (Magic Keyboard, Bluetooth klávesnice nebo USB klávesnice), můžete ovládat aplikaci bez dotyku obrazovky.

> **Režim:** Některé zkratky fungují jen tehdy, když je odpovídající funkce dostupná ve vašem aktuálním uživatelském režimu. Například `Cmd + Option + 6` (Záložky) a `Cmd + Option + 7` (Zvýraznění) v režimu Čtenář nedělají nic. Režim přepnete v **Nastavení** → **Režim aplikace**.

Zkratky fungují na **iPadu**.

## Globální zkratky (kdekoli)

| Zkratka           | Akce                                       |
| ----------------- | ------------------------------------------ |
| `Cmd + /`         | Zobrazit tuto nápovědu ke klávesovým zkratkám |
| `Cmd + .`         | Zavřít modální okno / panel (alternativa k Escape) |
| `Cmd + Option + 1` | Přejít na záložku Domů                     |
| `Cmd + Option + 2` | Přejít na záložku Bible                    |
| `Cmd + Option + 3` | Přejít na záložku Knihy                    |
| `Cmd + Option + 4` | Přejít na záložku Bohoslužebná čtení       |
| `Cmd + Option + 5` | Přejít na záložku Hledat                   |
| `Cmd + Option + 6` | Přejít na záložku Záložky (Standard a Badatel) |
| `Cmd + Option + 7` | Přejít na záložku Zvýraznění (Standard a Badatel) |
| `Cmd + Option + 8` | Přejít na záložku Poznámky (Standard a Badatel) |
| `Cmd + Option + 9` | Přejít na záložku AI (jen Badatel, pokud je povoleno) |
| `Cmd + Option + 0` | Přejít na záložku Nápověda                 |
| `Cmd + Option + I` | Přejít na záložku O aplikaci               |
| `Cmd + [`         | Zpět                                       |
| `Cmd + F`         | Otevřít Hledání                            |
| `Cmd + K`         | Otevřít Nabídku spouštěče (Badatel)        |
| `Cmd + ,`         | Otevřít Nastavení                          |
| `Cmd + Shift + M` | Otevřít hlavní nabídku                     |
| `Cmd + Shift + T` | Cyklovat téma (výchozí / tmavé)            |
| `Cmd + Shift + U` | Otevřít volič uživatelského režimu         |
| `Escape`          | Zrušit modální okno / zavřít panel         |

## Zkratky čtečky Bible

Ty fungují v **Study Reader** i **Focus Reader**.

| Zkratka            | Akce                                                        |
| ------------------ | ------------------------------------------------------------ |
| `← Left Arrow`     | Předchozí kapitola                                           |
| `→ Right Arrow`    | Další kapitola                                               |
| `Cmd + R`          | Přepnout mezi Study a Focus Reader (Standard a Badatel)      |
| `Cmd + Option + V` | Otevřít volič verzí                                          |
| `Cmd + Option + B` | Otevřít volič knih                                           |
| `Cmd + Option + C` | Otevřít volič kapitol                                        |
| `Cmd + T`          | Přepnout TTS (zastavit při přehrávání/pauze, spustit při klidu) |
| `Cmd + Option + T` | Přehrát / Pozastavit TTS                                     |

## Jen Study Reader

| Zkratka            | Akce                                                                 |
| ------------------ | ---------------------------------------------------------------------- |
| `↑ Up Arrow`       | Vybrat předchozí verš                                                  |
| `↓ Down Arrow`     | Vybrat další verš                                                      |
| `Cmd + ↑`          | Vybrat první verš                                                      |
| `Cmd + ↓`          | Vybrat poslední verš                                                   |
| `Cmd + ←`          | Přeskočit na kapitolu 1                                                |
| `Cmd + →`          | Přeskočit na poslední kapitolu                                         |
| `Cmd + 0`–`9`      | Přímý skok na verš (pište číslice, např. `Cmd + 1` `Cmd + 6` pro verš 16) |
| `Cmd + P`          | Přepnout paralelní Bible (Standard a Badatel)                          |
| `Cmd + B`          | Záložka vybraného verše (Standard a Badatel)                           |
| `Cmd + H`          | Zvýraznit vybraný verš (Standard a Badatel)                            |
| `Cmd + N`          | Přidat poznámku k vybranému verši (Standard a Badatel)                 |
| `Cmd + C`          | Porovnat překlady vybraného verše (Standard a Badatel)                 |
| `Cmd + X`          | Otevřít křížové odkazy vybraného verše (Standard a Badatel)            |
| `Cmd + I`          | Otevřít info o slově (Badatel)                                         |
| `Cmd + D`          | Otevřít slovník pro vybraný verš (Badatel)                             |
| `Cmd + A`          | Otevřít AI panel pro vybraný verš (Badatel)                            |
| `Cmd + Option + S` | Přepnout podnadpisy                                                    |
| `Cmd + Option + W` | Zavřít všechny otevřené studijní panely                                |
| `Cmd + Option + M` | Otevřít nabídku akcí verše                                             |

## Jen Focus Reader

| Zkratka        | Akce                |
| -------------- | ------------------- |
| `↑ Up Arrow`   | Posunout nahoru     |
| `↓ Down Arrow` | Posunout dolů       |
| `Cmd + ↑`      | Posunout nahoru     |
| `Cmd + ↓`      | Posunout dolů       |
| `Cmd + =`      | Přiblížit           |
| `Cmd + -`      | Oddálit             |

## Hledání

| Zkratka            | Akce                              |
| ------------------ | --------------------------------- |
| `Return`           | Spustit hledání                   |
| `Cmd + Return`     | Vymazat hledání a zaměřit vstup   |
| `Cmd + ↑`          | Posunout výsledky nahoru          |
| `Cmd + ↓`          | Posunout výsledky dolů            |
| `Cmd + Option + A` | Vybrat všechny položky rozsahu    |
| `Cmd + Option + C` | Zrušit výběr všech položek rozsahu |
| `Cmd + Option + B` | Režim hledání v Bibli             |
| `Cmd + Option + O` | Režim hledání v knihách           |
| `Cmd + Option + D` | Režim hledání ve slovníku (Badatel) |
| `Cmd + Option + X` | Režim hledání v lexikonu (Badatel) |

## Výsledky hledání

| Zkratka   | Akce                    |
| --------- | ----------------------- |
| `Cmd + S` | Otevřít list uložit vše |
| `Cmd + ↑` | Posunout výsledky nahoru |
| `Cmd + ↓` | Posunout výsledky dolů  |

## Čtečka knih

| Zkratka            | Akce                     |
| ------------------ | ------------------------ |
| `← Left Arrow`     | Předchozí kapitola       |
| `→ Right Arrow`    | Další kapitola           |
| `Cmd + ↑`          | Předchozí kapitola       |
| `Cmd + ↓`          | Další kapitola           |
| `↑ Up Arrow`       | Posunout nahoru          |
| `↓ Down Arrow`     | Posunout dolů            |
| `Cmd + B`          | Záložka aktuální kapitoly |
| `Cmd + J`          | Otevřít volič kapitol    |
| `Cmd + L`          | Otevřít volič hlasů      |
| `Cmd + T`          | Přepnout TTS             |
| `Cmd + Option + T` | Přehrát / Pozastavit TTS |

## Čtečka bohoslužebných čtení

| Zkratka            | Akce                          |
| ------------------ | ----------------------------- |
| `← Left Arrow`     | Předchozí den                 |
| `→ Right Arrow`    | Další den                     |
| `↑ Up Arrow`       | Posunout nahoru               |
| `↓ Down Arrow`     | Posunout dolů                 |
| `Cmd + ↑`          | Posunout nahoru (velký skok)  |
| `Cmd + ↓`          | Posunout dolů (velký skok)    |
| `Cmd + D`          | Otevřít volič data            |
| `Cmd + T`          | Přepnout TTS                  |
| `Cmd + Option + T` | Přehrát / Pozastavit TTS      |

## AI chat

| Zkratka            | Akce                         |
| ------------------ | ---------------------------- |
| `Cmd + Return`     | Odeslat zprávu               |
| `Cmd + N`          | Nový chat                    |
| `Cmd + D`          | Přepnout zásuvku konverzací  |
| `Cmd + Option + C` | Vymazat aktuální chat        |
| `Cmd + S`          | Otevřít nabídku uložení      |
| `Escape`           | Zavřít zásuvku / nabídku     |

## Záložky

| Zkratka                       | Akce                                  |
| ----------------------------- | ------------------------------------- |
| `↑ Up Arrow` / `↓ Down Arrow` | Vybrat záložku                        |
| `Return`                      | Otevřít záložku (tablet: vybrat)      |
| `Cmd + R`                     | Číst záložku v kontextu               |
| `Cmd + M`                     | Přesunout vybranou záložku do složek  |
| `Cmd + N`                     | Spravovat složky                      |
| `Escape`                      | Zavřít panel detailu / volič složek   |

Ve voliči **Uložit do složky** posouvá `↑ Up Arrow` / `↓ Down Arrow` výběr, `Return` přepne zvolenou složku nebo aktivuje zvýrazněnou akci a `Escape` volič zavře. Řádek **+ Vytvořit složku** je nahoře v seznamu.

## Poznámky k Bibli

| Zkratka                       | Akce                     |
| ----------------------------- | ------------------------ |
| `↑ Up Arrow` / `↓ Down Arrow` | Vybrat poznámku          |
| `Return`                      | Otevřít poznámku         |
| `Cmd + Return`                | Zaměřit vstup filtru     |
| `Escape`                      | Zavřít detail / editor   |

## Zvýraznění

| Zkratka                       | Akce                  |
| ----------------------------- | --------------------- |
| `↑ Up Arrow` / `↓ Down Arrow` | Vybrat zvýraznění     |
| `Return`                      | Otevřít zvýraznění    |
| `Cmd + Return`                | Zaměřit vstup filtru  |
| `Escape`                      | Zavřít panel detailu  |

## Seznam Biblí

| Zkratka                                  | Akce                                |
| ---------------------------------------- | ----------------------------------- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | Další Bible                         |
| `← Left Arrow` / `↑ Up Arrow`            | Předchozí Bible                     |
| `Return`                                 | Otevřít zaměřenou Bibli             |
| `Cmd + Shift + S`                        | Přepnout oblíbené u zaměřené Bible  |
| `Escape`                                 | Zpět                                |

## Obrazovka biblických knih

| Zkratka                 | Akce                            |
| ----------------------- | -------------------------------- |
| `Tab` / `→ Right Arrow` | Další kniha                      |
| `← Left Arrow`          | Předchozí kniha                  |
| `↓ Down Arrow`          | Kniha níže v mřížce              |
| `↑ Up Arrow`            | Kniha výše v mřížce              |
| `Cmd + ↓`               | Další oddíl (ST / NT)            |
| `Cmd + ↑`               | Předchozí oddíl (ST / NT)        |
| `Return`                | Otevřít zaměřenou knihu          |
| `Escape`                | Zpět                             |

## Seznam knih

| Zkratka                                  | Akce              |
| ---------------------------------------- | ----------------- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | Další kniha       |
| `← Left Arrow` / `↑ Up Arrow`            | Předchozí kniha   |
| `Return`                                 | Otevřít zaměřenou knihu |
| `Escape`                                 | Zpět              |

## Obrazovka biblických kapitol

| Zkratka                                  | Akce                    |
| ---------------------------------------- | ------------------------ |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | Další kapitola           |
| `← Left Arrow` / `↑ Up Arrow`            | Předchozí kapitola       |
| `Return`                                 | Otevřít zaměřenou kapitolu |
| `Escape`                                 | Zpět                     |

## Obrazovka kapitol knih

| Zkratka                | Akce                        |
| ---------------------- | --------------------------- |
| `Tab` / `↓ Down Arrow` | Další kapitola              |
| `↑ Up Arrow`           | Předchozí kapitola          |
| `Return`               | Otevřít zaměřenou kapitolu  |
| `Cmd + Return`         | Zaměřit vstup hledání/filtru |
| `Escape`               | Zpět                        |

## Seznam bohoslužebných čtení

| Zkratka                                  | Akce                          |
| ---------------------------------------- | ----------------------------- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | Další bohoslužebné čtení      |
| `← Left Arrow` / `↑ Up Arrow`            | Předchozí bohoslužebné čtení  |
| `Return`                                 | Otevřít zaměřené čtení        |
| `Escape`                                 | Zpět                          |

## Grafy

Na obrazovkách Statistiky, Cíle a Konkordance.

| Zkratka         | Akce                                      |
| --------------- | ----------------------------------------- |
| `← Left Arrow`  | Vybrat předchozí kategorii v grafu        |
| `→ Right Arrow` | Vybrat další kategorii v grafu            |

Popisek pod grafem sleduje výběr a nová hodnota se vysloví.

## Hlavní nabídka (když je otevřená)

| Zkratka        | Akce                        |
| -------------- | --------------------------- |
| `↑ Up Arrow`   | Předchozí položka nabídky   |
| `↓ Down Arrow` | Další položka nabídky       |
| `Return`       | Vybrat zvýrazněnou položku  |
| `Escape`       | Zavřít nabídku              |

## Nastavení

| Zkratka  | Akce                             |
| -------- | --------------------------------- |
| `Escape` | Zavřít otevřené modální okno / volič |

## Modální okna editorů

| Zkratka   | Akce               |
| --------- | ------------------ |
| `Cmd + S` | Uložit             |
| `Escape`  | Zrušit / zavřít    |

## Ochrana při psaní

Když jste zaměřeni v textovém poli (vyhledávací pole, editor poznámek, AI vstup), jsou ne-Cmd zkratky, jako jsou šipky a `Space`, potlačeny, aby nedopatřením nespustily navigaci. Zkratky používající klávesu `Cmd` (například `Cmd + S`, `Cmd + B`) fungují při psaní stále.
