---
title: Často kladené otázky
level: everyday
categories: faq
summary: Odpovědi na nejčastější otázky o používání Theodie.
---

# Často kladené otázky

## Stojí Theodia něco?

Theodia je jednorázový nákup. Žádné předplatné, žádná reklama, žádné nákupy v aplikaci a žádné výzvy k darům. Všechny další zdroje dostupné v katalogu jsou po zakoupení aplikace zdarma ke stažení.

## Potřebuji připojení k internetu?

Ne. Jakmile je aplikace a její datové soubory nainstalovány, vše funguje offline. Můžete číst, hledat, zvýrazňovat, psát poznámky a používat většinu studijních nástrojů bez signálu.

Jediná funkce, která potřebuje internet, je stahování nových zdrojů.

## Kde jsou moje data uložena?

Všechny vaše záložky, zvýraznění, poznámky a nastavení jsou uloženy na vašem zařízení. Na žádný server se nenahrávají.

Můžete je ručně zálohovat. Jak na to, popisuje průvodce [Zálohování dat](theodia://help/backups).

## Můžu si Bibli poslechnout nahlas?

Ano. Otevřete jakoukoli kapitolu, klepněte na nabídku a zvolte možnost čtení nahlas. Vaše zařízení musí mít nainstalovaný hlas pro převod textu na řeč. Více v průvodci [Čtení nahlas](theodia://help/tts).

## Jak vyhledám verš?

Můžete zadat odkaz jako `John 3:16` do Příkazu na domovské obrazovce, nebo použít záložku **Hledat** a hledat podle slova nebo fráze.

## Jak nahlásím chybu nebo navrhnu funkci?

Klepněte na **Odeslat návrh / problém** na obrazovce O aplikaci, [nahlaste to na GitHub](https://github.com/ecodiallc/theodia.app/issues/new), nebo navštivte stránku [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions).

## Jaká zařízení jsou podporována?

Theodia běží na iPhonu, iPadu, telefonech a tabletech s Androidem. Nejlépe funguje na zařízeních s alespoň 2 GB volného úložiště pro základní datové soubory.

## Můžu použít externí klávesnici?

Ano. Theodia podporuje Bluetooth a USB klávesnice na iPadu. Navigace, hledání a mnoho funkcí čtení má klávesové zkratky. Kompletní seznam najdete v průvodci [Externí klávesové zkratky](theodia://help/external-keyboard-shortcuts).

## Jaké jazyky jsou podporovány?

Rozhraní aplikace je dostupné v angličtině, arabštině, čínštině (zjednodušené a tradiční), češtině, dánštině, nizozemštině, filipínštině, francouzštině, němčině, řečtině, hebrejštině, hindštině, indonézštině, italštině, japonštině, korejštině, polštině, portugalštině (Brazílie), rumunštině, ruštině, španělštině, svahilštině, švédštině, thajštině, turečtině, ukrajinštině a vietnamštině.

Jazyk biblického textu závisí na tom, jaké překlady máte nainstalované.

## Jak změním jazyk?

Přejděte do **Nastavení** a najděte možnost jazyka.

## Moje otázka tu není. Kde získám víc pomoci?

Projděte zbytek průvodců nápovědy podle témat, nebo položte otázku v komunitě [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions).

Tip: Na hlavní obrazovce **Nápověda a průvodci** použijte vyhledávací pole a napište téma jako `notifications` nebo `search`, abyste našli odpovídajícího průvodce.
