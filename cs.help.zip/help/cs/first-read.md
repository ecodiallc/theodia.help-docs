---
title: Čtení první kapitoly
level: beginner
categories: [start, read]
summary: Návod krok za krokem, jak otevřít a přečíst kapitolu.
---

# Čtení první kapitoly

Tento průvodce vás provede otevřením kapitoly úplně poprvé.

## Krok 1: Otevřete záložku Bible

Podívejte se do spodní části obrazovky. Uvidíte řadu záložek. Klepněte na tu, která říká **Bible**.

## Krok 2: Zvolte knihu

Uvidíte seznam biblických knih. Genesis je první. Jan je skoro uprostřed. Zjevení je poslední.

Klepněte na název knihy, kterou chcete.

## Krok 3: Zvolte kapitolu

Uvidíte čísla 1 až po tolik kapitol, kolik kniha má. Klepněte na kapitolu, kterou chcete.

Kapitola se otevře. Verše jsou na obrazovce.

## Krok 4: Pohybujte se

- Přejeďte **doleva** na další kapitolu.
- Přejeďte **doprava** zpět.

## Krok 5: Pracujte s veršem

Co můžete s veršem dělat, závisí na vašem uživatelském režimu.

### Režim Čtenář

Režim Čtenář je čistý a bez rozptylování.

- Klepnutím na verš ho krátce zvýrazníte.
- Nejsou tu žádné studijní nástroje, záložky ani nabídky.
- Chcete-li více funkcí, přepněte v **Nastavení** na režim **Standard** nebo **Badatel**.

### Režim Standard

Režim Standard přidává každodenní funkce pro osobní studium Bible.

Klepněte na verš a otevřete nabídku s těmito volbami:

- **Záložka** verše.
- **Zvýraznit** barvou.
- **Přidat poznámku**.
- **Zkopírovat** text verše.
- **Porovnat** verš v jiném překladu.
- **Vyhledat křížové odkazy** verše.

### Režim Badatel

Režim Badatel odemkne každý nástroj pro hluboké studium Bible.

Klepněte na verš a otevřete nabídku se vším z režimu Standard, plus:

- **Komentář** k verši.
- **Info o slově** a vyhledávání v původních jazycích.
- **Slovníkové** definice.
- **AI asistent** pro hlubší studium.

Režim můžete kdykoli přepnout v **Nastavení**.

## Potřebujete pomoc s konkrétním nástrojem?

Každý nástroj má svého průvodce. Klepněte na **Nápověda** na domovské stránce a uvidíte je všechny. Průvodce [Režim Studium](theodia://help/study-mode) je dobrý začátek — projde každý nástroj v nabídce verše.

Pokud stále objevujete, kde co je, podívejte se na průvodce [Rozvržení a navigace aplikace](theodia://help/navigating-the-app). Vysvětluje domovskou obrazovku, hlavní nabídku a dolní lištu.

## Chcete více zdrojů?

Aplikace přichází s několika volně dostupnými verzemi Bible. Chcete-li přidat další, nebo přidat komentáře, knihy či bohoslužebná čtení, podívejte se na průvodce [Získání dalších zdrojů z GitHub](theodia://help/getting-core-files). Ukáže vám, kde je najít a jak je přidat.
