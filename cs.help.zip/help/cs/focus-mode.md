---
title: Režim Soustředění
level: beginner
categories: [layout, read]
summary: Čistý způsob čtení dlouhých míst bez rozptylování.
---

# Režim Soustředění

> **Režim:** Režim Soustředění je čtečkou v režimu **Čtenář**. Je dostupný i v režimu **Standard** a **Badatel** jako alternativa k režimu Studium. Režim můžete přepnout v **Nastavení** → **Režim aplikace**.

Režim Soustředění je způsob, jak číst biblickou kapitolu bez tlačítek a nabídek v cestě. Je dobrý pro dlouhé čtení.

## Jak ho zapnout

1. Otevřete jakoukoli kapitolu.
2. V řadě ikon nahoře na obrazovce klepněte na tlačítko 📖. Otevře tutéž kapitolu v režimu Soustředění.
3. Nabídky a tlačítka se skryjí. Zůstane jen text Bible.

V režimu **Čtenář** se kapitoly otevírají v režimu Soustředění automaticky. Tlačítko 📖 je skryté, protože režim Studium, na který by se šlo přepnout, není k dispozici.

## Co můžete v režimu Soustředění dělat

- **Posouvejte** při čtení.
- **Přejíždějte** na další nebo předchozí kapitolu.
- **Klepněte na tlačítko 📖** v dolní liště a přepněte zpět do režimu Studium. (Skryté v režimu Čtenář.)
- **Klepněte na tlačítko 🔊** v dolní liště a kapitola se přečte nahlas. Objeví se mini ovládací lišta s přehráním, pauzou, zpětným a rychlým posunem a voličem hlasu. (Skryté v režimu Čtenář — TTS vyžaduje Standard nebo Badatel.)

## K čemu se režim Soustředění hodí

- Čtení celé knihy, kapitolu po kapitole.
- Čtení dlouhého místa pro bohoslužbu nebo tichý čas.
- Čtení nahlas a sledování bez rozptylování.

## Přepnutí do režimu Studium

Režim Soustředění skryje každý studijní nástroj, ale jsou jen jedno klepnutí daleko. Klepněte na tlačítko 📖 nahoře na obrazovce a otevřete tutéž kapitolu v [režimu Studium](theodia://help/study-mode). Režim Studium je plná čtečka s komentáři, křížovými odkazy, vyhledáváním v lexikonech a poznámkami. Co režim Studium umí, popisuje průvodce [Režim Studium](theodia://help/study-mode).

V režimu **Čtenář** je tlačítko 📖 skryté, protože režim Studium není dostupný.
