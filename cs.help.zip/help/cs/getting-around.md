---
title: Rychlá orientace
level: beginner
categories: layout
summary: Každý rychlý způsob, jak přeskočit na verš, kapitolu nebo obrazovku v Theodii.
---

# Rychlá orientace

Tento průvodce je tahák pro navigaci. Pokrývá každý rychlý způsob, jak se přesunout tam, kde jste, tam, kam chcete.

## Skočte rovnou na verš

Nejrychlejší cesta k otevření libovolného verše je **Příkaz** na domovské obrazovce.

- Zadejte `John 3:16` a klepněte na Vykonat.
- Zadejte `Psalms 23` a klepněte na Vykonat.
- Zadejte `Genesis 1` a klepněte na Vykonat.

Aplikace otevře přesnou kapitolu (a posune se k verši, pokud jste ho uvedli).

## Přehazujte mezi kapitolami

Když čtete kapitolu:

- **Přejeďte doleva** → další kapitola.
- **Přejeďte doprava** → předchozí kapitola.

Tohle funguje napříč knihami. Po Exodusu 40 vás přejezd doleva zavede do Leviticus 1.

## Používejte horní lištu

Při čtení ukazuje horní část obrazovky aktuální **překlad**, **knihu** a **kapitolu**.

- Klepněte na název překladu a přepnete Bible.
- Klepněte na název knihy a vyberete jinou knihu.
- Klepněte na číslo kapitoly a vyberete jinou kapitolu.

## Skočte ze záložky

Pokud jste si verš uložili:

1. Otevřete záložku **Záložky**.
2. Klepněte na jakoukoli položku.
3. Dostanete se rovnou k tomu verši.

## Skočte z hledání

1. Otevřete záložku **Hledat**.
2. Zadejte slovo nebo frázi.
3. Klepněte na jakýkoli výsledek.
4. Aplikace otevře kapitolu s vašimi hledanými slovy zvýrazněnými žlutě.

## Přepínejte rozvržení čtení

Čtečka Bible má dvě rozvržení:

- **Režim Studium** — ukazuje kapitolu se všemi studijními nástroji jedno klepnutí daleko.
- **Režim Soustředění** — skryje každý nástroj a nabídku, zůstane jen text.

Přepnutí: při čtení klepněte na tlačítko **📖** nahoře na obrazovce. Klepnutím znovu se přepnete zpět. (Režim Čtenář zůstává vždy v režimu Soustředění.)

## Používejte dolní záložky

Řada ikon dole na obrazovce je vždy viditelná. Klepněte na libovolnou záložku a přepnete do té sekce. Přesné záložky závisí na vašem uživatelském režimu:

**Všechny režimy:**

- **Domů** — zpět na domovskou obrazovku.
- **Bible** — seznam překladů.
- **Hledat** — hledání v Bibli, knihách, slovnících, lexikonech a PDF.
- **Nastavení** — předvolby a zdroje.

**Standard a Badatel také vidí:**

- **Záložky** — uložené verše.
- **Zvýraznění** — barevně označené verše.
- **Poznámky** — vaše soukromé poznámky.
- **PDF** — vaše importované PDF dokumenty.

**Badatel také vidí:**

- **AI** — AI asistent (pokud je zapnutý v Nastavení).

### Pamatování, kde jste skončili

Každá záložka si uchovává vlastní historii navigace. Když se vrátíte na záložku, vrátíte se tam, **kde jste skončili**, ne na startovní obrazovku dané sekce.

- Otevřete záložku **Bible**, vyberte překlad, otevřete kapitolu, potom přepněte na **Hledat**. Později znovu klepnete na **Bible** a jste zase u téže kapitoly.
- Otevřete záložku **Záložky**, klepněte na uložený verš, potom přepněte na **Nastavení**. Opětovné klepnutí na **Záložky** vás vrátí do seznamu záložek.

Tohle platí pro každou záložku. Každá si pamatuje vaše místo, dokud se explicitně nepřesunete na jinou obrazovku uvnitř té záložky.

### Co resetuje záložku

Záložka se vrátí na svou kořenovou obrazovku jen tehdy, když:

- Již na té záložce jste a klepnete znovu na tutéž ikonu záložky. To je rychlý způsob resetu na začátek.
- Aplikace je násilně zavřena a znovu otevřena.

### Dolní záložky vs. hlavní nabídka

- **Dolní záložky** — každá záložka si pamatuje svůj vlastní zásobník. Klepnutí na záložku vás vrátí tam, kde jste skončili.
- **Hlavní nabídka** — klepnutí na položku přejde na danou obrazovku. Je to rozbalovací seznam, ne překryv.

Příklad:

- Čtete Jana 3. Klepnete na záložku **Záložky**, potom znovu na **Bible**. Vrátíte se do Jana 3.
- Čtete Jana 3. Otevřete nabídku a klepnete na **Poznámky**. Projdete si poznámky, potom klepnete na záložku **Bible** a vrátíte se do Jana 3.

## Tipy

- Domovská obrazovka si pamatuje, které sekce jsou rozbalené nebo sbalené.
- Pokud záložka chybí, zkontrolujte svůj **uživatelský režim** v **Nastavení** → **Režim aplikace**. Režim Čtenář skrývá záložky, zvýraznění, poznámky a AI. Režim Standard skrývá AI. Možná budete muset povolit funkci v **Nastavení** nebo nainstalovat zdroj.
