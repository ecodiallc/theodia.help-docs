---
title: Získání dalších zdrojů
level: everyday
categories: resources
summary: Jak přidat Bible, komentáře, knihy a další zdroje do Theodie.
---

# Získání dalších zdrojů

Theodia přichází s některými vestavěnými zdroji, ale můžete přidat víc. Nejsnazší cesta vede přes obrazovku **Spravovat zdroje** uvnitř aplikace.

## Co můžete přidat

- **Bible** — více překladů v různých jazycích
- **Komentáře** — studijní poznámky vysvětlující verše
- **Knihy** — křesťanské klasiky a referenční díla
- **Bohoslužebná čtení** — denní bohoslužebná čtení
- **Základní soubory** — větší datové soubory, jako morfologie, křížové odkazy a Marvel Interlinear Bible (MIB)

## Jak přidávat zdroje z aplikace

1. Otevřete **Nastavení**.
2. Klepněte na **Spravovat zdroje**.
3. Vyberte záložku: **Základní**, **Bible**, **Komentáře**, **Knihy** nebo **Bohoslužebná čtení**.
4. Projděte si seznam. Klepněte na zdroj a dočtěte si o něm víc.
5. Klepnutím na zaškrtávací políčko vyberte, co chcete.
6. Dole klepněte na **Stáhnout**. Soubory se stáhnou a nainstalují automaticky.

Po instalaci se zdroj v aplikaci objeví hned. Není třeba restartovat.

## Základní soubory

Záložka **Základní** obsahuje velké datové soubory, které pohánějí hlubší studijní funkce. Patří sem:

- Data morfologie (tvary slov v původních jazycích)
- Databáze křížových odkazů
- Marvel Interlinear Bible (MIB)

Základní soubory stačí stáhnout jednou. Zůstanou na vašem zařízení a fungují offline.

## Globální Bible

Záložka **Globální Bible** obsahuje biblické překlady z širší sbírky. Pokud v hlavní záložce **Bible** nevidíte překlad, který chcete, podívejte se sem.

## Správa nainstalovaných zdrojů

Na hlavní obrazovce **Spravovat zdroje** (nikoli záložky stahování) můžete:

- **Povolit nebo zakázat** zdroj bez mazání. Zakázané zdroje zůstávají na vašem zařízení, ale jsou skryté v nabídkách.
- **Smazat** zdroj, abyste uvolnili místo. Později si ho můžete stáhnout znovu.

## Přidávání vlastních souborů

Pokud máte soubor zdroje odjinud — od přítele, z jiného projektu nebo z webu — můžete ho importovat přímo:

1. V **Spravovat zdroje** klepněte na **Importovat lokální soubor**.
2. Vyberte soubor z vašeho zařízení.
3. Aplikace soubor přečte a přidá ho do vaší knihovny.

Aplikace přijímá tyto typy souborů:

- `.bible` — biblické překlady
- `.commentary` — komentáře
- `.lexicon` — lexikony
- `.book` — knihy
- `.devotional` — bohoslužebná čtení

## Připojení vlastního GitHub repozitáře

Pokud někdo spravuje GitHub repozitář se zdroji kompatibilními s Theodií, můžete ho přidat jako vlastní zdroj:

1. Přejděte na **Nastavení → GitHub Repozitáře**.
2. Klepněte na **Přidat repozitář**.
3. Zadejte GitHub URL (například `https://github.com/username/repo-name`).
4. Zvolte, které typy zdrojů repozitář obsahuje (Bible, komentáře nebo knihy).
5. Uložte.
6. Vraťte se do **Spravovat zdroje**. Objeví se nová záložka se zdroji z tohoto repozitáře.

Pokud je repozitář soukromý, budete muset v **Nastavení → GitHub Repozitáře** přidat **Personal Access Token**, aby ho aplikace mohla číst.

## Poznámka o velikostech souborů

Zdrojové soubory mohou být velké. Bible bývají malé (pár megabajtů). Komentáře a základní soubory mohou být mnohem větší (stovky megabajtů). Stahujte přes Wi-Fi, kdykoli je to možné.

## Shrnutí

- Používejte **Nastavení → Spravovat zdroje** k prohlížení a instalaci zdrojů.
- Základní soubory odemkují hlubší studijní nástroje, jako morfologie a křížové odkazy.
- Importujte lokální soubory, pokud vlastní máte.
- Přidejte vlastní GitHub repozitáře, pokud chcete zdroje z jiného zdroje.
