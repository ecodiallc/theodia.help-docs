---
title: Kde klást otázky
level: everyday
categories: trouble
summary: Jak získat pomoc od týmu a komunity Theodie a jak najít témata nápovědy uvnitř aplikace.
---

# Kde klást otázky

Pokud jste uvízlí, je několik míst, kde o pomoc požádat.

## Hledání tématu nápovědy

Pokud hledáte informace o konkrétní funkci, vyzkoušejte jednu z těchto cest:

- **Procházení podle kategorie.** Otevřete **Nápověda a průvodci** a klepněte na kategorii, jako **Nastavení a přizpůsobení** nebo **Odstraňování problémů**. Každá karta vypisuje související průvodce.
- **Hledání podle klíčového slova.** Na hlavní obrazovce **Nápověda a průvodci** napište slovo do vyhledávacího pole nahoře. Například zadání `notifications` ukáže průvodce [Oznámení a připomínky](theodia://help/notifications); zadání `search` ukáže průvodce [Hledání v Bibli](theodia://help/search-the-bible).
- **Nejdřív zkontrolujte Nastavení.** Mnoho funkcí se nastavuje v **Nastavení**. Chcete-li nastavit připomínky, otevřete **Nastavení** → **Oznámení**. Obrazovka nastavení má také odkaz **Nápověda** u každé sekce.

## Uvnitř aplikace

Otevřete obrazovku **O aplikaci**. Uvidíte dvě tlačítka:

- **Odeslat návrh / problém** — otevře formulář pro odeslání otázky, nápady nebo hlášení chyby týmu.
- **Diskuse / zpětná vazba** — otevře komunitní diskusní board.

## Stránka GitHub

Seznam známých problémů a nedávných změn můžete vidět na [GitHub](https://github.com/ecodiallc/theodia.app).

## Komunitní diskuse

Ostatní uživatelé Theodie kladou otázky a sdílejí tipy na [komunitním diskusním boardu](https://github.com/ecodiallc/theodia.app/discussions). Můžete číst stará vlákna a založit nové.

## Než se zeptáte

Pár věcí nám pomůže odpovědět rychleji:

- **Jaké máte zařízení?** (např. iPhone 13, Pixel 7)
- **Jakou verzi aplikace?** (Otevřete **O aplikaci** a uvidíte.)
- **Co jste udělali?** Krátký popis kroků.
- **Co se stalo?** Co jste viděli na obrazovce.
- **Co jste očekávali, že se stane?** To bývá nejužitečnější část.

## Čeho se očekávat

- U hlášení chyb obvykle tým odpoví do pár dní.
- Nápady tým všechny čte. Nemůžeme slíbit, kdy bude nápad přidán.
- Na komunitní otázky ostatní uživatelé často odpoví rychleji než tým.

## Poznámka o soukromí

Když odesíláte otázku, prosím nezahrnujte soukromé informace. Tým vidí, co odešlete.
