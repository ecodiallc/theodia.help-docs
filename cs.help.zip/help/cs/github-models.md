---
title: GitHub Models
categories: ai
level: advanced
summary: Nastavte GitHub Models — bezplatnou cestu, jak začít objevovat AI v Theodii bez existujícího API předplatného.
---

# GitHub Models

> **Režim:** AI asistent vyžaduje režim **Scholar** (Badatel). Režim můžete přepnout v **Nastavení** → **Režim aplikace**.

Pokud za AI službu ještě neplatíte, **GitHub Models** je nejsnazší cesta, jak začít objevovat AI v Theodii. Nabízí bezplatný začátek a vše, co potřebujete, je bezplatný GitHub účet.

## Co je GitHub Models?

GitHub Models je služba od GitHub, která vám umožní spouštět moderní AI modely přes API. Podporuje stejný formát jako OpenAI, takže bezproblémově funguje s Theodií.

## Proč zvolit GitHub Models?

- **Není potřeba platební karta** — Stačí GitHub účet.
- **Kvalitní modely** — Získáte přístup ke GPT-4o, GPT-4.1 a dalším spolehlivým modelům, které podporují nástroje Theodie.
- **Snadné nastavení** — Jeden token, jedno URL a hotovo.

## Krok 1: Vytvořte GitHub účet

Pokud GitHub účet už máte, přeskočte na Krok 2.

1. Přejděte na [github.com](https://github.com).
2. Klepněte na **Sign up** a postupujte podle pokynů k vytvoření bezplatného účtu.
3. Ověřte e-mailovou adresu, až GitHub pošle potvrzení.

## Krok 2: Vytvořte Personal Access Token

Tento token je váš API klíč. Říká GitHub, kdo jste, když Theodia posílá otázky.

1. Přejděte na [github.com/settings/tokens](https://github.com/settings/tokens).
2. Klepněte na **Generate new token** a zvolte **Generate new token (classic)**.
3. Dejte tokenu název, například **Theodia AI**.
4. V části **Select scopes** zaškrtněte políčko **`models:read`**.
   - Tohle je jediné oprávnění, které Theodia potřebuje.
5. Sjeďte dolů a klepněte na **Generate token**.
6. **Token si hned zkopírujte.** GitHub ho ukáže jen jednou. Vložte ho na bezpečné místo (třeba do poznámek v telefonu), dokud ho nepřidáte do Theodie.

## Krok 3: Zvolte model

GitHub Models nabízí několik modelů. Pro Theodii jsou tohle nejlepší volby:

| Model                 | Denní bezplatný limit | Hodí se pro                                   |
| --------------------- | ---------------------- | --------------------------------------------- |
| `openai/gpt-4.1-nano` | 150 požadavků / den    | Rychlé otázky a jednoduchá vysvětlení veršů   |
| `openai/gpt-4.1-mini` | 150 požadavků / den    | Obecné studium s dobrou podporou nástrojů     |
| `openai/gpt-4.1`      | 50 požadavků / den     | Hlubší studium a složité vícekrokové otázky   |
| `openai/gpt-4o`       | 50 požadavků / den     | Všestranný, výborná podpora nástrojů          |

Začněte s **`openai/gpt-4.1-mini`** — je rychlý, spolehlivý a nabízí vyšší denní limit požadavků.

## Krok 4: Nakonfigurujte Theodii

1. Otevřete **Theodii**.
2. Přejděte na **Nastavení** → **AI asistent**.
3. Ujistěte se, že je vybrán **Vzdálený model**.
4. Klepněte na rozbalovací seznam **Poskytovatel** a zvolte **GitHub Models**.
   - Pokud v seznamu GitHub Models není, klepněte na **Vlastní** a zadejte základní URL ručně: `https://models.github.ai`
5. Vložte svůj GitHub Personal Access Token do pole **API klíč**.
6. Zadejte zvolené ID modelu do pole **Model** (například: `openai/gpt-4.1-mini`).
7. Klepněte na **Otestovat připojení**.
8. Počkejte, až kontrola skončí. Měli byste vidět:
   - **✓ Připojení úspěšné**
   - **✓ Nástroje podporovány**

Pokud uvidíte **✗ Nástroje nepodporovány**, vyzkoušejte jiné ID modelu z tabulky výše.

## Krok 5: Začněte chatovat

1. Klepněte na záložku **AI** dole na obrazovce.
2. Napište otázku a klepněte na **Odeslat**.
3. Nebo při čtení jakékoli biblické kapitoly klepněte na číslo verše a zvolte **AI komentář**, abyste zahájili chat ke konkrétnímu verši.

## Odstraňování problémů

### „Připojení selhalo“ nebo „HTTP 401“

- Ujistěte se, že jste zkopírovali **celý** token. Je to dlouhý řetězec začínající na `ghp_`.
- Tokeny vyprší, pokud se dlouho nepoužívají. Vraťte se na GitHub a vygenerujte nový.
- Zkontrolujte, že jste při vytváření tokenu zvolili **models:read**.

### „Nástroje nepodporovány“

- Některé modely na GitHub Models nepřijímají volání nástrojů. Zkuste místo toho **`openai/gpt-4o`** nebo **`openai/gpt-4.1-mini`**.
- Ujistěte se, že ID modelu je napsáno přesně tak, jak je zobrazeno, včetně předpony `openai/`.

### Chyby limitu požadavků

- Pokud narazíte na denní limit, přepněte na model s vyšším přípustným limitem (například `openai/gpt-4.1-nano` s 150 požadavky denně).
- Limity se obnovují každých 24 hodin.

## Shrnutí

- GitHub Models je **doporučený způsob, jak začít objevovat AI** v Theodii.
- Potřebujete **bezplatný GitHub účet** a **Personal Access Token** s `models:read`.
- Nejlepším začátečnickým modelem je **`openai/gpt-4.1-mini`**.
- Zadejte token a model v **Nastavení → AI asistent**, klepněte na **Otestovat připojení** a začněte chatovat.
