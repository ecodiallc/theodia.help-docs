---
title: Zvýrazňování veršů
level: everyday
categories: [annotate, read]
summary: Jak označit verše barvou a později je najít.
---

# Zvýrazňování veršů

> **Režim:** Zvýraznění jsou dostupná v režimu **Standard** a **Badatel**. Režim Soustředění je určen jen pro čisté čtení bez rozptylování. Režim můžete přepnout v **Nastavení** → **Režim aplikace**.

Zvýraznění označí verš barvou. Funguje jako žlutý zvýrazňovač na papíře. Verš zůstane zvýrazněný i při příštím otevření.

## Jak zvýraznit verš

1. Otevřete verš.
2. Klepněte na verš, čímž zobrazíte nabídku.
3. Klepněte na ikonu **Zvýraznit**.
4. Vyberte barvu.

Verš je nyní zvýrazněn tou barvou.

## Jak změnit barvu zvýraznění

1. Otevřete verš.
2. Klepněte na verš, potom na ikonu **Zvýraznit**.
3. Vyberte novou barvu.

## Jak odebrat zvýraznění

1. Otevřete verš.
2. Klepněte na verš, potom v nabídce na **Zvýraznit**.
3. Dole ve voliči barev klepněte na **Odebrat zvýraznění**.

## Obvyklý způsob používání barev

Mnoho čtenářů používá malou sadu barev pro malou sadu účelů:

- **Žlutá** pro obecné oblíbené.
- **Zelená** pro verše o Bohu.
- **Modrá** pro verše o modlitbě.
- **Růžová** pro verše o útěše.
- **Oranžová** pro verše o výstraze nebo napomenutí.
- **Fialová** pro verše o prorockých věcech nebo konci časů.

Zvolte si systém, který vám vyhovuje.

## Jak vidět všechna svá zvýraznění

Klepněte na záložku **Zvýraznění** dole. Uvidíte seznam všech zvýrazněných veršů, nejnovější první. Nahoře je řada barevných čipů — klepnutím na barvu zobrazíte jen zvýraznění té barvy, nebo klepněte na **Vše** a filtr vymažete.

## Import zvýraznění

Zvýraznění můžete do Theodie přenést z jiných aplikací a souborů.

Přejděte na **Nastavení** → **Záložky** → **Importovat zvýraznění**. Zvolte **Importovat ze souboru** nebo vložte obsah ze schránky. Aplikace formát rozpozná automaticky.

### Podporované formáty

**Nativní export JSON** — Formát používaný vlastní funkcí exportu Theodie:

```json
{
  "/bible/KJV/John/3#v3_16": "yellow",
  "/bible/KJV/Genesis/1#v1_1": "green"
}
```

**CSV** — Tabulka se sloupci `url` a `color`. Příklad:

```csv
url,color
/bible/KJV/John/3#v3_16,yellow
/bible/KJV/Genesis/1#v1_1,green
```

**Prostý text** — Každý řádek je biblický odkaz nebo URL, volitelně následované názvem barvy. Příklad:

```
John 3:16 yellow
Genesis 1:1 green
Matthew 5:1
```

- Dostupné barvy: `yellow`, `green`, `blue`, `pink`, `orange`, `purple`.
- Pokud barva není uvedena, zvýraznění se ve výchozím stavu nastaví na žlutou.
- Řádky začínající na `#` nebo `//` se považují za komentáře a přeskočí se.

## Tipy

- Zvýraznění zůstávají na vašem zařízení. Nesynchronizují se do cloudu.
- Můžete zvýraznit verš v jednom překladu a objeví se i ve vašich ostatních překladech téhož verše.
- Jak je udržet v bezpečí, popisuje průvodce [Zálohování dat](theodia://help/backups).
