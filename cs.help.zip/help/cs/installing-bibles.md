---
title: Instalace biblických překladů
level: beginner
categories: start
summary: Jak přidat překlad Bible do vaší knihovny.
---

# Instalace biblických překladů

Theodia přichází s pár překlady Bible připravenými ke čtení. Víc můžete přidat kdykoli. „Překlad“ je jiná verze biblického textu, jako King James Version.

## Jak přidat překlad

Záložka Bible ukazuje seznam překladů, které už jsou nainstalované. Chcete-li přidat další, otevřete správce zdrojů:

1. Otevřete **Nastavení**.
2. Klepněte na **Spravovat zdroje**.
3. Klepněte na **Instalovat z GitHub**.
4. V modálním okně stahování klepněte na záložku **Bible**.
5. Klepněte na zaškrtávací políčko u každého překladu, který chcete.
6. Dole klepněte na **Instalovat vybrané**.
7. Počkejte na dokončení stahování.

Překlad je nyní ve vaší knihovně. Chcete-li ho vidět, otevřete záložku **Bible**.

## Jak přepínat mezi překlady

1. Otevřete kapitolu, kterou chcete číst.
2. Klepněte na název překladu nahoře na obrazovce.
3. Ze seznamu vyberte ten, který chcete.

Aplikace si vaši volbu uloží pro příště.

## Jak odebrat překlad

1. Otevřete **Nastavení**.
2. Klepněte na **Spravovat zdroje**.
3. Najděte překlad, který chcete odebrat.
4. Klepněte na **X** vedle něj.
5. Potvrďte, že ho chcete odebrat.

Odebrání překladu nemaže vaše poznámky, zvýraznění ani záložky. Ta zůstávají v bezpečí.

## Kolik místa překlady zabírají?

Většina překladů má mezi 2 a 10 MB. Ukládají se na vaše zařízení, ne do cloudu. Můžete jich mít tolik, kolik chcete, pokud má vaše zařízení místo.

## Co když překlad není v aplikaci?

Některé překlady nejsou v seznamu v aplikaci. I tak je můžete přidat.

1. Otevřete aplikaci a přejděte na **Nastavení** → **Spravovat zdroje**.
2. Klepněte na **Instalovat z GitHub**.
3. V modálním okně stahování se podívejte na záložku **Bible** a záložku **Globální Bible**. Pokud je váš překlad tam, vyberte ho a klepněte na **Instalovat vybrané**.
4. Pokud není, klepněte na **Instalovat lokální soubor** a importujte soubor `.bible`. Soubor získejte z GitHub stránky projektu. Podrobnou pomoc krok za krokem najdete v průvodci [Získání dalších zdrojů z GitHub](theodia://help/getting-core-files).
