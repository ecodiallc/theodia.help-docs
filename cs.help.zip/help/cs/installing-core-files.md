---
title: Přidání základních souborů
level: beginner
categories: start
summary: Jak stáhnout velké datové soubory, které aplikace potřebuje ke studiu Bible do hloubky.
---

# Přidání základních souborů

Theodia přichází s Biblí a pár malými doplňky připravenými k použití. Abyste z aplikace vytěžili maximum, musíte si stáhnout i **základní soubory**. Tohle jsou velké datové soubory, které přidávají studijní nástroje, jako komentář, vyhledávání slov a poznámky ke gramatice. Bez nich aplikace funguje, ale studijní funkce jsou omezené.

## Proč základní soubory potřebujete

Základní soubory přidávají:

- **Vyhledávání slov.** Klepněte na slovo v libovolném verši a uvidíte původní hebrejštinu nebo řečtinu a co znamená.
- **Komentář.** AI komentář ke každému verši.
- **Gramatiku.** Informace o každém slově v původním jazyce.
- **Interlineární Bible.** Čtěte text v původním jazyce s angličtinou pod každým slovem.

Bez nich Bible přečtete, ale většina studijních nástrojů je potřebuje.

## Jak nainstalovat základní soubory

**[Instalovat základní soubory](theodia://manage/core)**

1. Otevřete **Nastavení**.
2. Klepněte na **Spravovat zdroje**.
3. Otevře se záložka **Základní**. Uvidíte seznam základních souborů. Každý má název, velikost a zaškrtávací políčko.
4. Klepněte na každý soubor, který chcete nainstalovat. Značka ukazuje, že je vybrán.
5. Klepněte na **Instalovat vybrané**.
6. Počkejte, až se soubory stáhnou a nainstalují. Jsou velké, takže na pomalém připojení to může trvat pár minut.

Soubory se stáhnou na vaše zařízení. Udělat tohle musíte jen jednou. Aplikace soubory od té chvíle používá, i když jste offline.

## Tipy

- Používejte Wi-Fi. Soubory jsou velké.
- Připojte telefon nebo tablet. Velká stahování žerou baterii.
- Pokud stahování selže, klepněte na soubor znovu a opakujte.
- Můžete nainstalovat vše, nebo jen to, co potřebujete.

## Co když soubor chybí v seznamu?

Aplikace stahuje seznam z GitHub stránky projektu. Pokud je seznam prázdný, zkontrolujte internetové připojení a zkuste to znovu. Pokud je stále prázdný, podívejte se na průvodce [Kde klást otázky](theodia://help/getting-more-help).

Pokročilejší způsoby přidávání zdrojů popisuje průvodce [Získání dalších zdrojů z GitHub](theodia://help/getting-core-files).
