---
title: Jazyk a region aplikace
level: everyday
categories: settings
summary: Jak změnit jazyk aplikace.
---

# Jazyk a region aplikace

Theodia je dostupná v mnoha jazycích. Aplikace umí změnit jazyk nabídek a tlačítek. Obsah nápovědy je k dispozici v mnoha z těchto jazyků a je přímo součástí aplikace. Balíček nápovědy pro daný jazyk si také můžete stáhnout nebo aktualizovat — otevřete **Nastavení** → **Nápověda** nebo **Spravovat zdroje** → **Instalovat z GitHub** → **Dokumenty nápovědy**.

## Jak otevřít jazyková nastavení

1. Otevřete **Nastavení**.
2. Klepněte na **Jazyk**.

## Jak změnit jazyk aplikace

1. V seznamu **Jazyk** klepněte na požadovaný jazyk.
2. Aplikace nový jazyk použije okamžitě.

Volby, které vidíte, závisí na jazycích, které aplikace podporuje.

## Jak se jazyk zvolí při první instalaci

Když Theodii poprvé nainstalujete, aplikace vybere jazyk podle nastavení vašeho zařízení. Změnit ho můžete kdykoli.

## Co se překládá

- Nabídky, tlačítka a štítky.
- Obrazovky nastavení.
- Chybové zprávy.
- Vyhledávání a studijní nástroje.

## Co je jen v angličtině

- Některý obsah knih a bohoslužebných čtení.

## Biblické překlady a jazyk aplikace

Jazyk aplikace a jazyk biblického překladu jsou dvě různé věci. Můžete mít aplikaci ve španělštině a Bibli v angličtině, nebo naopak.

Jak změnit biblický překlad, popisuje průvodce [Instalace biblických překladů](theodia://help/installing-bibles).

## Tipy

- Pokud je tlačítko nebo štítek prázdný, aplikaci chybí překlad. Anglická verze tam obvykle je jako záloha.
- Chcete-li pomoci s překladem aplikace, podívejte se na průvodce [Kde klást otázky](theodia://help/getting-more-help).
