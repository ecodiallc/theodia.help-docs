---
title: Nabídka spouštěče
level: everyday
categories: layout
summary: Rychlý způsob, jak se vrátit k nedávným veršům, spustit příkazy a přepnout rozvržení Bible, aniž byste opustili aktuální obrazovku.
---

# Nabídka spouštěče

> **Režim:** Nabídka spouštěče vyžaduje režim **Scholar** (Badatel). Režim můžete přepnout v **Nastavení** → **Režim aplikace**.

Nabídka spouštěče je panel rychlého přístupu, který můžete otevřít téměř odkudkoli v aplikaci. Uchovává nedávné verše, příkazy a uložená nastavení Bible na jednom místě.

## Jak ji otevřít

Klepněte na **ikonu rozbalení (⌄)** v pravém horním rohu hlavičky domovské obrazovky. Panel se zasune shora.

## Co je uvnitř

### 1. Pole příkazu

Nahoře panelu je textové pole s ikonou klávesnice. Napište příkaz a klepněte na **Vykonat** na klávesnici. Aplikace příkaz přečte a zavede vás rovnou tam.

Příklady:

- `John 3:16` — otevře tento verš.
- `search love` — prohledá Bibli na „láska“.
- `bookmark psalms 23` — uloží verš do záložek.
- `kjv` — přepne na překlad KJV.

Kompletní seznam příkazů najdete v průvodci [Příkazy](theodia://help/commands).

### 2. Paralelní sady

Pokud máte uložené předvolby paralelních Biblí, objeví se zde jako sbalitelný seznam. Klepnutím na jednu okamžitě načtete toto paralelní nastavení.

Vytvoření paralelní předvolby:

1. Otevřete **Nastavení** → **Paralelní Bible**.
2. Přidejte překlady a klepněte na **Uložit předvolbu**.
3. Dejte jí název. Objeví se v nabídce spouštěče.

Dlouhým stiskem na paralelní sadě v nabídce spouštěče ji smažete.

### 3. Sbírky Bible

Sbírky Bible jsou zkratky na jedno klepnutí, které zároveň přepnou váš překlad i paralelní zobrazení. Pokud jste nějaké vytvořili, objeví se zde jako sbalitelný seznam.

Dlouhým stiskem na sbírku ji smažete.

### 4. Ikony funkcí

Pod polem příkazu můžete vidět řadu kulatých emoji tlačítek. Tohle jsou zkratky na jedno klepnutí k hlavním funkcím aplikace.

Dostupné ikony zahrnují:

- **O aplikaci**, **Bible**, **Poznámky k Bibli**, **Záložky**, **Knihy**
- **Bohoslužebná čtení**, **Flashkarty**, **Nápověda**, **Zvýraznění**
- **Seznamy skladeb**, **Pluginy**, **Hledat**, **Nastavení**, **Theoscript**

Jak zvolit, které ikony se zobrazí a v jakém pořadí:

1. Otevřete **Nastavení** → **Nabídka spouštěče**.
2. Klepněte na **Ikony nabídky spouštěče**.
3. Přepínači každou ikonu zobrazte nebo skryjte.
4. Šipkami nahoru/dolů přeřaďte ty, které jste povolili.

Pořadí v nastavení je pořadí, v jakém se objeví v nabídce spouštěče.

### 5. Nedávné verše

Aplikace si pamatuje poslední kapitoly a verše, které jste otevřeli. Objeví se jako seznam dole na panelu. Klepnutím na jakoukoli položku se na ni vrátíte.

- **Klepnutím** otevřete.
- **Přejezdem doleva** nebo **dlouhým stiskem** ji odeberete ze seznamu.
- Klepněte na **Vymazat vše** a odeberete všechny položky najednou.

## Kdy nabídku spouštěče použít

Použijte ji, když chcete:

- Vrátit se k verši, který jste právě četli.
- Napsat příkaz bez cesty na domovskou obrazovku.
- Přepnout překlad nebo paralelní nastavení jedním klepnutím.
- Otevřít hlavní funkci odkudkoli v aplikaci.
- Něco rychle zkontrolovat bez klikání nabídkami.

## Tipy

- Nabídka spouštěče je dostupná na téměř každé obrazovce, takže ji můžete otevřít při čtení kapitoly.
- Pole příkazu podporuje tytéž příkazy jako pole příkazu na domovské obrazovce.
- Ikony funkcí a jejich pořadí se ukládají lokálně na vašem zařízení. Přežijí restart aplikace.
- Nedávné verše se ukládají lokálně na vašem zařízení. Přežijí restart aplikace.
