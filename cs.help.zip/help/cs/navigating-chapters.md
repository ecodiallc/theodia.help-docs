---
title: Navigace mezi knihami, kapitolami a verši
level: everyday
categories: [layout, read]
summary: Jak se pohybovat po Bibli a přeskočit tam, kam chcete.
---

# Navigace mezi knihami, kapitolami a verši

Tento průvodce ukazuje všechny způsoby, jak se pohybovat po Bibli.

## Snadný způsob: přejezd

- Přejeďte **doleva** po kapitole na další kapitolu.
- Přejeďte **doprava** zpět.
- Funguje to i na další knihu. Po poslední kapitole, řekněme, Exodusu, vás přejezd zavede do první kapitoly Leviticus.

## Cesta nabídkou

- Klepnutím na název překladu nahoře přepnete na jinou Bibli.
- Klepnutím na název knihy nahoře vyberete jinou knihu.
- Klepnutím na číslo kapitoly vyberete jinou kapitolu.

## Rychlý způsob: psaní

- Na domovské stránce je nahoře pole. Zadejte odkaz, jako `John 3:16` nebo `psalms 23`, a klepněte na klávesu **Vykonat** na klávesnici.
- Aplikace verš otevře.

## Cesta přes záložky

Pokud jste si verš uložili, otevřete záložku **Záložky**. Klepnutím na jakoukoli položku na ni přeskočíte.

## Cesta přes hledání

Klepněte na záložku **Hledat**. Napište slovo. Aplikace vám ukáže každý verš, který ho má. Klepnutím na jakýkoli výsledek ho otevřete.

## Cesta přes historii

Aplikace si pamatuje kapitoly, které jste otevřeli. Najdete je znovu v záložce **Záložky** (pro verše, které jste si uložili), nebo projděte seznam knih v záložce **Bible** a najděte knihu, kterou jste četli nedávno.

## Tipy

- Záložka Bible ukazuje knihy v pořadí od Genesis po Zjevení.
- U žalmů, Přísloví a dalších dlouhých knih klepněte na knihu a použijte seznam kapitol k dlouhému přeskočení dopředu.
