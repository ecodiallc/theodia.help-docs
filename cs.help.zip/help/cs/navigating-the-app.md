---
title: Rozvržení a navigace aplikace
level: beginner
categories: layout
summary: Prohlídka domovské obrazovky, hlavní nabídky a dolní lišty — kde co najdete.
---

# Rozvržení a navigace aplikace

Theodia má tři hlavní oblasti, mezi kterými se pohybujete: **domovskou obrazovku**, **hlavní nabídku** a **dolní lištu**. Tento průvodce prochází každou z nich, takže vždy víte, kam jít.

## Rychlá mapa

- **Domovská obrazovka** je stránka, kterou uvidíte při prvním otevření aplikace. Má vyhledávací pole, velká tlačítka pro každou část aplikace a seznam vašich nainstalovaných Biblí, knih a bohoslužebných čtení.
- **Dolní lišta** (jinak řada záložek) je řada ikon dole na obrazovce. Klepnutím na kteroukoli z nich přeskočíte rovnou do té části aplikace.
- **Hlavní nabídka** je ikona se třemi čarami (☰) v pravém horním rohu domovské obrazovky. Klepnutím otevřete seznam všech obrazovek aplikace, včetně těch, které nemají vlastní záložku.

## Domovská obrazovka

Když Theodii poprvé otevřete, dostanete se na domovskou obrazovku. Je rozdělena na čtyři části, shora dolů.

### Hlavička

Úplně nahoře je barevný pruh. Vlevo je ikona aplikace a název „Theodia“. Vpravo je tlačítko hlavní nabídky (☰). Když jste uvnitř knihy nebo kapitoly, vlevo místo toho je tlačítko zpět (←). Klepněte na hlavní nabídku a otevřete nabídku (viz níže).

### Příkaz

Hned pod hlavičkou je textové pole ve stylu hledání označené **Příkaz**. Zadejte krátký pokyn a klepněte na klávesu pro odeslání na klávesnici. Aplikace pokyn přečte a zavede vás na správnou obrazovku. Příklady:

- `psalms 23` — otevře žalm 23
- `john 3:16` — otevře Jana 3:16
- `search love` — prohledá Bibli na „láska“
- `bookmark john 3:16` — uloží Jana 3:16 jako záložku
- `commentary romans 8:28` — otevře komentář k tomu verši
- `xref` (následovaný odkazem) — otevře křížové odkazy tohoto verše
- `help` — otevře seznam příkazů s příklady

Pokud aplikaci nerozumí, co jste zadali, ukáže malou výstrahu s tipem. Pokud příkazy nefungují, podívejte se do průvodce **Časté problémy**.

### Mřížka tlačítek

Pod Příkazem je mřížka velkých tlačítek, dvě na řádek. Každé tlačítko vás zavede do jiné části aplikace. Tlačítka jsou:

- 📖 **Bible** — váš seznam biblických překladů
- 🔍 **Hledat** — hledání slova nebo fráze v Bibli
- 📚 **Knihy** — vaše knihovna křesťanských klasik
- 📅 **Bohoslužebná čtení** — denní bohoslužebná čtení
- 🔖 **Záložky** — vaše uložené verše a kapitoly
- 🖍 **Zvýraznění** — vaše barevně označené verše
- 📝 **Poznámky** — vaše soukromé poznámky k veršům
- ⚙️ **Nastavení** — jazyk, téma, zdroje a víc
- ❓ **Nápověda** — systém nápovědy (tato stránka)
- ℹ️ **O aplikaci** — verze aplikace a poděkování

### Seznamy zdrojů

Pod mřížkou tlačítek jsou rozbalitelné sekce: **Bible**, **Knihy** a **Bohoslužebná čtení**. Každá sekce ukazuje položky, které máte nainstalované. Klepnutím na hlavičku sekce ji rozbalíte nebo sbalíte. Klepnutím na položku v sekci ji otevřete.

Sekce Bible je nejrychlejší cesta, jak přeskočit do konkrétního překladu — žádné nabídky, prostě klepněte.

## Dolní lišta

Dolní lišta (řada záložek) je řada ikon dole na obrazovce. Je téměř všude viditelná, takže se vždy můžete přeskočit do jiné sekce. Záložky, které vidíte, závisí na vašem uživatelském režimu.

**Všechny režimy vidí:**

- 🏠 **Domů** — otevře domovskou obrazovku
- 📖 **Bible** — otevře váš seznam biblických překladů
- 📚 **Knihy** — otevře vaši knihovnu knih
- 🔍 **Hledat** — otevře hledání v Bibli
- ⚙️ **Nastavení** — otevře nastavení

**Režim Standard a Badatel také vidí:**

- 🔖 **Záložky** — otevře vaše uložené verše
- 🖍 **Zvýraznění** — otevře vaše barevně označené verše
- 📝 **Poznámky** — otevře vaše soukromé poznámky

**Režim Badatel také vidí:**

- 💻 **AI** — otevře AI asistenta (pokud jste ho zapnuli v Nastavení)

Aktuální záložka je zvýrazněná. Klepněte na jinou záložku a přepnete.

### Jak se lišta chová

Každá záložka na liště má vlastní **zásobník** obrazovek. Když klepnete na záložku, vrátíte se tam, **kde jste skončili** v jejím zásobníku, ne na startovní obrazovku. Například:

- Klepnete na **Bible** → uvidíte seznam biblických překladů.
- Klepnete na překlad → uvidíte seznam knih.
- Klepnete na knihu → uvidíte seznam kapitol.
- Klepnete na kapitolu → čtete kapitolu.
- Přepnete na **Záložky** a něco zkontrolujete.
- Znovu klepnete na **Bible** → vrátíte se ke kapitole, kterou jste četli.

Každá záložka si pamatuje vaše místo. Aplikace uchovává vaši historii navigace v každé záložce, takže přepínání mezi záložkami nepřijde o postup.

### Co resetuje záložku

Záložka se resetuje na svou kořenovou obrazovku jen tehdy, když:

- Již na té záložce jste a klepnete znovu na tutéž ikonu záložky. To je rychlý způsob návratu na začátek.
- Aplikace je násilně zavřena a znovu otevřena.

### Dolní záložky vs. hlavní nabídka

- **Dolní záložky** — každá záložka si pamatuje svůj vlastní zásobník. Klepnutí na záložku vás vrátí tam, kde jste skončili.
- **Hlavní nabídka** — klepnutí na položku přejde na danou obrazovku stejným systémem záložek. Neotevírá se jako překryv.

Záložky použijte k přepnutí činnosti. Hlavní nabídku použijte, když chcete kompletní seznam všech obrazovek aplikace.

### Kdy lištu použít

Lištu použijte, když chcete změnit, co děláte:

- Čtete kapitolu a chcete něco jiného vyhledat → klepněte na **Hledat**.
- Hledáte a chcete zkontrolovat záložky → klepněte na **Záložky**.
- Jste kdekoliv v aplikaci a chcete domů → klepněte na **Domů**.

## Hlavní nabídka

Hlavní nabídka je tlačítko se třemi naskládanými čarami (☰) v pravém horním rohu domovské obrazovky. Klepnutím se panel zasune zprava. Panel ukazuje každou obrazovku, kterou váš aktuální režim podporuje:

- 🏠 **Domů**
- 📖 **Bible**
- 📚 **Knihy**
- 🙏 **Bohoslužebná čtení**
- 🔍 **Hledat**
- 🔖 **Záložky** (Standard a Badatel)
- 🖍 **Zvýraznění** (Standard a Badatel)
- 📝 **Poznámky** (Standard a Badatel)
- 💻 **AI asistent** (jen Badatel, a jen pokud je AI zapnutá)
- ⚙️ **Nastavení**
- ❓ **Nápověda**
- ℹ️ **O aplikaci**

Položka odpovídající obrazovce, na které právě jste, je zvýrazněná a má vedle sebe malou tečku. Klepnutím na jakoukoli položku se na ni dostanete rovnou. Klepněte mimo panel, na X nahoře, nebo na tlačítko zpět vašeho zařízení a zavřete ho beze změny obrazovky.

### Čím se hlavní nabídka liší

Hlavní nabídka je rozbalovací panel, nikoli samostatná navigační vrstva. Když klepnete na položku, aplikace přejde na danou obrazovku stejně, jako byste použili dolní záložku nebo mřížku tlačítek. Zásobník vaší aktuální záložky je zachován, takže se můžete vrátit tam, kde jste byli, opětovným klepnutím na původní záložku.

Například:

- Čtete Jana 3. Klepnete na záložku **Záložky**. Dostanete se ke svým záložkám. Když znovu klepnete na **Bible**, vrátíte se do Jana 3 — přesně tam, kde jste skončili.
- Čtete Jana 3. Otevřete hlavní nabídku a klepnete na **Poznámky**. Vaše poznámky se otevřou. Když se chcete vrátit do Jana 3, klepněte na záložku **Bible** a vrátíte se ke kapitole automaticky.

Záložky přepínají váš kontext a pamatují si vaše místo. Hlavní nabídka je prostě jiná cesta ke stejným obrazovkám.

### Kdy hlavní nabídku použít

Hlavní nabídku použijte, když:

- Chcete otevřít **Zvýraznění**, **Poznámky**, **Bohoslužebná čtení**, **Nápovědu** nebo **O aplikaci** — obrazovky, které nemají vlastní záložku na liště.
- Jste hluboko v kapitole nebo hledání a chcete něco rychle zkontrolovat, aniž byste ztratili místo.
- Chcete otevřít **Nastavení**, aniž byste opustili obrazovku, na které jste.

## Režim Badatel

Pokud je váš uživatelský režim nastaven na **Badatel**, rozvržení získá další záložky, položky nabídky a nástroje čtečky, které režimy Čtenář a Standard skrývají. Kompletní průchod všemi funkcemi najdete v průvodci [Režim Badatel](theodia://help/scholar-mode).

## Jak se tři oblasti zapadají dohromady

- **Přepnutí do jiné hlavní sekce** (Bible, Hledat, Záložky atd.) → Dolní lišta
- **Skočit na konkrétní verš nebo příkaz** → Příkaz na domovské obrazovce
- **Procházet všechny dostupné obrazovky** → Mřížka tlačítek na domovské obrazovce
- **Zkontrolovat poznámky, zvýraznění nebo nápovědu, aniž byste opustili místo** → hlavní nabídka
- **Otevřít Nastavení odkudkoli** → hlavní nabídka nebo lišta

Použijete všechny tři. Žádná není „ta správná cesta“. Zvolte tu nejsnazší pro to, co právě děláte.

### Lišta vs. hlavní nabídka: rychlý příklad

Představte si, že čtete Římanům 8 a chcete zvýraznit verš, který se vám líbí.

**Pomocí lišty:**

1. Klepněte na verš a otevřete nabídku verše.
2. Klepněte na **Zvýraznit** a vyberte barvu.
3. Hotovo. Nikdy jste kapitolu neopustili.

**Pomocí hlavní nabídky (pokud si chcete zvýraznění projít):**

1. Klepněte na ☰ a otevřete nabídku.
2. Klepněte na **Zvýraznění**. Otevře se váš seznam zvýraznění.
3. Projděte si je, potom klepněte na záložku **Bible** a vraťte se do Římanům 8.

**Pomocí lišty (pokud chcete změnit činnost):**

1. Klepněte na **Domů** nebo **Záložky** na liště.
2. Opustíte Římanům 8 a dostanete se na novou obrazovku.
3. Když se chcete vrátit do Římanů 8, znovu klepněte na **Bible** — automaticky se vrátíte ke kapitole.

## Tipy

- Domovská obrazovka si pamatuje, které sekce jsou rozbalené nebo sbalené. Stačí to nastavit jednou.
- Pokud nevidíte záložku, kterou očekáváte, zkontrolujte dvě věci:

1. **Váš uživatelský režim** — Režim Čtenář skrývá záložky, zvýraznění, poznámky a AI. Režim Standard skrývá AI. Režim přepnete v **Nastavení** → **Režim aplikace**.
2. **Nastavení funkcí** — některé záložky je třeba zapnout v **Nastavení** (například AI asistent).
