---
title: Psání poznámek
level: everyday
categories: [annotate, read]
summary: Jak si napsat vlastní myšlenky k verši.
---

# Psání poznámek

> **Režim:** Poznámky jsou dostupné v režimu **Standard** a **Badatel**. Režim Soustředění je určen jen pro čisté čtení bez rozptylování. Režim můžete přepnout v **Nastavení** → **Režim aplikace**.

Poznámky jsou místo, kde si k verši napíšete vlastní myšlenky, modlitby nebo studijní nápady. Každá poznámka je vázaná na konkrétní verš.

## Jak přidat poznámku

1. Otevřete verš.
2. Klepněte na verš, čímž zobrazíte nabídku.
3. V nabídce klepněte na **Poznámka**. Má ikonu tužky.
4. Napište poznámku.
5. Klepněte na **Uložit**.

Poznámka je nyní uložena s veršem.

## Jak poznámku přečíst

1. Otevřete verš.
2. Hledejte tužku vedle verše. Znamená to, že tu je poznámka.
3. Klepněte na verš. Poznámka se objeví pod ním.

## Jak upravit poznámku

1. Otevřete verš s poznámkou.
2. Klepněte na verš.
3. V nabídce klepněte na **Poznámka**.
4. Proveďte změny.
5. Klepněte na **Uložit**.

## Jak smazat poznámku

1. Otevřete verš s poznámkou.
2. Klepněte na verš.
3. V nabídce klepněte na **Poznámka**.
4. Klepněte na **Smazat**.

## Jak vidět všechny své poznámky

Klepněte na záložku **Poznámky** dole. Uvidíte seznam všech napsaných poznámek seřazených podle data.

## Hledejte ve svých poznámkách

Na záložce **Poznámky** klepněte do pole **Hledat**. Napište slovo. Aplikace najde každou poznámku, která to slovo má.

## Tipy

- Poznámky se hodí pro kázání, bohoslužby a studijní otázky.
- Poznámky jsou soukromé. Zůstávají na vašem zařízení.
- Jak je udržet v bezpečí, popisuje průvodce [Zálohování dat](theodia://help/backups).
