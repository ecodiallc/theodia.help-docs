---
title: Oznámení a připomínky
level: everyday
categories: [settings]
summary: Jak zapnout, přizpůsobit a spravovat offline připomínky pro modlitbu, bohoslužebná čtení, biblické plány a další.
---

# Oznámení a připomínky

Theodia vám může připomínat modlitbu, bohoslužebná čtení, biblické plány, flashkarty a další činnosti — i když je aplikace offline. Všechny připomínky se plánují na vašem zařízení; internetové připojení ani server push oznámení nejsou potřeba.

## Jak zapnout nebo vypnout připomínky

1. Otevřete **Nastavení**.
2. Klepněte na **Oznámení**.
3. Přepněte **Povolit připomínky** na zapnuto nebo vypnuto.

Když připomínky poprvé povolíte, aplikace požádá o povolení posílat oznámení. Klepněte na **Povolit**, aby se připomínky mohly objevovat.

Pokud jste povolení dříve zamítli, iOS nebo Android mohou požadavek zablokovat. V takovém případě přejděte do aplikace **Nastavení** vašeho zařízení, najděte **Theodii** a tam oznámení povolte.

## Typy připomínek

Obrazovka oznámení je rozdělena na kanály. Každý kanál je rodina připomínek, které lze zapínat nebo vypínat nezávisle:

- **Modlitební připomínky** — obecné modlitební připomínky.
- **Modlitební rutina** — připomínky vázané na konkrétní modlitební rutinu.
- **Bohoslužebné čtení** — připomínka denního verše nebo bohoslužebného čtení.
- **Připomínky biblického plánu** — připomínky aktivního biblického plánu.
- **Připomínky Theoscript** — připomínky ke spuštění Theoscriptu.
- **Připomínky AI vhledu** — připomínky generované AI.
- **Připomínky revize flashkaret** — výzvy k revizi flashkaret.
- **Připomínky čtecího návyku** — denní výzvy čtecího návyku.
- **Liturgické a sezónní připomínky** — připomínky vázané na církevní kalendář.
- **Mé připomínky** — připomínky, které jste vytvořili ze záložek, zvýraznění, seznamů skladeb, biblických kapitol nebo knih.
- **Vlastní připomínky** — plně vlastní připomínky, které si vytvoříte sami.

Klepněte na libovolný kanál a uvidíte jeho připomínky, změníte čas, zvolíte, ve které dny se spustí, nebo ho vypnete.

## Vlastní připomínky

Vlastní připomínky jsou připomínky, které si postavíte úplně od nuly.

1. V **Nastavení** → **Oznámení** klepněte na **Vlastní připomínky**.
2. Klepněte na tlačítko **+**.
3. Zadejte **Název** a **Zprávu**.
4. Zvolte **Čas**.
5. Vyberte **Dny**, ve které se má opakovat.
6. Zvolte, co připomínka otevře při klepnutí (volitelné).
7. Klepněte na **Uložit**.

Vlastní připomínku můžete kdykoli upravit nebo smazat jejím klepnutím v seznamu.

## Co se stane, když klepnete na připomínku

Většina připomínek otevře konkrétní obrazovku v aplikaci. Například připomínka modlitební rutiny otevře tu rutinu; připomínka biblického plánu otevře další čtení.

Pokud připomínka nemá odkázanou obrazovku, otevře aplikaci na domovské obrazovce.

## Tiché hodiny

Tiché hodiny ztlumí zvuky oznámení, ale vizuální připomínky se dál objevují.

1. V **Nastavení** → **Oznámení** klepněte na **Tiché hodiny**.
2. Nastavte **Začátek** a **Konec**.

Připomínky naplánované v tichých hodinách se na obrazovce ukáží bez zvuku.

## Nadcházející připomínky a historie

- **Nadcházející připomínky** ukazuje vše, co má být naplánováno ke spuštění.
- **Historie oznámení** ukazuje nedávno doručené, naplánované a zrušené připomínky.

Použijte tyhle seznamy, abyste potvrdili správné nastavení připomínky, nebo abyste viděli, proč se neobjevila.

## Pokud se připomínky neobjevují

- Ujistěte se, že **Povolit připomínky** je zapnuté.
- Zkontrolujte, že jsou oznámení povolená v systémových nastaveních vašeho zařízení.
- Ujistěte se, že kanál připomínky je povolený a že je zvolen alespoň jeden den.
- Pokud jste nastavili tiché hodiny, může být připomínka tichá.
- Někteří výrobci Androidu uspávají aplikace. Přidejte Theodii na seznam povolených, pokud vaše zařízení nabízí nastavení optimalizace baterie.
- Pokud je připomínka vázaná na obsah, který jste odebrali (například smazaný biblický plán nebo rutina), nemusí se spustit, dokud znovu nevyberete platný cíl.

## Zvuky oznámení

Můžete zvolit zvuk, který přehrají připomínky podporující zvuky. Klepněte na **Zvuk** uvnitř připomínky nebo kanálu a vyberte z dostupných voleb. Zvuky jsou součástí aplikace, takže fungují offline.

Tlačítkem **Náhled zvuku** si zvuk vyslechnete před uložením.

## Odznaky

Některé připomínky mohou přidat odznak na ikonu aplikace. Klepnutím na **Vymazat odznak** na obrazovce oznámení ho resetujete.
