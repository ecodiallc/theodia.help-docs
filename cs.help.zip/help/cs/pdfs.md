---
title: PDF
level: everyday
categories: [read, resources]
summary: Importujte, organizujte a čtěte PDF dokumenty v Theodii.
---

# PDF

> **Režim:** PDF jsou dostupná v režimu **Standard** a **Badatel**. Režim Soustředění je určen jen pro čisté čtení bez rozptylování. Režim můžete přepnout v **Nastavení** → **Režim aplikace**.

Theodia umí ukládat a číst PDF soubory. Importovaná PDF zůstávají na vašem zařízení, takže fungují offline.

## Otevřete knihovnu PDF

Klepněte na záložku **PDF** dole na obrazovce, nebo klepněte na dlaždici **PDF** na domovské obrazovce.

## Import PDF

1. Otevřete záložku **PDF**.
2. Klepněte na tlačítko **+** vpravo dole.
3. Zvolte PDF ze svého zařízení.
4. (Volitelné) Napište nebo vyberte kategorii pro uspořádání.

## Organizace PDF

Dlouze stiskněte jakoukoli kartu PDF a otevřete nabídku s těmito volbami:

- **Přejmenovat** — změňte název zobrazený v knihovně.
- **Změnit kategorii** — přesuňte PDF do kategorie.
- **Smazat** — odeberte PDF z Theodie. Tím se smaže i uložená pozice čtení.

Kategorie jsou libovolný text. Při importu nebo změně kategorie napište nový název nebo vyberte existující.

## Čtení PDF

Klepněte na kartu PDF a otevřete ho. Čtečka ukazuje:

- Název dokumentu v pruhu nahoře.
- Řadu stránek s tlačítky: **První stránka**, **Předchozí**, aktuální stránka („3 / 120“), **Další** a **Poslední stránka**.
- Lištu s nástroji dokumentu: **Obsah**, **Oddálit**, **Přiblížit**, **Resetovat přiblížení**, **Záložka**, **Hledat**, **Poslouchej** a **Textový zobrazení**.

Některé nástroje jsou ztlumené, když je nelze použít — například **Hledat** a **Poslouchej** jsou ztlumené, dokud není nainstalován hledatelný text PDF.

### Otáčení stránek

- Klepněte na **levou** nebo **pravou šipku** a přejděte o stránku zpět nebo dopředu.
- Klepnutím na **První stránka** nebo **Poslední stránka** přeskočíte na kterýkoli konec dokumentu.
- Klepněte na číslo stránky (například „3 / 120“) a otevřete mřížku stránek, potom klepněte na požadovanou stránku. Mřížka se otevře poblíž stránky, na které jste.
- Použijte **šipky doleva a doprava** na externí klávesnici.

### Přiblížení

- Klepnutím na **Přiblížit** (+) nebo **Oddálit** (−) změníte velikost stránky.
- Klepnutím na **Resetovat přiblížení** vrátíte stránku na normální velikost.
- Pokud přiblížíte, otočíte stránku a pak oddálíte, Theodia vás vrátí na stránku, kterou jste četli.

## Hledání v PDF

1. Otevřete PDF a klepněte na tlačítko **Hledat** (lupa) na liště.
2. Napište, co hledáte. Výsledky se objevují při psaní, s číslem stránky a úryvkem okolního textu.
3. Klepnutím na výsledek přeskočíte na tu stránku.

Hledání potřebuje nainstalovaný hledatelný text PDF. Pokud ještě není nainstalován, tlačítko Hledat je ztlumené. PDF nainstalovaná z komunitního GitHub repozitáře hledatelný text zahrnují; PDF, která importujete sami, ho nemají, dokud se nepřidá.

## Obsah

Pokud má PDF vestavěný obsah, tlačítko **Obsah** na liště ho ukáže jako osnovu. Klepnutím na název sekce přeskočíte na tu stránku. Sekce lze rozbalit a sbalit. Pokud PDF obsah nemá, tlačítko je ztlumené.

## Záložky v PDF

1. Otevřete PDF a klepněte na tlačítko **Záložka** na liště.
2. Klepněte na **Záložka stránky** a uložte aktuální stránku. Název začíná jako číslo stránky — pokud chcete, napište vlastní název — potom klepněte na **Uložit**.
3. Klepnutím na jakoukoli záložku v seznamu přeskočíte na její stránku.
4. Klepněte na **×** vedle záložky a smažte ji.

PDF záložky jsou oddělené od záložek Bible. Každé PDF má vlastní seznam.

## Čtení PDF nahlas

Pokud je hledatelný text PDF nainstalován, Theodia umí přečíst aktuální stránku nahlas:

1. Otevřete PDF a klepněte na tlačítko **Poslouchej** (reproduktor) na liště.
2. Objeví se ovládací lišta s **Přehrát/Pauza**, **Zpětný posun**, **Rychlý posun**, **Zastavit**, ukazatelem postupu, na který můžete klepnout a přeskočit v rámci stránky, rychlostí čtení a hlasem.
3. Když stránka skončí, čtení pokračuje automaticky na další stránce.

Hlas a rychlost jsou tytéž jako při čtení Bible — viz [Čtení nahlas](theodia://help/tts), jak je změnit.

## Kopírování, sdílení nebo ukládání textu stránky

Klepněte na tlačítko **Textové zobrazení** na liště a uvidíte aktuální stránku jako prostý text. Odtud můžete:

- **Kopírovat** — zkopírujte text stránky do schránky.
- **Sdílet** — sdílejte text stránky přes jakoukoli aplikaci na vašem zařízení.
- **Přidat do studijních poznámek** — otevře editor poznámek s textem stránky, citací a odkazem zpět na tuto stránku, předvyplněným za vás.

## Pokračování ve čtení

Theodia si pamatuje poslední zobrazenou stránku a příště otevře PDF tam.

## Stahování PDF z GitHub

V režimu **Badatel** se dole v knihovně objeví tlačítko **Stáhnout z GitHub**. Připojí se ke komunitnímu repozitáři PDF, takže si můžete nainstalovat zabaleny PDF dokumenty stejně, jako instalujete Bible nebo knihy.

## Poznámky

- PDF jsou uložena v soukromé složce dokumentů Theodie. Do záloh se nezahrnují, takže když se přesunete na nové zařízení, musíte je znovu importovat.
