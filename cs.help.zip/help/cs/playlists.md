---
title: Seznamy skladeb
level: everyday
categories: playlists
summary: Vytvářejte a poslouchejte mluvené seznamy biblických míst, prostého textu nebo jakéhokoli verše, který chcete slyšet.
---

# Seznamy skladeb

**Seznam skladeb** je seznam stop, které vám Theodia přečte nahlas. Každá stopa je buď biblické místo, nebo krátká prostá textová poznámka. Seznamy skladeb se hodí pro poslech bez použití rukou při cestování, procházce, bohoslužbě nebo procvičování zapamatování.

Seznamy skladeb se v aplikaci objeví, jakmile je vytvořen nebo naplněn alespoň jeden.

## Kde seznamy skladeb najít

Když jsou seznamy skladeb dostupné, dostanete se k nim dvěma způsoby:

- **Domovská obrazovka:** V sekci **Pluginy a víc** klepněte na **Seznamy skladeb**.
- **Hlavní nabídka:** Otevřete nabídku (☰) a klepněte na **Seznamy skladeb**.

Pokud žádné seznamy skladeb neexistují, dlaždice Seznamy skladeb a položka nabídky jsou skryté.

## Co seznam skladeb obsahuje

Každý seznam skladeb má:

- **Název** — například „Ranní verše“ nebo „Zapamatovat si žalm 23“.
- Volitelnou **kategorii** — hodí se pro seskupení seznamů podle účelu.
- Seznam **stop** — položky ke přečtení nahlas.

Každá stopa obsahuje:

- **Obsah** — buď odkaz na biblické místo, nebo prostý text.
- **Štítek** — zobrazený na obrazovce během přehrávání stopy.
- Volitelný **hlas** — pokud chcete, zvolte pro tuto stopu jiný hlas.

## Vytvoření seznamu skladeb

1. Otevřete obrazovku **Seznamy skladeb**.
2. Klepněte na **Vytvořit seznam skladeb** (nebo na tlačítko **+**).
3. Dejte seznamu název.
4. (Volitelné) Zvolte nebo vytvořte kategorii.
5. Začněte přidávat stopy.

### Přidání stopy z biblického místa

1. Klepněte na **Přidat stopu**.
2. Zvolte **Biblické místo** jako typ obsahu.
3. Zadejte odkaz, například `John 3:16` nebo `Psalm 23:1-6`.
4. Přidejte štítek, pokud chcete, nebo ho nechte prázdný a použije se odkaz.
5. Uložte stopu.

### Přidání stopy s prostým textem

1. Klepněte na **Přidat stopu**.
2. Zvolte **Prostý text**.
3. Napište text, který má Theodia přečíst.
4. Přidejte štítek.
5. Uložte stopu.

### Hromadné přidávání stop

Pokud máte seznam odkazů nebo textových řádků, použijte **Hromadné přidání**:

1. Otevřete seznam skladeb.
2. Klepněte na nabídku a zvolte **Hromadné přidání**.
3. Vložte jeden odkaz nebo textový řádek na řádek.
4. Zapněte **Detekovat biblické odkazy**, pokud většina řádků je odkazy na verše.
5. Klepněte na **Přidat**. Každý řádek se stane stopou.

## Poslech seznamu skladeb

1. Otevřete seznam skladeb, který chcete slyšet.
2. Klepněte na tlačítko **Přehrát** nahoře nebo vedle stopy.
3. Theodia přečte každou stopu v pořadí.

Během přehrávání seznamu se objeví ovládací lišta s těmito ovládacími prvky:

- **Přehrát / Pauza**
- **Další stopa**
- **Předchozí stopa**
- **Zastavit**

Můžete také nastavit:

- **Rychlost** — jak rychle hlas čte.
- **Opakování** — opakovat celý seznam, opakovat jednu stopu, nebo přehrát jednou.
- **Náhodné pořadí** — přehrávat stopy v náhodném pořadí.
- **Ignorovat závorky** — přeskočit text uvnitř závorek.
- **Pauza mezi stopami** — přidat krátké ticho mezi stopy.
- **Časovač spánku** — zastavit přehrávání po nastaveném čase.

## Úprava seznamu skladeb

Chcete-li seznam skladeb změnit, nejdřív pozastavte přehrávání, pokud právě hraje.

Můžete:

- **Přejmenovat** seznam skladeb.
- **Přeřadit stopy** — přetáhněte stopy do nového pořadí.
- **Upravit stopu** — změňte její odkaz, text, štítek nebo hlas.
- **Smazat stopu** — odeberte ji ze seznamu skladeb.
- **Smazat celý seznam skladeb** — tohle nelze vzít zpět.

## Export a import seznamů skladeb

Seznamy skladeb se exportují jako JSON soubory, které obsahují všechny stopy, kategorie a nastavení. Soubor můžete sdílet s jiným zařízením, uchovat jako zálohu, nebo ho upravit na počítači.

- **Exportovat všechny seznamy skladeb** — vytvoří soubor `playlists-YYYY-MM-DD.json`.
- **Exportovat kategorii** — vytvoří JSON soubor obsahující jen seznamy skladeb v jedné kategorii.
- **Importovat seznamy skladeb** — obnoví seznamy skladeb ze záložního JSON souboru.

## Rychlé způsoby, jak postavit seznam skladeb

Kompletní seznam skladeb můžete vytvořit i jako JSON a importovat ho. Zde je příklad:

```json
{
  "playlists": [
    {
      "name": "Morning Verses",
      "category": "Devotional",
      "tracks": [
        {
          "info": "John 3:16",
          "contentSource": "passage",
          "content": "For God so loved the world...",
          "rawContent": "John 3:16"
        },
        {
          "info": "Psalm 23",
          "contentSource": "passage",
          "content": "The Lord is my shepherd...",
          "rawContent": "Psalm 23:1-6"
        }
      ]
    }
  ]
}
```

Uložte soubor a potom pomocí **Importovat seznamy skladeb** ho načtěte do Theodie.

## Tipy

- Seznamy skladeb fungují nejlépe s krátkými, zaměřenými sadami veršů.
- Kategorie použijte k oddělení bohoslužebných seznamů od seznamů pro zapamatování.
- Nastavte časovač spánku, pokud posloucháte při usínání.
- Pokud stopa používá špatný hlas, zkontrolujte, že jazyk hlasu odpovídá jazyku textu.
- Theodia čte prostý text přesně tak, jak je napsaný; pro nejlepší výsledky zkontrolujte pravopis.
