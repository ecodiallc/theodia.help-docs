---
title: Přehled modlitby
level: beginner
categories: prayer
summary: Rychlé představení záložky Modlitba a jejích hlavních sekcí.
---

# Přehled modlitby

Záložka **Modlitba** je vyhrazené místo pro modlitbu. Spojuje seznamy, vedené sezení, deník, časovač, čtecí plány lekcionáře a klasické pevné modlitby.

## Hlavní sekce

- **Modlitební seznam** — sledujte lidi, situace a témata, za která se modlíte.
- **Deník** — zapisujte v průběhu času úvahy, odpovědi a myšlenky.
- **Vygenerovat modlitbu** — požádejte Theophila, aby napsal modlitbu z žádosti nebo záznamu deníku.
- **Vyznání a pevné modlitby** — klasické modlitby a vyznání z křesťanské tradice.
- **Lekcionář** — čtecí plány Písma pro denní nebo sezónní modlitbu.
- **Vedená modlitba** — modlitební sezení s hlasovým vedením pomocí převodu textu na řeč.
- **Časovač** — časovaná modlitební sezení s volitelnými zvony.
