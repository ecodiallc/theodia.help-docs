---
title: Čtení vestavěných knih
level: beginner
categories: [content, read]
summary: Jak číst křesťanské klasiky, které přicházejí s aplikací.
---

# Čtení vestavěných knih

Theodia přichází s malou knihovnou křesťanských knih. Tohle jsou klasiky, které si můžete přečíst na svém zařízení.

## Jak otevřít knihovnu

Klepněte na záložku **Knihy** dole na obrazovce. Uvidíte seznam knih ve vaší knihovně.

## Jak číst knihu

1. Klepněte na název knihy.
2. Kniha se otevře na první kapitole.
3. Tlačítky **Předchozí** a **Další** nahoře se pohybujte mezi kapitolami.

## Jak přeskočit na kapitolu

Klepněte na název kapitoly nahoře na obrazovce. Objeví se seznam kapitol. Vyberte kapitolu a přeskočíte na ni.

## Jak změnit velikost písma

Otevřete **Nastavení** → **Vzhled** a vyberte velikost písma. Velikost textu se změní v celé aplikaci, včetně knih.

## Jak přidat záložku v knize

Klepněte na ikonu **hvězdičky** vpravo nahoře. Aktuální kapitola se uloží. Klepněte na záložku **Záložky** a uvidíte uložené stránky.

## Jak knihu poslouchat

Klepněte na ikonu **Reproduktor** vpravo nahoře. Aplikace přečte kapitolu nahlas. Znovu klepnutím ji zastavíte.

## Jaké knihy jsou dostupné?

Knihovna má klasiky jako:

- Pilgrim's Progress
- The Imitation of Christ
- Practice of the Presence of God
- The Hymn Book

Seznam knih může v průběhu času růst. Aktualizace aplikace mohou přidat další.

## Tipy

- Knihy jsou uloženy na vašem zařízení. Internet není potřeba.
- Knihy se nesynchronizují do cloudu.
