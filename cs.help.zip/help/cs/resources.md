---
title: Hledání zdrojů na GitHub
level: everyday
categories: resources
summary: Prohledejte každý GitHub repozitář, o kterém aplikace ví, najednou, potom nainstalujte, co najdete.
---

# Hledání zdrojů na GitHub

Theodia uchovává seznam GitHub repozitářů, které publikují zdroje — Bible, komentáře, knihy, bohoslužebná čtení, seznamy skladeb, modlitební balíčky a víc. **Hledat v GitHub repozitářích** prohledá všechny najednou, takže nemusíte otevírat každou záložku a procházet je zvlášť.

> Sekce GitHub v Nastavení je dostupná jen v režimu **Badatel**. Zapnete ji na **Nastavení → Uživatelský režim → Badatel**.

## Jak hledat

1. Otevřete **Nastavení**.
2. Klepněte na **Hledat v GitHub repozitářích**.
3. Napište slovo do vyhledávacího pole. Aplikace hledá to slovo v **názvu** a **popisu** každého balíčku v každém repozitáři.

Pár věcí o hledání, které je dobré vědět:

- **Každé slovo musí sedět.** Hledání `morning evening` najde jen balíčky, jejichž název nebo popis obsahuje *obě* slova.
- **Velikost písmen nezáleží.** `Morning` a `morning` najdou tytéž balíčky.
- **Nejlepší shoda přijde první.** Balíček, jehož název *začíná* vaším hledaným výrazem, se ukáže před takovým, který ho jen zmiňuje v popisu.

## Filtrování

Klepněte na lištu filtrů nad výsledky a seznam ještě zúžíte. Jsou dva filtry a fungují spolu:

- **Autor** — jen balíčky od toho autora.
- **Tradice** — jen balíčky pro danou tradici.

Klepnutím na filtr znovu ho vymažete, nebo klepněte na **Vymazat filtry** a resetujete oba.

## Instalace z výsledku

Každý výsledek ukazuje název balíčku, jaký druh zdroje to je, kdo ho vytvořil a z jakého repozitáře pochází. Vpravo na řádku je jedno tlačítko:

- **Instalovat** — balíček ještě není na vašem zařízení.
- **Aktualizovat** — je dostupná novější verze. Aplikace vás nejdřív požádá o potvrzení, protože aktualizace odstraní starou kopii spolu s poznámkami, zvýrazněními nebo záložkami, které na ni ukazují.
- **Otevřít** — balíček už je nainstalovaný; klepnutím se dostanete na obrazovku, kde ho používáte.

Klepněte nahoře na **Obnovit** a hned načtete nejnovější seznam z GitHub. Aplikace si seznam sama obnoví jednou denně, takže ruční obnovení je potřeba jen tehdy, když víte, že něco nového bylo publikováno.

## Hledání bez připojení

Aplikace uchovává kopii seznamu na vašem zařízení, takže hledání funguje i offline. Pokud se aplikace nedostane na GitHub a seznam neobnoví, prouh nahoře vám řekne, že vidíte uložené výsledky.

## Pokud hledání nic nenajde

- Zkuste kratší, jednoslovné hledání.
- Zkontrolujte, že není stále použitý filtr **Autor** nebo **Tradice** — tlačítko **Vymazat filtry** se objeví, kdykoli nějaký je.
- Některé repozitáře publikují své balíčky v jiném jazyce než je název balíčku, takže hledání přeloženým slovem je nemusí najít.
