---
title: Režim Badatel
level: advanced
categories: [layout, read, study]
summary: Nejhlubší studijní režim v Theodii, který odemyká komentáře, lexikony, křížové odkazy, AI nástroje a nabídku spouštěče.
---

# Režim Badatel

> **Režim:** Režim Badatel je dostupný jen tehdy, když je váš uživatelský režim nastaven na **Badatel**. Režim přepnete v **Nastavení** → **Režim aplikace**.

Režim Badatel odemyká každý studijní nástroj v Theodii. Staví na režimu Studium, takže stále máte nabídku verše, paralelní Bible, záložky, zvýraznění a poznámky — plus pokročilé nástroje vypsané níže.

## Jak otevřít režim Badatel

Režim Badatel není samostatná obrazovka. Je to sada extra nástrojů, které se objeví uvnitř stávající čtečky a navigace, když je váš uživatelský režim nastaven na Badatel.

1. Otevřete **Nastavení**.
2. Klepněte na **Režim aplikace**.
3. Zvolte **Badatel**.

Změna se projeví okamžitě. Nabídky a tlačítka, které byly skryté, se teď objeví.

## Extra nástroje čtečky

Když otevřete kapitolu v [režimu Studium](theodia://help/study-mode), režim Badatel přidává tyto nástroje do nabídky verše:

- **AI komentář** (◈) — požádejte AI asistenta, aby napsal studijní poznámku k tomuto verši. (Není dostupný ve všech regionech.)
- **Info o slově** (?) — otevřete položku lexikonu pro původní hebrejské nebo řecké slovo za veršem. Viz průvodce [Komentáře a lexikony](theodia://help/commentaries-and-lexicons).
- **Slovník** (📖) — vyhledejte obecná biblická slova v nainstalovaných slovních zdrojích. Viz průvodce [Biblický slovník](theodia://help/dictionary).

Tyhle nástroje potřebují nainstalované zdroje (komentáře, lexikony, soubory slovníků). Pokud je nástroj zašedlý nebo ukazuje „nenalezeno“, otevřete **Nastavení** → **Spravovat zdroje** a přidejte zdroj, který potřebuje.

## Extra navigace

### Extra záložka na liště

Dolní lišta získá jednu extra záložku:

- 💻 **AI** — otevře AI asistenta (jen pokud jste AI zapnuli v Nastavení). Tato záložka sedí vpravo od Poznámek.

### Extra položky hlavní nabídky

Hlavní nabídka za stejných podmínek zahrnuje položku **AI asistent**.

## Nabídka spouštěče

Režim Badatel povoluje **Nabídku spouštěče**, rychlý způsob, jak se vrátit k nedávným veršům, spustit příkazy a přepnout rozvržení Bible, aniž byste opustili aktuální obrazovku. Jak ji používat, popisuje průvodce [Nabídka spouštěče](theodia://help/launcher-menu).

## Kdy režim Badatel použít

- Chcete AI asistenta, komentáře nebo vyhledávání v původních jazycích během čtení.
- Chcete nabídku spouštěče pro rychlou navigaci veršů a AI chat.
- Studujete místo do hloubky a potřebujete každý nástroj jedno klepnutí daleko.

## Přepnutí do lehčího režimu

Pokud chcete jednodušší čtečku bez pokročilých nástrojů, přepněte na režim **Standard** v **Nastavení** → **Režim aplikace**. Režim Standard zachovává záložky, zvýraznění, poznámky a režim Studium, ale skrývá AI, komentáře, lexikony a nabídku spouštěče.

Pokud chcete nejčistší možný zážitek ze čtení, otevřete kapitolu v [režimu Soustředění](theodia://help/focus-mode).

Vaše záložky, zvýraznění a poznámky se při změně režimu nikdy nemažou; jsou jen skryté, dokud se nevrátíte do režimu, který je podporuje.

## Nápověda a otázky

Pokud nástroj chybí nebo ukazuje chybu, podívejte se na průvodce [Časté problémy](theodia://help/common-problems). Pokud jste v Theodii noví, průvodce [Čtení první kapitoly](theodia://help/first-read) vás krok za krokem provede základy.
