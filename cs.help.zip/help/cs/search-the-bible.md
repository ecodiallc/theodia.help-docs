---
title: Hledání v Bibli
level: everyday
categories: [study, read]
summary: Jak najít verše podle slova, fráze nebo odkazu.
---

# Hledání v Bibli

Vyhledávací lišta vám pomůže rychle najít verše. Můžete hledat podle slova, fráze nebo biblického odkazu.

## Jak hledání spustit

1. Klepněte na záložku **Hledat** dole na obrazovce.
2. Napište, co chcete najít.
3. Klepněte na klávesnici na **Hledat**.

Výsledky se objeví jako seznam veršů. Každý výsledek ukazuje knihu, kapitolu a verš, plus text verše.

## Hledání kombinací slov

Když napíšete víc než jedno slovo, jako `love joy`, aplikace najde verše, které obsahují **obě** slova. Tohle je hledání **AND** — všechna slova se musí objevit ve verši. Nepoužívá logiku **OR** (verše s kterýmkoli jediným slovem).

Chcete-li hledat verše obsahující jedno nebo druhé slovo, musíte výslovně použít klíčové slovo `OR`: `love OR joy`.

## Hledání podle slova

Napište jediné slovo, jako `love` nebo `mercy`. Aplikace ukáže každý verš v Bibli, který to slovo má.

## Hledání podle fráze

Napište dvě nebo tři slova do uvozovek, jako `"do not be afraid"`. Aplikace ukáže verše, které mají přesně tu frázi.

## Filtrování výsledků

Po hledání se výsledky filtrují na biblické překlady, které máte nainstalované. Chcete-li dále zúžit, otevřete záložku **Bible** a podívejte se na konkrétní překlad — hledání běží proti překladům, které máte.

## Tipy pro lepší hledání

- Používejte krátká slova. Hledání `love` najde víc veršů než hledání `loving`.
- Uvozovky kolem fráze dělají hledání přesné.
- Aplikace hledá jen v biblických překladech, které máte nainstalované.
- Chcete-li přeskočit na konkrétní verš podle odkazu (například `John 3:16`), použijte místo záložky Hledat pole **Příkaz** na domovské obrazovce.

## Historie hledání

Aplikace si pamatuje vaše nejnovější hledání. Když otevřete záložku **Hledat**, seznam nahoře ukazuje vaše nedávné hledání. Klepnutím na jedno ho spustíte znovu. Seznam vymažete klepnutím na **Vymazat vše** nahoře u nedávného hledání.

## Hledání v PDF

Záložka Hledat umí hledat i uvnitř vašich PDF dokumentů:

1. Klepněte na záložku **Hledat**, potom nahoře na režim **PDF**.
2. Zvolte, která PDF se mají hledat. Klepnutím na PDF ho zahrnete nebo vynecháte; **Vše** nebo **Vymazat** nad seznamem zahrne vše, nebo začne znovu. Vybrat lze jen PDF, jejichž hledatelný text je nainstalován.
3. Napište, co chcete najít, a klepněte na **Hledat**.

Každý výsledek ukazuje název PDF, číslo stránky a úryvek odpovídajícího textu. Klepnutím na výsledek otevřete to PDF na té stránce.

Chcete-li hledat v jednom PDF během čtení, použijte místo toho tlačítko **Hledat** v čtečce PDF — viz [PDF](theodia://help/pdfs).
