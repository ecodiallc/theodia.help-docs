---
title: Režim Studium
level: everyday
categories: [layout, read]
summary: Plná čtečka Bible v Theodii, plná studijních nástrojů, jako komentář, křížové odkazy, lexikon a poznámky.
---

# Režim Studium

> **Režim:** Režim Studium je dostupný v režimu **Standard** a **Badatel**. Režim Čtenář místo toho otevírá kapitoly v režimu Soustředění. Režim můžete přepnout v **Nastavení** → **Režim aplikace**.

Režim Studium je hlavní čtečka Bible v Theodii. Má všechny studijní nástroje vestavěné: komentář, křížové odkazy, vyhledávání slov, paralelní překlady, poznámky a víc.

Režim Soustředění je jednodušší čtečka bez studijních nástrojů. Pokud chcete jen čistý text, podívejte se na průvodce [Režim Soustředění](theodia://help/focus-mode). Tento průvodce je pro režim Studium.

## Jak otevřít režim Studium

Kapitolu v režimu Studium lze otevřít několika způsoby:

- Klepněte na záložku **Bible** dole na obrazovce. Vyberte překlad, knihu a kapitolu.
- Klepněte na verš ve výsledcích **Hledání**.
- Klepněte na záložku ze záložky **Záložky**.
- Z režimu Soustředění klepněte na tlačítko 📖 nahoře na obrazovce a přepněte do režimu Studium.

## Čtení kapitoly

Kapitola se otevře s verši vypsanými v pořadí. Nahoře na obrazovce jsou tlačítka pro nejčastější akce. Dole na obrazovce je stavová lišta.

- **Přejeďte doleva** na další kapitolu.
- **Přejeďte doprava** na předchozí kapitolu.
- **Klepněte na verš** a otevřete nabídku verše se studijními nástroji (viz níže).
- **Klepněte na Strongovo číslo ve verši** (například G1234 nebo H1234) a otevřete rychlé vyhledání v lexikonu pro to slovo.

Pokud máte zapnutý paralelní překlad, pod hlavním se objeví druhá kopie kapitoly, v překladu, který jste si zvolili. Viz **Čtení dvou překladů najednou** níže.

## Nabídka verše

Když klepnete na verš, otevře se nabídka s názvem „Kniha Kapitola:Verš“. Nástroje, které vidíte, závisí na vašem uživatelském režimu.

### Nástroje v režimu Standard a Badatel

- **Záložka** (★) — uložte verš, abyste ho mohli znovu najít. Znovu klepnutím záložku odeberete. První klepnutí ji přidá. Viz průvodce [Ukládání veršů do záložek](theodia://help/bookmarks).
- **Zvýraznit** (□) — obarvěte verš, aby vynikl. Klepnutím otevřete volič barev. Znovu klepnutím na tutéž barvu zvýraznění odeberete. Viz průvodce [Zvýrazňování veršů](theodia://help/highlights).
- **Říkej** (🔊) — nechte verš přečíst nahlas hlasem převodu textu na řeč vašeho zařízení. U interlineárních Biblí se nezobrazuje. Viz průvodce [Čtení nahlas](theodia://help/tts), jak ho používat a jak zvolit hlas.
- **Kopírovat** (⎘) — vložte text verše do schránky, abyste ho mohli vložit kamkoli.
- **Porovnat** (⇄) — otevřete panel ukazující stejný verš v každém nainstalovaném překladu. Klepnutím na překlad v panelu si verš přečtete v tom překladu. Viz průvodce [Porovnávání překladů](theodia://help/compare-translations).
- **Křížové odkazy** (↗) — otevřete seznam souvisejících veršů z databáze křížových odkazů. Viz průvodce [Křížové odkazy](theodia://help/cross-references).
- **Přidat/upravit poznámku k Bibli** (✎) — napište vlastní soukromou poznámku připojenou k verši. Viz průvodce [Psání poznámek](theodia://help/notes).

### Nástroje jen v režimu Badatel

- **AI komentář** (◈) — požádejte AI asistenta, aby napsal studijní poznámku k tomuto verši. (Není dostupný ve všech regionech.)
- **Info o slově** (?) — otevřete položku lexikonu pro původní hebrejské nebo řecké slovo za veršem. Viz průvodce [Komentáře a lexikony](theodia://help/commentaries-and-lexicons).
- **Slovník** (📖) — vyhledejte obecná biblická slova v nainstalovaných slovních zdrojích. Viz průvodce [Biblický slovník](theodia://help/dictionary).

Některé nástroje potřebují nainstalované extra zdroje. Pokud je nástroj zašedlý nebo ukazuje „nenalezeno“, otevřete **Nastavení** → **Spravovat zdroje** a přidejte zdroj, který potřebuje.

## Tlačítka nahoře na obrazovce

Nad textem kapitoly je řada ikon. Tohle jsou rychlé akce:

- **Verze Bible** — klepnutím na název překladu (například „KJV“) přepnete na jiný překlad.
- **Kniha** — klepnutím na název knihy přeskočíte na jinou knihu.
- **Kapitola** — klepnutím na číslo kapitoly přeskočíte na jinou kapitolu.
- **Otevřít v AI** (🤖) — pošlete aktuální kapitolu AI asistentovi s vaší otázkou. (Jen režim Badatel.)
- **Režim Soustředění** (📖) — přepněte do režimu Soustředění pro čisté čtení.
- **Paralelní Bible** (🔵 / ⚪) — klepnutím zapnete nebo vypnete paralelní překlady. Když je zapnuto, stejná kapitola se ukáže ve vašich zvolených paralelních překladech pod hlavním textem. Když je vypnuto, ukazuje se jen hlavní překlad. Viz **Čtení více překladů najednou** níže.
- **Poslouchej** — nechte celou kapitolu přečíst nahlas. Viz průvodce [Čtení nahlas](theodia://help/tts).
- **Víc** — otevřete extra akce kapitoly (kapitola biblická poznámka, komentář kapitoly, sdílení a tak dále).

## Čtení více překladů najednou

Vedle hlavního překladu můžete ukázat až čtyři další překlady. Tohle se jmenuje **paralelní zobrazení**.

1. Otevřete **Nastavení**.
2. Zapněte **Paralelní Bible**.
3. Klepněte na **Přidat paralelní Bibli** a vyberte překlad.
4. Opakujte a přidejte víc. Můžete mít až čtyři paralelní překlady.

Když je paralelní zobrazení zapnuté, každý verš v kapitole ukazuje nejdřív váš hlavní překlad, následovaný stejným veršem v každém paralelním překladu. Tak se snadno porovná, jak různí překladatelé zacházejí s těžkým veršem, aniž byste kapitolu opustili.

Aktuální paralelní nastavení si můžete uložit jako **předvolbu**. Klepněte na tlačítko uložení vedle vybraných překladů, dejte jí název a stane se rychlou volbou přepnutí. Později klepněte na jakoukoli předvolbu a okamžitě načtete tu kombinaci. Dlouhým stiskem na předvolbu ji smažete.

Jediný verš najednou můžete porovnat i nástrojem **Porovnat** (⇄) v nabídce verše. Otevře panel ukazující verš v každém nainstalovaném překladu.

## Podnadpisy

Některé překlady mají vestavěné nadpisy sekcí (například „Kázání na hoře“). Pokud je váš překlad má, můžete je ukázat nebo skrýt nastavením **Ukázat podnadpisy** v **Nastavení**. Podnadpisy se objevují jako malé šedé názvy mezi verši.

## Poznámka ke kapitole

Poznámka ke kapitole je jediná poznámka připojená k celé kapitole, nikoli k jedinému verši. Hodí se pro jednu velkou myšlenku o kapitole.

Otevření poznámky ke kapitole:

1. Klepněte na tlačítko **Víc** nahoře na obrazovce.
2. Klepněte na **Poznámka ke kapitole**.
3. Napište poznámku. Klepněte na **Uložit**.

Poznámka ke kapitole se ukládá s kapitolou. Objevuje se pokaždé, když tu kapitolu otevřete.

## Zvýraznění hledání

Pokud jste do kapitoly přišli z hledání, vaše hledaná slova jsou zvýrazněná žlutě v textu verše. Tak snadno vidíte, proč verš seděl.

Hledání na kapitole, kterou čtete, můžete spustit znovu. Otevřete záložku **Hledat** a zadejte slovo. Výsledky vám umožní klepnout rovnou zpět do kapitoly se zvýrazněnými shodami.

Interlineární Bible (MIB — Marvel Interlinear Bible — a OHGB) se vždy otevírají v režimu Studium, protože potřebují rozvržení po úrovní slov.

## Přepnutí do režimu Soustředění pro jednu kapitolu

Z jakékoli kapitoly v režimu Studium klepněte nahoře na tlačítko 📖. Tatáž kapitola se otevře v režimu Soustředění se všemi nabídkami skrytými. Klepněte na tlačítko 📖 v dolní liště a přepněte zpět do režimu Studium.

## Kdy režim Studium použít

Režim Studium je správná volba, když chcete:

- **Číst a studovat zároveň.** Všechny nástroje jsou jedno klepnutí daleko.
- **Vyhledat slovo, které neznáte.** Klepněte na Strongovo číslo ve verši pro rychlou položku lexikonu.
- **Porovnat překlady.** Použijte nástroj Porovnat v nabídce verše nebo zapněte paralelní zobrazení.
- **Vidět, jak verš souvisí se zbytkem Bible.** Použijte Křížové odkazy.
- **Dělat si poznámky při čtení.** Nabídka verše má rychlou volbu „Přidat poznámku“.

Pro dlouhé čtení bez rozptylování přepněte do režimu Soustředění.

## Přepnutí do režimu Soustředění

Z jakékoli kapitoly v režimu Studium klepněte nahoře na tlačítko 📖. Tatáž kapitola se otevře v [režimu Soustředění](theodia://help/focus-mode) se skrytými nabídkami a studijními nástroji. Klepněte na tlačítko 📖 v dolní liště a přepněte zpět do režimu Studium. Kompletní popis toho, co režim Soustředění dělá, najdete v průvodci [Režim Soustředění](theodia://help/focus-mode).

## Nápověda a otázky

Pokud nástroj chybí nebo ukazuje chybu, podívejte se na průvodce [Časté problémy](theodia://help/common-problems). Pokud jste v Theodii noví, průvodce [Čtení první kapitoly](theodia://help/first-read) vás krok za krokem provede základy.
