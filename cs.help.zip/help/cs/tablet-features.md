---
title: Funkce tabletu
level: everyday
categories: [layout, tablet]
summary: Jak se rozvržení Theodie přizpůsobuje tabletům a větším obrazovkám, se split zobrazeními, bočními panely a dvoupanelovými režimy čtení.
---

# 📱 Funkce tabletu

Theodia je navržená tak, aby využila větší obrazovky tabletů. Na tabletu (nebo jakémkoli zařízení širším než zhruba 700 pixelů) aplikace na mnoha místech automaticky přepne na dvousloupcové rozvržení.

> **Režim:** Funkce popsané tady se objeví jen tehdy, pokud je váš aktuální uživatelský režim podporuje. Například boční panely komentářů a AI chat jsou dostupné jen v režimu Badatel. Split zobrazení záložek, zvýraznění a poznámek vyžadují režim Standard nebo Badatel. Režim Soustředění ukazuje jen čisté jednosloupcové čtení. Režim přepnete v **Nastavení** → **Režim aplikace**.

## Nabídka verše v čtečce

Když klepnete na číslo verše (nebo dlouze stisknete text verše), **nabídka verše** se objeví jako **vycentrovaná karta** nad tmavým pozadím.

- Tlačítka **Kopírovat** a **Sdílet** jsou vždy viditelná nahoře v nabídce.
- **Záložky** a **Zvýraznění** jsou ukázány se svým aktuálním stavem.
- **Komentář**, **Slovník** a **Porovnat** se otevírají z nabídky. Na tabletu se tyhle nástroje po zvolení mohou objevit v bočním panelu nebo široké kartě.
- Klepnutím na pozadí nebo na zavírací šipku nabídku zrušíte.

## Panel komentáře verše

Nástroj **Komentář** otevírá na tabletu **vyhrazený boční panel**:

- Text komentáře se objeví vedle biblického textu.
- Komentář můžete posouvat nezávisle na Bibli.
- Klepnutím na **X** nebo přejezdem pryč se zavře.
- **Ikona knihy** nahoře na panelu vám umožní přepínat zdroje komentářů.
- **Ikona kapitoly** umožní zobrazit komentář na úrovni kapitoly.

Na telefonu se komentář otevírá jako modální okno na celou obrazovku.

## Komentář ke kapitole

**Komentář ke kapitole** se otevírá z tlačítka **Víc** nahoře na obrazovce, nikoli z nabídky verše. Na tabletu se otevírá jako boční panel stejně jako komentář verše, takže komentář a biblický text čtete spolu.

## Záložka Porovnat

Záložka **Porovnat** (v nabídce verše) se na tabletu otevírá jako **boční panel**. Ukazuje zvolený verš v každé paralelní verzi, kterou máte povolenou. Klepnutím na jakoukoli verzi přeskočíte na to místo v čtečce.

## Závit Slovník / Strongovo číslo

Nástroj **Slovník** (nabídka verše → Slovník) se na tabletu otevírá jako široká karta. Ukazuje řecké nebo hebrejské slovo, jeho transliteraci, definici a Strongovo číslo. Klepnutím na tlačítko **Konkordance** uvidíte každý výskyt toho slova v Bibli.

## Klepněte na slovo a otevřete lexikon

V bočním panelu **Info o slově** na tabletu je každá karta slova, která má Strongovo číslo, klepnutelná. Klepněte na kartu a otevřete panel **Lexikon** pro to slovo rovnou. Panel Lexikon nahradí panel Info o slově, takže můžete dál studovat bez zavření čtečky.

Na telefonu karty Info o slově klepnutelné nejsou, protože obrazovka je pro dva panely příliš malá.

## Paralelní Bible vedle sebe

V Nastavení klepněte na **Paralelní Bible** a vyberte až tři verze. Na tabletu se verze objeví jako **svislé panely** vedle sebe:

- Každý panel se posouvá nezávisle.
- Klepnutím na číslo verše otevřete boční panel s nástroji.
- Záložka **Porovnat** ukazuje všechny zvolené verše na jednom místě.
- Klepnutím na **X** na jakémkoli panelu ho zavřete a vrátíte se k jednosloupcovému zobrazení.
- Klepnutím na ikonu **Paralelní Bible** (🔵 / ⚪) na horní liště ikon přepnete paralelní zobrazení zapnuto/vypnuto, aniž byste otevřeli Nastavení.

Na telefonu se paralelní verze ukazují jedna po druhé (svisle) místo vedle sebe. Tatáž ikona přepínače funguje i na telefonech.

## Split zobrazení záložek a zvýraznění

Na tabletu používají záložky **Záložky** a **Zvýraznění** rozvržení seznam-detail:

- **Levá strana** — seznam záložek nebo zvýraznění.
- **Pravá strana** — klepnutím na položku se otevře panel náhledu s textem verše nebo místa.

Položky si můžete projít a zobrazit náhled, aniž byste opustili záložku. Na telefonu klepnutí na položku naviguje na obrazovku čtečky.

## Split zobrazení poznámek

Záložka **Poznámky** na tabletu ukazuje váš seznam poznámek vlevo a zvolenou poznámku vpravo. Klepnutím na poznámku se otevře v bočním panelu, takže si můžete projít několik poznámek za sebou, aniž byste opustili seznam. Vytváření nebo úprava poznámky používá také boční panel.

## Split zobrazení hledání

Na tabletu záložka **Hledat** ukazuje vyhledávací formulář vlevo a výsledky vpravo, jakmile hledání spustíte. Dotaz si můžete upřesnit a sledovat aktualizaci výsledků bez změny obrazovky. Na telefonu se výsledky hledání otevírají na samostatné obrazovce.

## Boční lišta kategorií nastavení

Obrazovka **Nastavení** na tabletu ukazuje vlevo seznam kategorií (AI, Vzhled, Záloha, Bible atd.). Klepnutím na kategorii přejdete přímo na její nastavení vpravo. Rozbalená je jen zvolená kategorie, takže nikdy nemusíte posouvat celý seznam nastavení.

## Navigace Bible na tabletech

Obrazovky **Seznam Biblí**, **Biblické knihy** a **Biblické kapitoly** zůstávají na tabletech jednosloupcové, ale používají větší dotykové cíle, širší mřížky a prostornější odsazení, takže obsah se snáz čte a klepá. Nepoužívají split rozvržení, protože každý krok potřebuje plnou šířku, aby svůj seznam nebo mřížku ukázal jasně.

## Na šířku a na výšku

Otočení tabletu upraví rozvržení automaticky. Na **šířku** mají boční panely dost místa. Na **výšku** se panely zúží, ale zůstávají vedle textu.

## AI chat ke zvolenému verši

**AI** chat se otevírá v bočním panelu nabídky verše. Ukazuje konverzační rozhraní, kde můžete pokládat otázky ke zvolenému verši. Odpověď AI se objeví v panelu a konverzaci můžete pokračovat, aniž byste opustili čtečku.

## Boční lišta konverzací na obrazovce AI

Na záložce **AI** na tabletu je seznam konverzací vždy viditelný jako trvalá levá boční lišta. Mezi chaty můžete přepínat bez otevírání nabídky. Tlačítko **Nový chat** je také vždy viditelné. Na telefonu je seznam konverzací vysouvací zásuvka.

## Co zůstává stejné

Ne každá obrazovka se rozděluje na dva panely. Tyhle obrazovky zůstávají na tabletech jednosloupcové:

- **Seznam Biblí** — seznam biblických verzí (plná šířka)
- **Biblické knihy** — mřížka knih a sekce (plná šířka)
- **Biblické kapitoly** — mřížka kapitol (plná šířka)
- **PDF** — knihovna PDF používá širší mřížku karet (plná šířka)
- **Nastavení** — jednotlivé stránky nastavení (plná šířka)
- **Nápověda** — články nápovědy (plná šířka)

## Shrnutí

Na tabletu dostanete:

- **Paralelní Bible** v svislých panelech vedle sebe
- **Komentář** v trvalých bočních panelech
- **Porovnat** a **Slovník** v širokých kartách
- **Lexikon** z klepnutí na jakoukoli kartu Info o slově
- **Záložky, Zvýraznění, Poznámky, Bohoslužebná čtení, Knihy, Nastavení** v split zobrazení seznam-detail
- **Hledat** s výsledky inline vedle vyhledávacího formuláře
- **Na šířku** i **na výšku** podporováno s automatickými změnami rozvržení

Na telefonu všechno používá tradiční jednosloupcovou navigaci postupným proklikáváním. Aplikace při spuštění rozpozná šířku obrazovky a automaticky zvolí správné rozvržení.
