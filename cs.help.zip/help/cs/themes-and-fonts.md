---
title: Změna témat a písem
level: everyday
categories: settings
summary: Jak změnit vzhled aplikace.
---

# Změna témat a písem

Theodia vám umožní změnit, jak aplikace vypadá. Můžete si vybrat téma (světlé nebo tmavé) a velikost písma.

## Jak otevřít nastavení vzhledu

1. Otevřete **Nastavení**.
2. Klepněte na **Vzhled**.

## Jak změnit téma

V sekci **Vzhled** uvidíte dvě tlačítka témat:

- **Výchozí** — světlé pozadí s tmavým textem. Dobré na den.
- **Tmavé** — tmavé pozadí se světlým textem. Dobré na noc a šetří baterii.

Klepněte na téma a použije se. Změna je okamžitá.

## Jak změnit velikost písma

V sekci **Vzhled** klepněte na jedno z tlačítek velikosti: **---**, **--**, **-**, **Normální**, **+**, **++**, **+++**. Text se v celé aplikaci zmenší nebo zvětší. Zvolte velikost, která se vám čte nejsnazší.

## Tipy

- Tmavé téma šetří baterii na telefonech s OLED obrazovkami.
- Pokud je text příliš malý na čtení, zvětšete velikost písma v aplikaci, ne v zařízení. Nastavení aplikace je jemnější.
- Pro dlouhé čtení vyzkoušejte tmavé téma a větší písmo.
- [Aktivovat téma pouště](theodia://unlock-desert)
