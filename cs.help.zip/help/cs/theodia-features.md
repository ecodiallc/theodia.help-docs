---
title: Funkce Theodie
level: beginner
categories: welcome
summary: Rychlý přehled toho, co dělá Theodii výjimečnou a jak vám pomáhá studovat Bibli.
---

# Funkce Theodie

Theodia je postavená jako kompletní průvodce studiem Bible. Tohle je to, čím vyčnívá.

## Offline na prvním místě

Všechno funguje bez internetu. Bible, komentáře, lexikony, knihy a bohoslužebná čtení jsou uložena na vašem zařízení. Můžete číst, hledat a studovat kdekoli — v letadle, v odlehlé oblasti, nebo na jakémkoli místě bez signálu.

## Zaměření na soukromí

Vaše data zůstávají u vás. Poznámky, zvýraznění, záložky a historie čtení se ukládají lokálně na vašem zařízení. Není potřeba žádný účet a na server se nic neposílá, pokud si nevyberete používat volitelného AI asistenta.

## Podpora tabletů

Theodia je navržená pro telefony i tablety. Na větší obrazovce dostanete více místa ke čtení, paralelní zobrazení Bible a rozvržení, které využije ten extra prostor.

## Instalovatelné zdroje

Nejste omezeni tím, co aplikace přichází. Můžete přidat víc verzí Bible, komentářů, lexikonů, knih a bohoslužebných čtení. Zdroje jsou dostupné na GitHub stránce projektu a lze je instalovat přímo do aplikace.

## AI asistent

Volitelný AI asistent vám pomůže porozumět veršům, vysvětlit kontext a odpovědět na otázky. Je aktivní jen tehdy, když ho zapnete. Ve výchozím stavu se připojuje ke vzdálenému modelu, který dodáte přes koncový bod a API klíč, který nastavíte. Při prvním použití AI aplikace požádá o váš souhlas a přesně ukáže, co se odesílá.

## Paralelní čtení Bible

Čtěte až čtyři verze Bible najednou. Když otevřete kapitolu, váš hlavní překlad se objeví první a každý verš je následován stejným veršem ve vašich zvolených paralelních překladech. Porovnávejte formulace, studujte rozdíly a získejte plnější obraz textu. Uložte si oblíbené kombinace jako předvolby a rychle mezi nimi přepínejte.

## Fulltextové hledání

Hledejte napříč libovolnou verzí Bible. Hledejte slova, fráze nebo částečné shody. Hledání můžete omezit i na rozsah knih.

## Křížové odkazy

Klepněte na odkaz verše a rovnou přeskočíte na to místo. Křížové odkazy jsou vestavěné a fungují napříč celou Biblí.

## Lexikon a Strongova čísla

Klepněte na Strongovo číslo a uvidíte původní řeckou nebo hebrejskou definici. Položky lexikonu jsou zahrnuty pro hlubší studium slov.

## Záložky a zvýraznění

Uložte verše do záložek a označte je barvami. Všechno je uloženo lokálně a přetrvává mezi sezeními.

## Poznámky

Pište vlastní myšlenky vedle jakéhokoli verše. Poznámky jsou vázané na verš a snadno se později najdou.

## Denní bohoslužebné čtení

Začněte den krátkým bohoslužebným čtením. Aplikace obsahuje bohoslužebná čtení, která se automaticky otevřou na dnešní položku.

## Křesťanské knihy

Čtěte klasickou křesťanskou literaturu uvnitř aplikace. Knihy jsou naformátované pro snadné čtení a mají obsah pro rychlou navigaci.

## Čtení PDF

Importujte vlastní PDF dokumenty a čtěte je offline, uspořádané do kategorií. Čtečka podporuje hledání, obsah, záložky, přiblížení a čtení nahlas. Z komunitního repozitáře si můžete nainstalovat i zabaleny sbírky PDF.

## Více jazyků

Theodia podporuje mnoho jazyků pro rozhraní aplikace i biblický obsah. V nastavení přepněte jazyk a studujte ve svém preferovaném jazyce.

## Tmavý režim a témata

Vyberte si světlý nebo tmavý režim, nebo zvolte téma, které vám vyhovuje. Pohodlí čtení záleží, zvlášť při slabém světle.

## Záloha dat

Zálohujte své poznámky, záložky a zvýraznění. Udržujte svá data v bezpečí a podle potřeby je přeneste na nové zařízení.

## Žádné reklamy, žádné rozptylování

Theodia je postavená pro soustředění. Nejsou tu žádné reklamy, žádné vyskakovací okna, žádné přerušení. Jen text a vaše studijní nástroje.
