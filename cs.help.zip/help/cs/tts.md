---
title: Čtení nahlas (převod textu na řeč)
level: everyday
categories: tts
summary: Nechte Theodii přečíst Bibli nebo bohoslužebné čtení nahlas. Jak to použít, jak zvolit hlas a co dělat, když je ticho.
---

# Čtení nahlas (převod textu na řeč)

> **Režim:** Převod textu na řeč je dostupný v režimu **Standard** a **Badatel**. Režim Soustředění je jen pro čisté čtení bez rozptylování. Režim můžete přepnout v **Nastavení** → **Režim aplikace**.

Theodia umí číst text nahlas pomocí hlasu převodu textu na řeč (TTS) vašeho zařízení. Můžete poslouchat jediný verš, celou kapitolu nebo bohoslužebné čtení. Hodí se to pro čtení bez rukou, poslech při chůzi nebo cestování, čtení s audiem, nebo prostě když chcete odpočinout oči.

## Kde je tlačítko poslechu

Tlačítko poslechu najdete na třech místech.

### 1. V nabídce verše (jediný verš)

Tohle je nejrychlejší způsob, jak poslouchat po jednom verši. Otevřete kapitolu v [režimu Studium](theodia://help/study-mode), klepněte na verš a otevřete nabídku verše, potom klepněte na **Říkej** (🔊). Čtení začne od toho verše. Dole na obrazovce se objeví malá ovládací lišta s přehráváním, pauzou, přetočením, přetočením vpřed a voličem hlasu.

Volba Říkej se nezobrazuje u interlineárních Biblí (MIB — Marvel Interlinear Bible — a OHGB), protože ty zobrazují slova v jiném rozvržení, které se nepřečte přirozeně.

### 2. Nahoře nad kapitolou (celá kapitola)

Když čtete kapitolu, podívejte se na řadu ikon nahoře na obrazovce. Klepněte na **Poslouchej** (🔊) a spustí se čtení celé kapitoly od začátku. Během přehrávání audia se tlačítko změní na stop tlačítko (⏹). Klepnutím znovu zastavíte. Dole se objeví tatáž ovládací lišta.

Můžete přeskočit na jiný verš a tlačítko Poslouchej u něj začne od toho verše.

### 3. V bohoslužebném čtení

Otevřete libovolný den bohoslužebného čtení a klepněte na tlačítko **Poslouchej** (🔊) nahoře nad čtením. Celý text bohoslužebného čtení se přečte nahlas, věta po větě. Ovládací lišta dole nabízí přehrávání, pauzu, přetočení a ovládání hlasu.

## Používání ovládací lišty

Během přehrávání audia zůstává dole na obrazovce viditelná malá lišta. Má šest ovládacích prvků:

- ⏪ **Přetočit** — vraťte se o jeden verš zpět (nebo o jednu větu u bohoslužebného čtení)
- ⏸ **Pauza / ▶ Pokračovat** — pauza bez ztráty místa. Klepnutím znovu pokračujete od téhož místa.
- ⏩ **Přetočit vpřed** — přeskočí na další verš (nebo další větu u bohoslužebného čtení)
- 🎙 **Hlas** — otevřete volič hlasu, aniž byste opustili kapitolu (viz níže)
- ⚙ **Volby** — otevřete rozšířený panel voleb (viz níže)
- **Zastavit** — klepněte na tlačítko 🔊 nahoře na obrazovce, nebo na ⏹, které ho během přehrávání nahrazuje, a zastavíte a zavřete lištu.

Ovládací lišta se zavře, když kapitola skončí, nebo když klepnete na stop.

### Rozšířené volby

Klepnutím na ⚙ rozbalíte extra volby přehrávání. Tyhle volby platí jen pro aktuální kapitolu a resetují se při přepnutí kapitoly nebo zastavení poslechu.

- ⏮ **Na začátek** — přeskočí na první verš zvoleného rozsahu.
- **Začátek** — napište číslo verše, kde má čtení začít.
- **Konec** — napište číslo verše, kde má čtení skončit.
- **Vše** — resetuje rozsah na celou kapitolu.
- **()** — přepne, zda se text v závorkách (text uvnitř závorek) čte nahlas.
- 🔁 **Opakovat** — automaticky začne znovu od začátku rozsahu, když se dojde na konec, s krátkou pauzou mezi tím. Pokud toto zapnete bez nastaveného začátečního nebo koncového verše, opakuje se celá kapitola.

### Na modlitebních obrazovkách

Vyznání a pevné modlitby, generované modlitby a modlitební rutiny mají vlastní sadu rozšířených voleb. Klepnutím na ⚙ v ovládací liště je rozbalíte:

- **Rychlost** — klepněte na rychlost (například `1x`) a zvolte rychlost čtení od 0.1x do 1.5x. Vaše volba se zapamatuje a použije při dalším předčítání.
- **()** — přepne, zda se text v závorkách (text uvnitř závorek) čte nahlas.
- 🔁 **Opakovat** — automaticky začne modlitbu znovu od začátku, když skončí, s krátkou pauzou mezi tím. Hodí se to pro učení vyznání nebo pevné modlitby nazpaměť.

Změna rychlosti se projeví okamžitě, bez ztráty místa. Zapnutí nebo vypnutí volby závorek modlitbu spustí znovu od začátku, aby se změna slyšela od začátku.

## Jak změnit hlas

Můžete zvolit, který hlas Theodia pro čtení použije. Hodí se to, když chcete jiný přízvuk, jiný jazyk, nebo rychlejší či pomalejší hlas než výchozí hlas zařízení.

1. Otevřete **Nastavení**.
2. Najděte sekci **Řeč**.
3. Klepněte na **Zvolit hlas**.
4. Objeví se seznam hlasů. První řádek, **Systémový výchozí**, používá hlas, který vaše zařízení preferuje. Zvolte jakýkoli jiný řádek a stane se novým výchozím.
5. Vaše volba se uloží a použije při dalším klepnutí na **Poslouchej** nebo **Říkej**.

Můžete také klepnout na ikonu 🎙 v ovládací liště poslechu a otevřít tentýž volič, aniž byste opustili kapitolu.

Dostupnost hlasů závisí zcela na vašem zařízení. iOS i Android se dodávají se sadou vestavěných hlasů. Další hlasy můžete nainstalovat z nastavení **Zpřístupnění** nebo **Jazyk a vstup** vašeho zařízení. Theodia může použít jakýkoli hlas nainstalovaný na vašem zařízení.

## Oblíbené hlasy

Pokud má vaše zařízení mnoho hlasů, může být procházení celého seznamu pokaždé zdlouhavé. Můžete si vytvořit krátký seznam **oblíbených hlasů** a voliče hlasů budou ukazovat jen ty.

1. Otevřete **Nastavení**.
2. Najděte sekci **Řeč**.
3. Klepněte na **Oblíbené hlasy** (první řádek nahoře v sekci).
4. Klepněte na **Nastavit oblíbené hlasy** a otevřete obrazovku oblíbených.
5. Klepnutím na tlačítko přehrání vedle hlasu si ho poslechnete. Klepnutím na hvězdičku ho přidáte do oblíbených. Oblíbených hlasů můžete mít, kolik chcete.
6. Vraťte se zpět. Voliče hlasů v celé Theodii teď ukazují jen vaše oblíbené hlasy.

Pokud všechny oblíbené odstraníte, voliče se vrátí ke zobrazování všech hlasů. Oblíbené hlasy se zahrnují do zálohy a obnovení nastavení Theodie.

## Jiný hlas pro každou Bibli

Každému překladu Bible můžete dát vlastní hlas. Hodí se to, když přecházíte mezi překlady, které zní velmi rozdílně — například formálnější hlas pro King James Version a konverzačnější hlas pro moderní překlad jako NIV nebo NLT. Pomáhá to také, když posloucháte Biblie v různých jazycích a chcete, aby se každá četla ve správném přízvuku.

1. Otevřete **Nastavení**.
2. Najděte sekci **Řeč**.
3. Najděte **Hlasy Biblí**.
4. Klepněte na jakoukoli Bibli v seznamu.
5. Zvolte hlas, který chcete pro ten překlad. První řádek, **Systémový výchozí**, používá pro tu Bibli váš hlavní hlas TTS.
6. Opakujte pro další Biblie.

Záhlaví ukazuje, kolik překladů Bible má nastavený vlastní hlas. **Zvolit hlas**, **Hlas komentáře**, **Hlas biblických poznámek** a **Hlas bohoslužebných čtení** také ukazují počet, když je hlas nastavený.

Když příště posloucháte kapitolu z té Biblie, Theodia použije hlas, který jste zvolili. Všechny ostatní Biblie dál používají hlavní výchozí hlas, pokud je nezměníte také.

## Pokračování řeči na pozadí

Ve výchozím stavu Theodia zastaví řeč, když opustíte obrazovku čtečky, přepnete do jiné aplikace, nebo zamknete telefon. Tím se zamezí nečekanému audiu, když už aktivně nečtete.

Aby řeč pokračovala na pozadí:

1. Otevřete **Nastavení**.
2. Najděte sekci **Řeč**.
3. Zapněte **Pokračovat v řeči na pozadí**.

Když je to zapnuté, můžete přepínat záložky, otevřít jinou aplikaci nebo zamknout obrazovku a kapitola nebo bohoslužebné čtení bude dál číst. Ovládací lišta zůstává aktivní, takže můžete pozastavit nebo přeskočit z oblasti oznámení (pokud to vaše zařízení podporuje).

Vypnutí tohoto přepínače, zatímco řeč už hraje, ji okamžitě zastaví.

## Co dělat, když to nefunguje

Převod textu na řeč závisí na vašem zařízení. Theodia pošle text operačnímu systému a operační systém ho přečte nahlas pomocí hlasu. Pokud to nefunguje, zkuste tyhle kroky v pořadí.

### Theodia říká, že TTS není dostupné

Některá zařízení nemají TTS vůbec. Otevřete **Nastavení** a hledejte sekci **TTS**. Pokud tam není, vaše zařízení nepodporuje TTS v tomto sestavení.

### Seznam hlasů je prázdný

Volič hlasů může ukazovat „žádné hlasy nenalezeny“. To obvykle znamená, že zařízení ještě nedokončilo načítání svých hlasů.

1. Otevřete **Nastavení → Řeč → Zvolit hlas**.
2. Pokud je seznam prázdný, najděte těsně pod rozbalovacím seznamem tlačítko **Retest**. Klepněte na něj. Theodia se znovu zeptá zařízení na hlasy.
3. Pokud je to pořád prázdné, zkontrolujte systémová nastavení zařízení. Na iOS přejděte do **Nastavení → Zpřístupnění → Mluvený obsah → Hlasy** a stáhněte hlas pro svůj jazyk. Na Androidu přejděte do **Nastavení → Jazyk a vstup → Výstup převodu textu na řeč** a klepněte na **Instalovat hlasová data**.
4. Zavřete a znovu otevřete Theodii, aby si nový hlas všimla.

Pokud máte nastavené oblíbené hlasy a seznam je prázdný, ujistěte se, že aspoň jeden z vašich oblíbených odpovídá hlasu nainstalovanému na tomto zařízení.

### Klepnu na Říkej a nic se nestane

- Zkontrolujte, že zařízení není v tichém režimu. Většina zařízení nepřehraje TTS audio v tichém režimu.
- Ujistěte se, že je hlasitost zařízení zvednutá.
- Zkuste tlačítko **Retest** v **Nastavení → Řeč**.
- Otevřete **Nastavení** a podívejte se na sekci **Systém** dole. Řádek **TTS** má říkat **Dostupné**. Pokud říká **Nedostupné**, TTS je vypnuté na úrovni operačního systému. Tam ho znovu zapněte a potom znovu otevřete Theodii.

### Audio hraje, ale ve špatném jazyce

Theodia posílá text v jazyce aktuálního obsahu a žádá zařízení o hlas, který jste zvolili. Pokud zvolený hlas je pro jiný jazyk, zařízení text možná přečte stejně, ale bude to znít divně.

1. Otevřete **Nastavení → Řeč → Zvolit hlas**.
2. Zvolte **Systémový výchozí**, ať zařízení zvolí správný, nebo zvolte hlas, jehož jazyk odpovídá textu, který čtete.

Theodia teď ještě nečte řecké ani hebrejské interlineární Biblie nahlas. Tlačítka Říkej a Poslouchej se u těch překladů skrývají.

### Audio hraje, ale skončí dřív

Pokud verš chybí nebo se nedá přečíst, kapitola přeskočí na další. Pokud se lišta sama zavře po několika verších, klepněte na tlačítko **Poslouchej** (🔊) nahoře na obrazovce a začněte znovu.

### Řeč hraje, ale nevím, kde začala

Pokud jste zapnuli **Pokračovat v řeči na pozadí** a později slyšíte audio, ale nemůžete najít obrazovku, která ho spustila, můžete ho zastavit odkudkoli v aplikaci.

1. Otevřete **Nastavení**.
2. Najděte sekci **Řeč**.
3. Klepněte na červené tlačítko **Zastavit řeč** dole v sekci.

Tím se okamžitě zastaví jakékoli běžící předčítání v Theodii. Můžete také otevřít přepínač aplikací na vašem zařízení a Theodii odsvihnout pryč, čímž audio vynuceně zastavíte.

### Čte to příliš rychle nebo pomalu

Theodia rychlost čtení neovlivňuje. Rychlost určuje zvolený hlas. Chcete-li ji změnit:

- Na iOS: **Nastavení → Zpřístupnění → Mluvený obsah → Tempo řeči**.
- Na Androidu: **Nastavení → Jazyk a vstup → Výstup převodu textu na řeč → Rychlost řeči**.

## Tipy

- Ovládací lišta zůstává viditelná, když přecházíte mezi kapitolami, takže můžete pozastavit, přeskočit nebo změnit hlas, aniž byste ztratili místo.
- Theodia čte čísla veršů jako malé pauzy. Můžete zastavit lištu, přejet na jiný verš a klepnutím na přehrání pokračovat od něj.
- Na dlouhý poslech zapněte **Nerušit**, aby oznámení nepřerušila audio.
- Tlačítko 🔊 používá aktuální hlasitost zařízení. Pokud zapojíte sluchátka, hlasitost se přepne na úroveň sluchátek.

## Předčítání PDF nahlas

Theodia umí číst i stránky PDF nahlas. Otevřete PDF a klepněte na tlačítko **Poslouchej** (reproduktor) v jeho panelu nástrojů. Objeví se ovládací lišta s přehrání/pauzou, přetočením, přetočením vpřed, stopením, ukazatelem postupu a voliči rychlosti a hlasu. Když stránka skončí, čtení automaticky pokračuje na další stránce.

Čtení PDF používá nainstalovaný prohledávatelný text PDF a tytéž hlasy a rychlost jako čtení Bible.

## Související průvodci

- Průvodce [Režim Studium](theodia://help/study-mode) podrobněji popisuje nabídku verše a tlačítka nahoře na obrazovce.
- Průvodce [Režim Soustředění](theodia://help/focus-mode) je čistější zobrazení čtení, které také podporuje TTS tlačítkem 🔊 v dolní liště.
- Průvodce [Časté problémy](theodia://help/common-problems) má opravy pro další problémy s audiem, hlasem a jazykem.
- Průvodce [Denní bohoslužebné čtení](theodia://help/daily-devotionals) popisuje čtení bohoslužebných čtení a to, kde je na té obrazovce tlačítko poslechu.
- Průvodce [PDF](theodia://help/pdfs) popisuje čtečku PDF a její tlačítko poslechu.
