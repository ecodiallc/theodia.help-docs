---
title: Vítejte v Theodii
level: beginner
categories: welcome
summary: Krátká prohlídka aplikace a to, co pro vás umí.
---

# Vítejte v Theodii

Theodia je aplikace pro studium Bible. Běží na vašem telefonu nebo tabletu, i když nemáte internet. Všechno, co čtete, hledáte a studujete, se ukládá na vaše zařízení.

## Co můžete dělat

Theodia má tři uživatelské režimy. Každý režim ukazuje jinou sadu funkcí.

- **Čtenář** — čtěte Bibli v čistém zobrazení bez rozptylování.
- **Standard** — všechno z Čtenáře, plus záložky, zvýraznění, poznámky, převod textu na řeč, hledání a denní bohoslužebná čtení.
- **Badatel** — všechno ze Standardu, plus komentáře, lexikony, Biblický slovník, AI asistenta a víc.

Režimy můžete přepínat kdykoli v **Nastavení** → **Režim aplikace**.

### Funkce, které máte k dispozici

Bez ohledu na zvolený režim můžete vždy:

- **Číst Bibli.** Vyberte si z mnoha překladů. Přepínejte mezi nimi kdykoli.
- **Hledat v Bibli.** Hledejte slovo nebo frázi. Aplikace ukáže každý verš, který odpovídá.
- **Číst knihy a bohoslužebná čtení.** Aplikace přichází s křesťanskými klasikami a denním bohoslužebným čtením.

Podle režimu můžete navíc:

- **Poslouchat.** Nechte verše přečíst nahlas funkcí předčítání. (Standard a Badatel.)
- **Dělat si poznámky.** Napište vlastní myšlenky vedle verše. (Standard a Badatel.)
- **Zvýrazňovat.** Označte oblíbené verše barvami. (Standard a Badatel.)
- **Vkládat záložky.** Uložte verše, abyste je rychle našli znovu. (Standard a Badatel.)
- **Zeptat se AI asistenta.** Získejte pomoc s porozuměním verši. (Jen Badatel.)

## Kde začít

1. Otevřete záložku **Bible** dole na obrazovce.
2. Zvolte překlad.
3. Klepněte na jakoukoli knihu a začněte číst.

Chcete-li se dozvědět víc, ostatní průvodci nápovědou jsou tu pro vás. Zvolte téma ze seznamu na domovské stránce nápovědy.

## Několik věcí, které vědět

- Účet nepotřebujete.
- Vaše poznámky, zvýraznění a záložky zůstávají na vašem zařízení.
- Můžete je zálohovat. Jak na to, viz průvodce [Záloha vašich dat](theodia://help/backups).

## Chcete víc zdrojů?

Aplikace přichází s několika volně dostupnými verzemi Bible. Další Biblie, komentáře, lexikony, knihy a bohoslužebná čtení najdete v průvodci [Získávání extra zdrojů z GitHub](theodia://help/getting-core-files). Ukazuje, jak najít a přidat víc zdrojů z GitHub stránky projektu.

Vítejte. Doufáme, že vám Theodia pomůže číst a studovat.
