---
title: Co jsou zdroje?
level: beginner
categories: resources
summary: Přehled různých druhů souborů, které Theodia používá — Biblie, komentáře, knihy a víc.
---

# Co jsou zdroje?

V Theodii je „zdroj“ jakýkoli soubor, který přidává do aplikace čtecí nebo studijní materiál. Samotná aplikace je jen čtečka a sešit. Biblie, komentáře, knihy a ostatní materiály, se kterými studujete, jsou všechny samostatné soubory, které načtete.

Tento průvodce vysvětluje různé druhy zdrojů a k čemu každý slouží.

## Proč na tom záleží?

Když poprvé otevřete Theodii, už má co číst. Jak zkoumáte, uvidíte tlačítka k instalování dalšího. Znalost toho, co který druh zdroje je, vám pomůže rozhodnout, co přidat.

## Různé druhy zdrojů

Theodia poznává soubory podle přípony. Každá přípona je jiný druh zdroje.

### `.bible` — překlad Bible

Překlad Bible je kompletní kopie Bible v konkrétní verzi, jako King James Version. Theodia přichází s několika překlady a dovolí vám přidat víc.

Podrobnosti viz průvodce [Instalování překladů Bible](theodia://help/installing-bibles).

### `.commentary` — komentář

Komentář je kniha studijních poznámek napsaná biblickým badatelem. U daného verše komentář říká pozadí, význam a jak verš zapadá do zbytku Bible.

Podrobnosti viz průvodce [Komentáře a lexikony](theodia://help/commentaries-and-lexicons).

### `.lexicon` — lexikon

Lexikon je slovník biblických slov. Říká původní hebrejské nebo řecké slovo, co znamená a jak se v Bibli používá.

Podrobnosti viz průvodce [Komentáře a lexikony](theodia://help/commentaries-and-lexicons).

### `.book` — křesťanská kniha

Kniha je delší křesťanské dílo, jako klasika z dějin církve. Čtení knih v aplikaci funguje hodně podobně jako čtení Bible. Theodia přichází s malou knihovnou volně dostupných křesťanských klasik.

Podrobnosti viz průvodce [Čtení vestavěných knih](theodia://help/reading-books).

### `.devotional` — bohoslužebné čtení

Bohoslužebné čtení je krátké denní čtení. Každá položka má obvykle verš, krátkou reflexi a modlitbu nebo otázku k zamyšlení. Mnohá bohoslužebná čtení jsou navržená tak, aby se četla jedna položka denně po celý rok.

Podrobnosti viz průvodce [Denní bohoslužebné čtení](theodia://help/daily-devotionals).

### `.sqlite` — referenční databáze

Referenční databáze je velký vyhledávací soubor, který aplikace používá, aby vám při čtení dávala extra informace. Existují dva druhy:

- **Křížové odkazy** — seznamy veršů, které se vážou na verš, který čtete.
- **Morfologie** — informace o původních hebrejských nebo řeckých slovech ve verši.

Tyto soubory přímo neotevíráte. Pracují na pozadí a přidávají funkce čtečce Bible. Podrobnosti viz průvodce [Křížové odkazy](theodia://help/cross-references).

### `.data` — data slov

Soubor dat slov obsahuje extra informace o původních biblických slovech. Používá ho lexikon a studijní nástroje. Stejně jako referenční databáze se přímo neotevírá. Aplikace ho používá na pozadí.

## Jak přidat zdroj

Obrazovka **Spravovat zdroje** v aplikaci je snadný způsob, jak zdroj přidat.

1. Otevřete **Nastavení**.
2. Klepněte na **Spravovat zdroje**.
3. Klepněte na **Instalovat z GitHub**.
4. V modálním okně stahování zvolte záložku — **Biblie**, **Komentáře**, **Knihy**, **Bohoslužebná čtení** nebo **Core** — potom zvolte, co chcete, a klepněte na **Instalovat zvolené**.
5. Nebo klepněte na **Instalovat lokální soubor** a importujte soubor, který už máte stažený.

Podrobný postup získávání souborů přímo z GitHub viz průvodce [Získávání extra zdrojů z GitHub](theodia://help/getting-core-files).

## Jak odstranit zdroj

1. Otevřete **Nastavení**.
2. Klepněte na **Spravovat zdroje**.
3. Najděte zdroj, který chcete odstranit.
4. Klepněte na ikonu koše vedle něj.
5. Potvrďte, že ho chcete odstranit.

Odstranění zdroje nesmaže vaše poznámky, zvýraznění ani záložky. Ty zůstávají v bezpečí.

## Kde zdroje žijí na vašem zařízení

Zdroje se ukládají na vaše zařízení, ne do cloudu. Jakmile je zdroj nainstalovaný, nepotřebujete k jeho čtení internet. Zařízení můžete zálohovat, ale samotné zdroje Theodia do cloudu nezálohuje. Pokud aplikaci odinstalujete a nainstalujete znovu, budete muset znovu přidat všechny zdroje, které jste měli nainstalované.

## Nápověda a otázky

Pokud máte potíže, podívejte se na průvodce [Kde klást otázky](theodia://help/getting-more-help). Tým a komunita pomůžou.
