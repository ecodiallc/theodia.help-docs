---
title: AI-basics
level: advanced
categories: ai
summary: Sådan bruger du AI-hjælperen til at forstå vers.
---

# AI-basics

> **Tilstand:** AI-assistenten kræver **Forsker**-tilstand. Du kan skifte tilstand i **Indstillinger** → **App-brugertilstand**.

Theodia har en AI-assistent. Den kan hjælpe dig med at forstå et vers, besvare et spørgsmål eller tale om et bibelsk emne.

## Sådan tænder du for AI

AI er slukket som standard. Sådan tænder du for den:

1. Åbn **Indstillinger**.
2. Tryk på **AI-assistent**.
3. Tryk på kontakten for at slå den til.

## Sådan åbner du AI

Tryk på fanen **AI** nederst på skærmen. Der åbnes et chatvindue.

## Sådan stiller du et spørgsmål

Tryk på feltet nederst. Skriv dit spørgsmål. Tryk på **Send**.

Nogle ting, du kan spørge om:

- "Hvad betyder Johannes 3,16?"
- "Fortæl mig om Romerbrevet."
- "Hvad er Åndens frugt?"
- "Sammenlign Bjergprædikenen i Matthæus og Lukas."

## Sådan spørger du om et bestemt vers

1. Åbn et kapitel.
2. Tryk på et vers for at få versmenuen frem.
3. Tryk på **AI-kommentar**.

Verset sendes til AI'en. AI-panelet åbner med verset allerede udfyldt. Du kan tilføje et spørgsmål, f.eks. "Hvad betyder det?" eller "Hvordan kan jeg bruge det?"

## Vigtige ting at vide

- AI'en er et værktøj, ikke et menneske. Den kan tage fejl.
- Tjek altid AI'ens svar mod Bibelen selv.
- AI'en kan have brug for internettet. Den virker ikke offline.
- Når du bruger AI'en, sendes dine spørgsmål, verskontekst og din API-nøgle til det endpoint, du vælger. Første gang du gør dette, beder appen om din tilladelse og viser præcis, hvad der sendes. Du kan senere ændre eller tilbagekalde den tilladelse i **Indstillinger → AI-assistent → Deling af AI-data med fjernserver**.
- Nogle regioner, f.eks. App Store-versionen i Fastlands-Kina, tilbyder ikke AI-assistenten. I den version er kun offline Bibel-funktioner tilgængelige.

## Sådan administrerer du samtaler

AI-skærmen gemmer en liste over tidligere samtaler. Fra listen kan du åbne en gammel samtale, starte en ny eller slette en, du ikke længere har brug for.

## Gå dybere med AI

Denne side dækker det grundlæggende. Theodias AI kan langt mere end at chatte. Her er, hvor du skal gå hen nu:

- **[AI-funktioner](theodia://help/ai-features)** — Oplev alt, hvad Theofilus kan: versstudium med ét tryk på græsk og hebraisk, krydshenvisningskæder, prædispositioner, bønnegenerering, morfologi i originalsproget, ordbogsopslag og appnavigation uden hænder. Dette er guiden, der viser dig, hvordan du forvandler AI'en fra en chatbot til en fuld studiepartner.
- **[Skriv bedre AI-prompts](theodia://help/ai-prompts)** — Lær kunsten at stille spørgsmål, der giver rige og præcise svar. Et par justeringer af, hvordan du formulerer din forespørgsel, kan give markant dybere svar fra AI'en.
- **[Vælg en AI-model](theodia://help/choosing-a-model)** — Ikke alle AI-modeller er ens. Find ud af, hvilke modeller der understøtter Theodias indbyggede værktøjer (f.eks. at åbne vers og søge i Skriften), og hvilke der gør AI'en til en sand bibelstudieassistent uden hænder.
- **[GitHub Models](theodia://help/github-models)** — Den anbefalede gratis udbyder til Theodia. Få en gratis API-nøgle med en GitHub-konto og begynd at stille spørgsmål på en generøs daglige kvote. Intet kreditkort, intet abonnement.
- **[API-nøgler og omkostninger](theodia://help/ai-keys-and-costs)** — Forstå, hvordan API-prissætning fungerer på tværs af udbydere, og hvordan du holder omkostningerne tæt på nul.
