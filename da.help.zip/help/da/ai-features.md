---
title: AI-funktioner
categories: ai
level: advanced
summary: Oplev alt, hvad Theodias AI kan — fra vers-for-vers-studium til prædikeforberedelse, udforskning af originalsproget og navigation uden hænder.
---

# AI-funktioner

> **Tilstand:** AI-assistenten kræver **Forsker**-tilstand. Du kan skifte tilstand i **Indstillinger** → **App-brugertilstand**.

Theodias AI-assistent, Theofilus, er ikke bare en chatbot. Det er en studiepartner, der kan læse Bibelen sammen med dig, slå kommentarer op, søge i Skriften, administrere dine noter og endda navigere i appen — alt sammen med stemme eller tekst.

Før Theofilus sender data til et AI-endpoint for første gang, viser appen en samtykkebesked, der forklarer, hvad der sendes, og beder om din tilladelse. Du kan når som helst ændre eller tilbagekalde den tilladelse i **Indstillinger → AI-assistent → Deling af AI-data med fjernserver**.

## AI-verschat: Studér ét vers grundigt

**AI-verschatten** er kernen i Theodias AI-oplevelse. Mens du læser et kapitel, trykker du på et versnummer (eller holder verset inde længe) og vælger **AI-kommentar**. Der åbnes et chatpanel med det vers allerede indlæst. AI'en ved præcis, hvad du læser, og er klar til at udforske det sammen med dig.

### Startere med ét tryk

Ikke sikker på, hvad du skal spørge om? Panelet viser otte øjeblikkelige startere:

- **Forklar dette vers** — Få en klar og gennemtænkt gennemgang af betydning og betydningens vægt.
- **Originalsprog** — Se de græske eller hebraiske ord, transskriptioner og leksikalske definitioner bag den engelske tekst.
- **Historisk kontekst** — Lær om kulturen, politikken og begivenhederne omkring verset.
- **Tekstlig kontekst** — Se, hvordan verset passer ind i afsnittet, kapitlet og bogen omkring det.
- **Hovedtemaer** — Opdag de store tanker, dette vers bidrager med til den bibelske teologi.
- **Anvend på mit liv** — Få praktiske, personlige anvendelser, du kan handle på i dag.
- **Generer en bøn** — Gør verset til en bøn, der er modelleret over dets sprog og sandheder.
- **Generer en prædisposition** — Få en disposition med tre punkter, indledning og afslutning, klar til at prædike.

Tryk på en af startene, og AI'en går straks i gang. Du kan komme med egne opfølgende spørgsmål, bede om en uddybning eller styre samtalen i en ny retning.

### Opfølgning som i en rigtig samtale

AI'en husker de sidste beskeder i chatten, så du kan grave dybere naturligt:

- "Kan du sige det mere enkelt?"
- "Hvad siger originalgræsk her?"
- "Vis mig krydshenvisninger, der knytter sig hertil."
- "Sammenlign dette vers i tre forskellige oversættelser."
- "Hvordan ville det se ud på en moderne arbejdsplads?"
- "Giv mig tre flere anvendelser for en forælder."

Samtalen bliver knyttet til verset, så alle svar er forankret i teksten, du læser.

### Tryk på enhver Bibelhenvisning

Når AI'en nævner et andet vers — f.eks. "Dette spejler Romerne 8,28" — vises henvisningen som et **link, du kan trykke på**. Tryk på den, og appen hopper til det sted i Bibel-læseren. Du kan udforske kæden af henvisninger uden at forlade samtalen.

## Hvad AI'en kan ud over verschat

Theofilus har adgang til hele indholdet af Theodia — Bibler, kommentarer, leksika, ordbøger, bøger, andagter, dine noter, bogmærker og fremhævninger. Her er, hvad det betyder i praksis.

### Læs og navigér i Skriften

- **Læs ethvert vers eller kapitel** — "Læs Johannes 3,16 i WEB" eller "Læs Salme 23 op."
- **Åbn passager i læseren** — "Tag mig til 1. Mosebog 1" eller "Åbn Romerne 8,28."
- **Sammenlign versioner** — "Vis mig Johannes 3,16 i alle mine Bibler."
- **Søg i Bibelen** — "Find vers om tilgivelse" eller "Søg efter 'fred, der overgår al forstand'."
- **Få krydshenvisninger** — "Hvilke andre vers knytter sig til Esajas 53,5?"
- **Læs afsnitsoverskrifter** — "Hvad er underoverskrifterne i Matthæus 5?"

### Udforsk originalsprogene

- **Leksikon-opslag** — "Hvad betyder det græske ord 'agape' i Johannes 3,16?" eller "Slå Strongs G26 op."
- **Morfologi** — "Analysér de græske verber i Romerne 8,28" eller "Hvad betyder morfologikoden V-PAI-3S?"
- **Ordinfo** — AI'en kan se den samme ord-for-ord-gennemgang, som du ser i appen — transskription, oversættelse, grammatik og Strongs numre.

### Læs kommentarer og studiebøger

- **Verskommentar** — "Hvad siger Matthew Henry om Efeserne 2,8?"
- **Kapitelkommentar** — "Giv mig kapiteloversigten for Romerne 8."
- **Bogkommentar** — "Opsummér kommentaren på bogniveau om Åbenbaringen."
- **Studiebøger** — "Læs et kapitel fra Hymn Lyrics English for mig" eller "Søg i mine bøger efter 'tålmodighed'."
- **Andagter** — "Læs dagens andagt" eller "Find en andagt om angst."

### Søg i ordbøger

- "Hvem var Melkisedek?"
- "Hvad siger Bibel-ordbogen om Gilgal?"
- "Slå 'forsoning' op i Easton's."

### Administrér dit studieliv

AI'en kan arbejde med dine personlige data — altid gemt lokalt på din enhed:

- **Bogmærker** — "Sæt bogmærke på dette vers i min mappe Prædikeforberedelse" eller "Vis mine bogmærker."
- **Fremhævninger** — "Fremhæv Johannes 3,16 i gult" eller "Vis alle mine fremhævninger."
- **Noter** — "Opret en Bibel-note på dette vers" eller "Læs mine noter til 1. Mosebog 1."
- **Studienoter** — "Gem denne samtale som en studienote" eller "Opret en ny studienotebog kaldet Romerbrevsstudie."
- **Mapper** — "Opret en mappe kaldet Morgandagt" eller "Flyt mit Johannes 3,16-bogmærke til mappen Bøn."

### Skift appindstillinger

- "Skift til mørk tilstand."
- "Gør BSB til min standardbibel."
- "Slå parallelle Bibler til med NET."
- "Forøg skriftstørrelsen."

### Læs op

- "Læs Salme 23 op" — AI'en kan aktivere tekst-til-tale for enhver passagen, bog eller note.
- "Hold op med at læse" — Sæt TTS på pause når som helst.

## Gem dine samtaler

Enhver AI-verschat kan gemmes. Tryk på menuen i chatpanelet og vælg:

- **Gem som Bibel-note** — Tilføjer hele samtalen til versnoten i Bibel-læseren.
- **Gem som studienote** — Gemmer samtalen i din Studienoter-bog til senere brug.

Det omdanner en hurtig AI-udforskning til permanent studiemateriale, du kan vende tilbage til, redigere eller bygge prædikener ud fra.

## Hele AI-fanen

Ud over verschatpanelet har Theodia en dedikeret **AI**-fane i bundnavigationen. Det er en fri chat, hvor du kan spørge om hvad som helst — intet vers er forvalgt. Brug den til:

- Tematiske studier på tværs af hele Bibelen
- Prædikeundersøgelse og dispositioner
- Sammenligning af teologiske temaer mellem bøger
- Daglig andagt og bønneprompts
- Bibel-quizzer og læseplaner
- Apphjælp — "Hvordan virker parallelle Bibler?"

Dine samtaler gemmes automatisk. Du kan vende tilbage til tidligere chats, starte nye og slette gamle tråde.

## Idéer til at komme i gang

Her er nogle spændende måder at bruge AI'en på. Vælg én og prøv den i dag.

**Personlig vækst**

- "Forklar Filipperne 4,6–7, og giv mig en bøn til, når jeg føler mig ængstelig."
- "Hvad siger Bibelen om hvile? Find fem vers til mig og forklar hvert af dem."

**Familie og forældreskab**

- "Hvordan bør Efeserne 6,4 vejlede moderne forældreskab? Giv mig tre praktiske regler."
- "Find vers om at opdrage børn, og læs dem op for mig."

**Prædike- og undervisningsforberedelse**

- "Lav en disposition til en 25-minutters prædiken om Romerne 8,28 med en indledning, tre punkter og en afslutning."
- "Hvad siger mine kommentarer om 'Guds rustning' i Efeserne 6?"
- "Sammenlign Bjergprædikenen i Matthæus med Lukas' version. Hvad er forskellene?"

**Studium af originalsprogene**

- "Vis mig morfologien for hvert ord i Johannes 1,1."
- "Hvad er forskellen på 'agape' og 'philia' i Det Nye Testamente?"

**Andagt-dybde**

- "Læs dagens andagt, og forbind den til et vers i Salmerne."
- "Giv mig en syv-dages andagtsdisposition om Åndens frugt."

**Krydshenvisningskæder**

- "Start med Esajas 53,5 og spor temaet 'sår' og 'helbredelse' gennem Det Nye Testamente."
- "Hvor optræder begrebet 'pagt' fra 1. Mosebog til Hebræerbrevet?"

**Hukommelse og gentagelse**

- "Quiz mig om Bibelens bøger i rækkefølge."
- "Opret en studienote, der opsummerer hovedpointen i hvert kapitel i Romerbrevet."

## Et par vigtige bemærkninger

- AI'en er et **værktøj**, ikke en erstatning for Bibelen eller sjælesorg. Sammenlign altid dens svar med Skriften selv.
- Når du bruger AI'en, rejser dine spørgsmål over internettet til udbyderens servere. De fleste udbydere træner ikke på dine data, men teksten forlader din enhed.
- AI'en kan tage fejl. Brug kommentarer, leksika og selve Bibelteksten som din endelige autoritet.

## Opsummering

Theodias AI er designet til at gøre bibelstudium hurtigere, dybere og mere personligt. Uanset om du vil have en sætnings forklaring på et forvirrende vers, en fuld prædisposition, et græsk ordstudie eller en krydshenvisningskæde, der spænder over hele Bibelen, er Theofilus klar til at hjælpe. Tryk på et vers, stil et spørgsmål, og se, hvor samtalen fører hen.
