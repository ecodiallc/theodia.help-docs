---
title: API-nøgler og omkostninger
level: advanced
categories: ai
summary: Hvorfor du skal bruge en API-nøgle, hvordan du får én, og hvad en fjern AI-model typisk koster.
---

# API-nøgler og omkostninger

> **Tilstand:** AI-assistenten kræver **Forsker**-tilstand. Du kan skifte tilstand i **Indstillinger** → **App-brugertilstand**.

AI-assistenten forbinder til fjerne AI-modeller. Hvis du vil bruge én, skal du bruge en API-nøgle. Denne side forklarer hvorfor, hvordan du får én, og hvad det normalt koster.

## Hvorfor du skal bruge en API-nøgle

En fjern AI-model bor på en server på internettet. API-nøglen er som en adgangskode, der fortæller serveren: "Denne person må stille spørgsmål." Uden den svarer serveren ikke.

Appen leverer ikke en indbygget nøgle. Du skal oprette din egen konto hos en udbyder og indsætte din nøgle i appen.

## Sådan får du en API-nøgle

1. Åbn **Indstillinger** i Theodia.
2. Tryk på **AI-assistent**.
3. Vælg **Fjern model**.
4. Vælg en udbyder fra listen, eller vælg **Brugerdefineret** og indtast en basis-URL.
5. Tryk på linket til udbyderens nøgleside. Opret en konto, hvis du ikke har én.
6. Generér en ny API-nøgle på udbyderens websted.
7. Kopiér nøglen og indsæt den i Theodia.
8. Tryk på **Test forbindelse** for at sikre, at det virker.

## Understøttede udbydere

Theodia kan forbinde til enhver udbyder, der bruger en OpenAI-kompatibel API. Her er dem med forudindstillede links i appen:

- **GitHub Models** — github.com/marketplace/models (gratis daglig kvote, anbefalet)
- **OpenAI** — platform.openai.com
- **OpenRouter** — openrouter.ai
- **Anthropic** — console.anthropic.com
- **Groq** — console.groq.com
- **Mistral** — console.mistral.ai
- **Together AI** — api.together.xyz

Du kan også bruge en **brugerdefineret** basis-URL, hvis du kører din egen server eller bruger en anden tjeneste.

## Hvad koster det?

De fleste udbybere opkræver betaling pr. **token**. En token er omtrent et ord eller en del af et ord. Du betaler for de tokens, du sender (dit spørgsmål), plus de tokens, AI'en sender tilbage (svaret).

### Typiske priser

Priserne ændrer sig, men her er et fingerpeg pr. midten af 2026:

- **Små hurtige modeller** (f.eks. billigere endepunkter i GPT-3.5-klassen) koster en brøkdel af en cent pr. tusind tokens.
- **Modeller i mellemklassen** (f.eks. GPT-4o eller Claude Sonnet) koster typisk nogle få cent pr. tusind tokens.
- **Store ræsonnementmodeller** (f.eks. GPT-4.5 eller Claude Opus) kan koste ti til tyve cent pr. tusind tokens.

Et typisk Bibel-spørgsmål i Theodia kan bruge et par hundrede til et par tusind tokens i alt. Det betyder, at de fleste spørgsmål koster fra **under en cent til nogle få cent**.

### Tips til at holde omkostningerne nede

- Start med en billigere model. De fleste Bibel-spørgsmål behøver ikke den dyreste model.
- Brug Groq eller OpenRouter, hvis du vil prøve forskellige modeller og sammenligne priser.
- Hold øje med dit forbrugspanel på udbyderens websted.

## GitHub Models

[GitHub Models](https://github.com/marketplace/models) tilbyder en gratis kvote uden abonnement. Alt, du behøver, er en gratis GitHub-konto og en personlig adgangstoken med tilladelse til at læse modeller.

**Sådan sætter du det op:**

1. Gå til [github.com/settings/tokens](https://github.com/settings/tokens) og opret en **Personal access token (classic)**.
2. Giv den `models:read`-omfanget (eller vælg blot modelltilladelsen).
3. I Theodia vælger du **GitHub Models** som udbyder og indsætter din token.

**Modeller i gratis-kvoten:**

- `openai/gpt-4.1-nano` — **15 forespørgsler pr. minut, 150 forespørgsler pr. dag**
- `openai/gpt-4.1-mini` — **15 forespørgsler pr. minut, 150 forespørgsler pr. dag**
- `openai/gpt-4.1` — **10 forespørgsler pr. minut, 50 forespørgsler pr. dag**
- `openai/gpt-4o` — **10 forespørgsler pr. minut, 50 forespørgsler pr. dag**

Disse grænser nulstilles dagligt og er rigeligt til almindeligt bibelstudium.

Se den dedikerede [GitHub Models](theodia://help/github-models)-guide for en fuld trin-for-trin-gennemgang med skærmbilleder.

## Om privatliv

Når du bruger en fjern AI-model, viser appen først en samtykkebesked, der forklarer, hvad der sendes: dine beskeder, vers- eller kapitelkontekst, værktøjskald og resultater, det konfigurerede modelnavn og din API-nøgle i anmodningens header. Anmodningen går direkte til det endpoint, du har konfigureret, ikke gennem Theodia. De fleste udbybere bruger ikke dine data til at træne deres modeller, men teksten forlader din enhed. Du kan når som helst ændre eller tilbagekalde tilladelsen i **Indstillinger → AI-assistent → Deling af AI-data med fjernserver**.

## Opsummering

- Du skal bruge en API-nøgle for at bruge AI-assistenten.
- Opret en konto hos en udbyder, generér en nøgle, og indsæt den i Theodia.
- De fleste spørgsmål koster nogle få cent eller mindre.
