---
title: AI-assistenten
level: advanced
category: ai
summary: Sådan bruger du AI-hjælperen til at forstå vers.
---

# AI-assistenten

Theodia har en AI-assistent. Den kan hjælpe dig med at forstå et vers, besvare et spørgsmål eller tale om et bibelsk emne.

## Sådan tænder du for AI

AI er slukket som standard. Sådan tænder du for den:

1. Åbn **Indstillinger**.
2. Tryk på **AI-assistent**.
3. Tryk på kontakten for at slå den til.

Du skal muligvis oprette en konto eller en nøgle. Appen vejleder dig.

## Sådan åbner du AI

Tryk på fanen **AI** nederst på skærmen. Der åbnes et chatvindue.

## Sådan stiller du et spørgsmål

Tryk på feltet nederst. Skriv dit spørgsmål. Tryk på **Send**.

Nogle ting, du kan spørge om:

- "Hvad betyder Johannes 3,16?"
- "Fortæl mig om Romerbrevet."
- "Hvad er Åndens frugt?"
- "Sammenlign Bjergprædikenen i Matthæus og Lukas."

## Sådan spørger du om et bestemt vers

1. Åbn et kapitel.
2. Tryk på et vers for at få versmenuen frem.
3. Tryk på **AI-kommentar**.

Verset sendes til AI'en. AI-panelet åbner med verset allerede udfyldt. Du kan tilføje et spørgsmål, f.eks. "Hvad betyder det?" eller "Hvordan kan jeg bruge det?"

## Vigtige ting at vide

- AI'en er et værktøj, ikke et menneske. Den kan tage fejl.
- Tjek altid AI'ens svar mod Bibelen selv.
- AI'en kan have brug for internettet. Den virker ikke offline.
- Når du bruger AI'en, sendes dine spørgsmål, verskontekst og din API-nøgle til det endpoint, du vælger. Første gang du gør dette, beder appen om din tilladelse og viser præcis, hvad der sendes. Du kan senere ændre eller tilbagekalde den tilladelse i **Indstillinger → AI-assistent → Deling af AI-data med fjernserver**.
- Nogle regioner, f.eks. App Store-versionen i Fastlands-Kina, tilbyder ikke AI-assistenten. I den version er kun offline Bibel-funktioner tilgængelige.

## Sådan administrerer du samtaler

AI-skærmen gemmer en liste over tidligere samtaler. Fra listen kan du åbne en gammel samtale, starte en ny eller slette en, du ikke længere har brug for.

Se guiden [Skriv bedre AI-prompts](theodia://help/ai-prompts) for mere avancerede tips.
