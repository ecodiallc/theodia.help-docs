---
title: Skriv bedre AI-prompts
level: advanced
categories: ai
summary: Sådan spørger du AI-assistenten på en måde, der giver gode svar.
---

# Skriv bedre AI-prompts

> **Tilstand:** AI-assistenten kræver **Forsker**-tilstand. Du kan skifte tilstand i **Indstillinger** → **App-brugertilstand**.

En "prompt" er det spørgsmål eller den instruktion, du giver AI'en. Bedre prompts giver bedre svar. Denne guide viser dig hvordan.

## Vær konkret

Dårligt: "Fortæl mig om kærlighed."
Bedre: "I 1. Korinther 13, hvilken slags kærlighed beskriver Paulus, og hvordan adskiller den sig fra romantisk kærlighed?"

Jo flere detaljer du giver, desto mere nyttigt er svaret.

## Giv kontekst

Dårligt: "Hvad betyder dette vers?"
Bedre: "Jeg læser Romerbrevet 8 med en lille gruppe. Hvad betyder 'ingen fordømmelse' i dette kapitel, og hvordan knytter det sig til resten af kapitlet?"

Kontekst hjælper AI'en med at tilpasse sit svar til din situation.

## Spørg om én ting ad gangen

Dårligt: "Fortæl mig om bøn, tro og helbredelse."
Bedre: "Fortæl mig først om bøn. Bagefter spørger jeg om tro."

At spørge om én ting ad gangen holder svarene fokuserede.

## Bed AI'en om at tage en rolle

Du kan bede AI'en svare i en bestemt tone. For eksempel:

- "Svar, som om du underviste en ny kristen."
- "Svar som en bibelforsker."
- "Svar til en 10-årig."

AI'en tilpasser sit svaret til rollen.

## Brug opfølgende spørgsmål

Hvis det første svar ikke helt er rigtigt, så stil et opfølgende spørgsmål:

- "Kan du sige det mere enkelt?"
- "Kan du give mig et eksempel?"
- "Hvad siger originalgræsk?"
- "Hvor andre steder i Bibelen optræder det?"

En god samtale er en frem og tilbage. AI'en husker de sidste beskeder.

## Tjek AI'ens svar

AI'en kan tage fejl. Det er et værktøj, ikke en lærer.

- Sammenlign AI'ens svar med de vers, den henviser til.
- Brug kommentarerne og leksikaene i appen som en anden mening.
- Hvis svaret handler om lære, så spørg en præst eller en betroet ven.

## Almindelige prompt-mønstre

Her er nogle, der virker godt:

- "Forklar dette vers til mig, som om jeg er en ny kristen."
- "Hvad er hovedpointen i dette kapitel i én sætning?"
- "Nævn tre anvendelser til min hverdag fra denne passagen."
- "Hvilke spørgsmål bør jeg stille til dette vers, før jeg prædiker over det?"
