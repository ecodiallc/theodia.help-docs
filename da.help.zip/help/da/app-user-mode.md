---
title: App-brugertilstand
level: beginner
categories: [user-mode]
summary: Vælg mellem Læser-, Standard- og Forsker-tilstand for at styre, hvilke funktioner der er tilgængelige i appen.
---

# App-brugertilstand

Theodia tilbyder tre brugertilstande, der styrer, hvilke funktioner du ser. Vælg den, der passer til, hvordan du vil bruge appen.

## Læser

Den enkleste tilstand. Læser-tilstand er til bibel læsning uden afbrydelser.

- Læs enhver Bibeloversættelse
- Brug Fokustilstand til ren læsning i fuldskærm
- Navigér i bøger og kapitler
- Ingen studieværktøjer, ingen AI, ingen bogmærker, ingen fremhævninger

Læser-tilstand er ideel, hvis du vil have Theodia til at føles som en ren digital Bibel uden noget ekstra.

## Standard

Standard-tilstand tilføjer hverdagsfunktioner til personligt bibelstudium.

Alt fra Læser, plus:

- Bogmærker, fremhævninger og noter
- Tekst-til-tale
- Studietilstand-læser med versmenu
- Parallelle Bibler
- Kommandoinddata
- Søg i Bibelen
- Daglige andagter og indbyggede bøger

Standard-tilstand er det rigtige valg for de fleste brugere, der vil læse, markere og søge i Bibelen uden avancerede studieværktøjer.

## Forsker

Den fuldt udrustede tilstand. Forsker-tilstand låser op for alle værktøjer i Theodia til dybt bibelstudium.

Alt fra Standard, plus:

- Kommentarer og leksika
- Krydshenvisninger
- Bibel-ordbog
- Ordinfo (Strongs-opslag)
- AI-assistent og AI-kommentar
- Launcher-menu

Forsker-tilstand er designet til præster, teologistuderende og alle, der ønsker værktøjer til originalsprogene og AI-drevne studiehjælpemidler.

## Sådan skifter du tilstand

1. Åbn **Indstillinger**.
2. Tryk på **App-brugertilstand**.
3. Vælg **Læser**, **Standard** eller **Forsker**.

Ændringen træder i kraft med det samme. Menuer og knapper, du ikke har adgang til i din nuværende tilstand, skjules.

## Valg af tilstand

- **Læser** — Du vil kun læse Bibelen, intet andet.
- **Standard** — Du vil have bogmærker, fremhævninger, noter, søgning og andagter.
- **Forsker** — Du vil have alle studieværktøjer, inklusive AI, kommentarer og leksika.

Du kan skifte tilstand når som helst. Dine bogmærker, fremhævninger og noter slettes aldrig, når du skifter tilstand; de skjules blot, indtil du vender tilbage til en tilstand, der understøtter dem.
