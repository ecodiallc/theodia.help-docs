---
title: Sikkerhedskopiering af dine data
level: everyday
categories: settings
summary: Sådan gemmer og gendanner du dine noter, fremhævninger, bogmærker og hemmeligheder.
---

# Sikkerhedskopiering af dine data

Dine noter, fremhævninger, bogmærker og indstillinger gemmes på din enhed. Hvis du mister din telefon, får en ny eller afinstallerer appen, kan dataene gå tabt. Denne guide viser dig, hvordan du sikkerhedskopierer dem.

## Sådan åbner du sikkerhedskopi-indstillingerne

1. Åbn **Indstillinger**.
2. Tryk på **App-sikkerhedskopi**.

## Sådan laver du en app-sikkerhedskopi

1. Åbn **Indstillinger**.
2. Tryk på **App-sikkerhedskopi**.
3. Tryk på **Opret app-sikkerhedskopi**.
4. Vælg en mappe på din enhed til at gemme filen. Du kan også vælge en cloud-drev.
5. Appen laver én enkelt fil med alle dine data. Filen ender på `.zip`.

## Hvor ofte du skal lave en sikkerhedskopi

Lav en sikkerhedskopi:

- Når du har skrevet mange noter.
- Før du opdaterer din enheds operativsystem.
- Før du afinstallerer appen eller skifter telefon.

En god vane er én sikkerhedskopi om måneden. Nogle laver sikkerhedskopi hver uge.

## Sådan gendanner du fra en app-sikkerhedskopi

1. Åbn **Indstillinger**.
2. Tryk på **App-sikkerhedskopi**.
3. Tryk på **Gendan fra app-sikkerhedskopi**.
4. Vælg `.zip`-sikkerhedskopifilen.
5. For hver datatype (noter, fremhævninger, bogmærker osv.) skal du vælge, om du vil beholde det, der er på enheden, erstatte det med sikkerhedskopien eller springe det over.
6. Tryk på **Gendan**.

Appen erstatter dine data med dataene i sikkerhedskopien. Det inkluderer:

- Noter
- Fremhævninger
- Bogmærker
- Bogmærkemapper
- Indstillinger (tema, skriftstørrelse, sprog)

## Sikkerhedskopi af hemmeligheder

Din **App-sikkerhedskopi** indholder **ikke** følsomme hemmeligheder som din AI API-nøgle eller GitHub-token. For at sikkerhedskopiere dem separat skal du bruge **Sikkerhedskopi af hemmeligheder**.

### Gem en sikkerhedskopi af hemmeligheder

1. Åbn **Indstillinger**.
2. Tryk på **App-sikkerhedskopi**.
3. Under **Sikkerhedskopi af hemmeligheder** trykker du på **Gem sikkerhedskopi af hemmeligheder**.
4. Indtast en stærk adgangskode og bekræft den.
5. Appen krypterer dine hemmeligheder og deler den krypterede fil. Gem den et sikkert sted.

### Gendan en sikkerhedskopi af hemmeligheder

1. Åbn **Indstillinger**.
2. Tryk på **App-sikkerhedskopi**.
3. Under **Sikkerhedskopi af hemmeligheder** trykker du på **Gendan sikkerhedskopi af hemmeligheder**.
4. Vælg den krypterede sikkerhedskopifil med hemmeligheder.
5. Indtast den samme adgangskode, du brugte, da du gemte den.
6. Dine hemmeligheder er gendannet.

> **Vigtigt:** Hvis du glemmer adgangskoden, kan hemmelighederne ikke gendannes. Der er ingen nulstilling.

## Ting at vide

- En gendannelse **erstatter** de kategorier, du valgte. Alt, hvad du tilføjede efter sikkerhedskopien, går tabt for de kategorier.
- En app-sikkerhedskopi er én enkelt `.zip`-fil. Opbevar den et sikkert sted.
- Du kan kopiere filen, flytte den eller opbevare den i enhver cloud-tjeneste.
- App-sikkerhedskopier indholder ikke selve Bibeloversættelserne. De kan downloades igen fra **Indstillinger** → **Administrer ressourcer**.
- Sikkerhedskopier af hemmeligheder er krypteret med din adgangskode. Vælg en adgangskode, du husker.

## Tip

Hvis du har mere end én enhed, kan du kopiere sikkerhedskopifilen til hver enhed og gendanne den. Dine data bliver ens på begge.
