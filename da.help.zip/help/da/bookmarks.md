---
title: Bogmærkning af vers
level: everyday
categories: [annotate, read]
summary: Sådan gemmer du vers, så du kan finde dem igen.
---

# Bogmærkning af vers

> **Tilstand:** Bogmærker er tilgængelige i **Standard**- og **Forsker**-tilstand. Fokustilstand er kun til ren læsning uden afbrydelser. Du kan skifte tilstand i **Indstillinger** → **App-brugertilstand**.

Et bogmærke gemmer et vers eller et bogkapitel, så du kan finde det igen. Bogmærker er som faneblade i en bog.

## Sådan sætter du bogmærke på et vers

1. Åbn verset.
2. Tryk på verset for at få menuen frem.
3. Tryk på **Bogmærke** i menuen. En stjerneikon markerer verset som gemt.

Et flueben på ikonet betyder, at verset nu har bogmærke.

## Sådan sætter du bogmærke på et bogkapitel

Når du læser en bog (ikke en Bibel), kan du sætte bogmærke på hele kapitlet:

1. Åbn kapitlet.
2. Tryk på **Bogmærke**-ikonet øverst på skærmen.

## Sådan ser du dine bogmærker

Tryk på fanen **Bogmærker** nederst. Du ser en liste over hvert vers og bogkapitel, du har gemt.

## Sådan fjerner du et bogmærke

- **Ét vers:** Åbn verset. Tryk på verset, og tryk derefter på **Bogmærke**-ikonet igen. Fluebenet forsvinder.
- **Fra listen:** I fanen **Bogmærker** holder du et bogmærke inde længe. Der vises en lille menu. Tryk på **Slet**. (Du kan også trykke på den lille ×-knap på rækken.)

## Organisér med mapper

Du kan lægge bogmærker i mapper. For eksempel kan du have en mappe kaldet "Prædikeforberedelse" og en anden kaldet "Opmuntring".

Sådan laver du en mappe:

1. Åbn fanen **Bogmærker**.
2. Tryk på **Administrer mapper** øverst.
3. Tryk på **+ Opret mappe** øverst i mappelisten.
4. Skriv et navn, og tryk på **Gem**.

Du kan ikke oprette to mapper med samme navn. Hvis navnet allerede findes, vises en fejl i boksen til oprettelse af mappe, så du kan ændre det og prøve igen.

Sådan lægger du et bogmærke i en mappe:

1. I fanen **Bogmærker** holder du et bogmærke inde længe.
2. Tryk på **Gem i mappe**.
3. Vælg mappen, og tryk derefter på **Færdig**.

## Import af bogmærker

Du kan bringe bogmærker ind i Theodia fra andre apps og filer.

Gå til **Indstillinger** → **Bogmærker** → **Importér bogmærker**. Vælg **Importér fra fil** eller indsæt fra udklipsholderen. Appen genkender automatisk formatet.

### Understøttede formater

**Indbygget JSON-eksport** — Formatet, der bruges af Theodias egen eksportfunktion. Det bevarer mapper og oprettelsesdatoer.

**Netscape Bookmark HTML** — Formatet, der bruges af Chrome, Firefox og Safari, når du eksporterer bogmærker. Mapper bevares.

**CSV** — Et regneark med kolonner. Appen leder efter `url`- og `folder`-kolonnerne (eller `href` / `category`). Eksempel:

```csv
url,folder
/bible/KJV/John/3,Favorites
/bible/KJV/Genesis/1,Sermon Prep
```

**Almindelig tekst** — Hver linje er enten en Bibelhenvisning, en app-URL eller en mappe-direktiv. Eksempel:

```
folder: Favorites
John 3:16
Genesis 1:1
folder: Sermon Prep
Matthew 5:1
```

- Linjer, der starter med `folder: <name>`, sætter den aktive mappe for alle efterfølgende bogmærker.
- Bibelhenvisninger som `John 3:16` konverteres til bogmærker i din standardbibel.
- App-URL'er som `/bible/KJV/John/3#v3_16` eller `/book/MyBook/1` importeres direkte.
- Linjer, der starter med `#` eller `//`, behandles som kommentarer og springes over.

### Tips til import

- Dublerede bogmærker springes automatisk over.
- Eksterne URL'er (f.eks. BibleGateway-links) konverteres til app-bogmærker, når det er muligt.
- Hvis en mappe fra importfilen allerede findes, lægges bogmærkerne i den eksisterende mappe.

## Tips

- Du kan sætte bogmærke på samme vers i mange oversættelser. De vises alle i listen.
- Bogmærker bliver på din enhed. De synkroniseres ikke til cloud.
- Se guiden [Sikkerhedskopiering af dine data](theodia://help/backups) for at holde dem i sikkerhed.

## Bogmærker i PDF'er

PDF'er har deres egne bogmærker, holdt adskilt fra dine Bibel-bogmærker. Mens du læser en PDF, trykker du på **Bogmærke**-knappen i læserens værktøjslinje for at gemme den aktuelle side, give den et navn og springe tilbage til den senere. Hver PDF har sin egen liste — se [PDF'er](theodia://help/pdfs).
