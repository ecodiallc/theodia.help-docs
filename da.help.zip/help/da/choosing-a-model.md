---
title: Vælg en AI-model
level: advanced
categories: ai
summary: Sådan vælger du en model, der fungerer godt med Theodias indbyggede værktøjer og funktioner.
---

# Vælg en AI-model

> **Tilstand:** AI-assistenten kræver **Forsker**-tilstand. Du kan skifte tilstand i **Indstillinger** → **App-brugertilstand**.

Ikke hver AI-model virker på samme måde i Theodia. Den bedste oplevelse kommer fra en model, der understøtter **værktøjskald** — AI'ens evne til at bruge Theodias indbyggede funktioner som at slå Bibelvers op, søge, læse kommentarer og navigere i appen.

## Hvad er værktøjskald?

Når du stiller Theodias AI et spørgsmål, kan AI'en mere end bare tale. Den kan også **handle**. For eksempel:

- Du siger: "Vis mig Johannes 3,16 i ESV." AI'en kalder et værktøj til at åbne det vers i læseren.
- Du siger: "Hvad siger mine kommentarer om Romerne 8,28?" AI'en kalder et værktøj til at hente kommentarindhold.
- Du siger: "Gem dette vers som et bogmærke." AI'en kalder et værktøj til at oprette et bogmærke.

Modeller, der ikke understøtter værktøjskald, kan kun give dig tekstsvarene. De kan ikke slå ting op, navigere eller ændre noget i appen.

## Hvilke modeller understøtter værktøjer?

### Fjerne modeller

De fleste moderne fjerne modeller fra store udbydere understøtter OpenAI-kompatibelt værktøjskald. Generelt:

- **Store modeller** (f.eks. GPT-4o, Claude Sonnet/Opus, Gemini Pro) håndterer værktøjer pålideligt og kan kæde flere værktøjskald sammen i én samtale. Udbydernavne og model-id'er vises i appen for bekvemmelighedens skyld; den tjeneste, du faktisk forbinder til, er den, hvis endpoint og nøgle du konfigurerer.
- **Mindre eller billigere modeller** understøtter måske værktøjer, men kan være mindre pålidelige. De kan ignorere et værktøjskald eller formatere det forkert.
- **Meget gamle eller specialiserede modeller** understøtter ofte slet ikke værktøjer.

Hvis du er i tvivl, så test modellen i Theodia. Bed den om "Vis mig 1. Mosebog 1,1" eller "Søg i Bibelen efter vers om kærlighed." Hvis verset åbner, eller søgeresultaterne vises, virker værktøjskald.

## Anbefalede modeller til Theodia

Disse er gode valg, der balancerer pris, kvalitet og værktøjsunderstøttelse:

- **OpenAI GPT-4o** — fremragende værktøjsunderstøttelse, hurtig, håndterer komplekse flertrins-spørgsmål godt.
- **Anthropic Claude Sonnet / Opus** — meget pålidelig værktøjsbrug, god til lange passager og detaljeret studium.
- **Groq** (forskellige modeller) — hurtig inferens, ofte gratis eller meget billig, værktøjsunderstøttelse varierer efter model.
- **OpenRouter** — lader dig prøve mange modeller fra én konto. Kig efter modeller, der nævner "function calling" eller "tools" i deres egenskaber.
- **[GitHub Models](theodia://help/github-models)** — den anbefalede gratis udbyder. Adgang til OpenAI, Anthropic og andre modeller gennem din GitHub-konto med en generøs daglig gratis kvote. Bruger de samme `openai/gpt-4o`-agtige model-id'er.

## Modeller, du bør undgå

- **Ren tekstfuldstændelsesmodeller** (f.eks. GPT-3 base eller rå LLaMA uden instruktionstræning) understøtter normalt ikke værktøjer.
- **Kun-billede- eller visionsmodeller** med fokus på billeder frem for tekst mangler måske værktøjsunderstøttelse.
- **Ekstremt små modeller** under 1 milliard parametre bruger næppe værktøjer korrekt, selv hvis API'en hævder, at de understøtter dem.

## Sådan tester du værktøjsunderstøttelse

Theodia tjekker for værktøjsunderstøttelse automatisk. Når du har sat en model op i **Indstillinger → AI-assistent**, trykker du på **Test forbindelse**. Når forbindelsen lykkes, sender appen en anden anmodning med en eksempelværktøjsdefinition. Du ser ét af to resultater:

- **✓ Værktøjer understøttet** — Modellen accepterer værktøjskald og kan bruge Theodias indbyggede funktioner.
- **✗ Værktøjer ikke understøttet** — Modellen afviser værktøjsanmodningen. Den svarer kun i tekst og kan ikke åbne vers, søge eller administrere bogmærker for dig.

Hvis du ser "Værktøjer ikke understøttet", kan modellen stadig virke som en almindelig tekstchat-assistent, men du får ikke den integrerede oplevelse uden hænder.

Du kan også verificere det manuelt ved at bede AI'en om at gøre noget:

- "Vis mig Matthæus 5,3 i KJV." — Bør åbne verset i læseren.
- "Hvad siger leksikonet om ordet 'agape' i Johannes 3,16?" — Bør returnere leksikondata.
- "Søg i Bibelen efter vers om tilgivelse." — Bør returnere søgeresultater.
- "Sæt bogmærke på Markus 12,30." — Bør oprette et bogmærke.

Hvis AI'en giver dig en tekstbeskrivelse i stedet for faktisk at gøre det, så har modellen svært ved at bruge sine værktøjer, selv om appen meldte understøttelse.

## Hvad hvis min model ikke understøtter værktøjer?

Du kan stadig bruge den. AI'en svarer i tekst, og du kan selv slå vers op, søge og navigere i appen. Men du går glip af den integrerede oplevelse uden hænder, der gør Theodia kraftfuld.

## Opsummering

- Vælg en model med understøttelse af **værktøjskald / function calling** for den bedste Theodia-oplevelse.
- **Store fjerne modeller** håndterer værktøjer mest pålideligt.
- Test enhver model med simple kommandoer som "Vis mig 1. Mosebog 1,1" for at verificere værktøjsunderstøttelsen.
