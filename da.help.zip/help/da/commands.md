---
title: Kommandoer
level: everyday
categories: [layout, study]
summary: Kommandoinput lader dig hoppe til enhver funktion ved at skrive en kort kommando. Lær de understøttede formater og eksempler.
---

# Kommandoer

**Kommando**-input lader dig hoppe til næsten enhver del af Theodia ved at skrive en kort instruktion. Du kan bruge den fra Hjem-fanen eller fra **Launcher-menuen** (**▼**-ikonet i sidehovedet).

## Sådan virker det

1. Tryk på kommandoboksen.
2. Skriv en kommando.
3. Tryk på go-tasten på dit tastatur.

Appen læser kommandoen og fører dig direkte til den rigtige skærm.

## Intet skråstreg-præfiks

Kommandoer bruger **ikke** et `/`-præfiks. De indtastes som almindelig tekst:

```
john 3:16
search love
backup
```

Hvis du skriver `/settings`, gør det indledende `/` den uigenkendelig.

## Bibelhenvisninger

Skriv en hvilken som helst Bibelhenvisning for at åbne den i læseren.

```
psalms 23
john 3:16
matthew 5:1
1 cor 15:10
```

Bognavne kan matches med fuldt navn eller forkortelse. På ikke-engelske brugergrænsefladesprog kan du også skrive bognavnene på det aktive sprog.

## Søgning

```
search abraham
search love
search faith not works
```

## Bogmærker, sammenlign, kommentar, krydshenvisninger og ordinfo

```
bookmark john 3:16
compare genesis 1:1
commentary john 1
aicommentary eph 2:8
xref 1 cor 15:10
word info john 1:1
```

Disse kommandoer åbner det navngivne værktøj for den givne passagen.

## Leksikon

Skriv et Strongs-nummer for at åbne leksikonposten.

```
g1161
h7225
```

## Andagter

```
devotional
devotional smith
devotional daily
```

Uden navn åbner dette andagtslisten.

## Navigationsgenveje

```
notes
highlights
bookmarks
flashcards
playlist
theoscript
resources
read john 3:16
```

Disse hopper direkte til den navngivne skærm eller åbner en passagen i læseren.

## Skift af oversættelse

Skriv en oversættelsesforkortelse for at skifte til den.

```
kjv
web
trlit
ohgb
```

På en læserskærm udskiftes oversættelsen på stedet. Alle andre steder åbner den oversættelsen ved din seneste passagen.

## Lokaliserede kommandoverber

De offentlige kommandoverber kan skrives på det aktive brugergrænsefladesprog **eller** på engelsk. Engelsk virker altid som reserve. Skjulte kommandoer (genveje til indstillinger, installationskommandoer, påskeæg) beholder kun engelsk syntaks.

## Hjælp

Skriv `help` eller `commands` i kommandoboksen for at åbne appens kommandoreference når som helst.
