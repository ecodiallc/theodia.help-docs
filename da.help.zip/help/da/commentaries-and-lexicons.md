---
title: Kommentarer og leksika
level: everyday
categories: study
summary: Sådan slår du ordbetydninger op og læser studienoter.
---

# Kommentarer og leksika

> **Tilstand:** Kommentarer og leksika kræver **Forsker**-tilstand. Du kan skifte tilstand i **Indstillinger** → **App-brugertilstand**.

Theodia indeholder to studieværktøjer: **kommentarer** og **leksika**. De hjælper dig med at forstå Bibelen mere dybgoing.

## Hvad er en kommentar?

En kommentar er en bog med studienoter skrevet af en bibelforsker. For et givet vers fortæller en kommentar dig baggrunden, betydningen, og hvordan verset passer ind i resten af Bibelen.

## Hvad er et leksikon?

Et leksikon er en ordbog over Bibelens ord. Det fortæller dig det oprindelige hebraiske eller græske ord, hvad det betyder, og hvordan det bruges i Bibelen.

## Sådan åbner du en kommentar

1. Åbn et kapitel.
2. Tryk på et vers.
3. Tryk på **Kommentar**.

Der åbnes et panel. Det viser noter fra en bibelforsker om det vers.

## Sådan åbner du et leksikon

1. Åbn et kapitel i en Bibel, der inkluderer Strongs numre.
2. Tryk på et Strongs-nummer i verset (f.eks. G1234 eller H1234).
3. Der åbnes et panel, der viser det oprindelige hebraiske eller græske ord, dets betydning og andre vers, der bruger ordet.

Strongs numre vises i en anden farve i verset, så de skiller sig ud fra de almindelige ord.

## Vælg en anden kommentar

Kommentaren vælges fra en rullemenu øverst på selve kommentarpanelet. Åbn panelet, og tryk derefter på rullemenuen for at se de kommentarer, du har installeret. Vælg en anden.

## Vælg et andet leksikon

Leksikonet vælges fra en rullemenu øverst på leksikonpanelet. Åbn panelet, og tryk derefter på rullemenuen for at se de leksika, du har installeret. Vælg et andet.

## Indbyggede ressourcer

Theodia leveres med et indbygget sæt kommentarer og leksika. De følger med appen og virker offline. Flere kommentarer og leksika kan ikke installeres eller downloades separat.

## Hvornår skal man bruge dem

- **Kommentarer** er gode, når et vers er svært at forstå. Noterne giver dig baggrunden.
- **Leksika** er gode til ordstudier. De fortæller dig den præcise betydning af et ord på originalsproget.

## Tip

Hvis et vers har en note, du vil gemme, så tag et skærmbillede eller kopiér teksten ind i en note. (Se guiden [At skrive noter](theodia://help/notes).)

## Bibel-ordbog i almindeligt sprog

Til definitioner på engelsk af Bibelens ord og begreber (pagt, forsoning, farisæere osv.) indeholder Theodia også et Bibel-ordbog-værktøj. Åbn det fra versmenuen ved at trykke på **Ordbog** (📖). Det er noget andet end leksikon: Leksika forklarer de oprindelige hebraiske og græske ord, mens ordbogen forklarer det engelske ord i almindeligt sprog. Se guiden [Bibel-ordbog](theodia://help/dictionary) for, hvordan du bruger den.
