---
title: Almindelige problemer
level: everyday
categories: trouble
summary: Hurtige løsninger på problemer, du kan støde ind i.
---

# Almindelige problemer

Denne guide dækker de problemer, folk oftest støder ind i. Hvis dit problem ikke er her, så se guiden [Hvor stiller jeg spørgsmål](theodia://help/getting-more-help).

## Appen er langsom

1. Luk andre apps, der kører i baggrunden.
2. Genstart appen.
3. Genstart din enhed.

## Jeg kan ikke finde en Bibeloversættelse

1. Åbn **Indstillinger** → **Administrer ressourcer** for at se, hvad der er installeret.
2. Hvis oversættelsen ikke er der, så tryk på **Installér fra GitHub**.
3. I download-vinduet trykker du på fanen **Bibler** (eller **Globale Bibler**) og vælger den oversættelse, du vil have.
4. Tryk på **Installér valgte**, og vent til downloaden er færdig.
5. Du skal bruge internettet for at downloade en ny oversættelse.

## Mine noter eller bogmærker er væk

1. Tjek, at du kigger på den rigtige fane. Noter er i fanen **Noter**. Bogmærker er i fanen **Bogmærker**.
2. Hvis du for nyligt gendannede en sikkerhedskopi, kan den have erstattet dine data. Tjek sikkerhedskopiens dato.
3. Hvis du afinstallerede og geninstallerede appen, gik dine data tabt. Næste gang, så lav en sikkerhedskopi først.

## Søgningen finder ikke vers

1. Sørg for, at du har stavet ordet rigtigt.
2. Prøv et kortere ord. "Kærlighed" finder flere vers end "kærlighedens".
3. Sørg for, at du har den rigtige Bibeloversættelse installeret. Søgning virker kun i de oversættelser, du har.

## Oplæsning virker ikke

1. Sørg for, at din enheds volumen er skruet op.
2. Sørg for, at appen har lov til at bruge højttaleren.
3. Prøv en anden oversættelse. Nogle oversættelser fungerer bedre med oplæsning end andre.
4. For en trin-for-trin-tjekliste, se guiden [Læsning op (tekst-til-tale)](theodia://help/tts).

## Appen fortsætter med at crashe

1. Genstart appen.
2. Genstart din enhed.
3. Hvis problemet bliver ved, så rapportér det venligst. Se guiden [Hvor stiller jeg spørgsmål](theodia://help/getting-more-help).

## Jeg vil afinstallere appen

Du kan afinstallere Theodia som enhver anden app. Inden du gør det, så lav en sikkerhedskopi af dine data. Når du har afinstalleret, er dataene på enheden væk.

## Stadig kørt fast?

Se guiden [Hvor stiller jeg spørgsmål](theodia://help/getting-more-help). Der kan du finde links til at rapportere et problem og til at spørge fællesskabet.

Du kan også søge i hjælpeguidene fra **Hjælp & guider**-hovedskærmen. Skriv et ord som `notifications`, `search` eller `bookmarks` for at finde den matchende guide.
