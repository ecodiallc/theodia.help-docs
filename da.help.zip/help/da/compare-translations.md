---
title: Sammenligning af oversættelser
level: everyday
categories: [read, study]
summary: Sådan ser du det samme vers i hver oversættelse, du har installeret.
---

# Sammenligning af oversættelser

> **Tilstand:** Sammenlign-værktøjet er tilgængeligt i **Standard**- og **Forsker**-tilstand. Fokustilstand er kun til ren læsning uden afbrydelser. Du kan skifte tilstand i **Indstillinger** → **App-brugertilstand**.

**Sammenlign**-værktøjet viser ét vers i hver Bibeloversættelse, du har installeret, alt sammen i ét panel. Det er nyttigt, når du vil se, hvordan forskellige oversættere håndterer et svært vers, eller når du er ved at vælge en oversættelse og vil se det samme vers i hver af dem.

## Sådan åbner du Sammenlign

1. Åbn et kapitel i en hvilken som helst oversættelse.
2. Tryk på et vers for at få versmenuen frem.
3. Tryk på **Sammenlign** (⇄).

Der åbnes et panel. Titelbjælken viser henvisningen (f.eks. "Johannes 3,16 — Sammenlign"). Panelet viser det samme vers i hver installerede oversættelse. Din nuværende oversættelse vises først; resten sorteres alfabetisk.

## Sådan ser panelet ud

Panelet er en **lodret liste**, ikke en side-om-side-kolonne. Hver række er én oversættelse:

- **Oversættelsesnavnet** (f.eks. "KJV") står øverst i rækken. Det kan trykkes på.
- **Verseteksten** står under navnet.

Rul panelet for at se alle oversættelserne. Hver oversættelse, der er installeret på din enhed, vises her. Hvis en oversættelse ikke har den bog eller det vers, udelades den.

## Sådan læser du verset i en anden oversættelse

Tryk på oversættelsesnavnet i rækken. Sammenlign-panelet lukker, og det samme kapitel åbner med det valgte vers vist i den oversættelse. Det er den hurtigste måde at hoppe fra en sammenligning direkte til at læse en bestemt oversættelse.

## Sådan lukker du Sammenlign

- **På en telefon:** tryk på X'et øverst til højre i panelet.
- **På en tablet:** tryk på X'et i panelhovedet, eller tryk uden for panelet.

Du er tilbage i kapitelvisningen i din oprindelige oversættelse.

## Hvornår skal man bruge Sammenlign

- **Ved valg af oversættelse.** Åbn et vers, du kender godt, i din nuværende oversættelse, og tryk derefter på Sammenlign for at se det i andre. Forskellene springer i øjnene.
- **Svære vers.** Et vers, der er forvirrende i én oversættelse, er ofte klarere i en anden.
- **Ordstudier.** Se, hvordan forskellige oversættere håndterer et nøgleord eller en frase.

Til et blik-blik-sammenligning af et helt kapitel i flere oversættelser på én gang, så brug i stedet **parallelvisningen**. Se guiden [Studietilstand](theodia://help/study-mode) for, hvordan du slår den til.
