---
title: At skabe dine egne ressourcer
level: advanced
categories: resources
summary: Sådan opretter du brugerdefinerede Bibler, kommentarer, bøger, andagter og leksika og importerer dem i Theodia.
---

# At skabe dine egne ressourcer

Theodia understøtter brugerdefinerede ressourcer i Unique Bible App-formatet. Hver ressource er en SQLite-fil med en bestemt tabelstruktur. Du kan oprette disse filer på en computer og importere dem i appen.

## Filtyper og påkrævede tabeller

### Bibler (`.bible`)

En Bibel-fil er en SQLite-database med mindst én af disse tabeller:

- **`Verses`** — kolonner: `Book` (heltal, 1-66), `Chapter` (heltal), `Verse` (heltal), `Scripture` (tekst)
- **`Bible`** — kolonner: `Book` (heltal), `Chapter` (heltal), `Verse` (heltal), `Scripture` (tekst)

Du kan også inkludere en **`Details`**-tabel med metadata-kolonner som `Description`, `Abbreviation` og `Version`.

Eksempel på SQL:

```sql
-- Main text table
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- Optional metadata table
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### Kommentarer (`.commentary`)

Kommentarer findes i tre typer: **bog**, **kapitel** og **vers**. Typen bestemmes af **det første bogstav i filnavnet**.

#### Bogkommentarer — filnavn starter med `b`

En bogkommentar dækker en hel Bog i Bibelen i én enkelt post. Tabellen `Commentary` behøver kolonnerne `Book` og `Scripture` (eller `Content`). Ingen `Chapter`- eller `Verse`-kolonner er nødvendige.

- **`Commentary`** — kolonner: `Book` (heltal), `Scripture` (tekst) eller `Content` (tekst)

Eksempel på SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

Eksempel på filnavn: `bMyCommentary.commentary`

#### Kapitelkommentarer — filnavn starter med `c`

En kapitelkommentar dækker hvert kapitel i en Bibelbog.

- **`Commentary`** — kolonner: `Book` (heltal), `Chapter` (heltal), `Scripture` (tekst) eller `Content` (tekst)

Eksempel på SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

Eksempel på filnavn: `cMyCommentary.commentary`

#### Verskommentarer — filnavn starter med `v`

En verskommentar dækker individuelle vers. Tabellen `Commentary` behøver kolonnerne `Book`, `Chapter`, `Verse` og `Scripture` (eller `Content`).

- **`Commentary`** — kolonner: `Book` (heltal), `Chapter` (heltal), `Verse` (heltal), `Scripture` (tekst) eller `Content` (tekst)

Eksempel på SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

Eksempel på filnavn: `vMyCommentary.commentary`

### Bøger (`.book`)

En bogfil er en SQLite-database med en `Reference`-tabel.

- **`Reference`** — kolonner: `id` (heltal), `Chapter` (tekst), `Content` (tekst)

Hver række er ét kapitel. Kolonnen `Chapter` er kapiteltitlen. Kolonnen `Content` er kapitelkroppen, som kan indeholde HTML (`<b>`, `<i>`, `<br>` osv.).

Eksempel på SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

Du kan også oprette bøger fra Markdown-filer. Appen kan importere `.md`-filer, hvor `#` er bogens titel, og `##` markerer kapitler. Markdownen konverteres automatisk til HTML.

### Andagter (`.devotional`)

En andagtsfil er en SQLite-database med en `devotional`-tabel.

- **`devotional`** — kolonner: `month` (heltal, 1-12), `day` (heltal, 1-31), `devotion` (tekst)

Hver række er én dags læsning. Appen slår posten op efter dagens måned og dag.

Eksempel på SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### Leksika (`.lexicon`)

En leksikonfil er en SQLite-database med en `Lexicon`-tabel.

- **`Lexicon`** — kolonner: `Topic` (tekst, Strongs-nummeret), `Definition` (tekst, leksikonposten)

Kolonnen `Topic` indeholder Strongs-nummeret (f.eks. `G1161` eller `H7225`). Kolonnen `Definition` indeholder hele postens tekst, som kan indeholde HTML.

Eksempel på SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

Leksika driver værktøjet Ordinfo. Når du trykker på et ord i en interlineær Bibel, slår appen Strongs-nummeret op i de installerede leksika.

## At oprette en fil på din computer

1. Installér en SQLite-editor (DB Browser for SQLite, SQLiteStudio eller `sqlite3`-kommandolinjeværktøjet).
2. Opret en ny databasefil.
3. Opret den påkrævede tabel, og indsæt dine data.
4. Gem filen med den korrekte endelse (`.bible`, `.commentary`, `.book`, `.devotional` eller `.lexicon`).

## Import i Theodia

1. Overfør filen til din enhed (AirDrop, e-mail, cloud-lager eller USB).
2. Åbn **Theodia**.
3. Gå til **Indstillinger** → **Administrer ressourcer**.
4. Tryk på **Importér fra fil**.
5. Vælg din fil.

Appen validerer filen (tjekker for den påkrævede tabel), kopierer den til appens datamappe og aktiverer den automatisk. Hvis filen er ugyldig, ser du en fejlmeddelelse, der forklarer, hvad der er galt.

## Begrænsninger

- Du kan ikke overskrive indbyggede ressourcer. Hvis du forsøger at importere en fil med samme navn som en indbygget Bibel, kommentar eller bog, fejler importen.
- Bibelfiler behøver en `Verses`- eller `Bible`-tabel. Hvis ingen af dem findes, fejler importen.
- Kommentarfiler behøver en `Commentary`-tabel.
  - Bogkommentarer behøver kolonnerne `Book` og `Scripture` (eller `Content`).
  - Kapitelkommentarer behøver kolonnerne `Book`, `Chapter` og `Scripture` (eller `Content`).
  - Verskommentarer behøver kolonnerne `Book`, `Chapter`, `Verse` og `Scripture` (eller `Content`).
- Bogfiler behøver en `Reference`-tabel.
- Leksikonfiler behøver en `Lexicon`-tabel.
- Andagtsfiler behøver en `devotional`-tabel.

## Tips

- Hold filstørrelserne rimelige. Meget store SQLite-filer kan give hukommelsesproblemer på ældre enheder.
- Test din fil på en computer først. Åbn den i en SQLite-browser, og kør `SELECT * FROM` den påkrævede tabel for at verificere, at dataene ser rigtige ud.
- For Bibler, sørg for, at kolonnen `Book` bruger tal (1 = 1. Mosebog, 66 = Åbenbaringen).
- For Kommentarer, du kan bruge enten `Scripture` eller `Content` som kommentarens tekstkolonne.
- For Bøger, HTML i kolonnen `Content` gengives ved læsning. Hold det enkelt: `<b>`, `<i>`, `<br>` og `<hr>` er sikre.

## Hvor finder man eksisterende ressourcer

Theodia kan læse ressourcer fra [Unique Bible App](https://github.com/eliranwong/UniqueBible)-projektet. Mange Bibler, kommentarer, bøger og andre ressourcer er tilgængelige der i det korrekte SQLite-format. Se guiden [Hentning af ekstra ressourcer](theodia://help/getting-core-files) for, hvordan du finder og tilføjer dem.
