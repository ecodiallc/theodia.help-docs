---
title: Krydshenvisninger
level: everyday
categories: study
summary: Sådan finder du vers, der knytter sig til det, du læser.
---

# Krydshenvisninger

> **Tilstand:** Krydshenvisninger er tilgængelige i **Standard**- og **Forsker**-tilstand. Fokustilstand er kun til ren læsning uden afbrydelser. Du kan skifte tilstand i **Indstillinger** → **App-brugertilstand**.

En "krydshenvisning" er et andet vers, der taler om det samme som det vers, du læser. Krydshenvisningspanelet viser dig, hvilke vers i Bibelen der knytter sig til hinanden.

## Sådan åbner du krydshenvisningerne

1. Åbn et kapitel.
2. Tryk på et vers for at få versmenuen frem.
3. Tryk på **Krydshenvisninger**.

Der åbnes et panel. Det viser en liste over andre vers, der knytter sig til det, du trykkede på.

## Sådan læser du listen

Hver række er ét tilknyttet vers. Du ser:

- Bogen, kapitlet og verset.
- En kort forhåndsvisning af verset.
- En score, der viser, hvor stærk forbindelsen er.

## Sådan hopper du til et tilknyttet vers

Tryk på en hvilken som helst række. Appen åbner det vers for dig. Når du er færdig, trykker du på tilbage-knappen for at vende tilbage.

## Hvad scoren betyder

Scoren fortæller dig, hvor tæt versene er forbundet. En høj score betyder en stærk, direkte forbindelse. En lav score betyder en løsere.

## Brug krydshenvisninger til studium

Krydshenvisninger er nyttige til:

- **Ordstudier.** Se, hvordan Bibelen bruger et ord forskellige steder.
- **Temastudier.** Spor et tema, som "kærlighed" eller "pagt", gennem Skriften.
- **Prædikeforberedelse.** Find understøttende vers hurtigt.

## Tip

Krydshenvisninger virker bedst med en ord-for-ord-oversættelse som WEB.
