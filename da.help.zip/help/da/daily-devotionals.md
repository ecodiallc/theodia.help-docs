---
title: Daglige andagter
level: everyday
categories: [content, read]
summary: Sådan læser du en kort andagt hver dag.
---

# Daglige andagter

En andagt er en kort læsning for én dag. Den har ofte et vers, en kort tanke og et spørgsmål at tænke over. Theodia leveres med et lille bibliotek af andagter.

## Sådan åbner du en andagt

1. Tryk på fanen **Andagter** nederst på skærmen.
2. Du ser en liste over de andagter, der er installeret på din enhed.
3. Tryk på en for at åbne den.

## Sådan læser du en andagt

1. Åbn andagten.
2. Rul for at læse.
3. Brug knapperne øverst til:
   - Tryk på **datoen** for at hoppe til en anden dag.
   - Tryk på **stjernen** for at sætte bogmærke på dagen.
   - Tryk på **højttaleren** for at læse den op (hvis din enhed understøtter det). Se guiden [Oplæsning](theodia://help/tts) for, hvordan du vælger en stemme.
   - Tryk på **Forrige** eller **Næste** for at gå til dagen før eller efter.

## Sådan gemmer du et vers fra en andagt

1. Åbn andagten.
2. Tryk på et vers.
3. Tryk på **Bogmærke** eller **Fremhæv**.

Verset gemmes i dine Bogmærker eller Fremhævninger.

## Sådan skriver du en note til en andagt

1. Åbn andagten.
2. Tryk på et vers.
3. Tryk på **Note**. Skriv din refleksion eller bøn. Tryk på **Gem**.

Noten vises i din Notes-fane.

## Tips

- Andagter behøver ikke internettet. De virker offline.
- Hvis du gerne vil have flere andagter, så se guiden [Hentning af ekstra ressourcer fra GitHub](theodia://help/getting-core-files).
