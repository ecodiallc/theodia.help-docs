---
title: Bibel-ordbog
level: everyday
categories: study
summary: Slå Bibelens ord og begreber op i installerede ordbogsressourcer. Åbn den fra versmenuen eller fra en leksikonpost, og tryk derefter på et hvilket som helst ord for at se det samme ord i hver ordbog.
---

# Bibel-ordbog

> **Tilstand:** Bibel-ordbogen kræver **Forsker**-tilstand. Du kan skifte tilstand i **Indstillinger** → **App-brugertilstand**.

Værktøjet Bibel-ordbog slår et ord eller en frase op i hver ordbogsressource, du har installeret. Det er nyttigt, når du vil have en definition i almindeligt sprog af et bibelsk ord, en beskrivelse af en person eller et sted eller en kort artikel om et teologisk begreb.

Bibel-ordbogen er noget andet end værktøjet **Ordinfo**, som slår det oprindelige hebraiske eller græske ord bag et vers op. Ordbogen læser det **engelske** ord, du trykker på, og viser dig, hvad dine installerede ordbøger siger om det. Til ord-for-ord-noter i Bibeloversættelser, se guiden [Kommentarer og leksika](theodia://help/commentaries-and-lexicons).

## Sådan åbner du Ordbogen

Der er to måder at åbne ordbogen på.

### Fra versmenuen

1. Åbn et kapitel i [Studietilstand](theodia://help/study-mode).
2. Tryk på et vers for at åbne versmenuen.
3. Tryk på **Ordbog** (📖).

Der åbnes et panel med titel efter vershenvisningen (f.eks. "Johannes 3,16"). Verset står øverst, og hvert ord kan trykkes på. Under verset er en chiprække, der viser hver installerede ordbog. Under den er definitionen, som er tom, indtil du trykker på et ord.

### Fra en leksikonpost

Når du læser en leksikonpost i Ordinfo-panelet, indeholder nogle poster blå links til relaterede ordbogsartikler. Tryk på et af de links. Leksikonet lukker, og ordbogen åbner ved den artikel. Det er den hurtigste måde at hoppe fra et græsk eller hebraisk ord til en forklaring i almindeligt sprog på, hvad det betyder.

## Sådan virker versvisningen

Når du åbner ordbogen fra en versmenu, vises verset øverst i panelet som en liste af ord, du kan trykke på. Almindelige engelske ord som "the," "and," "of," "to" og "a" kan ikke trykkes på. Alle andre ord kan. Hvert trykbare ord er farvet og fed, så det skiller sig ud fra resten af verset.

Tryk på et hvilket som helst ord i verset. Theodia søger i hver installerede ordbog efter et eksakt match på det ord. Chiprækken i bunden opdateres og viser, hvilke ordbøger der har en post: ordbøger, der ikke har en post for det ord, nedtones. Den første ordbog med en post vælges automatisk, og dens definition vises under chiprækken.

Det ord, du trykkede på, fremhæves i verseteksten øverst i panelet, så du altid ved, hvad du slår op.

## Skift mellem ordbøger

Hver installerede ordbog vises som en lille chip under verset. Efter tryk på et ord:

- **Solid farve**-chip — denne ordbog har en post for det ord, du trykkede på. Tryk på den for at skifte til den ordbogs definition.
- **Nedtonet** chip — denne ordbog har ikke en post for det ord. Den vises gråtone, så du kan se med ét blik, hvilke ordbøger der dækker ordet, og chippet kan ikke trykkes på.

Den valgte ordbog er fremhævet. Tryk på et andet solidt chip for at læse det samme ord i den ordbog. Definitionen nedenfor opdateres straks.

Hvis ordet findes i kun én af dine installerede ordbøger, er kun det ene chip solidt, og de andre er nedtonede.

## Hvad panelet viser

Ordbogspanelet har tre dele, ovenfra og ned:

- **Verset** — verset, du åbnede ordbogen fra. Ordene kan trykkes på, og det ord, du sidst trykkede på, er fremhævet.
- **Chiprækken** — hver installerede ordbog. Solid betyder "har en post for det trykkede ord". Nedtonet betyder "ingen post for det ord".
- **Definitionen** — artiklen fra den valgte ordbog. Almindelig tekst, formateret med afsnit og overskrifter. Interne links til andre ordbogsposter kan trykkes på; tryk på ét af dem for at åbne den post i ordbogen.

## Hvad sker der, hvis ingen post findes

Hvis du trykker på et ord, som ingen af dine installerede ordbøger dækker, viser panelet en kort besked "ingen poster fundet" i stedet for en definition. Det er almindeligt for meget almindelige ord som "year" eller "come", der ikke rigtig er bibelteologiske ord, selv om de optræder overalt i Bibelen. Prøv et mere specifikt ord, eller brug i stedet leksikonets Ordinfo-værktøj, som virker på den underliggende græske og hebraiske tekst.

## Hvad sker der, hvis ingen ordbog er installeret

Ordbogen behøver mindst én ordbogsressourcefil for at være nyttig. Theodia leveres med én. Hvis du har fjernet den, eller du kører en brugerdefineret installation uden ordbøger, viser versvisningen sig stadig, og ordene kan stadig trykkes på, men chiprækken er tom, og hver søgning returnerer "ingen poster fundet".

Flere ordbøger kan ikke installeres separat.

## Tips

- Ordbogen søger efter **eksakte ordmatches**. Tryk på "love" finder poster med titlen "love", men ikke "loved" eller "loving". For at slå en relateret form op skal du bruge leksikonets Ordinfo-værktøj på det græske eller hebraiske ord.
- Chiprækken er ens på telefoner og tablets. På en tablet åbner ordbogen som et sidepanel ved siden af kapitlet; på en telefon åbner den som en fuldskærmsmodal. Begge har samme tre-delt layout.
- Tryk på et ord i et andet vers åbner et nyt vers i panelet. Dit forrige valg ryddes. Tryk på et ord i det nye vers for at starte et nyt opslag.
- Nogle ordbogsposter henviser til det samme ord i en anden ordbog. Tryk på de interne links for at følge sporet på tværs af alle dine installerede ordbøger.

## Forskelle mellem Ordbog og Ordinfo

Begge værktøjer åbner fra versmenuen, men de gør forskellige ting:

- **Ordbog** (📖) læser det engelske ord, du trykker på, og finder det i dine installerede engelske ordbøger. Det er det rigtige værktøj til definitioner i almindeligt sprog af bibelteologiske ord som "covenant", "atonement" eller "Pharisee".
- **Ordinfo** (?) læser det oprindelige græske eller hebraiske ord bag verset og finder det i dine installerede leksika. Det er det rigtige værktøj til seriøse ordstudier, at finde hvert sted et græsk ord bruges, og at læse definitionerne på originalsproget.

Når du er i tvivl, så start med ordbogen. Hvis du vil grave i originalsproget, så skift til Ordinfo. Se guiden [Kommentarer og leksika](theodia://help/commentaries-and-lexicons) for den fulde Ordinfo-gennemgang.

## Relaterede guider

- Guiden [Studietilstand](theodia://help/study-mode) forklarer versmenuen i detaljer, og hvor værktøjet Ordbog (📖) sidder ved siden af Bogmærke, Fremhæv, Læs op, Sammenlign, Krydshenvisninger, AI-kommentar, Ordinfo og Noter.
- Guiden [Kommentarer og leksika](theodia://help/commentaries-and-lexicons) dækker Ordinfo og leksikaerne på originalsprogene.
- Guiden [Hvad er ressourcer?](theodia://help/what-are-resources) forklarer de forskellige typer filer, Theodia bruger, inklusive ordbogsressourcerne.
- Guiden [Almindelige problemer](theodia://help/common-problems) har løsninger på tomme resultater og andre ordbogsproblemer.
