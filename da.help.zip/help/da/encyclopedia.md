---
title: Leksikon (encyklopædi)
level: everyday
categories: study
summary: Sådan slår du leksikonartikler op og bladrer i opslagsværker.
---

# Leksikon (encyklopædi)

Theodia indeholder et indbygget **Leksikon (encyklopædi)** til opslag af bibelrelaterede artikler, personer, steder og emner. Appen leveres med _Kitto's Illustrated Commentary_ (KIT) indbygget, og du kan downloade flere leksika fra depotet.

## Hvad er et leksikon i Theodia?

Et leksikon er et opslagsværk bestående af korte artikler. Hver artikel dækker en person, et sted, en begivenhed eller et bibelsk emne. I modsætning til en kommentar, der forklarer et bestemt vers, forklarer en leksikonartikel emnet selv.

## Sådan åbner du Leksikonet

1. Tryk på **Leksikon** i bundværktøjslinjen.
2. Vælg et leksikon fra rækken af forkortelser øverst.
3. Skriv et emne, en person eller et sted i søgeboksen.

Søgning kræver mindst **3 tegn**, før resultater og forslag til autofuldførelse vises.

## Læsning af en artikel

- På **telefon** trykker du på et hvilket som helst resultat for at åbne artiklen på en ny skærm.
- På **tablet** åbner artiklen i panelet til højre, mens listen bliver til venstre.

## Valg af leksika

Tryk på et forkortelseschip (f.eks. **KIT**) for at skifte til det leksikon. For at søge i mere end ét leksikon ad gangen skal du bruge fanen **Søg** og vælge **Leksikon** som søgetilstand.

## Få flere leksika

1. Åbn **Indstillinger**.
2. Tryk på **Administrer ressourcer**.
3. Tryk på **Installér fra GitHub**.
4. Vælg fanen **Leksika (encyklopædier)**.
5. Tryk på download-knappen ved siden af det leksikon, du vil have.

Leksika downloades fra Theodias leksikon-GitHub-depot og installeres automatisk. Installerede leksika vises på Leksikon-skærmen og i Søg.

Du kan også installere et leksikon fra en lokal fil: i **Administrer ressourcer** trykker du på **Installér lokal fil** og vælger en `.encyclopedia`-fil. Filen kopieres ind i appens leksikonmappe og tilføjes til det delte opslagsindeks.

## Lang tryk for den fulde titel

På Søg-skærmen viser leksikonchippene korte forkortelser. Hold et chip inde længe for at se leksikonets fulde navn.

## Hvornår skal man bruge Leksikonet

- Slå en person, et sted eller et emne op før eller mens du læser en passagen.
- Få baggrund om et bibelsk ord eller begreb, der spænder over mange vers.
- Læs sammen med en kommentar for dybere studium.
