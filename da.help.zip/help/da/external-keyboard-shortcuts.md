---
title: Eksterne tastaturgenveje
level: everyday
categories: [tablet, settings]
summary: Fuld tastaturgenvejsreference til iPad med et eksternt tastatur tilsluttet.
---

# ⌨️ Eksterne tastaturgenveje

Hvis du bruger Theodia på iPad med et eksternt tastatur (Magic Keyboard, Bluetooth-tastatur eller USB-tastatur), kan du navigere i appen uden at røre skærmen.

> **Tilstand:** Nogle genveje virker kun, når den tilsvarende funktion er tilgængelig i din nuværende brugertilstand. For eksempel gør `Cmd + Option + 6` (Bogmærker) og `Cmd + Option + 7` (Fremhævninger) ingenting i Læser-tilstand. Skift tilstand i **Indstillinger** → **App-brugertilstand**.

Genveje virker på **iPad**.

## Globale genveje (hvor som helst)

| Genvej             | Handling                                       |
| ------------------ | ---------------------------------------------- |
| `Cmd + /`          | Vis denne hjælp til tastaturgenveje            |
| `Cmd + .`          | Luk modal / panel (Escape-alternativ)          |
| `Cmd + Option + 1` | Gå til Hjem-fanen                              |
| `Cmd + Option + 2` | Gå til Bibler-fanen                            |
| `Cmd + Option + 3` | Gå til Bøger-fanen                             |
| `Cmd + Option + 4` | Gå til Andagter-fanen                          |
| `Cmd + Option + 5` | Gå til Søg-fanen                               |
| `Cmd + Option + 6` | Gå til Bogmærker-fanen (Standard og Forsker)   |
| `Cmd + Option + 7` | Gå til Fremhævninger-fanen (Standard og Forsker) |
| `Cmd + Option + 8` | Gå til Noter-fanen (Standard og Forsker)       |
| `Cmd + Option + 9` | Gå til AI-fanen (kun Forsker, hvis slået til)  |
| `Cmd + Option + 0` | Gå til Hjælp-fanen                             |
| `Cmd + Option + I` | Gå til Om-fanen                                |
| `Cmd + [`          | Gå tilbage                                     |
| `Cmd + F`          | Åbn Søg                                        |
| `Cmd + K`          | Åbn Launcher-menu (Forsker)                    |
| `Cmd + ,`          | Åbn Indstillinger                              |
| `Cmd + Shift + M`  | Åbn hovedmenu                                  |
| `Cmd + Shift + T`  | Skift tema (standard / mørkt)                  |
| `Cmd + Shift + U`  | Åbn brugertilstandsvælger                      |
| `Escape`           | Afvis modal / luk panel                        |

## Bibel-læser-genveje

Disse virker i både **Studielæser** og **Fokumlæser**.

| Genvej             | Handling                                                        |
| ------------------ | --------------------------------------------------------------- |
| `← Venstre pil`    | Forrige kapitel                                                 |
| `→ Højre pil`      | Næste kapitel                                                   |
| `Cmd + R`          | Skift mellem Studie- og Fokumlæser (Standard og Forsker)        |
| `Cmd + Option + V` | Åbn versionsvælger                                              |
| `Cmd + Option + B` | Åbn bogvælger                                                   |
| `Cmd + Option + C` | Åbn kapitelvælger                                               |
| `Cmd + T`          | Slå TTS til/fra (stop ved afspilning/pause, start ved inaktiv)  |
| `Cmd + Option + T` | Afspil / pause TTS                                              |

## Kun Studielæser

| Genvej             | Handling                                                                  |
| ------------------ | ------------------------------------------------------------------------- |
| `↑ Op-pil`         | Vælg forrige vers                                                         |
| `↓ Ned-pil`        | Vælg næste vers                                                           |
| `Cmd + ↑`          | Vælg første vers                                                          |
| `Cmd + ↓`          | Vælg sidste vers                                                          |
| `Cmd + ←`          | Hop til kapitel 1                                                         |
| `Cmd + →`          | Hop til sidste kapitel                                                    |
| `Cmd + 0`–`9`      | Direkte vershop (skriv cifre, f.eks. `Cmd + 1` `Cmd + 6` for vers 16)     |
| `Cmd + P`          | Slå parallelle Bibler til/fra (Standard og Forsker)                       |
| `Cmd + B`          | Sæt bogmærke på valgt vers (Standard og Forsker)                          |
| `Cmd + H`          | Fremhæv valgt vers (Standard og Forsker)                                  |
| `Cmd + N`          | Tilføj note til valgt vers (Standard og Forsker)                          |
| `Cmd + C`          | Sammenlign valgt vers-oversættelser (Standard og Forsker)                 |
| `Cmd + X`          | Åbn krydshenvisninger for valgt vers (Standard og Forsker)                |
| `Cmd + I`          | Åbn ordinfo (Forsker)                                                     |
| `Cmd + D`          | Åbn ordbog for valgt vers (Forsker)                                       |
| `Cmd + A`          | Åbn AI-panel for valgt vers (Forsker)                                     |
| `Cmd + Option + S` | Slå underoverskrifter til/fra                                             |
| `Cmd + Option + W` | Luk alle åbne studiepaneler                                               |
| `Cmd + Option + M` | Åbn vershandlingsmenu                                                     |

## Kun Fokumlæser

| Genvej         | Handling         |
| -------------- | ---------------- |
| `↑ Op-pil`     | Rul op           |
| `↓ Ned-pil`    | Rul ned          |
| `Cmd + ↑`      | Rul til toppen   |
| `Cmd + ↓`      | Rul til bunden   |
| `Cmd + =`      | Zoom ind         |
| `Cmd + -`      | Zoom ud          |

## Søgning

| Genvej             | Handling                                  |
| ------------------ | ----------------------------------------- |
| `Return`           | Udfør søgning                             |
| `Cmd + Return`     | Ryd søgning og fokusér input              |
| `Cmd + ↑`          | Rul resultater op                         |
| `Cmd + ↓`          | Rul resultater ned                        |
| `Cmd + Option + A` | Vælg alle omfangselementer                |
| `Cmd + Option + C` | Fravælg alle omfangselementer             |
| `Cmd + Option + B` | Bibel-søgetilstand                        |
| `Cmd + Option + O` | Bog-søgetilstand                          |
| `Cmd + Option + D` | Ordbog-søgetilstand (Forsker)             |
| `Cmd + Option + X` | Leksikon-søgetilstand (Forsker)           |

## Søgeresultater

| Genvej    | Handling                    |
| --------- | --------------------------- |
| `Cmd + S` | Åbn gem-alle-ark            |
| `Cmd + ↑` | Rul resultater op           |
| `Cmd + ↓` | Rul resultater ned          |

## Boglæser

| Genvej             | Handling                    |
| ------------------ | --------------------------- |
| `← Venstre pil`    | Forrige kapitel             |
| `→ Højre pil`      | Næste kapitel               |
| `Cmd + ↑`          | Forrige kapitel             |
| `Cmd + ↓`          | Næste kapitel               |
| `↑ Op-pil`         | Rul op                      |
| `↓ Ned-pil`        | Rul ned                     |
| `Cmd + B`          | Sæt bogmærke på nuværende kapitel |
| `Cmd + J`          | Åbn kapitelvælger           |
| `Cmd + L`          | Åbn stemmevælger            |
| `Cmd + T`          | Slå TTS til/fra             |
| `Cmd + Option + T` | Afspil / pause TTS          |

## Andagtslæser

| Genvej             | Handling                    |
| ------------------ | --------------------------- |
| `← Venstre pil`    | Forrige dag                 |
| `→ Højre pil`      | Næste dag                   |
| `↑ Op-pil`         | Rul op                      |
| `↓ Ned-pil`        | Rul ned                     |
| `Cmd + ↑`          | Rul op (stort)              |
| `Cmd + ↓`          | Rul ned (stort)             |
| `Cmd + D`          | Åbn datovælger              |
| `Cmd + T`          | Slå TTS til/fra             |
| `Cmd + Option + T` | Afspil / pause TTS          |

## AI-chat

| Genvej             | Handling                       |
| ------------------ | ------------------------------ |
| `Cmd + Return`     | Send besked                    |
| `Cmd + N`          | Ny chat                        |
| `Cmd + D`          | Slå samtaleskuffen til/fra     |
| `Cmd + Option + C` | Ryd nuværende chat             |
| `Cmd + S`          | Åbn gem-menu                   |
| `Escape`           | Luk skuffe / menu              |

## Bogmærker

| Genvej                        | Handling                                   |
| ----------------------------- | ------------------------------------------ |
| `↑ Op-pil` / `↓ Ned-pil`      | Vælg bogmærke                              |
| `Return`                      | Åbn bogmærke (tablet: vælg)                |
| `Cmd + R`                     | Læs bogmærke i kontekst                    |
| `Cmd + M`                     | Flyt valgt bogmærke til mapper             |
| `Cmd + N`                     | Administrer mapper                         |
| `Escape`                      | Luk detaljepanel / mappevælger             |

I **Gem i mappe**-vælgeren flytter `↑ Op-pil` / `↓ Ned-pil` valget, `Return` slår den valgte mappe til/fra eller aktiverer den fremhævede handling, og `Escape` lukker vælgeren. Rækken **+ Opret mappe** er øverst i listen.

## Bibelnoter

| Genvej                        | Handling                     |
| ----------------------------- | ---------------------------- |
| `↑ Op-pil` / `↓ Ned-pil`      | Vælg note                    |
| `Return`                      | Åbn note                     |
| `Cmd + Return`                | Fokusér filterinput          |
| `Escape`                      | Luk detalje / editor         |

## Fremhævninger

| Genvej                        | Handling                     |
| ----------------------------- | ---------------------------- |
| `↑ Op-pil` / `↓ Ned-pil`      | Vælg fremhævning             |
| `Return`                      | Åbn fremhævning              |
| `Cmd + Return`                | Fokusér filterinput          |
| `Escape`                      | Luk detaljepanel             |

## Bibelliste

| Genvej                                    | Handling                                     |
| ----------------------------------------- | -------------------------------------------- |
| `Tab` / `→ Højre pil` / `↓ Ned-pil`       | Næste Bibel                                  |
| `← Venstre pil` / `↑ Op-pil`              | Forrige Bibel                                |
| `Return`                                  | Åbn fokuseret Bibel                          |
| `Cmd + Shift + S`                         | Slå favorit til/fra for fokuseret Bibel      |
| `Escape`                                  | Gå tilbage                                   |

## Bibel-bøger-skærm

| Genvej                  | Handling                                |
| ----------------------- | --------------------------------------- |
| `Tab` / `→ Højre pil`   | Næste bog                               |
| `← Venstre pil`         | Forrige bog                             |
| `↓ Ned-pil`             | Bog under i gitteret                    |
| `↑ Op-pil`              | Bog over i gitteret                     |
| `Cmd + ↓`               | Næste sektion (GT / NT)                 |
| `Cmd + ↑`               | Forrige sektion (GT / NT)               |
| `Return`                | Åbn fokuseret bog                       |
| `Escape`                | Gå tilbage                              |

## Bogliste

| Genvej                                    | Handling          |
| ----------------------------------------- | ----------------- |
| `Tab` / `→ Højre pil` / `↓ Ned-pil`       | Næste bog         |
| `← Venstre pil` / `↑ Op-pil`              | Forrige bog       |
| `Return`                                  | Åbn fokuseret bog |
| `Escape`                                  | Gå tilbage        |

## Bibel-kapitler-skærm

| Genvej                                    | Handling                |
| ----------------------------------------- | ----------------------- |
| `Tab` / `→ Højre pil` / `↓ Ned-pil`       | Næste kapitel           |
| `← Venstre pil` / `↑ Op-pil`              | Forrige kapitel         |
| `Return`                                  | Åbn fokuseret kapitel   |
| `Escape`                                  | Gå tilbage              |

## Bog-kapitler-skærm

| Genvej                 | Handling                            |
| ---------------------- | ----------------------------------- |
| `Tab` / `↓ Ned-pil`    | Næste kapitel                       |
| `↑ Op-pil`             | Forrige kapitel                     |
| `Return`               | Åbn fokuseret kapitel               |
| `Cmd + Return`         | Fokusér søge-/filterinput           |
| `Escape`               | Gå tilbage                          |

## Andagtsliste

| Genvej                                    | Handling                      |
| ----------------------------------------- | ----------------------------- |
| `Tab` / `→ Højre pil` / `↓ Ned-pil`       | Næste andagt                  |
| `← Venstre pil` / `↑ Op-pil`              | Forrige andagt                |
| `Return`                                  | Åbn fokuseret andagt          |
| `Escape`                                  | Gå tilbage                    |

## Diagrammer

På Statistik-, Mål- og Koncordans-skærmene.

| Genvej          | Handling                                          |
| --------------- | ------------------------------------------------- |
| `← Venstre pil` | Vælg den forrige kategori i et diagram            |
| `→ Højre pil`   | Vælg den næste kategori i et diagram              |

Billedteksten under diagrammet følger valget, og den nye værdi oplæses.

## Hovedmenu (når den er åben)

| Genvej         | Handling                          |
| -------------- | --------------------------------- |
| `↑ Op-pil`     | Forrige menupunkt                 |
| `↓ Ned-pil`    | Næste menupunkt                   |
| `Return`       | Vælg fremhævet punkt              |
| `Escape`       | Luk menu                          |

## Indstillinger

| Genvej   | Handling                              |
| -------- | ------------------------------------- |
| `Escape` | Luk åben modal / vælger               |

## Editor-modaler

| Genvej    | Handling            |
| --------- | ------------------- |
| `Cmd + S` | Gem                 |
| `Escape`  | Annullér / luk      |

## Skrivnings-beskyttelse

Når du er fokuseret i et tekstfelt (søgeboks, noteeditor, AI-input), undertrykkes ikke-Cmd-genveje som piletaster og `Mellemrum`, så de ikke ved et uheld udløser navigation. Genveje, der bruger `Cmd`-tasten (f.eks. `Cmd + S`, `Cmd + B`), virker stadig, mens du skriver.
