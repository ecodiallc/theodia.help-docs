---
title: Ofte stillede spørgsmål
level: everyday
categories: faq
summary: Svar på de mest almindelige spørgsmål om brug af Theodia.
---

# Ofte stillede spørgsmål

## Koster Theodia noget?

Theodia er et engangskøb. Der er intet abonnement, ingen reklamer, ingen indkøb i appen og ingen anmodninger om donationer. Alle ekstra ressourcer i kataloget er gratis at downloade, efter du har købt appen.

## Behøver jeg en internetforbindelse?

Nej. Når appen og dens datafiler er installeret, virker alt offline. Du kan læse, søge, fremhæve, tage noter og bruge de fleste studieværktøjer uden signal.

Den eneste funktion, der behøver internettet, er download af nye ressourcer.

## Hvor gemmes mine data?

Alle dine bogmærker, fremhævninger, noter og indstillinger gemmes på din enhed. De uploades ikke til nogen server.

Du kan sikkerhedskopiere dem manuelt. Se guiden [Sikkerhedskopiering af dine data](theodia://help/backups) for hvordan.

## Kan jeg lytte til Bibelen?

Ja. Åbn et hvilket som helst kapitel, tryk på menuen, og vælg oplæsningsindstillingen. Din enhed skal have en tekst-til-tale-stemme installeret. Se guiden [Oplæsning](theodia://help/tts) for mere.

## Hvordan søger jeg efter et vers?

Du kan skrive en henvisning som `John 3:16` i Kommandoen på hjemskærmen, eller bruge fanen **Søg** til at søge efter ord eller frase.

## Hvordan rapporterer jeg en fejl eller foreslår en funktion?

Tryk på **Indsend forslag / problem** på Om-skærmen, [rapportér det på GitHub](https://github.com/ecodiallc/theodia.app/issues/new), eller besøg [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions)-siden.

## Hvilke enheder understøttes?

Theodia kører på iPhone, iPad og Android-telefoner og -tablets. Det virker bedst på enheder med mindst 2 GB ledig lagerplads til kernenes datafiler.

## Kan jeg bruge et eksternt tastatur?

Ja. Theodia understøtter Bluetooth- og USB-tastaturer på iPad. Navigation, søgning og mange læsefunktioner har tastaturgenveje. Se guiden [Eksterne tastaturgenveje](theodia://help/external-keyboard-shortcuts) for hele listen.

## Hvilke sprog understøttes?

Appens brugergrænseflade findes på engelsk, arabisk, kinesisk (forenklet og traditionelt), tjekkisk, dansk, hollandsk, filippinsk, fransk, tysk, græsk, hebraisk, hindi, indonesisk, italiensk, japansk, koreansk, polsk, portugisisk (Brasilien), rumænsk, russisk, spansk, swahili, svensk, thai, tyrkisk, ukrainsk og vietnamesisk.

Bibeltekstens sprog afhænger af, hvilke oversættelser du har installeret.

## Hvordan skifter jeg sprog?

Gå til **Indstillinger**, og se efter sprogindstillingen.

## Mit spørgsmål er ikke her. Hvor kan jeg få mere hjælp?

Gennemse resten af hjælpeguidene efter emne, eller stil et spørgsmål i [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions)-fællesskabet.

Tip: På **Hjælp & guider**-hovedskærmen kan du bruge søgeboksen til at skrive et emne som `notifications` eller `search` for at finde den matchende guide.
