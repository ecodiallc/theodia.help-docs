---
title: Læsning af dit første kapitel
level: beginner
categories: [start, read]
summary: En trin-for-trin-gennemgang af at åbne og læse et kapitel.
---

# Læsning af dit første kapitel

Denne guide fører dig gennem at åbne et kapitel for allerførste gang.

## Trin 1: Åbn Bibel-fanen

Kig i bunden af skærmen. Du ser en række faner. Tryk på den, der siger **Bibel**.

## Trin 2: Vælg en bog

Du ser en liste over Bibelens bøger. 1. Mosebog er først. Johannes er tæt på midten. Åbenbaringen er sidst.

Tryk på navnet på den bog, du vil have.

## Trin 3: Vælg et kapitel

Du ser tallene 1 op til det antal kapitler, bogen har. Tryk på det kapitel, du vil have.

Kapitlet åbner. Versene er på skærmen.

## Trin 4: Bevæg dig rundt

- Stryg til **venstre** for at gå til næste kapitel.
- Stryg til **højre** for at gå tilbage.

## Trin 5: Interagér med et vers

Hvad du kan gøre med et vers afhænger af din brugertilstand.

### Læser-tilstand

Læser-tilstand er ren og fri for afbrydelser.

- Tryk på et vers for kort at fremhæve det.
- Der er ingen studieværktøjer, bogmærker eller menuer.
- Hvis du vil have flere funktioner, så skift til **Standard**- eller **Forsker**-tilstand i **Indstillinger**.

### Standard-tilstand

Standard-tilstand tilføjer hverdagsfunktioner til personligt bibelstudium.

Tryk på et vers for at åbne en menu med disse valg:

- **Sæt bogmærke** på verset.
- **Fremhæv** det i en farve.
- **Tilføj en note** til det.
- **Kopiér** verseteksten.
- **Sammenlign** verset i en anden oversættelse.
- **Slå krydshenvisninger op** for verset.

### Forsker-tilstand

Forsker-tilstand låser op for alle værktøjer til dybt bibelstudium.

Tryk på et vers for at åbne en menu med alt fra Standard-tilstand, plus:

- **Kommentar** til verset.
- **Ordinfo** og opslag på originalsprogene.
- **Ordbogs**-definitioner.
- **AI-assistent** til dybere studium.

Du kan skifte tilstand når som helst i **Indstillinger**.

## Har du brug for hjælp til et bestemt værktøj?

Hvert værktøj har sin egen guide. Tryk på **Hjælp** på hjemmesiden for at se dem alle. Guiden [Studietilstand](theodia://help/study-mode) er et godt sted at starte — den går gennem hvert værktøj i versmenuen.

Hvis du stadig lærer, hvor tingene bor, så se guiden [App-layout og navigation](theodia://help/navigating-the-app). Den forklarer hjemskærmen, hovedmenuen og bundværktøjslinjen.

## Vil du have flere ressourcer?

Appen leveres med flere frit tilgængelige Bibelversioner. Hvis du vil tilføje flere, eller tilføje kommentarer, bøger eller andagter, så se guiden [Hentning af ekstra ressourcer fra GitHub](theodia://help/getting-core-files). Den viser dig, hvor du finder dem, og hvordan du tilføjer dem.
