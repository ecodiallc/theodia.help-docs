---
title: Fokustilstand
level: beginner
categories: [layout, read]
summary: En ren måde uden afbrydelser at læse lange passager på.
---

# Fokustilstand

> **Tilstand:** Fokustilstand er læseren i **Læser**-tilstand. Den er også tilgængelig i **Standard**- og **Forsker**-tilstand som et alternativ til Studietilstand. Du kan skifte tilstand i **Indstillinger** → **App-brugertilstand**.

Fokustilstand er en måde at læse et Bibelkapitel uden knapper eller menuer i vejen. Den er god til lange læsesessioner.

## Sådan slår du den til

1. Åbn et hvilket som helst kapitel.
2. I rækken af ikoner øverst på skærmen trykker du på 📖-knappen. Den åbner samme kapitel i Fokustilstand.
3. Menuerne og knapperne skjules. Kun Bibelteksten er tilbage.

I **Læser**-tilstand åbner kapitler automatisk i Fokustilstand. 📖-knappen er skjult, fordi der ingen Studietilstand er at skifte til.

## Hvad du kan gøre i Fokustilstand

- **Rul** for at læse.
- **Stryg** for at gå til næste eller forrige kapitel.
- **Tryk på 📖-knappen** i bundlinjen for at skifte tilbage til Studietilstand. (Skjult i Læser-tilstand.)
- **Tryk på 🔊-knappen** i bundlinjen for at få kapitlet læst op. En mini-ontrolbar vises med afspilning, pause, tilbage og frem og stemmevælger. (Skjult i Læser-tilstand — TTS kræver Standard eller Forsker.)

## En god brug af Fokustilstand

- At læse en hel bog igennem, ét kapitel ad gangen.
- At læse en lang passagen til en andagt eller stille tid.
- At læse op og følge med uden afbrydelser.

## Skift til Studietilstand

Fokustilstand skjuler hvert studieværktøj, men de er stadig ét tryk væk. Tryk på 📖-knappen øverst på skærmen for at åbne samme kapitel i [Studietilstand](theodia://help/study-mode). Studietilstand er den fulde læser, med kommentar, krydshenvisninger, leksikon-opslag og noter. For at lære, hvad Studietilstand kan, se guiden [Studietilstand](theodia://help/study-mode).

I **Læser**-tilstand er 📖-knappen skjult, fordi Studietilstand ikke er tilgængelig.
