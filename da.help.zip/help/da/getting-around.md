---
title: Kom hurtigt rundt
level: beginner
categories: layout
summary: Alle de hurtige måder at hoppe til et vers, et kapitel eller en skærm i Theodia.
---

# Kom hurtigt rundt

Denne guide er et snydeark til navigation. Den dækker hver hurtig måde at komme fra, hvor du er, til, hvor du vil hen.

## Hop direkte til et vers

Den hurtigste måde at åbne ethvert vers er **Kommandoen** på hjemskærmen.

- Skriv `John 3:16`, og tryk på Go.
- Skriv `Psalms 23`, og tryk på Go.
- Skriv `Genesis 1`, og tryk på Go.

Appen åbner det præcise kapitel (og ruller til verset, hvis du angav ét).

## Stryg mellem kapitler

Når du læser et kapitel:

- **Stryg til venstre** → næste kapitel.
- **Stryg til højre** → forrige kapitel.

Dette virker på tværs af bøger. Efter 2. Mosebog 40 fører en stryg til venstre dig til 3. Mosebog 1.

## Brug toplinjen

Mens du læser, viser toppen af skærmen den aktuelle **oversættelse**, **bog** og **kapitel**.

- Tryk på oversættelsesnavnet for at skifte Bibel.
- Tryk på bognavnet for at vælge en anden bog.
- Tryk på kapitelnummeret for at vælge et andet kapitel.

## Hop fra et bogmærke

Hvis du har gemt et vers:

1. Åbn fanen **Bogmærker**.
2. Tryk på et hvilket som helst punkt.
3. Du kommer direkte til det vers.

## Hop fra søgning

1. Åbn fanen **Søg**.
2. Skriv et ord eller en frase.
3. Tryk på et hvilket som helst resultat.
4. Appen åbner kapitlet med dine søgeord fremhævet i gult.

## Skift læselayouts

Bibel-læseren har to layouts:

- **Studietilstand** — viser kapitlet med alle studieværktøjer ét tryk væk.
- **Fokustilstand** — skjuler hvert værktøj og hver menu og efterlader kun teksten.

Sådan skifter du: tryk på **📖**-knappen øverst på skærmen, mens du læser. Tryk igen for at skifte tilbage. (Læser-tilstand forbliver altid i Fokustilstand.)

## Brug bundfanerne

Rækken af ikoner i bunden af skærmen er altid synlig. Tryk på en hvilken som helst fane for at skifte til den sektion. De præcise faner afhænger af din brugertilstand:

**Alle tilstande:**

- **Hjem** — tilbage til hjemskærmen.
- **Bibler** — liste over oversættelser.
- **Søg** — søg i Bibelen, bøger, ordbøger, leksika og PDF'er.
- **Indstillinger** — præferencer og ressourcer.

**Standard og Forsker ser også:**

- **Bogmærker** — gemte vers.
- **Fremhævninger** — farvemarkerede vers.
- **Noter** — dine private noter.
- **PDF'er** — dine importerede PDF-dokumenter.

**Forsker ser også:**

- **AI** — AI-assistenten (hvis slået til i Indstillinger).

### Husk, hvor du slap

Hver fane gemmer sin egen navigationshistorik. Når du skifter tilbage til en fane, vender du tilbage til **der, hvor du slap**, ikke startsalen for den sektion.

- Du åbner fanen **Bibler**, vælger en oversættelse, åbner et kapitel og skifter derefter til **Søg**. Senere trykker du på **Bibler** igen, og du er lige tilbage ved det samme kapitel.
- Du åbner fanen **Bogmærker**, trykker på et vers med bogmærke og skifter derefter til **Indstillinger**. Tryk på **Bogmærker** igen fører dig tilbage til bogmærkelisten.

Dette gælder for hver fane. Hver enkelt husker dit sted, indtil du eksplicit navigerer til en anden skærm inde i den fane.

### Hvad nulstiller en fane

En fane vender kun tilbage til sin rodskærm, når:

- Du allerede er på den fane, og du trykker på samme faneikon igen. Det er en hurtig måde at nulstille den til start på.
- Appen tvinges lukket og genåbnes.

### Bundfaner vs. hovedmenuen

- **Bundfaner** — hver fane gemmer sin egen stak. Tryk på en fane fører dig tilbage til, hvor du slap.
- **Hovedmenuen** — tryk på et punkt navigerer til den skærm. Det er en dropdown-liste, ikke et overlay.

Eksempel:

- Du læser Johannes 3. Tryk på fanen **Bogmærker**, og tryk derefter på **Bibler** igen. Du vender tilbage til Johannes 3.
- Du læser Johannes 3. Åbn menuen, og tryk på **Noter**. Gennemse dine noter, og tryk derefter på fanen **Bibler** for at vende tilbage til Johannes 3.

## Tips

- Hjemskærmen husker, hvilke sektioner der er foldet ud eller foldet sammen.
- Hvis en fane mangler, så tjek din **brugertilstand** i **Indstillinger** → **App-brugertilstand**. Læser-tilstand skjuler bogmærker, fremhævninger, noter og AI. Standard-tilstand skjuler AI. Du skal muligvis også slå en funktion til i **Indstillinger** eller installere en ressource.
