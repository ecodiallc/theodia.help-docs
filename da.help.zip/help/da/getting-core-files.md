---
title: Hentning af ekstra ressourcer
level: everyday
categories: resources
summary: Sådan tilføjer du Bibler, kommentarer, bøger og andre ressourcer til Theodia.
---

# Hentning af ekstra ressourcer

Theodia leveres med nogle ressourcer indbygget, men du kan tilføje flere. Den nemmeste måde er gennem **Administrer ressourcer**-skærmen inde i appen.

## Hvad du kan tilføje

- **Bibler** — flere oversættelser på forskellige sprog
- **Kommentarer** — studienoter, der forklarer vers
- **Bøger** — kristelige klassikere og opslagsværker
- **Andagter** — dagelige andagtslæsninger
- **Kernefiler** — større datafiler som morfologi, krydshenvisninger og Marvel Interlinear Bible (MIB)

## Sådan tilføjer du ressourcer inde fra appen

1. Åbn **Indstillinger**.
2. Tryk på **Administrer ressourcer**.
3. Vælg en fane: **Kerne**, **Bibler**, **Kommentarer**, **Bøger** eller **Andagter**.
4. Gennemse listen. Tryk på en ressource for at læse mere om den.
5. Tryk på afkrydsningsboksen for at vælge, hvad du vil have.
6. Tryk på **Download** i bunden. Filerne downloades og installeres automatisk.

Når de er installeret, vises ressourcen i appen med det samme. Du behøver ikke genstarte.

## Kernefiler

Fanen **Kerne** har store datafiler, der driver dybere studiefunktioner. Disse inkluderer:

- Morfologidata (ordformer på originalsprogene)
- Krydshenvisningsdatabaser
- Marvel Interlinear Bible (MIB)

Du behøver kun at downloade kernefiler én gang. De forbliver på din enhed og virker offline.

## Globale Bibler

Fanen **Globale Bibler** har Bibeloversættelser fra en bredere samling. Hvis du ikke ser en oversættelse, du ønsker, i hovedfanen **Bibler**, så tjek her.

## Administration af installerede ressourcer

På hovedskærmen **Administrer ressourcer** (ikke download-fanen) kan du:

- **Slå en ressource til eller fra** uden at slette den. Slukkede ressourcer forbliver på din enhed, men er skjult i menuerne.
- **Slette** en ressource for at frigøre plads. Du kan downloade den igen senere.

## Tilføjelse af dine egne filer

Hvis du har en ressourcefil fra et andet sted — en ven, et andet projekt eller et websted — kan du importere den direkte:

1. I **Administrer ressourcer** trykker du på **Importér lokal fil**.
2. Vælg filen fra din enhed.
3. Appen læser filen og tilføjer den til dit bibliotek.

Appen accepterer disse filtyper:

- `.bible` — Bibeloversættelser
- `.commentary` — kommentarer
- `.lexicon` — leksika
- `.book` — bøger
- `.devotional` — andagter

## Tilslutning af et brugerdefineret GitHub-depot

Hvis nogen vedligeholder et GitHub-depot med Theodia-kompatible ressourcer, kan du tilføje det som en brugerdefineret kilde:

1. Gå til **Indstillinger → GitHub-depoter**.
2. Tryk på **Tilføj depot**.
3. Indtast GitHub-URL'en (f.eks. `https://github.com/username/repo-name`).
4. Vælg, hvilke typer ressourcer depotet indeholder (Bibler, kommentarer eller bøger).
5. Gem det.
6. Vend tilbage til **Administrer ressourcer**. En ny fane vises med ressourcerne fra det depot.

Hvis depotet er privat, skal du tilføje en **Personal Access Token** i **Indstillinger → GitHub-depoter**, så appen kan læse det.

## En note om filstørrelser

Ressourcefiler kan være store. Bibler er normalt små (et par megabyte). Kommentarer og kernefiler kan være meget større (hundredevis af megabyte). Download over Wi-Fi, når det er muligt.

## Opsummering

- Brug **Indstillinger → Administrer ressourcer** til at gennemse og installere ressourcer.
- Kernefiler låser op for dybere studieværktøjer som morfologi og krydshenvisninger.
- Importér lokale filer, hvis du har dine egne.
- Tilføj brugerdefinerede GitHub-depoter, hvis du vil have ressourcer fra en anden kilde.
