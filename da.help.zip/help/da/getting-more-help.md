---
title: Hvor stiller jeg spørgsmål
level: everyday
categories: trouble
summary: Sådan får du hjælp fra Theodia-teamet og fællesskabet, og hvordan du finder hjælpeemner inde i appen.
---

# Hvor stiller jeg spørgsmål

Hvis du er kørt fast, er der et par steder at bede om hjælp.

## At finde et hjælpeemne

Hvis du leder efter oplysninger om en bestemt funktion, så prøv en af disse veje:

- **Gennemse efter kategori.** Åbn **Hjælp & guider**, og tryk på en kategori som **Indstillinger & tilpasning** eller **Fejlfinding**. Hvert kort viser relaterede guider.
- **Søg efter nøgleord.** På hovedskærmen **Hjælp & guider** skriver du et ord i søgeboksen øverst. For eksempel viser skrivning af `notifications` guiden [Notifikationer og påmindelser](theodia://help/notifications); skrivning af `search` viser guiden [Søgning i Bibelen](theodia://help/search-the-bible).
- **Tjek Indstillinger først.** Mange funktioner konfigureres i **Indstillinger**. Hvis du vil oprette påmindelser, så åbn **Indstillinger** → **Notifikationer**. Indstillingsskærmen har også et **Hjælp**-link for hver sektion.

## Inden i appen

Åbn **Om**-skærmen. Du ser to knapper:

- **Indsend forslag / problem** — åbner en formular til at sende teamet et spørgsmål, en idé eller en fejlrapport.
- **Diskussion / feedback** — åbner fællesskabets diskussionsbræt.

## GitHub-siden

Du kan se listen over kendte problemer og nylige ændringer på [GitHub](https://github.com/ecodiallc/theodia.app).

## Fællesskabsdiskussion

Andre, der bruger Theodia, stiller spørgsmål og deler tips på [fællesskabets diskussionsbræt](https://github.com/ecodiallc/theodia.app/discussions). Du kan læse gamle tråde og starte en ny.

## Før du spørger

Et par ting hjælper os med at svare dig hurtigere:

- **Hvad er din enhed?** (f.eks. iPhone 13, Pixel 7)
- **Hvilken version af appen?** (Åbn **Om** for at se.)
- **Hvad gjorde du?** En kort beskrivelse af trinene.
- **Hvad skete der?** Hvad du så på skærmen.
- **Hvad forventede du, skulle ske?** Det er ofte den mest nyttige del.

## Hvad du kan forvente

- For fejlrapporter svarer teamet normalt inden for et par dage.
- For idéer læser teamet dem alle. Vi kan ikke love, hvornår en idé bliver tilføjet.
- For fællesskabsspørgsmål svarer andre brugere ofte hurtigere end teamet.

## En note om privatliv

Når du indsender et spørgsmål, så medtag venligst ikke private oplysninger. Teamet kan se, hvad du sender.
