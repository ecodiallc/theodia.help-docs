---
title: GitHub Models
categories: ai
level: advanced
summary: Sæt GitHub Models op — en gratis måde at begynde at udforske AI i Theodia uden et eksisterende API-abonnement.
---

# GitHub Models

> **Tilstand:** AI-assistenten kræver **Forsker**-tilstand. Du kan skifte tilstand i **Indstillinger** → **App-brugertilstand**.

Hvis du ikke allerede betaler for en AI-tjeneste, er **GitHub Models** den nemmeste måde at begynde at udforske Theodias AI. Det tillader en gratis start, og alt, du behøver, er en gratis GitHub-konto.

## Hvad er GitHub Models?

GitHub Models er en tjeneste fra GitHub, der lader dig køre moderne AI-modeller gennem en API. Den understøtter samme format som OpenAI, så den fungerer gnidningsfrit med Theodia.

## Hvorfor vælge GitHub Models?

- **Intet kreditkort påkrævet** — Bare en GitHub-konto.
- **Modeller af høj kvalitet** — Du får adgang til GPT-4o, GPT-4.1 og andre pålidelige modeller, der understøtter Theodias værktøjer.
- **Nem opsætning** — Én token, én URL, og du er færdig.

## Trin 1: Opret en GitHub-konto

Hvis du allerede har en GitHub-konto, så spring videre til Trin 2.

1. Gå til [github.com](https://github.com).
2. Tryk på **Sign up**, og følg anvisningerne for at oprette en gratis konto.
3. Verificér din e-mail-adresse, når GitHub sender bekræftelsen.

## Trin 2: Opret en Personal Access Token

Denne token er din API-nøgle. Den fortæller GitHub, hvem du er, når Theodia sender spørgsmål.

1. Gå til [github.com/settings/tokens](https://github.com/settings/tokens).
2. Tryk på **Generate new token**, og vælg **Generate new token (classic)**.
3. Giv tokenen et navn som **Theodia AI**.
4. Under **Select scopes** afkrydses boksen for **`models:read`**.
   - Det er den eneste tilladelse, Theodia behøver.
5. Rul til bunden, og tryk på **Generate token**.
6. **Kopiér tokenen straks.** GitHub viser den kun én gang. Indsæt den et sikkert sted (f.eks. i din telefons notat-app), indtil du tilføjer den i Theodia.

## Trin 3: Vælg en model

GitHub Models tilbyder flere modeller. Til Theodia er disse de bedste valg:

| Model                  | Daglig gratis grænse | Bedst til                                             |
| ---------------------- | -------------------- | ----------------------------------------------------- |
| `openai/gpt-4.1-nano`  | 150 forespørgsler / dag | Hurtige spørgsmål og simple versforklaringer      |
| `openai/gpt-4.1-mini`  | 150 forespørgsler / dag | Generelt studium med god værktøjsunderstøttelse   |
| `openai/gpt-4.1`       | 50 forespørgsler / dag   | Dybere studium og komplekse flertrins-spørgsmål   |
| `openai/gpt-4o`        | 50 forespørgsler / dag   | Alsidig, fremragende værktøjsunderstøttelse       |

Start med **`openai/gpt-4.1-mini`** — den er hurtig, pålidelig og tilbyder en højere daglig grænse.

## Trin 4: Konfigurér Theodia

1. Åbn **Theodia**.
2. Gå til **Indstillinger** → **AI-assistent**.
3. Sørg for, at **Fjern model** er valgt.
4. Tryk på **Udbyder**-dropdownen, og vælg **GitHub Models**.
   - Hvis GitHub Models ikke er i listen, tryk på **Brugerdefineret** og indtast basis-URL'en manuelt: `https://models.github.ai`
5. Indsæt din GitHub Personal Access Token i feltet **API-nøgle**.
6. Indtast dit valgte model-id i feltet **Model** (f.eks.: `openai/gpt-4.1-mini`).
7. Tryk på **Test forbindelse**.
8. Vent på, at tjekket slutter. Du bør se:
   - **✓ Forbindelsen lykkedes**
   - **✓ Værktøjer understøttet**

Hvis du ser **✗ Værktøjer ikke understøttet**, så prøv et andet model-id fra tabellen ovenfor.

## Trin 5: Begynd at chatte

1. Tryk på **AI**-fanen nederst på skærmen.
2. Skriv et spørgsmål, og tryk på **Send**.
3. Eller, mens du læser et hvilket som helst Bibelkapitel, trykker du på et versnummer og vælger **AI-kommentar** for at starte en vers-specifik chat.

## Fejlfinding

### "Forbindelsen mislykkedes" eller "HTTP 401"

- Sørg for, at du kopierede **hele** tokenen. Det er en lang streng, der starter med `ghp_`.
- Tokens udløber, hvis de ikke bruges i lang tid. Gå tilbage til GitHub, og generér en ny.
- Tjek, at du valgte **models:read**, da du oprettede tokenen.

### "Værktøjer ikke understøttet"

- Nogle modeller på GitHub Models accepterer ikke værktøjskald. Prøv i stedet **`openai/gpt-4o`** eller **`openai/gpt-4.1-mini`**.
- Sørg for, at model-id'et er stavet præcis som vist, inklusive `openai/`-præfikset.

### Fejl ved rategrænse

- Hvis du rammer den daglige grænse, så skift til en model med en højere kvote (f.eks. `openai/gpt-4.1-nano` med 150 forespørgsler pr. dag).
- Grænserne nulstilles hver 24. time.

## Opsummering

- GitHub Models er den **anbefalede måde at begynde at udforske AI** i Theodia.
- Du behøver en **gratis GitHub-konto** og en **Personal Access Token** med `models:read`.
- Den bedste startmodel er **`openai/gpt-4.1-mini`**.
- Indtast tokenen og modellen i **Indstillinger → AI-assistent**, tryk på **Test forbindelse**, og begynd at chatte.
