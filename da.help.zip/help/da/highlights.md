---
title: Fremhævning af vers
level: everyday
categories: [annotate, read]
summary: Sådan markerer du vers i farve og finder dem senere.
---

# Fremhævning af vers

> **Tilstand:** Fremhævninger er tilgængelige i **Standard**- og **Forsker**-tilstand. Fokustilstand er kun til ren læsning uden afbrydelser. Du kan skifte tilstand i **Indstillinger** → **App-brugertilstand**.

Fremhævning markerer et vers i en farve. Det virker som en gul markør på papir. Verset forbliver fremhævet, næste gang du åbner det.

## Sådan fremhæver du et vers

1. Åbn verset.
2. Tryk på verset for at få menuen frem.
3. Tryk på **Fremhæv**-ikonet.
4. Vælg en farve.

Verset er nu fremhævet i den farve.

## Sådan ændrer du fremhævningsfarven

1. Åbn verset.
2. Tryk på verset, og tryk derefter på **Fremhæv**-ikonet.
3. Vælg en ny farve.

## Sådan fjerner du en fremhævning

1. Åbn verset.
2. Tryk på verset, og tryk derefter på **Fremhæv** i menuen.
3. Tryk på **Fjern fremhævning** i bunden af farvevælgeren.

## En almindelig måde at bruge farver på

Mange læsere bruger et lille sæt farver til et lille sæt formål:

- **Gul** til generelle favoritter.
- **Grøn** til vers om Gud.
- **Blå** til vers om bøn.
- **Pink** til vers om trøst.
- **Orange** til vers om advarsel eller irettesættelse.
- **Lilla** til vers om profeti eller endetiden.

Vælg et system, der virker for dig.

## Sådan ser du alle dine fremhævninger

Tryk på fanen **Fremhævninger** nederst. Du ser en liste over hvert vers, du har fremhævet, nyeste først. Der er en række farvechips øverst — tryk på en farve for at vise kun fremhævninger i den farve, eller tryk på **Alle** for at rykke filteret.

## Import af fremhævninger

Du kan bringe fremhævninger ind i Theodia fra andre apps og filer.

Gå til **Indstillinger** → **Bogmærker** → **Importér fremhævninger**. Vælg **Importér fra fil**, eller indsæt fra udklipsholderen. Appen genkender automatisk formatet.

### Understøttede formater

**Indbygget JSON-eksport** — Formatet, der bruges af Theodias egen eksportfunktion:

```json
{
  "/bible/KJV/John/3#v3_16": "yellow",
  "/bible/KJV/Genesis/1#v1_1": "green"
}
```

**CSV** — Et regneark med kolonnerne `url` og `color`. Eksempel:

```csv
url,color
/bible/KJV/John/3#v3_16,yellow
/bible/KJV/Genesis/1#v1_1,green
```

**Almindelig tekst** — Hver linje er en Bibelhenvisning eller URL, valgfrit efterfulgt af et farvenavn. Eksempel:

```
John 3:16 yellow
Genesis 1:1 green
Matthew 5:1
```

- Tilgængelige farver: `yellow`, `green`, `blue`, `pink`, `orange`, `purple`.
- Hvis ingen farve er angivet, går fremhævningen som standard til gul.
- Linjer, der starter med `#` eller `//`, behandles som kommentarer og springes over.

## Tips

- Fremhævninger forbliver på din enhed. De synkroniseres ikke til cloud.
- Du kan fremhæve et vers i én oversættelse og lade det vise sig i dine andre oversættelser af samme vers.
- Se guiden [Sikkerhedskopiering af dine data](theodia://help/backups) for at holde dem i sikkerhed.
