---
title: Installation af Bibeloversættelser
level: beginner
categories: start
summary: Sådan tilføjer du en Bibeloversættelse til dit bibliotek.
---

# Installation af Bibeloversættelser

Theodia leveres med et par Bibeloversættelser klar til læsning. Du kan tilføje flere når som helst. En "oversættelse" er en anden version af Bibelteksten, som King James Version.

## Sådan tilføjer du en oversættelse

Bibel-fanen viser en liste over oversættelser, der allerede er installeret. For at tilføje flere, åbner du ressourceadministratoren:

1. Åbn **Indstillinger**.
2. Tryk på **Administrer ressourcer**.
3. Tryk på **Installér fra GitHub**.
4. I download-vinduet trykker du på fanen **Bibler**.
5. Tryk på afkrydsningsboksen ved siden af hver oversættelse, du vil have.
6. Tryk på **Installér valgte** i bunden.
7. Vent til downloaden er færdig.

Oversættelsen er nu i dit bibliotek. For at se den, åbn **Bibel**-fanen.

## Sådan skifter du mellem oversættelser

1. Åbn et kapitel, du vil læse.
2. Tryk på oversættelsesnavnet øverst på skærmen.
3. Vælg den, du vil have, fra listen.

Appen gemmer dit valg til næste gang.

## Sådan fjerner du en oversættelse

1. Åbn **Indstillinger**.
2. Tryk på **Administrer ressourcer**.
3. Find den oversættelse, du vil fjerne.
4. Tryk på **X** ved siden af den.
5. Bekræft, at du vil fjerne den.

Fjernelse af en oversættelse sletter ikke dine noter, fremhævninger eller bogmærker. De forbliver i sikkerhed.

## Hvor meget plads bruger oversættelser?

De fleste oversættelser er mellem 2 og 10 MB. De gemmes på din enhed, ikke i cloud. Du kan beholde så mange, du vil, så længe din enhed har plads.

## Hvad hvis en oversættelse ikke er i appen?

Nogle oversættelser er ikke i listen i appen. Du kan stadig tilføje dem.

1. Åbn appen, og gå til **Indstillinger** → **Administrer ressourcer**.
2. Tryk på **Installér fra GitHub**.
3. I download-vinduet kigger du på fanen **Bibler** og fanen **Globale Bibler**. Hvis din oversættelse er der, vælg den, og tryk på **Installér valgte**.
4. Hvis den ikke er, tryk på **Installér lokal fil** for at importere en `.bible`-fil. Få filen fra projektets GitHub-side. Se guiden [Hentning af ekstra ressourcer fra GitHub](theodia://help/getting-core-files) for trin-for-trin-hjælp.
