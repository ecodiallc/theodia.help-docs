---
title: Tilføjelse af kernefilerne
level: beginner
categories: start
summary: Sådan downloader du de store datafiler, appen behøver for at studere Bibelen i dybden.
---

# Tilføjelse af kernefilerne

Theodia leveres med en Bibel og et par små ekstrafiler klar til brug. For at få mest ud af appen skal du også downloade **kernefilerne**. Det er store datafiler, der tilføjer studieværktøjer som en kommentar, ordopslag og grammatiknoter. Uden dem virker appen, men studiefunktionerne er begrænsede.

## Hvorfor du behøver kernefilerne

Kernefilerne tilføjer:

- **Ordopslag.** Tryk på et ord i et hvilket som helst vers for at se det oprindelige hebraiske eller græske og hvad det betyder.
- **Kommentar.** AI-kommentar til hvert vers.
- **Grammatik.** Oplysninger om hvert ord på originalsproget.
- **Interlineær Bibel.** Læs teksten på originalsproget med engelsk under hvert ord.

Du kan læse Bibelen uden dem, men de fleste studieværktøjer behøver dem.

## Sådan installerer du kernefilerne

**[Installér kernefiler](theodia://manage/core)**

1. Åbn **Indstillinger**.
2. Tryk på **Administrer ressourcer**.
3. Fanen **Kerne** åbner. Du ser en liste over kernefilerne. Hver har et navn, en størrelse og en afkrydsningsboks.
4. Tryk på hver fil, du vil installere. Et flueben viser, at den er valgt.
5. Tryk på **Installér valgte**.
6. Vent på, at filerne downloader og installerer. De er store, så det kan tage et par minutter på en langsom forbindelse.

Filerne downloader til din enhed. Du behøver kun at gøre dette én gang. Appen bruger filerne herefter, selv når du er offline.

## Tips

- Brug Wi-Fi. Filerne er store.
- Slut din telefon eller tablet til strøm. Store downloads bruger batteri.
- Hvis en download fejler, tryk på filen igen for at prøve igen.
- Du kan installere alle eller kun dem, du behøver.

## Hvad hvis en fil mangler i listen?

Appen henter listen fra projektets GitHub-side. Hvis listen er tom, tjek din internetforbindelse, og prøv igen. Hvis den stadig er tom, se guiden [Hvor stiller jeg spørgsmål](theodia://help/getting-more-help).

For mere avancerede måder at tilføje ressourcer på, se guiden [Hentning af ekstra ressourcer fra GitHub](theodia://help/getting-core-files).
