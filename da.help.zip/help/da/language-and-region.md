---
title: Appsprog og region
level: everyday
categories: settings
summary: Sådan ændrer du appens sprog.
---

# Appsprog og region

Theodia findes på mange sprog. Appen kan ændre sproget i menuer og knapper. Hjælpeindhold er også tilgængeligt på mange af disse sprog og er indbygget i appen. Du kan også downloade eller opdatere et sprogs hjælpepakke — åbn **Indstillinger** → **Hjælp** eller **Administrer ressourcer** → **Installér fra GitHub** → **Hjælp-dokumenter**.

## Sådan åbner du sprogindstillingerne

1. Åbn **Indstillinger**.
2. Tryk på **Sprog**.

## Sådan ændrer du appsproget

1. I **Sprog**-listen trykker du på det sprog, du vil have.
2. Appen anvender det nye sprog straks.

De valg, du ser, afhænger af de sprog, appen understøtter.

## Sådan vælges sproget ved første installation

Når du først installerer Theodia, vælger appen et sprog baseret på din enheds indstillinger. Du kan ændre det når som helst.

## Hvad oversættes

- Menuer, knapper og mærkater.
- Indstillingsskærme.
- Fejlmeddelelser.
- Søge- og studieværktøjer.

## Hvad kun findes på engelsk

- Noget bog- og andagtsindhold.

## Bibeloversættelser og appsprog

Appsproget og Bibeloversættelsens sprog er to forskellige ting. Du kan have appen på spansk og Bibelen på engelsk, eller omvendt.

For at ændre Bibeloversættelsen, se guiden [Installation af Bibeloversættelser](theodia://help/installing-bibles).

## Tips

- Hvis en knap eller mærkat er tom, mangler appen en oversættelse. Den engelske version er normalt der som reserve.
- Hvis du gerne vil hjælpe med at oversætte appen, se guiden [Hvor stiller jeg spørgsmål](theodia://help/getting-more-help).
