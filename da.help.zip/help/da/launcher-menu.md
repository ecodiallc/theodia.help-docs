---
title: Launcher-menuen
level: everyday
categories: layout
summary: En hurtig måde at hoppe til seneste vers, køre kommandoer og skifte Bibel-layout uden at forlade din nuværende skærm.
---

# Launcher-menuen

> **Tilstand:** Launcher-menuen kræver **Forsker**-tilstand. Du kan skifte tilstand i **Indstillinger** → **App-brugertilstand**.

Launcher-menuen er et hurtigadgangspanel, du kan åbne fra næsten hvor som helst i appen. Den holder dine seneste vers, kommandoer og gemte Bibel-opsætninger ét sted.

## Sådan åbner du den

Tryk på **udvid-ikonet (⌄)** i øverste højre hjørne af hjemskærmens sidehoved. Et panel glider ind ovenfra.

## Hvad der er indeni

### 1. Kommandoboks

Øverst i panelet er et tekstfelt med et tastaturikon. Skriv en kommando, og tryk på **Go** på dit tastatur. Appen læser kommandoen og fører dig direkte derhen.

Eksempler:

- `John 3:16` — åbner det vers.
- `search love` — søger i Bibelen efter "love".
- `bookmark psalms 23` — sætter bogmærke på verset.
- `kjv` — skifter til KJV-oversættelsen.

For hele kommandolisten, se guiden [Kommandoer](theodia://help/commands).

### 2. Parallelle sæt

Hvis du har gemt parallelle Bibel-forudindstillinger, vises de her som en sammenklappelig liste. Tryk på én for straks at indlæse den parallelle opsætning.

Sådan opretter du en parallel forudindstilling:

1. Åbn **Indstillinger** → **Parallel Bibel**.
2. Tilføj oversættelser, og tryk på **Gem forudindstilling**.
3. Giv den et navn. Den vises i Launcher-menuen.

Hold et parallelt sæt inde længe i Launcher-menuen for at slette det.

### 3. Bibelsamlinger

Bibelsamlinger er genveje med ét tryk, der skifter din oversættelse og parallelvisning på samme tid. Hvis du har oprettet nogle, vises de her som en sammenklappelig liste.

Hold en samling inde længe for at slette den.

### 4. Funktionsikoner

Under kommandoboksen kan du se en række runde emoji-knapper. Det er genveje med ét tryk til appens vigtigste funktioner.

Tilgængelige ikoner inkluderer:

- **Om**, **Bibler**, **Bibelnoter**, **Bogmærker**, **Bøger**
- **Andagter**, **Flashcards**, **Hjælp**, **Fremhævninger**
- **Playlister**, **Plugins**, **Søg**, **Indstillinger**, **Theoscript**

Sådan vælger du, hvilke ikoner der vises, og i hvilken rækkefølge:

1. Åbn **Indstillinger** → **Launcher-menu**.
2. Tryk på **Launcher-menu-ikoner**.
3. Brug kontakterne til at vise eller skjule hvert ikon.
4. Brug op/ned-pilerne til at omorganisere dem, du har slået til.

Rækkefølgen i indstillingerne er rækkefølgen, de vises i Launcher-menuen.

### 5. Seneste vers

Appen husker de sidste kapitler og vers, du åbnede. De vises som en liste i bunden af panelet. Tryk på et hvilket som helst punkt for at hoppe lige tilbage til det.

- **Tryk** for at åbne.
- **Stryg til venstre** eller **hold inde længe** for at fjerne fra listen.
- Tryk på **Ryd alle** for at fjerne hvert punkt på én gang.

## Hvornår skal man bruge Launcher-menuen

Brug den, når du vil:

- Hoppe tilbage til et vers, du lige har læst.
- Skrive en kommando uden at gå til hjemskærmen.
- Skifte oversættelse eller parallel opsætning i ét tryk.
- Åbne en hovedfunktion fra hvor som helst i appen.
- Tjek noget hurtigt uden at navigere gennem menuer.

## Tips

- Launcher-menuen er tilgængelig på næsten hver skærm, så du kan åbne den, mens du læser et kapitel.
- Kommandoboksen understøtter de samme kommandoer som kommandoboksen på hjemskærmen.
- Funktionsikoner og deres rækkefølge gemmes lokalt på din enhed. De overlever app-genstarter.
- Seneste vers gemmes lokalt på din enhed. De overlever app-genstarter.
