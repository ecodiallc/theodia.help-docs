---
title: Navigation mellem bøger, kapitler og vers
level: everyday
categories: [layout, read]
summary: Sådan bevæger du dig rundt i Bibelen og hopper til, hvor du vil hen.
---

# Navigation mellem bøger, kapitler og vers

Denne guide viser dig alle måderne at bevæge dig rundt i Bibelen.

## Den lette måde: stryg

- Stryg til **venstre** på et kapitel for at gå til næste kapitel.
- Stryg til **højre** for at gå tilbage.
- Dette virker også for næste bog. Efter det sidste kapitel i, lad os sige, 2. Mosebog, fører stryget dig til første kapitel i 3. Mosebog.

## Menu-måden

- Tryk på oversættelsesnavnet øverst for at skifte til en anden Bibel.
- Tryk på bognavnet øverst for at vælge en anden bog.
- Tryk på kapitelnummeret for at vælge et andet kapitel.

## Den hurtige måde: skriv

- På hjemmesiden er der en boks øverst. Skriv en henvisning, som `John 3:16` eller `psalms 23`, og tryk på **Go**-tasten på tastaturet.
- Appen åbner verset.

## Bogmærke-måden

Hvis du har gemt et vers, åbn fanen **Bogmærker**. Tryk på et hvilket som helst punkt for at hoppe til det.

## Søge-måden

Tryk på fanen **Søg**. Skriv et ord. Appen viser dig hvert vers, der har det. Tryk på et hvilket som helst resultat for at åbne det.

## Historik-måden

Appen husker de kapitler, du har åbnet. For at finde dem igen, kig i fanen **Bogmærker** (for de vers, du gemte), eller rul boglisten i **Bibel**-fanen for at finde en bog, du læste for nylig.

## Tips

- Bibel-fanen viser bøgerne i rækkefølge fra 1. Mosebog til Åbenbaringen.
- For Salmerne, Ordsproene og andre lange bøger, tryk på bogen og brug kapitellisten til at hoppe langt frem.
