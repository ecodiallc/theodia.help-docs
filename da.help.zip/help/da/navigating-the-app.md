---
title: App-layout og navigation
level: beginner
categories: layout
summary: En tur rundt på hjemskærmen, hovedmenuen og bundværktøjslinjen — hvor alt bor.
---

# App-layout og navigation

Theodia har tre hovedområder, du kan bevæge dig mellem: **hjemskærmen**, **hovedmenuen** og **bundværktøjslinjen**. Denne guide gennemgår hver enkelt, så du altid ved, hvor du skal hen.

## Et hurtigt kort

- **Hjemskærmen** er den side, du ser, når du først åbner appen. Den har en søgeboks, store knapper til hver del af appen og en liste over dine installerede Bibler, bøger og andagter.
- **Bundværktøjslinjen** (også kaldet fanefeltet) er rækken af ikoner i bunden af skærmen. Tryk på et af dem for at hoppe direkte til den del af appen.
- **Hovedmenuen** er ikonen med tre linjer (☰) i øverste højre hjørne af hjemskærmen. Tryk på den for at åbne en liste over hver skærm i appen, også dem, der ikke har deres egen fane.

## Hjemskærmen

Når du først åbner Theodia, lander du på hjemskærmen. Den er opdelt i fire dele, ovenfra og ned.

### Sidehovedet

Allerøverst er en farvet bjælke. Til venstre er app-ikonet og navnet "Theodia". Til højre er hovedmenu-knappen (☰). Når du er inde i en bog eller et kapitel, viser venstre side en tilbage-knap (←) i stedet. Tryk på hovedmenuen for at åbne menuen (se nedenfor).

### Kommandoen

Lige under sidehovedet er et søgefelt-mæssigt tekstfelt mærket **Kommando**. Skriv en kort instruktion, og tryk på go-tasten på dit tastatur. Appen læser instruktionen og fører dig til den rigtige skærm. Eksempler:

- `psalms 23` — åbner Salmerne kapitel 23
- `john 3:16` — åbner Johannes 3,16
- `search love` — søger i Bibelen efter "love"
- `bookmark john 3:16` — gemmer Johannes 3,16 som bogmærke
- `commentary romans 8:28` — åbner kommentaren til det vers
- `xref` (efterfulgt af en henvisning) — åbner krydshenvisningerne for det vers
- `help` — åbner kommandolisten med eksempler

Hvis appen ikke forstår, hvad du skrev, viser den en lille advarsel med et hint. Se guiden **Almindelige problemer**, hvis kommandoer ikke virker.

### Knapgitteret

Under Kommandoen er et gitter af store knapper, to pr. række. Hver knapper fører dig til en anden del af appen. Knapperne er:

- 📖 **Bibler** — din liste over Bibeloversættelser
- 🔍 **Søg** — søg i Bibelen efter et ord eller en frase
- 📚 **Bøger** — dit bibliotek af kristelige klassikere
- 📅 **Andagter** — dagelige andagter
- 🔖 **Bogmærker** — dine gemte vers og kapitler
- 🖍 **Fremhævninger** — dine farvemarkerede vers
- 📝 **Noter** — dine private noter om vers
- ⚙️ **Indstillinger** — sprog, tema, ressourcer og mere
- ❓ **Hjælp** — hjælpesystemet (denne side)
- ℹ️ **Om** — appversion og kredittering

### Ressourcelisterne

Under knapgitteret er sammenklappelige sektioner: **Bibler**, **Bøger** og **Andagter**. Hver sektion viser de punkter, du har installeret. Tryk på en sektionsoverskrift for at folde den ud eller sammen. Tryk på et hvilket som helst punkt i en sektion for at åbne det.

Bibler-sektionen er den hurtigste måde at hoppe ind i en bestemt oversættelse — ingen menuer, bare tryk.

## Bundværktøjslinjen

Bundværktøjslinjen (fanefeltet) er rækken af ikoner i bunden af skærmen. Den forbliver synlig næsten alle steder i appen, så du kan altid hoppe til en anden sektion. Fanerne, du ser, afhænger af din brugertilstand.

**Alle tilstande ser:**

- 🏠 **Hjem** — åbner hjemskærmen
- 📖 **Bibler** — åbner din liste over Bibeloversættelser
- 📚 **Bøger** — åbner dit bogbibliotek
- 🔍 **Søg** — åbner Bibelsøgning
- ⚙️ **Indstillinger** — åbner indstillinger

**Standard- og Forsker-tilstand ser også:**

- 🔖 **Bogmærker** — åbner dine gemte vers
- 🖍 **Fremhævninger** — åbner dine farvemarkerede vers
- 📝 **Noter** — åbner dine private noter

**Forsker-tilstand ser også:**

- 💻 **AI** — åbner AI-assistenten (hvis du har slået den til i Indstillinger)

Den aktuelle fane er fremhævet. Tryk på enhver anden fane for at skifte.

### Sådan opfører værktøjslinjen sig

Hver fane i værktøjslinjen har sin egen **stak** af skærme. Når du trykker på en fane, vender du tilbage til **der, hvor du slap** i den fanes stak, ikke startsalen. For eksempel:

- Tryk på **Bibler** → du ser listen over Bibeloversættelser.
- Tryk på en oversættelse → du ser listen over bøger.
- Tryk på en bog → du ser listen over kapitler.
- Tryk på et kapitel → du læser kapitlet.
- Skift til **Bogmærker** for at tjekke noget.
- Tryk på **Bibler** igen → du vender tilbage til kapitlet, du læste.

Hver fane husker dit sted. Appen gemmer din navigationshistorik inde i hver fane, så skift mellem faner ikke mister din fremdrift.

### Hvad nulstiller en fane

En fane nulstilles kun til sin rodskærm, når:

- Du allerede er på den fane, og du trykker på samme faneikon igen. Det er en hurtig måde at gå tilbage til starten på.
- Appen tvinges lukket og genåbnes.

### Bundfaner vs. hovedmenuen

- **Bundfaner** — hver fane gemmer sin egen stak. Tryk på en fane fører dig tilbage til, hvor du slap.
- **Hovedmenuen** — tryk på et punkt navigerer til den skærm med samme fanesystem. Det åbner ikke som et overlay.

Brug fanerne til at skifte opgave. Brug hovedmenuen, når du vil have en fuld liste over hver skærm i appen.

### Hvornår skal man bruge værktøjslinjen

Brug værktøjslinjen, når du vil skifte, hvad du laver:

- Du læser et kapitel og vil søge efter noget andet → tryk på **Søg**.
- Du søger og vil tjekke dine bogmærker → tryk på **Bogmærker**.
- Du er hvor som helst i appen og vil hjem → tryk på **Hjem**.

## Hovedmenuen

Hovedmenuen er knappen med tre stablede linjer (☰) i øverste højre hjørne af hjemskærmen. Tryk på den, og et panel glider ind fra højre side. Panelet viser hver skærm, din nuværende tilstand understøtter:

- 🏠 **Hjem**
- 📖 **Bibler**
- 📚 **Bøger**
- 🙏 **Andagter**
- 🔍 **Søg**
- 🔖 **Bogmærker** (Standard og Forsker)
- 🖍 **Fremhævninger** (Standard og Forsker)
- 📝 **Noter** (Standard og Forsker)
- 💻 **AI-assistent** (kun Forsker, og kun hvis AI er slået til)
- ⚙️ **Indstillinger**
- ❓ **Hjælp**
- ℹ️ **Om**

Det punkt, der matcher den skærm, du er på lige nu, er fremhævet og har en lille prik ved siden af. Tryk på et hvilket som helst punkt for at gå direkte til det. Tryk uden for panelet, på X'et øverst eller på din enheds tilbage-knap for at lukke det uden at skifte skærm.

### Hvordan hovedmenuen er anderledes

Hovedmenuen er et dropdown-panel, ikke et separat navigationslag. Når du trykker på et punkt, navigerer appen til den skærm på samme måde, som hvis du havde brugt bundfanen eller knapgitteret. Din nuværende fanes stak bevares, så du kan vende tilbage til, hvor du var, ved at trykke på den oprindelige fane igen.

For eksempel:

- Du læser Johannes 3. Du trykker på fanen **Bogmærker**. Du kommer til dine bogmærker. Når du trykker på **Bibler** igen, vender du tilbage til Johannes 3 — lige der, hvor du slap.
- Du læser Johannes 3. Du åbner hovedmenuen og trykker på **Noter**. Dine noter åbner. For at komme tilbage til Johannes 3, tryk på fanen **Bibler**, og du vender automatisk tilbage til kapitlet.

Fanerne skifter din kontekst og husker dit sted. Hovedmenuen er blot en anden måde at nå de samme skærme.

### Hvornår skal man bruge hovedmenuen

Brug hovedmenuen, når:

- Du vil åbne **Fremhævninger**, **Noter**, **Andagter**, **Hjælp** eller **Om** — skærme, der ikke har deres egen værktøjslinje-fane.
- Du er dybt inde i et kapitel eller en søgning og vil tjekke noget hurtigt uden at miste dit sted.
- Du vil åbne **Indstillinger** uden at forlade den skærm, du er på.

## Forsker-tilstand

Hvis din brugertilstand er sat til **Forsker**, får layoutet ekstra faner, menupunkter og læserværktøjer, som Læser- og Standard-tilstand skjuler. Se guiden [Forsker-tilstand](theodia://help/scholar-mode) for en fuld gennemgang af hver funktion.

## Sådan passer de tre områder sammen

- **Skift til en anden hovedsektion** (Bibler, Søg, Bogmærker osv.) → Bundværktøjslinjen
- **Hop til et bestemt vers eller en kommando** → Hjemskærmens Kommando
- **Gennemse alle tilgængelige skærme** → Hjemskærmens knapgitter
- **Tjek Noter, Fremhævninger eller Hjælp uden at forlade dit sted** → Hovedmenuen
- **Åbn Indstillinger hvor som helst fra** → Hovedmenuen eller værktøjslinjen

Du vil bruge alle tre. Ingen af dem er "den rigtige måde". Vælg den, der er nemmest for det, du laver.

### Værktøjslinje vs. hovedmenu: et hurtigt eksempel

Forestil dig, at du læser Romerne 8 og vil fremhæve et vers, du kan lide.

**Brug af værktøjslinjen:**

1. Tryk på verset for at åbne versmenuen.
2. Tryk på **Fremhæv**, og vælg en farve.
3. Færdig. Du forlod aldrig kapitlet.

**Brug af hovedmenuen (hvis du vil gennemse dine fremhævninger):**

1. Tryk på ☰ for at åbne menuen.
2. Tryk på **Fremhævninger**. Din fremhævningsliste åbner.
3. Gennemse dem, og tryk derefter på fanen **Bibler** for at vende tilbage til Romerne 8.

**Brug af værktøjslinjen (hvis du vil skifte opgave):**

1. Tryk på **Hjem** eller **Bogmærker** i værktøjslinjen.
2. Du forlader Romerne 8 og går til den nye skærm.
3. For at komme tilbage til Romerne 8, tryk på **Bibler** igen — du vender automatisk tilbage til kapitlet.

## Tips

- Hjemskærmen husker, hvilke sektioner der er foldet ud eller foldet sammen. Du behøver kun at sætte det op én gang.
- Hvis du ikke ser en fane, du forventer, så tjek to ting:

1. **Din brugertilstand** — Læser-tilstand skjuler bogmærker, fremhævninger, noter og AI. Standard-tilstand skjuler AI. Skift tilstand i **Indstillinger** → **App-brugertilstand**.
2. **Funktionsindstillinger** — nogle faner behøver at blive slået til i **Indstillinger** (f.eks. AI-assistenten).
