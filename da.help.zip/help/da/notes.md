---
title: At skrive noter
level: everyday
categories: [annotate, read]
summary: Sådan skriver du dine egne tanker ved siden af et vers.
---

# At skrive noter

> **Tilstand:** Noter er tilgængelige i **Standard**- og **Forsker**-tilstand. Fokustilstand er kun til ren læsning uden afbrydelser. Du kan skifte tilstand i **Indstillinger** → **App-brugertilstand**.

Noter er, hvor du skriver dine egne tanker, bønner eller studieideer ved siden af et vers. Hver note er knyttet til et bestemt vers.

## Sådan tilføjer du en note

1. Åbn verset.
2. Tryk på verset for at få menuen frem.
3. Tryk på **Note** i menuen. Den har et blyant-ikon.
4. Skriv din note.
5. Tryk på **Gem**.

Noten er nu gemt med verset.

## Sådan læser du en note

1. Åbn verset.
2. Kig efter blyantmærket ved siden af verset. Det betyder, at der er en note.
3. Tryk på verset. Noten vises nedenfor.

## Sådan redigerer du en note

1. Åbn verset med noten.
2. Tryk på verset.
3. Tryk på **Note** i menuen.
4. Foretag dine ændringer.
5. Tryk på **Gem**.

## Sådan sletter du en note

1. Åbn verset med noten.
2. Tryk på verset.
3. Tryk på **Note** i menuen.
4. Tryk på **Slet**.

## Sådan ser du alle dine noter

Tryk på fanen **Noter** nederst. Du ser en liste over hver note, du har skrevet, sorteret efter dato.

## Søg i dine noter

I fanen **Noter** trykker du på **Søg**-boksen. Skriv et ord. Appen finder hver note, der har det ord.

## Tips

- Noter er gode til prædikener, andagter og studiespørgsmål.
- Noter er private. De forbliver på din enhed.
- Se guiden [Sikkerhedskopiering af dine data](theodia://help/backups) for at holde dem i sikkerhed.
