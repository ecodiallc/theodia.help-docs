---
title: Notifikationer og påmindelser
level: everyday
categories: [settings]
summary: Sådan slår du offline påmindelser til, tilpasser og administrerer dem for bøn, andagter, Bibelplaner og mere.
---

# Notifikationer og påmindelser

Theodia kan minde dig om bøn, andagter, Bibelplaner, flashcards og andre aktiviteter — selv når appen er offline. Alle påmindelser planlægges på din enhed; ingen internetforbindelse eller push-notifikationsserver er nødvendig.

## Sådan slår du påmindelser til eller fra

1. Åbn **Indstillinger**.
2. Tryk på **Notifikationer**.
3. Slå **Aktivér påmindelser** til eller fra.

Første gang du aktiverer påmindelser, beder appen om tilladelse til at sende notifikationer. Tryk på **Tillad**, så påmindelserne kan vise sig.

Hvis du tidligere afviste tilladelsen, kan iOS eller Android blokere anmodningen. I så fald skal du gå til din enheds **Indstillinger**-app, finde **Theodia**, og slå notifikationer til der.

## Typer af påmindelser

Notifikationsskærmen er opdelt i kanaler. Hver kanal er en familie af påmindelser, du kan slå til eller fra uafhængigt:

- **Bønne-påmindelser** — generelle bønne-påmindelser.
- **Bønnerutine** — påmindelser knyttet til en bestemt bønnerutine.
- **Andagt** — den daglige vers- eller andagtspåmindelse.
- **Bibelplan-påmindelser** — påmindelser til en aktiv Bibelplan.
- **Theoscript-påmindelser** — påmindelser til at køre et Theoscript.
- **AI-indsigt-påmindelser** — AI-genererede påmindelser.
- **Flashcard-gennemgang-påmindelser** — opfordringer til at gennemgå flashcards.
- **Læsevane-påmindelser** — dagelige læsevane-opfordringer.
- **Liturgiske & sæsonmæssige påmindelser** — påmindelser knyttet til kirkekalenderen.
- **Mine påmindelser** — påmindelser, du oprettede fra bogmærker, fremhævninger, playlister, Bibelkapitler eller bøger.
- **Brugerdefinerede påmindelser** — helt brugerdefinerede påmindelser, du selv opretter.

Tryk på en hvilken som helst kanal for at se dens påmindelser, ændre klokkeslættet, vælge, hvilke dage den udløses, eller slå den fra.

## Brugerdefinerede påmindelser

Brugerdefinerede påmindelser er påmindelser, du bygger fra bunden.

1. I **Indstillinger** → **Notifikationer** trykker du på **Brugerdefinerede påmindelser**.
2. Tryk på **+**-knappen.
3. Indtast en **Titel** og en **Besked**.
4. Vælg et **Klokkeslæt**.
5. Vælg de **Dage**, du vil have den til at gentage sig.
6. Vælg, hvad påmindelsen åbner, når den trykkes (valgfrit).
7. Tryk på **Gem**.

Du kan redigere eller slette en brugerdefineret påmindelse når som helst ved at trykke på den i listen.

## Hvad sker der, når du trykker på en påmindelse

De fleste påmindelser åbner en bestemt skærm i appen. For eksempel åbner en bønnerutine-påmindelse den rutine; en Bibelplan-påmindelse åbner den næste læsning.

Hvis en påmindelse ikke har en linket skærm, åbner den appen til Hjem-skærmen.

## Stille timer

Stille timer gør notifikationslyde stumme, mens visuelle påmindelser stadig kan vise sig.

1. I **Indstillinger** → **Notifikationer** trykker du på **Stille timer**.
2. Sæt et **Start**- og **Slut**-klokkeslæt.

Påmindelser, der planlægges i stille timer, vises på skærmen uden lyd.

## Kommende påmindelser og historik

- **Kommende påmindelser** viser alt, hvad der er planlagt til at udløses næste gang.
- **Notifikationshistorik** viser nyligt leverede, planlagte og aflyste påmindelser.

Brug disse lister til at bekræfte, at en påmindelse er sat rigtigt op, eller til at se, hvorfor en ikke viste sig.

## Hvis påmindelser ikke viser sig

- Sørg for, at **Aktivér påmindelser** er slået til.
- Tjek, at notifikationer er tilladt i din enheds systemindstillinger.
- Sørg for, at påmindelsens kanal er slået til, og at mindst én dag er valgt.
- Hvis du har sat stille timer, kan påmindelsen være lydløs.
- Nogle Android-producenter lægger apps i dvale. Tilføj Theodia til den tilladte liste, hvis din enhed tilbyder batterioptimeringsindstillinger.
- Hvis en påmindelse er knyttet til indhold, du fjernede (f.eks. en slettet Bibelplan eller rutine), udløses påmindelsen måske ikke, før du vælger et gyldigt mål igen.

## Notifikationslyde

Du kan vælge den lyd, der afspilles af påmindelser, der understøtter lyde. Tryk på **Lyd** inde i en påmindelse eller kanal for at vælge mellem de tilgængelige valg. Lydene følger med appen, så de virker offline.

Brug knappen **Forhåndsvis lyd** for at høre den valgte lyd, før du gemmer.

## Badges

Nogle påmindelser kan tilføje et badge til app-ikonet. Tryk på **Ryd badge** på notifikationsskærmen for at nulstille det.
