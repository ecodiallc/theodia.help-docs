---
title: PDF'er
level: everyday
categories: [read, resources]
summary: Importér, organisér og læs PDF-dokumenter i Theodia.
---

# PDF'er

> **Tilstand:** PDF'er er tilgængelige i **Standard**- og **Forsker**-tilstand. Fokustilstand er kun til ren læsning uden afbrydelser. Du kan skifte tilstand i **Indstillinger** → **App-brugertilstand**.

Theodia kan gemme og læse PDF-filer. Importerede PDF'er forbliver på din enhed, så de virker offline.

## Åbn PDF-biblioteket

Tryk på fanen **PDF'er** i bunden af skærmen, eller tryk på **PDF'er**-flisen på Hjem-skærmen.

## Importér en PDF

1. Åbn fanen **PDF'er**.
2. Tryk på **+**-knappen nederst til højre.
3. Vælg en PDF fra din enhed.
4. (Valgfrit) Skriv eller vælg en kategori for at organisere den.

## Organisér PDF'er

Hold et hvilket som helst PDF-kort inde længe for at åbne en menu med disse valg:

- **Omdøb** — ændr titlen, der vises i biblioteket.
- **Skift kategori** — flyt PDF'en ind i en kategori.
- **Slet** — fjern PDF'en fra Theodia. Det sletter også dens gemte læseposition.

Kategorier er fri tekst. Skriv et nyt navn, eller vælg et eksisterende, når du importerer eller skifter kategori.

## Læs en PDF

Tryk på et PDF-kort for at åbne det. Læseren viser:

- Dokumenttitlen i en bjælke øverst.
- En række sideknapper: **Første side**, **Forrige**, den aktuelle side ("3 / 120"), **Næste** og **Sidste side**.
- En værktøjslinje med dokumentets værktøjer: **Indhold**, **Zoom ud**, **Zoom ind**, **Nulstil zoom**, **Bogmærke**, **Søg**, **Lyt** og **Tekstvisning**.

Nogle værktøjer er nedtonede, når de ikke kan bruges — f.eks. er **Søg** og **Lyt** nedtonede, indtil PDF'ens søgbare tekst er installeret.

### Bladr sider

- Tryk på **venstre** eller **højre pil** for at gå en side tilbage eller frem.
- Tryk på **Første side** eller **Sidste side** for at hoppe til hver sin ende af dokumentet.
- Tryk på sidetallet (f.eks. "3 / 120") for at åbne et sidegitter, og tryk derefter på den side, du vil have. Gitteret åbner nær den side, du er på.
- Brug **venstre- og højre-piletasterne** på et eksternt tastatur.

### Zoom

- Tryk på **Zoom ind** (+) eller **Zoom ud** (−) for at ændre sidestørrelsen.
- Tryk på **Nulstil zoom** for at bringe siden tilbage til sin normale størrelse.
- Hvis du zoomer ind, bladr siden og derefter zoomer ud, bringer Theodia dig tilbage til den side, du læste.

## Søg i en PDF

1. Åbn PDF'en, og tryk på **Søg**-knappen (forstørrelsesglas) i værktøjslinjen.
2. Skriv, hvad du leder efter. Resultater vises, mens du skriver, med sidetallet og et uddrag af den omgivende tekst.
3. Tryk på et resultat for at hoppe til den side.

Søgning behøver PDF'ens søgbare tekst installeret. Hvis den endnu ikke er installeret, er Søg-knappen nedtonet. PDF'er installeret fra fællesskabets GitHub-depot inkluderer søgbar tekst; PDF'er, du selv importerer, har den ikke, før den tilføjes.

## Indhold

Hvis PDF'en har et indbygget indholdsfortegnelse, viser **Indhold**-knappen i værktøjslinjen det som en oversigt. Tryk på en sektionstitel for at hoppe til den side. Sektioner kan foldes ud og sammen. Hvis PDF'en ikke har et indholdsfortegnelse, er knappen nedtonet.

## Bogmærker i en PDF

1. Åbn PDF'en, og tryk på **Bogmærke**-knappen i værktøjslinjen.
2. Tryk på **Sæt bogmærke på side** for at gemme den aktuelle side. Navnet starter som sidetallet — skriv et navn, hvis du foretrækker det — og tryk derefter på **Gem**.
3. Tryk på et hvilket som helst bogmærke i listen for at hoppe til dets side.
4. Tryk på **×** ved siden af et bogmærke for at slette det.

PDF-bogmærker er adskilt fra dine Bibel-bogmærker. Hver PDF beholder sin egen liste.

## Læs en PDF op

Hvis PDF'ens søgbare tekst er installeret, kan Theodia læse den aktuelle side op:

1. Åbn PDF'en, og tryk på **Lyt**-knappen (højttaler) i værktøjslinjen.
2. Der vises en kontrolbar med **Afspil/Pause**, **Tilbage**, **Fremad**, **Stop**, en fremdriftsbar, du kan trykke på for at springe inden for siden, læsehastigheden og stemmen.
3. Når siden slutter, fortsætter læsningen automatisk på næste side.

Stemmen og hastigheden er de samme, der bruges til Bibel-læsning — se [Oplæsning](theodia://help/tts) for, hvordan du ændrer dem.

## Kopiér, del eller gem sidetekst

Tryk på **Tekstvisning**-knappen i værktøjslinjen for at se den aktuelle side som almindelig tekst. Derfra kan du:

- **Kopiér** — kopiér sideteksten til udklipsholderen.
- **Del** — del sideteksten gennem enhver app på din enhed.
- **Tilføj til studienoter** — åbner en noteeditor med sideteksten, en kildeangivelse og et link tilbage til denne side udfyldt for dig.

## Fortsæt læsningen

Theodia husker den sidste side, du så, og åbner PDF'en dér næste gang.

## Download PDF'er fra GitHub

I **Forsker**-tilstand vises en **Download fra GitHub**-knap i bunden af biblioteket. Den forbinder til fællesskabets PDF-depot, så du kan installere pakkede PDF-dokumenter på samme måde, som du installerer Bibler eller bøger.

## Noter

- PDF'er gemmes i Theodias private dokumentmappe. De er ikke inkluderet i sikkerhedskopier, så hvis du skifter til en ny enhed, skal du importere dem igen.
