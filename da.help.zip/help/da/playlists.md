---
title: Playlister
level: everyday
categories: playlists
summary: Opret og lyt til talt spillelister med Bibelpassager, almindelig tekst eller ethvert vers, du vil høre.
---

# Playlister

En **playlist** er en liste af numre, Theodia kan læse op for dig. Hvert nummer er enten en Bibelpassage eller en kort notat i almindelig tekst. Playlister er nyttige til lytning uden hænder under en pendling, en gåtur, andagtstid eller hukommelsestræning.

Playlister vises i appen, når mindst én playlist er oprettet eller udfyldt.

## Hvor finder man Playlister

Når playlister er tilgængelige, kan du nå dem på to måder:

- **Hjemskærmen:** I sektionen **Plugins & mere** trykker du på **Playlister**.
- **Hovedmenuen:** Åbn menuen (☰), og tryk på **Playlister**.

Hvis der endnu ikke findes playlister, er Playlister-flisen og menupunktet skjulte.

## Hvad en playlist indeholder

Hver playlist har:

- Et **navn** — for eksempel "Morgensvers" eller "Memorér Salme 23".
- En valgfri **kategori** — nyttig til at gruppere playlister efter formål.
- En liste af **numre** — de punkter, der skal læses op.

Hvert nummer indeholder:

- **Indhold** — enten en Bibelpassagenhenvisning eller almindelig tekst.
- En **mærkat** — vist på skærmen, mens nummeret afspilles.
- En valgfri **stemme** — vælg en anden stemme til dette nummer, hvis du vil.

## Oprettelse af en playlist

1. Åbn **Playlister**-skærmen.
2. Tryk på **Opret playlist** (eller **+**-knappen).
3. Giv playlisten et navn.
4. (Valgfrit) Vælg eller opret en kategori.
5. Begynd at tilføje numre.

### Tilføjelse af et nummer fra en Bibelpassage

1. Tryk på **Tilføj nummer**.
2. Vælg **Bibelpassage** som indholdstype.
3. Indtast en henvisning, som `John 3:16` eller `Psalm 23:1-6`.
4. Tilføj en mærkat, hvis du vil, eller lad den stå tom for at bruge henvisningen.
5. Gem nummeret.

### Tilføjelse af et nummer med almindelig tekst

1. Tryk på **Tilføj nummer**.
2. Vælg **Almindelig tekst**.
3. Skriv den tekst, du vil have Theodia til at læse.
4. Tilføj en mærkat.
5. Gem nummeret.

## Batch-tilføjelse af numre

Hvis du har en liste over henvisninger eller tekstlinjer, så brug **Batch-tilføj**:

1. Åbn en playlist.
2. Tryk på menuen, og vælg **Batch-tilføj**.
3. Indsæt én henvisning eller tekstlinje pr. linje.
4. Slå **Genkend Bibelhenvisninger** til, hvis de fleste linjer er vershenvisninger.
5. Tryk på **Tilføj**. Hver linje bliver et nummer.

## Lytning til en playlist

1. Åbn den playlist, du vil høre.
2. Tryk på **Afspil**-knappen øverst eller ved siden af et nummer.
3. Theodia læser hvert nummer i rækkefølge.

Mens en playlist afspilles, vises en kontrolbar med disse kontroller:

- **Afspil / Pause**
- **Næste nummer**
- **Forrige nummer**
- **Stop**

Du kan også indstille:

- **Hastighed** — hvor hurtigt stemmen læser.
- **Gentag** — gentag hele playlisten, gentag ét nummer, eller afspil én gang.
- **Bland** — afspil numrene i tilfældig rækkefølge.
- **Ignorér parentetisk** — spring tekst inde i parenteser over.
- **Pause mellem numre** — tilføj en kort stilhed mellem numre.
- **Søvnur** — stop afspilning efter en fastsat tid.

## Redigering af en playlist

For at ændre en playlist skal du først sætte afspilningen på pause, hvis den afspilles lige nu.

Du kan:

- **Omdøbe** playlisten.
- **Omorganisere numre** — træk numre ind i en ny rækkefølge.
- **Redigere et nummer** — ændr dets henvisning, tekst, mærkat eller stemme.
- **Slette et nummer** — fjern det fra playlisten.
- **Slette hele playlisten** — det kan ikke fortrydes.

## Eksport og import af playlister

Playlister eksporteres som JSON-filer, der inkluderer alle numre, kategorier og indstillinger. Du kan dele filen med en anden enhed, beholde den som sikkerhedskopi eller redigere den på en computer.

- **Eksportér alle playlister** — opretter en `playlists-YYYY-MM-DD.json`-fil.
- **Eksportér en kategori** — opretter en JSON-fil, der kun indeholder playlisterne i én kategori.
- **Importér playlister** — gendanner playlister fra en JSON-sikkerhedskopifil.

## Hurtige måder at bygge en playlist på

Du kan også oprette en hel playlist som JSON og importere den. Her er et eksempel:

```json
{
  "playlists": [
    {
      "name": "Morning Verses",
      "category": "Devotional",
      "tracks": [
        {
          "info": "John 3:16",
          "contentSource": "passage",
          "content": "For God so loved the world...",
          "rawContent": "John 3:16"
        },
        {
          "info": "Psalm 23",
          "contentSource": "passage",
          "content": "The Lord is my shepherd...",
          "rawContent": "Psalm 23:1-6"
        }
      ]
    }
  ]
}
```

Gem filen, og brug derefter **Importér playlister** for at indlæse den i Theodia.

## Tips

- Playlister virker bedst med korte, fokuserede sæt af vers.
- Brug kategorier til at adskille andagtsplaylister fra hukommelsesplaylister.
- Sæt en søvnur, hvis du lytter, mens du falder i søvn.
- Hvis et nummer bruger den forkerte stemme, tjek at stemmens sprog matcher tekstens sprog.
- Theodia læser almindelig tekst præcis, som den er skrevet; tjek stavning for det bedste resultat.
