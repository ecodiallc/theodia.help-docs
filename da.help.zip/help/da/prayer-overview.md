---
title: Overblik over Bøn
level: beginner
categories: prayer
summary: En kort introduktion til Bøn-fanen og dens hovedsektioner.
---

# Overblik over Bøn

Fanen **Bøn** er et dedikeret rum til bøn. Den samler lister, vejledte sessioner, en dagbog, et timer, lektionær-læseskemaer og klassiske faste bønner.

## Hovedsektionerne

- **Bønneliste** — hold styr på mennesker, situationer og emner, du beder for.
- **Dagbog** — skriv refleksioner, svar og tanker hen over tiden.
- **Generér bøn** — bed Theofilus skrive en bøn ud fra en anmodning eller dagbogspost.
- **Bekendelser & faste bønner** — klassiske bønner og bekendelser fra den kristelige tradition.
- **Lektionær** — skriftlæseskemaer til daglig eller sæsonmæssig bøn.
- **Vejledt bøn** — lydvejledte bønnesessioner med tekst-til-tale.
- **Timer** — tidsmålte bønnesessioner med valgfrie klokker.
