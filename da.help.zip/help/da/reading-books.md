---
title: Læsning af indbyggede bøger
level: beginner
categories: [content, read]
summary: Sådan læser du de kristelige klassikere, der følger med appen.
---

# Læsning af indbyggede bøger

Theodia leveres med et lille bibliotek af kristelige bøger. Det er klassikere, du kan læse på din enhed.

## Sådan åbner du biblioteket

Tryk på fanen **Bøger** i bunden af skærmen. Du ser en liste over bøgerne i dit bibliotek.

## Sådan læser du en bog

1. Tryk på bogens titel.
2. Bogen åbner ved første kapitel.
3. Brug **Forrige**- og **Næste**-knapperne øverst til at bevæge dig mellem kapitler.

## Sådan hopper du til et kapitel

Tryk på kapitelnavnet øverst på skærmen. Der vises en liste over kapitler. Vælg et kapitel for at hoppe til det.

## Sådan ændrer du skriftstørrelsen

Åbn **Indstillinger** → **Udseende**, og vælg en skriftstørrelse. Tekststørrelsen ændres i hele appen, også i bøger.

## Sådan tilføjer du et bogmærke i en bog

Tryk på **stjerne**-ikonet øverst til højre. Det aktuelle kapitel gemmes. Tryk på **Bogmærker**-fanen for at se dine gemte sider.

## Sådan lytter du til en bog

Tryk på **Højttaler**-ikonet øverst til højre. Appen læser kapitlet op. Tryk igen for at stoppe.

## Hvilke bøger er tilgængelige?

Biblioteket har klassikere som:

- Pilgrim's Progress
- The Imitation of Christ
- Practice of the Presence of God
- The Hymn Book

Boglisten kan vokse hen over tiden. Opdateringer til appen kan tilføje flere.

## Tips

- Bøger gemmes på din enhed. Intet internet behøves.
- Bøger synkroniseres ikke til cloud.
