---
title: Find ressourcer på GitHub
level: everyday
categories: resources
summary: Søg i hvert GitHub-depot, appen kender, på én gang, og installér det, du finder.
---

# Find ressourcer på GitHub

Theodia gemmer en liste over GitHub-depoter, der udgiver ressourcer — Bibler, kommentarer, bøger, andagter, playlister, bønne-pakker og mere. **Søg GitHub-depoter** søger i alle på én gang, så du ikke behøver at åbne hver fane og gennemse separat.

> GitHub-sektionen i Indstillinger er kun tilgængelig i **Forsker-tilstand**. For at slå den til, gå til **Indstillinger → Brugertilstand → Forsker**.

## Sådan søger du

1. Åbn **Indstillinger**.
2. Tryk på **Søg GitHub-depoter**.
3. Skriv et ord i søgeboksen. Appen leder efter det ord i **navnet** og **beskrivelsen** af hver pakke i hvert depot.

Et par ting at vide om søgningen:

- **Hvert ord skal matche.** Søgning på `morning evening` finder kun pakker, hvis navn eller beskrivelse indeholder *begge* ord.
- **Versaler betyder intet.** `Morning` og `morning` finder de samme pakker.
- **Det bedste match kommer først.** En pakke, hvis navn *starter* med din søgning, vises før én, der kun nævner det i beskrivelsen.

## Filtrering

Tryk på filterlinjen over resultaterne for at indsnævre listen yderligere. Der er to filtre, og de virker sammen:

- **Forfatter** — kun pakker af den forfatter.
- **Tradition** — kun pakker for den tradition.

Tryk på et filter igen for at rydde det, eller tryk på **Ryd filtre** for at nulstille begge.

## Installation fra et resultat

Hvert resultat viser pakkens navn, hvilken slags ressource det er, hvem der lavede det, og hvilket depot det kommer fra. Til højre for rækken er én knap:

- **Installér** — pakken er endnu ikke på din enhed.
- **Opdatér** — en nyere version er tilgængelig. Appen beder dig først bekræfte, fordi opdatering fjerner den gamle kopi sammen med eventuelle noter, fremhævninger eller bogmærker, der peger på den.
- **Åbn** — pakken er allerede installeret; tryk på den fører dig til skærmen, hvor du bruger den.

Tryk på **Opdatér** øverst for straks at hente den nyeste liste fra GitHub. Appen opdaterer listen af sig selv én gang om dagen, så en manuel opdatering behøves kun, når du ved, at noget nyt er udgivet.

## Søgning uden en forbindelse

Appen beholder en kopi af listen på din enhed, så søgning virker, selv når du er offline. Hvis appen ikke kan nå GitHub for at opdatere listen, fortæller et banner øverst dig, at du ser de cachede resultater.

## Hvis en søgning finder intet

- Prøv et kortere, enkelt ord.
- Tjek, at intet **Forfatter**- eller **Tradition**-filter stadig er anvendt — knappen **Ryd filtre** vises, når der er ét.
- Nogle depoter udgiver deres pakker på et andet sprog end pakkenavnet, så søgning på et oversat ord finder dem måske ikke.
