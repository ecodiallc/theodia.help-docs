---
title: Forsker-tilstand
level: advanced
categories: [layout, read, study]
summary: Den dybeste studietilstand i Theodia, der låser op for kommentarer, leksika, krydshenvisninger, AI-værktøjer og Launcher-menuen.
---

# Forsker-tilstand

> **Tilstand:** Forsker-tilstand er kun tilgængelig, når din brugertilstand er sat til **Forsker**. Skift tilstand i **Indstillinger** → **App-brugertilstand**.

Forsker-tilstand låser op for hvert studieværktøj i Theodia. Den er bygget oven på Studietilstand, så du får stadig versmenuen, parallelle Bibler, bogmærker, fremhævninger og noter — plus de avancerede værktøjer, der er nævnt nedenfor.

## Sådan åbner du Forsker-tilstand

Forsker-tilstand er ikke en separat skærm. Det er et sæt ekstra værktøjer, der viser sig inde i den eksisterende læser og navigation, når din brugertilstand er sat til Forsker.

1. Åbn **Indstillinger**.
2. Tryk på **App-brugertilstand**.
3. Vælg **Forsker**.

Ændringen træder i kraft med det samme. Menuer og knapper, der var skjulte, viser sig nu.

## Ekstra læserværktøjer

Når du åbner et kapitel i [Studietilstand](theodia://help/study-mode), tilføjer Forsker-tilstand disse værktøjer til versmenuen:

- **AI-kommentar** (◈) — bed AI-assistenten skrive en studienote til dette vers. (Ikke tilgængelig i alle regioner.)
- **Ordinfo** (?) — åbn en leksikonpost for det oprindelige hebraiske eller græske ord bag verset. Se guiden [Kommentarer og leksika](theodia://help/commentaries-and-lexicons).
- **Ordbog** (📖) — slå almindelige bibelske ord op i de ordbogsressourcer, du har installeret. Se guiden [Bibel-ordbog](theodia://help/dictionary).

Disse værktøjer behøver ressourcer installeret (kommentarer, leksika, ordbogsfiler). Hvis et værktøj er gråtone eller viser "ikke fundet", åbn **Indstillinger** → **Administrer ressourcer**, og tilføj den ressource, det behøver.

## Ekstra navigation

### Ekstra værktøjslinje-fane

Bundværktøjslinjen får én ekstra fane:

- 💻 **AI** — åbner AI-assistenten (kun hvis du har slået AI til i Indstillinger). Denne fane sidder til højre for Noter.

### Ekstra hovedmenu-punkter

Hovedmenuen inkluderer et **AI-assistent**-punkt under de samme betingelser.

## Launcher-menuen

Forsker-tilstand aktiverer **Launcher-menuen**, en hurtig måde at hoppe til seneste vers, køre kommandoer og skifte Bibel-layout uden at forlade din nuværende skærm. Se guiden [Launcher-menuen](theodia://help/launcher-menu) for, hvordan du bruger den.

## Hvornår skal man bruge Forsker-tilstand

- Du vil have AI-assistenten, kommentarer eller opslag på originalsprogene, mens du læser.
- Du vil have Launcher-menuen til hurtig versnavigation og AI-chat.
- Du studerer en passagen i dybden og behøver hvert værktøj ét tryk væk.

## Skift til en lettere tilstand

Hvis du vil have en enklere læser uden de avancerede værktøjer, så skift til **Standard**-tilstand i **Indstillinger** → **App-brugertilstand**. Standard-tilstand beholder bogmærker, fremhævninger, noter og Studietilstand, men skjuler AI, kommentarer, leksika og Launcher-menuen.

Hvis du vil have den reneste mulige læseoplevelse, så åbn et kapitel i [Fokustilstand](theodia://help/focus-mode).

Dine bogmærker, fremhævninger og noter slettes aldrig, når du skifter tilstand; de skjules blot, indtil du vender tilbage til en tilstand, der understøtter dem.

## Hjælp og spørgsmål

Hvis et værktøj mangler eller viser en fejl, se guiden [Almindelige problemer](theodia://help/common-problems). Hvis du er ny til Theodia, fører guiden [Læsning af dit første kapitel](theodia://help/first-read) dig gennem det grundlæggende trin for trin.
