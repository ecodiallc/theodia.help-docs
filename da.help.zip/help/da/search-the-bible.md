---
title: Søgning i Bibelen
level: everyday
categories: [study, read]
summary: Sådan finder du vers efter ord, frase eller henvisning.
---

# Søgning i Bibelen

Søgelinjen hjælper dig med hurtigt at finde vers. Du kan søge efter et ord, en frase eller en Bibelhenvisning.

## Sådan starter du en søgning

1. Tryk på fanen **Søg** i bunden af skærmen.
2. Skriv, hvad du vil finde.
3. Tryk på **Søg** på tastaturet.

Resultaterne vises som en liste over vers. Hvert resultat viser bog, kapitel og vers, plus verseteksten.

## Søgning efter ordkombinationer

Når du skriver mere end ét ord, som `love joy`, finder appen vers, der indeholder **begge** ord. Det er en **AND**-søgning — alle ordene skal vises i verset. Den bruger **ikke** **OR**-logik (vers med ethvert enkelt ord).

For at søge efter vers, der indeholder enten ordet, skal du eksplicit bruge `OR`-nøgleordet: `love OR joy`.

## Søgning efter ord

Skriv et enkelt ord, som `love` eller `mercy`. Appen viser hvert vers i Bibelen, der har det ord.

## Søgning efter frase

Skriv to eller tre ord i anførselstegn, som `"do not be afraid"`. Appen viser vers, der har den præcise frase.

## Filtrér resultaterne

Efter en søgning filtreres resultaterne til de Bibeloversættelser, du har installeret. For at indsnævre yderligere, åbn **Bibel**-fanen og se på en bestemt oversættelse — søgninger køres mod de oversættelser, du har.

## Tips til bedre søgninger

- Brug korte ord. Søgninger på `love` finder flere vers end søgninger på `loving`.
- Anførselstegn omkring en frase gør søgningen eksakt.
- Appen søger kun i de Bibeloversættelser, du har installeret.
- For at hoppe til et bestemt vers efter henvisning (f.eks. `John 3:16`), brug **Kommando**-boksen på hjemskærmen i stedet for Søg-fanen.

## Søgehistorik

Appen husker dine seneste søgninger. Når du åbner **Søg**-fanen, viser listen dine nylige søgninger øverst. Tryk på én for at køre den igen. For at rydde listen, tryk på **Ryd alle** øverst i de nylige søgninger.

## Søg i PDF'er

Søg-fanen kan også søge inde i dine PDF-dokumenter:

1. Tryk på **Søg**-fanen, og tryk derefter på **PDF'er**-tilstanden øverst.
2. Vælg, hvilke PDF'er der skal søges i. Tryk på en PDF for at inkludere eller udelukke den; brug **Alle** eller **Ryd** over listen for at inkludere alt eller starte forfra. Kun PDF'er, hvis søgbare tekst er installeret, kan vælges.
3. Skriv, hvad du vil finde, og tryk på **Søg**.

Hvert resultat viser PDF'ens titel, sidetallet og et uddrag af den matchende tekst. Tryk på et resultat for at åbne den PDF på den side.

For at søge i en enkelt PDF, mens du læser den, brug **Søg**-knappen i PDF-læseren i stedet — se [PDF'er](theodia://help/pdfs).
