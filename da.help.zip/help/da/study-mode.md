---
title: Studietilstand
level: everyday
categories: [layout, read]
summary: Den fulde Bibel-læser i Theodia, pakket med studieværktøjer som kommentar, krydshenvisninger, leksikon og noter.
---

# Studietilstand

> **Tilstand:** Studietilstand er tilgængelig i **Standard**- og **Forsker**-tilstand. Læser-tilstand åbner kapitler i Fokustilstand i stedet. Du kan skifte tilstand i **Indstillinger** → **App-brugertilstand**.

Studietilstand er den vigtigste Bibel-læser i Theodia. Den har alle studieværktøjerne indbygget: kommentar, krydshenvisninger, ordopslag, parallelle oversættelser, noter og mere.

Fokustilstand er en enklere læser uden studieværktøjer. Se guiden [Fokustilstand](theodia://help/focus-mode), hvis du kun vil have ren tekst. Denne guide er til Studietilstand.

## Sådan åbner du Studietilstand

Der er et par måder at åbne et kapitel i Studietilstand:

- Tryk på **Bibel**-fanen i bunden af skærmen. Vælg en oversættelse, en bog og et kapitel.
- Tryk på et vers i **Søg**-resultaterne.
- Tryk på et bogmærke fra **Bogmærker**-fanen.
- Fra Fokustilstand trykker du på 📖-knappen øverst på skærmen for at skifte til Studietilstand.

## Læsning af kapitlet

Kapitlet åbner med versene opstillet i rækkefølge. Øverst på skærmen er knapper til de mest almindelige handlinger. Nederst på skærmen er en statuslinje.

- **Stryg til venstre** for at gå til næste kapitel.
- **Stryg til højre** for at gå til forrige kapitel.
- **Tryk på et vers** for at åbne versmenuen med studieværktøjer (se nedenfor).
- **Tryk på et Strongs-nummer i et vers** (f.eks. G1234 eller H1234) for at åbne et hurtigt leksikon-opslag for det ord.

Hvis du har en parallel oversættelse slået til, vises en anden kopi af kapitlet under den vigtigste, i den oversættelse, du valgte. Se **Læsning af to oversættelser på én gang** nedenfor.

## Versmenuen

Når du trykker på et vers, åbner en menu med titlen "Bog Kapitel:Vers". De værktøjer, du ser, afhænger af din brugertilstand.

### Værktøjer i Standard- og Forsker-tilstand

- **Bogmærke** (★) — gem verset, så du kan finde det igen. Tryk igen for at fjerne bogmærket. Det første tryk tilføjer det. Se guiden [Bogmærkning af vers](theodia://help/bookmarks).
- **Fremhæv** (□) — farv verset, så det skiller sig ud. Tryk på det for at åbne en farvevælger. Tryk på samme farve igen for at fjerne fremhævningen. Se guiden [Fremhævning af vers](theodia://help/highlights).
- **Læs op** (🔊) — lad verset læses op med din enheds tekst-til-tale-stemme. Det vises ikke for interlineære Bibler. Se guiden [Oplæsning](theodia://help/tts) for, hvordan du bruger det, og hvordan du vælger en stemme.
- **Kopiér** (⎘) — læg verseteksten på din udklipsholder, så du kan indsætte den hvor som helst.
- **Sammenlign** (⇄) — åbn et panel, der viser det samme vers i hver oversættelse, du har installeret. Tryk på en oversættelse i panelet for at læse verset i den oversættelse. Se guiden [Sammenligning af oversættelser](theodia://help/compare-translations).
- **Krydshenvisninger** (↗) — åbn en liste over relaterede vers fra krydshenvisningsdatabasen. Se guiden [Krydshenvisninger](theodia://help/cross-references).
- **Tilføj/redigér Bibelnote** (✎) — skriv din egen private note knyttet til verset. Se guiden [At skrive noter](theodia://help/notes).

### Værktøjer kun i Forsker-tilstand

- **AI-kommentar** (◈) — bed AI-assistenten skrive en studienote til dette vers. (Ikke tilgængelig i alle regioner.)
- **Ordinfo** (?) — åbn en leksikonpost for det oprindelige hebraiske eller græske ord bag verset. Se guiden [Kommentarer og leksika](theodia://help/commentaries-and-lexicons).
- **Ordbog** (📖) — slå almindelige bibelske ord op i de ordbogsressourcer, du har installeret. Se guiden [Bibel-ordbog](theodia://help/dictionary).

Nogle værktøjer behøver ekstra ressourcer installeret. Hvis et værktøj er gråtone eller viser "ikke fundet", åbn **Indstillinger** → **Administrer ressourcer**, og tilføj den ressource, det behøver.

## Knapper øverst på skærmen

Over kapitelteksten er en række ikoner. Det er de hurtige handlinger:

- **Bibelversion** — tryk på oversættelsesnavnet (f.eks. "KJV") for at skifte til en anden oversættelse.
- **Bog** — tryk på bognavnet for at hoppe til en anden bog.
- **Kapitel** — tryk på kapitelnummeret for at hoppe til et andet kapitel.
- **Åbn i AI** (🤖) — send det aktuelle kapitel til AI-assistenten med dit spørgsmål. (Kun Forsker-tilstand.)
- **Fokustilstand** (📖) — skift til Fokustilstand for ren læsning.
- **Parallelle Bibler** (🔵 / ⚪) — tryk for at slå parallelle oversættelser til eller fra. Når slået til, vises samme kapitel i dine valgte parallelle oversættelser under hovedteksten. Når slået fra, vises kun hovedoversættelsen. Se **Læsning af flere oversættelser på én gang** nedenfor.
- **Lyt** — lad hele kapitlet læses op. Se guiden [Oplæsning](theodia://help/tts).
- **Mere** — åbn ekstra kapitelhandlinger (kapitel-Bibelnote, kapitelkommentar, deling og så videre).

## Læsning af flere oversættelser på én gang

Du kan vise op til fire ekstra oversættelser ved siden af din vigtigste. Det kaldes **parallelvisning**.

1. Åbn **Indstillinger**.
2. Slå **Parallel Bibel** til.
3. Tryk på **Tilføj parallel Bibel**, og vælg en oversættelse.
4. Gentag for at tilføje flere. Du kan have op til fire parallelle oversættelser.

Når parallelvisning er slået til, viser hvert vers i kapitlet din hovedoversættelse først, efterfulgt af samme vers i hver parallel oversættelse. Det gør det nemt at sammenligne, hvordan forskellige oversættere håndterer et svært vers, uden at forlade kapitlet.

Du kan gemme din nuværende parallelle opsætning som en **forudindstilling**. Tryk på gem-knappen ved siden af dine valgte oversættelser, giv den et navn, og den bliver en hurtigskift-indstilling. Tryk på en hvilken som helst forudindstilling senere for straks at indlæse den kombination. Hold en forudindstilling inde længe for at slette den.

Du kan også sammenligne kun ét vers ad gangen med værktøjet **Sammenlign** (⇄) i versmenuen. Det åbner et panel, der viser verset i hver installerede oversættelse.

## Underoverskrifter

Nogle oversættelser har sektionsoverskrifter indbygget (f.eks. "Bjergprædikenen"). Hvis din oversættelse har dem, kan du vise eller skjule dem med indstillingen **Vis underoverskrifter** i **Indstillinger**. Underoverskrifter viser sig som små grå titler mellem vers.

## Kapitelnoten

En kapitelnote er en enkelt note knyttet til hele kapitlet, ikke til et enkelt vers. Den er nyttig til én stor tanke om kapitlet.

Sådan åbner du kapitelnoten:

1. Tryk på **Mere**-knappen øverst på skærmen.
2. Tryk på **Kapitelnote**.
3. Skriv din note. Tryk på **Gem**.

Kapitelnoten gemmes med kapitlet. Den viser sig, hver gang du åbner det kapitel.

## Søgefremhævninger

Hvis du kom til kapitlet fra en søgning, er dine søgeord fremhævede i gult i verseteksten. Det gør det nemt at se, hvorfor et vers matchede.

Du kan også køre en søgning igen på et kapitel, du læser. Åbn **Søg**-fanen, og indtast et ord. Resultaterne lader dig trykke lige tilbage ind i kapitlet med matchene fremhævet.

Interlineære Bibler (MIB — Marvel Interlinear Bible — og OHGB) åbner altid i Studietilstand, fordi de behøver layoutet på ordniveau.

## Skift til Fokustilstand for et enkelt kapitel

Fra ethvert kapitel i Studietilstand trykker du på 📖-knappen øverst. Samme kapitel åbner i Fokustilstand med alle menuerne skjulte. Tryk på 📖-knappen i bundlinjen for at skifte tilbage til Studietilstand.

## Hvornår skal man bruge Studietilstand

Studietilstand er det rigtige valg, når du vil:

- **Læse og studere på samme tid.** Alle værktøjerne er ét tryk væk.
- **Slå et ord op, du ikke kender.** Tryk på et Strongs-nummer i verset for en hurtig leksikonpost.
- **Sammenligne oversættelser.** Brug versmenuens Sammenlign-værktøj eller slå parallelvisning til.
- **Se, hvordan et vers knytter sig til resten af Bibelen.** Brug Krydshenvisninger.
- **Tage noter, mens du læser.** Versmenuen har en hurtig "Tilføj note"-indstilling.

Til lang, afbrydelsesfri læsning, skift til Fokustilstand.

## Skift til Fokustilstand

Fra ethvert kapitel i Studietilstand trykker du på 📖-knappen øverst. Samme kapitel åbner i [Fokustilstand](theodia://help/focus-mode) med menuerne og studieværktøjerne skjulte. Tryk på 📖-knappen i bundlinjen for at skifte tilbage til Studietilstand. For en fuld beskrivelse af, hvad Fokustilstand gør, se guiden [Fokustilstand](theodia://help/focus-mode).

## Hjælp og spørgsmål

Hvis et værktøj mangler eller viser en fejl, se guiden [Almindelige problemer](theodia://help/common-problems). Hvis du er ny til Theodia, fører guiden [Læsning af dit første kapitel](theodia://help/first-read) dig gennem det grundlæggende trin for trin.
