---
title: Tablet-funktioner
level: everyday
categories: [layout, tablet]
summary: Sådan tilpasser Theodias layout sig til tablets og større skærme, med delte visninger, sidepaneler og tospaltet læsning.
---

# 📱 Tablet-funktioner

Theodia er designet til at udnytte de større skærme på tablets. På en tablet (eller enhver enhed bredere end ca. 700 pixels) skifter appen automatisk til et tokolonne-layout mange steder.

> **Tilstand:** De funktioner, der beskrives her, vises kun, hvis din aktuelle brugertilstand understøtter dem. For eksempel er kommentar-sidepaneler og AI-chat kun tilgængelige i Forsker-tilstand. Delte visninger af bogmærker, fremhævninger og noter behøver Standard- eller Forsker-tilstand. Fokustilstand viser kun ren, enkel kolonne-læsning. Du kan skifte tilstand i **Indstillinger** → **App-brugertilstand**.

## Versmenuen i Læser-tilstand

Når du trykker på et versnummer (eller holder verseteksten nede), viser **versmenuen** sig som et **centreret kort** over en mørk baggrund.

- **Kopiér**- og **Del**-knapperne er altid synlige øverst i menuen.
- **Bogmærker** og **Fremhævninger** vises med deres aktuelle tilstand.
- **Kommentar**, **Ordbog** og **Sammenlign** åbner fra menuen. På en tablet kan disse værktøjer vise sig i et sidepanel eller et bredt kort, når de er valgt.
- Tryk på baggrunden eller lukke-pilen for at fjerne menuen.

## Verskommentar-panelet

Værktøjet **Kommentar** åbner et **dedikeret sidepanel** på en tablet:

- Kommentarteksten vises ved siden af Bibelteksten.
- Du kan rulle i kommentaren uafhængigt af Bibelen.
- Tryk på **X** eller stryg væk for at lukke.
- Et **bog-ikon** øverst i panelet lader dig skifte kommentarkilde.
- Et **kapitel-ikon** lader dig se kommentar på kapitelniveau.

På en telefon åbner kommentaren som et fuldskærms-vindue.

## Kapitelkommentar

**Kapitelkommentar** nås via **Mere**-knappen øverst på skærmen, ikke via versmenuen. På en tablet åbner den som et sidepanel, ligesom Verskommentar, så du kan læse kommentaren og Bibelteksten sammen.

## Sammenlign-fanen

**Sammenlign**-fanen (i versmenuen) åbner som et **sidepanel** på en tablet. Den viser det valgte vers i hver parallel version, du har slået til. Du kan trykke på en hvilken som helst version for at hoppe til den passagen i læseren.

## Ordbog / Strongs-popop

Værktøjet **Ordbog** (versmenu → Ordbog) åbner som et bredt kort på en tablet. Det viser det græske eller hebraiske ord, dets translitteration, definition og Strongs-nummer. Tryk på **Konkordans**-knappen for at se enhver forekomst af det ord i Bibelen.

## Tryk på et ord for at åbne dets leksikon

I **Ordinfo**-sidepanelet på en tablet kan hvert ordkort, der har et Strongs-nummer, trykkes på. Tryk på kortet for at åbne **Leksikon**-panelet for det ord direkte. Leksikon-panelet erstatter Ordinfo-panelet, så du kan fortsætte med at studere uden at lukke læseren.

På en telefon kan Ordinfo-kort ikke trykkes på, fordi skærmen er for lille til to paneler.

## Parallelle Bibler side om side

I Indstillinger trykker du på **Parallelle Bibler** og vælger op til tre versioner. På en tablet vises versionerne som **lodrette ruder** ved siden af hinanden:

- Hver rude ruller uafhængigt.
- Du kan trykke på et versnummer for at åbne et sidepanel med værktøjer.
- **Sammenlign**-fanen viser alle valgte vers ét sted.
- Tryk på **X** på en hvilken som helst rude for at lukke den og vende tilbage til en enkelt-kolonne-visning.
- Tryk på ikonet **Parallelle Bibler** (🔵 / ⚪) i den øverste ikonlinje for at slå parallelvisning til eller fra uden at åbne Indstillinger.

På en telefon vises parallelle versioner én efter én (lodret) i stedet for side om side. Samme skifte-ikon virker også på telefoner.

## Delt visning af bogmærker og fremhævninger

På en tablet bruger **Bogmærker**- og **Fremhævninger**-fanerne et master-detay-layout:

- **Venstre side** — listen over bogmærker eller fremhævninger.
- **Højre side** — tryk på et punkt for at åbne en forhåndsvisningsrude med vers- eller passagenteksten.

Du kan skumme dine gemte punkter og forhåndsvise dem uden at forlade fanen. På en telefon navigerer tryk på et punkt til læser-skærmen.

## Delt visning af noter

**Noter**-fanen på en tablet viser din noteliste til venstre og den valgte note til højre. Tryk på en note for at åbne den i et sidepanel, så du kan skumme flere noter i træk uden at forlade listen. Oprettelse eller redigering af en note bruger også et sidepanel.

## Delt visning af søgning

På en tablet viser **Søg**-fanen søgeformularen til venstre og resultaterne til højre, så snart du kører en søgning. Du kan forfine din forespørgsel og se resultaterne opdatere sig uden at skifte skærm. På en telefon åbner søgeresultaterne på en separat skærm.

## Indstillinger-sidebjælke med kategorier

**Indstillinger**-skærmen på en tablet viser en kategoriliste til venstre (AI, Udseende, Sikkerhedskopi, Bibler og så videre). Tryk på en kategori for at hoppe direkte til dens indstillinger til højre. Kun den valgte kategori er foldet ud, så du behøver aldrig at rulle gennem hele indstillingslisten.

## Bibelnavigation på tablets

Skærmene **Bibelliste**, **Bibelbøger** og **Bibelkapitler** forbliver enkelt-kolonne på tablets, men de bruger større trykflader, bredere gitre og mere rummelig polstring, så indholdet er lettere at læse og trykke på. De bruger ikke et delt-visning-layout, fordi hvert trin behøver den fulde bredde for at vise sin liste eller sit gitter klart.

## Landskab og portræt

At dreje tabletten tilpasser layoutet automatisk. I **landskab** har sidepanelerne masser af plads. I **portræt** bliver panelerne smalere, men forbliver stadig ved siden af teksten.

## AI-chat for valgt vers

**AI**-chatten åbner i versmenuens sidepanel. Den viser en samtalegrænseflade, hvor du kan stille spørgsmål om det valgte vers. AI-svaret viser sig i panelet, og du kan fortsætte samtalen uden at forlade læseren.

## Samtale-sidebjælke i AI-skærmen

I **AI**-fanen på en tablet er samtalelisten altid synlig som en vedvarende venstre sidebjælke. Du kan skifte mellem chats uden at åbne en menu. **Ny chat**-knappen er også altid synlig. På en telefon er samtalelisten en popop-skuffe.

## Hvad forbliver det samme

Ikke hver skærm deler sig i to ruder. Følgende skærme forbliver enkelt-kolonne på tablets:

- **Bibelliste** — liste over Bibelversioner (fuld bredde)
- **Bibelbøger** — boggitter og sektioner (fuld bredde)
- **Bibelkapitler** — kapitelgitter (fuld bredde)
- **PDF'er** — PDF-biblioteket bruger et bredere kortgitter (fuld bredde)
- **Indstillinger** — individuelle indstillingssider (fuld bredde)
- **Hjælp** — hjælpeartikler (fuld bredde)

## Opsummering

På en tablet får du:

- **Parallelle Bibler** i lodrette ruder side om side
- **Kommentar** i vedvarende sidepaneler
- **Sammenlign** og **Ordbog** i brede kort
- **Leksikon** fra et tryk på et hvilket som helst Ordinfo-kort
- **Bogmærker, Fremhævninger, Noter, Andagter, Bøger, Indstillinger** i master-detay-delte visninger
- **Søgning** med resultater ved siden af søgeformularen
- **Landskab** og **portræt** understøttes begge med automatiske layoutændringer

På en telefon bruger alt den traditionelle enkelt-kolonne navigation med gennemklik. Appen opdager skærmbredden ved start og vælger det rigtige layout automatisk.
