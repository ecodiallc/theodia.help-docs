---
title: Ændring af temaer og skrifttyper
level: everyday
categories: settings
summary: Sådan ændrer du appens udseende.
---

# Ændring af temaer og skrifttyper

Theodia lader dig ændre, hvordan appen ser ud. Du kan vælge et tema (light eller dark) og en skriftstørrelse.

## Sådan åbner du udseende-indstillingerne

1. Åbn **Indstillinger**.
2. Tryk på **Udseende**.

## Sådan ændrer du temaet

I sektionen **Udseende** ser du to temaknapper:

- **Standard** — en lys baggrund med mørk tekst. God til dagtid.
- **Mørk** — en mørk baggrund med lys tekst. God til nattetid og sparer batteri.

Tryk på et tema for at anvende det. Ændringen er øjeblikkelig.

## Sådan ændrer du skriftstørrelsen

I sektionen **Udseende** trykker du på en af størrelsesknapperne: **---**, **--**, **-**, **Normal**, **+**, **++**, **+++**. Teksten bliver mindre eller større i hele appen. Vælg den størrelse, der er lettest for dig at læse.

## Tips

- Mørkt tema sparer batteri på telefoner med OLED-skærme.
- Hvis teksten er for lille til at læse, øg skriftstørrelsen i appen, ikke på enheden. Appens indstilling er finere.
- Til lang læsning, prøv det mørke tema og en større skrift.
- [Aktivér ørken-temaet](theodia://unlock-desert)
