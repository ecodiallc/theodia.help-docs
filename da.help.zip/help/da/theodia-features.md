---
title: Theodias funktioner
level: beginner
categories: welcome
summary: Et hurtigt overblik over, hvad der gør Theodia særlig, og hvordan den hjælper dig med at studere Bibelen.
---

# Theodias funktioner

Theodia er bygget til at være en komplet Bibelstudie-kammerat. Her er, hvad der gør den særlig.

## Offline først

Alt virker uden internet. Bibler, kommentarer, leksika, bøger og andagter gemmes på din enhed. Du kan læse, søge og studere hvor som helst — i et fly, i et fjernt område eller ethvert sted uden signal.

## Privatliv først

Dine data forbliver hos dig. Noter, fremhævninger, bogmærker og læsehistorik gemmes lokalt på din enhed. Ingen konto behøves, og intet sendes til en server, medmindre du selv vælger at bruge den valgfrie AI-assistent.

## Tablet-understøttelse

Theodia er designet til både telefoner og tablets. På en større skærm får du mere plads til læsning, parallelle Bibel-visninger og et layout, der udnytter den ekstra plads.

## Installérbare ressourcer

Du er ikke begrænset til det, der følger med appen. Du kan tilføje flere Bibelversioner, kommentarer, leksika, bøger og andagter. Ressourcerne findes på projektets GitHub-side og kan installeres direkte i appen.

## AI-assistent

Den valgfrie AI-assistent hjælper dig med at forstå vers, forklare sammenhæng og besvare spørgsmål. Den er kun aktiv, hvis du slår den til. Som standard forbinder den til en fjernmodel, du angiver via et endpoint og en API-nøgle, du konfigurerer. Første gang du bruger AI'en, beder appen om din tilladelse og viser præcis, hvad der sendes.

## Parallel Bibel-læsning

Læs op til fire Bibelversioner på én gang. Når du åbner et kapitel, vises din hovedoversættelse først, og hvert vers følges af samme vers i dine valgte parallelle oversættelser. Sammenlign ordlyd, studér forskelle og få et fyldigere billede af teksten. Gem dine yndlingskombinationer som forudindstillinger, og skift hurtigt mellem dem.

## Fuldtekst-søgning

Søg på tværs af enhver Bibelversion. Find ord, fraser eller delvise match. Du kan også begrænse søgningen til et udvalg af bøger.

## Krydshenvisninger

Tryk på en vershenvisning for at hoppe direkte til den passagen. Krydshenvisningerne er indbyggede og virker på tværs af hele Bibelen.

## Leksikon og Strongs-numre

Tryk på et Strongs-nummer for at se den oprindelige græske eller hebraiske definition. Leksikonposter er medtaget til dybere ordstudier.

## Bogmærker og fremhævninger

Gem vers med bogmærker og markér dem med farver. Alt gemmes lokalt og overlever mellem sessioner.

## Noter

Skriv dine egne tanker ved siden af ethvert vers. Noterne er knyttet til verset og nemme at finde senere.

## Daglig andagt

Start din dag med en kort andagt. Appen inkluderer andagter, der åbner dagens indgang automatisk.

## Kristne bøger

Læs klassisk kristen litteratur inde i appen. Bøgerne er formateret til let læsning og har en indholdsfortegnelse til hurtig navigation.

## PDF-læsning

Importér dine egne PDF-dokumenter, og læs dem offline, organiseret i kategorier. Læseren understøtter søgning, indholdsfortegnelse, bogmærker, zoom og oplæsning. Du kan også installere pakkede PDF-samlinger fra fællesskabs-depotet.

## Flere sprog

Theodia understøtter mange sprog, både for appens grænseflade og Bibelindhold. Skift sprog i indstillingerne for at studere på dit foretrukne sprog.

## Mørk tilstand og temaer

Vælg mellem lys eller mørk tilstand, eller vælg et tema, der passer til din smag. Læsekomfort betyder noget, især i svagt lys.

## Datassikkerhedskopi

Tag sikkerhedskopi af dine noter, bogmærker og fremhævninger. Hold dine data trygge, og flyt dem til en ny enhed, når det behøves.

## Ingen reklamer, ingen distraktioner

Theodia er bygget til fokus. Ingen reklamer, ingen pop-ups og ingen afbrydelser. Bare teksten og dine studieværktøjer.
