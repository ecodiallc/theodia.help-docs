---
title: Oplæsning (tekst-til-tale)
level: everyday
categories: tts
summary: Lad Theodia oplæse Bibelen eller en andagt. Sådan bruger du den, hvordan du vælger en stemme, og hvad du gør, hvis den er tavs.
---

# Oplæsning (tekst-til-tale)

> **Tilstand:** Tekst-til-tale er tilgængelig i **Standard**- og **Forsker**-tilstand. Fokustilstand er kun til ren, afbrydelsesfri læsning. Du kan skifte tilstand i **Indstillinger** → **App-brugertilstand**.

Theodia kan oplæse tekst med din enheds tekst-til-tale-stemme (TTS). Du kan lytte til et enkelt vers, et helt kapitel eller en andagt. Det er nyttigt til hændefri læsning, at lytte, mens du går eller pendler, at læse med i lyden, eller blot at give dine øjne en pause.

## Hvor lyt-knappen er

Du finder en lyt-knap tre steder.

### 1. I versmenuen (enkelt vers)

Det er den hurtigste måde at lytte til ét vers ad gangen. Åbn et kapitel i [Studietilstand](theodia://help/study-mode), tryk på et vers for at åbne versmenuen, og tryk derefter på **Sig** (🔊). Oplæsningen begynder fra det vers. En lille kontrolbjælke viser sig i bunden af skærmen med afspil, pause, spole tilbage, spole frem og en stemmevælger.

Indstillingen Sig vises ikke for interlineære Bibler (MIB — Marvel Interlinear Bible — og OHGB), da de viser ord i et andet layout, der ikke læses naturligt.

### 2. Øverst i et kapitel (hele kapitlet)

Når du læser et kapitel, se på ikonrækken øverst på skærmen. Tryk på **Lyt** (🔊) for at starte oplæsning af hele kapitlet fra begyndelsen. Knappen bliver til en stop-knap (⏹), mens lyden afspilles. Tryk på den igen for at stoppe. Den samme kontrolbjælke viser sig i bunden.

Du kan hoppe til et andet vers, og Lyt-knappen dér starter fra det vers i stedet.

### 3. I en andagt

Åbn en hvilken som helst andagtsdag, og tryk derefter på **Lyt**-knappen (🔊) øverst i læsningen. Hele andagsteksten oplæses, sætning for sætning. En kontrolbjælke i bunden giver dig afspil, pause, spole tilbage og stemmestyring.

## Brug af kontrolbjælken

Mens lyden afspilles, forbliver en lille bjælke synlig i bunden af skærmen. Den har seks kontroller:

- ⏪ **Spol tilbage** — gå ét vers tilbage (eller én sætning i en andagt)
- ⏸ **Pause / ▶ Fortsæt** — pause uden at miste dit sted. Tryk igen for at fortsætte fra samme sted.
- ⏩ **Spol frem** — hop til næste vers (eller næste sætning i en andagt)
- 🎙 **Stemme** — åbn stemmevælgeren uden at forlade kapitlet (se nedenfor)
- ⚙ **Indstillinger** — åbn det udvidede indstillingspanel (se nedenfor)
- **Stop** — tryk på 🔊-knappen øverst på skærmen, eller den ⏹, der erstatter den, mens lyden afspilles, for at stoppe og lukke bjælken.

Kontrolbjælken lukker, når kapitlet slutter, eller når du trykker stop.

### Udvidede indstillinger

Tryk på ⚙ for at folde ekstra afspilningsvalg ud. Disse indstillinger varer kun for det aktuelle kapitel og nulstilles, når du skifter kapitel eller stopper med at lytte.

- ⏮ **Tilbage til start** — hop til første vers i det område, du satte.
- **Start** — skriv et versnummer for at sætte, hvor oplæsningen begynder.
- **Slut** — skriv et versnummer for at sætte, hvor oplæsningen stopper.
- **Alle** — nulstil området til hele kapitlet.
- **()** — slå til eller fra, om tekst i parenteser oplæses.
- 🔁 **Gentag** — start automatisk forfra i begyndelsen af området, når slutten nås, med en kort pause imellem. Hvis du slår dette til uden at sætte et start- eller slutvers, gentages hele kapitlet.

### I bønneskærme

Bekendelser og faste bønner, genererede bønner og bønnerutiner har deres eget sæt udvidede valg. Tryk på ⚙ i kontrolbjælken for at folde dem ud:

- **Hastighed** — tryk på farten (for eksempel `1x`) for at vælge en oplæsningshastighed fra 0.1x til 1.5x. Dit valg huskes og bruges næste gang, du oplæser noget.
- **()** — slå til eller fra, om tekst i parenteser oplæses.
- 🔁 **Gentag** — start automatisk bønnen forfra, når den slutter, med en kort pause imellem. Det er nyttigt til at lære en bekendelse eller en fast bønne udenad.

Hastighedsændring træder i kraft med det samme, uden at du mister dit sted. At slå parentes-valget til eller fra starter bønnen forfra, så ændringen kan høres fra begyndelsen.

## Sådan skifter du stemme

Du kan vælge, hvilken stemme Theodia bruger til oplæsning. Det er nyttigt, hvis du vil have en anden accent, et andet sprog eller en hurtigere eller langsommere stemme end enhedens standard.

1. Åbn **Indstillinger**.
2. Find sektionen **Tale**.
3. Tryk på **Vælg stemme**.
4. En liste over stemmer viser sig. Første række, **Systemstandard**, bruger den stemme, din enhed foretrækker. Vælg enhver anden række for at gøre den til den nye standard.
5. Dit valg gemmes og bruges næste gang, du trykker på **Lyt** eller **Sig**.

Du kan også trykke på 🎙-ikonet i lytte-kontrolbjælken for at åbne samme vælger uden at forlade kapitlet.

Stemmernes tilgængelighed afhænger helt af din enhed. iOS og Android leveres hver med et sæt indbyggede stemmer. Du kan installere flere stemmer fra din enheds **Tilgængelighed**- eller **Sprog & input**-indstillinger. Theodia kan bruge enhver stemme, der er installeret på din enhed.

## Yndlingsstemmer

Hvis din enhed har mange stemmer, kan det være langsomt at rulle gennem hele listen hver gang. Du kan oprette en kort liste over **yndlingsstemmer**, og stemmevælgerne viser så kun disse stemmer.

1. Åbn **Indstillinger**.
2. Find sektionen **Tale**.
3. Tryk på **Yndlingsstemmer** (første række øverst i sektionen).
4. Tryk på **Sæt yndlingsstemmer** for at åbne yndlings-skærmen.
5. Tryk på afspil-knappen ved siden af en stemme for at forhåndsvise den. Tryk på stjernen for at tilføje den til dine yndlings. Du kan yndlings-markere så mange stemmer, du vil.
6. Gå tilbage. Stemmevælgerne i hele Theodia viser nu kun dine yndlingsstemmer.

Hvis du fjerner alle yndlings, går vælgerne tilbage til at vise hver stemme. Yndlingsstemmer medtages, når du tager sikkerhedskopi af og gendanner Theodia-indstillinger.

## Forskellig stemme pr. Bibel

Du kan give hver Bibeloversættelse sin egen stemme. Det er nyttigt, når du skifter mellem oversættelser, der læses meget forskelligt — for eksempel en mere formel stemme til King James Version og en mere samtaleagtig stemme til en moderne oversættelse som NIV eller NLT. Det hjælper også, hvis du lytter til Bibler på forskellige sprog og vil have hver enkelt oplæst med den rigtige accent.

1. Åbn **Indstillinger**.
2. Find sektionen **Tale**.
3. Se efter **Bibelstemmer**.
4. Tryk på en hvilken som helst Bibel i listen.
5. Vælg den stemme, du vil have til den oversættelse. Første række, **Systemstandard**, bruger din vigtigste TTS-stemme til den Bibel.
6. Gentag for andre Bibler.

Overskriften viser, hvor mange Bibeloversættelser der har en brugerdefineret stemme sat. **Vælg stemme**, **Kommentarstemme**, **Bibelnoter-stemme** og **Andagtsstemme** viser også et antal, når en stemme er sat.

Næste gang du lytter til et kapitel fra den Bibel, bruger Theodia den stemme, du valgte. Alle andre Bibler fortsætter med at bruge hoved-standardstemmen, medmindre du også ændrer dem.

## Fortsæt oplæsning i baggrunden

Som standard stopper Theodia oplæsningen, når du forlader læser-skærmen, skifter til en anden app eller låser din telefon. Det forhindrer uventet lyd, når du ikke længere aktivt læser.

For at lade oplæsningen fortsætte i baggrunden:

1. Åbn **Indstillinger**.
2. Find sektionen **Tale**.
3. Slå **Fortsæt oplæsning i baggrunden** til.

Når dette er slået til, kan du skifte fane, åbne en anden app eller låse skærmen, og kapitlet eller andagten fortsætter med at oplæse. Kontrolbjælken forbliver aktiv, så du kan pause eller springe fra notifikationsområdet (hvis din enhed understøtter det).

At slå denne kontakt **fra**, mens oplæsningen allerede kører, stopper den straks.

## Hvad gør jeg, hvis det ikke virker

Tekst-til-tale afhænger af din enhed. Theodia sender teksten til operativsystemet, og operativsystemet oplæser den med en stemme. Hvis det ikke virker, prøv disse trin i rækkefølge.

### Theodia siger, at TTS ikke er tilgængelig

Nogle enheder har slet ikke TTS. Åbn **Indstillinger**, og se efter sektionen **TTS**. Hvis sektionen ikke er der, understøtter din enhed ikke TTS i denne build.

### Stemmelisten er tom

Stemmevælgeren kan vise "ingen stemmer fundet". Det betyder som regel, at enheden endnu ikke er færdig med at indlæse sine stemmer.

1. Åbn **Indstillinger → Tale → Vælg stemme**.
2. Hvis listen er tom, se efter en **Test igen**-knap lige under rullegardinmenuen. Tryk på den. Theodia forespørger enheden om stemmer igen.
3. Hvis den stadig er tom, tjek din enheds systemindstillinger. På iOS gå til **Indstillinger → Tilgængelighed → Oplæst indhold → Stemmer**, og download en stemme til dit sprog. På Android gå til **Indstillinger → Sprog & input → Output for tekst-til-tale**, og tryk på **Installér stemmedata**.
4. Luk og genåbn Theodia, så den opfanger den nye stemme.

Hvis du har sat yndlingsstemmer, og listen er tom, så sørg for, at mindst én af dine yndlings matcher en stemme installeret på denne enhed.

### Tryk på Sig, men intet sker

- Tjek, at enheden ikke er i lydløs tilstand. De fleste enheder afspiller ikke TTS-lyd i lydløs tilstand.
- Sørg for, at enhedens volumen er oppe.
- Prøv **Test igen**-knappen i **Indstillinger → Tale**.
- Åbn **Indstillinger**, og se på sektionen **System** i bunden. **TTS**-rækken bør sige **Tilgængelig**. Hvis den siger **Ikke tilgængelig**, er TTS slået fra på operativsystem-niveau. Slå den til dér, og genåbn derefter Theodia.

### Lyden afspilles, men det er det forkerte sprog

Theodia sender tekst på det aktuelle indholds sprog og beder enheden om den stemme, du valgte. Hvis den valgte stemme er til et andet sprog, kan enheden stadig oplæse teksten, men det lyder mærkeligt.

1. Åbn **Indstillinger → Tale → Vælg stemme**.
2. Vælg **Systemstandard** for at lade enheden vælge den rigtige, eller vælg en stemme, hvis sprog matcher teksten, du læser.

Theodia oplæser i øjeblikket ikke græske eller hebraiske interlineære Bibler. Sig- og Lyt-knapperne er skjulte på disse oversættelser.

### Lyden afspilles, men stopper tidligt

Hvis et vers mangler eller ikke kan læses, springer kapitlet til det næste. Hvis bjælken lukker af sig selv efter et par vers, tryk på **Lyt**-knappen (🔊) øverst på skærmen for at starte forfra.

### Oplæsningen kører, men jeg ved ikke, hvor den startede

Hvis du slog **Fortsæt oplæsning i baggrunden** til og senere hører lyd, men ikke kan finde skærmen, der startede den, kan du stoppe den hvor som helst i appen.

1. Åbn **Indstillinger**.
2. Find sektionen **Tale**.
3. Tryk på den røde **Stop oplæsning**-knap i bunden af sektionen.

Dette stopper straks enhver kørende tekst-til-tale i Theodia. Du kan også åbne app-skifteren på din enhed og stryge Theodia væk for at tvinge lyden til at stoppe.

### Den læser for hurtigt eller for langsomt

Theodia styrer ikke læsehastigheden. Farten sættes af den valgte stemme. For at ændre den:

- På iOS: **Indstillinger → Tilgængelighed → Oplæst indhold → Talehastighed**.
- På Android: **Indstillinger → Sprog & input → Output for tekst-til-tale → Talehastighed**.

## Tips

- Kontrolbjælken forbliver synlig, mens du navigerer mellem kapitler, så du kan pause, springe eller skifte stemme uden at miste dit sted.
- Theodia oplæser versnumre som små pauser. Du kan stoppe bjælken, stryge til et andet vers og derefter trykke afspil for at fortsætte derfra.
- Til lange lyttesessioner, slå **Forstyr ikke** til, så notifikationer ikke afbryder lyden.
- 🔊-knappen bruger din enheds aktuelle volumen. Hvis du tilslutter hovedtelefoner, skifter volumen til hovedtelefon-niveauet.

## Oplæsning af en PDF

Theodia kan også oplæse PDF-sider. Åbn en PDF, og tryk på **Lyt**-knappen (højttaler) i dens værktøjslinje. En kontrolbjælke viser sig med afspil/pause, spole tilbage, spole frem, stop, en fremskridtsbjælke samt farts- og stemmevælgere. Når en side slutter, fortsætter oplæsningen automatisk på næste side.

PDF-oplæsning bruger PDF'ens installerede søgbare tekst og de samme stemmer og fart som Bibel-læsning.

## Relaterede guider

- Guiden [Studietilstand](theodia://help/study-mode) dækker versmenuen og knapperne øverst på skærmen mere i detaljer.
- Guiden [Fokustilstand](theodia://help/focus-mode) er en renere læsevisning, der også understøtter TTS via 🔊-knappen i bundlinjen.
- Guiden [Almindelige problemer](theodia://help/common-problems) har løsninger til andre lyd-, stemme- og sprogproblemer.
- Guiden [Daglige andagter](theodia://help/daily-devotionals) dækker andagtslæsning og, hvor lyt-knappen findes på den skærm.
- Guiden [PDF'er](theodia://help/pdfs) dækker PDF-læseren og dens lyt-knap.
