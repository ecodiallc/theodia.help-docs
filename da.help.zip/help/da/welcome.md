---
title: Velkommen til Theodia
level: beginner
categories: welcome
summary: En kort rundtur i appen og, hvad den kan gøre for dig.
---

# Velkommen til Theodia

Theodia er en Bibelstudie-app. Den kører på din telefon eller tablet, selv når du ikke har internet. Alt, hvad du læser, søger og studerer, gemmes på din enhed.

## Hvad du kan gøre

Theodia har tre brugertilstande. Hver tilstand viser et andet sæt funktioner.

- **Læser** — læs Bibelen i en ren, afbrydelsesfri visning.
- **Standard** — alt i Læser, plus bogmærker, fremhævninger, noter, tekst-til-tale, søgning og daglige andagter.
- **Forsker** — alt i Standard, plus kommentarer, leksika, Bibel-ordbogen, AI-assistenten og mere.

Du kan skifte tilstand når som helst i **Indstillinger** → **App-brugertilstand**.

### Funktioner til rådighed for dig

Uanset hvilken tilstand du vælger, kan du altid:

- **Læse Bibelen.** Vælg mellem mange oversættelser. Skift mellem dem når som helst.
- **Søge i Bibelen.** Find et ord eller en frase. Appen viser dig hvert vers, der matcher.
- **Læse bøger og andagter.** Appen følges med kristne klassikere og en daglig andagt.

Afhængigt af din tilstand kan du også:

- **Lytte.** Få vers oplæst med oplæsningsfunktionen. (Standard og Forsker.)
- **Tage noter.** Skriv dine egne tanker ved siden af et vers. (Standard og Forsker.)
- **Fremhæve.** Markér dine yndlingsvers i farver. (Standard og Forsker.)
- **Bogmærke.** Gem vers, så du hurtigt kan finde dem igen. (Standard og Forsker.)
- **Spørge AI-assistenten.** Få hjælp til at forstå et vers. (Kun Forsker.)

## Hvor du starter

1. Åbn **Bibel**-fanen i bunden af skærmen.
2. Vælg en oversættelse.
3. Tryk på en hvilken som helst bog for at begynde at læse.

Hvis du vil lære mere, er resten af hjælpeguiderne her for dig. Vælg et emne fra listen på hjælpens hjemmeside.

## Et par ting at vide

- Du behøver ikke en konto.
- Dine noter, fremhævninger og bogmærker forbliver på din enhed.
- Du kan tage sikkerhedskopi af dem. Se guiden [Sikkerhedskopiering af dine data](theodia://help/backups) for hvordan.

## Vil du have flere ressourcer?

Appen følges med flere frit tilgængelige Bibelversioner. For ekstra Bibler, kommentarer, leksika, bøger og andagter, se guiden [Hentning af ekstra ressourcer fra GitHub](theodia://help/getting-core-files). Den viser dig, hvordan du finder og tilføjer flere ressourcer fra projektets GitHub-side.

Velkommen. Vi håber, Theodia hjælper dig med at læse og studere.
