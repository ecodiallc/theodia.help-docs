---
title: Hvad er ressourcer?
level: beginner
categories: resources
summary: Et overblik over de forskellige slags filer, Theodia bruger — Bibler, kommentarer, bøger og mere.
---

# Hvad er ressourcer?

I Theodia er en "ressource" enhver fil, der tilføjer læse- eller studiemateriale til appen. Appen selv er blot en læser og en notesbog. Biblerne, kommentarerne, bøgerne og de andre materialer, du studerer med, er alle separate filer, du indlæser.

Denne guide forklarer de forskellige slags ressourcer, og hvad hver enkelt er til.

## Hvorfor betyder det noget?

Når du åbner Theodia for første gang, har den allerede et par ting at læse. Efterhånden som du udforsker, vil du se knapper til at installere mere. At vide, hvad hver slags ressource er, hjælper dig med at beslutte, hvad du skal tilføje.

## De forskellige slags ressourcer

Theodia genkender filer efter deres endelse. Hver endelse er en anden slags ressource.

### `.bible` — en Bibeloversættelse

En Bibeloversættelse er en fuld kopi af Bibelen i en bestemt version, som King James Version. Theodia følges med et par oversættelser og lader dig tilføje flere.

Se guiden [Installation af Bibeloversættelser](theodia://help/installing-bibles) for detaljer.

### `.commentary` — en kommentar

En kommentar er en bog med studienoter skrevet af en Bibelforsker. For et givet vers fortæller kommentaren dig baggrunden, betydningen, og hvordan verset passer ind i resten af Bibelen.

Se guiden [Kommentarer og leksika](theodia://help/commentaries-and-lexicons) for detaljer.

### `.lexicon` — et leksikon

Et leksikon er en ordbog over Bibelord. Det fortæller dig det oprindelige hebraiske eller græske ord, hvad det betyder, og hvordan det bruges i Bibelen.

Se guiden [Kommentarer og leksika](theodia://help/commentaries-and-lexicons) for detaljer.

### `.book` — en kristen bog

En bog er et længere kristent værk, som en klassiker fra kirkens historie. At læse bøger i appen fungerer meget som at læse en Bibel. Theodia følges med et lille bibliotek af frit tilgængelige kristne klassikere.

Se guiden [Læsning af indbyggede bøger](theodia://help/reading-books) for detaljer.

### `.devotional` — en andagt

En andagt er en kort daglig læsning. Hver indgang har som regel et vers, en kort refleksion og en bøn eller et spørgsmål at tænke over. Mange andagter er designet til at blive læst én indgang om dagen i et år.

Se guiden [Daglige andagter](theodia://help/daily-devotionals) for detaljer.

### `.sqlite` — en referencedatabase

En referencedatabase er en stor opslagsfil, appen bruger til at give dig ekstra information, mens du læser. Der er to slags:

- **Krydshenvisninger** — lister over vers, der knytter sig til det vers, du læser.
- **Morfologi** — information om de oprindelige hebraiske eller græske ord i verset.

Du åbner dem ikke direkte. De virker i baggrunden og tilføjer funktioner til Bibel-læseren. Se guiden [Krydshenvisninger](theodia://help/cross-references) for detaljer.

### `.data` — orddata

En orddata-fil indeholder ekstra information om de oprindelige Bibelord. Den bruges af leksikon og studieværktøjer. Ligesom referencedatabaserne åbner du den ikke direkte. Appen bruger den i baggrunden.

## Sådan tilføjer du en ressource

Appens **Administrer ressourcer**-skærm er den lette måde at tilføje en ressource på.

1. Åbn **Indstillinger**.
2. Tryk på **Administrer ressourcer**.
3. Tryk på **Installér fra GitHub**.
4. I download-vinduet vælger du en fane — **Bibler**, **Kommentarer**, **Bøger**, **Andagter** eller **Kerne** — og vælger derefter, hvad du vil have, og trykker på **Installér valgte**.
5. Eller tryk på **Installér lokal fil** for at importere en fil, du allerede har downloadet.

For en trin-for-trin gennemgang af at hente filer direkte fra GitHub, se guiden [Hentning af ekstra ressourcer fra GitHub](theodia://help/getting-core-files).

## Sådan fjerner du en ressource

1. Åbn **Indstillinger**.
2. Tryk på **Administrer ressourcer**.
3. Find den ressource, du vil fjerne.
4. Tryk på skraldespands-ikonet ved siden af den.
5. Bekræft, at du vil fjerne den.

At fjerne en ressource sletter ikke dine noter, fremhævninger eller bogmærker. De forbliver trygge.

## Hvor ressourcerne findes på din enhed

Ressourcerne gemmes på din enhed, ikke i cloud. Når en ressource er installeret, behøver du ikke internettet for at læse den. Du kan tage sikkerhedskopi af din enhed, men selve ressourcerne tages ikke i sikkerhedskopi til cloud af Theodia. Hvis du afinstallerer og geninstallerer appen, bliver du nødt til at tilføje de ressourcer, du havde installeret, igen.

## Hjælp og spørgsmål

Hvis du har problemer, se guiden [Hvor du stiller spørgsmål](theodia://help/getting-more-help). Teamet og fællesskabet kan hjælpe.
