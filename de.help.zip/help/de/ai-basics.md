---
title: KI-Grundlagen
level: advanced
categories: ai
summary: So nutzt du den KI-Assistenten, um Verse besser zu verstehen.
---

# KI-Grundlagen

> **Modus:** Der KI-Assistent erfordert den **Gelehrten**-Modus. Du kannst die Modi unter **Einstellungen** → **App-Benutzermodus** wechseln.

Theodia hat einen KI-Assistenten. Er hilft dir, einen Vers zu verstehen, eine Frage zu beantworten oder ein Bibelthema zu durchdenken.

## KI aktivieren

Die KI ist standardmäßig ausgeschaltet. So schaltest du sie ein:

1. Öffne **Einstellungen**.
2. Tippe auf **KI-Assistent**.
3. Tippe auf den Schalter, um ihn einzuschalten.

## KI öffnen

Tippe unten auf die **KI**-Registerkarte. Ein Chat-Fenster öffnet sich.

## Eine Frage stellen

Tippe auf das Feld unten. Gib deine Frage ein. Tippe auf **Senden**.

Einige Fragen, die du stellen kannst:

- "Was bedeutet Johannes 3,16?"
- "Erzähl mir vom Buch der Römer."
- "Was ist die Frucht des Geistes?"
- "Vergleiche die Bergpredigt bei Matthäus und Lukas."

## Zu einem bestimmten Vers fragen

1. Öffne ein Kapitel.
2. Tippe auf einen Vers, um das Vers-Menü zu öffnen.
3. Tippe auf **KI-Kommentar**.

Der Vers wird an die KI gesendet. Das KI-Panel öffnet sich mit dem bereits eingetragenen Vers. Du kannst eine Frage hinzufügen, etwa "Was bedeutet das?" oder "Wie kann ich das anwenden?"

## Wichtiges zur KI

- Die KI ist ein Werkzeug, keine Person. Sie kann Fehler machen.
- Prüfe die Antworten der KI immer an der Bibel selbst.
- Die KI braucht möglicherweise das Internet. Sie funktioniert nicht offline.
- Wenn du die KI nutzt, werden deine Fragen, der Vers-Kontext und dein API-Schlüssel an den von dir gewählten Endpunkt gesendet. Beim ersten Mal fragt die App nach deiner Erlaubnis und zeigt genau, was gesendet wird. Du kannst diese Erlaubnis später unter **Einstellungen → KI-Assistent → Remote-KI-Datenweitergabe** ändern oder widerrufen.
- In manchen Regionen, etwa der China-Mainland-Version im App Store, ist der KI-Assistent nicht verfügbar. Dort stehen nur offline Bibel-Funktionen zur Verfügung.

## Gespräche verwalten

Der KI-Bildschirm speichert vergangene Gespräche. In der Liste kannst du ein altes Gespräch öffnen, ein neues beginnen oder eines löschen, das du nicht mehr brauchst.

## Mehr zur KI erfahren

Diese Seite behandelt die Grundlagen. Theodias KI kann weitaus mehr als chatten. Hier geht es weiter:

- **[KI-Funktionen](theodia://help/ai-features)** — Entdecke alles, was Theophilus kann: Ein-Tippen-Studien auf Griechisch und Hebräisch, Parallelstellen-Ketten, Predigtentwürfe, Gebete, Morphologie und Originalsprachen-Wörter, Wörterbuch-Abfragen und freihändige Navigation.
- **[Bessere KI-Fragen stellen](theodia://help/ai-prompts)** — Lerne, Fragen so zu formulieren, dass sie reiche, genaue Antworten liefern. Ein paar kleine Änderungen an der Formulierung können die Antworten deutlich vertiefen.
- **[KI-Modell auswählen](theodia://help/choosing-a-model)** — Nicht jedes Modell ist gleich. Finde heraus, welche Theodias eingebaute Werkzeuge unterstützen und aus der KI einen echten freihändigen Bibelstudien-Partner machen.
- **[GitHub Models](theodia://help/github-models)** — Der empfohlene kostenlose Anbieter. Hol dir mit einem GitHub-Konto einen kostenlosen API-Schlüssel und starte auf einer großzügigen täglichen Stufe. Keine Kreditkarte, kein Abo.
- **[API-Schlüssel und Kosten](theodia://help/ai-keys-and-costs)** — Verstehe, wie API-Preise bei verschiedenen Anbietern funktionieren und wie du die Kosten nahezu bei Null hältst.
