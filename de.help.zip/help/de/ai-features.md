---
title: KI-Funktionen
categories: ai
level: advanced
summary: Entdecke alles, was Theodias KI kann — von Vers-für-Vers-Studium bis zur Predigtvorbereitung, Originalsprachen-Forschung und freihändiger Navigation.
---

# KI-Funktionen

> **Modus:** Der KI-Assistent erfordert den **Gelehrten**-Modus. Du kannst die Modi unter **Einstellungen** → **App-Benutzermodus** wechseln.

Theodias KI-Assistent, Theophilus, ist nicht nur ein Chatbot. Er ist ein Studienpartner, der die Bibel neben dir lesen, Kommentare nachschlagen, Schrift suchen, deine Notizen verwalten und sogar die App steuern kann — alles per Sprache oder Text.

Bevor Theophilus Daten an einen KI-Endpunkt sendet, zeigt die App eine Zustimmungsabfrage, die erklärt, was gesendet wird, und fragt nach deiner Erlaubnis. Du kannst diese Erlaubnis jederzeit unter **Einstellungen → KI-Assistent → Remote-KI-Datenweitergabe** ändern oder widerrufen.

## KI-Vers-Chat: Einen Vers tiefgründig studieren

Der **KI-Vers-Chat** ist das Herzstück der KI-Erfahrung in Theodia. Während du ein Kapitel liest, tippe auf eine Versnummer (oder halte den Vers lange gedrückt) und wähle **KI-Kommentar**. Ein Chat-Panel öffnet sich mit diesem bereits geladenen Vers. Die KI weiß genau, was du liest, und ist bereit, ihn mit dir zu erforschen.

### Schnellstarter mit einem Tippen

Du weißt nicht, was du fragen sollst? Das Panel zeigt acht Sofort-Starter:

- **Diesen Vers erklären** — Erhalte eine klare, durchdachte Aufschlüsselung von Bedeutung und Tragweite.
- **Originalsprache** — Sieh die griechischen oder hebräischen Wörter, Transliterationen und lexikalischen Definitionen hinter dem englischen Text.
- **Historischer Kontext** — Erfahre mehr über Kultur, Politik und Ereignisse um den Vers herum.
- **Textueller Kontext** — Sieh, wie der Vers in den Absatz, das Kapitel und das Buch um ihn herum passt.
- **Hauptthemen** — Entdecke die großen Ideen, die dieser Vers zur biblischen Theologie beiträgt.
- **Auf mein Leben anwenden** — Erhalte praktische, persönliche Anwendungen, die du heute umsetzen kannst.
- **Ein Gebet generieren** — Verwandle den Vers in ein Gebet, das an seiner Sprache und Wahrheit orientiert ist.
- **Predigtentwurf generieren** — Erhalte einen Drei-Punkte-Entwurf mit Einleitung und Schluss, bereit zu predigen.

Tippe einen beliebigen Starter an, und die KI beginnt sofort. Du kannst mit eigenen Fragen nachhaken, um Klarstellung bitten oder die Unterhaltung in eine neue Richtung lenken.

### Nachfragen wie in einem echten Gespräch

Die KI merkt sich die letzten Nachrichten im Chat, sodass du natürlich tiefer graben kannst:

- "Kannst du das einfacher sagen?"
- "Was sagt das ursprüngliche Griechisch hier?"
- "Zeige mir Parallelstellen, die damit verbunden sind."
- "Vergleiche diesen Vers in drei verschiedenen Übersetzungen."
- "Wie sähe das in einer modernen Arbeitswelt aus?"
- "Gib mir drei weitere Anwendungen für Eltern."

Das Gespräch bleibt an den Vers gebunden, sodass jede Antwort im Text verankert ist, den du gerade liest.

### Auf Bibelstellen tippen

Wenn die KI einen anderen Vers erwähnt — etwa "Das spiegelt Römer 8,28" — erscheint die Stelle als **anklickbarer Link**. Tippe darauf, und die App springt zu dieser Passage im Bibelleser. Du kannst die Kette von Stellen erkunden, ohne das Gespräch zu verlassen.

## Was die KI über den Vers-Chat hinaus kann

Theophilus hat Zugriff auf die gesamten Inhalte von Theodia — Bibeln, Kommentare, Lexika, Wörterbücher, Bücher, Andachten, deine Notizen, Lesezeichen und Markierungen. Das bedeutet in der Praxis:

### Schrift lesen und navigieren

- **Lies einen beliebigen Vers oder ein Kapitel** — "Lies Johannes 3,16 in der WEB" oder "Lies Psalm 23 laut vor."
- **Öffne Passagen im Leser** — "Bring mich zu Genesis 1" oder "Öffne Römer 8,28."
- **Vergleiche Übersetzungen** — "Zeige mir Johannes 3,16 in all meinen Bibeln."
- **Durchsuche die Bibel** — "Finde Verse über Vergebung" oder "Suche nach 'Frieden, der allen Verstand übersteigt.'"
- **Parallelstellen abrufen** — "Welche anderen Verse gehören zu Jesaja 53,5?"
- **Abschnittsüberschriften lesen** — "Was sind die Zwischenüberschriften in Matthäus 5?"

### Originalsprachen erforschen

- **Lexikon-Abfragen** — "Was bedeutet das griechische Wort 'agape' in Johannes 3,16?" oder "Schlage Strong G26 nach."
- **Morphologie** — "Analysiere die griechischen Verben in Römer 8,28" oder "Was bedeutet der Morphologie-Code V-PAI-3S?"
- **Wortinformation** — Die KI sieht dieselbe wort-für-wort-Aufschlüsselung wie du in der App: Transliteration, Glosse, Grammatik und Strong-Nummern.

### Kommentare und Studienbücher lesen

- **Verskommentar** — "Was sagt Matthew Henry zu Epheser 2,8?"
- **Kapitelkommentar** — "Gib mir die Kapitelübersicht für Römer 8."
- **Buchkommentar** — "Fasse den Buch-Kommentar zur Offenbarung zusammen."
- **Studienbücher** — "Lies mir ein Kapitel aus Hymn Lyrics English vor" oder "Durchsuche meine Bücher nach 'Geduld.'"
- **Andachten** — "Lies die heutige Andacht" oder "Finde eine Andacht über Angst."

### Wörterbücher durchsuchen

- "Wer war Melchisedek?"
- "Was sagt das Bibelwörterbuch über Gilgal?"
- "Schlage 'Versöhnung' in Easton's nach."

### Dein Studienleben verwalten

Die KI kann auf deine persönlichen Daten zugreifen — sie bleiben immer lokal auf deinem Gerät gespeichert:

- **Lesezeichen** — "Setze diesen Vers in meinen Predigt-Vorbereitung-Ordner" oder "Liste meine Lesezeichen auf."
- **Markierungen** — "Markiere Johannes 3,16 in Gelb" oder "Zeige mir alle meine Markierungen."
- **Notizen** — "Erstelle eine Bibelnotiz zu diesem Vers" oder "Lies meine Notizen zu Genesis 1."
- **Studiennotizen** — "Speichere dieses Gespräch als Studiennotiz" oder "Erstelle ein neues Studiennotizbuch namens Römer-Studium."
- **Ordner** — "Erstelle einen Ordner namens Morgenandacht" oder "Verschiebe mein Lesezeichen Johannes 3,16 in den Gebets-Ordner."

### App-Einstellungen ändern

- "Wechsle in den Dunkel-Modus."
- "Mach die BSB zu meiner Standardbibel."
- "Schalte Parallelbibeln mit der NET ein."
- "Vergrößere die Schrift."

### Laut vorlesen

- "Lies Psalm 23 laut vor" — Die KI kann die Sprachausgabe für jede Passage, jedes Buch oder jede Notiz starten.
- "Stoppe das Vorlesen" — Pausiere die Sprachausgabe jederzeit.

## Gespräche speichern

Jeder KI-Vers-Chat kann gespeichert werden. Tippe im Chat-Panel auf das Menü und wähle:

- **Als Bibelnotiz speichern** — Hängt das gesamte Gespräch an die Versnotiz im Bibelleser an.
- **Als Studiennotiz speichern** — Speichert das Gespräch in deinem Studiennotizbuch zur späteren Verwendung.

So wird eine schnelle KI-Erkundung zu dauerhaftem Studienmaterial, das du wiederbesuchen, bearbeiten oder für Predigten nutzen kannst.

## Die volle KI-Registerkarte

Neben dem Vers-Chat-Panel gibt es eine eigene **KI**-Registerkarte in der unteren Navigation. Dies ist ein freier Chat, in dem du alles fragen kannst — ohne vorausgewählten Vers. Nutze ihn für:

- Themenstudien über die ganze Bibel
- Predigt-Recherche und Gliederungen
- Vergleich theologischer Themen zwischen Büchern
- Tägliche Andacht und Gebetsanregungen
- Bibel-Quiz und Lesepläne
- App-Hilfe — "Wie funktionieren Parallelbibeln?"

Deine Gespräche werden automatisch gespeichert. Du kannst zu früheren Chats zurückkehren, neue beginnen und alte Threads löschen.

## Ideen zum Ausprobieren

Hier sind einige aufregende Möglichkeiten, die KI zu nutzen. Wähle eine aus und probiere sie heute.

**Persönliches Wachstum**

- "Erkläre Philipper 4,6–7 und gib mir ein Gebet für Momente der Angst."
- "Was sagt die Bibel über Ruhe? Finde mir fünf Verse und erkläre jeden."

**Familie und Erziehung**

- "Wie sollte Epheser 6,4 die moderne Erziehung leiten? Gib mir drei praktische Regeln."
- "Finde Verse über Kindererziehung und lies sie mir laut vor."

**Predigt- und Unterrichtsvorbereitung**

- "Gliedere eine 25-minütige Predigt über Römer 8,28 mit Einleitung, drei Punkten und Schluss."
- "Was sagen meine Kommentare zur 'Rüstung Gottes' in Epheser 6?"
- "Vergleiche die Bergpredigt bei Matthäus mit der Version bei Lukas. Was sind die Unterschiede?"

**Originalsprachen-Studium**

- "Zeige mir die Morphologie für jedes Wort in Johannes 1,1."
- "Was ist der Unterschied zwischen 'agape' und 'philia' im Neuen Testament?"

**Andächtige Tiefe**

- "Lies die heutige Andacht und verbinde sie mit einem Vers aus den Psalmen."
- "Gib mir einen siebentägigen Andachtsplan über die Frucht des Geistes."

**Parallelstellen-Ketten**

- "Beginne mit Jesaja 53,5 und verfolge das Thema 'Wunden' und 'Heilung' durch das Neue Testament."
- "Wo erscheint der Gedanke 'Bund' von Genesis bis Hebräer?"

**Gedächtnis und Wiederholung**

- "Quizze mich über die Bibelbücher in der richtigen Reihenfolge."
- "Erstelle eine Studiennotiz, die den Hauptpunkt jedes Kapitels in Römern zusammenfasst."

## Einige wichtige Hinweise

- Die KI ist ein **Werkzeug**, kein Ersatz für die Bibel oder pastorale Begleitung. Vergleiche ihre Antworten immer mit der Schrift selbst.
- Wenn du die KI nutzt, reisen deine Fragen über das Internet zu den Servern des Anbieters. Die meisten Anbieter trainieren nicht mit deinen Daten, aber der Text verlässt dein Gerät.
- Die KI kann Fehler machen. Nutze Kommentare, Lexika und den Bibeltext selbst als letzte Instanz.

## Zusammenfassung

Theodias KI soll Bibelstudium schneller, tiefer und persönlicher machen. Ob du eine einfache Erklärung für einen verwirrenden Vers, einen vollen Predigtentwurf, eine griechische Wortstudie oder eine Parallelstellen-Kette über die ganze Bibel möchtest — Theophilus ist bereit. Tippe einen Vers an, stelle eine Frage und schau, wohin das Gespräch führt.
