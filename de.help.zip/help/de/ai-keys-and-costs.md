---
title: API-Schlüssel und Kosten
level: advanced
categories: ai
summary: Warum du einen API-Schlüssel brauchst, wie du einen bekommst und was die Nutzung eines Remote-KI-Modells normalerweise kostet.
---

# API-Schlüssel und Kosten

> **Modus:** Der KI-Assistent erfordert den **Gelehrten**-Modus. Du kannst die Modi unter **Einstellungen** → **App-Benutzermodus** wechseln.

Der KI-Assistent verbindet sich mit Remote-KI-Modellen. Wenn du eines nutzen möchtest, brauchst du einen API-Schlüssel. Diese Seite erklärt warum, wie du einen bekommst und was das normalerweise kostet.

## Warum du einen API-Schlüssel brauchst

Ein Remote-KI-Modell läuft auf einem Server im Internet. Der API-Schlüssel ist wie ein Passwort, das dem Server sagt: "Diese Person darf Fragen stellen." Ohne ihn antwortet der Server nicht.

Die App stellt keinen eigenen Schlüssel bereit. Du musst dir selbst ein Konto bei einem Anbieter erstellen und den Schlüssel in die App einfügen.

## Wie du einen API-Schlüssel bekommst

1. Öffne **Einstellungen** in Theodia.
2. Tippe auf **KI-Assistent**.
3. Wähle **Remote-Modell**.
4. Wähle einen Anbieter aus der Liste, oder tippe auf **Benutzerdefiniert** und gib eine Basis-URL ein.
5. Tippe auf den Link zur Schlüsselseite des Anbieters. Erstelle ein Konto, falls du noch keins hast.
6. Erstelle auf der Seite des Anbieters einen neuen API-Schlüssel.
7. Kopiere den Schlüssel und füge ihn in Theodia ein.
8. Tippe auf **Verbindung testen**, um sicherzustellen, dass alles funktioniert.

## Unterstützte Anbieter

Theodia kann sich mit jedem Anbieter verbinden, der eine OpenAI-kompatible API verwendet. Hier sind diejenigen mit voreingestellten Links in der App:

- **GitHub Models** — github.com/marketplace/models (kostenlose Tagesstufe, empfohlen)
- **OpenAI** — platform.openai.com
- **OpenRouter** — openrouter.ai
- **Anthropic** — console.anthropic.com
- **Groq** — console.groq.com
- **Mistral** — console.mistral.ai
- **Together AI** — api.together.xyz

Du kannst auch eine **benutzerdefinierte** Basis-URL verwenden, wenn du einen eigenen Server betreibst oder einen anderen Dienst nutzt.

## Was kostet das?

Die meisten Anbieter berechnen Kosten pro **Token**. Ein Token ist etwa ein Wort oder ein Wortteil. Du zahlst für die Token, die du sendest (deine Frage), plus die Token, die die KI zurücksendet (die Antwort).

### Typische Preise

Preise ändern sich, aber hier ist eine grobe Orientierung Mitte 2026:

- **Kleine schnelle Modelle** (wie günstigere GPT-3.5-Klasse) kosten einen Bruchteil eines Cents pro tausend Token.
- **Mittelklasse-Modelle** (wie GPT-4o oder Claude Sonnet) kosten typischerweise einige Cents pro tausend Token.
- **Große Reasoning-Modelle** (wie GPT-4.5 oder Claude Opus) können zehn bis zwanzig Cents pro tausend Token kosten.

Eine typische Bibelfrage in Theodia kann einige hundert bis ein paar tausend Token insgesamt verbrauchen. Das bedeutet, die meisten Fragen kosten zwischen **unter einem Cent und ein paar Cents**.

### Tipps, um Kosten gering zu halten

- Beginne mit einem günstigeren Modell. Die meisten Bibelfragen brauchen nicht das teuerste Modell.
- Nutze Groq oder OpenRouter, wenn du verschiedene Modelle testen und Preise vergleichen möchtest.
- Beobachte dein Nutzungs-Dashboard auf der Seite des Anbieters.

## GitHub Models

[GitHub Models](https://github.com/marketplace/models) bietet eine kostenlose Stufe ohne Abonnement. Alles, was du brauchst, ist ein kostenloses GitHub-Konto und ein persönlicher Zugriffstoken mit Berechtigung zum Lesen von Modellen.

**So richtest du es ein:**

1. Gehe zu [github.com/settings/tokens](https://github.com/settings/tokens) und erstelle einen **Personal access token (classic)**.
2. Gib ihm den Bereich `models:read` (oder wähle einfach die Modelle-Berechtigung).
3. In Theodia wählst du **GitHub Models** als Anbieter und fügst deinen Token ein.

**Kostenlose Modelle:**

- `openai/gpt-4.1-nano` — **15 Anfragen pro Minute, 150 Anfragen pro Tag**
- `openai/gpt-4.1-mini` — **15 Anfragen pro Minute, 150 Anfragen pro Tag**
- `openai/gpt-4.1` — **10 Anfragen pro Minute, 50 Anfragen pro Tag**
- `openai/gpt-4o` — **10 Anfragen pro Minute, 50 Anfragen pro Tag**

Diese Limits setzen sich täglich zurück und sind für regelmäßiges Bibelstudium ausreichend.

Eine ausführliche Schritt-für-Schritt-Anleitung mit Screenshots findest du im gesonderten [GitHub Models](theodia://help/github-models)-Leitfaden.

## Hinweis zum Datenschutz

Wenn du ein Remote-KI-Modell nutzt, zeigt die App zuerst eine Zustimmungsabfrage, die erklärt, was gesendet wird: deine Nachrichten, Vers- oder Kapitelkontext, Tool-Aufrufe und deren Ergebnisse, der konfigurierte Modellname und dein API-Schlüssel im Anfrage-Header. Die Anfrage geht direkt an den von dir konfigurierten Endpunkt, nicht über Theodia. Die meisten Anbieter nutzen deine Daten nicht zum Trainieren ihrer Modelle, aber der Text verlässt dein Gerät. Du kannst die Erlaubnis jederzeit unter **Einstellungen → KI-Assistent → Remote-KI-Datenweitergabe** ändern oder widerrufen.

## Zusammenfassung

- Du brauchst einen API-Schlüssel, um den KI-Assistenten zu nutzen.
- Erstelle ein Konto bei einem Anbieter, generiere einen Schlüssel und füge ihn in Theodia ein.
- Die meisten Fragen kosten wenige Cents oder weniger.
