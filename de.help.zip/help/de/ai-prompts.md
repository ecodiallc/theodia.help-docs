---
title: Bessere KI-Fragen stellen
level: advanced
categories: ai
summary: Wie du den KI-Assistenten so fragst, dass du gute Antworten bekommst.
---

# Bessere KI-Fragen stellen

> **Modus:** Der KI-Assistent erfordert den **Gelehrten**-Modus. Du kannst die Modi unter **Einstellungen** → **App-Benutzermodus** wechseln.

Ein "Prompt" ist die Frage oder Anweisung, die du der KI gibst. Bessere Prompts liefern bessere Antworten. Dieser Leitfaden zeigt dir, wie.

## Sei konkret

Schlecht: "Erzähl mir von Liebe."
Besser: "In 1. Korinther 13, welche Art von Liebe beschreibt Paulus, und wie unterscheidet sie sich von romantischer Liebe?"

Je mehr Details du gibst, desto nützlicher ist die Antwort.

## Gib Kontext

Schlecht: "Was bedeutet dieser Vers?"
Besser: "Ich lese Römer 8 mit einer kleinen Gruppe. Was bedeutet 'keine Verdammnis' in diesem Kapitel, und wie hängt es mit dem Rest des Kapitels zusammen?"

Kontext hilft der KI, ihre Antwort an deine Situation anzupassen.

## Frag nach einer Sache nach dem anderen

Schlecht: "Erzähl mir von Gebet, Glaube und Heilung."
Besser: "Erzähl mir zuerst von Gebet. Danach frage ich nach Glauben."

Eine Frage nach der anderen hält die Antworten fokussiert.

## Bitte die KI, eine Rolle einzunehmen

Du kannst die KI bitten, in einer bestimmten Stimme zu antworten. Zum Beispiel:

- "Antworte, als würdest du einem neuen Christen etwas beibringen."
- "Antworte als Bibelgelehrter."
- "Antworte für ein Zehnjähriges."

Die KI passt ihre Antwort an die Rolle an.

## Nutze Nachfragen

Wenn die erste Antwort nicht ganz passt, frage nach:

- "Kannst du das einfacher sagen?"
- "Kannst du mir ein Beispiel geben?"
- "Was sagt das ursprüngliche Griechisch?"
- "Wo sonst in der Bibel kommt das vor?"

Ein gutes Gespräch ist ein Hin und Her. Die KI merkt sich die letzten Nachrichten.

## Prüfe die Antworten der KI

Die KI kann Fehler machen. Sie ist ein Werkzeug, kein Lehrer.

- Vergleiche die Antwort der KI mit den Versen, auf die sie dich verweist.
- Nutze die Kommentare und Lexika in der App als zweite Meinung.
- Wenn die Antwort eine Lehre betrifft, frage einen Pastor oder eine vertraute Person.

## Häufige Prompt-Muster

Hier sind einige, die gut funktionieren:

- "Erkläre mir diesen Vers, als wäre ich ein neuer Christ."
- "Was ist der Hauptpunkt dieses Kapitels in einem Satz?"
- "Liste drei Anwendungen für meinen Alltag aus dieser Passage."
- "Welche Fragen sollte ich zu diesem Vers stellen, bevor ich ihn predige?"
