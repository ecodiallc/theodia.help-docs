---
title: App-Benutzermodus
level: beginner
categories: [user-mode]
summary: Wähle zwischen Lesen-, Standard- und Gelehrten-Modus, um zu steuern, welche Funktionen in der App verfügbar sind.
---

# App-Benutzermodus

Theodia bietet drei Benutzermodi, die steuern, welche Funktionen du siehst. Wähle den, der am besten zu deiner Nutzung passt.

## Lesen

Der einfachste Modus. Der Lesen-Modus ist für ablenkungsfreies Bibellesen.

- Lies jede Bibelübersetzung.
- Nutze den Fokus-Modus für sauberes, bildschirmfüllendes Lesen.
- Navigiere durch Bücher und Kapitel.
- Keine Studienwerkzeuge, keine KI, keine Lesezeichen, keine Markierungen.

Der Lesen-Modus ist ideal, wenn du Theodia als reine digitale Bibel ohne Zusätze erleben möchtest.

## Standard

Der Standard-Modus fügt alltägliche Funktionen für persönliches Bibelstudium hinzu.

Alles aus dem Lesen-Modus, plus:

- Lesezeichen, Markierungen und Notizen.
- Text-zu-Sprache.
- Studienbibel-Leser mit Vers-Menü.
- Parallelbibeln.
- Schnellbefehl.
- Bibelsuche.
- Tägliche Andachten und integrierte Bücher.

Der Standard-Modus ist die richtige Wahl für die meisten Nutzer, die die Bibel lesen, markieren und durchsuchen möchten, ohne fortgeschrittene Studienwerkzeuge.

## Gelehrter

Der voll ausgestattete Modus. Der Gelehrten-Modus schaltet jedes Werkzeug in Theodia für tiefes Bibelstudium frei.

Alles aus dem Standard-Modus, plus:

- Kommentare und Lexika.
- Parallelstellen.
- Bibelwörterbuch.
- Wortinformation (Strong-Abfragen).
- KI-Assistent und KI-Kommentar.
- Schnellmenü.

Der Gelehrten-Modus ist gedacht für Pastoren, Seminarystudenten und alle, die Werkzeuge für Originalsprachen und KI-gestütztes Studium nutzen möchten.

## Modus wechseln

1. Öffne **Einstellungen**.
2. Tippe auf **App-Benutzermodus**.
3. Wähle **Lesen**, **Standard** oder **Gelehrter**.

Die Änderung wirkt sofort. Menüs und Schaltflächen, die in deinem aktuellen Modus nicht verfügbar sind, werden ausgeblendet.

## Einen Modus wählen

- **Lesen** — Du willst nur die Bibel lesen, nichts anderes.
- **Standard** — Du willst Lesezeichen, Markierungen, Notizen, Suche und Andachten.
- **Gelehrter** — Du willst jedes Studienwerkzeug, inklusive KI, Kommentaren und Lexika.

Du kannst jederzeit den Modus wechseln. Deine Lesezeichen, Markierungen und Notizen werden dabei nie gelöscht; sie werden nur ausgeblendet, bis du zu einem Modus zurückkehrst, der sie unterstützt.
