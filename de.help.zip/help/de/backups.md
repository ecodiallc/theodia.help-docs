---
title: Daten sichern
level: everyday
categories: settings
summary: So sicherst und stellst du deine Notizen, Markierungen, Lesezeichen und Geheimnisse wieder her.
---

# Daten sichern

Deine Notizen, Markierungen, Lesezeichen und Einstellungen werden auf deinem Gerät gespeichert. Wenn du dein Telefon verlierst, ein neues bekommst oder die App deinstallierst, können diese Daten verloren gehen. Dieser Leitfaden zeigt dir, wie du sie sicherst.

## Sicherungseinstellungen öffnen

1. Öffne **Einstellungen**.
2. Tippe auf **Sicherung**.

## Eine App-Sicherung erstellen

1. Öffne **Einstellungen**.
2. Tippe auf **Sicherung**.
3. Tippe auf **App-Sicherung erstellen**.
4. Wähle einen Ordner auf deinem Gerät, um die Datei zu speichern. Du kannst auch einen Cloud-Speicher wählen.
5. Die App erstellt eine einzelne Datei mit allen deinen Daten. Die Datei endet auf `.zip`.

## Wie oft du eine Sicherung machen solltest

Erstelle eine Sicherung:

- Nachdem du viele Notizen geschrieben hast.
- Bevor du das Betriebssystem deines Geräts aktualisierst.
- Bevor du die App deinstallierst oder das Telefon wechselst.

Eine gute Gewohnheit ist eine Sicherung pro Monat. Manche Menschen sichern jede Woche.

## Aus einer App-Sicherung wiederherstellen

1. Öffne **Einstellungen**.
2. Tippe auf **Sicherung**.
3. Tippe auf **App-Sicherung wiederherstellen**.
4. Wähle die `.zip`-Sicherungsdatei.
5. Für jeden Datentyp (Notizen, Markierungen, Lesezeichen usw.) entscheide, ob du das auf dem Gerät Vorhandene behalten, durch die Sicherung ersetzen oder überspringen willst.
6. Tippe auf **Wiederherstellen**.

Die App ersetzt deine Daten durch die Daten in der Sicherung. Dazu gehören:

- Notizen
- Markierungen
- Lesezeichen
- Lesezeichen-Ordner
- Einstellungen (Thema, Schriftgröße, Sprache)

## Sicherung geheimer Daten

Deine **App-Sicherung** enthält **keine** sensiblen Geheimnisse wie deinen KI-API-Schlüssel oder GitHub-Token. Um diese separat zu sichern, nutze **Sicherung geheimer Daten**.

### Geheime Daten sichern

1. Öffne **Einstellungen**.
2. Tippe auf **Sicherung**.
3. Tippe unter **Sicherung geheimer Daten** auf **Geheime Daten-Backup erstellen**.
4. Gib ein starkes Passwort ein und bestätige es.
5. Die App verschlüsselt deine Geheimnisse und teilt die verschlüsselte Datei. Speichere sie an einem sicheren Ort.

### Geheime Daten wiederherstellen

1. Öffne **Einstellungen**.
2. Tippe auf **Sicherung**.
3. Tippe unter **Sicherung geheimer Daten** auf **Geheime Daten wiederherstellen**.
4. Wähle die verschlüsselte Sicherungsdatei.
5. Gib dasselbe Passwort ein, das du beim Erstellen verwendet hast.
6. Deine Geheimnisse werden wiederhergestellt.

> **Wichtig:** Wenn du das Passwort vergisst, können die Geheimnisse nicht wiederhergestellt werden. Es gibt keinen Reset.

## Dinge, die du wissen solltest

- Eine Wiederherstellung **ersetzt** die gewählten Kategorien. Alles, was du nach der Sicherung hinzugefügt hast, geht in diesen Kategorien verloren.
- Eine App-Sicherung ist eine einzelne `.zip`-Datei. Bewahre sie an einem sicheren Ort auf.
- Du kannst die Datei kopieren, verschieben oder in einem Cloud-Dienst speichern.
- App-Sicherungen enthalten nicht die Bibelübersetzungen selbst. Diese kannst du unter **Einstellungen** → **Ressourcen verwalten** erneut herunterladen.
- Sicherungen geheimer Daten sind mit deinem Passwort verschlüsselt. Wähle ein Passwort, das du dir merken kannst.

## Tipp

Wenn du mehr als ein Gerät hast, kannst du die Sicherungsdatei auf jedes Gerät kopieren und dort wiederherstellen. Deine Daten sind dann auf beiden gleich.
