---
title: Lesezeichen setzen
level: everyday
categories: [annotate, read]
summary: So speicherst du Verse, damit du sie wiederfindest.
---

# Lesezeichen setzen

> **Modus:** Lesezeichen sind im **Standard**- und **Gelehrten**-Modus verfügbar. Der Fokus-Modus ist nur für sauberes, ablenkungsfreies Lesen. Du kannst die Modi unter **Einstellungen** → **App-Benutzermodus** wechseln.

Ein Lesezeichen speichert einen Vers oder ein Buchkapitel, damit du es wiederfindest. Lesezeichen sind wie Register in einem Buch.

## Einen Vers mit Lesezeichen markieren

1. Öffne den Vers.
2. Tippe auf den Vers, um das Menü zu öffnen.
3. Tippe im Menü auf **Lesezeichen**. Ein Stern markiert den Vers als gespeichert.

Ein Häkchen auf dem Symbol bedeutet, dass der Vers jetzt mit Lesezeichen versehen ist.

## Ein Buchkapitel mit Lesezeichen markieren

Wenn du ein Buch (keine Bibel) liest, kannst du das ganze Kapitel mit Lesezeichen markieren:

1. Öffne das Kapitel.
2. Tippe oben auf das **Lesezeichen**-Symbol.

## Deine Lesezeichen ansehen

Tippe unten auf die **Lesezeichen**-Registerkarte. Dort siehst du eine Liste jedes gespeicherten Verses und Buchkapitels.

## Ein Lesezeichen entfernen

- **Einen Vers:** Öffne den Vers. Tippe auf den Vers, dann erneut auf das **Lesezeichen**-Symbol. Das Häkchen verschwindet.
- **Aus der Liste:** Tippe in der **Lesezeichen**-Registerkarte lange auf ein Lesezeichen. Ein kleines Menü erscheint. Tippe auf **Löschen**. (Du kannst auch den kleinen ×-Button in der Zeile nutzen.)

## Mit Ordnern organisieren

Du kannst Lesezeichen in Ordnern ablegen. Zum Beispiel könntest du Ordner namens "Predigt-Vorbereitung" und "Ermutigung" haben.

So erstellst du einen Ordner:

1. Öffne die **Lesezeichen**-Registerkarte.
2. Tippe oben auf **Ordner verwalten**.
3. Tippe oben in der Ordnerliste auf **+ Ordner erstellen**.
4. Gib einen Namen ein und tippe auf **Speichern**.

Du kannst nicht zwei Ordner mit demselben Namen erstellen. Wenn ein Name bereits existiert, erscheint innerhalb des Erstellen-Fensters eine Fehlermeldung, damit du den Namen ändern und es erneut versuchen kannst.

So legst du ein Lesezeichen in einem Ordner ab:

1. Tippe in der **Lesezeichen**-Registerkarte lange auf ein Lesezeichen.
2. Tippe auf **In Ordner verschieben**.
3. Wähle den Ordner und tippe auf **Fertig**.

## Lesezeichen importieren

Du kannst Lesezeichen aus anderen Apps und Dateien in Theodia importieren.

Gehe zu **Einstellungen** → **Lesezeichen** → **Lesezeichen importieren**. Wähle **Aus Datei importieren** oder füge aus der Zwischenablage ein. Die App erkennt das Format automatisch.

### Unterstützte Formate

**Eigenes JSON-Exportformat** — Das Format, das Theodias eigene Exportfunktion nutzt. Es erhält Ordner und Erstellungsdaten.

**Netscape Bookmark HTML** — Das Format, das Chrome, Firefox und Safari beim Exportieren von Lesezeichen verwenden. Ordner werden erhalten.

**CSV** — Eine Tabelle mit Spalten. Die App sucht nach den Spalten `url` und `folder` (oder `href` / `category`). Beispiel:

```csv
url,folder
/bible/KJV/John/3,Favoriten
/bible/KJV/Genesis/1,Predigt-Vorbereitung
```

**Reiner Text** — Jede Zeile ist entweder eine Bibelstelle, eine App-URL oder eine Ordner-Anweisung. Beispiel:

```
folder: Favoriten
John 3:16
Genesis 1:1
folder: Predigt-Vorbereitung
Matthew 5:1
```

- Zeilen, die mit `folder: <Name>` beginnen, legen den aktiven Ordner für alle folgenden Lesezeichen fest.
- Bibelstellen wie `John 3:16` werden in deiner Standardbibel zu Lesezeichen.
- App-URLs wie `/bible/KJV/John/3#v3_16` oder `/book/MyBook/1` werden direkt importiert.
- Zeilen, die mit `#` oder `//` beginnen, werden als Kommentare übersprungen.

### Tipps zum Importieren

- Doppelte Lesezeichen werden automatisch übersprungen.
- Externe URLs (wie BibleGateway-Links) werden nach Möglichkeit in App-Lesezeichen umgewandelt.
- Wenn ein Ordner aus der Importdatei bereits existiert, werden die Lesezeichen in den bestehenden Ordner gelegt.

## Tipps

- Du kannst denselben Vers in vielen Übersetzungen mit Lesezeichen versehen. Sie erscheinen alle in der Liste.
- Lesezeichen bleiben auf deinem Gerät. Sie werden nicht in die Cloud synchronisiert.
- Sieh dir den Leitfaden [Daten sichern](theodia://help/backups) an, um sie zu schützen.

## Lesezeichen in einem PDF

PDFs haben ihre eigenen Lesezeichen, getrennt von deinen Bibel-Lesezeichen. Tippe beim Lesen eines PDFs auf die **Lesezeichen**-Schaltfläche in der Werkzeugleiste des Lesers, um die aktuelle Seite zu speichern, ihr einen Namen zu geben und später zu ihr zurückzuspringen. Jedes PDF hat seine eigene Liste — siehe [PDFs](theodia://help/pdfs).
