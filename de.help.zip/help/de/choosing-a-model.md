---
title: KI-Modell auswählen
level: advanced
categories: ai
summary: Wie du ein Modell wählst, das gut mit Theodias eingebauten Werkzeugen und Fähigkeiten zusammenarbeitet.
---

# KI-Modell auswählen

> **Modus:** Der KI-Assistent erfordert den **Gelehrten**-Modus. Du kannst die Modi unter **Einstellungen** → **App-Benutzermodus** wechseln.

Nicht jedes KI-Modell funktioniert in Theodia gleich. Die beste Erfahrung bietet ein Modell, das **Tool-Nutzung** unterstützt — die Fähigkeit der KI, Theodias eingebaute Funktionen wie Bibelstellen öffnen, Suchen, Kommentare lesen und in der App navigieren zu nutzen.

## Was ist Tool-Nutzung?

Wenn du Theodias KI eine Frage stellst, kann die KI mehr als nur reden. Sie kann auch **handeln**. Zum Beispiel:

- Du sagst: "Zeige mir Johannes 3,16 in der ESV." Die KI ruft ein Werkzeug auf, um diesen Vers im Leser zu öffnen.
- Du sagst: "Was sagen meine Kommentare zu Römer 8,28?" Die KI ruft ein Werkzeug auf, um den Kommentar abzurufen.
- Du sagst: "Speichere diesen Vers als Lesezeichen." Die KI ruft ein Werkzeug auf, um ein Lesezeichen zu erstellen.

Modelle ohne Tool-Nutzung können dir nur Textantworten geben. Sie können nichts nachschlagen, nicht navigieren und nichts in der App ändern.

## Welche Modelle unterstützen Werkzeuge?

### Remote-Modelle

Die meisten modernen Remote-Modelle großer Anbieter unterstützen OpenAI-kompatible Tool-Nutzung. Im Allgemeinen:

- **Große Modelle** (wie GPT-4o, Claude Sonnet/Opus, Gemini Pro) handhaben Werkzeuge zuverlässig und können mehrere Tool-Aufrufe in einem Gespräch verketten. Anbieter- und Modellnamen werden in der App zur Orientierung angezeigt; der tatsächliche Dienst, mit dem du dich verbindest, ist derjenige, dessen Endpunkt und Schlüssel du konfiguriert hast.
- **Kleinere oder günstigere Modelle** können Werkzeuge unterstützen, sind aber weniger zuverlässig. Sie könnten einen Tool-Aufruf ignorieren oder falsch formatieren.
- **Sehr alte oder spezialisierte Modelle** unterstützen oft gar keine Werkzeuge.

Wenn du unsicher bist, teste das Modell in Theodia. Bitte es: "Zeige mir Genesis 1,1" oder "Suche in der Bibel nach Verse über Liebe." Wenn der Vers geöffnet oder Suchergebnisse erscheinen, funktioniert die Tool-Nutzung.

## Empfohlene Modelle für Theodia

Diese Optionen bieten ein gutes Gleichgewicht aus Kosten, Qualität und Tool-Unterstützung:

- **OpenAI GPT-4o** — ausgezeichnete Tool-Unterstützung, schnell, bewältigt komplexe mehrstufige Fragen gut.
- **Anthropic Claude Sonnet / Opus** — sehr zuverlässiger Werkzeuggebrauch, großartig für lange Passagen und detailliertes Studium.
- **Groq** (verschiedene Modelle) — schnelle Inferenz, oft kostenlos oder sehr günstig, Tool-Unterstützung variiert je nach Modell.
- **OpenRouter** — ermöglicht es, viele Modelle mit einem Konto zu testen. Suche nach Modellen, die in ihren Fähigkeiten "function calling" oder "tools" angeben.
- **[GitHub Models](theodia://help/github-models)** — der empfohlene kostenlose Anbieter. Zugang zu OpenAI, Anthropic und anderen Modellen über dein GitHub-Konto mit einer großzügigen täglichen kostenlosen Stufe. Verwendet dieselben `openai/gpt-4o`-Modell-IDs.

## Modelle, die du vermeiden solltest

- **Reine Textvervollständigungsmodelle** (wie GPT-3-Basis oder rohes LLaMA ohne Instruction Tuning) unterstützen meist keine Werkzeuge.
- **Nur-Bild- oder Vision-Modelle**, die auf Bilder fokussiert sind, fehlt möglicherweise die Text-Tool-Unterstützung.
- **Extrem kleine Modelle** unter 1 Milliarde Parametern verwenden Werkzeuge selbst dann wahrscheinlich nicht korrekt, selbst wenn die API das behauptet.

## Tool-Unterstützung testen

Theodia prüft die Tool-Unterstützung automatisch. Nachdem du ein Modell unter **Einstellungen → KI-Assistent** eingerichtet hast, tippe auf **Verbindung testen**. Sobald die Verbindung klappt, sendet die App eine zweite Anfrage mit einer Beispiel-Tool-Definition. Du siehst eines von zwei Ergebnissen:

- **✓ Werkzeuge unterstützt** — Das Modell akzeptiert Tool-Aufrufe und kann Theodias eingebaute Funktionen nutzen.
- **✗ Werkzeuge nicht unterstützt** — Das Modell lehnt die Tool-Anfrage ab. Es wird nur textbasiert antworten und kann keine Verse öffnen, suchen oder Lesezeichen verwalten.

Wenn du "Werkzeuge nicht unterstützt" siehst, kann das Modell immer noch als einfacher Text-Chat-Assistent funktionieren, aber du verlierst die integrierte, freihändige Erfahrung.

Du kannst es auch manuell prüfen, indem du der KI etwas zu tun gibst:

- "Zeige mir Matthäus 5,3 in der KJV." — Sollte den Vers im Leser öffnen.
- "Was sagt das Lexikon zum Wort 'agape' in Johannes 3,16?" — Sollte Lexikon-Daten liefern.
- "Suche in der Bibel nach Verse über Vergebung." — Sollte Suchergebnisse liefern.
- "Setze Markus 12,30 als Lesezeichen." — Sollte ein Lesezeichen erstellen.

Wenn die KI dir stattdessen eine Textbeschreibung gibt, hat das Modell Schwierigkeiten, seine Werkzeuge zu nutzen, auch wenn die App Unterstützung gemeldet hat.

## Was, wenn mein Modell keine Werkzeuge unterstützt?

Du kannst es trotzdem nutzen. Die KI wird textbasiert antworten, und du kannst Verse, Suche und Navigation manuell in der App erledigen. Aber du verpasst die freihändige, integrierte Erfahrung, die Theodia stark macht.

## Zusammenfassung

- Wähle ein Modell mit Unterstützung für **Tool-Nutzung / Funktionsaufrufe** für die beste Theodia-Erfahrung.
- **Große Remote-Modelle** handhaben Werkzeuge am zuverlässigsten.
- Teste jedes Modell mit einfachen Befehlen wie "Zeige mir Genesis 1,1", um die Tool-Unterstützung zu prüfen.
