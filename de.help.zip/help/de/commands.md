---
title: Schnellbefehle
level: everyday
categories: [layout, study]
summary: Der Schnellbefehl lässt dich mit einer kurzen Eingabe zu jeder Funktion springen. Lerne die unterstützten Formate und Beispiele.
---

# Schnellbefehle

Der **Schnellbefehl** lässt dich mit einer kurzen Anweisung zu fast jedem Teil von Theodia springen. Du kannst ihn auf der Startseite oder im **Schnellmenü** (das **▼**-Symbol in der Kopfzeile) nutzen.

## So funktioniert es

1. Tippe auf das Befehlsfeld.
2. Gib einen Befehl ein.
3. Tippe auf die Bestätigen-Taste deiner Tastatur.

Die App liest den Befehl und bringt dich direkt zur richtigen Ansicht.

## Kein Schrägstrich-Präfix

Befehle verwenden **kein** `/`-Präfix. Sie werden als normaler Text eingegeben:

```
john 3:16
search love
backup
```

Wenn du `/settings` eingibst, macht der führende `/` es unerkennbar.

## Bibelstellen

Gib eine beliebige Bibelstelle ein, um sie im Leser zu öffnen.

```
psalms 23
john 3:16
matthew 5:1
1 cor 15:10
```

Buchnamen können per vollständigem Namen oder Abkürzung erkannt werden. In nicht-englischen UI-Sprachen kannst du Buchnamen auch in der aktiven Sprache eingeben.

## Suche

```
search abraham
search love
search faith not works
```

## Lesezeichen, Vergleich, Kommentar, Parallelstellen und Wortinformation

```
bookmark john 3:16
compare genesis 1:1
commentary john 1
aicommentary eph 2:8
xref 1 cor 15:10
word info john 1:1
```

Diese Befehle öffnen das genannte Werkzeug für die angegebene Passage.

## Lexikon

Gib eine Strong-Nummer ein, um den Lexikon-Eintrag zu öffnen.

```
g1161
h7225
```

## Andachten

```
devotional
devotional smith
devotional daily
```

Ohne Namen öffnet das die Andachtsliste.

## Navigations-Abkürzungen

```
notes
highlights
bookmarks
flashcards
playlist
theoscript
resources
read john 3:16
```

Diese springen direkt zum genannten Bildschirm oder öffnen eine Passage im Leser.

## Übersetzung wechseln

Gib eine Übersetzungsabkürzung ein, um zu ihr zu wechseln.

```
kjv
web
trlit
ohgb
```

Auf einem Leserbildschirm wechselt die Übersetzung vor Ort. Überall sonst öffnet sie die Übersetzung an deiner zuletzt besuchten Passage.

## Lokalisierte Befehlsverben

Die öffentlichen Befehlsverben können in der aktiven UI-Sprache **oder** auf Englisch eingegeben werden. Englisch funktioniert immer als Fallback. Versteckte Befehle (Einstellungs-Abkürzungen, Installationsbefehle, Easter Eggs) behalten nur die englische Syntax.

## Hilfe

Gib `help` oder `commands` in das Befehlsfeld ein, um jederzeit die in-App-Befehlsreferenz zu öffnen.
