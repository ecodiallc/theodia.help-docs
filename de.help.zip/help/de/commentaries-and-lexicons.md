---
title: Kommentare und Lexika
level: everyday
categories: study
summary: So schlägst du Wortbedeutungen nach und liest Studiennotizen.
---

# Kommentare und Lexika

> **Modus:** Kommentare und Lexika erfordern den **Gelehrten**-Modus. Du kannst die Modi unter **Einstellungen** → **App-Benutzermodus** wechseln.

Theodia enthält zwei Studienwerkzeuge: **Kommentare** und **Lexika**. Sie helfen dir, die Bibel tiefer zu verstehen.

## Was ist ein Kommentar?

Ein Kommentar ist ein Buch mit Studiennotizen, verfasst von einem Bibelgelehrten. Zu einem bestimmten Vers erklärt ein Kommentar Hintergrund, Bedeutung und wie der Vers in den Rest der Bibel passt.

## Was ist ein Lexikon?

Ein Lexikon ist ein Wörterbuch der Bibelwörter. Es zeigt dir das ursprüngliche hebräische oder griechische Wort, was es bedeutet und wie es in der Bibel verwendet wird.

## Einen Kommentar öffnen

1. Öffne ein Kapitel.
2. Tippe auf einen Vers.
3. Tippe auf **Kommentar**.

Ein Panel öffnet sich. Es zeigt Notizen eines Bibelgelehrten zu diesem Vers.

## Ein Lexikon öffnen

1. Öffne ein Kapitel in einer Bibel, die Strong-Nummern enthält.
2. Tippe auf eine Strong-Nummer im Vers (zum Beispiel G1234 oder H1234).
3. Ein Panel öffnet sich mit dem ursprünglichen hebräischen oder griechischen Wort, seiner Bedeutung und anderen Versen, die das Wort verwenden.

Strong-Nummern erscheinen in einer anderen Farbe im Vers-Text, damit sie sich vom normalen Text abheben.

## Einen anderen Kommentar wählen

Der Kommentar wird aus einem Dropdown oben im Kommentar-Panel selbst ausgewählt. Öffne das Panel, tippe dann auf das Dropdown, um die installierten Kommentare zu sehen. Wähle einen anderen aus.

## Ein anderes Lexikon wählen

Das Lexikon wird aus einem Dropdown oben im Lexikon-Panel ausgewählt. Öffne das Panel, tippe dann auf das Dropdown, um die installierten Lexika zu sehen. Wähle ein anderes aus.

## Integrierte Ressourcen

Theodia liefert einen integrierten Satz an Kommentaren und Lexika mit. Diese sind in der App enthalten und funktionieren offline. Zusätzliche Kommentare und Lexika können nicht einzeln installiert oder heruntergeladen werden.

## Wann du diese nutzt

- **Kommentare** sind gut, wenn ein Vers schwer zu verstehen ist. Die Notizen geben dir Hintergrund.
- **Lexika** sind gut für Wortstudien. Sie sagen dir die genaue Bedeutung eines Wortes in der Ursprache.

## Tipp

Wenn du eine Notiz zu einem Vers behalten möchtest, mache einen Screenshot oder kopiere den Text in eine Notiz. (Siehe den Leitfaden [Notizen schreiben](theodia://help/notes).)

## Bibelwörterbuch in einfacher Sprache

Für englischsprachige Definitionen von Bibelbegriffen (Bund, Sühne, Pharisäer und so weiter) enthält Theodia auch ein Bibelwörterbuch-Werkzeug. Öffne es im Vers-Menü durch Tippen auf **Wörterbuch** (📖). Es unterscheidet sich vom Lexikon: Lexika erklären die ursprünglichen hebräischen und griechischen Wörter, während das Wörterbuch das englische Wort in einfacher Sprache erklärt. Siehe den Leitfaden [Bibelwörterbuch](theodia://help/dictionary) zur Nutzung.
