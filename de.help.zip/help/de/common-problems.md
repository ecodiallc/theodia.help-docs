---
title: Häufige Probleme
level: everyday
categories: trouble
summary: Schnelle Lösungen für Probleme, auf die du stoßen könntest.
---

# Häufige Probleme

Dieser Leitfaden behandelt die Probleme, auf die Menschen am häufigsten stoßen. Wenn dein Problem hier nicht aufgeführt ist, sieh dir den Leitfaden [Wo du Fragen stellen kannst](theodia://help/getting-more-help) an.

## Die App ist langsam

1. Schließe andere Apps im Hintergrund.
2. Starte die App neu.
3. Starte dein Gerät neu.

## Ich finde eine Bibelübersetzung nicht

1. Öffne **Einstellungen** → **Ressourcen verwalten**, um zu sehen, was installiert ist.
2. Wenn die Übersetzung nicht dort ist, tippe auf **Aus GitHub installieren**.
3. Tippe im Download-Dialog auf die **Bibeln**-Registerkarte (oder **Globale Bibeln**) und wähle die gewünschte Übersetzung.
4. Tippe auf **Ausgewählte installieren** und warte, bis der Download fertig ist.
5. Zum Herunterladen einer neuen Übersetzung brauchst du das Internet.

## Meine Notizen oder Lesezeichen sind weg

1. Prüfe, ob du im richtigen Tab bist. Notizen sind in der **Bibelnotizen**-Registerkarte. Lesezeichen sind in der **Lesezeichen**-Registerkarte.
2. Wenn du kürzlich eine Sicherung wiederhergestellt hast, kann diese deine Daten ersetzt haben. Prüfe das Datum der Sicherung.
3. Wenn du die App deinstalliert und neu installiert hast, sind deine Daten verloren. Sichere das nächste Mal vorher.

## Die Suche findet keine Verse

1. Stelle sicher, dass du das Wort richtig geschrieben hast.
2. Versuche ein kürzeres Wort. "Liebe" findet mehr Verse als "liebend".
3. Stelle sicher, dass du die richtige Bibelübersetzung installiert hast. Die Suche funktioniert nur in den Übersetzungen, die du hast.

## Vorlesen funktioniert nicht

1. Stelle sicher, dass die Lautstärke deines Geräts aufgedreht ist.
2. Stelle sicher, dass die App die Erlaubnis hat, den Lautsprecher zu nutzen.
3. Versuche eine andere Übersetzung. Manche Übersetzungen funktionieren besser mit Vorlesen als andere.
4. Für eine Schritt-für-Schritt-Checkliste sieh dir den Leitfaden [Laut vorlesen](theodia://help/tts) an.

## Die App stürzt immer ab

1. Starte die App neu.
2. Starte dein Gerät neu.
3. Wenn das Problem weiterhin auftritt, melde es bitte. Siehe den Leitfaden [Wo du Fragen stellen kannst](theodia://help/getting-more-help).

## Ich möchte die App deinstallieren

Du kannst Theodia wie jede andere App deinstallieren. Bevor du das tust, erstelle eine Sicherung deiner Daten. Nach der Deinstallation sind die Daten auf dem Gerät weg.

## Immer noch festgefahren?

Sieh dir den Leitfaden [Wo du Fragen stellen kannst](theodia://help/getting-more-help) an. Dort findest du Links, um ein Problem zu melden und die Community zu fragen.

Du kannst auch die Hilfe-Leitfäden vom Hauptbildschirm **Hilfe und Anleitungen** durchsuchen. Gib ein Wort wie `notifications`, `search` oder `bookmarks` ein, um den passenden Leitfaden zu finden.
