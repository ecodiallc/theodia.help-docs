---
title: Übersetzungen vergleichen
level: everyday
categories: [read, study]
summary: So siehst du denselben Vers in jeder installierten Übersetzung.
---

# Übersetzungen vergleichen

> **Modus:** Das Vergleichen-Werkzeug ist im **Standard**- und **Gelehrten**-Modus verfügbar. Der Fokus-Modus ist nur für sauberes, ablenkungsfreies Lesen. Du kannst die Modi unter **Einstellungen** → **App-Benutzermodus** wechseln.

Das **Vergleichen**-Werkzeug zeigt einen einzelnen Vers in jeder Bibelübersetzung, die du installiert hast, in einem Panel. Es ist nützlich, wenn du sehen möchtest, wie verschiedene Übersetzer einen schwierigen Vers handhaben, oder wenn du eine Übersetzung auswählst und denselben Vers in jeder betrachten möchtest.

## Vergleichen öffnen

1. Öffne ein Kapitel in einer beliebigen Übersetzung.
2. Tippe auf einen Vers, um das Vers-Menü zu öffnen.
3. Tippe auf **Vergleichen** (⇄).

Ein Panel öffnet sich. Die Titelleiste zeigt die Stelle (zum Beispiel "Johannes 3,16 — Vergleichen"). Das Panel listet denselben Vers in jeder installierten Übersetzung. Deine aktuelle Übersetzung steht zuerst; der Rest ist alphabetisch sortiert.

## Wie das Panel aussieht

Das Panel ist eine **vertikale Liste**, keine nebeneinander liegende Spalte. Jede Zeile ist eine Übersetzung:

- Der **Übersetzungsname** (zum Beispiel "KJV") steht oben in der Zeile. Er ist antippbar.
- Der **Vers-Text** steht unter dem Namen.

Scrolle durch das Panel, um alle Übersetzungen zu sehen. Jede auf deinem Gerät installierte Übersetzung erscheint hier. Wenn eine Übersetzung das betreffende Buch oder den Vers nicht hat, wird sie ausgelassen.

## Den Vers in einer anderen Übersetzung lesen

Tippe auf den Übersetzungsnamen in der Zeile. Das Vergleichen-Panel schließt sich, und dasselbe Kapitel öffnet sich in der gewählten Übersetzung mit dem entsprechenden Vers. Das ist der schnellste Weg, vom Vergleich direkt in eine bestimmte Übersetzung zu springen.

## Vergleichen schließen

- **Auf einem Telefon:** Tippe oben rechts im Panel auf das X.
- **Auf einem Tablet:** Tippe auf das X in der Panel-Kopfzeile oder tippe außerhalb des Panels.

Du kehrst zur Kapitelansicht in deiner ursprünglichen Übersetzung zurück.

## Wann du Vergleichen nutzt

- **Übersetzung auswählen.** Öffne einen Vers, den du gut kennst, in deiner aktuellen Übersetzung, dann vergleiche, um ihn in anderen zu sehen. Die Unterschiede fallen auf.
- **Schwierige Verse.** Ein Vers, der in einer Übersetzung verwirrend ist, ist in einer anderen oft klarer.
- **Wortstudien.** Sieh dir an, wie verschiedene Übersetzer ein Schlüsselwort oder einen Satz handhaben.

Für einen schnellen Überblick über ein ganzes Kapitel in mehreren Übersetzungen auf einmal nutze stattdessen die **Parallelansicht**. Im Leitfaden [Studien-Modus](theodia://help/study-mode) erfährst du, wie du sie einschaltest.
