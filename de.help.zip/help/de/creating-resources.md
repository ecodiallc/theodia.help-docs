---
title: Eigene Ressourcen erstellen
level: advanced
categories: resources
summary: So erstellst du eigene Bibeln, Kommentare, Bücher, Andachten und Lexika und importierst sie in Theodia.
---

# Eigene Ressourcen erstellen

Theodia unterstützt benutzerdefinierte Ressourcen im Unique Bible App-Format. Jede Ressource ist eine SQLite-Datei mit einer bestimmten Tabellenstruktur. Du kannst diese Dateien auf einem Computer erstellen und in die App importieren.

## Dateitypen und erforderliche Tabellen

### Bibeln (`.bible`)

Eine Bibel-Datei ist eine SQLite-Datenbank mit mindestens einer dieser Tabellen:

- **`Verses`** — Spalten: `Book` (Integer, 1-66), `Chapter` (Integer), `Verse` (Integer), `Scripture` (Text)
- **`Bible`** — Spalten: `Book` (Integer), `Chapter` (Integer), `Verse` (Integer), `Scripture` (Text)

Du kannst auch eine **`Details`**-Tabelle mit Metadaten-Spalten wie `Description`, `Abbreviation` und `Version` hinzufügen.

Beispiel-SQL:

```sql
-- Haupttext-Tabelle
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- Optionale Metadaten-Tabelle
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### Kommentare (`.commentary`)

Kommentare gibt es in drei Typen: **Buch**, **Kapitel** und **Vers**. Der Typ wird durch den **ersten Buchstaben des Dateinamens** bestimmt.

#### Buchkommentare — Dateiname beginnt mit `b`

Ein Buchkommentar deckt ein ganzes Bibelbuch in einem einzigen Eintrag ab. Die `Commentary`-Tabelle benötigt die Spalten `Book` und `Scripture` (oder `Content`). Keine `Chapter`- oder `Verse`-Spalten nötig.

- **`Commentary`** — Spalten: `Book` (Integer), `Scripture` (Text) oder `Content` (Text)

Beispiel-SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

Dateiname-Beispiel: `bMyCommentary.commentary`

#### Kapitelkommentare — Dateiname beginnt mit `c`

Ein Kapitelkommentar deckt jedes Kapitel eines Bibelbuchs ab.

- **`Commentary`** — Spalten: `Book` (Integer), `Chapter` (Integer), `Scripture` (Text) oder `Content` (Text)

Beispiel-SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

Dateiname-Beispiel: `cMyCommentary.commentary`

#### Verskommentare — Dateiname beginnt mit `v`

Ein Verskommentar deckt einzelne Verse ab. Die `Commentary`-Tabelle benötigt `Book`, `Chapter`, `Verse` und `Scripture` (oder `Content`).

- **`Commentary`** — Spalten: `Book` (Integer), `Chapter` (Integer), `Verse` (Integer), `Scripture` (Text) oder `Content` (Text)

Beispiel-SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

Dateiname-Beispiel: `vMyCommentary.commentary`

### Bücher (`.book`)

Eine Buch-Datei ist eine SQLite-Datenbank mit einer `Reference`-Tabelle.

- **`Reference`** — Spalten: `id` (Integer), `Chapter` (Text), `Content` (Text)

Jede Zeile ist ein Kapitel. Die Spalte `Chapter` ist der Kapiteltitel. Die Spalte `Content` ist der Kapiteltext, der HTML enthalten darf (`<b>`, `<i>`, `<br>`, usw.).

Beispiel-SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

Du kannst Bücher auch aus Markdown-Dateien erstellen. Die App kann `.md`-Dateien importieren, bei denen `#` der Buchtitel und `##` Kapitel markiert. Das Markdown wird automatisch in HTML umgewandelt.

### Andachten (`.devotional`)

Eine Andachts-Datei ist eine SQLite-Datenbank mit einer `devotional`-Tabelle.

- **`devotional`** — Spalten: `month` (Integer, 1-12), `day` (Integer, 1-31), `devotion` (Text)

Jede Zeile ist ein Tagesabschnitt. Die App sucht den Eintrag anhand des aktuellen Monats und Tags.

Beispiel-SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### Lexika (`.lexicon`)

Eine Lexikon-Datei ist eine SQLite-Datenbank mit einer `Lexicon`-Tabelle.

- **`Lexicon`** — Spalten: `Topic` (Text, die Strong-Nummer), `Definition` (Text, der Lexikon-Eintrag)

Die Spalte `Topic` enthält die Strong-Nummer (zum Beispiel `G1161` oder `H7225`). Die Spalte `Definition` enthält den vollen Eintragstext, der HTML enthalten darf.

Beispiel-SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

Lexika versorgen das Wortinformation-Werkzeug. Wenn du in einer interlinearen Bibel auf ein Wort tippst, schlägt die App die Strong-Nummer in den installierten Lexika nach.

## Eine Datei auf dem Computer erstellen

1. Installiere einen SQLite-Editor (DB Browser for SQLite, SQLiteStudio oder das Kommandozeilen-Tool `sqlite3`).
2. Erstelle eine neue Datenbankdatei.
3. Erstelle die erforderliche Tabelle und füge deine Daten ein.
4. Speichere die Datei mit der richtigen Endung (`.bible`, `.commentary`, `.book`, `.devotional` oder `.lexicon`).

## In Theodia importieren

1. Übertrage die Datei auf dein Gerät (AirDrop, E-Mail, Cloud-Speicher oder USB).
2. Öffne **Theodia**.
3. Gehe zu **Einstellungen** → **Ressourcen verwalten**.
4. Tippe auf **Aus Datei importieren**.
5. Wähle deine Datei.

Die App prüft die Datei (ob die erforderliche Tabelle vorhanden ist), kopiert sie in den App-Datenordner und aktiviert sie automatisch. Wenn die Datei ungültig ist, siehst du eine Fehlermeldung, die erklärt, was falsch ist.

## Einschränkungen

- Du kannst integrierte Ressourcen nicht überschreiben. Wenn du eine Datei mit demselben Namen wie eine integrierte Bibel, ein integrierter Kommentar oder ein integriertes Buch importieren willst, schlägt der Import fehl.
- Bibel-Dateien brauchen eine `Verses`- oder `Bible`-Tabelle. Wenn keine vorhanden ist, schlägt der Import fehl.
- Kommentar-Dateien brauchen eine `Commentary`-Tabelle.
  - Buchkommentare benötigen `Book` und `Scripture` (oder `Content`).
  - Kapitelkommentare benötigen `Book`, `Chapter` und `Scripture` (oder `Content`).
  - Verskommentare benötigen `Book`, `Chapter`, `Verse` und `Scripture` (oder `Content`).
- Buch-Dateien brauchen eine `Reference`-Tabelle.
- Lexikon-Dateien brauchen eine `Lexicon`-Tabelle.
- Andachts-Dateien brauchen eine `devotional`-Tabelle.

## Tipps

- Halte Dateigrößen vernünftig. Sehr große SQLite-Dateien können auf älteren Geräten Speicherprobleme verursachen.
- Teste deine Datei zuerst auf dem Computer. Öffne sie in einem SQLite-Browser und führe `SELECT * FROM` der erforderlichen Tabelle aus, um zu prüfen, ob die Daten korrekt aussehen.
- Bei Bibeln muss die Spalte `Book` Zahlen verwenden (1 = Genesis, 66 = Offenbarung).
- Bei Kommentaren kannst du `Scripture` oder `Content` als Kommentartext-Spalte verwenden.
- Bei Büchern wird HTML in der Spalte `Content` beim Lesen dargestellt. Halte es einfach: `<b>`, `<i>`, `<br>` und `<hr>` sind sicher.

## Wo du bestehende Ressourcen findest

Theodia kann Ressourcen aus dem [Unique Bible App](https://github.com/eliranwong/UniqueBible)-Projekt lesen. Dort sind viele Bibeln, Kommentare, Bücher und andere Ressourcen im korrekten SQLite-Format verfügbar. Im Leitfaden [Zusätzliche Ressourcen bekommen](theodia://help/getting-core-files) erfährst du, wie du sie findest und hinzufügst.
