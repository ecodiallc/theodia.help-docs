---
title: Parallelstellen
level: everyday
categories: study
summary: So findest du Verse, die mit dem Vers zusammenhängen, den du gerade liest.
---

# Parallelstellen

> **Modus:** Parallelstellen sind im **Standard**- und **Gelehrten**-Modus verfügbar. Der Fokus-Modus ist nur für sauberes, ablenkungsfreies Lesen. Du kannst die Modi unter **Einstellungen** → **App-Benutzermodus** wechseln.

Eine "Parallelstelle" ist ein anderer Vers, der dasselbe Thema behandelt wie der Vers, den du gerade liest. Das Parallelstellen-Panel zeigt dir, welche Verse in der Bibel miteinander verbunden sind.

## Parallelstellen öffnen

1. Öffne ein Kapitel.
2. Tippe auf einen Vers, um das Vers-Menü zu öffnen.
3. Tippe auf **Parallelstellen**.

Ein Panel öffnet sich. Es zeigt eine Liste anderer Verse, die mit dem angetippten Vers zusammenhängen.

## Die Liste lesen

Jede Zeile ist ein verknüpfter Vers. Du siehst:

- Buch, Kapitel und Vers.
- Eine kurze Vorschau des Vers-Textes.
- Eine Bewertung, wie stark die Verbindung ist.

## Zu einem verknüpften Vers springen

Tippe auf eine beliebige Zeile. Die App öffnet diesen Vers für dich. Wenn du fertig bist, tippe auf den Zurück-Button, um zurückzukehren.

## Was die Bewertung bedeutet

Die Bewertung sagt dir, wie eng die Verse zusammenhängen. Eine hohe Bewertung bedeutet eine starke, direkte Verbindung. Eine niedrige Bewertung bedeutet einen loserer Zusammenhang.

## Parallelstellen zum Studieren nutzen

Parallelstellen sind nützlich für:

- **Wortstudien.** Sieh, wie die Bibel ein Wort an verschiedenen Stellen verwendet.
- **Themenstudien.** Verfolge ein Thema wie "Liebe" oder "Bund" durch die Schrift.
- **Predigtvorbereitung.** Finde schnell unterstützende Verse.

## Tipp

Parallelstellen funktionieren am besten mit einer Wort-für-Wort-Übersetzung wie WEB.
