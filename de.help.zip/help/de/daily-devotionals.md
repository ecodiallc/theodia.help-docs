---
title: Tägliche Andachten
level: everyday
categories: [content, read]
summary: So liest du jeden Tag eine kurze Andacht.
---

# Tägliche Andachten

Eine Andacht ist ein kurzer Lesetext für einen Tag. Sie enthält oft einen Vers, einen kurzen Gedanken und eine Frage zum Nachdenken. Theodia kommt mit einer kleinen Bibliothek an Andachten.

## Eine Andacht öffnen

1. Tippe unten auf die **Andachten**-Registerkarte.
2. Du siehst eine Liste der Andachten, die auf deinem Gerät installiert sind.
3. Tippe eine an, um sie zu öffnen.

## Eine Andacht lesen

1. Öffne die Andacht.
2. Scrolle zum Lesen.
3. Nutze die Buttons oben:
   - Tippe auf das **Datum**, um zu einem anderen Tag zu springen.
   - Tippe auf den **Stern**, um den Tag mit Lesezeichen zu markieren.
   - Tippe auf den **Lautsprecher**, um sie dir vorlesen zu lassen (falls dein Gerät es unterstützt). Im Leitfaden [Laut vorlesen](theodia://help/tts) erfährst du, wie du eine Stimme wählst.
   - Tippe auf **Zurück** oder **Weiter**, um zum Vortag oder zum nächsten Tag zu gelangen.

## Einen Vers aus einer Andacht speichern

1. Öffne die Andacht.
2. Tippe auf einen Vers.
3. Tippe auf **Lesezeichen** oder **Markieren**.

Der Vers wird in deinen Lesezeichen oder Markierungen gespeichert.

## Eine Notiz zu einer Andacht schreiben

1. Öffne die Andacht.
2. Tippe auf einen Vers.
3. Tippe auf **Notiz**. Schreibe deine Gedanken oder ein Gebet. Tippe auf **Speichern**.

Die Notiz erscheint in deiner Bibelnotizen-Registerkarte.

## Tipps

- Andachten brauchen kein Internet. Sie funktionieren offline.
- Wenn du mehr Andachten möchtest, sieh dir den Leitfaden [Zusätzliche Ressourcen bekommen](theodia://help/getting-core-files) an.
