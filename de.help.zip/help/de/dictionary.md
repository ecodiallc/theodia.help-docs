---
title: Bibelwörterbuch
level: everyday
categories: study
summary: Schlage Bibelwörter und Begriffe in installierten Wörterbuch-Ressourcen nach. Öffne es im Vers-Menü oder von einem Lexikon-Eintrag aus, tippe dann auf ein Wort, um es in jedem Wörterbuch zu sehen.
---

# Bibelwörterbuch

> **Modus:** Das Bibelwörterbuch erfordert den **Gelehrten**-Modus. Du kannst die Modi unter **Einstellungen** → **App-Benutzermodus** wechseln.

Das Bibelwörterbuch-Werkzeug schlägt ein Wort oder einen Satz in jedem installierten Wörterbuch nach. Es ist nützlich, wenn du eine einfache Definition eines Bibelworts, eine Beschreibung einer Person oder eines Ortes oder einen kurzen Artikel zu einem theologischen Begriff möchtest.

Das Bibelwörterbuch unterscheidet sich vom **Wortinformation**-Werkzeug, das das ursprüngliche hebräische oder griechische Wort hinter einem Vers nachschlägt. Das Wörterbuch liest das **englische** Wort, das du antippst, und zeigt, was deine installierten Wörterbücher dazu sagen. Für wort-für-wort-Bibelübersetzungshinweise sieh dir den Leitfaden [Kommentare und Lexika](theodia://help/commentaries-and-lexicons) an.

## Wörterbuch öffnen

Es gibt zwei Wege, das Wörterbuch zu öffnen.

### Vom Vers-Menü aus

1. Öffne ein Kapitel im [Studien-Modus](theodia://help/study-mode).
2. Tippe auf einen Vers, um das Vers-Menü zu öffnen.
3. Tippe auf **Wörterbuch** (📖).

Ein Panel öffnet sich mit dem Vers im Titel (zum Beispiel "Johannes 3,16"). Der Vers-Text steht oben, jedes Wort ist antippbar. Darunter befindet sich ein Chip-Streifen mit jedem installierten Wörterbuch. Darunter steht die Definition, die leer bleibt, bis du auf ein Wort tippst.

### Von einem Lexikon-Eintrag aus

Wenn du einen Lexikon-Eintrag im Wortinformation-Panel liest, enthalten manche Einträge blaue Links zu verwandten Wörterbuch-Artikeln. Tippe auf einen dieser Links. Das Lexikon schließt sich und das Wörterbuch öffnet sich bei diesem Artikel. Das ist der schnellste Weg, von einem griechischen oder hebräischen Wort zu einer einfachen Erklärung seiner Bedeutung zu springen.

## Wie die Vers-Ansicht funktioniert

Wenn du das Wörterbuch vom Vers-Menü aus öffnest, erscheint der Vers oben im Panel als Liste antippbarer Wörter. Häufige englische Wörter wie "the", "and", "of", "to" und "a" sind nicht antippbar. Jedes andere Wort ist antippbar. Jedes antippbare Wort ist farbig und fett, damit es sich vom Rest des Verses abhebt.

Tippe auf ein beliebiges Wort im Vers. Theodia durchsucht jedes installierte Wörterbuch nach einer exakten Übereinstimmung mit diesem Wort. Der Chip-Streifen unten zeigt aktualisiert, welche Wörterbücher einen Eintrag haben: Wörterbücher ohne Eintrag für das Wort sind abgedunkelt. Das erste Wörterbuch mit einem Eintrag wird automatisch ausgewählt und seine Definition erscheint unter dem Chip-Streifen.

Das Wort, das du angetippt hast, wird im Vers-Text oben im Panel hervorgehoben, damit du immer weißt, wonach du suchst.

## Zwischen Wörterbüchern wechseln

Jedes installierte Wörterbuch wird als kleiner Chip unter dem Vers angezeigt. Nachdem du auf ein Wort getippt hast:

- Ein Chip in **voller Farbe** bedeutet, dass dieses Wörterbuch einen Eintrag für das angetippte Wort hat. Tippe darauf, um zu der Definition dieses Wörterbuchs zu wechseln.
- Ein **abgedunkelter** Chip bedeutet, dass dieses Wörterbuch keinen Eintrag für das Wort hat. Er ist grau, damit du auf einen Blick siehst, welche Wörterbücher das Wort abdecken, und er ist nicht antippbar.

Das ausgewählte Wörterbuch ist hervorgehoben. Tippe auf einen anderen farbigen Chip, um denselben Begriff in diesem Wörterbuch zu lesen. Die Definition unten aktualisiert sich sofort.

Wenn das Wort nur in einem deiner installierten Wörterbücher vorkommt, ist nur dieser eine Chip farbig und die anderen sind abgedunkelt.

## Was das Panel zeigt

Das Wörterbuch-Panel hat drei Teile, von oben nach unten:

- **Der Vers** — der Vers, aus dem du das Wörterbuch geöffnet hast. Wörter sind antippbar, und das zuletzt angetippte Wort ist hervorgehoben.
- **Der Chip-Streifen** — jedes installierte Wörterbuch. Farbig bedeutet "hat einen Eintrag für das angetippte Wort". Abgedunkelt bedeutet "kein Eintrag für das Wort".
- **Die Definition** — der Artikel aus dem ausgewählten Wörterbuch. Klartext, formatiert mit Absätzen und Überschriften. Interne Links zu anderen Wörterbuch-Einträgen sind antippbar; beim Tippen öffnet sich dieser Eintrag im Wörterbuch.

## Was passiert, wenn kein Eintrag gefunden wird

Wenn du auf ein Wort tippst, das keines deiner installierten Wörterbücher abdeckt, zeigt das Panel eine kurze "Keine Einträge gefunden"-Meldung statt einer Definition. Das ist häufig bei sehr allgemeinen Wörtern wie "Jahr" oder "kommen", die keine echten Bibel-Theologie-Begriffe sind, auch wenn sie überall in der Bibel vorkommen. Versuche ein spezifischeres Wort, oder nutze stattdessen das Lexikon-Wortinformation-Werkzeug, das mit dem zugrunde liegenden Griechisch und Hebräisch arbeitet.

## Was passiert, wenn kein Wörterbuch installiert ist

Das Wörterbuch braucht mindestens eine Wörterbuch-Ressourcendatei, um nützlich zu sein. Theodia liefert eines mit. Wenn du es entfernt hast oder eine benutzerdefinierte Installation ohne Wörterbücher nutzt, erscheint die Vers-Ansicht dennoch und Wörter sind weiterhin antippbar, aber der Chip-Streifen ist leer und jede Suche gibt "Keine Einträge gefunden" zurück.

Zusätzliche Wörterbücher können nicht separat installiert werden.

## Tipps

- Das Wörterbuch sucht nach **exakten Worttreffern**. "love" findet Einträge mit dem Titel "love", aber nicht "loved" oder "loving". Für verwandte Formen nutze das Lexikon-Wortinformation-Werkzeug auf dem griechischen oder hebräischen Wort.
- Der Chip-Streifen ist auf Telefonen und Tablets gleich. Auf einem Tablet öffnet sich das Wörterbuch als Seitenpanel neben dem Kapitel; auf einem Telefon als Vollbild-Modal. Beide haben dasselbe dreiteilige Layout.
- Wenn du ein Wort in einem anderen Vers antippst, öffnet sich ein neuer Vers im Panel. Deine vorherige Auswahl wird gelöscht. Tippe auf ein Wort im neuen Vers, um eine neue Suche zu starten.
- Manche Wörterbuch-Einträge verweisen auf dasselbe Wort in einem anderen Wörterbuch. Tippe auf diese internen Links, um die Spur durch alle installierten Wörterbücher zu verfolgen.

## Unterschied zwischen Wörterbuch und Wortinformation

Beide Werkzeuge öffnen sich aus dem Vers-Menü, aber sie tun unterschiedliche Dinge:

- **Wörterbuch** (📖) liest das englische Wort, das du antippst, und findet es in deinen installierten englischen Wörterbüchern. Es ist das richtige Werkzeug für einfache Definitionen von Bibel-Theologie-Begriffen wie "Bund", "Sühne" oder "Pharisäer".
- **Wortinformation** (?) liest das ursprüngliche griechische oder hebräische Wort hinter dem Vers und findet es in deinen installierten Lexika. Es ist das richtige Werkzeug für ernsthafte Wortstudien, um jede Stelle zu finden, an der ein griechisches Wort verwendet wird, und die Originalsprachen-Definitionen zu lesen.

Im Zweifel beginne mit dem Wörterbuch. Wenn du in die Originalsprache eintauchen möchtest, wechsle zu Wortinformation. Im Leitfaden [Kommentare und Lexika](theodia://help/commentaries-and-lexicons) findest du die vollständige Wortinformation-Anleitung.

## Verwandte Leitfäden

- Der Leitfaden [Studien-Modus](theodia://help/study-mode) erklärt das Vers-Menü im Detail und wo das Wörterbuch-Werkzeug (📖) neben Lesezeichen, Markierung, Vorlesen, Vergleichen, Parallelstellen, KI-Kommentar, Wortinformation und Notizen sitzt.
- Der Leitfaden [Kommentare und Lexika](theodia://help/commentaries-and-lexicons) behandelt Wortinformation und die Originalsprachen-Lexika.
- Der Leitfaden [Was sind Ressourcen?](theodia://help/what-are-resources) erklärt die verschiedenen Dateitypen, die Theodia verwendet, inklusive der Wörterbuch-Ressourcen.
- Der Leitfaden [Häufige Probleme](theodia://help/common-problems) enthält Lösungen für leere Ergebnisse und andere Wörterbuch-Probleme.
