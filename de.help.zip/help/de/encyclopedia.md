---
title: Enzyklopädie
level: everyday
categories: study
summary: So schlägst du Enzyklopädie-Artikel nach und durchblättert Nachschlagewerke.
---

# Enzyklopädie

Theodia enthält eine integrierte **Enzyklopädie** zum Nachschlagen von bibelbezogenen Artikeln, Personen, Orten und Themen. Die App liefert _Kitto's Illustrated Commentary_ (KIT) mit, und du kannst zusätzliche Enzyklopädien aus dem Repository herunterladen.

## Was ist eine Enzyklopädie in Theodia?

Eine Enzyklopädie ist ein Nachschlagewerk aus kurzen Artikeln. Jeder Artikel behandelt eine Person, einen Ort, ein Ereignis oder ein Bibelthema. Im Gegensatz zu einem Kommentar, der einen bestimmten Vers erklärt, erklärt ein Enzyklopädie-Artikel das Thema selbst.

## Enzyklopädie öffnen

1. Tippe unten in der Werkzeugleiste auf **Enzyklopädie**.
2. Wähle oben in der Reihe der Abkürzungen eine Enzyklopädie aus.
3. Gib ein Thema, eine Person oder einen Ort in das Suchfeld ein.

Die Suche benötigt mindestens **3 Zeichen**, bevor Ergebnisse und Autocomplete-Vorschläge erscheinen.

## Einen Artikel lesen

- Auf dem **Telefon** tippe auf ein beliebiges Ergebnis, um den Artikel auf einem neuen Bildschirm zu öffnen.
- Auf dem **Tablet** öffnet sich der Artikel im Panel rechts, während die Liste links bleibt.

## Enzyklopädien auswählen

Tippe auf einen Abkürzungs-Chip (zum Beispiel **KIT**), um zu dieser Enzyklopädie zu wechseln. Um mehrere Enzyklopädien gleichzeitig zu durchsuchen, nutze die **Suchen**-Registerkarte und wähle **Enzyklopädie** als Suchmodus.

## Mehr Enzyklopädien bekommen

1. Öffne **Einstellungen**.
2. Tippe auf **Ressourcen verwalten**.
3. Tippe auf **Aus GitHub installieren**.
4. Wähle die **Enzyklopädien**-Registerkarte.
5. Tippe auf den Download-Button neben der gewünschten Enzyklopädie.

Enzyklopädien werden aus Theodias Enzyklopädie-GitHub-Repository heruntergeladen und automatisch installiert. Installierte Enzyklopädien erscheinen auf dem Enzyklopädie-Bildschirm und in der Suche.

Du kannst auch eine Enzyklopädie aus einer lokalen Datei installieren: Tippe in **Ressourcen verwalten** auf **Lokale Datei installieren** und wähle eine `.encyclopedia`-Datei. Die Datei wird in den Enzyklopädien-Ordner der App kopiert und dem gemeinsamen Suchindex hinzugefügt.

## Lang drücken für den vollen Titel

Auf dem Suchbildschirm zeigen die Enzyklopädie-Chips kurze Abkürzungen. Halte einen Chip lange gedrückt, um den vollen Enzyklopädie-Namen zu sehen.

## Wann du die Enzyklopädie nutzt

- Schlage eine Person, einen Ort oder ein Thema nach, bevor oder während du eine Passage liest.
- Hole dir Hintergrund zu einem Bibelwort oder Begriff, der viele Verse überspannt.
- Lies neben einem Kommentar für tieferes Studium.
