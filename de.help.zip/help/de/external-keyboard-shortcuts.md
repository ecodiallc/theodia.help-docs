---
title: Externe Tastaturkürzel
level: everyday
categories: [tablet, settings]
summary: Vollständige Tastaturkürzel-Referenz für iPad mit angeschlossener externer Tastatur.
---

# ⌨️ Externe Tastaturkürzel

Wenn du Theodia auf dem iPad mit einer externen Tastatur (Magic Keyboard, Bluetooth-Tastatur oder USB-Tastatur) nutzt, kannst du die App bedienen, ohne den Bildschirm zu berühren.

> **Modus:** Einige Kürzel funktionieren nur, wenn die entsprechende Funktion in deinem aktuellen Benutzermodus verfügbar ist. Zum Beispiel tun `Cmd + Option + 6` (Lesezeichen) und `Cmd + Option + 7` (Markierungen) im Lesen-Modus nichts. Wechsel die Modi unter **Einstellungen** → **App-Benutzermodus**.

Kürzel funktionieren auf dem **iPad**.

## Globale Kürzel (überall)

| Kürzel | Aktion |
| ------ | ------ |
| `Cmd + /` | Diese Tastaturkürzel-Hilfe anzeigen |
| `Cmd + .` | Modal / Panel schließen (Escape-Alternative) |
| `Cmd + Option + 1` | Zur Startseite-Registerkarte gehen |
| `Cmd + Option + 2` | Zur Bibeln-Registerkarte gehen |
| `Cmd + Option + 3` | Zur Bücher-Registerkarte gehen |
| `Cmd + Option + 4` | Zur Andachten-Registerkarte gehen |
| `Cmd + Option + 5` | Zur Suche-Registerkarte gehen |
| `Cmd + Option + 6` | Zur Lesezeichen-Registerkarte gehen (Standard und Gelehrter) |
| `Cmd + Option + 7` | Zur Höhepunkte-Registerkarte gehen (Standard und Gelehrter) |
| `Cmd + Option + 8` | Zur Bibelnotizen-Registerkarte gehen (Standard und Gelehrter) |
| `Cmd + Option + 9` | Zur KI-Registerkarte gehen (Gelehrter, falls aktiviert) |
| `Cmd + Option + 0` | Zur Helfen-Registerkarte gehen |
| `Cmd + Option + I` | Zur Über-Registerkarte gehen |
| `Cmd + [` | Zurück gehen |
| `Cmd + F` | Suche öffnen |
| `Cmd + K` | Schnellmenü öffnen (Gelehrter) |
| `Cmd + ,` | Einstellungen öffnen |
| `Cmd + Shift + M` | Hauptmenü öffnen |
| `Cmd + Shift + T` | Thema wechseln (Standard / Dunkel) |
| `Cmd + Shift + U` | Benutzermodus-Auswahl öffnen |
| `Escape` | Modal schließen / Panel schließen |

## Bibel-Leser-Kürzel

Diese funktionen sowohl im **Studienleser** als auch im **Fokus-Leser**.

| Kürzel | Aktion |
| ------ | ------ |
| `← Pfeil links` | Vorheriges Kapitel |
| `→ Pfeil rechts` | Nächstes Kapitel |
| `Cmd + R` | Zwischen Studien- und Fokus-Leser wechseln (Standard und Gelehrter) |
| `Cmd + Option + V` | Übersetzungsauswahl öffnen |
| `Cmd + Option + B` | Buchauswahl öffnen |
| `Cmd + Option + C` | Kapitelauswahl öffnen |
| `Cmd + T` | Sprachausgabe umschalten (stoppen wenn aktiv/pausiert, starten wenn inaktiv) |
| `Cmd + Option + T` | Sprachausgabe wiedergeben / pausieren |

## Nur Studienleser

| Kürzel | Aktion |
| ------ | ------ |
| `↑ Pfeil hoch` | Vorherigen Vers auswählen |
| `↓ Pfeil runter` | Nächsten Vers auswählen |
| `Cmd + ↑` | Ersten Vers auswählen |
| `Cmd + ↓` | Letzten Vers auswählen |
| `Cmd + ←` | Zu Kapitel 1 springen |
| `Cmd + →` | Zum letzten Kapitel springen |
| `Cmd + 0`–`9` | Direkter Vers-Sprung (Ziffern eingeben, z. B. `Cmd + 1` `Cmd + 6` für Vers 16) |
| `Cmd + P` | Parallelbibeln umschalten (Standard und Gelehrter) |
| `Cmd + B` | Ausgewählten Vers mit Lesezeichen markieren (Standard und Gelehrter) |
| `Cmd + H` | Ausgewählten Vers markieren (Standard und Gelehrter) |
| `Cmd + N` | Notiz für ausgewählten Vers hinzufügen (Standard und Gelehrter) |
| `Cmd + C` | Übersetzungen des ausgewählten Verses vergleichen (Standard und Gelehrter) |
| `Cmd + X` | Parallelstellen für ausgewählten Vers öffnen (Standard und Gelehrter) |
| `Cmd + I` | Wortinformation öffnen (Gelehrter) |
| `Cmd + D` | Wörterbuch für ausgewählten Vers öffnen (Gelehrter) |
| `Cmd + A` | KI-Panel für ausgewählten Vers öffnen (Gelehrter) |
| `Cmd + Option + S` | Abschnittsüberschriften umschalten |
| `Cmd + Option + W` | Alle offenen Studien-Panels schließen |
| `Cmd + Option + M` | Vers-Aktions-Menü öffnen |

## Nur Fokus-Leser

| Kürzel | Aktion |
| ------ | ------ |
| `↑ Pfeil hoch` | Nach oben scrollen |
| `↓ Pfeil runter` | Nach unten scrollen |
| `Cmd + ↑` | An den Anfang scrollen |
| `Cmd + ↓` | An das Ende scrollen |
| `Cmd + =` | Hineinzoomen |
| `Cmd + -` | Herauszoomen |

## Suche

| Kürzel | Aktion |
| ------ | ------ |
| `Return` | Suche ausführen |
| `Cmd + Return` | Suche löschen und Eingabe fokussieren |
| `Cmd + ↑` | Ergebnisse nach oben scrollen |
| `Cmd + ↓` | Ergebnisse nach unten scrollen |
| `Cmd + Option + A` | Alle Bereichs-Elemente auswählen |
| `Cmd + Option + C` | Alle Bereichs-Elemente abwählen |
| `Cmd + Option + B` | Bibel-Suchmodus |
| `Cmd + Option + O` | Buch-Suchmodus |
| `Cmd + Option + D` | Wörterbuch-Suchmodus (Gelehrter) |
| `Cmd + Option + X` | Lexikon-Suchmodus (Gelehrter) |

## Suchergebnisse

| Kürzel | Aktion |
| ------ | ------ |
| `Cmd + S` | Alle-speichern-Dialog öffnen |
| `Cmd + ↑` | Ergebnisse nach oben scrollen |
| `Cmd + ↓` | Ergebnisse nach unten scrollen |

## Buch-Leser

| Kürzel | Aktion |
| ------ | ------ |
| `← Pfeil links` | Vorheriges Kapitel |
| `→ Pfeil rechts` | Nächstes Kapitel |
| `Cmd + ↑` | Vorheriges Kapitel |
| `Cmd + ↓` | Nächstes Kapitel |
| `↑ Pfeil hoch` | Nach oben scrollen |
| `↓ Pfeil runter` | Nach unten scrollen |
| `Cmd + B` | Aktuelles Kapitel mit Lesezeichen markieren |
| `Cmd + J` | Kapitelauswahl öffnen |
| `Cmd + L` | Stimmenauswahl öffnen |
| `Cmd + T` | Sprachausgabe umschalten |
| `Cmd + Option + T` | Sprachausgabe wiedergeben / pausieren |

## Andachten-Leser

| Kürzel | Aktion |
| ------ | ------ |
| `← Pfeil links` | Voriger Tag |
| `→ Pfeil rechts` | Nächster Tag |
| `↑ Pfeil hoch` | Nach oben scrollen |
| `↓ Pfeil runter` | Nach unten scrollen |
| `Cmd + ↑` | Groß nach oben scrollen |
| `Cmd + ↓` | Groß nach unten scrollen |
| `Cmd + D` | Datumsauswahl öffnen |
| `Cmd + T` | Sprachausgabe umschalten |
| `Cmd + Option + T` | Sprachausgabe wiedergeben / pausieren |

## KI-Chat

| Kürzel | Aktion |
| ------ | ------ |
| `Cmd + Return` | Nachricht senden |
| `Cmd + N` | Neuer Chat |
| `Cmd + D` | Gesprächs-Seitenleiste umschalten |
| `Cmd + Option + C` | Aktuellen Chat leeren |
| `Cmd + S` | Speicher-Menü öffnen |
| `Escape` | Schublade / Menü schließen |

## Lesezeichen

| Kürzel | Aktion |
| ------ | ------ |
| `↑ Pfeil hoch` / `↓ Pfeil runter` | Lesezeichen auswählen |
| `Return` | Lesezeichen öffnen (Tablet: auswählen) |
| `Cmd + R` | Lesezeichen im Kontext lesen |
| `Cmd + M` | Ausgewähltes Lesezeichen in Ordner verschieben |
| `Cmd + N` | Ordner verwalten |
| `Escape` | Detail-Panel / Ordnerauswahl schließen |

Im **In Ordner verschieben**-Dialog bewegen `↑ Pfeil hoch` / `↓ Pfeil runter` die Auswahl, `Return` schaltet den ausgewählten Ordner um oder aktiviert die markierte Aktion, und `Escape` schließt den Dialog. Die Zeile **+ Ordner erstellen** steht oben in der Liste.

## Bibelnotizen

| Kürzel | Aktion |
| ------ | ------ |
| `↑ Pfeil hoch` / `↓ Pfeil runter` | Notiz auswählen |
| `Return` | Notiz öffnen |
| `Cmd + Return` | Filter-Eingabe fokussieren |
| `Escape` | Detail / Editor schließen |

## Markierungen

| Kürzel | Aktion |
| ------ | ------ |
| `↑ Pfeil hoch` / `↓ Pfeil runter` | Markierung auswählen |
| `Return` | Markierung öffnen |
| `Cmd + Return` | Filter-Eingabe fokussieren |
| `Escape` | Detail-Panel schließen |

## Bibel-Liste

| Kürzel | Aktion |
| ------ | ------ |
| `Tab` / `→ Pfeil rechts` / `↓ Pfeil runter` | Nächste Bibel |
| `← Pfeil links` / `↑ Pfeil hoch` | Vorherige Bibel |
| `Return` | Fokussierte Bibel öffnen |
| `Cmd + Shift + S` | Favoriten-Status für fokussierte Bibel umschalten |
| `Escape` | Zurück gehen |

## Bibel-Bücher-Bildschirm

| Kürzel | Aktion |
| ------ | ------ |
| `Tab` / `→ Pfeil rechts` | Nächstes Buch |
| `← Pfeil links` | Vorheriges Buch |
| `↓ Pfeil runter` | Buch unten im Raster |
| `↑ Pfeil hoch` | Buch oben im Raster |
| `Cmd + ↓` | Nächster Abschnitt (AT / NT) |
| `Cmd + ↑` | Vorheriger Abschnitt (AT / NT) |
| `Return` | Fokussiertes Buch öffnen |
| `Escape` | Zurück gehen |

## Buch-Liste

| Kürzel | Aktion |
| ------ | ------ |
| `Tab` / `→ Pfeil rechts` / `↓ Pfeil runter` | Nächstes Buch |
| `← Pfeil links` / `↑ Pfeil hoch` | Vorheriges Buch |
| `Return` | Fokussiertes Buch öffnen |
| `Escape` | Zurück gehen |

## Bibel-Kapitel-Bildschirm

| Kürzel | Aktion |
| ------ | ------ |
| `Tab` / `→ Pfeil rechts` / `↓ Pfeil runter` | Nächstes Kapitel |
| `← Pfeil links` / `↑ Pfeil hoch` | Vorheriges Kapitel |
| `Return` | Fokussiertes Kapitel öffnen |
| `Escape` | Zurück gehen |

## Buch-Kapitel-Bildschirm

| Kürzel | Aktion |
| ------ | ------ |
| `Tab` / `↓ Pfeil runter` | Nächstes Kapitel |
| `↑ Pfeil hoch` | Vorheriges Kapitel |
| `Return` | Fokussiertes Kapitel öffnen |
| `Cmd + Return` | Suche- / Filter-Eingabe fokussieren |
| `Escape` | Zurück gehen |

## Andachten-Liste

| Kürzel | Aktion |
| ------ | ------ |
| `Tab` / `→ Pfeil rechts` / `↓ Pfeil runter` | Nächste Andacht |
| `← Pfeil links` / `↑ Pfeil hoch` | Vorherige Andacht |
| `Return` | Fokussierte Andacht öffnen |
| `Escape` | Zurück gehen |

## Hauptmenü (wenn geöffnet)

| Kürzel | Aktion |
| ------ | ------ |
| `↑ Pfeil hoch` | Vorheriger Menüpunkt |
| `↓ Pfeil runter` | Nächster Menüpunkt |
| `Return` | Markierten Punkt auswählen |
| `Escape` | Menü schließen |

## Einstellungen

| Kürzel | Aktion |
| ------ | ------ |
| `Escape` | Offenes Modal / Auswahl schließen |

## Editor-Modals

| Kürzel | Aktion |
| ------ | ------ |
| `Cmd + S` | Speichern |
| `Escape` | Abbrechen / schließen |

## Eingabeschutz

Wenn du in einem Textfeld fokussiert bist (Suchfeld, Notiz-Editor, KI-Eingabe), werden Kürzel ohne `Cmd` wie Pfeiltasten und `Leertaste` unterdrückt, damit sie nicht versehentlich die Navigation auslösen. Kürzel mit `Cmd` (z. B. `Cmd + S`, `Cmd + B`) funktionieren weiterhin während der Eingabe.
