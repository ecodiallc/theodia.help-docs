---
title: Häufig gestellte Fragen
level: everyday
categories: faq
summary: Antworten auf die häufigsten Fragen zur Nutzung von Theodia.
---

# Häufig gestellte Fragen

## Kostet Theodia etwas?

Theodia ist ein einmaliger Kauf. Es gibt kein Abonnement, keine Werbung, keine In-App-Käufe und keine Spendenaufrufe. Alle zusätzlichen Ressourcen im Katalog sind nach dem App-Kauf kostenlos herunterladbar.

## Brauche ich eine Internetverbindung?

Nein. Sobald die App und ihre Datendateien installiert sind, funktioniert alles offline. Du kannst lesen, suchen, markieren, Notizen schreiben und die meisten Studienwerkzeuge ohne Signal nutzen.

Das einzige Feature, das das Internet braucht, ist das Herunterladen neuer Ressourcen.

## Wo werden meine Daten gespeichert?

Alle deine Lesezeichen, Markierungen, Notizen und Einstellungen werden auf deinem Gerät gespeichert. Sie werden auf keinen Server hochgeladen.

Du kannst sie manuell sichern. Im Leitfaden [Daten sichern](theodia://help/backups) erfährst du, wie das geht.

## Kann ich mir die Bibel laut vorlesen lassen?

Ja. Öffne ein beliebiges Kapitel, tippe auf das Menü und wähle die Vorlese-Option. Dein Gerät muss eine Text-zu-Sprache-Stimme installiert haben. Mehr dazu im Leitfaden [Laut vorlesen](theodia://help/tts).

## Wie suche ich nach einem Vers?

Du kannst eine Stelle wie `John 3:16` in den Schnellbefehl auf der Startseite eingeben oder die **Suchen**-Registerkarte nutzen, um nach Wort oder Phrase zu suchen.

## Wie melde ich einen Fehler oder schlage eine Funktion vor?

Tippe auf der Über-Seite auf **Vorschlag / Problem senden**, [melde es auf GitHub](https://github.com/ecodiallc/theodia.app/issues/new) oder besuche die [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions)-Seite.

## Welche Geräte werden unterstützt?

Theodia läuft auf iPhone, iPad und Android-Telefonen und -Tablets. Es funktioniert am besten auf Geräten mit mindestens 2 GB freiem Speicher für die Kerndatendateien.

## Kann ich eine externe Tastatur nutzen?

Ja. Theodia unterstützt Bluetooth- und USB-Tastaturen auf dem iPad. Navigation, Suche und viele Lesefunktionen haben Tastaturkürzel. Die vollständige Liste findest du im Leitfaden [Externe Tastaturkürzel](theodia://help/external-keyboard-shortcuts).

## Welche Sprachen werden unterstützt?

Die App-Oberfläche ist verfügbar auf Englisch, Arabisch, Chinesisch (vereinfacht und traditionell), Tschechisch, Dänisch, Niederländisch, Filipino, Französisch, Deutsch, Griechisch, Hebräisch, Hindi, Indonesisch, Italienisch, Japanisch, Koreanisch, Polnisch, Portugiesisch (Brasilien), Rumänisch, Russisch, Spanisch, Schwedisch, Thai, Türkisch, Ukrainisch und Vietnamesisch.

Die Sprache des Bibeltextes hängt von den installierten Übersetzungen ab.

## Wie ändere ich die Sprache?

Gehe zu **Einstellungen** und suche die Sprachoption.

## Meine Frage ist hier nicht aufgeführt. Wo bekomme ich mehr Hilfe?

Durchstöbere die restlichen Hilfe-Leitfäden nach Thema, oder stelle eine Frage im [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions)-Forum.

Tipp: Auf dem Hauptbildschirm **Hilfe und Anleitungen** nutze das Suchfeld, um ein Thema wie `notifications` oder `search` einzugeben und den passenden Leitfaden zu finden.
