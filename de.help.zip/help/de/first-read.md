---
title: Dein erstes Kapitel lesen
level: beginner
categories: [start, read]
summary: Eine Schritt-für-Schritt-Anleitung zum Öffnen und Lesen eines Kapitels.
---

# Dein erstes Kapitel lesen

Dieser Leitfaden führt dich durch das erste Öffnen eines Kapitels.

## Schritt 1: Bibel-Registerkarte öffnen

Schau auf den unteren Bildschirmrand. Du siehst eine Reihe von Registerkarten. Tippe auf die, die **Bibel** heißt.

## Schritt 2: Ein Buch wählen

Du siehst eine Liste der Bibelbücher. Genesis ist zuerst. Johannes ist etwa in der Mitte. Offenbarung ist zuletzt.

Tippe auf den Namen des Buches, das du lesen möchtest.

## Schritt 3: Ein Kapitel wählen

Du siehst Zahlen von 1 bis zur Anzahl der Kapitel des Buches. Tippe auf das gewünschte Kapitel.

Das Kapitel öffnet sich. Die Verse erscheinen auf dem Bildschirm.

## Schritt 4: Hin und her bewegen

- Wische nach **links**, um zum nächsten Kapitel zu gelangen.
- Wische nach **rechts**, um zurückzugehen.

## Schritt 5: Mit einem Vers interagieren

Was du mit einem Vers tun kannst, hängt von deinem Benutzermodus ab.

### Lesen-Modus

Der Lesen-Modus ist sauber und ablenkungsfrei.

- Tippe auf einen Vers, um ihn kurz hervorzuheben.
- Es gibt keine Studienwerkzeuge, Lesezeichen oder Menüs.
- Wenn du mehr Funktionen möchtest, wechsle in den **Standard**- oder **Gelehrten**-Modus unter **Einstellungen**.

### Standard-Modus

Der Standard-Modus fügt alltägliche Funktionen für persönliches Bibelstudium hinzu.

Tippe auf einen Vers, um ein Menü mit diesen Optionen zu öffnen:

- Den Vers als **Lesezeichen** speichern.
- Ihn in einer Farbe **markieren**.
- Eine **Notiz** hinzufügen.
- Den Vers-Text **kopieren**.
- Den Vers in einer anderen Übersetzung **vergleichen**.
- **Parallelstellen** für den Vers nachschlagen.

### Gelehrter-Modus

Der Gelehrter-Modus schaltet jedes Werkzeug für tiefes Bibelstudium frei.

Tippe auf einen Vers, um ein Menü mit allem aus dem Standard-Modus plus Folgendem zu öffnen:

- **Kommentar** zu dem Vers.
- **Wortinformation** und Originalsprachen-Abfragen.
- **Wörterbuch**-Definitionen.
- **KI-Assistent** für tieferes Studium.

Du kannst jederzeit unter **Einstellungen** den Modus wechseln.

## Hilfe zu einem bestimmten Werkzeug?

Jedes Werkzeug hat einen eigenen Leitfaden. Tippe auf der Startseite auf **Helfen**, um sie alle zu sehen. Der Leitfaden [Studien-Modus](theodia://help/study-mode) ist ein guter Startpunkt — er führt dich durch jedes Werkzeug im Vers-Menü.

Wenn du noch lernst, wo sich was befindet, sieh dir den Leitfaden [App-Layout und Navigation](theodia://help/navigating-the-app) an. Er erklärt Startbildschirm, Hauptmenü und untere Werkzeugleiste.

## Möchtest du mehr Ressourcen?

Die App kommt mit mehreren frei verfügbaren Bibelversionen. Wenn du mehr hinzufügen möchtest — Bibeln, Kommentare, Bücher oder Andachten — sieh dir den Leitfaden [Zusätzliche Ressourcen bekommen](theodia://help/getting-core-files) an. Er zeigt dir, wo du sie findest und wie du sie hinzufügst.
