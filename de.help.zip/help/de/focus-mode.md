---
title: Fokus-Modus
level: beginner
categories: [layout, read]
summary: Eine saubere, ablenkungsfreie Art, längere Passagen zu lesen.
---

# Fokus-Modus

> **Modus:** Der Fokus-Modus ist der Leser im **Lesen**-Modus. Er ist auch im **Standard**- und **Gelehrten**-Modus als Alternative zum Studien-Modus verfügbar. Du kannst die Modi unter **Einstellungen** → **App-Benutzermodus** wechseln.

Der Fokus-Modus ist eine Art, ein Bibelkapitel ohne Buttons oder Menüs im Weg zu lesen. Er eignet sich gut für längere Lesesitzungen.

## Einschalten

1. Öffne ein beliebiges Kapitel.
2. Tippe in der Reihe der Symbole oben auf den Bildschirm auf die 📖-Schaltfläche. Das gleiche Kapitel öffnet sich im Fokus-Modus.
3. Die Menüs und Buttons verschwinden. Nur der Bibeltext bleibt übrig.

Im **Lesen**-Modus öffnen sich Kapitel automatisch im Fokus-Modus. Die 📖-Schaltfläche ist ausgeblendet, weil es keinen Studien-Modus zum Wechseln gibt.

## Möglichkeiten im Fokus-Modus

- **Scrollen**, um zu lesen.
- **Wischen**, um zum nächsten oder vorherigen Kapitel zu gelangen.
- **Auf die 📖-Schaltfläche tippen** in der unteren Leiste, um zurück zum Studien-Modus zu wechseln. (Im Lesen-Modus ausgeblendet.)
- **Auf die 🔊-Schaltfläche tippen** in der unteren Leiste, um das Kapitel laut vorlesen zu lassen. Eine Mini-Steuerleiste erscheint mit Wiedergabe, Pause, Zurückspulen, Vorspulen und Stimmenauswahl. (Im Lesen-Modus ausgeblendet — Vorlesen erfordert Standard oder Gelehrter.)

## Gute Einsatzmöglichkeiten für den Fokus-Modus

- Ein ganzes Buch Kapitel für Kapitel durchlesen.
- Eine lange Passage für Andacht oder Stille lesen.
- Laut vorlesen und mitlesen, ohne Ablenkungen.

## Zum Studien-Modus wechseln

Der Fokus-Modus versteckt jedes Studienwerkzeug, aber sie sind nur einen Tipp entfernt. Tippe oben auf den Bildschirm auf die 📖-Schaltfläche, um dasselbe Kapitel im [Studien-Modus](theodia://help/study-mode) zu öffnen. Der Studien-Modus ist der vollständige Leser mit Kommentar, Parallelstellen, Lexikon-Abfragen und Notizen. Was der Studien-Modus kann, erfährst du im Leitfaden [Studien-Modus](theodia://help/study-mode).

Im **Lesen**-Modus ist die 📖-Schaltfläche ausgeblendet, weil der Studien-Modus nicht verfügbar ist.
