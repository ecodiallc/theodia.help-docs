---
title: Schnell zurechtfinden
level: beginner
categories: layout
summary: Jede schnelle Möglichkeit, zu einem Vers, einem Kapitel oder einem Bildschirm in Theodia zu springen.
---

# Schnell zurechtfinden

Dieser Leitfaden ist eine Übersicht zur Navigation. Er deckt alle schnellen Wege ab, von dort, wo du bist, dorthin, wo du hinwillst.

## Direkt zu einem Vers springen

Der schnellste Weg, einen beliebigen Vers zu öffnen, ist der **Schnellbefehl** auf der Startseite.

- Gib `Johannes 3,16` ein und tippe auf Los.
- Gib `Psalm 23` ein und tippe auf Los.
- Gib `Genesis 1` ein und tippe auf Los.

Die App öffnet das genaue Kapitel (und scrollt zum Vers, falls du einen angegeben hast).

## Zwischen Kapiteln wischen

Wenn du ein Kapitel liest:

- **Nach links wischen** → nächstes Kapitel.
- **Nach rechts wischen** → vorheriges Kapitel.

Das funktioniert auch über Bücher hinweg. Nach Exodus 40 führt ein Wischen nach links zu Levitikus 1.

## Die obere Leiste nutzen

Während des Lesens zeigt die obere Bildschirmhälfte die aktuelle **Übersetzung**, das **Buch** und das **Kapitel**.

- Tippe auf den Übersetzungsnamen, um die Bibel zu wechseln.
- Tippe auf den Buchnamen, um ein anderes Buch zu wählen.
- Tippe auf die Kapitelnummer, um ein anderes Kapitel zu wählen.

## Von einem Lesezeichen springen

Wenn du einen Vers gespeichert hast:

1. Öffne die **Lesezeichen**-Registerkarte.
2. Tippe auf einen beliebigen Eintrag.
3. Du springst direkt zu diesem Vers.

## Von der Suche springen

1. Öffne die **Suchen**-Registerkarte.
2. Gib ein Wort oder eine Phrase ein.
3. Tippe auf ein beliebiges Ergebnis.
4. Die App öffnet das Kapitel, wobei deine Suchwörter gelb hervorgehoben sind.

## Lese-Layout wechseln

Der Bibelleser hat zwei Layouts:

- **Studien-Modus** — zeigt das Kapitel mit allen Studienwerkzeugen einen Tipp entfernt.
- **Fokus-Modus** — verbirgt jedes Werkzeug und Menü und lässt nur den Text.

Zum Wechseln: Tippe beim Lesen oben auf die **📖**-Schaltfläche. Tippe erneut, um zurückzuwechseln. (Der Lesen-Modus bleibt immer im Fokus-Modus.)

## Die unteren Registerkarten nutzen

Die Reihe der Symbole am unteren Bildschirmrand ist immer sichtbar. Tippe auf eine Registerkarte, um zu diesem Bereich zu wechseln. Die genauen Registerkarten hängen von deinem Benutzermodus ab:

**Alle Modi:**

- **Startseite** — zurück zur Startseite.
- **Bibeln** — Liste der Übersetzungen.
- **Suchen** — Bibelsuche.
- **Einstellungen** — Einstellungen und Ressourcen.

**Standard und Gelehrter zeigen außerdem:**

- **Lesezeichen** — gespeicherte Verse.
- **Höhepunkte** — farbig markierte Verse.
- **Bibelnotizen** — deine privaten Notizen.

**Gelehrter zeigt außerdem:**

- **KI** — der KI-Assistent (falls in den Einstellungen eingeschaltet).

### Letzte Position merken

Jede Registerkarte merkt sich ihren eigenen Navigationsverlauf. Wenn du zu einer Registerkarte zurückwechselst, kehrst du zu **der Stelle zurück, an der du aufgehört hast**, nicht zum Startbildschirm dieses Bereichs.

- Du öffnest die **Bibeln**-Registerkarte, wählst eine Übersetzung, öffnest ein Kapitel und wechselst dann zur **Suchen**-Registerkarte. Wenn du später wieder auf **Bibeln** tippst, landest du direkt bei diesem Kapitel.
- Du öffnest die **Lesezeichen**-Registerkarte, tippst auf einen mit Lesezeichen versehenen Vers und wechselst dann zu **Einstellungen**. Wenn du erneut auf **Lesezeichen** tippst, kehrst du zur Lesezeichenliste zurück.

Das gilt für jede Registerkarte. Jede merkt sich ihre Position, bis du ausdrücklich zu einem anderen Bildschirm innerhalb dieser Registerkarte navigierst.

### Was eine Registerkarte zurücksetzt

Eine Registerkarte kehrt nur zu ihrem Startbildschirm zurück, wenn:

- du bereits auf dieser Registerkarte bist und erneut auf dasselbe Symbol tippst. Das ist ein schneller Weg zurück zum Start.
- die App gewaltsam geschlossen und neu geöffnet wird.

### Untere Registerkarten vs. Hauptmenü

- **Untere Registerkarten** — jede Registerkarte merkt sich ihren eigenen Stapel. Ein Tippen auf eine Registerkarte bringt dich zurück zu deiner letzten Position.
- **Hauptmenü** — ein Tippen auf einen Eintrag navigiert zu diesem Bildschirm. Es ist eine Dropdown-Liste, kein Overlay.

Beispiel:

- Du liest Johannes 3. Tippe auf die **Lesezeichen**-Registerkarte, dann wieder auf **Bibeln**. Du kehrst zu Johannes 3 zurück.
- Du liest Johannes 3. Öffne das Menü und tippe auf **Notizen**. Deine Notizen öffnen sich. Tippe dann auf die **Bibeln**-Registerkarte, um zu Johannes 3 zurückzukehren.

## Tipps

- Die Startseite merkt sich, welche Abschnitte ausgeklappt oder eingeklappt sind.
- Wenn eine Registerkarte fehlt, prüfe deinen **Benutzermodus** unter **Einstellungen** → **App-Benutzermodus**. Der Lesen-Modus verbirgt Lesezeichen, Markierungen, Notizen und KI. Der Standard-Modus verbirgt KI. Manche Funktionen musst du außerdem in den **Einstellungen** aktivieren oder eine Ressource installieren.
