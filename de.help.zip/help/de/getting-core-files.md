---
title: Zusätzliche Ressourcen bekommen
level: everyday
categories: resources
summary: So fügst du Bibeln, Kommentare, Bücher und andere Ressourcen zu Theodia hinzu.
---

# Zusätzliche Ressourcen bekommen

Theodia kommt mit einigen integrierten Ressourcen, aber du kannst mehr hinzufügen. Der einfachste Weg führt über den **Ressourcen verwalten**-Bildschirm innerhalb der App.

## Was du hinzufügen kannst

- **Bibeln** — weitere Übersetzungen in verschiedenen Sprachen.
- **Kommentare** — Studiennotizen, die Verse erklären.
- **Bücher** — christliche Klassiker und Nachschlagewerke.
- **Andachten** — tägliche Andachtstexte.
- **Kerndateien** — größere Dateien wie Morphologie, Parallelstellen und die Marvel Interlinear Bible (MIB).

## Ressourcen aus der App heraus hinzufügen

1. Öffne **Einstellungen**.
2. Tippe auf **Ressourcen verwalten**.
3. Wähle eine Registerkarte: **Kern**, **Bibeln**, **Kommentare**, **Bücher** oder **Andachten**.
4. Durchsuche die Liste. Tippe auf eine Ressource, um mehr über sie zu lesen.
5. Tippe auf die Checkbox, um auszuwählen, was du willst.
6. Tippe unten auf **Herunterladen**. Die Dateien laden und installieren sich automatisch.

Sobald installiert, erscheint die Ressource sofort in der App. Du musst die App nicht neu starten.

## Kerndateien

Die **Kern**-Registerkarte enthält große Datendateien, die tiefergehende Studienwerkzeuge ermöglichen. Dazu gehören:

- Morphologie-Daten (Originalsprachen-Wortformen)
- Parallelstellen-Datenbanken
- Die Marvel Interlinear Bible (MIB)

Du musst die Kerndateien nur einmal herunterladen. Sie bleiben auf deinem Gerät und funktionieren offline.

## Globale Bibeln

Die **Globale Bibeln**-Registerkarte enthält Bibelübersetzungen aus einer breiteren Sammlung. Wenn du eine gewünschte Übersetzung in der Haupt-**Bibeln**-Registerkarte nicht findest, schau hier.

## Installierte Ressourcen verwalten

Auf dem Hauptbildschirm **Ressourcen verwalten** (nicht der Download-Registerkarte) kannst du:

- Eine Ressource **aktivieren oder deaktivieren**, ohne sie zu löschen. Deaktivierte Ressourcen bleiben auf dem Gerät, sind aber in den Menüs ausgeblendet.
- Eine Ressource **löschen**, um Speicherplatz freizugeben. Du kannst sie später erneut herunterladen.

## Eigene Dateien hinzufügen

Wenn du eine Ressourcendatei von woanders hast — von einem Freund, einem anderen Projekt oder einer Webseite — kannst du sie direkt importieren:

1. Tippe in **Ressourcen verwalten** auf **Lokale Datei installieren**.
2. Wähle die Datei auf deinem Gerät.
3. Die App liest die Datei und fügt sie deiner Bibliothek hinzu.

Die App akzeptiert diese Dateitypen:

- `.bible` — Bibelübersetzungen
- `.commentary` — Kommentare
- `.lexicon` — Lexika
- `.book` — Bücher
- `.devotional` — Andachten

## Ein eigenes GitHub-Repository verbinden

Wenn jemand ein GitHub-Repository mit Theodia-kompatiblen Ressourcen pflegt, kannst du es als eigene Quelle hinzufügen:

1. Gehe zu **Einstellungen → GitHub Repositories**.
2. Tippe auf **Repository hinzufügen**.
3. Gib die GitHub-URL ein (zum Beispiel `https://github.com/username/repo-name`).
4. Wähle, welche Ressourcentypen das Repository enthält (Bibeln, Kommentare oder Bücher).
5. Speichere es.
6. Kehre zu **Ressourcen verwalten** zurück. Eine neue Registerkarte mit den Ressourcen dieses Repos erscheint.

Wenn das Repository privat ist, brauchst du einen **Persönlichen Zugriffstoken** in **Einstellungen → GitHub Repositories**, damit die App darauf zugreifen kann.

## Hinweis zu Dateigrößen

Ressourcendateien können groß sein. Bibeln sind meist klein (einige Megabyte). Kommentare und Kerndateien können deutlich größer sein (Hunderte Megabyte). Lade nach Möglichkeit über WLAN herunter.

## Zusammenfassung

- Nutze **Einstellungen → Ressourcen verwalten**, um Ressourcen zu durchsuchen und zu installieren.
- Kerndateien schalten tiefergehende Studienwerkzeuge wie Morphologie und Parallelstellen frei.
- Importiere lokale Dateien, wenn du eigene hast.
- Füge benutzerdefinierte GitHub-Repos hinzu, wenn du Ressourcen aus einer anderen Quelle möchtest.
