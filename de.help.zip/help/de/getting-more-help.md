---
title: Wo du Fragen stellen kannst
level: everyday
categories: trouble
summary: Wie du Hilfe vom Theodia-Team und der Community bekommst und Hilfethemen innerhalb der App findest.
---

# Wo du Fragen stellen kannst

Wenn du feststeckst, gibt es einige Orte, um Hilfe zu fragen.

## Ein Hilfethema finden

Wenn du Informationen zu einer bestimmten Funktion suchst, probiere einen dieser Wege:

- **Nach Kategorie durchblättern.** Öffne **Hilfe und Anleitungen** und tippe auf eine Kategorie wie **Einstellungen und Anpassung** oder **Fehlerbehebung**. Jede Karte listet verwandte Leitfäden auf.
- **Nach Stichwort suchen.** Auf dem Hauptbildschirm **Hilfe und Anleitungen** gibst du ein Wort in das Suchfeld oben ein. Wenn du zum Beispiel `notifications` eingibst, erscheint der Leitfaden [Benachrichtigungen und Erinnerungen](theodia://help/notifications); bei `search` erscheint der Leitfaden [Die Bibel durchsuchen](theodia://help/search-the-bible).
- **Zuerst in den Einstellungen nachschauen.** Viele Funktionen werden in den **Einstellungen** konfiguriert. Wenn du Erinnerungen einrichten möchtest, öffne **Einstellungen** → **Benachrichtigungen**. Der Einstellungsbildschirm hat außerdem für jeden Bereich einen **Helfen**-Link.

## Innerhalb der App

Öffne den **Über**-Bildschirm. Dort siehst du zwei Buttons:

- **Vorschlag / Problem senden** — öffnet ein Formular, um dem Team eine Frage, eine Idee oder einen Fehlerbericht zu senden.
- **Diskussion / Feedback** — öffnet das Community-Diskussionsforum.

## Die GitHub-Seite

Du kannst dir die Liste bekannter Probleme und aktueller Änderungen auf [GitHub](https://github.com/ecodiallc/theodia.app) ansehen.

## Community-Diskussion

Andere Theodia-Nutzer stellen Fragen und teilen Tipps im [Community-Diskussionsforum](https://github.com/ecodiallc/theodia.app/discussions). Du kannst alte Threads lesen und einen neuen beginnen.

## Bevor du fragst

Ein paar Dinge helfen uns, schneller zu antworten:

- **Welches Gerät hast du?** (z. B. iPhone 13, Pixel 7)
- **Welche App-Version?** (Öffne **Über**, um es zu sehen.)
- **Was hast du gemacht?** Eine kurze Beschreibung der Schritte.
- **Was ist passiert?** Was hast du auf dem Bildschirm gesehen?
- **Was hast du erwartet?** Das ist oft der nützlichste Teil.

## Was du erwarten kannst

- Bei Fehlerberichten antwortet das Team normalerweise innerhalb weniger Tage.
- Bei Ideen liest das Team sie alle. Wir können nicht versprechen, wann eine Idee umgesetzt wird.
- Bei Community-Fragen antworten andere Nutzer oft schneller als das Team.

## Hinweis zum Datenschutz

Wenn du eine Frage sendest, füge bitte keine privaten Informationen bei. Das Team kann sehen, was du sendest.
