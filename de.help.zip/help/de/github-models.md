---
title: GitHub Models nutzen
level: advanced
categories: ai
summary: So richtest du Microsoft GitHub Models als KI-Provider in Theodia ein.
---

# GitHub Models nutzen

Microsofts [GitHub Models](https://github.com/marketplace/models) bietet einen einfachen und günstigen Weg, leistungsstarke KI-Modelle über eine bekannte API zu nutzen. Theodia unterstützt GitHub Models direkt.

## Was GitHub Models kostet

- GitHub gibt dir monatlich kostenlose API-Credits.
- Sie begrenzen die Anzahl der Anfragen und Token pro Minute.
- Für die meisten Nutzer reicht das kostenlose Kontingent für gelegentliche Bibelstudien aus.
- Wenn du mehr brauchst, kannst du auf ein kostenpflichtiges Abonnement upgraden.

Vergleiche die aktuellen Preise und Limits auf der [GitHub Models-Website](https://github.com/marketplace/models).

## Voraussetzungen

- Ein GitHub-Konto.
- Ein **GitHub Personal Access Token** mit Marketplace-Berechtigungen.
- Theodia geöffnet auf dem Gerät, auf dem du die KI nutzen möchtest.

## Einen GitHub-Token erstellen

1. Gehe in einem Browser zu **GitHub → Einstellungen → Entwicklereinstellungen → Personal Access Tokens**.
2. Erstelle ein neues Token (Fine-grained oder Classic).
3. Aktiviere mindestens das Recht, auf Marketplace-Modelle zuzugreifen.
4. Kopiere das Token.

Tipp: Lege das Token an einem sicheren Ort ab. Du wirst es gleich in die App eingeben.

## Token in Theodia eingeben

1. Öffne **Einstellungen**.
2. Tippe auf **KI-Assistent**.
3. Wähle **GitHub Models** als Provider.
4. Füge deinen Token ein.
5. Tippe auf **Verbindung testen**. Du solltest eine Erfolgsmeldung sehen.
6. Kehre zur Startseite zurück und tippe auf **KI-Assistent**, um ihn zu benutzen.

## Ein Modell auswählen

GitHub Models bietet viele Modelle an, darunter OpenAI-, Microsoft- und andere. Theodia zeigt dir die verfügbaren Modelle, sobald dein Token gespeichert ist.

Beachte, dass einige kleinere Modelle kürzere Antworten und geringere Kosten haben, während größere Modelle bessere Kommentare schreiben, aber mehr verbrauchen. Weitere Hinweise findest du im Leitfaden [Ein Modell wählen](theodia://help/choosing-a-model).

## Limits und Fehlerbehebung

- **429 / Rate-Limit** — du hast das Limit der kostenlosen Stufe erreicht. Warte eine Minute oder prüfe, ob du mehr Credits brauchst.
- **401 / Nicht autorisiert** — dein Token ist ungültig oder abgelaufen. Erstelle ein neues Token in GitHub.
- **Modell nicht verfügbar** — nicht jedes GitHub Models-Modell ist in jedem Land oder auf jeder Stufe verfügbar. Versuche ein anderes Modell.
- **Leere Antwort** — sehr kleine Modelle geben manchmal keine Antwort. Wähle ein größeres Modell oder kürze deine Frage.

## Datenschutz

GitHub speichert deine Anfragen auf deren Servern. Sende keine privaten Informationen. Die meisten Anfragen werden lokal auf deinem Gerät verarbeitet, bevor sie an GitHub gesendet werden, aber der eigentliche KI-Text muss dennoch über das Netzwerk.

## Zusammenfassung

- Erstelle einen GitHub Personal Access Token.
- Wähle in Theodia **Einstellungen → KI-Assistent → GitHub Models**.
- Füge den Token ein und teste die Verbindung.
- Wähle ein Modell und beginne mit dem Bibelstudium.
