---
title: Markierungen nutzen
level: everyday
categories: annotate
summary: Verse farbig markieren, Farbcodes verwalten und Markierungen als Filter verwenden.
---

# Markierungen nutzen

Markierungen sind farbige Verse. Du kannst sie verwenden, um Verse zu kategorisieren, wie Lesezeichen, aber farbig.

## Einen Vers markieren

1. Tippe lange auf einen Vers im Leser.
2. Tippe im Menü auf **Markieren**.
3. Wähle eine Farbe.

Der Vers behält diese Farbe, bis du sie entfernst.

## Farben wechseln

Wenn du einen markierten Vers erneut lange drückst und **Markieren** wählst, kannst du eine andere Farbe auswählen. Das Überschreibt die vorherige.

## Eine Markierung entfernen

Halte den markierten Vers gedrückt, tippe auf **Markierung entfernen**, und die Farbe verschwindet.

## Markierungen ansehen

Öffne die **Höhepunkte**-Registerkarte. Du siehst alle markierten Verse nach Farbe gruppiert. Tippe auf einen Vers, um ihn im Kontext zu lesen.

## Filter im Leser verwenden

Im Bibelleser kannst du auswählen, welche Markierungen sichtbar sein sollen. Wenn du im Studien-Modus bist, tippe auf das Markierungs-Symbol in der Werkzeugleiste, um nach Farbe zu filtern. Das ist nützlich, wenn du mehrere Farben hast und nur eine sehen willst.

## Farbcodes verwalten

Jede Farbe hat eine Bedeutung. Du kannst deine eigenen Bedeutungen festlegen:

1. Öffne **Einstellungen**.
2. Tippe auf **Markierungen**.
3. Wähle eine Farbe und gib ihr eine Bezeichnung. Zum Beispiel:
   - Gelb: Tröstung
   - Rot: Lieblingsverse
   - Grün: Glaube
   - Blau: Heilung

Diese Bezeichnungen erscheinen auf dem Markierungsbildschirm und helfen dir, dich zu erinnern, warum du markiert hast.

## Markierungen und Lesezeichen

Lesezeichen speichern einen Verweis. Markierungen färben einen Vers ein. Ein Vers kann gleichzeitig mit einem Lesezeichen versehen und markiert sein.

## Sicherung

Markierungen werden lokal auf deinem Gerät gespeichert. Um sie zu sichern oder auf ein anderes Gerät zu übertragen, nutze die Sicherungsfunktion in den **Einstellungen**. Siehe [Sicherungen und Wiederherstellung](theodia://help/backups).

## Zusammenfassung

- Langes Drücken auf einen Vers → **Markieren** → Farbe wählen.
- Ändere Farben jederzeit über das gleiche Menü.
- Verwende die **Höhepunkte**-Registerkarte, um alle markierten Verse zu sehen.
- Lege Farbcodes in den **Einstellungen** fest.
