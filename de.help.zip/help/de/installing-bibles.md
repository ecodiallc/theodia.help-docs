---
title: Bibeln installieren
level: beginner
categories: resources
summary: So fügst du weitere Bibelübersetzungen zu Theodia hinzu und verwaltest sie.
---

# Bibeln installieren

Theodia enthält einige Bibeln, aber du kannst viele weitere installieren. Alle arbeiten offline, sobald sie heruntergeladen sind.

## Weitere Bibeln finden

1. Öffne **Einstellungen**.
2. Tippe auf **Ressourcen verwalten**.
3. Tippe auf die Registerkarte **Bibeln**.

Du siehst eine Liste verfügbarer Übersetzungen. Sie ist nach Sprache und Namen sortiert.

## Eine Bibel herunterladen

1. Suche in der Bibel-Liste nach der gewünschten Übersetzung.
2. Tippe auf die Checkbox neben dem Namen, um sie auszuwählen.
3. Tippe unten auf **Herunterladen**.
4. Die Datei wird kopiert und die Bibel erscheint in deiner Liste.

## Eine andere Bibel lesen

Nach der Installation kannst du die Übersetzung sofort benutzen:

1. Öffne die **Bibeln**-Registerkarte.
2. Wähle die Bibel aus der Liste.
3. Wähle ein Buch und ein Kapitel.

Du kannst während des Lesens auch oben auf den Bibelnamen tippen, um schnell zu einer anderen installierten Übersetzung zu wechseln.

## Installierte Bibeln verwalten

Auf dem Hauptbildschirm **Ressourcen verwalten** (oben):

- Schalte eine Bibel **an oder aus**, um sie in den Menüs anzuzeigen oder auszublenden, ohne sie zu löschen.
- Lösche eine Bibel, um Speicherplatz freizugeben. Du kannst sie später erneut herunterladen.

## Speicherplatz

Bibeln sind meist klein (einige Megabyte). Wenn du viele Übersetzungen oder zusätzliche Kommentare installiert hast, kann der Speicherbedarf deutlich steigen. Lösche Bibeln, die du nicht mehr brauchst, um Platz zu sparen.

## Zusammenfassung

- Gehe zu **Einstellungen → Ressourcen verwalten → Bibeln**.
- Wähle eine Bibel aus und tippe auf **Herunterladen**.
- Wähle sie in der **Bibeln**-Registerkarte aus, um zu lesen.
