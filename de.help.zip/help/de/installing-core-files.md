---
title: Kerndateien installieren
level: everyday
categories: resources
summary: So lädst du Morphologie, Parallelstellen und andere große Kerndateien herunter, die tiefergehende Werkzeuge ermöglichen.
---

# Kerndateien installieren

Kerndateien sind große Datendateien, die erweiterte Studienfunktionen in Theodia freischalten. Ohne sie funktionieren einige Werkzeuge nicht oder nur eingeschränkt.

## Was die Kerndateien beinhalten

- **Morphologie** — Wortformen der hebräischen und griechischen Originalsprachen.
- **Parallelstellen** — Verknüpfungen zwischen verwandten Bibelversen.
- **Marvel Interlinear Bible (MIB)** — eine interlineare Bibel mit Originalsprachen-Informationen.
- Weitere Index- und Hilfsdateien.

## Kerndateien herunterladen

1. Öffne **Einstellungen**.
2. Tippe auf **Ressourcen verwalten**.
3. Wähle die Registerkarte **Kern**.
4. Tippe auf **Alles auswählen** oder wähle einzelne Dateien aus.
5. Tippe unten auf **Herunterladen**.

Die Dateien können mehrere hundert Megabyte groß sein. Lade sie am besten über WLAN herunter.

## Nach der Installation

Wenn die Kerndateien installiert sind, erscheinen neue Werkzeuge automatisch:

- Tippe im Bibelleser auf ein Wort, um Morphologie-Informationen zu sehen.
- Tippe auf die Parallelstellen-Schaltfläche, um verwandte Verse anzuzeigen.
- Wähle die Marvel Interlinear Bible als Übersetzung, um hebräische oder griechische Wörter zu sehen.

## Warum manche Dateien separat sind

Kerndateien sind groß. Sie werden nicht automatisch mit der App geliefert, damit der Download der App klein bleibt und du nur die Daten herunterlädst, die du wirklich willst.

## Kerndateien löschen

Wenn du Speicherplatz brauchst:

1. Öffne **Ressourcen verwalten**.
2. Tippe auf eine installierte Kerndatei.
3. Tippe auf **Löschen**.

Du kannst die Dateien später erneut herunterladen, wenn du sie wieder brauchst.

## Zusammenfassung

- Gehe zu **Einstellungen → Ressourcen verwalten → Kern**.
- Lade die Morphologie-, Parallelstellen- und MIB-Daten herunter.
- Verwende sie im Bibelleser für tiefergehende Studien.
