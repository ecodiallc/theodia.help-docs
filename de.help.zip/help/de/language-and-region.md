---
title: Sprache und Region
categories: settings
level: everyday
summary: Ändern der App-Sprache.
---

# Sprache und Region

Theodia ist in vielen Sprachen verfügbar. Die App kann die Sprache der Menüs und Schaltflächen ändern. Hilfe-Inhalte können ebenfalls in mehreren Sprachen heruntergeladen werden; öffne **Einstellungen** → **Helfen** oder **Ressourcen verwalten** → **Von GitHub herunterladen** → **Hilfe-Dokumentation**, um eine Sprache hinzuzufügen.

## Spracheinstellungen öffnen

1. Öffne **Einstellungen**.
2. Tippe auf **Sprache**.

## App-Sprache ändern

1. Tippe in der Liste **Sprache** auf die gewünschte Sprache.
2. Die App wendet die neue Sprache sofort an.

Die angezeigten Optionen hängen von den von der App unterstützten Sprachen ab.

## Wie die Sprache bei der Erstinstallation gewählt wird

Wenn du Theodia zum ersten Mal installierst, wählt die App eine Sprache basierend auf den Einstellungen deines Geräts. Du kannst sie jederzeit ändern.

## Was übersetzt wird

- Menüs, Schaltflächen und Beschriftungen.
- Einstellungsbildschirme.
- Fehlermeldungen.
- Such- und Studienwerkzeuge.

## Was nur auf Englisch verfügbar ist

- Einige Buch- und Andachtsinhalte.
- Hilfe-Handbücher sind auf Englisch verfügbar und als herunterladbare Pakete für andere Sprachen. Füge eine Sprache unter **Einstellungen** → **Helfen** oder **Ressourcen verwalten** → **Von GitHub herunterladen** → **Hilfe-Dokumentation** hinzu.

## Bibelübersetzungen und App-Sprache

Die App-Sprache und die Sprache der Bibelübersetzung sind zwei verschiedene Dinge. Du kannst die App auf Spanisch und die Bibel auf Englisch haben, oder umgekehrt.

Informationen zum Ändern der Bibelübersetzung findest du im Handbuch [Bibelübersetzungen installieren](theodia://help/installing-bibles).

## Tipps

- Wenn eine Schaltfläche oder Beschriftung leer ist, fehlt der App diese Übersetzung. Normalerweise ist die englische Version als Fallback verfügbar.
- Wenn du bei der Übersetzung der App helfen möchtest, sieh dir das Handbuch [Wo du Fragen stellen kannst](theodia://help/getting-more-help) an.
