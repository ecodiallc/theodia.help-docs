---
title: Das Schnellmenü
level: beginner
categories: layout
summary: Das Symbol oben links öffnet ein Menü mit schnellen Aktionen, Plugins und Einstellungen.
---

# Das Schnellmenü

Oben links auf den meisten Bildschirmen siehst du ein Menüsymbol. In der App heißt das **Schnellmenü**. Ein Tippen darauf öffnet eine Liste mit schnellen Aktionen.

## Was das Menü enthält

Der Menüinhalt hängt von deinem **Benutzermodus** und deinen installierten Ressourcen ab. Mögliche Einträge:

- **Home** — zur Startseite zurückkehren.
- **Bibeln** — die Liste der Bibeln öffnen.
- **Suche** — die Bibelsuche öffnen.
- **Lesezeichen** — deine Lesezeichen ansehen.
- **Höhepunkte** — deine markierten Verse ansehen.
- **Bibelnotizen** — deine Notizen öffnen.
- **Gebet** — die Gebetssektion öffnen (falls aktiv).
- **Wiedergabelisten** — deine Audio-Wiedergabelisten (falls aktiv).
- **Plugins** — aktive Plugins öffnen (falls aktiv).
- **KI-Assistent** — den KI-Assistenten starten (falls aktiv).
- **Theoscript** — die Theoscript-Konsole öffnen (falls aktiv).
- **Hilfe und Anleitungen** — die Hilfesektion öffnen.
- **Einstellungen** — die App-Einstellungen öffnen.

## Einen Eintrag nutzen

Tippe einfach auf einen Menüeintrag. Die App navigiert zum passenden Bildschirm.

## Warum das Menü nützlich ist

Die untere Tab-Leiste führt dich zu den wichtigsten Bereichen. Das **Schnellmenü** ergänzt sie mit weniger oft genutzten Bereichen und einer einheitlichen Möglichkeit, von überall aus zu navigieren.

## Unterschied zum Hauptmenü auf der Startseite

Die Startseite hat ein eigenes Menüfeld. Das linke obere **Schnellmenü** ist jedoch immer verfügbar und funktioniert auf fast jedem Bildschirm gleich.

## Zusammenfassung

- Das Symbol oben links öffnet das **Schnellmenü**.
- Es enthält Navigation, Plugins, Werkzeuge und Einstellungen.
- Der genaue Inhalt hängt von deinem Benutzermodus und deinen Ressourcen ab.
