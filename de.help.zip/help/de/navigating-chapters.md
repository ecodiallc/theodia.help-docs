---
title: In Kapiteln navigieren
level: beginner
categories: read
summary: Wischegesten, Kapitel-Wähler und obere Leiste im Bibelleser erklärt.
---

# In Kapiteln navigieren

Wenn du ein Kapitel liest, gibt es mehrere Wege, dich zu bewegen.

## Mit Wischen zwischen Kapiteln wechseln

- **Nach links wischen** → nächstes Kapitel.
- **Nach rechts wischen** → vorheriges Kapitel.

Das funktioniert auch über Bücher hinweg. Nach 2. Könige 25 kommst du durch ein Wischen nach links zu 1. Chronik 1.

## Kapitel aus der oberen Leiste wählen

Die obere Leiste zeigt das aktuelle Buch und Kapitel, zum Beispiel **Johannes 3**. Tippe auf die Kapitelnummer, um ein Dropdown mit allen Kapiteln dieses Buches zu öffnen. Wähle ein Kapitel aus.

## Buch aus der oberen Leiste wählen

Tippe auf den Buchnamen in der oberen Leiste, um die Buchliste zu öffnen. Wähle ein Buch, dann erscheint automatisch die Kapitelliste.

## Kapitelliste im Leser öffnen

Im Studien-Modus ist in der oberen Symbolleiste ein Kapitel-Symbol. Tippe darauf, um eine Liste aller Kapitel des aktuellen Buches zu sehen. Tippe auf eine Nummer, um direkt zu diesem Kapitel zu springen.

## Zurück zur Bibel-Übersicht

Tippe oben auf den Übersetzungsnamen, um zur Liste der installierten Bibeln zurückzukehren.

## Tipp: Verse markieren, während du liest

Halte einen Vers lange gedrückt, um ihn zu markieren, mit einem Lesezeichen zu versehen, eine Notiz hinzuzufügen oder ihn mit dem KI-Assistenten zu erkunden.

## Zusammenfassung

- Wische links/rechts, um Kapitel zu wechseln.
- Tippe auf Buch- oder Kapitelnamen in der oberen Leiste, um zu springen.
- Verwende die Kapitelliste für schnellen Zugriff.
