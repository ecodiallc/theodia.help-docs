---
title: In der App navigieren
level: beginner
categories: layout
summary: Startseite, untere Tabs, Hauptmenü und Leser erklärt.
---

# In der App navigieren

Theodia hat drei Hauptnavigationsebenen: die Startseite, die untere Tab-Leiste und das obere Menü.

## Startseite

Wenn du die App öffnest, landest du auf der Startseite. Sie zeigt:

- Deine letzte Leseposition.
- Heutige Andachten.
- Deine Lesezeichen.
- KI-Empfehlungen (falls aktiviert).
- Eine Schnellsuche.
- Gebetserinnerungen (falls aktiviert).

Viele Bereiche der Startseite kannst du ein- oder ausklappen. Tippe auf eine Karte, um sie zu erweitern oder zu verbergen.

## Schnellbefehl

Oben auf der Startseite befindet sich ein Eingabefeld. Du kannst direkt eingeben:

- `Johannes 3,16`
- `Psalm 23`
- `1 Mose 1`

Tippe auf Los, um das Kapitel zu öffnen.

## Untere Registerkarten

Unten am Bildschirm siehst du Symbole. Die genauen Tabs hängen von deinem Benutzermodus ab:

- **Home** — Startseite.
- **Bibeln** — Bibelauswahl.
- **Suchen** — Bibelsuche.
- **Lesezeichen** — gespeicherte Verse.
- **Höhepunkte** — farbige Verse.
- **Bibelnotizen** — private Notizen.
- **Gebet** — Gebetsbereich.
- **Einstellungen** — App-Einstellungen.

Jede Registerkarte merkt sich, wo du aufgehört hast. Wenn du zurückwechselst, kehrst du zur letzten Stelle in diesem Bereich zurück.

## Obere Menüleiste

Oben links ist das **Schnellmenü**. Es öffnet eine Liste mit schnellen Links, Plugins und Werkzeugen. Oben rechts findest du oft ein **Helfen**-Symbol, das direkt zu einem passenden Hilfethema führt.

## Leser-Bildschirm

Der zentrale Bildschirm zeigt ein Bibelkapitel. Er hat zwei Modi:

- **Studien-Modus** — Werkzeugleiste unten mit Lesezeichen, Markierungen, Notizen, KI und mehr.
- **Fokus-Modus** — nur der Text, keine Werkzeuge.

Tippe oben auf das Buch-Symbol, um zwischen den Modi zu wechseln. Lies mehr im Leitfaden [Lesemodi](theodia://help/study-mode).

## Zurück navigieren

- Tippe auf die System-Zurück-Taste (Android) oder wische von links (iOS).
- Tippe auf eine untere Registerkarte, um zu deren letzter Stelle zurückzukehren.

## Zusammenfassung

- Startseite: schneller Überblick und Schnellbefehl.
- Untere Tabs: Hauptbereiche, jeder merkt sich seine Position.
- Schnellmenü: weitere Aktionen und Werkzeuge.
- Leser: Studien- und Fokus-Modus.
