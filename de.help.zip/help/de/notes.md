---
title: Notizen zu Versen
level: everyday
categories: annotate
summary: Füge private Notizen zu Versen, Büchern oder Themen hinzu und verwalte sie.
---

# Notizen zu Versen

In Theodia kannst du Notizen zu einzelnen Versen, Kapiteln oder allgemeinen Themen schreiben. Notizen sind privat und werden auf deinem Gerät gespeichert.

## Eine Notiz zu einem Vers hinzufügen

1. Halte den Vers lange gedrückt.
2. Tippe im Menü auf **Notiz**.
3. Schreibe deine Notiz.
4. Tippe auf **Speichern**.

Ein Notiz-Symbol erscheint neben dem Vers.

## Eine Notiz bearbeiten

Tippe auf das Notiz-Symbol neben einem Vers, oder gehe zur **Bibelnotizen**-Registerkarte, wähle eine Notiz aus und tippe auf **Bearbeiten**.

## Notizen ansehen

Öffne die **Bibelnotizen**-Registerkarte. Du siehst alle Notizen sortiert nach Datum. Tippe auf eine Notiz, um den dazugehörigen Vers oder das Kapitel zu öffnen.

## Notizen suchen

Auf dem Notizenbildschirm kannst du oben in das Suchfeld tippen. Die App durchsucht Titel und Inhalt deiner Notizen.

## Notizen löschen

Wähle auf dem Notizenbildschirm eine Notiz aus und tippe auf **Löschen**. Bestätige, wenn du gefragt wirst.

## Notizen sichern

Notizen werden lokal gespeichert. Um sie zu sichern oder auf ein anderes Gerät zu übertragen, verwende die Sicherungsfunktion in den **Einstellungen**. Siehe [Sicherungen und Wiederherstellung](theodia://help/backups).

## Zusammenfassung

- Langes Drücken auf einen Vers → **Notiz**.
- Verwalte Notizen in der **Bibelnotizen**-Registerkarte.
- Sichere Notizen regelmäßig über die Sicherungsfunktion.
