---
title: Benachrichtigungen und Erinnerungen
level: everyday
categories: settings
summary: So richtest du Erinnerungen für das Bibellesen, Andachten und Gebete ein.
---

# Benachrichtigungen und Erinnerungen

Theodia kann dich erinnern, regelmäßig die Bibel zu lesen, zu beten oder Andachten anzusehen. Du bestimmst, wann und wie oft du erinnert werden möchtest.

## Benachrichtigungen erlauben

Auf deinem Gerät musst du zuerst Benachrichtigungen für Theodia erlauben. Wenn die App fragt, tippe auf **Erlauben**. Du kannst dies später auch in den Systemeinstellungen deines Geräts ändern.

## Erinnerungen einrichten

1. Öffne **Einstellungen**.
2. Tippe auf **Benachrichtigungen**.
3. Wähle die Art der Erinnerung:
   - **Bibellesen** — Erinnerung zur täglichen Bibellektüre.
   - **Andachten** — Erinnerung, die heutige Andacht zu öffnen.
   - **Gebet** — Erinnerung für Gebetsroutinen oder Ziele.
4. Stelle die Uhrzeit ein.
5. Wähle, an welchen Wochentagen die Erinnerung erscheinen soll.
6. Tippe auf **Speichern**.

## Erinnerungen bearbeiten

Gehe zurück zu **Einstellungen → Benachrichtigungen**. Tippe auf eine vorhandene Erinnerung, um sie zu ändern oder zu löschen.

## Push-Benachrichtigungen vs. lokale Erinnerungen

Theodia verwendet lokale Benachrichtigungen. Sie werden von deinem Gerät ausgelöst, nicht von einem Server. Du brauchst dafür keine Internetverbindung.

## Keine Benachrichtigungen erhalten?

- Prüfe in den Systemeinstellungen, ob Theodia Benachrichtigungen senden darf.
- Stelle sicher, dass der **Nicht stören**-Modus deines Geräts ausgeschaltet ist.
- Überprüfe, ob die Erinnerung aktiviert und die Uhrzeit korrekt ist.
- Auf manchen Android-Geräten muss die App vom Akku-Optimierungssystem ausgenommen werden, damit Erinnerungen zuverlässig erscheinen.

## Zusammenfassung

- Öffne **Einstellungen → Benachrichtigungen**.
- Wähle Erinnerungsart, Uhrzeit und Wochentage.
- Benachrichtigungen sind lokal und funktionieren offline.
