---
title: PDFs
level: everyday
categories: [read, resources]
summary: PDF-Dokumente in Theodia importieren, ordnen und lesen.
---

# PDFs

> **Modus:** PDFs sind im **Standard**- und **Gelehrten**-Modus verfügbar. Der Fokus-Modus ist nur für sauberes, ablenkungsfreies Lesen. Du kannst die Modi unter **Einstellungen** → **App-Benutzermodus** wechseln.

Theodia kann PDF-Dateien speichern und lesen. Importierte PDFs bleiben auf deinem Gerät und funktionieren daher offline.

## Die PDF-Bibliothek öffnen

Tippe unten auf dem Bildschirm auf die Registerkarte **PDFs** oder auf dem Startbildschirm auf die Kachel **PDFs**.

## Ein PDF importieren

1. Öffne die Registerkarte **PDFs**.
2. Tippe unten rechts auf die **+**-Schaltfläche.
3. Wähle ein PDF von deinem Gerät.
4. (Optional) Tippe eine Kategorie ein oder wähle eine aus, um das PDF zu ordnen.

## PDFs ordnen

Halte eine PDF-Karte gedrückt, um ein Menü mit diesen Optionen zu öffnen:

- **Umbenennen** — ändert den Titel, der in der Bibliothek angezeigt wird.
- **Kategorie ändern** — verschiebt das PDF in eine Kategorie.
- **Löschen** — entfernt das PDF aus Theodia. Dabei wird auch die gespeicherte Leseposition gelöscht.

Kategorien sind freier Text. Tippe beim Importieren oder Ändern einer Kategorie einen neuen Namen ein oder wähle einen vorhandenen aus.

## Ein PDF lesen

Tippe auf eine PDF-Karte, um sie zu öffnen. Der Leser zeigt:

- Den Dokumenttitel in einer Leiste oben.
- Eine Reihe von Seiten-Schaltflächen: **Erste Seite**, **Zurück**, die aktuelle Seite („3 / 120“), **Weiter** und **Letzte Seite**.
- Eine Werkzeugleiste mit den Werkzeugen des Dokuments: **Inhalt**, **Verkleinern**, **Vergrößern**, **Zoom zurücksetzen**, **Lesezeichen**, **Suchen**, **Vorlesen** und **Textansicht**.

Manche Werkzeuge sind ausgegraut, wenn sie nicht benutzt werden können — zum Beispiel sind **Suchen** und **Vorlesen** ausgegraut, bis der durchsuchbare Text des PDFs installiert ist.

### Blättern

- Tippe auf den **linken** oder **rechten Pfeil**, um eine Seite zurück oder vor zu gehen.
- Tippe auf **Erste Seite** oder **Letzte Seite**, um an ein Ende des Dokuments zu springen.
- Tippe auf die Seitenzahl (zum Beispiel „3 / 120“), um ein Raster der Seiten zu öffnen, und tippe dann auf die gewünschte Seite. Das Raster öffnet sich in der Nähe der Seite, auf der du gerade bist.
- Benutze die **Pfeiltasten links und rechts** einer externen Tastatur.

### Zoom

- Tippe auf **Vergrößern** (+) oder **Verkleinern** (−), um die Seitengröße zu ändern.
- Tippe auf **Zoom zurücksetzen**, um die Seite auf ihre normale Größe zurückzusetzen.
- Wenn du vergrößerst, blätterst und dann wieder verkleinerst, bringt dich Theodia zurück zu der Seite, die du gerade gelesen hast.

## Innerhalb eines PDFs suchen

1. Öffne das PDF und tippe auf die **Suchen**-Schaltfläche (Lupe) in der Werkzeugleiste.
2. Tippe ein, wonach du suchst. Die Ergebnisse erscheinen schon beim Tippen, mit der Seitenzahl und einem Ausschnitt des umgebenden Texts.
3. Tippe auf ein Ergebnis, um zu dieser Seite zu springen.

Zum Suchen muss der durchsuchbare Text des PDFs installiert sein. Ist das noch nicht der Fall, ist die Suchen-Schaltfläche ausgegraut. PDFs aus dem Community-GitHub-Repository enthalten den durchsuchbaren Text; bei selbst importierten PDFs fehlt er, bis er hinzugefügt wird.

## Inhalt

Hat das PDF ein eingebautes Inhaltsverzeichnis, zeigt die **Inhalt**-Schaltfläche in der Werkzeugleiste es als Gliederung. Tippe auf einen Abschnittstitel, um zu dieser Seite zu springen. Abschnitte lassen sich auf- und zuklappen. Hat das PDF kein Inhaltsverzeichnis, ist die Schaltfläche ausgegraut.

## Lesezeichen in einem PDF

1. Öffne das PDF und tippe auf die **Lesezeichen**-Schaltfläche in der Werkzeugleiste.
2. Tippe auf **Seite mit Lesezeichen versehen**, um die aktuelle Seite zu speichern. Der Name beginnt als Seitenzahl — tippe lieber einen eigenen Namen ein — und tippe dann auf **Speichern**.
3. Tippe auf ein beliebiges Lesezeichen in der Liste, um zu seiner Seite zu springen.
4. Tippe auf das **×** neben einem Lesezeichen, um es zu löschen.

PDF-Lesezeichen sind getrennt von deinen Bibel-Lesezeichen. Jedes PDF hat seine eigene Liste.

## Ein PDF vorlesen lassen

Ist der durchsuchbare Text des PDFs installiert, kann Theodia die aktuelle Seite vorlesen:

1. Öffne das PDF und tippe auf die **Vorlesen**-Schaltfläche (Lautsprecher) in der Werkzeugleiste.
2. Es erscheint eine Steuerleiste mit **Wiedergabe/Pause**, **Zurückspulen**, **Vorspulen**, **Stopp**, einer Fortschrittsleiste, auf die du tippen kannst, um innerhalb der Seite zu springen, sowie der Lesegeschwindigkeit und der Stimme.
3. Wenn die Seite fertig ist, liest die Sprachausgabe automatisch auf der nächsten Seite weiter.

Stimme und Geschwindigkeit sind dieselben wie beim Bibelvorlesen — siehe [Sprachausgabe](theodia://help/tts), wie du sie änderst.

## Seitentext kopieren, teilen oder speichern

Tippe auf die **Textansicht**-Schaltfläche in der Werkzeugleiste, um die aktuelle Seite als reinen Text zu sehen. Von dort kannst du:

- **Kopieren** — den Seitentext in die Zwischenablage kopieren.
- **Teilen** — den Seitentext über eine beliebige App auf deinem Gerät teilen.
- **Zu Studiennotizen hinzufügen** — öffnet einen Notiz-Editor, in dem Seitentext, Quellenangabe und ein Link zurück zu dieser Seite bereits für dich eingetragen sind.

## Lesen fortsetzen

Theodia merkt sich die zuletzt angesehene Seite und öffnet das PDF beim nächsten Mal dort.

## PDFs von GitHub herunterladen

Im **Gelehrten**-Modus erscheint unten in der Bibliothek eine Schaltfläche **Von GitHub herunterladen**. Sie stellt die Verbindung zum Community-PDF-Repository her, sodass du gepackte PDF-Dokumente genauso installieren kannst wie Bibeln oder Bücher.

## Hinweise

- PDFs werden im privaten Dokumentenordner von Theodia gespeichert. Sie sind nicht in Sicherungen enthalten — wenn du auf ein neues Gerät umziehst, musst du sie erneut importieren.
