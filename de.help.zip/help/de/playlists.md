---
title: Wiedergabelisten
level: everyday
categories: playlists
summary: So erstellst du Wiedergabelisten aus Bibelkapiteln und lauschst ihnen mit Sprachausgabe.
---

# Wiedergabelisten

Wiedergabelisten sind Zusammenstellungen von Bibelkapiteln, die du nacheinander anhören möchtest. Du kannst sie mit der Sprachausgabe (TTS) abspielen.

## Eine Wiedergabeliste erstellen

1. Öffne die **Wiedergabelisten**-Registerkarte oder gehe über das Menü zu **Wiedergabelisten**.
2. Tippe auf **Neue Wiedergabeliste**.
3. Gib einen Namen ein, zum Beispiel "Morgenandacht".
4. Tippe auf **Speichern**.

## Kapitel hinzufügen

1. Öffne eine Wiedergabeliste.
2. Tippe auf **Kapitel hinzufügen**.
3. Wähle eine Bibel, ein Buch und ein Kapitel.
4. Wiederhole den Vorgang, um weitere Kapitel hinzuzufügen.

## Wiedergabeliste abspielen

1. Öffne die Wiedergabeliste.
2. Tippe auf die **Wiedergabe**-Schaltfläche.
3. Die App liest die Kapitel nacheinander vor.

Du kannst die Wiedergabe pausieren, überspringen oder die Geschwindigkeit ändern.

## Stimme und Geschwindigkeit

Während der Wiedergabe kannst du:

- Die TTS-Stimme ändern.
- Die Sprechgeschwindigkeit anpassen.
- Zwischen Kapiteln springen.

Weitere Details findest du im Leitfaden [Sprachausgabe](theodia://help/tts).

## Wiedergabelisten verwalten

- Tippe auf eine Wiedergabeliste, um sie zu bearbeiten.
- Halte eine Wiedergabeliste lange gedrückt, um sie umzubenennen oder zu löschen.
- Verschiebe Kapitel innerhalb einer Wiedergabeliste per Drag & Drop, um die Reihenfolge zu ändern.

## Verwendungszwecke

- Mache eine Wiedergabeliste für die Morgenandacht.
- Erstelle eine Liste mit Psalmen zum Einschlafen.
- Füge Kapitel einer Predigtreihe hinzu, die du anhören möchtest.

## Zusammenfassung

- Erstelle Wiedergabelisten unter **Wiedergabelisten**.
- Füge Bibelkapitel hinzu und spiele sie mit TTS ab.
- Verwalte Reihenfolge, Stimme und Geschwindigkeit innerhalb der Wiedergabeliste.
