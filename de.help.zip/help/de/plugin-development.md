---
title: Plugins entwickeln
level: advanced
categories: plugins
summary: Grundgerüst für eigene Theodia-Plugins mit TypeScript, Werkzeugen und Dateiformaten.
---

# Plugins entwickeln

Theodia-Plugins sind eigenständige Erweiterungen, die neue Funktionen zur App hinzufügen. Sie werden mit JavaScript oder TypeScript geschrieben und über die Plugin-Verwaltung geladen.

> Hinweis: Dies ist eine technische Einführung. Du brauchst Grundkenntnisse in JavaScript und vertrautheit mit JSON-Dateien.

## Ein Plugin besteht aus

- Einer `plugin.json` mit Metadaten.
- Einem oder mehreren JavaScript/TypeScript-Dateien.
- Optional: Wiedergabelisten-Dateien, UI-Definitionen oder Hilfsbibliotheken.

## plugin.json

Die `plugin.json` beschreibt dein Plugin:

```json
{
  "id": "meine-erweiterung",
  "name": "Meine Erweiterung",
  "version": "1.0.0",
  "author": "Dein Name",
  "description": "Beschreibe, was das Plugin macht.",
  "entry": "index.js",
  "permissions": ["storage", "bible", "tts"]
}
```

- `id` muss eindeutig sein.
- `entry` ist die Hauptdatei, die Theodia lädt.
- `permissions` listet auf, auf welche App-Bereiche das Plugin zugreifen darf.

## Die Hauptdatei

Die `entry`-Datei exportiert normalerweise ein Objekt mit Lebenszyklus-Funktionen:

```js
export default {
  async onLoad({ bibleApi, ui, storage }) {
    // Wird aufgerufen, wenn das Plugin aktiviert wird.
  },
  async onUnload() {
    // Wird aufgerufen, wenn das Plugin deaktiviert wird.
  },
};
```

Theodia stellt dem Plugin einen Kontext mit ausgewählten APIs zur Verfügung. Welche APIs verfügbar sind, hängt von den `permissions` ab.

## APIs im Plugin-Kontext

- `bibleApi` — Bibeltext, Kommentare, Lexika und Suchergebnisse abrufen.
- `storage` — eigene Schlüssel-Werte-Paare im Plugin-Bereich speichern.
- `ui` — Schaltflächen, Menüs und Dialoge in der App registrieren.
- `tts` — Text-to-Speech auslösen.
- `router` — zu App-Bildschirmen navigieren.

Nicht jede API ist in jeder App-Version verfügbar. Prüfe `ui.isApiAvailable`, wenn du robusten Code schreiben möchtest.

## Plugin installieren

Während der Entwicklung kannst du ein Plugin lokal laden:

1. Gehe zu **Einstellungen → Plugins → Lokales Plugin installieren**.
2. Wähle die Plugin-Datei oder den Plugin-Ordner.
3. Aktiviere es.

Wenn das Plugin Fehler enthält, zeigt die App eine Fehlermeldung an. Öffne **Einstellungen → Plugins**, um es zu deaktivieren oder zu löschen.

## Fehlerbehebung

- Die App meldet "Plugin-ID fehlt" — `id` in `plugin.json` ist leer oder doppelt vorhanden.
- Keine Reaktion nach dem Laden — prüfe, ob du `onLoad` exportierst und keine Fehler wirfst.
- API nicht verfügbar — füge die passende Berechtigung zu `permissions` hinzu.

## Weiterführende Hinweise

- Halte Plugins klein. Ein Plugin sollte eine klar definierte Aufgabe haben.
- Verwende `storage` für Plugin-Daten, nicht die globalen App-Einstellungen.
- Teste Plugins im Lesen-Modus und im Gelehrten-Modus, damit sie überall funktionieren.

## Zusammenfassung

- Schreibe `plugin.json`, `entry`-Datei und optional weitere Dateien.
- Wähle Berechtigungen, die zu deinem Plugin passen.
- Installiere lokal über **Einstellungen → Plugins**.
- Nutze `bibleApi`, `storage`, `ui` und andere APIs, um Funktionen zu ergänzen.
