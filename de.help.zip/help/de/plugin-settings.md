---
title: Plugin-Einstellungen
level: advanced
categories: plugins
summary: So konfigurierst du aktive Plugins und verwaltest deren Berechtigungen.
---

# Plugin-Einstellungen

Aktive Plugins können ihre eigenen Einstellungen haben. Du findest sie in der Plugin-Verwaltung.

## Einstellungen eines Plugins öffnen

1. Öffne **Einstellungen**.
2. Tippe auf **Plugins**.
3. Tippe auf ein aktiviertes Plugin in der Liste.
4. Tippe auf **Einstellungen** (falls verfügbar).

## Was du einstellen kannst

Jedes Plugin definiert selbst, welche Einstellungen es anbietet. Häufige Beispiele:

- API-Schlüssel für externe Dienste.
- Standard-Sprache oder Übersetzung.
- Anzeige-Optionen wie Farben oder Schriftgröße.
- Aktivierte Funktionen innerhalb des Plugins.

## Berechtigungen prüfen

Wenn du ein Plugin aktivierst, fragt die App nach Berechtigungen. Du kannst sie später ändern:

1. Öffne **Einstellungen → Plugins**.
2. Tippe auf das Plugin.
3. Tippe auf **Berechtigungen**.
4. Schalte Berechtigungen an oder aus.

Vorsicht: Wenn du eine Berechtigung entziehst, kann das Plugin nicht mehr richtig funktionieren.

## Plugin deaktivieren

1. Öffne **Einstellungen → Plugins**.
2. Tippe auf das Plugin.
3. Tippe auf **Deaktivieren**.

Deaktivierte Plugins bleiben installiert, werden aber nicht mehr ausgeführt.

## Plugin löschen

1. Öffne **Einstellungen → Plugins**.
2. Tippe auf das Plugin.
3. Tippe auf **Löschen**.

Das entfernt das Plugin vollständig. Seine Einstellungen werden ebenfalls gelöscht.

## Zusammenfassung

- Öffne **Einstellungen → Plugins**.
- Tippe auf ein Plugin, um Einstellungen und Berechtigungen zu bearbeiten.
- Deaktiviere oder lösche Plugins, die du nicht mehr brauchst.
