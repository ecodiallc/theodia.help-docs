---
title: Plugins
level: everyday
categories: plugins
summary: Übersicht über Plugins in Theodia — installieren, aktivieren und nutzen.
---

# Plugins

Plugins erweitern Theodia um zusätzliche Funktionen. Sie werden separat von der Haupt-App verwaltet, damit du selbst entscheidest, welche Erweiterungen du nutzen möchtest.

## Was Plugins machen können

Plugins können:

- Neue Bildschirme oder Werkzeuge hinzufügen.
- Mit Bibeltext, Kommentaren und Lexika arbeiten.
- Benachrichtigungen oder Erinnerungen einrichten.
- Auf die Sprachausgabe zugreifen.
- Eigene Einstellungen und Datenspeicher nutzen.

## Ein Plugin installieren

1. Öffne **Einstellungen**.
2. Tippe auf **Plugins**.
3. Tippe auf **Plugin installieren**.
4. Wähle die Plugin-Datei oder den Plugin-Ordner.
5. Bestätige die Berechtigungen.
6. Schalte das Plugin ein, um es zu aktivieren.

## Ein Plugin aktivieren

Nach der Installation ist ein Plugin zunächst inaktiv. Tippe in der Plugin-Liste auf den Schalter neben dem Namen, um es einzuschalten.

## Ein Plugin deaktivieren

Tippe auf den Schalter neben einem aktiven Plugin, um es auszuschalten. Deaktivierte Plugins bleiben installiert, werden aber nicht ausgeführt.

## Ein Plugin löschen

1. Tippe in der Plugin-Liste auf das Plugin.
2. Tippe auf **Löschen**.
3. Bestätige.

## Plugin-Menüs

Einige Plugins fügen dem oberen Schnellmenü oder dem Startseitenmenü Einträge hinzu. Diese erscheinen automatisch, wenn das Plugin aktiviert ist.

## Eigene Plugins entwickeln

Wenn du ein Plugin selbst schreiben möchtest, findest du eine Einführung im Leitfaden [Plugins entwickeln](theodia://help/plugin-development).

## Zusammenfassung

- Gehe zu **Einstellungen → Plugins**.
- Installiere, aktiviere, deaktiviere oder lösche Plugins.
- Plugins erweitern das Menü und die Funktionen der App.
