---
title: Gebetsziele
level: everyday
categories: prayer
summary: So legst du Gebetsziele an, verfolgst sie und teilst sie optional mit anderen.
---

# Gebetsziele

Gebetsziele sind Dinge, für die du über längere Zeit beten möchtest. Sie helfen dir, regelmäßig für Menschen, Situationen oder Themen zu beten.

## Ein Gebetsziel anlegen

1. Öffne die **Gebet**-Registerkarte.
2. Tippe auf **Ziele**.
3. Tippe auf **Neues Ziel**.
4. Gib einen Titel ein, zum Beispiel "Heilung für Oma" oder "Frieden im Nahen Osten".
5. Optional: Füge eine Beschreibung, eine Kategorie und ein Fälligkeitsdatum hinzu.
6. Tippe auf **Speichern**.

## Ein Ziel während des Gebets auswählen

Wenn du eine Gebetsroutine startest, kannst du eins oder mehrere Ziele auswählen, die du heute beten möchtest. Die Routine wird diese Ziele in die Gebetszeit einbauen.

## Fortschritt verfolgen

Jedes Ziel zeigt, wie oft du dafür gebetet hast. Du kannst dir auf der Ziel-Detailseite ansehen:

- Wann du zuletzt dafür gebetet hast.
- Wie viele Tage oder Wochen es aktiv ist.
- Ob es abgeschlossen oder erledigt ist.

## Ziele kategorisieren

Du kannst Ziele in eigene Kategorien einteilen, zum Beispiel:

- Familie
- Arbeit
- Gemeinde
- Welt
- Persönlich

Beim Erstellen oder Bearbeiten wählst du einfach eine Kategorie.

## Ziele bearbeiten oder löschen

1. Tippe in der Zielliste auf ein Ziel.
2. Tippe auf **Bearbeiten** oder **Löschen**.
3. Speichere die Änderungen.

## Ziele mit anderen teilen

Einige Nutzer möchten Gebetsziele in einer Gruppe oder mit einem Freund teilen. Wenn die App diese Funktion unterstützt, siehst du auf der Ziel-Detailseite eine Teilen-Schaltfläche.

## Zusammenfassung

- Lege Gebetsziele unter **Gebet → Ziele** an.
- Wähle sie in Routinen aus, um sie regelmäßig zu beten.
- Verfolge Fortschritt und Kategorien.
