---
title: Das Gebet in Theodia
level: everyday
categories: prayer
summary: Überblick über die Gebetsfunktionen der App: Routinen, Ziele und Statistiken.
---

# Das Gebet in Theodia

Theodia bietet einfache Werkzeuge, die dir helfen, regelmäßig und fokussiert zu beten. Du kannst Routinen, Gebetsziele und Erinnerungen nutzen.

## Was du tun kannst

- **Routinen** erstellen — feste Gebetsabläufe für Morgen, Abend oder besondere Anliegen.
- **Ziele** verfolgen — Anliegen, für die du langfristig betest.
- **Erinnerungen** einrichten — damit die App dich zur Gebetszeit benachrichtigt.
- **Statistiken** ansehen — einen Überblick darüber, wie regelmäßig du betest.

## Den Gebet-Bereich öffnen

1. Tippe unten auf die **Gebet**-Registerkarte. Wenn sie nicht sichtbar ist, ist der Gebetsbereich in deinem Benutzermodus ausgeblendet. Öffne **Einstellungen → App-Benutzermodus**, um ihn einzuschalten.

## Für wen es gedacht ist

Der Gebetsbereich ist für alle Nutzer gedacht, die eine strukturierte Gebetszeit möchten. Du musst keine bestimmte Tradition haben, um ihn zu nutzen.

## Datenschutz

Gebetsziele, Routinen und Statistiken werden lokal auf deinem Gerät gespeichert. Theodia speichert sie nicht auf einem Server, es sei denn, du entscheidest dich ausdrücklich für eine Synchronisation.

## Weiterführende Leitfäden

- [Gebetsroutinen](theodia://help/prayer-routines)
- [Gebetsziele](theodia://help/prayer-goals)
- [Gebetsstatistiken](theodia://help/prayer-statistics)

## Zusammenfassung

- Öffne den Gebetsbereich über die untere Registerkarte.
- Erstelle Routinen, Ziele und Erinnerungen.
- Verfolge deine Gebetsgewohnheiten in den Statistiken.
