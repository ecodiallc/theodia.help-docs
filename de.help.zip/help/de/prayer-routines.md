---
title: Gebetsroutinen
level: everyday
categories: prayer
summary: So baust du Abläufe für regelmäßige Gebetszeiten.
---

# Gebetsroutinen

Eine Gebetsroutine ist ein festgelegter Ablauf für eine Gebetszeit. Du kannst zum Beispiel eine Morgenroutine mit Anbetung, Danksagung, Fürbitte und abschließendem Segen erstellen.

## Eine Routine erstellen

1. Öffne die **Gebet**-Registerkarte.
2. Tippe auf **Routinen**.
3. Tippe auf **Neue Routine**.
4. Gib der Routine einen Namen, zum Beispiel "Morgengebet".
5. Füge Schritte hinzu. Jeder Schritt hat einen Titel und optional:
   - Eine Dauer (zum Beispiel 5 Minuten).
   - Eine Beschreibung oder ein Gebetstext.
   - Ein oder mehrere verknüpfte Gebetsziele.
   - Einen Bibelvers.
6. Tippe auf **Speichern**.

## Eine Routine starten

1. Tippe in der Routinenliste auf eine Routine.
2. Tippe auf **Starten**.
3. Folge den Schritten. Wenn du Dauern eingestellt hast, hilft die App dir, die Zeit im Blick zu behalten.

## Routinen während des Gebets bearbeiten

Du kannst Schritte überspringen oder wiederholen, während die Routine läuft. Tippe dazu auf die entsprechenden Schaltflächen.

## Beispiel für eine einfache Routine

- Anbetung — 2 Minuten
- Danken — 2 Minuten
- Fürbitte für Familie — 3 Minuten
- Fürbitte für die Gemeinde — 3 Minuten
- Segen — 1 Minute

## Routinen mit Erinnerungen verknüpfen

Wenn du möchtest, dass die App dich regelmäßig an eine Routine erinnert, gehe zu **Einstellungen → Benachrichtigungen** und richte eine Erinnerung ein. Weitere Details findest du im Leitfaden [Benachrichtigungen und Erinnerungen](theodia://help/notifications).

## Zusammenfassung

- Erstelle Routinen unter **Gebet → Routinen**.
- Füge Titel, Dauer, Beschreibungen, Ziele und Verse hinzu.
- Starte eine Routine und folge den Schritten.
