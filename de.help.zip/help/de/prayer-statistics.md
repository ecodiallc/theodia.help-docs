---
title: Gebetsstatistiken
level: everyday
categories: prayer
summary: Überblick über deine Gebetsgewohnheiten und Fortschritt.
---

# Gebetsstatistiken

Theodia zeichnet auf, wann und wie oft du betest. Die Statistiken helfen dir, Gewohnheiten zu erkennen und dich zu ermutigen.

## Statistiken ansehen

1. Öffne die **Gebet**-Registerkarte.
2. Tippe auf **Statistiken**.

Du siehst Diagramme für:

- Gebetszeit pro Tag oder Woche.
- Abgeschlossene Routinen.
- Anzahl der Gebetsziele, für die du gebetet hast.

## Zeitraum wählen

Oben auf dem Statistikbildschirm kannst du zwischen Tag, Woche, Monat und Jahr wechseln.

## Statistiken zurücksetzen

Wenn du von vorne beginnen möchtest:

1. Tippe oben rechts auf das Menü (drei Punkte).
2. Tippe auf **Statistiken zurücksetzen**.
3. Bestätige.

Hinweis: Gelöschte Statistiken können nicht wiederhergestellt werden.

## Streaks

Eine Streak zeigt, an wie vielen aufeinanderfolgenden Tagen du mindestens einmal gebetet hast. Wenn du eine Tage verpasst, beginnt die Streak neu.

## Zusammenfassung

- Öffne **Gebet → Statistiken**.
- Wechsle zwischen Tages-, Wochen-, Monats- und Jahresansicht.
- Setze Statistiken zurück, wenn du neu beginnen möchtest.
