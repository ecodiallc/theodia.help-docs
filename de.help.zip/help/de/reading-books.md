---
title: Bücher lesen
level: everyday
categories: content
summary: So öffnest und liest du installierte Bücher wie Kommentare, christliche Klassiker und Nachschlagewerke.
---

# Bücher lesen

Neben der Bibel kann Theodia auch Bücher anzeigen. Das sind meist christliche Klassiker, Nachschlagewerke oder spezielle Sammlungen.

## Ein Buch öffnen

1. Tippe unten auf die **Bibeln**-Registerkarte.
2. Tippe oben auf die Registerkarte **Bücher**.
3. Wähle ein Buch aus der Liste.
4. Tippe auf ein Kapitel oder einen Abschnitt, um zu lesen.

## Im Buch navigieren

- Wische nach links oder rechts, um zum nächsten oder vorherigen Kapitel zu gelangen.
- Tippe oben auf den Buchtitel, um das Inhaltsverzeichnis zu öffnen.
- Verwende die Suche innerhalb des Buches, um ein Stichwort zu finden.

## Bücher installieren

Wenn die Liste leer ist, musst du zuerst Bücher hinzufügen:

1. Öffne **Einstellungen**.
2. Tippe auf **Ressourcen verwalten**.
3. Wähle die Registerkarte **Bücher**.
4. Wähle die gewünschten Bücher aus und tippe auf **Herunterladen**.

## Bücher und Bibel im Blick

Wenn du einen Bibelvers im Buch siehst, kannst du oft darauf tippen, um ihn direkt in der Bibel zu öffnen. Das ist besonders bei Kommentaren und Nachschlagewerken praktisch.

## Schriftgröße und Thema

Bücher verwenden dieselben Lese-Einstellungen wie die Bibel. Du kannst Schriftgröße, Zeilenabstand und Thema in den **Einstellungen** ändern. Siehe [Designs und Schriftarten](theodia://help/themes-and-fonts).

## Zusammenfassung

- Wechsle in der **Bibeln**-Registerkarte zu **Bücher**.
- Installiere Bücher über **Einstellungen → Ressourcen verwalten → Bücher**.
- Tippe auf Bibelverweise im Buch, um die Bibel zu öffnen.
