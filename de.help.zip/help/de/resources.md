---
title: Ressourcen auf GitHub finden
level: everyday
categories: resources
summary: Durchsuche auf einmal alle GitHub-Repos, die die App kennt, und installiere, was du findest.
---

# Ressourcen auf GitHub finden

Theodia führt eine Liste von GitHub-Repositories, die Ressourcen veröffentlichen — Bibeln, Kommentare, Bücher, Andachten, Wiedergabelisten, Gebetspakete und mehr. **GitHub-Repos durchsuchen** durchsucht alle auf einmal, sodass du nicht jede Registerkarte einzeln öffnen und durchstöbern musst.

> Der GitHub-Bereich der Einstellungen ist nur im **Gelehrten-Modus** verfügbar. Um ihn zu aktivieren, gehe zu **Einstellungen → App-Benutzermodus → Gelehrter**.

## So wird gesucht

1. Öffne die **Einstellungen**.
2. Tippe auf **GitHub-Repos durchsuchen**.
3. Tippe ein Wort in das Suchfeld ein. Die App sucht dieses Wort im **Namen** und in der **Beschreibung** jedes Pakets in jedem Repository.

Ein paar Dinge, die du über die Suche wissen solltest:

- **Jedes Wort muss übereinstimmen.** Die Suche nach `morning evening` findet nur Pakete, deren Name oder Beschreibung *beide* Wörter enthält.
- **Groß- und Kleinschreibung ist egal.** `Morning` und `morning` finden dieselben Pakete.
- **Die beste Übereinstimmung kommt zuerst.** Ein Paket, dessen Name *mit* deiner Suche *beginnt*, wird vor einem angezeigt, das sie nur in der Beschreibung erwähnt.

## Filtern

Tippe auf die Filterleiste über den Ergebnissen, um die Liste weiter einzugrenzen. Es gibt zwei Filter, und sie wirken zusammen:

- **Autor** — nur Pakete dieses Autors.
- **Tradition** — nur Pakete dieser Tradition.

Tippe erneut auf einen Filter, um ihn zu entfernen, oder tippe auf **Filter löschen**, um beide zurückzusetzen.

## Aus einem Ergebnis installieren

Jedes Ergebnis zeigt den Namen des Pakets, welche Art von Ressource es ist, wer es erstellt hat und aus welchem Repository es stammt. Rechts in der Zeile gibt es eine Schaltfläche:

- **Installieren** — das Paket ist noch nicht auf deinem Gerät.
- **Aktualisieren** — eine neuere Version ist verfügbar. Die App bittet dich zuerst um Bestätigung, denn beim Aktualisieren wird die alte Kopie zusammen mit allen Notizen, Markierungen oder Lesezeichen entfernt, die darauf verweisen.
- **Öffnen** — das Paket ist bereits installiert; beim Antippen gelangst du zum Bildschirm, auf dem du es benutzt.

Tippe oben auf **Aktualisieren**, um die neueste Liste sofort von GitHub abzurufen. Die App aktualisiert die Liste von selbst einmal täglich; eine manuelle Aktualisierung ist nur nötig, wenn du weißt, dass etwas Neues veröffentlicht wurde.

## Suchen ohne Verbindung

Die App bewahrt eine Kopie der Liste auf deinem Gerät auf, sodass die Suche auch offline funktioniert. Kann die App GitHub nicht erreichen, um die Liste zu aktualisieren, weist dich ein Banner oben darauf hin, dass du die zwischengespeicherten Ergebnisse siehst.

## Wenn die Suche nichts findet

- Versuche es mit einem kürzeren, einzelnen Wort.
- Prüfe, ob noch ein **Autor**- oder **Tradition**-Filter aktiv ist — die Schaltfläche **Filter löschen** erscheint, sobald einer aktiv ist.
- Manche Repositories veröffentlichen ihre Pakete in einer anderen Sprache als der des Paketnamens; die Suche nach einem übersetzten Wort findet sie daher womöglich nicht.
