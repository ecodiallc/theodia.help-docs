---
title: Gelehrter Modus
level: advanced
categories: userMode
summary: Der Modus für ernsthaftes Bibelstudium mit Morphologie, Lexika, Kommentaren und KI.
---

# Gelehrter Modus

Der **Gelehrte**-Modus ist für Nutzer gedacht, die tiefer in die Bibel eintauchen möchten. Er zeigt alle Studienwerkzeuge auf einmal.

## Was aktiviert ist

Im Gelehrten-Modus hast du Zugriff auf:

- **Lexika** — griechische und hebräische Wortbedeutungen.
- **Kommentare** — mehrere Kommentare pro Vers.
- **Morphologie** — Wortformen der Originalsprachen.
- **Parallelstellen** — verwandte Bibelstellen.
- **Vergleichende Übersetzungen** — mehrere Bibelübersetzungen nebeneinander.
- **KI-Assistent** — tiefgehende Analysen und Fragen.
- **Theoscript** — die Skriptkonsole für erweiterte Abfragen.

## Benutzermodus wechseln

1. Öffne **Einstellungen**.
2. Tippe auf **App-Benutzermodus**.
3. Wähle **Gelehrter**.
4. Kehre zur App zurück. Neue Registerkarten und Werkzeuge erscheinen.

## Voraussetzungen

Damit alle Werkzeuge funktionieren, müssen die passenden Ressourcen installiert sein:

- Lexika: installiere über **Ressourcen verwalten → Lexika**.
- Kommentare: installiere über **Ressourcen verwalten → Kommentare**.
- Morphologie und MIB: lade die Kerndateien herunter. Siehe [Kerndateien installieren](theodia://help/installing-core-files).

## Lesen-Modus vs. Gelehrter Modus

Der **Lesen**-Modus versteckt fast alle Werkzeuge und zeigt nur Text. Der **Gelehrte**-Modus zeigt alles. Wenn du viel studierst, ist der Gelehrte-Modus schneller. Wenn du einfach nur lesen möchtest, ist der Lesen-Modus ruhiger.

## Für Anfänger

Der Gelehrte-Modus kann überwältigend wirken. Wenn du neu in der App bist, beginne mit dem **Standard**-Modus und schalte nach Bedarf Werkzeuge frei.

## Zusammenfassung

- Wechsle in **Einstellungen → App-Benutzermodus** zu **Gelehrter**.
- Installiere Lexika, Kommentare und Kerndateien für alle Werkzeuge.
- Nutze Morphologie, Parallelstellen, Vergleiche und KI im Studien-Modus.
