---
title: Die Bibel durchsuchen
level: everyday
categories: [study, read]
summary: So findest du Verse nach Wort, Phrase oder Bibelstelle.
---

# Die Bibel durchsuchen

Die Suchleiste hilft dir, Verse schnell zu finden. Du kannst nach einem Wort, einer Phrase oder einer Bibelstelle suchen.

## Wie du eine Suche startest

1. Tippe unten auf dem Bildschirm auf die **Suchen**-Registerkarte.
2. Tippe ein, wonach du suchst.
3. Tippe auf der Tastatur auf **Suchen**.

Die Ergebnisse erscheinen als Liste von Versen. Jedes Ergebnis zeigt Buch, Kapitel und Vers sowie den Text des Verses.

## Nach Wortkombinationen suchen

Wenn du mehr als ein Wort eingibst, zum Beispiel `love joy`, findet die App Verse, die **beide** Wörter enthalten. Das ist eine **UND**-Suche — alle Wörter müssen im Vers vorkommen. Sie verwendet **keine** **ODER**-Logik (Verse, die nur eines der Wörter enthalten).

Um Verse zu finden, die eines der Wörter enthalten, musst du das Schlüsselwort `OR` ausdrücklich benutzen: `love OR joy`.

## Nach einem Wort suchen

Tippe ein einzelnes Wort ein, zum Beispiel `love` oder `mercy`. Die App zeigt jeden Vers in der Bibel, der dieses Wort enthält.

## Nach einer Phrase suchen

Tippe zwei oder drei Wörter in Anführungszeichen ein, zum Beispiel `"do not be afraid"`. Die App zeigt Verse mit genau dieser Phrase.

## Die Ergebnisse eingrenzen

Nach einer Suche werden die Ergebnisse auf die Bibelübersetzungen gefiltert, die du installiert hast. Um weiter einzugrenzen, öffne die **Bibeln**-Registerkarte und sieh dir eine bestimmte Übersetzung an — die Suche läuft über die Übersetzungen, die du hast.

## Tipps für bessere Suchen

- Benutze kurze Wörter. Suchen nach `love` finden mehr Verse als Suchen nach `loving`.
- Anführungszeichen um eine Phrase machen die Suche exakt.
- Die App durchsucht nur die Bibelübersetzungen, die du installiert hast.
- Um mit einer Stellenangabe direkt zu einem bestimmten Vers zu springen (zum Beispiel `John 3:16`), benutze stattdessen den **Schnellbefehl** auf der Startseite.

## Suchverlauf

Die App merkt sich deine letzten Suchanfragen. Wenn du die **Suchen**-Registerkarte öffnest, erscheinen die letzten Suchanfragen oben in der Liste. Tippe auf eine, um sie erneut auszuführen. Um die Liste zu leeren, tippe bei den letzten Suchanfragen oben auf **Alles löschen**.

## PDFs durchsuchen

Die Registerkarte **Suchen** kann auch in deinen PDF-Dokumenten suchen:

1. Tippe auf die **Suchen**-Registerkarte und dann oben auf den **PDFs**-Modus.
2. Wähle aus, welche PDFs durchsucht werden sollen. Tippe auf ein PDF, um es einzuschließen oder auszuschließen; benutze **Alle** oder **Leeren** über der Liste, um alles einzuschließen oder von vorn zu beginnen. Nur PDFs, deren durchsuchbarer Text installiert ist, lassen sich auswählen.
3. Tippe ein, wonach du suchst, und tippe auf **Suchen**.

Jedes Ergebnis zeigt den Titel des PDFs, die Seitenzahl und einen Ausschnitt des passenden Texts. Tippe auf ein Ergebnis, um das PDF an dieser Seite zu öffnen.

Um innerhalb eines einzelnen PDFs zu suchen, während du es liest, benutze stattdessen die **Suchen**-Schaltfläche im PDF-Leser — siehe [PDFs](theodia://help/pdfs).
