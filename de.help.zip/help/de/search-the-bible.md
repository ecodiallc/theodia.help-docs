---
title: Die Bibel durchsuchen
level: beginner
categories: study
summary: Suche nach Wörtern, Phrasen, Strong-Nummern und Mehrfachbegriffen.
---

# Die Bibel durchsuchen

Theodia kann die installierten Bibelübersetzungen durchsuchen. Du kannst einfache und erweiterte Suchanfragen verwenden.

## Einfache Suche

1. Tippe unten auf die **Suchen**-Registerkarte.
2. Gib ein Wort oder eine Phrase in das Suchfeld ein.
3. Tippe auf **Suchen**.

Die App zeigt alle Verse, die deine Suchbegriffe enthalten.

## Suchergebnisse öffnen

Tippe auf ein Ergebnis, um das Kapitel zu öffnen. Deine Suchwörter werden im Text gelb hervorgehoben.

## Erweiterte Suche

Du kannst die Suche verfeinern:

- **Mehrere Wörter** — gib `Glaube Liebe` ein, um Verse mit beiden Wörtern zu finden.
- **Exakte Phrase** — gib `"Frieden sei mit dir"` ein, um genau diese Wortfolge zu finden.
- **Strong-Nummer** — gib `G2424` ein, um alle Stellen zu finden, an denen diese griechische Wortnummer vorkommt. Dafür muss die Strong-Nummern-Daten installiert sein.
- **Buch einschränken** — wähle vor der Suche eine Bibel oder ein Buch aus, um nur dort zu suchen.

## Filter

Auf der Suchergebnisseite kannst du filtern:

- Nach Bibelübersetzung.
- Nach Testament (Alt oder Neu).
- Nach Buch.

## Suchverlauf

Theodia speichert deine letzten Suchanfragen. Tippe auf das Suchfeld, um Vorschläge aus deinem Verlauf zu sehen.

## Tipp: Schnellbefehl

Auf der Startseite kannst du auch direkt einen Vers öffnen, anstatt zu suchen. Gib `Johannes 3,16` ein und tippe auf Los. Das ist schneller, wenn du bereits weißt, was du lesen möchtest.

## Zusammenfassung

- Verwende die **Suchen**-Registerkarte für einfache und erweiterte Suchanfragen.
- Tippe auf ein Ergebnis, um den Vers im Kontext zu lesen.
- Nutze Filter und Strong-Nummern, um präziser zu suchen.
