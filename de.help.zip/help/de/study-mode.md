---
title: Lesemodi
level: beginner
categories: read
summary: Studien- und Fokus-Modus im Bibelleser erklärt.
---

# Lesemodi

Der Bibelleser hat zwei Modi: **Studien-Modus** und **Fokus-Modus**. Sie ändern, welche Werkzeuge am Bildschirm sichtbar sind.

## Studien-Modus

Im Studien-Modus siehst du:

- Die obere Werkzeugleiste mit Kapitel-, Such- und Einstellungs-Icons.
- Die untere Werkzeugleiste mit **Lesezeichen**, **Markierungen**, **Notizen**, **Vergleich**, **Parallelstellen**, **KI** und mehr.
- Die Seitenleiste mit Lexikon-, Kommentar- und Morphologie-Informationen.

Dieser Modus ist nützlich, wenn du die Bibel studieren und viele Werkzeuge gleichzeitig nutzen möchtest.

## Fokus-Modus

Im Fokus-Modus verschwinden alle Werkzeuge. Du siehst nur:

- Die obere Leiste mit Buch- und Kapitelnamen.
- Den Bibeltext.

Dieser Modus ist nützlich, wenn du ablenkungsfrei lesen oder laut lesen möchtest.

## Zwischen den Modi wechseln

Während du im Leser bist:

- Tippe oben auf das Buch-Symbol (zum Beispiel **📖** oder **🖋️**, je nach aktuellem Modus).
- Oder wische nach unten, um die Modusauswahl zu öffnen, falls verfügbar.

## Lesen-Modus vs. die beiden Modi

Wenn du den **Lesen**-Benutzermodus wählst, ist der Leser immer im Fokus-Modus. Du kannst nicht in den Studien-Modus wechseln, außer du wechselst den Benutzermodus. Siehe [Benutzermodi](theodia://help/app-user-mode).

## Im Studien-Modus Werkzeuge ein-/ausblenden

Auch im Studien-Modus kannst du einzelne Seitenleisten oder Werkzeuge ausblenden, wenn du mehr Platz für den Text möchtest. Tippe auf das entsprechende Icon, um ein Werkzeug zu öffnen oder zu schließen.

## Zusammenfassung

- **Studien-Modus** zeigt alle Werkzeuge.
- **Fokus-Modus** zeigt nur den Text.
- Tippe oben auf das Buch-Symbol, um zu wechseln.
- Im Lesen-Modus bleibt der Leser immer im Fokus-Modus.
