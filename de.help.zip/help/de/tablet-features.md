---
title: Tablet-Funktionen
level: everyday
categories: [layout, tablet]
summary: Wie sich Theodias Layout an Tablets und größere Bildschirme anpasst — mit geteilten Ansichten, Seitenpanels und zweispaltigen Lesemodi.
---

# 📱 Tablet-Funktionen

Theodia ist darauf ausgelegt, die größeren Bildschirme von Tablets zu nutzen. Auf einem Tablet (oder einem beliebigen Gerät, das breiter als etwa 700 Pixel ist) schaltet die App an vielen Stellen automatisch auf ein zweispaltiges Layout um.

> **Modus:** Die hier beschriebenen Funktionen erscheinen nur, wenn dein aktueller Benutzermodus sie unterstützt. Zum Beispiel sind Kommentar-Seitenpanels und KI-Chat nur im Gelehrten-Modus verfügbar. Geteilte Ansichten für Lesezeichen, Markierungen und Notizen erfordern den Standard- oder Gelehrten-Modus. Der Fokus-Modus zeigt nur sauberes, einspaltiges Lesen. Du kannst die Modi unter **Einstellungen** → **App-Benutzermodus** wechseln.

## Vers-Menü im Leser

Wenn du auf eine Versnummer tippst (oder den Vers-Text lange gedrückt hältst), erscheint das **Vers-Menü** als **zentrierte Karte** über einem abgedunkelten Hintergrund.

- Die Schaltflächen **Kopieren** und **Teilen** sind oben im Menü immer sichtbar.
- **Lesezeichen** und **Markierungen** werden mit ihrem aktuellen Zustand angezeigt.
- **Kommentar**, **Wörterbuch** und **Vergleich** öffnen sich aus dem Menü. Auf einem Tablet erscheinen diese Werkzeuge nach der Auswahl in einem Seitenpanel oder einer breiten Karte.
- Tippe auf den Hintergrund oder auf den Schließen-Pfeil, um das Menü zu schließen.

## Kommentar-Panel zum Vers

Das **Kommentar**-Werkzeug öffnet auf einem Tablet ein **eigenes Seitenpanel**:

- Der Kommentar-Text erscheint neben dem Bibeltext.
- Du kannst den Kommentar unabhängig von der Bibel scrollen.
- Tippe auf das **X** oder wische es weg, um zu schließen.
- Ein **Buch-Symbol** oben im Panel lässt dich die Kommentar-Quelle wechseln.
- Ein **Kapitel-Symbol** zeigt dir den Kommentar zum ganzen Kapitel.

Auf einem Telefon öffnet sich der Kommentar als Vollbild-Dialog.

## Kapitelkommentar

Der **Kapitelkommentar** wird über die **Mehr**-Schaltfläche oben auf dem Bildschirm geöffnet, nicht über das Vers-Menü. Auf einem Tablet öffnet er sich als Seitenpanel genau wie der Vers-Kommentar, sodass du Kommentar und Bibeltext zusammen lesen kannst.

## Vergleichs-Registerkarte

Die **Vergleich**-Registerkarte (im Vers-Menü) öffnet sich auf einem Tablet als **Seitenpanel**. Sie zeigt den ausgewählten Vers in jeder Parallelübersetzung, die du aktiviert hast. Tippe auf eine Übersetzung, um im Leser zu dieser Stelle zu springen.

## Wörterbuch- / Strong-Popup

Das **Wörterbuch**-Werkzeug (Vers-Menü → Wörterbuch) öffnet sich auf einem Tablet als breite Karte. Es zeigt das griechische oder hebräische Wort, seine Umschrift, seine Definition und die Strong-Nummer. Tippe auf die **Konkordanz**-Schaltfläche, um jede Stelle zu sehen, an der dieses Wort in der Bibel vorkommt.

## Auf ein Wort tippen, um sein Lexikon zu öffnen

Im **Wortinformation**-Seitenpanel auf einem Tablet ist jede Wortkarte mit einer Strong-Nummer antippbar. Tippe auf die Karte, um das **Lexikon**-Panel direkt für dieses Wort zu öffnen. Das Lexikon-Panel ersetzt das Wortinformation-Panel, sodass du weiterstudieren kannst, ohne den Leser zu schließen.

Auf einem Telefon lassen sich Wortinformation-Karten nicht antippen, weil der Bildschirm zu klein für zwei Panels ist.

## Parallelbibeln nebeneinander

Tippe in den Einstellungen auf **Parallelbibeln** und wähle bis zu drei Übersetzungen. Auf einem Tablet erscheinen die Übersetzungen als **vertikale Paneele** nebeneinander:

- Jedes Paneel scrollt unabhängig.
- Du kannst auf eine Versnummer tippen, um ein Seitenpanel mit Werkzeugen zu öffnen.
- Die **Vergleich**-Registerkarte zeigt alle ausgewählten Verse an einem Ort.
- Tippe auf das **X** eines Paneels, um es zu schließen und zur einspaltigen Ansicht zurückzukehren.
- Tippe auf das **Parallelbibeln**-Symbol (🔵 / ⚪) in der oberen Symbolleiste, um die Parallelansicht ein- oder auszuschalten, ohne die Einstellungen zu öffnen.

Auf einem Telefon werden die Parallelübersetzungen nacheinander (untereinander) statt nebeneinander angezeigt. Dasselbe Umschalt-Symbol funktioniert auch auf Telefonen.

## Geteilte Ansicht für Lesezeichen und Markierungen

Auf einem Tablet verwenden die **Lesezeichen**- und **Markierungen**-Registerkarten ein Master-Detail-Layout:

- **Links** — die Liste der Lesezeichen bzw. Markierungen.
- **Rechts** — tippst du einen Eintrag an, öffnet sich ein Vorschaupanel mit dem Vers- oder Abschnittstext.

Du kannst deine gespeicherten Einträge überfliegen und sie in der Vorschau ansehen, ohne die Registerkarte zu verlassen. Auf einem Telefon navigiert das Antippen eines Eintrags zum Leser-Bildschirm.

## Geteilte Ansicht für Notizen

Die **Notizen**-Registerkarte zeigt auf einem Tablet links deine Notizliste und rechts die ausgewählte Notiz. Tippst du eine Notiz an, öffnet sie sich in einem Seitenpanel, sodass du mehrere Notizen hintereinander überfliegen kannst, ohne die Liste zu verlassen. Auch das Erstellen oder Bearbeiten einer Notiz nutzt ein Seitenpanel.

## Geteilte Ansicht für die Suche

Auf einem Tablet zeigt die **Suchen**-Registerkarte links das Suchformular und rechts die Ergebnisse, sobald du eine Suche ausführst. Du kannst deine Abfrage verfeinern und zusehen, wie sich die Ergebnisse aktualisieren, ohne den Bildschirm zu wechseln. Auf einem Telefon öffnen sich Suchergebnisse auf einem separaten Bildschirm.

## Kategorienleiste in den Einstellungen

Der **Einstellungen**-Bildschirm zeigt auf einem Tablet links eine Kategorienliste (KI, Erscheinungsbild, Sicherung, Bibeln usw.). Tippe auf eine Kategorie, um rechts direkt zu ihren Einstellungen zu springen. Nur die ausgewählte Kategorie ist ausgeklappt, sodass du nie durch die gesamte Einstellungsliste scrollen musst.

## Bibel-Navigation auf Tablets

Die Bildschirme **Bibel-Liste**, **Bibel-Bücher** und **Bibel-Kapitel** bleiben auf Tablets einspaltig, verwenden aber größere Tastziele, breitere Raster und großzügigere Abstände, damit sich der Inhalt leichter lesen und antippen lässt. Sie verwenden kein geteiltes Layout, weil jeder Schritt die volle Breite braucht, um seine Liste oder sein Raster klar zu zeigen.

## Querformat und Hochformat

Drehst du das Tablet, passt sich das Layout automatisch an. Im **Querformat** haben Seitenpanels viel Platz. Im **Hochformat** werden die Panels schmaler, bleiben aber neben dem Text.

## KI-Chat zum ausgewählten Vers

Der **KI**-Chat öffnet sich im Seitenpanel des Vers-Menüs. Er zeigt eine Chat-Oberfläche, in der du Fragen zum ausgewählten Vers stellen kannst. Die KI-Antwort erscheint im Panel, und du kannst das Gespräch fortsetzen, ohne den Leser zu verlassen.

## Gesprächs-Seitenleiste im KI-Bildschirm

In der **KI**-Registerkarte auf einem Tablet ist die Gesprächsliste immer als dauerhafte linke Seitenleiste sichtbar. Du kannst zwischen Chats wechseln, ohne ein Menü zu öffnen. Die Schaltfläche **Neuer Chat** ist ebenfalls immer sichtbar. Auf einem Telefon erscheint die Gesprächsliste als eingeblendetes Menü am Rand.

## Was gleich bleibt

Nicht jeder Bildschirm teilt sich in zwei Paneele. Die folgenden Bildschirme bleiben auf Tablets einspaltig:

- **Bibel-Liste** — Liste der Bibelübersetzungen (volle Breite)
- **Bibel-Bücher** — Bücher-Raster und Abschnitte (volle Breite)
- **Bibel-Kapitel** — Kapitel-Raster (volle Breite)
- **PDFs** — die PDF-Bibliothek nutzt ein breiteres Karten-Raster (volle Breite)
- **Einstellungen** — einzelne Einstellungsseiten (volle Breite)
- **Hilfe** — Hilfe-Artikel (volle Breite)

## Zusammenfassung

Auf einem Tablet bekommst du:

- **Parallelbibeln** in nebeneinanderliegenden vertikalen Paneelen
- **Kommentar** in dauerhaften Seitenpanels
- **Vergleich** und **Wörterbuch** in breiten Karten
- **Lexikon** per Tipp auf jede Wortinformation-Karte
- **Lesezeichen, Markierungen, Notizen, Andachten, Bücher, Einstellungen** in Master-Detail-Geteilten-Ansichten
- **Suchen** mit Ergebnissen direkt neben dem Suchformular
- **Querformat** und **Hochformat**, beide unterstützt, mit automatischen Layout-Änderungen

Auf einem Telefon verwendet alles die klassische einspaltige Schritt-für-Schritt-Navigation. Die App erkennt die Bildschirmbreite beim Start und wählt automatisch das passende Layout.
