---
title: Tablet-Funktionen
level: everyday
categories: tablet
summary: Besondere Layouts und Gesten für größere Bildschirme wie iPads und Android-Tablets.
---

# Tablet-Funktionen

Theodia unterstützt größere Bildschirme wie iPads und Android-Tablets. Auf Tablets gibt es zusätzliche Layouts und Gesten, die das Studium erleichtern.

## Geteilte Ansicht

Auf Tablets kannst du zwei Bereiche nebeneinander öffnen:

- Links die Bibel, rechts ein Kommentar.
- Links die Bibel, rechts die Suchergebnisse.
- Links ein Buch, rechts die Bibel.

Wenn die App die geteilte Ansicht unterstützt, erscheint am oberen Rand ein Symbol zum Aktivieren.

## Mehr Platz für Werkzeuge

Im Studien-Modus bleiben die Werkzeugleisten und Seitenleisten auf Tablets offen, ohne den Text zu sehr zu verkleinern. Du siehst mehr Informationen gleichzeitig.

## Gesten

- Mit zwei Fingern zoomen, um die Schriftgröße zu ändern.
- In der geteilten Ansicht die Trennlinie verschieben, um die Bereiche anzupassen.
- Wische weiterhin links/rechts, um Kapitel zu wechseln.

## Externe Tastatur

Wenn du eine Bluetooth-Tastatur verwendest, findest du eine Liste der Tastaturkürzel im Leitfaden [Tastaturkürzel](theodia://help/external-keyboard-shortcuts).

## Vollbild

Tippe oben auf das Vollbild-Symbol, um die obere und untere Systemleiste auszublenden und mehr Text zu sehen. Tippe erneut, um zurückzukehren.

## Zusammenfassung

- Tablets bieten geteilte Ansichten und mehr Platz für Werkzeuge.
- Verwende Gesten zum Zoomen und Anpassen.
- Nutze eine externe Tastatur für schnelle Navigation.
