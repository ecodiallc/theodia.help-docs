---
title: Designs und Schriftarten
level: beginner
categories: settings
summary: App-Aussehen, Lesefarben, Schriftarten und Schriftgrößen ändern.
---

# Designs und Schriftarten

Du kannst das Erscheinungsbild von Theodia nach deinem Geschmack anpassen.

## Helles und dunkles Design

1. Öffne **Einstellungen**.
2. Tippe auf **Erscheinungsbild**.
3. Wähle **Hell**, **Dunkel** oder **System**.

Wenn du **System** wählst, folgt die App der Einstellung deines Geräts.

## Schriftgröße

1. Öffne **Einstellungen → Erscheinungsbild**.
2. Tippe auf **Schriftgröße**.
3. Bewege den Regler.

Diese Einstellung gilt für Bibeltext, Bücher und Hilfeseiten.

## Schriftart

Auf dem gleichen Bildschirm kannst du eine Schriftart auswählen. Theodia bietet mehrere serifenlose und serifenbetonte Schriften.

## Lesefarben

Im Bibelleser kannst du die Hintergrund- und Textfarben anpassen:

1. Tippe beim Lesen auf das Einstellungs-Symbol in der Werkzeugleiste.
2. Wähle ein Farbschema wie **Sepia**, **Schwarz auf Weiß** oder **Dunkel**.

## Zeilenabstand

Auf dem Erscheinungsbild-Bildschirm kannst du den Zeilenabstand erhöhen, wenn du mehr Luft zwischen den Zeilen möchtest.

## Text-Richtung

Hebräische Bibeln werden automatisch rechts-nach-links dargestellt. Die Richtung hängt von der gewählten Bibel ab und muss nicht extra eingestellt werden.

## Zurücksetzen

Wenn du die Anpassungen rückgängig machen möchtest, tippe auf **Auf Standard zurücksetzen** in den Erscheinungsbild-Einstellungen.

## Zusammenfassung

- Gehe zu **Einstellungen → Erscheinungsbild**.
- Wähle hell/dunkel, Schriftart, Größe und Farben.
- Passe Zeilenabstand und Lesefarben direkt im Leser an.
