---
title: Theodia-Funktionen
level: beginner
categories: welcome
summary: Ein kurzer Überblick darüber, was Theodia besonders macht und wie es dir beim Bibelstudium hilft.
---

# Theodia-Funktionen

Theodia ist als kompletter Begleiter fürs Bibelstudium gebaut. Das macht es besonders.

## Vollständig offline

Alles funktioniert ohne Internet. Bibeln, Kommentare, Lexika, Bücher und Andachten sind auf deinem Gerät gespeichert. Du kannst überall lesen, suchen und studieren — im Flugzeug, in abgelegenen Gegenden oder an jedem Ort ohne Empfang.

## Datenschutz im Fokus

Deine Daten bleiben bei dir. Notizen, Markierungen, Lesezeichen und Leseverlauf werden lokal auf deinem Gerät gespeichert. Kein Konto ist nötig, und nichts wird an einen Server geschickt, es sei denn, du entscheidest dich für den optionalen KI-Assistenten.

## Tablet-Unterstützung

Theodia ist für Telefone und Tablets ausgelegt. Auf einem größeren Bildschirm bekommst du mehr Platz zum Lesen, parallele Bibelansichten und ein Layout, das den zusätzlichen Raum nutzt.

## Installierbare Ressourcen

Du bist nicht auf das beschränkt, was mit der App kommt. Du kannst weitere Bibelübersetzungen, Kommentare, Lexika, Bücher und Andachten hinzufügen. Ressourcen gibt es auf der GitHub-Seite des Projekts, und sie lassen sich direkt in die App installieren.

## KI-Assistent

Der optionale KI-Assistent hilft dir, Verse zu verstehen, den Zusammenhang zu erklären und Fragen zu beantworten. Er ist nur aktiv, wenn du ihn einschaltest. Standardmäßig verbindet er sich mit einem entfernten Modell, das du über einen Endpunkt und einen API-Schlüssel konfigurierst, die du selbst angibst. Beim ersten Gebrauch fragt die App um deine Erlaubnis und zeigt genau, was gesendet wird.

## Parallelbibeln lesen

Lies bis zu vier Bibelübersetzungen gleichzeitig. Wenn du ein Kapitel öffnest, erscheint deine Hauptübersetzung zuerst, und auf jeden Vers folgt derselbe Vers in deinen gewählten Parallelübersetzungen. Vergleiche Formulierungen, studiere Unterschiede und gewinne ein vollständigeres Bild vom Text. Speichere deine Lieblingskombinationen als Voreinstellungen und wechsle schnell zwischen ihnen.

## Volltextsuche

Durchsuche jede Bibelübersetzung. Suche nach Wörtern, Phrasen oder Teiltreffern. Du kannst die Suche auch auf einen Bereich von Büchern beschränken.

## Parallelstellen

Tippe auf eine Stellenangabe, um direkt zu dieser Passage zu springen. Parallelstellen sind eingebaut und funktionieren in der ganzen Bibel.

## Lexikon und Strong-Nummern

Tippe auf eine Strong-Nummer, um die Definition des ursprünglichen griechischen oder hebräischen Wortes zu sehen. Lexikon-Einträge sind für vertieftes Wortstudium enthalten.

## Lesezeichen und Markierungen

Speichere Verse mit Lesezeichen und markiere sie mit Farben. Alles wird lokal gespeichert und bleibt zwischen Sitzungen erhalten.

## Notizen

Schreibe deine eigenen Gedanken zu jedem Vers. Notizen sind mit dem Vers verknüpft und lassen sich später leicht wiederfinden.

## Tägliche Andacht

Starte den Tag mit einer kurzen Andacht. Die App enthält Andachten, die automatisch zum heutigen Eintrag öffnen.

## Christliche Bücher

Lies klassische christliche Literatur in der App. Bücher sind für einfaches Lesen formatiert und enthalten ein Inhaltsverzeichnis für schnelle Navigation.

## PDFs lesen

Importiere eigene PDF-Dokumente und lies sie offline, geordnet in Kategorien. Der Leser unterstützt Suche, ein Inhaltsverzeichnis, Lesezeichen, Zoom und lautes Vorlesen. Du kannst auch gepackte PDF-Sammlungen aus dem Community-Repository installieren.

## Mehrere Sprachen

Theodia unterstützt viele Sprachen — sowohl für die App-Oberfläche als auch für Bibelinhalte. Wechsle die Sprache in den Einstellungen, um in deiner bevorzugten Sprache zu studieren.

## Dunkelmodus und Designs

Wähle hellen oder dunklen Modus oder ein Design nach deinem Geschmack. Lesekomfort zählt, besonders bei wenig Licht.

## Datensicherung

Sichere deine Notizen, Lesezeichen und Markierungen. Halte deine Daten sicher und zieh bei Bedarf auf ein neues Gerät um.

## Keine Werbung, keine Ablenkungen

Theodia ist für Konzentration gebaut. Es gibt keine Werbung, keine Pop-ups und keine Unterbrechungen. Nur der Text und deine Studienwerkzeuge.
