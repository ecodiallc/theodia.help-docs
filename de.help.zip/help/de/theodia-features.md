---
title: Theodia-Funktionen
level: beginner
categories: welcome
summary: Eine Kurzübersicht der Hauptfunktionen der Theodia Bible App.
---

# Theodia-Funktionen

Theodia ist eine Offline-Bibel-App, die viele Werkzeuge für Lesen, Studieren, Beten und Zuhören bietet.

## Was du hier tun kannst

- **Die Bibel lesen** — offline, in vielen Übersetzungen.
- **Suchen** — Wörter, Phrasen und Strong-Nummern durchsuchen.
- **Studieren** — Lexika, Kommentare, Morphologie und Parallelstellen nutzen.
- **Vergleichen** — mehrere Übersetzungen nebeneinander lesen.
- **Markieren und speichern** — Lesezeichen, Markierungen und Notizen zu Versen.
- **Zuhören** — Bibelkapitel und Wiedergabelisten mit Sprachausgabe anhören.
- **Beten** — Routinen, Ziele, Erinnerungen und Statistiken.
- **Anpassen** — Designs, Schriftarten, Sprache und Benutzermodus.
- **Erweitern** — Plugins und eigene Ressourcen hinzufügen.

## Offline-First

Die meisten Funktionen funktionieren, sobald die Ressourcen einmal heruntergeladen sind, ohne Internet. Nur der KI-Assistent und einige Plugin-Funktionen brauchen gelegentlich eine Verbindung.

## Starten

Wenn du neu bist, beginne mit dem Leitfaden [Willkommen](theodia://help/welcome).

## Zusammenfassung

Theodia vereint Lesen, Studieren, Beten und Zuhören in einer offline-fähigen App.
