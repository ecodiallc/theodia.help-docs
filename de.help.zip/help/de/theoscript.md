---
title: Theoscript
level: advanced
categories: theoscript
summary: Die Theoscript-Konsole für erweiterte Abfragen und Automatisierungen in Theodia.
---

# Theoscript

Theoscript ist eine Skriptkonsole für erfahrene Nutzer. Damit kannst du direkt mit den Daten der App arbeiten, Abfragen ausführen und kleine Automatisierungen erstellen.

> Hinweis: Theoscript ist experimentell. Falsche Befehle können die App zum Absturz bringen oder Daten verändern.

## Theoscript öffnen

1. Öffne **Einstellungen**.
2. Tippe auf **Theoscript**.

Wenn der Menüeintrag fehlt, ist der Gelehrte-Modus oder Theoscript in deinem Benutzermodus ausgeblendet. Siehe [Benutzermodi](theodia://help/app-user-mode).

## Was du damit tun kannst

- Bibeltext, Kommentare und Lexika abfragen.
- Eigene Berechnungen über Bibeldaten ausführen.
- Daten ausgeben und kopieren.
- Kleinere Automatisierungen schreiben.

## Erste Schritte

In der Konsole gibst du JavaScript-ähnliche Befehle ein. Beispiel:

```js
bibleApi.getVerses('KJV', 'John', 3, 16);
```

Dieser Befehl gibt Johannes 3,16 in der KJV-Übersetzung zurück.

## Verfügbare Objekte

- `bibleApi` — alle Funktionen der Bibel-API.
- `db` — direkter Zugriff auf SQLite-Datenbanken.
- `storage` — App-Speicher lesen und schreiben.
- `ui` — kurze Benachrichtigungen anzeigen.

## Ergebnisse speichern

Wenn du ein Ergebnis kopieren möchtest:

1. Tippe auf das Ergebnis.
2. Tippe auf **Kopieren**.

## Beispiel: Alle Verse mit einem Wort finden

```js
const result = await bibleApi.search('KJV', 'faith');
ui.toast(`Gefunden: ${result.data.length}`);
```

## Fehlerbehebung

- **Befehl nicht erkannt** — prüfe die Schreibweise und die verfügbaren Objekte.
- **Keine Daten** — stelle sicher, dass die benötigte Ressource installiert ist.
- **App reagiert nicht** — ein Befehl kann zu viel Arbeit verursacht haben. Schließe die App und öffne sie neu.

## Zusammenfassung

- Theoscript ist eine erweiterte Konsole im Gelehrten-Modus.
- Du kannst `bibleApi`, `db`, `storage` und `ui` verwenden.
- Speichere Ergebnisse durch Kopieren.
- Vorsicht bei Befehlen, die Daten verändern.
