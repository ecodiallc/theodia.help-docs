---
title: Laut vorlesen (Sprachausgabe)
level: everyday
categories: tts
summary: Lass Theodia die Bibel oder eine Andacht laut vorlesen. Wie du es benutzt, wie du eine Stimme wählst und was zu tun ist, wenn es still bleibt.
---

# Laut vorlesen (Sprachausgabe)

> **Modus:** Die Sprachausgabe ist im **Standard**- und **Gelehrten**-Modus verfügbar. Der Fokus-Modus ist nur für sauberes, ablenkungsfreies Lesen. Du kannst die Modi unter **Einstellungen** → **App-Benutzermodus** wechseln.

Theodia kann Text mit der Sprachausgabe (TTS) deines Geräts laut vorlesen. Du kannst einen einzelnen Vers, ein ganzes Kapitel oder eine Andacht anhören. Das ist nützlich fürs Lesen ohne Hände, zum Zuhören beim Spazierengehen oder Pendeln, um beim Zuhören mitzulesen oder um deinen Augen eine Pause zu gönnen.

## Wo die Vorlesen-Schaltfläche ist

Du findest eine Vorlesen-Schaltfläche an drei Stellen.

### 1. Im Vers-Menü (einzelner Vers)

Das ist der schnellste Weg, einen Vers nach dem anderen anzuhören. Öffne ein Kapitel im [Studien-Modus](theodia://help/study-mode), tippe auf einen Vers, um das Vers-Menü zu öffnen, und tippe dann auf **Vorlesen** (🔊). Das Vorlesen beginnt an diesem Vers. Unten auf dem Bildschirm erscheint eine kleine Steuerleiste mit Wiedergabe, Pause, Zurückspulen, Vorspulen und einer Stimmenauswahl.

Die Vorlesen-Option wird bei interlinearen Bibeln nicht angezeigt (MIB — Marvel Interlinear Bible — und OHGB), weil sie Wörter in einem anderen Layout zeigen, das sich nicht natürlich vorlesen lässt.

### 2. Oben am Kapitel (ganzes Kapitel)

Wenn du ein Kapitel liest, sieh dir die Icon-Leiste oben auf dem Bildschirm an. Tippe auf **Vorlesen** (🔊), um das ganze Kapitel von vorn vorlesen zu lassen. Während die Audiowiedergabe läuft, wird die Schaltfläche zur Stopp-Schaltfläche (⏹). Tippe erneut, um zu stoppen. Dieselbe Steuerleiste erscheint unten.

Du kannst zu einem anderen Vers springen — die Vorlesen-Schaltfläche dort startet dann an diesem Vers.

### 3. In einer Andacht

Öffne einen beliebigen Andachtstag und tippe über der Lesung auf die **Vorlesen**-Schaltfläche (🔊). Der ganze Andachtstext wird Satz für Satz vorgelesen. Eine Steuerleiste unten bietet Wiedergabe, Pause, Zurückspulen und Stimmensteuerung.

## Die Steuerleiste benutzen

Während Audio läuft, bleibt unten auf dem Bildschirm eine kleine Leiste sichtbar. Sie hat sechs Bedienelemente:

- ⏪ **Zurückspulen** — einen Vers zurück (oder einen Satz bei einer Andacht)
- ⏸ **Pause / ▶ Fortsetzen** — pausieren, ohne deine Stelle zu verlieren. Nochmal tippen, um an derselben Stelle weiterzumachen.
- ⏩ **Vorspulen** — zum nächsten Vers springen (oder zum nächsten Satz bei einer Andacht)
- 🎙 **Stimme** — die Stimmenauswahl öffnen, ohne das Kapitel zu verlassen (siehe unten)
- ⚙ **Optionen** — das erweiterte Optionspanel öffnen (siehe unten)
- **Stopp** — tippe auf die 🔊-Schaltfläche oben auf dem Bildschirm oder auf das ⏹, das sie während der Wiedergabe ersetzt, um zu stoppen und die Leiste zu schließen.

Die Steuerleiste schließt sich, wenn das Kapitel zu Ende ist oder wenn du auf Stopp tippst.

### Erweiterte Optionen

Tippe auf ⚙, um zusätzliche Wiedergabeoptionen einzublenden. Diese Einstellungen gelten nur für das aktuelle Kapitel und werden zurückgesetzt, wenn du das Kapitel wechselst oder das Zuhören beendest.

- ⏮ **Zum Anfang** — springt zum ersten Vers des gesetzten Bereichs.
- **Anfang** — tippe eine Versnummer ein, um festzulegen, wo das Vorlesen beginnt.
- **Ende** — tippe eine Versnummer ein, um festzulegen, wo das Vorlesen aufhört.
- **Alle** — setzt den Bereich auf das ganze Kapitel zurück.
- **()** — legt fest, ob Klammerausdrücke (Text in Klammern) vorgelesen werden.
- 🔁 **Wiederholen** — startet am Ende automatisch wieder am Anfang des Bereichs, mit einer kurzen Pause dazwischen. Schaltest du das ein, ohne einen Anfangs- oder Endvers zu setzen, wiederholt sich das ganze Kapitel.

### In den Gebetsbildschirmen

Bekenntnisse und feste Gebete, erzeugte Gebete und Gebetsroutinen haben ihre eigenen erweiterten Optionen. Tippe in der Steuerleiste auf ⚙, um sie einzublenden:

- **Geschwindigkeit** — tippe auf die Geschwindigkeitsangabe (zum Beispiel `1x`), um eine Lesegeschwindigkeit von 0,1x bis 1,5x zu wählen. Deine Wahl wird gemerkt und beim nächsten Vorlesen verwendet.
- **()** — legt fest, ob Text in Klammern vorgelesen wird.
- 🔁 **Wiederholen** — startet das Gebet am Ende automatisch wieder von vorn, mit einer kurzen Pause dazwischen. Das ist nützlich, um ein Bekenntnis oder ein festes Gebet auswendig zu lernen.

Eine Geschwindigkeitsänderung wirkt sofort, ohne dass du deine Stelle verlierst. Das Ein- oder Ausschalten der Klammeroption beginnt das Gebet von vorn, damit die Änderung von Anfang an zu hören ist.

## Wie du die Stimme änderst

Du kannst wählen, welche Stimme Theodia zum Vorlesen benutzt. Das ist nützlich, wenn du einen anderen Akzent, eine andere Sprache oder eine schnellere oder langsamere Stimme als die Standardstimme des Geräts möchtest.

1. Öffne die **Einstellungen**.
2. Suche den Bereich **Sprachausgabe**.
3. Tippe auf **Stimme auswählen**.
4. Eine Liste der Stimmen erscheint. Die erste Zeile, **Systemstandard**, benutzt die Stimme, die dein Gerät bevorzugt. Wähle eine andere Zeile, um sie zur neuen Standardstimme zu machen.
5. Deine Wahl wird gespeichert und beim nächsten Tippen auf **Vorlesen** verwendet.

Du kannst auch auf das 🎙-Symbol in der Steuerleiste tippen, um dieselbe Auswahl zu öffnen, ohne das Kapitel zu verlassen.

Welche Stimmen verfügbar sind, hängt ganz von deinem Gerät ab. iOS und Android bringen jeweils eine Reihe eingebauter Stimmen mit. Weitere Stimmen kannst du in den Einstellungen **Barrierefreiheit** oder **Sprache & Eingabe** deines Geräts installieren. Theodia kann jede auf deinem Gerät installierte Stimme benutzen.

## Lieblingsstimmen

Wenn dein Gerät viele Stimmen hat, ist das Durchblättern der ganzen Liste jedes Mal mühsam. Du kannst eine kurze Liste **Lieblingsstimmen** anlegen, und die Stimmenauswahlfelder zeigen dann nur diese Stimmen.

1. Öffne die **Einstellungen**.
2. Suche den Bereich **Sprachausgabe**.
3. Tippe auf **Lieblingsstimmen** (die erste Zeile oben im Bereich).
4. Tippe auf **Lieblingsstimmen festlegen**, um den Lieblingsstimmen-Bildschirm zu öffnen.
5. Tippe auf die Wiedergabe-Schaltfläche neben einer Stimme, um sie anzuhören. Tippe auf den Stern, um sie zu deinen Lieblingen hinzuzufügen. Du kannst so viele Stimmen favorisieren, wie du magst.
6. Gehe zurück. Die Stimmenauswahlfelder in Theodia zeigen jetzt nur noch deine Lieblingsstimmen.

Wenn du alle Lieblinge entfernst, zeigen die Auswahlfelder wieder alle Stimmen. Lieblingsstimmen sind in Sicherung und Wiederherstellung der Theodia-Einstellungen enthalten.

## Für jede Bibel eine andere Stimme

Du kannst jeder Bibelübersetzung ihre eigene Stimme geben. Das ist nützlich, wenn du zwischen Übersetzungen wechselst, die sich sehr unterschiedlich anhören — zum Beispiel eine formellere Stimme für die King James Version und eine gesprächigere Stimme für eine moderne Übersetzung wie die NIV oder NLT. Es hilft auch, wenn du Bibeln in verschiedenen Sprachen anhörst und jede im richtigen Akzent gesprochen werden soll.

1. Öffne die **Einstellungen**.
2. Suche den Bereich **Sprachausgabe**.
3. Suche **Bibel-Stimmen**.
4. Tippe auf eine beliebige Bibel in der Liste.
5. Wähle die Stimme für diese Übersetzung. Die erste Zeile, **Systemstandard**, benutzt deine Hauptstimme der Sprachausgabe für diese Bibel.
6. Wiederhole das für jede weitere Bibel.

Der Kopfbereich zeigt, wie viele Bibelübersetzungen eine eigene Stimme haben. **Stimme auswählen**, **Kommentar-Stimme**, **Bibelnotizen-Stimme** und **Andachten-Stimme** zeigen ebenfalls eine Zahl, wenn eine Stimme gesetzt ist.

Wenn du das nächste Mal ein Kapitel aus dieser Bibel anhörst, benutzt Theodia die gewählte Stimme. Alle anderen Bibeln behalten die Standardstimme, es sei denn, du änderst auch sie.

## Sprachausgabe im Hintergrund fortsetzen

Standardmäßig stoppt Theodia die Sprachausgabe, wenn du den Leser verlässt, zu einer anderen App wechselst oder dein Telefon sperrst. So gibt es keine unerwartete Audiowiedergabe, wenn du nicht mehr aktiv liest.

Damit die Sprachausgabe im Hintergrund weiterläuft:

1. Öffne die **Einstellungen**.
2. Suche den Bereich **Sprachausgabe**.
3. Schalte **Sprachausgabe im Hintergrund fortsetzen** ein.

Ist das eingeschaltet, kannst du Registerkarten wechseln, eine andere App öffnen oder den Bildschirm sperren, und das Kapitel oder die Andacht liest weiter vor. Die Steuerleiste bleibt aktiv, sodass du über den Benachrichtigungsbereich pausieren oder überspringen kannst (wenn dein Gerät das unterstützt).

Schaltest du diese Option **aus**, während die Sprachausgabe bereits läuft, stoppt sie sofort.

## Was zu tun ist, wenn es nicht funktioniert

Die Sprachausgabe hängt von deinem Gerät ab. Theodia übergibt den Text an das Betriebssystem, und das Betriebssystem liest ihn mit einer Stimme laut vor. Wenn es nicht funktioniert, probiere diese Schritte der Reihe nach.

### Theodia sagt, dass TTS nicht verfügbar ist

Manche Geräte haben gar keine TTS. Öffne die **Einstellungen** und suche den **TTS**-Bereich. Fehlt der Bereich, unterstützt dein Gerät in dieser Version kein TTS.

### Die Stimmenliste ist leer

Die Stimmenauswahl zeigt vielleicht „keine Stimmen gefunden“. Das bedeutet meist, dass das Gerät das Laden seiner Stimmen noch nicht abgeschlossen hat.

1. Öffne **Einstellungen → Sprachausgabe → Stimme auswählen**.
2. Ist die Liste leer, suche eine **Erneut testen**-Schaltfläche direkt unter dem Auswahlfeld. Tippe darauf. Theodia fragt das Gerät erneut nach Stimmen ab.
3. Ist sie immer noch leer, prüfe die Systemeinstellungen deines Geräts. Öffne auf iOS **Einstellungen → Barrierefreiheit → Gesprochene Inhalte → Stimmen** und lade eine Stimme für deine Sprache herunter. Öffne auf Android **Einstellungen → Sprache & Eingabe → Text-to-Speech-Ausgabe** und tippe auf **Sprachdaten installieren**.
4. Schließe Theodia und öffne es wieder, damit es die neue Stimme übernimmt.

Hast du Lieblingsstimmen gesetzt und die Liste ist leer, stelle sicher, dass mindestens einer deiner Lieblinge zu einer auf diesem Gerät installierten Stimme passt.

### Du tippst auf Vorlesen, aber nichts passiert

- Prüfe, ob sich das Gerät nicht im lautlosen Modus befindet. Die meisten Geräte geben im lautlosen Modus keine TTS-Audios wieder.
- Stelle sicher, dass die Lautstärke des Geräts aufgedreht ist.
- Probiere die **Erneut testen**-Schaltfläche unter **Einstellungen → Sprachausgabe**.
- Öffne die **Einstellungen** und sieh dir den **System**-Bereich unten an. Die **TTS**-Zeile sollte **Verfügbar** zeigen. Steht dort **Nicht verfügbar**, ist TTS auf Betriebssystemebene ausgeschaltet. Aktiviere es dort und öffne Theodia erneut.

### Audio läuft, aber in der falschen Sprache

Theodia sendet den Text in der Sprache des aktuellen Inhalts und bittet das Gerät um die von dir gewählte Stimme. Ist die gewählte Stimme für eine andere Sprache, liest das Gerät den Text vielleicht trotzdem, aber es klingt seltsam.

1. Öffne **Einstellungen → Sprachausgabe → Stimme auswählen**.
2. Wähle **Systemstandard**, damit das Gerät die richtige Stimme wählt, oder wähle eine Stimme, deren Sprache zum Text passt, den du liest.

Theodia liest derzeit keine griechischen oder hebräischen interlinearen Bibeln laut vor. Die Vorlesen-Schaltflächen sind bei diesen Übersetzungen ausgeblendet.

### Audio läuft, aber hört zu früh auf

Fehlt ein Vers oder ist er unlesbar, springt das Kapitel zum nächsten. Schließt sich die Leiste nach ein paar Versen von selbst, tippe oben auf dem Bildschirm auf die **Vorlesen**-Schaltfläche (🔊), um von vorn zu beginnen.

### Die Sprachausgabe läuft, aber ich weiß nicht, wo sie gestartet ist

Hast du **Sprachausgabe im Hintergrund fortsetzen** eingeschaltet und hörst später Audio, findest aber den Bildschirm nicht, auf dem es gestartet ist, kannst du es von jeder Stelle in der App stoppen.

1. Öffne die **Einstellungen**.
2. Suche den Bereich **Sprachausgabe**.
3. Tippe unten im Bereich auf die rote **Sprachausgabe stoppen**-Schaltfläche.

Das stoppt sofort jede laufende Sprachausgabe in Theodia. Du kannst auch den App-Wechsler deines Geräts öffnen und Theodia wegwischen, um die Audioausgabe gewaltsam zu beenden.

### Es liest zu schnell oder zu langsam

Theodia steuert die Lesegeschwindigkeit nicht. Die Geschwindigkeit legt die gewählte Stimme fest. So änderst du sie:

- Auf iOS: **Einstellungen → Barrierefreiheit → Gesprochene Inhalte → Sprechgeschwindigkeit**.
- Auf Android: **Einstellungen → Sprache & Eingabe → Text-to-Speech-Ausgabe → Sprechgeschwindigkeit**.

## Tipps

- Die Steuerleiste bleibt sichtbar, während du zwischen Kapiteln navigierst, sodass du pausieren, überspringen oder die Stimme wechseln kannst, ohne deine Stelle zu verlieren.
- Theodia liest Versnummern als kleine Pausen. Du kannst die Leiste stoppen, zu einem anderen Vers wischen und dann auf Wiedergabe tippen, um dort weiterzumachen.
- Für langes Zuhören schalte **Nicht stören** ein, damit Benachrichtigungen die Wiedergabe nicht unterbrechen.
- Die 🔊-Schaltfläche benutzt die aktuelle Lautstärke deines Geräts. Steckst du Kopfhörer an, wechselt die Lautstärke auf den Kopfhörer-Pegel.

## Ein PDF vorlesen lassen

Theodia kann auch PDF-Seiten laut vorlesen. Öffne ein PDF und tippe in seiner Werkzeugleiste auf die **Vorlesen**-Schaltfläche (Lautsprecher). Es erscheint eine Steuerleiste mit Wiedergabe/Pause, Zurückspulen, Vorspulen, Stopp, einer Fortschrittsleiste, auf die du tippen kannst, um innerhalb der Seite zu springen, sowie der Auswahl von Geschwindigkeit und Stimme. Ist eine Seite fertig, liest die Sprachausgabe automatisch auf der nächsten Seite weiter.

Das Vorlesen von PDFs nutzt den installierten durchsuchbaren Text des PDFs und dieselben Stimmen und dieselbe Geschwindigkeit wie beim Bibelvorlesen.

## Verwandte Leitfäden

- Der Leitfaden [Studien-Modus](theodia://help/study-mode) erklärt das Vers-Menü und die Schaltflächen oben auf dem Bildschirm ausführlicher.
- Der Leitfaden [Fokus-Modus](theodia://help/focus-mode) ist eine aufgeräumte Leseansicht, die Sprachausgabe ebenfalls über die 🔊-Schaltfläche in der unteren Leiste unterstützt.
- Der Leitfaden [Häufige Probleme](theodia://help/common-problems) hat Lösungen für weitere Probleme mit Audio, Stimmen und Sprachen.
- Der Leitfaden [Tägliche Andachten](theodia://help/daily-devotionals) erklärt das Andachtslesen und wo sich die Vorlesen-Schaltfläche auf diesem Bildschirm befindet.
- Der Leitfaden [PDFs](theodia://help/pdfs) erklärt den PDF-Leser und seine Vorlesen-Schaltfläche.
