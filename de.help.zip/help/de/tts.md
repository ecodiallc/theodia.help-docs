---
title: Sprachausgabe
level: everyday
categories: tts
summary: So lässt du Bibeltext, Kapitel und Wiedergabelisten vorlesen.
---

# Sprachausgabe

Theodia kann Bibeltext mit der Sprachausgabe deines Geräts vorlesen. Das funktioniert für einzelne Verse, ganze Kapitel und Wiedergabelisten.

## Text während des Lesens vorlesen lassen

1. Öffne ein Bibelkapitel.
2. Tippe auf das Lautsprecher-Symbol in der Werkzeugleiste.
3. Die App beginnt, das Kapitel vorzulesen.

## Wiedergabe steuern

Während der Sprachausgabe erscheint eine Steuerleiste:

- **Pause / Wiedergabe** — unterbrechen oder fortsetzen.
- **Vorheriger / Nächster Vers** — einen Vers zurück oder weiter.
- **Geschwindigkeit** — langsamer oder schneller sprechen lassen.
- **Stimme** — eine andere Stimme auswählen, falls verfügbar.

## Im Hintergrund weiterhören

Auf iOS und Android kannst du die App in den Hintergrund schieben, während die Sprachausgabe läuft. Achte darauf, dass auf iOS der spezielle App-Build die Hintergrundwiedergabe ermöglicht.

## Wiedergabelisten abspielen

Wenn du eine Wiedergabeliste erstellt hast, tippe auf die Wiedergabe-Schaltfläche in der Wiedergabeliste. Die Kapitel werden nacheinander vorgelesen. Siehe [Wiedergabelisten](theodia://help/playlists).

## Stimmen verwalten

1. Öffne **Einstellungen**.
2. Tippe auf **Sprachausgabe**.
3. Wähle eine bevorzugte Stimme.

Auf manchen Geräten kannst du zusätzliche Stimmen in den Systemeinstellungen herunterladen.

## Geschwindigkeit

Im Einstellungsbildschirm oder während der Wiedergabe kannst du die Geschwindigkeit anpassen. Niedrigere Werte klingen langsamer, höhere schneller.

## Wenn die Stimme nicht funktioniert

- Prüfe, ob die Lautstärke deines Geräts hoch genug ist.
- Stelle sicher, dass auf deinem Gerät mindestens eine TTS-Stimme installiert ist.
- Auf iOS: Öffne **Einstellungen → Barrierefreiheit → Sprachausgabe** und prüfe die Stimmen.
- Auf Android: Öffne **Einstellungen → Barrierefreiheit → Text-to-Speech** und prüfe die Engine.

## Zusammenfassung

- Tippe im Leser auf das Lautsprecher-Symbol.
- Steuere Pause, Sprung, Geschwindigkeit und Stimme.
- Wiedergabelisten können nacheinander vorgelesen werden.
