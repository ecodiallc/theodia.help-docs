---
title: Willkommen bei Theodia
level: beginner
categories: welcome
summary: Erste Schritte mit der Theodia Bible App.
---

# Willkommen bei Theodia

Danke, dass du Theodia nutzt. Diese App soll dir helfen, die Bibel offline zu lesen, zu studieren, zu markieren und zu hören.

## Zuerst

1. Wenn du die App zum ersten Mal öffnest, lädt sie vorbundene Ressourcen in deinen lokalen Speicher.
2. Wähle anschließend deine bevorzugte Sprache und dein Design in den **Einstellungen**.
3. Wähle einen **Benutzermodus**: **Lesen**, **Standard** oder **Gelehrter**. Du kannst ihn später jederzeit ändern.

## Ein Kapitel öffnen

- Tippe auf der Startseite in das Schnellbefehl-Feld und gib `Johannes 3,16` ein.
- Oder tippe unten auf **Bibeln**, wähle eine Übersetzung, ein Buch und ein Kapitel.

## Lesen und verstehen

- Tippe auf einen Vers, um Markierungen, Lesezeichen oder Notizen hinzuzufügen.
- Tippe im Studien-Modus auf Werkzeuge wie **Kommentare**, **Lexikon** oder **Parallelstellen**.
- Tippe auf das Buch-Symbol oben, um zwischen **Studien-Modus** und **Fokus-Modus** zu wechseln.

## Mehr Ressourcen

Wenn du mehr Bibelübersetzungen, Kommentare oder Bücher möchtest, gehe zu **Einstellungen → Ressourcen verwalten**.

## Hilfe

Tippe auf das Fragezeichen oder **Helfen**-Symbol auf den meisten Bildschirmen, um passende Hilfethemen zu öffnen.

## Zusammenfassung

Theodia ist eine offline-fähige Bibel-App. Beginne mit dem Schnellbefehl, wähle deinen Modus und erkunde die Werkzeuge.
