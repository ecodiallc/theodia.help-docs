---
title: Was sind Ressourcen?
level: beginner
categories: resources
summary: Bibeln, Kommentare, Bücher, Lexika, Andachten und Kerndateien erklärt.
---

# Was sind Ressourcen?

In Theodia sind Ressourcen alle zusätzlichen Dateien, die du zur App hinzufügen kannst. Sie machen die App umfangreicher, ohne die App selbst zu vergrößern.

## Arten von Ressourcen

- **Bibeln** — Übersetzungen der Bibel in verschiedenen Sprachen.
- **Kommentare** — Erklärungen und Studiennotizen zu Bibelversen.
- **Lexika** — Wörterbücher für hebräische und griechische Wörter.
- **Bücher** — christliche Literatur und Nachschlagewerke.
- **Andachten** — tägliche Andachtstexte.
- **Kerndateien** — große Dateien, die tiefergehende Funktionen wie Morphologie und Parallelstellen ermöglichen.

## Warum Ressourcen getrennt sind

Die App-Datei bleibt klein, weil die meisten Inhalte separat heruntergeladen werden. Du entscheidest, welche Ressourcen du brauchst.

## Ressourcen finden und installieren

1. Öffne **Einstellungen**.
2. Tippe auf **Ressourcen verwalten**.
3. Wähle eine Registerkarte.
4. Wähle die gewünschten Ressourcen aus und tippe auf **Herunterladen**.

## Eigene Ressourcen

Du kannst eigene Ressourcen im `.bible`, `.commentary`, `.lexicon`, `.book` oder `.devotional`-Format importieren. Siehe [Zusätzliche Ressourcen bekommen](theodia://help/getting-core-files).

## Aktivieren und deaktivieren

Installierte Ressourcen kannst du ein- oder ausschalten, ohne sie zu löschen. Das ist nützlich, wenn du eine saubere Liste haben möchtest.

## Zusammenfassung

- Ressourcen sind Bibeln, Kommentare, Lexika, Bücher, Andachten und Kerndateien.
- Installiere sie über **Einstellungen → Ressourcen verwalten**.
- Importiere eigene Dateien oder deaktiviere Ressourcen, die du gerade nicht brauchst.
