---
title: Δημιουργία των δικών σας πόρων
level: advanced
categories: resources
summary: Πώς να φτιάξετε προσαρμοσμένες Βίβλους, σχόλια, βιβλία, αναγνώσματα και λεξικά και να τα εισάγετε στο Theodia.
---

# Δημιουργία των δικών σας πόρων

Το Theodia υποστηρίζει προσαρμοσμένους πόρους στη μορφή Unique Bible App. Κάθε πόρος είναι ένα αρχείο SQLite με συγκεκριμένη δομή πινάκων. Μπορείτε να φτιάξετε αυτά τα αρχεία σε υπολογιστή και να τα εισάγετε στην εφαρμογή.

## Τύποι αρχείων και απαιτούμενοι πίνακες

### Βίβλοι (`.bible`)

Ένα αρχείο Βίβλου είναι μια βάση δεδομένων SQLite με τουλάχιστον έναν από αυτούς τους πίνακες:

- **`Verses`** — στήλες: `Book` (ακέραιος, 1-66), `Chapter` (ακέραιος), `Verse` (ακέραιος), `Scripture` (κείμενο)
- **`Bible`** — στήλες: `Book` (ακέραιος), `Chapter` (ακέραιος), `Verse` (ακέραιος), `Scripture` (κείμενο)

Μπορείτε επίσης να συμπεριλάβετε έναν πίνακα **`Details`** με στήλες μεταδεδομένων όπως `Description`, `Abbreviation` και `Version`.

Παράδειγμα SQL:

```sql
-- Main text table
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- Optional metadata table
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### Σχόλια (`.commentary`)

Τα σχόλια έρχονται σε τρεις τύπους: **βιβλίου**, **κεφαλαίου** και **στίχου**. Ο τύπος προσδιορίζεται από το **πρώτο γράμμα του ονόματος αρχείου**.

#### Σχόλια βιβλίου — το όνομα αρχείου αρχίζει με `b`

Ένα σχόλιο βιβλίου καλύπτει ένα ολόκληρο βιβλίο της Βίβλου σε μία εγγραφή. Ο πίνακας `Commentary` χρειάζεται στήλες `Book` και `Scripture` (ή `Content`). Δεν χρειάζονται στήλες `Chapter` ή `Verse`.

- **`Commentary`** — στήλες: `Book` (ακέραιος), `Scripture` (κείμενο) ή `Content` (κείμενο)

Παράδειγμα SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

Παράδειγμα ονόματος αρχείου: `bMyCommentary.commentary`

#### Σχόλια κεφαλαίου — το όνομα αρχείου αρχίζει με `c`

Ένα σχόλιο κεφαλαίου καλύπτει κάθε κεφάλαιο ενός βιβλίου Βίβλου.

- **`Commentary`** — στήλες: `Book` (ακέραιος), `Chapter` (ακέραιος), `Scripture` (κείμενο) ή `Content` (κείμενο)

Παράδειγμα SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

Παράδειγμα ονόματος αρχείου: `cMyCommentary.commentary`

#### Σχόλια στίχου — το όνομα αρχείου αρχίζει με `v`

Ένα σχόλιο στίχου καλύπτει μεμονωμένους στίχους. Ο πίνακας `Commentary` χρειάζεται στήλες `Book`, `Chapter`, `Verse` και `Scripture` (ή `Content`).

- **`Commentary`** — στήλες: `Book` (ακέραιος), `Chapter` (ακέραιος), `Verse` (ακέραιος), `Scripture` (κείμενο) ή `Content` (κείμενο)

Παράδειγμα SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

Παράδειγμα ονόματος αρχείου: `vMyCommentary.commentary`

### Βιβλία (`.book`)

Ένα αρχείο βιβλίου είναι μια βάση δεδομένων SQLite με έναν πίνακα `Reference`.

- **`Reference`** — στήλες: `id` (ακέραιος), `Chapter` (κείμενο), `Content` (κείμενο)

Κάθε γραμμή είναι ένα κεφάλαιο. Η στήλη `Chapter` είναι ο τίτλος του κεφαλαίου. Η στήλη `Content` είναι το σώμα του κεφαλαίου, που μπορεί να περιλαμβάνει HTML (`<b>`, `<i>`, `<br>` κ.λπ.).

Παράδειγμα SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

Μπορείτε επίσης να φτιάξετε βιβλία από αρχεία Markdown. Η εφαρμογή μπορεί να εισάγει αρχεία `.md` όπου το `#` είναι ο τίτλος του βιβλίου και το `##` σημειώνει κεφάλαια. Το Markdown μετατρέπεται σε HTML αυτόματα.

### Αναγνώσματα (`.devotional`)

Ένα αρχείο αναγνώσματος είναι μια βάση δεδομένων SQLite με έναν πίνακα `devotional`.

- **`devotional`** — στήλες: `month` (ακέραιος, 1-12), `day` (ακέραιος, 1-31), `devotion` (κείμενο)

Κάθε γραμμή είναι το ανάγνωσμα μιας ημέρας. Η εφαρμογή βρίσκει την εγγραφή με τον τρέχοντα μήνα και ημέρα.

Παράδειγμα SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### Λεξικά (`.lexicon`)

Ένα αρχείο λεξικού είναι μια βάση δεδομένων SQLite με έναν πίνακα `Lexicon`.

- **`Lexicon`** — στήλες: `Topic` (κείμενο, ο αριθμός Strong), `Definition` (κείμενο, η εγγραφή λεξικού)

Η στήλη `Topic` κρατά τον αριθμό Strong (για παράδειγμα, `G1161` ή `H7225`). Η στήλη `Definition` κρατά το πλήρες κείμενο της εγγραφής, που μπορεί να περιλαμβάνει HTML.

Παράδειγμα SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

Τα λεξικά τροφοδοτούν το εργαλείο Πληροφορίες λέξης. Όταν πατάτε μια λέξη σε μια διαγραμματική Βίβλο, η εφαρμογή ψάχνει τον αριθμό Strong στα εγκατεστημένα λεξικά.

## Δημιουργία αρχείου στον υπολογιστή σας

1. Εγκαταστήστε έναν επεξεργαστή SQLite (DB Browser for SQLite, SQLiteStudio, ή το εργαλείο γραμμής εντολών `sqlite3`).
2. Φτιάξτε ένα νέο αρχείο βάσης δεδομένων.
3. Δημιουργήστε τον απαιτούμενο πίνακα και εισάγετε τα δεδομένα σας.
4. Αποθηκεύστε το αρχείο με τη σωστή επέκταση (`.bible`, `.commentary`, `.book`, `.devotional` ή `.lexicon`).

## Εισαγωγή στο Theodia

1. Μεταφέρετε το αρχείο στη συσκευή σας (AirDrop, email, αποθήκευση cloud ή USB).
2. Ανοίξτε το **Theodia**.
3. Πηγαίνετε σε **Ρυθμίσεις** → **Διαχείριση πόρων**.
4. Πατήστε **Εισαγωγή από αρχείο**.
5. Διαλέξτε το αρχείο σας.

Η εφαρμογή ελέγχει το αρχείο (ψάχνει για τον απαιτούμενο πίνακα), το αντιγράφει στον φάκελο δεδομένων της εφαρμογής, και το ενεργοποιεί αυτόματα. Αν το αρχείο είναι άκυρο, βλέπετε ένα μήνυμα λάθους που εξηγεί τι πάει στραβά.

## Περιορισμοί

- Δεν μπορείτε να αντικαταστήσετε ενσωματωμένους πόρους. Αν προσπαθήσετε να εισάγετε ένα αρχείο με το ίδιο όνομα με ενσωματωμένη Βίβλο, σχόλιο ή βιβλίο, η εισαγωγή αποτυγχάνει.
- Τα αρχεία Βίβλου χρειάζονται πίνακα `Verses` ή `Bible`. Αν δεν υπάρχει κανένας, η εισαγωγή αποτυγχάνει.
- Τα αρχεία σχολίων χρειάζονται πίνακα `Commentary`.
  - Τα σχόλια βιβλίου χρειάζονται στήλες `Book` και `Scripture` (ή `Content`).
  - Τα σχόλια κεφαλαίου χρειάζονται στήλες `Book`, `Chapter` και `Scripture` (ή `Content`).
  - Τα σχόλια στίχου χρειάζονται στήλες `Book`, `Chapter`, `Verse` και `Scripture` (ή `Content`).
- Τα αρχεία βιβλίων χρειάζονται πίνακα `Reference`.
- Τα αρχεία λεξικών χρειάζονται πίνακα `Lexicon`.
- Τα αρχεία αναγνωσμάτων χρειάζονται πίνακα `devotional`.

## Συμβουλές

- Κρατήστε τα μεγέθη των αρχείων λογικά. Πολύ μεγάλα αρχεία SQLite μπορεί να προκαλέσουν προβλήματα μνήμης σε παλαιότερες συσκευές.
- Δοκιμάστε το αρχείο σας πρώτα σε υπολογιστή. Ανοίξτε το σε έναν περιηγητή SQLite και τρέξτε `SELECT * FROM` στον απαιτούμενο πίνακα για να επιβεβαιώσετε ότι τα δεδομένα φαίνονται σωστά.
- Για Βίβλους, βεβαιωθείτε ότι η στήλη `Book` χρησιμοποιεί αριθμούς (1 = Γένεση, 66 = Αποκάλυψη).
- Για σχόλια, μπορείτε να χρησιμοποιήσετε είτε `Scripture` είτε `Content` ως στήλη κειμένου του σχολίου.
- Για βιβλία, το HTML στη στήλη `Content` αποδίδεται κατά την ανάγνωση. Κρατήστε το απλό: `<b>`, `<i>`, `<br>` και `<hr>` είναι ασφαλή.

## Πού να βρείτε υπάρχοντες πόρους

Το Theodia μπορεί να διαβάσει πόρους από το έργο [Unique Bible App](https://github.com/eliranwong/UniqueBible). Πολλές Βίβλοι, σχόλια, βιβλία και άλλοι πόροι είναι διαθέσιμοι εκεί στη σωστή μορφή SQLite. Δείτε τον οδηγό [Λήψη επιπλέον πόρων](theodia://help/getting-core-files) για πώς να τους βρείτε και να τους προσθέσετε.
