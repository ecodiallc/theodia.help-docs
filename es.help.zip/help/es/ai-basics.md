---
title: Fundamentos de la IA
level: advanced
categories: ai
summary: Cómo usar el asistente de IA para entender versículos.
---

# Fundamentos de la IA

> **Modo:** El asistente de IA requiere el modo **Académico**. Puedes cambiar de modo en **Configuración** → **Modo de usuario de la app**.

Theodia tiene un asistente de IA. Puede ayudarte a entender un versículo, responder una pregunta o conversar sobre un tema bíblico.

## Cómo encender la IA

La IA está apagada de forma predeterminada. Para encenderla:

1. Abre **Configuración**.
2. Toca **Asistente de IA**.
3. Toca el interruptor para encenderla.

## Cómo abrir la IA

Toca la pestaña **IA** en la parte inferior de la pantalla. Se abre una ventana de chat.

## Cómo hacer una pregunta

Toca la caja de la parte inferior. Escribe tu pregunta. Toca **Enviar**.

Algunas cosas que puedes preguntar:

- "¿Qué significa Juan 3:16?"
- "Cuéntame sobre el libro de Romanos."
- "¿Qué es el fruto del Espíritu?"
- "Compara el Sermón del Monte en Mateo y Lucas."

## Cómo preguntar sobre un versículo específico

1. Abre un capítulo.
2. Toca un versículo para abrir el menú de versículo.
3. Toca **Comentario de IA**.

El versículo se envía a la IA. El panel de IA se abre con el versículo ya rellenado. Puedes añadir una pregunta, como "¿Qué significa esto?" o "¿Cómo debería aplicarlo?"

## Cosas importantes que debes saber

- La IA es una herramienta, no una persona. Puede cometer errores.
- Comprueba siempre las respuestas de la IA con la propia Biblia.
- La IA puede necesitar internet. No funciona sin conexión.
- Cuando usas la IA, tus preguntas, el contexto del versículo y tu clave API se envían al punto de acceso que elijas. La primera vez que lo haces, la app pide tu permiso y te muestra exactamente qué se envía. Puedes cambiar o revocar ese permiso más tarde en **Configuración → Asistente de IA → Compartir datos con IA remota**.
- En algunas regiones, como la compilación de la App Store de China continental, no se ofrece el asistente de IA. En esa compilación solo están disponibles las funciones bíblicas sin conexión.

## Cómo gestionar conversaciones

La pantalla de IA guarda una lista de conversaciones pasadas. Desde la lista puedes abrir una conversación antigua, empezar una nueva o borrar una que ya no necesites.

## Profundiza con la IA

Esta página cubre lo básico. La IA de Theodia puede hacer mucho más que chatear. Aquí tienes dónde continuar:

- **[Funciones de la IA](theodia://help/ai-features)** — Descubre todo lo que Theophilus puede hacer: estudio de versículos de un toque en griego y hebreo, cadenas de referencias cruzadas, bosquejos de sermones, generación de oraciones, morfología de lenguas originales, búsquedas en el léxico y navegación de la app sin usar las manos. Esta es la guía que te muestra cómo convertir la IA de un simple chatbot en un compañero de estudio completo.
- **[Escribir mejores indicaciones para la IA](theodia://help/ai-prompts)** — Aprende el arte de hacer preguntas que obtengan respuestas ricas y precisas. Unos pequeños cambios en cómo redactas tu petición pueden desbloquear respuestas mucho más profundas de la IA.
- **[Elegir un modelo de IA](theodia://help/choosing-a-model)** — No todos los modelos de IA son iguales. Descubre qué modelos admiten las herramientas integradas de Theodia (como abrir versículos y buscar en las Escrituras) y cuáles convierten a la IA en un verdadero asistente de estudio bíblico manos libres.
- **[GitHub Models](theodia://help/github-models)** — El proveedor gratuito recomendado para Theodia. Obtén una clave API gratuita con una cuenta de GitHub y empieza a hacer preguntas con una generosa cuota diaria. Sin tarjeta de crédito, sin suscripción.
- **[Claves API y costos](theodia://help/ai-keys-and-costs)** — Entiende cómo funciona el precio de las API entre proveedores y cómo mantener los costos casi en cero.
