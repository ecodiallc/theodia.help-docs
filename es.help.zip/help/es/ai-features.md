---
title: Funciones de la IA
categories: ai
level: advanced
summary: Descubre todo lo que la IA de Theodia puede hacer — desde el estudio versículo por versículo hasta la preparación de sermones, la exploración de lenguas originales y la navegación manos libres.
---

# Funciones de la IA

> **Modo:** El asistente de IA requiere el modo **Académico**. Puedes cambiar de modo en **Configuración** → **Modo de usuario de la app**.

El asistente de IA de Theodia, Theophilus, no es solo un chatbot. Es un compañero de estudio que puede leer la Biblia junto a ti, consultar comentarios, buscar en las Escrituras, gestionar tus notas e incluso navegar la app — todo por voz o texto.

Antes de que Theophilus envíe datos a un punto de acceso de IA por primera vez, la app muestra un mensaje de consentimiento explicando qué se envía y pidiendo tu permiso. Puedes cambiar o revocar ese permiso en cualquier momento en **Configuración → Asistente de IA → Compartir datos con IA remota**.

## Chat de IA del versículo: estudia un versículo en profundidad

El **chat de IA del versículo** es el corazón de la experiencia de IA de Theodia. Mientras lees cualquier capítulo, toca un número de versículo (o mantén presionado el texto del versículo) y elige **Comentario de IA**. Se abre un panel de chat con ese versículo ya cargado. La IA sabe exactamente qué estás leyendo y está lista para explorarlo contigo.

### Iniciadores de un toque

¿No sabes qué preguntar? El panel muestra ocho iniciadores instantáneos:

- **Explica este verso** — Obtén una explicación clara y reflexiva del significado y la importancia.
- **Lengua original** — Ve las palabras griegas o hebreas, transliteraciones y definiciones léxicas detrás del texto en inglés.
- **Contexto histórico** — Conoce la cultura, la política y los eventos que rodean el versículo.
- **Contexto textual** — Ve cómo encaja el versículo en el párrafo, el capítulo y el libro que lo rodean.
- **Temas principales** — Descubre las grandes ideas que este versículo aporta a la teología bíblica.
- **Aplicar a mi vida** — Obtén aplicaciones prácticas y personales que puedes poner en práctica hoy.
- **Generar una oración** — Convierte el versículo en una oración inspirada en su lenguaje y verdades.
- **Generar un bosquejo de sermón** — Obtén un bosquejo de tres puntos con introducción y conclusión, listo para predicar.

Toca cualquier iniciador y la IA empieza inmediatamente. Puedes hacer preguntas de seguimiento, pedir aclaraciones o dirigir la conversación en una nueva dirección.

### Conversación de seguimiento natural

La IA recuerda los últimos mensajes del chat, así que puedes profundizar de forma natural:

- "¿Puedes decirlo más sencillo?"
- "¿Qué dice el griego original aquí?"
- "Muéstrame referencias cruzadas que se conecten con esto."
- "Compara este versículo en tres traducciones diferentes."
- "¿Cómo se vería esto en un lugar de trabajo moderno?"
- "Dame tres aplicaciones más para un padre."

La conversación permanece unida al versículo, así que cada respuesta está anclada al texto que estás leyendo.

### Toca cualquier referencia bíblica

Cuando la IA menciona otro versículo —por ejemplo, "Esto se refleja en Romanos 8:28"— la referencia aparece como un **enlace tocable**. Tócala y la app salta a ese pasaje en el lector bíblico. Puedes explorar la cadena de referencias sin salir nunca de la conversación.

## Qué más puede hacer la IA

Theophilus tiene acceso a todo el contenido de Theodia —Biblias, comentarios, léxicos, diccionarios, libros, devocionales, tus notas, marcadores y resaltados—. Esto es lo que significa en la práctica.

### Leer y navegar por las Escrituras

- **Lee cualquier versículo o capítulo** — "Lee Juan 3:16 en la WEB" o "Lee el Salmo 23 en voz alta."
- **Abre pasajes en el lector** — "Llévame a Génesis 1" o "Abre Romanos 8:28."
- **Compara versiones** — "Muéstrame Juan 3:16 en todas mis Biblias."
- **Busca en la Biblia** — "Encuentra versículos sobre el perdón" o "Busca 'paz que sobrepasa todo entendimiento.'"
- **Obtén referencias cruzadas** — "¿Qué otros versículos se relacionan con Isaías 53:5?"
- **Lee títulos de sección** — "¿Cuáles son los subtítulos de Mateo 5?"

### Explorar lenguas originales

- **Búsquedas en el léxico** — "¿Qué significa la palabra griega 'agape' en Juan 3:16?" o "Busca el Strong G26."
- **Morfología** — "Analiza los verbos griegos de Romanos 8:28" o "¿Qué significa el código de morfología V-PAI-3S?"
- **Información de la palabra** — La IA puede ver el mismo desglose palabra por palabra que ves en la app: transliteración, glosa, gramática y números de Strong.

### Leer comentarios y libros de estudio

- **Comentario del versículo** — "¿Qué dice Matthew Henry sobre Efesios 2:8?"
- **Comentario del capítulo** — "Dame la descripción del capítulo de Romanos 8."
- **Comentario del libro** — "Resume el comentario a nivel de libro del Apocalipsis."
- **Libros de estudio** — "Léeme un capítulo de Hymn Lyrics English" o "Busca en mis libros 'paciencia.'"
- **Devocionales** — "Lee el devocional de hoy" o "Encuentra un devocional sobre la ansiedad."

### Buscar en diccionarios

- "¿Quién fue Melquisedec?"
- "¿Qué dice el diccionario bíblico sobre Gilgal?"
- "Busca 'propiciación' en Easton's."

### Gestionar tu vida de estudio

La IA puede actuar sobre tus datos personales, siempre almacenados localmente en tu dispositivo:

- **Marcadores** — "Guarda este versículo como marcador en mi carpeta Preparación de sermones" o "Lista mis marcadores."
- **Resaltados** — "Resalta Juan 3:16 en amarillo" o "Muéstrame todos mis resaltados."
- **Notas** — "Crea una nota bíblica en este versículo" o "Lee mis notas de Génesis 1."
- **Notas de estudio** — "Guarda esta conversación como nota de estudio" o "Crea un nuevo cuaderno de estudio llamado Estudio de Romanos."
- **Carpetas** — "Crea una carpeta llamada Devoción matutina" o "Mueve mi marcador de Juan 3:16 a la carpeta Oración."

### Cambiar ajustes de la app

- "Cambia al modo oscuro."
- "Haz que la BSB sea mi Biblia principal."
- "Activa las Biblias paralelas con la NET."
- "Aumenta el tamaño de letra."

### Leer en voz alta

- "Lee el Salmo 23 en voz alta" — La IA puede activar el texto a voz para cualquier pasaje, libro o nota.
- "Deja de leer" — Pausa el texto a voz en cualquier momento.

## Guarda tus conversaciones

Cada chat de IA de un versículo se puede guardar. Toca el menú en el panel de chat y elige:

- **Guardar como nota bíblica** — Añade la conversación completa a la nota del versículo en el lector bíblico.
- **Guardar como nota de estudio** — Guarda la conversación en tu libro de Notas de estudio para consultarla después.

Esto convierte una exploración rápida con la IA en material de estudio permanente que puedes revisitar, editar o usar para preparar sermones.

## La pestaña completa de IA

Además del panel de chat del versículo, Theodia tiene una pestaña dedicada **IA** en la navegación inferior. Es un chat de forma libre donde puedes preguntar cualquier cosa sin un versículo preseleccionado. Úsalo para:

- Estudios temáticos a lo largo de toda la Biblia
- Investigación y bosquejos de sermones
- Comparar temas teológicos entre libros
- Devoción diaria e indicaciones de oración
- Trivia bíblica y planes de lectura
- Ayuda de la app — "¿Cómo funcionan las Biblias paralelas?"

Tus conversaciones se guardan automáticamente. Puedes volver a chats anteriores, empezar otros nuevos y borrar conversaciones antiguas.

## Ideas para empezar

Aquí tienes algunas formas interesantes de usar la IA. Elige una y pruébala hoy.

**Crecimiento personal**

- "Explica Filipenses 4:6-7 y dame una oración para cuando siento ansiedad."
- "¿Qué dice la Biblia sobre el descanso? Encuéntrame cinco versículos y explícame cada uno."

**Familia y crianza**

- "¿Cómo debería Efesios 6:4 guiar la crianza moderna? Dame tres reglas prácticas."
- "Encuentra versículos sobre criar hijos y léemelos en voz alta."

**Preparación de sermones y enseñanza**

- "Bosqueja un sermón de 25 minutos sobre Romanos 8:28 con introducción, tres puntos y conclusión."
- "¿Qué dicen mis comentarios sobre la 'armadura de Dios' en Efesios 6?"
- "Compara el Sermón del Monte en Mateo con la versión de Lucas. ¿Cuáles son las diferencias?"

**Estudio de lenguas originales**

- "Muéstrame la morfología de cada palabra en Juan 1:1."
- "¿Cuál es la diferencia entre 'agape' y 'philia' en el Nuevo Testamento?"

**Profundidad devocional**

- "Lee el devocional de hoy y conéctalo con un versículo de los Salmos."
- "Dame un bosquejo devocional de siete días sobre el fruto del Espíritu."

**Cadenas de referencias cruzadas**

- "Empieza con Isaías 53:5 y sigue el tema de las 'heridas' y la 'sanidad' a través del Nuevo Testamento."
- "¿Dónde aparece el concepto de 'pacto' desde Génesis hasta Hebreos?"

**Memorización y repaso**

- "Pregúntame los libros de la Biblia en orden."
- "Crea una nota de estudio que resuma el punto principal de cada capítulo de Romanos."

## Algunas notas importantes

- La IA es una **herramienta**, no un reemplazo de la Biblia ni de la orientación pastoral. Compara siempre sus respuestas con la propia Escritura.
- Cuando usas la IA, tus preguntas viajan por internet a los servidores del proveedor. La mayoría de los proveedores no entrenan con tus datos, pero el texto sí sale de tu dispositivo.
- La IA puede cometer errores. Usa los comentarios, los léxicos y el propio texto bíblico como autoridad final.

## Resumen

La IA de Theodia está diseñada para hacer el estudio bíblico más rápido, profundo y personal. Ya sea que quieras una explicación de una frase confusa, un bosquejo de sermón completo, un estudio de una palabra griega o una cadena de referencias cruzadas que abarque toda la Biblia, Theophilus está listo para ayudar. Toca un versículo, haz una pregunta y mira adónde te lleva la conversación.
