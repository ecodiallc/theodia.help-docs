---
title: Claves API y costos
level: advanced
categories: ai
summary: Por qué necesitas una clave API, cómo obtener una y qué suele costar usar un modelo de IA remoto.
---

# Claves API y costos

> **Modo:** El asistente de IA requiere el modo **Académico**. Puedes cambiar de modo en **Configuración** → **Modo de usuario de la app**.

El asistente de IA se conecta a modelos de IA remotos. Si quieres usar uno, necesitas una clave API. Esta página explica por qué, cómo obtener una y qué suele costar.

## Por qué necesitas una clave API

Un modelo de IA remoto vive en un servidor en internet. La clave API es como una contraseña que le dice al servidor: "Esta persona tiene permiso para hacer preguntas." Sin ella, el servidor no responderá.

La app no incluye una clave integrada. Debes crear tu propia cuenta en un proveedor y pegar tu clave en la app.

## Cómo obtener una clave API

1. Abre **Configuración** en Theodia.
2. Toca **Asistente de IA**.
3. Elige **Modelo remoto**.
4. Selecciona un proveedor de la lista, o elige **Personalizado** e introduce una URL base.
5. Toca el enlace a la página de claves del proveedor. Crea una cuenta si no tienes una.
6. Genera una clave API nueva en el sitio del proveedor.
7. Copia la clave y pégala en Theodia.
8. Toca **Probar conexión** para asegurarte de que funciona.

## Proveedores compatibles

Theodia puede conectarse a cualquier proveedor que use una API compatible con OpenAI. Estos son los que tienen enlaces predefinidos en la app:

- **GitHub Models** — github.com/marketplace/models (nivel diario gratuito, recomendado)
- **OpenAI** — platform.openai.com
- **OpenRouter** — openrouter.ai
- **Anthropic** — console.anthropic.com
- **Groq** — console.groq.com
- **Mistral** — console.mistral.ai
- **Together AI** — api.together.xyz

También puedes usar una URL base **Personalizada** si ejecutas tu propio servidor o usas otro servicio.

## ¿Cuánto cuesta?

La mayoría de los proveedores cobran por **token**. Un token es aproximadamente una palabra o parte de una palabra. Pagas por los tokens que envías (tu pregunta) más los tokens que la IA devuelve (la respuesta).

### Precios típicos

Los precios cambian, pero esta es una idea aproximada a mediados de 2026:

- **Modelos pequeños y rápidos** (como puntos de acceso de la clase de GPT-3.5 más baratos) cuestan una fracción de céntimo por mil tokens.
- **Modelos de rango medio** (como GPT-4o o Claude Sonnet) suelen costar unos pocos céntimos por mil tokens.
- **Modelos de razonamiento grandes** (como GPT-4.5 o Claude Opus) pueden costar de diez a veinte céntimos por mil tokens.

Una pregunta típica de la Biblia en Theodia puede usar de unos pocos cientos a un par de miles de tokens en total. Eso significa que la mayoría de las preguntas cuestan entre **menos de un céntimo y unos pocos céntimos**.

### Consejos para mantener los costos bajos

- Empieza con un modelo más barato. La mayoría de las preguntas de la Biblia no necesitan el modelo más caro.
- Usa Groq u OpenRouter si quieres probar diferentes modelos y comparar precios.
- Revisa tu panel de uso en el sitio del proveedor.

## GitHub Models

[GitHub Models](https://github.com/marketplace/models) ofrece un nivel gratuito sin suscripción. Solo necesitas una cuenta gratuita de GitHub y un token de acceso personal con permiso para leer modelos.

**Cómo configurarlo:**

1. Ve a [github.com/settings/tokens](https://github.com/settings/tokens) y crea un **token de acceso personal (classic)**.
2. Dale el alcance `models:read` (o simplemente selecciona el permiso de modelos).
3. En Theodia, elige **GitHub Models** como proveedor y pega tu token.

**Modelos del nivel gratuito:**

- `openai/gpt-4.1-nano` — **15 solicitudes por minuto, 150 solicitudes por día**
- `openai/gpt-4.1-mini` — **15 solicitudes por minuto, 150 solicitudes por día**
- `openai/gpt-4.1` — **10 solicitudes por minuto, 50 solicitudes por día**
- `openai/gpt-4o` — **10 solicitudes por minuto, 50 solicitudes por día**

Estos límites se reinician diariamente y son suficientes para el estudio bíblico regular.

Para una guía paso a paso completa con capturas de pantalla, consulta la guía dedicada [GitHub Models](theodia://help/github-models).

## Nota de privacidad

Cuando usas un modelo de IA remoto, la app primero muestra un mensaje de consentimiento explicando qué se envía: tus mensajes, el contexto del versículo o capítulo, las llamadas a herramientas y sus resultados, el nombre del modelo configurado y tu clave API en el encabezado de la solicitud. La solicitud va directamente al punto de acceso que configuraste, no a través de Theodia. La mayoría de los proveedores no usan tus datos para entrenar sus modelos, pero el texto sí sale de tu dispositivo. Puedes cambiar o revocar el permiso en cualquier momento en **Configuración → Asistente de IA → Compartir datos con IA remota**.

## Resumen

- Necesitas una clave API para usar el asistente de IA.
- Crea una cuenta en un proveedor, genera una clave y pégala en Theodia.
- La mayoría de las preguntas cuestan unos pocos céntimos o menos.
