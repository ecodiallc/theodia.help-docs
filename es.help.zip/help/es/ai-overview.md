---
title: El asistente de IA
level: advanced
category: ai
summary: Cómo usar el asistente de IA para entender versículos.
---

# El asistente de IA

Theodia tiene un asistente de IA. Puede ayudarte a entender un versículo, responder una pregunta o conversar sobre un tema bíblico.

## Cómo encender la IA

La IA está apagada de forma predeterminada. Para encenderla:

1. Abre **Configuración**.
2. Toca **Asistente de IA**.
3. Toca el interruptor para encenderla.

Es posible que necesites configurar una cuenta o una clave. La app te guiará.

## Cómo abrir la IA

Toca la pestaña **IA** en la parte inferior de la pantalla. Se abre una ventana de chat.

## Cómo hacer una pregunta

Toca la caja de la parte inferior. Escribe tu pregunta. Toca **Enviar**.

Algunas cosas que puedes preguntar:

- "¿Qué significa Juan 3:16?"
- "Cuéntame sobre el libro de Romanos."
- "¿Qué es el fruto del Espíritu?"
- "Compara el Sermón del Monte en Mateo y Lucas."

## Cómo preguntar sobre un versículo específico

1. Abre un capítulo.
2. Toca un versículo para abrir el menú de versículo.
3. Toca **Comentario de IA**.

El versículo se envía a la IA. El panel de IA se abre con el versículo ya rellenado. Puedes añadir una pregunta, como "¿Qué significa esto?" o "¿Cómo debería aplicarlo?"

## Cosas importantes que debes saber

- La IA es una herramienta, no una persona. Puede cometer errores.
- Comprueba siempre las respuestas de la IA con la propia Biblia.
- La IA puede necesitar internet. No funciona sin conexión.
- Cuando usas la IA, tus preguntas, el contexto del versículo y tu clave API se envían al punto de acceso que elijas. La primera vez que lo haces, la app pide tu permiso y te muestra exactamente qué se envía. Puedes cambiar o revocar ese permiso más tarde en **Configuración → Asistente de IA → Compartir datos con IA remota**.
- En algunas regiones, como la compilación de la App Store de China continental, no se ofrece el asistente de IA. En esa compilación solo están disponibles las funciones bíblicas sin conexión.

## Cómo gestionar conversaciones

La pantalla de IA guarda una lista de conversaciones pasadas. Desde la lista puedes abrir una conversación antigua, empezar una nueva o borrar una que ya no necesites.

Para más consejos avanzados, consulta la guía [Escribir mejores indicaciones para la IA](theodia://help/ai-prompts).
