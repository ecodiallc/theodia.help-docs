---
title: Escribir mejores indicaciones para la IA
level: advanced
categories: ai
summary: Cómo preguntarle al asistente de IA de forma que obtengas buenas respuestas.
---

# Escribir mejores indicaciones para la IA

Una "indicación" es la pregunta o instrucción que le das a la IA. Mejores indicaciones obtienen mejores respuestas. Esta guía te muestra cómo.

## Sé específico

Malo: "Cuéntame sobre el amor."
Mejor: "En 1 Corintios 13, ¿qué tipo de amor describe Pablo y en qué se diferencia del amor romántico?"

Cuanto más detalle des, más útil será la respuesta.

## Da contexto

Malo: "¿Qué significa este versículo?"
Mejor: "Estoy leyendo Romanos 8 con un grupo pequeño. ¿Qué significa 'ninguna condenación' en este capítulo, y cómo se conecta con el resto del capítulo?"

El contexto ayuda a la IA a ajustar su respuesta a tu situación.

## Pide una cosa a la vez

Malo: "Cuéntame sobre la oración, la fe y la sanidad."
Mejor: "Cuéntame primero sobre la oración. Después te preguntaré sobre la fe."

Pedir una cosa a la vez mantiene las respuestas enfocadas.

## Pídele a la IA que adopte un rol

Puedes pedirle a la IA que responda con una voz determinada. Por ejemplo:

- "Responde como si estuvieras enseñando a un cristiano nuevo."
- "Responde como un erudito bíblico."
- "Responde para un niño de 10 años."

La IA ajusta su respuesta al rol.

## Usa preguntas de seguimiento

Si la primera respuesta no es del todo adecuada, haz una pregunta de seguimiento:

- "¿Puedes decirlo más sencillo?"
- "¿Puedes darme un ejemplo?"
- "¿Qué dice el griego original?"
- "¿Dónde más en la Biblia aparece esto?"

Una buena conversación es un intercambio. La IA recuerda los últimos mensajes.

## Comprueba las respuestas de la IA

La IA puede cometer errores. Es una herramienta, no un maestro.

- Compara la respuesta de la IA con los versículos a los que te señala.
- Usa los comentarios y léxicos de la app para una segunda opinión.
- Si la respuesta trata sobre doctrina, pregúntale a un pastor o a un amigo de confianza.

## Patrones de indicaciones comunes

Aquí hay algunos que funcionan bien:

- "Explícame este versículo como si fuera un cristiano nuevo."
- "¿Cuál es el punto principal de este capítulo en una sola frase?"
- "Enumera tres aplicaciones para mi vida diaria a partir de este pasaje."
- "¿Qué preguntas debería hacerme sobre este versículo antes de predicarlo?"
