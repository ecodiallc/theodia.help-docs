---
title: Modo de usuario de la app
level: beginner
categories: [user-mode]
summary: Elige entre los modos Lector, Estándar y Académico para controlar qué funciones están disponibles en la app.
---

# Modo de usuario de la app

Theodia ofrece tres modos de usuario que controlan qué funciones ves. Elige el que se ajuste a cómo quieres usar la app.

## Lector

El modo más sencillo. El modo Lector es para leer la Biblia sin distracciones.

- Leer cualquier traducción de la Biblia
- Usar el modo de enfoque para lectura limpia a pantalla completa
- Navegar por libros y capítulos
- Sin herramientas de estudio, sin IA, sin marcadores, sin resaltados

El modo Lector es ideal si quieres que Theodia se sienta como una Biblia digital limpia sin nada extra.

## Estándar

El modo Estándar añade funciones cotidianas para el estudio personal de la Biblia.

Todo lo del modo Lector, más:

- Marcadores, resaltados y notas
- Texto a voz
- Lector en modo de estudio con menú de versículo
- Biblias paralelas
- Comando rápido
- Buscar en la Biblia
- Devocionales diarios y libros incorporados

El modo Estándar es la opción adecuada para la mayoría de los usuarios que quieren leer, marcar y buscar en la Biblia sin herramientas de estudio avanzadas.

## Académico

El modo completo. El modo Académico desbloquea todas las herramientas de Theodia para el estudio profundo de la Biblia.

Todo lo del modo Estándar, más:

- Comentarios y léxicos
- Referencias cruzadas
- Diccionario bíblico
- Información de la palabra (consultas de Strong)
- Asistente de IA y comentario de IA
- Menú rápido

El modo Académico está diseñado para pastores, estudiantes de seminario y cualquiera que quiera herramientas en idiomas originales y ayudas de estudio con IA.

## Cómo cambiar de modo

1. Abre **Configuración**.
2. Toca **Modo de usuario de la app**.
3. Elige **Lector**, **Estándar** o **Académico**.

El cambio surte efecto inmediatamente. Los menús y botones a los que no tienes acceso en tu modo actual se ocultan.

## Elegir un modo

- **Lector** — Solo quieres leer la Biblia, nada más.
- **Estándar** — Quieres marcadores, resaltados, notas, búsqueda y devocionales.
- **Académico** — Quieres todas las herramientas de estudio, incluida la IA, comentarios y léxicos.

Puedes cambiar de modo en cualquier momento. Tus marcadores, resaltados y notas nunca se eliminan al cambiar de modo; simplemente se ocultan hasta que vuelvas a un modo que los soporte.
