---
title: Copias de seguridad de tus datos
level: everyday
categories: settings
summary: Cómo guardar y restaurar tus notas, resaltados, marcadores y secretos.
---

# Copias de seguridad de tus datos

Tus notas, resaltados, marcadores y ajustes se guardan en tu dispositivo. Si pierdes el teléfono, consigues uno nuevo o desinstalas la app, esos datos pueden perderse. Esta guía te muestra cómo hacer una copia de seguridad.

## Cómo abrir los ajustes de copia de seguridad

1. Abre **Configuración**.
2. Toca **Copia de seguridad de la app**.

## Cómo hacer una copia de seguridad de la app

1. Abre **Configuración**.
2. Toca **Copia de seguridad de la app**.
3. Toca **Crear copia de seguridad de la app**.
4. Elige una carpeta en tu dispositivo para guardar el archivo. También puedes elegir una unidad en la nube.
5. La app crea un solo archivo con todos tus datos. El archivo termina en `.zip`.

## Con qué frecuencia hacer una copia de seguridad

Haz una copia de seguridad:

- Después de haber escrito muchas notas.
- Antes de actualizar el sistema operativo de tu dispositivo.
- Antes de desinstalar la app o cambiar de teléfono.

Un buen hábito es una copia de seguridad al mes. Algunas personas hacen una cada semana.

## Cómo restaurar desde una copia de seguridad de la app

1. Abre **Configuración**.
2. Toca **Copia de seguridad de la app**.
3. Toca **Restaurar copia de seguridad de la app**.
4. Elige el archivo de copia de seguridad `.zip`.
5. Para cada tipo de datos (notas, resaltados, marcadores, etc.), elige si conservar lo que hay en el dispositivo, reemplazarlo por la copia de seguridad, u omitirlo.
6. Toca **Restaurar**.

La app reemplaza tus datos por los de la copia de seguridad. Esto incluye:

- Notas
- Resaltados
- Marcadores
- Carpetas de marcadores
- Ajustes (tema, tamaño de fuente, idioma)

## Copia de seguridad de secretos

Tu **Copia de seguridad de la app** **no** incluye secretos sensibles como tu clave API de IA o tu token de GitHub. Para respaldar esos por separado, usa la **Copia de seguridad de secretos**.

### Guardar una copia de seguridad de secretos

1. Abre **Configuración**.
2. Toca **Copia de seguridad de la app**.
3. En **Copia de seguridad de secretos**, toca **Crear copia de seguridad de secretos**.
4. Introduce una contraseña segura y confírmala.
5. La app cifra tus secretos y comparte el archivo cifrado. Guárdalo en un lugar seguro.

### Restaurar una copia de seguridad de secretos

1. Abre **Configuración**.
2. Toca **Copia de seguridad de la app**.
3. En **Copia de seguridad de secretos**, toca **Restaurar copia de seguridad de secretos**.
4. Elige el archivo de copia de seguridad de secretos cifrado.
5. Introduce la misma contraseña que usaste al guardarlo.
6. Tus secretos se restauran.

> **Importante:** Si olvidas la contraseña, los secretos no se pueden recuperar. No hay restablecimiento.

## Cosas que debes saber

- Una restauración **reemplaza** las categorías que elegiste. Cualquier cosa que añadieras después de la copia de seguridad se perderá para esas categorías.
- Una copia de seguridad de la app es un solo archivo `.zip`. Mantenlo en un lugar seguro.
- Puedes copiar el archivo, moverlo o almacenarlo en cualquier servicio en la nube.
- Las copias de seguridad de la app no incluyen las traducciones de la Biblia en sí. Esas se pueden volver a descargar desde **Configuración** → **Gestionar recursos**.
- Las copias de seguridad de secretos están cifradas con tu contraseña. Elige una contraseña que recordarás.

## Consejo

Si tienes más de un dispositivo, puedes copiar el archivo de copia de seguridad a cada dispositivo y restaurarlo. Tus datos serán los mismos en ambos.
