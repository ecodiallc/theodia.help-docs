---
title: Guardar marcadores
level: everyday
categories: [annotate, read]
summary: Cómo guardar versículos para encontrarlos de nuevo.
---

# Guardar marcadores

> **Modo:** Los marcadores están disponibles en los modos **Estándar** y **Académico**. El modo de enfoque es solo para lectura limpia y sin distracciones. Puedes cambiar de modo en **Configuración** → **Modo de usuario de la app**.

Un marcador guarda un versículo o un capítulo de libro para que puedas encontrarlo de nuevo. Los marcadores son como las pestañas de un libro.

## Cómo guardar un marcador de versículo

1. Abre el versículo.
2. Toca el versículo para mostrar el menú.
3. Toca **Marcador** en el menú. Un icono de estrella marca el versículo como guardado.

Una marca de verificación en el icono significa que el versículo ahora está guardado.

## Cómo guardar un marcador de capítulo de libro

Cuando lees un libro (no la Biblia), puedes guardar el capítulo completo:

1. Abre el capítulo.
2. Toca el icono de **Marcador** en la parte superior de la pantalla.

## Cómo ver tus marcadores

Toca la pestaña **Marcadores** en la parte inferior. Verás una lista de cada versículo y capítulo de libro que has guardado.

## Cómo quitar un marcador

- **Un versículo:** Abre el versículo. Toca el versículo y luego el icono de **Marcador** de nuevo. La marca de verificación desaparece.
- **Desde la lista:** En la pestaña **Marcadores**, mantén presionado un marcador. Aparece un pequeño menú. Toca **Eliminar**. (También puedes tocar el pequeño botón × de la fila.)

## Organizar con carpetas

Puedes poner marcadores en carpetas. Por ejemplo, puedes tener una carpeta llamada "Predicación" y otra llamada "Aliento".

Para crear una carpeta:

1. Abre la pestaña **Marcadores**.
2. Toca **Gestionar carpetas** en la parte superior.
3. Toca **Crear carpeta** en la parte superior de la lista de carpetas.
4. Escribe un nombre y toca **Guardar**.

No puedes crear dos carpetas con el mismo nombre. Si el nombre ya existe, aparece un error dentro de la caja de crear carpeta para que lo cambies y vuelvas a intentar.

Para poner un marcador en una carpeta:

1. En la pestaña **Marcadores**, mantén presionado un marcador.
2. Toca **Mover a carpeta**.
3. Elige la carpeta y luego toca **Hecho**.

## Importar marcadores

Puedes traer marcadores a Theodia desde otras apps y archivos.

Ve a **Configuración** → **Marcadores** → **Importar marcadores**. Elige **Importar desde archivo** o pega desde el portapapeles. La app detecta el formato automáticamente.

### Formatos admitidos

**Exportación JSON nativa** — El formato usado por la función de exportación propia de Theodia. Esto conserva carpetas y fechas de creación.

**Marcadores HTML de Netscape** — El formato usado por Chrome, Firefox y Safari al exportar marcadores. Las carpetas se conservan.

**CSV** — Una hoja de cálculo con columnas. La app busca columnas `url` y `folder` (o `href` / `category`). Ejemplo:

```csv
url,folder
/bible/KJV/John/3,Favoritos
/bible/KJV/Genesis/1,Predicación
```

**Texto plano** — Cada línea es una referencia bíblica, una URL de la app o una directiva de carpeta. Ejemplo:

```
folder: Favoritos
John 3:16
Genesis 1:1
folder: Predicación
Matthew 5:1
```

- Las líneas que empiezan con `folder: <nombre>` establecen la carpeta activa para todos los marcadores siguientes.
- Las referencias bíblicas como `John 3:16` se convierten a marcadores en tu Biblia predeterminada.
- Las URLs de la app como `/bible/KJV/John/3#v3_16` o `/book/MyBook/1` se importan directamente.
- Las líneas que empiezan con `#` o `//` se tratan como comentarios y se omiten.

### Consejos para importar

- Los marcadores duplicados se omiten automáticamente.
- Las URLs externas (como enlaces de BibleGateway) se convierten a marcadores de la app cuando es posible.
- Si una carpeta del archivo de importación ya existe, los marcadores se colocan en la carpeta existente.

## Consejos

- Puedes guardar el mismo versículo en muchas traducciones. Todos aparecen en la lista.
- Los marcadores permanecen en tu dispositivo. No se sincronizan con la nube.
- Consulta la guía [Copias de seguridad de tus datos](theodia://help/backups) para mantenerlos a salvo.

## Marcadores en un PDF

Los PDF tienen sus propios marcadores, que se mantienen separados de tus marcadores de la Biblia. Al leer un PDF, toca el botón **Marcador** de la barra de herramientas del lector para guardar la página actual, darle un nombre y volver a ella más tarde. Cada PDF tiene su propia lista: consulta [PDF](theodia://help/pdfs).
