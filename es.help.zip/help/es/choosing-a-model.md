---
title: Elegir un modelo de IA
level: advanced
categories: ai
summary: Cómo elegir un modelo que funcione bien con las herramientas y capacidades integradas de Theodia.
---

# Elegir un modelo de IA

> **Modo:** El asistente de IA requiere el modo **Académico**. Puedes cambiar de modo en **Configuración** → **Modo de usuario de la app**.

No todos los modelos de IA funcionan igual en Theodia. La mejor experiencia viene de un modelo que admite **tool calling** —la capacidad de la IA para usar las funciones integradas de Theodia, como buscar versículos, buscar en las Escrituras, leer comentarios y navegar la app.

## Qué es el tool calling

Cuando le haces una pregunta a la IA de Theodia, la IA puede hacer más que hablar. También puede **actuar**. Por ejemplo:

- Dices: "Muéstrame Juan 3:16 en la ESV." La IA llama a una herramienta para abrir ese versículo en el lector.
- Dices: "¿Qué dicen mis comentarios sobre Romanos 8:28?" La IA llama a una herramienta para obtener el contenido del comentario.
- Dices: "Guarda este versículo como marcador." La IA llama a una herramienta para crear un marcador.

Los modelos que no admiten tool calling solo pueden darte respuestas de texto. No pueden buscar, navegar ni cambiar nada en la app.

## Qué modelos admiten herramientas

### Modelos remotos

La mayoría de los modelos remotos modernos de los proveedores principales admiten tool calling compatible con OpenAI. En general:

- **Modelos grandes** (como GPT-4o, Claude Sonnet/Opus, Gemini Pro) manejan herramientas de forma confiable y pueden encadenar varias llamadas en una conversación. Los nombres de proveedor e ID de modelo se muestran en la app como referencia; el servicio real al que te conectas es el de la URL y la clave que configures.
- **Modelos más pequeños o baratos** pueden admitir herramientas pero ser menos confiables. Podrían ignorar una llamada o formatearla mal.
- **Modelos muy antiguos o especializados** a menudo no admiten herramientas.

Si no estás seguro, prueba el modelo en Theodia. Pídele que "Muéstrame Génesis 1:1" o "Busca en la Biblia versículos sobre el amor." Si se abre el versículo o aparecen resultados de búsqueda, el tool calling funciona.

## Modelos recomendados para Theodia

Estos modelos equilibran costo, calidad y soporte de herramientas:

- **OpenAI GPT-4o** — excelente soporte de herramientas, rápido, maneja bien preguntas complejas de varios pasos.
- **Anthropic Claude Sonnet / Opus** — uso de herramientas muy confiable, ideal para pasajes largos y estudio detallado.
- **Groq** (varios modelos) — inferencia rápida, a menudo gratis o muy barato; el soporte de herramientas varía según el modelo.
- **OpenRouter** — te permite probar muchos modelos desde una sola cuenta. Busca modelos que incluyan "function calling" o "tools" en sus capacidades.
- **[GitHub Models](theodia://help/github-models)** — el proveedor gratuito recomendado. Accede a modelos de OpenAI, Anthropic y otros a través de tu cuenta de GitHub con una generosa cuota diaria gratuita. Usa los mismos ID de modelo tipo `openai/gpt-4o`.

## Modelos que conviene evitar

- **Modelos de solo completado de texto** (como GPT-3 base o LLaMA sin ajuste de instrucciones) suelen no admitir herramientas.
- **Modelos solo de imagen o de visión**, enfocados en imágenes en lugar de texto, pueden carecer de soporte de herramientas.
- **Modelos extremadamente pequeños** de menos de 1 mil millón de parámetros es improbable que usen herramientas correctamente, aunque la API diga que las admiten.

## Cómo probar el soporte de herramientas

Theodia verifica el soporte de herramientas automáticamente. Después de configurar un modelo en **Configuración → Asistente de IA**, toca **Probar conexión**. Una vez que la conexión tiene éxito, la app envía una segunda solicitud con una definición de herramienta de ejemplo. Verás uno de dos resultados:

- **✓ Herramientas admitidas** — El modelo acepta llamadas de herramienta y puede usar las funciones integradas de Theodia.
- **✗ Herramientas no admitidas** — El modelo rechaza la solicitud de herramienta. Responderá solo en texto y no podrá abrir versículos, buscar ni gestionar marcadores por ti.

Si ves "Herramientas no admitidas", el modelo puede seguir funcionando como asistente de chat de texto plano, pero no obtendrás la experiencia integrada y manos libres.

También puedes verificar manualmente pidiéndole a la IA que haga algo:

- "Muéstrame Mateo 5:3 en la KJV." — Debería abrir el versículo en el lector.
- "¿Qué dice el léxico sobre la palabra 'agape' en Juan 3:16?" — Debería devolver datos del léxico.
- "Busca en la Biblia versículos sobre el perdón." — Debería devolver resultados de búsqueda.
- "Guarda un marcador en Marcos 12:30." — Debería crear un marcador.

Si la IA te da una descripción de texto en lugar de hacer realmente la acción, el modelo está teniendo dificultades para usar sus herramientas aunque la app reportara soporte.

## ¿Qué pasa si mi modelo no admite herramientas?

Puedes seguir usándolo. La IA responderá en texto, y tú puedes buscar versículos, buscar y navegar la app manualmente. Pero perderás la experiencia integrada y manos libres que hace poderoso a Theodia.

## Resumen

- Elige un modelo con soporte de **tool calling / function calling** para la mejor experiencia en Theodia.
- Los **modelos remotos grandes** manejan las herramientas con más confiabilidad.
- Prueba cualquier modelo con comandos sencillos como "Muéstrame Génesis 1:1" para verificar el soporte de herramientas.
