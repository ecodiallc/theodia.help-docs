---
title: Comandos
level: everyday
categories: [layout, study]
summary: El comando rápido te permite saltar a cualquier función de Theodia escribiendo un comando corto. Aprende los formatos admitidos y ejemplos.
---

# Comandos

El comando **Comando rápido** te permite saltar a casi cualquier parte de Theodia escribiendo una instrucción corta. Puedes usarlo desde la pestaña **Inicio** o desde el **Menú rápido** (el icono **▼** del encabezado).

## Cómo funciona

1. Toca la caja de comando.
2. Escribe un comando.
3. Toca la tecla de ir en tu teclado.

La app lee el comando y te lleva directamente a la pantalla correcta.

## Sin prefijo de barra

Los comandos **no** usan el prefijo `/`. Se escriben como texto plano:

```
john 3:16
search love
backup
```

Si escribes `/settings`, la barra inicial lo hace irreconocible.

## Referencias bíblicas

Escribe cualquier referencia bíblica para abrirla en el lector.

```
psalms 23
john 3:16
matthew 5:1
1 cor 15:10
```

Los nombres de los libros se reconocen por su nombre completo o abreviatura. En idiomas de interfaz distintos del inglés también puedes escribir los nombres de los libros en el idioma activo.

## Búsqueda

```
search abraham
search love
search faith not works
```

## Marcador, comparar, comentario, referencias cruzadas e información de palabra

```
bookmark john 3:16
compare genesis 1:1
commentary john 1
aicommentary eph 2:8
xref 1 cor 15:10
word info john 1:1
```

Estos comandos abren la herramienta indicada para el pasaje dado.

## Léxico

Escribe un número de Strong para abrir la entrada del léxico.

```
g1161
h7225
```

## Devocionales

```
devotional
devotional smith
devotional daily
```

Sin nombre, abre la lista de devocionales.

## Atajos de navegación

```
notes
highlights
bookmarks
flashcards
playlist
theoscript
resources
read john 3:16
```

Estos saltan directamente a la pantalla indicada o abren un pasaje en el lector.

## Cambio de traducción

Escribe la abreviatura de una traducción para cambiar a ella.

```
kjv
web
trlit
ohgb
```

En la pantalla del lector, la traducción se cambia en el lugar. En cualquier otro sitio, abre la traducción en tu pasaje más reciente.

## Comandos localizados

Los verbos de comando públicos se pueden escribir en el idioma activo de la interfaz **o** en inglés. El inglés siempre funciona como respaldo. Los comandos ocultos (atajos de configuración, comandos de instalación, huevos de Pascua) mantienen solo la sintaxis en inglés.

## Ayuda

Escribe `help` o `commands` en la caja de comando para abrir la referencia de comandos integrada en cualquier momento.
