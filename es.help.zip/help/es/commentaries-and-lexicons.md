---
title: Comentarios y léxicos
level: everyday
categories: study
summary: Cómo consultar significados de palabras y leer notas de estudio.
---

# Comentarios y léxicos

> **Modo:** Los comentarios y léxicos requieren el modo **Académico**. Puedes cambiar de modo en **Configuración** → **Modo de usuario de la app**.

Theodia incluye dos herramientas de estudio: **comentarios** y **léxicos**. Te ayudan a entender la Biblia con más profundidad.

## Qué es un comentario?

Un comentario es un libro de notas de estudio escrito por un erudito de la Biblia. Para un versículo dado, un comentario te cuenta el trasfondo, el significado y cómo encaja el versículo en el resto de la Biblia.

## Qué es un léxico?

Un léxico es un diccionario de palabras bíblicas. Te dice la palabra original en hebreo o griego, qué significa y cómo se usa en la Biblia.

## Cómo abrir un comentario

1. Abre un capítulo.
2. Toca un versículo.
3. Toca **Comentario**.

Se abre un panel. Muestra notas de un erudito de la Biblia sobre ese versículo.

## Cómo abrir un léxico

1. Abre un capítulo en una Biblia que incluya números de Strong.
2. Toca un número de Strong en el versículo (por ejemplo, G1234 o H1234).
3. Se abre un panel que muestra la palabra original en hebreo o griego, su significado y otros versículos que usan la palabra.

Los números de Strong aparecen en un color diferente en el texto del versículo para destacar de las palabras normales.

## Elegir otro comentario

El comentario se elige desde una lista desplegable en la parte superior del propio panel de comentario. Abre el panel y luego toca la lista desplegable para ver los comentarios que tienes instalados. Elige otro.

## Elegir otro léxico

El léxico se elige desde una lista desplegable en la parte superior del panel de léxico. Abre el panel y luego toca la lista desplegable para ver los léxicos que tienes instalados. Elige otro.

## Recursos incorporados

Theodia incluye un conjunto incorporado de comentarios y léxicos. Van con la app y funcionan sin conexión. No se pueden instalar ni descargar comentarios y léxicos adicionales por separado.

## Cuándo usarlos

- Los **comentarios** son útiles cuando un versículo es difícil de entender. Las notas te dan contexto.
- Los **léxicos** son útiles para estudios de palabras. Te dicen el significado exacto de una palabra en el idioma original.

## Consejo

Si un versículo tiene una nota que quieres conservar, toma una captura de pantalla o copia el texto en una nota. (Consulta la guía [Escribir notas](theodia://help/notes).)

## Diccionario bíblico en lenguaje sencillo

Para definiciones en inglés de palabras y conceptos bíblicos (pacto, expiación, fariseos, etc.), Theodia también incluye una herramienta de Diccionario bíblico. Ábrela desde el menú de versículo tocando **Diccionario** (📖). Es diferente del léxico: los léxicos explican las palabras originales en hebreo y griego, mientras que el diccionario explica la palabra en inglés en lenguaje sencillo. Consulta la guía [Diccionario bíblico](theodia://help/dictionary) para saber cómo usarlo.
