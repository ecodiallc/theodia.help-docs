---
title: Solución de problemas comunes
level: everyday
categories: trouble
summary: Soluciones rápidas para los problemas más frecuentes.
---

# Solución de problemas comunes

Esta guía cubre los problemas más frecuentes. Si el tuyo no está aquí, consulta la guía [Dónde pedir ayuda](theodia://help/getting-more-help).

## La app va lenta

1. Cierra otras apps en segundo plano.
2. Reinicia la app.
3. Reinicia tu dispositivo.

## No encuentro una traducción de la Biblia

1. Abre **Configuración** → **Gestionar recursos** para ver qué tienes instalado.
2. Si la traducción no está allí, toca **Instalar desde GitHub**.
3. En la ventana de descarga, toca la pestaña **Biblias** (o **Biblias globales**) y selecciona la traducción que quieras.
4. Toca **Instalar seleccionados** y espera a que termine la descarga.
5. Necesitas internet para descargar una traducción nueva.

## Mis notas o marcadores desaparecieron

1. Comprueba que estás en la pestaña correcta. Las notas están en la pestaña **Notas bíblicas**. Los marcadores están en la pestaña **Marcadores**.
2. Si restauraste una copia de seguridad recientemente, la copia puede haber reemplazado tus datos. Comprueba la fecha de la copia.
3. Si desinstalaste y volviste a instalar la app, tus datos se perdieron. La próxima vez, haz una copia de seguridad primero.

## La búsqueda no encuentra versículos

1. Asegúrate de que escribiste la palabra correctamente.
2. Prueba con una palabra más corta. "love" encuentra más versículos que "loving".
3. Asegúrate de tener instalada la traducción correcta. La búsqueda solo funciona en las traducciones que tienes.

## La lectura en voz alta no funciona

1. Asegúrate de que el volumen del dispositivo esté subido.
2. Asegúrate de que la app tenga permiso para usar el altavoz.
3. Prueba con otra traducción. Algunas traducciones funcionan mejor con lectura en voz alta que otras.
4. Para una lista de verificación paso a paso, consulta la guía [Lectura en voz alta](theodia://help/tts).

## La app se cierra repetidamente

1. Reinicia la app.
2. Reinicia tu dispositivo.
3. Si el problema persiste, repórtalo. Consulta la guía [Dónde pedir ayuda](theodia://help/getting-more-help).

## Quiero desinstalar la app

Puedes desinstalar Theodia como cualquier otra app. Antes, haz una copia de seguridad de tus datos. Después de desinstalar, los datos del dispositivo se pierden.

## ¿Sigues atascado?

Consulta la guía [Dónde pedir ayuda](theodia://help/getting-more-help). Allí encontrarás enlaces para reportar un problema y preguntar a la comunidad.

También puedes buscar en las guías de ayuda desde la pantalla principal de **Ayuda y guías**. Escribe una palabra como `notificaciones`, `búsqueda` o `marcadores` para encontrar la guía correspondiente.
