---
title: Comparar traducciones
level: everyday
categories: [read, study]
summary: Cómo ver el mismo versículo en cada traducción que tengas instalada.
---

# Comparar traducciones

> **Modo:** La herramienta **Comparar** está disponible en los modos **Estándar** y **Académico**. El modo de enfoque es solo para lectura limpia y sin distracciones. Puedes cambiar de modo en **Configuración** → **Modo de usuario de la app**.

La herramienta **Comparar** muestra un solo versículo en cada traducción de la Biblia que tengas instalada, todo en un solo panel. Es útil cuando quieres ver cómo distintos traductores manejan un versículo difícil, o cuando eliges una traducción y quieres ver el mismo versículo en cada una.

## Cómo abrir Comparar

1. Abre un capítulo en cualquier traducción.
2. Toca un versículo para mostrar el menú de versículo.
3. Toca **Comparar** (⇄).

Se abre un panel. La barra de título muestra la referencia (por ejemplo, "Juan 3:16 — Comparar"). El panel lista el mismo versículo en cada traducción instalada. Tu traducción actual aparece primero; el resto se ordena alfabéticamente.

## Cómo se ve el panel

El panel es una **lista vertical**, no una columna lado a lado. Cada fila es una traducción:

- El **nombre de la traducción** (por ejemplo, "KJV") está en la parte superior de la fila. Es tocable.
- El **texto del versículo** aparece debajo del nombre.

Desplázate por el panel para ver todas las traducciones. Aparecerá cada traducción instalada en tu dispositivo. Si una traducción no tiene ese libro o versículo, se omite.

## Cómo leer el versículo en otra traducción

Toca el nombre de la traducción en la fila. El panel de Comparar se cierra y se abre el mismo capítulo mostrando el versículo elegido en esa traducción. Esta es la forma más rápida de pasar de una comparación a leer una traducción específica.

## Cómo cerrar Comparar

- **En un teléfono:** toca la X en la parte superior derecha del panel.
- **En una tableta:** toca la X en el encabezado del panel, o toca fuera del panel.

Vuelves a la vista del capítulo en tu traducción original.

## Cuándo usar Comparar

- **Elegir una traducción.** Abre un versículo que conozcas bien en tu traducción actual, luego usa Comparar para verlo en otras. Las diferencias saltan a la vista.
- **Versículos difíciles.** Un versículo confuso en una traducción suele ser más claro en otra.
- **Estudios de palabras.** Observa cómo distintos traductores manejan una palabra o frase clave.

Para una comparación rápida de todo un capítulo en varias traducciones a la vez, usa la **vista paralela** en su lugar. Consulta la guía [Modo de estudio](theodia://help/study-mode) para saber cómo activarla.
