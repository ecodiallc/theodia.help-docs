---
title: Crear tus propios recursos
level: advanced
categories: resources
summary: Cómo crear Biblias, comentarios, libros, devocionales y léxicos personalizados e importarlos en Theodia.
---

# Crear tus propios recursos

Theodia admite recursos personalizados en el formato de Unique Bible App. Cada recurso es un archivo SQLite con una estructura de tablas específica. Puedes crear estos archivos en una computadora y luego importarlos en la app.

## Tipos de archivo y tablas requeridas

### Biblias (`.bible`)

Un archivo de Biblia es una base de datos SQLite con al menos una de estas tablas:

- **`Verses`** — columnas: `Book` (entero, 1-66), `Chapter` (entero), `Verse` (entero), `Scripture` (texto)
- **`Bible`** — columnas: `Book` (entero), `Chapter` (entero), `Verse` (entero), `Scripture` (texto)

También puedes incluir una tabla **`Details`** con columnas de metadatos como `Description`, `Abbreviation` y `Version`.

Ejemplo de SQL:

```sql
-- Tabla principal de texto
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- Tabla opcional de metadatos
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### Comentarios (`.commentary`)

Los comentarios vienen en tres tipos: **libro**, **capítulo** y **versículo**. El tipo se determina por la **primera letra del nombre del archivo**.

#### Comentarios de libro — el nombre empieza con `b`

Un comentario de libro cubre un libro bíblico completo en una sola entrada. La tabla `Commentary` necesita las columnas `Book` y `Scripture` (o `Content`). No se necesitan columnas `Chapter` ni `Verse`.

- **`Commentary`** — columnas: `Book` (entero), `Scripture` (texto) o `Content` (texto)

Ejemplo de SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

Ejemplo de nombre: `bMyCommentary.commentary`

#### Comentarios de capítulo — el nombre empieza con `c`

Un comentario de capítulo cubre cada capítulo de un libro bíblico.

- **`Commentary`** — columnas: `Book` (entero), `Chapter` (entero), `Scripture` (texto) o `Content` (texto)

Ejemplo de SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

Ejemplo de nombre: `cMyCommentary.commentary`

#### Comentarios de versículo — el nombre empieza con `v`

Un comentario de versículo cubre versículos individuales. La tabla `Commentary` necesita las columnas `Book`, `Chapter`, `Verse` y `Scripture` (o `Content`).

- **`Commentary`** — columnas: `Book` (entero), `Chapter` (entero), `Verse` (entero), `Scripture` (texto) o `Content` (texto)

Ejemplo de SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

Ejemplo de nombre: `vMyCommentary.commentary`

### Libros (`.book`)

Un archivo de libro es una base de datos SQLite con una tabla `Reference`.

- **`Reference`** — columnas: `id` (entero), `Chapter` (texto), `Content` (texto)

Cada fila es un capítulo. La columna `Chapter` es el título del capítulo. La columna `Content` es el cuerpo del capítulo, que puede incluir HTML (`<b>`, `<i>`, `<br>`, etc.).

Ejemplo de SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

También puedes crear libros desde archivos Markdown. La app puede importar archivos `.md` donde `#` es el título del libro y `##` marca los capítulos. El Markdown se convierte a HTML automáticamente.

### Devocionales (`.devotional`)

Un archivo devocional es una base de datos SQLite con una tabla `devotional`.

- **`devotional`** — columnas: `month` (entero, 1-12), `day` (entero, 1-31), `devotion` (texto)

Cada fila es la lectura de un día. La app busca la entrada según el mes y día actual.

Ejemplo de SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### Léxicos (`.lexicon`)

Un archivo de léxico es una base de datos SQLite con una tabla `Lexicon`.

- **`Lexicon`** — columnas: `Topic` (texto, el número de Strong), `Definition` (texto, la entrada del léxico)

La columna `Topic` contiene el número de Strong (por ejemplo, `G1161` o `H7225`). La columna `Definition` contiene el texto completo de la entrada, que puede incluir HTML.

Ejemplo de SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

Los léxicos potencian la herramienta Información de la palabra. Cuando tocas una palabra en una Biblia interlineal, la app busca el número de Strong en los léxicos instalados.

## Crear un archivo en tu computadora

1. Instala un editor de SQLite (DB Browser for SQLite, SQLiteStudio o la herramienta de línea de comandos `sqlite3`).
2. Crea un nuevo archivo de base de datos.
3. Crea la tabla requerida e inserta tus datos.
4. Guarda el archivo con la extensión correcta (`.bible`, `.commentary`, `.book`, `.devotional` o `.lexicon`).

## Importar en Theodia

1. Transfiere el archivo a tu dispositivo (AirDrop, correo, almacenamiento en la nube o USB).
2. Abre **Theodia**.
3. Ve a **Configuración** → **Gestionar recursos**.
4. Toca **Importar desde archivo**.
5. Selecciona tu archivo.

La app valida el archivo (comprueba que tenga la tabla requerida), lo copia a la carpeta de datos de la app y lo activa automáticamente. Si el archivo no es válido, verás un mensaje de error explicando qué está mal.

## Limitaciones

- No puedes sobrescribir recursos incorporados. Si intentas importar un archivo con el mismo nombre que una Biblia, comentario o libro incorporado, la importación fallará.
- Los archivos de Biblia necesitan una tabla `Verses` o `Bible`. Si no existe ninguna, la importación falla.
- Los archivos de comentario necesitan una tabla `Commentary`.
  - Los comentarios de libro necesitan las columnas `Book` y `Scripture` (o `Content`).
  - Los comentarios de capítulo necesitan las columnas `Book`, `Chapter` y `Scripture` (o `Content`).
  - Los comentarios de versículo necesitan las columnas `Book`, `Chapter`, `Verse` y `Scripture` (o `Content`).
- Los archivos de libro necesitan una tabla `Reference`.
- Los archivos de léxico necesitan una tabla `Lexicon`.
- Los archivos devocionales necesitan una tabla `devotional`.

## Consejos

- Mantén los tamaños de archivo razonables. Archivos SQLite muy grandes pueden causar problemas de memoria en dispositivos antiguos.
- Prueba tu archivo primero en una computadora. Ábrelo en un navegador de SQLite y ejecuta `SELECT * FROM` la tabla requerida para verificar que los datos se vean bien.
- Para Biblias, asegúrate de que la columna `Book` use números (1 = Génesis, 66 = Apocalipsis).
- Para Comentarios, puedes usar `Scripture` o `Content` como columna de texto del comentario.
- Para Libros, el HTML en la columna `Content` se renderiza al leer. Mantenlo simple: `<b>`, `<i>`, `<br>` y `<hr>` son seguros.

## Dónde encontrar recursos existentes

Theodia puede leer recursos del proyecto [Unique Bible App](https://github.com/eliranwong/UniqueBible). Hay muchas Biblias, comentarios, libros y otros recursos disponibles allí en el formato SQLite correcto. Consulta la guía [Obtener recursos adicionales](theodia://help/getting-core-files) para saber cómo encontrarlos y añadirlos.
