---
title: Referencias cruzadas
level: everyday
categories: study
summary: Cómo encontrar versículos que se conectan con el que estás leyendo.
---

# Referencias cruzadas

> **Modo:** Las referencias cruzadas están disponibles en los modos **Estándar** y **Académico**. El modo de enfoque es solo para lectura limpia y sin distracciones. Puedes cambiar de modo en **Configuración** → **Modo de usuario de la app**.

Una "referencia cruzada" es otro versículo que habla de lo mismo que el versículo que estás leyendo. El panel de referencias cruzadas te muestra qué versículos de la Biblia se conectan entre sí.

## Cómo abrir las referencias cruzadas

1. Abre un capítulo.
2. Toca un versículo para mostrar el menú.
3. Toca **Referencias cruzadas**.

Se abre un panel. Muestra una lista de otros versículos que se conectan con el que tocaste.

## Cómo leer la lista

Cada fila es un versículo conectado. Ves:

- El libro, capítulo y versículo.
- Una breve vista previa del texto del versículo.
- Una puntuación que indica qué tan fuerte es la conexión.

## Cómo saltar a un versículo conectado

Toca cualquier fila. La app abre ese versículo para ti. Cuando termines, toca el botón de atrás para volver.

## Qué significa la puntuación

La puntuación te dice qué tan estrechamente están conectados los versículos. Una puntuación alta significa una conexión fuerte y directa. Una puntuación baja significa una conexión más débil.

## Usar referencias cruzadas para estudiar

Las referencias cruzadas son útiles para:

- **Estudios de palabras.** Ver cómo la Biblia usa una palabra en distintos lugares.
- **Estudios de temas.** Seguir un tema, como "amor" o "pacto", a través de la Escritura.
- **Preparación de sermones.** Encontrar versículos de apoyo rápidamente.

## Consejo

Las referencias cruzadas funcionan mejor con una traducción palabra por palabra como WEB.
