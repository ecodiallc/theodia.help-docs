---
title: Devocionales diarios
level: everyday
categories: [content, read]
summary: Cómo leer una breve meditación cada día.
---

# Devocionales diarios

Un devocional es una breve lectura para un día. Suele tener un versículo, una breve reflexión y una pregunta para pensar. Theodia viene con una pequeña biblioteca de devocionales.

## Cómo abrir un devocional

1. Toca la pestaña **Devocionales** en la parte inferior de la pantalla.
2. Ves una lista de los devocionales instalados en tu dispositivo.
3. Toca uno para abrirlo.

## Cómo leer un devocional

1. Abre el devocional.
2. Desplázate para leer.
3. Usa los botones de la parte superior para:
   - Tocar la **fecha** para saltar a otro día.
   - Tocar la **estrella** para guardar el día como marcador.
   - Tocar el **altavoz** para escucharlo en voz alta (si tu dispositivo lo admite). Consulta la guía [Lectura en voz alta](theodia://help/tts) para saber cómo elegir una voz.
   - Tocar **Anterior** o **Siguiente** para ir al día anterior o siguiente.

## Cómo guardar un versículo de un devocional

1. Abre el devocional.
2. Toca un versículo.
3. Toca **Marcador** o **Resaltar**.

El versículo se guarda en tus Marcadores o Resaltados.

## Cómo escribir una nota en un devocional

1. Abre el devocional.
2. Toca un versículo.
3. Toca **Nota bíblica**. Escribe tu reflexión oración. Toca **Guardar**.

La nota aparece en tu pestaña de Notas bíblicas.

## Consejos

- Los devocionales no necesitan internet. Funcionan sin conexión.
- Si quieres más devocionales, consulta la guía [Obtener recursos adicionales desde GitHub](theodia://help/getting-core-files).
