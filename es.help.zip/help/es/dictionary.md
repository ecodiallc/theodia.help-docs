---
title: Diccionario bíblico
level: everyday
categories: study
summary: Busca palabras y conceptos bíblicos en los recursos de diccionario instalados. Ábrelo desde el menú de versículo o desde una entrada del léxico, luego toca cualquier palabra para ver la misma palabra en cada diccionario.
---

# Diccionario bíblico

> **Modo:** El diccionario bíblico requiere el modo **Académico**. Puedes cambiar de modo en **Configuración** → **Modo de usuario de la app**.

La herramienta de Diccionario bíblico busca una palabra o frase en cada recurso de diccionario que tengas instalado. Es útil cuando quieres una definición en lenguaje sencillo de una palabra bíblica, una descripción de una persona o lugar, o un breve artículo sobre un concepto teológico.

El Diccionario bíblico es diferente de la herramienta **Información de la palabra**, que busca la palabra original en hebreo o griego detrás de un versículo. El diccionario lee la palabra en **inglés** que tocas y te muestra lo que tus diccionarios instalados dicen sobre ella. Para notas de traducción bíblica palabra por palabra, consulta la guía [Comentarios y léxicos](theodia://help/commentaries-and-lexicons).

## Cómo abrir el diccionario

Hay dos formas de abrir el diccionario.

### Desde el menú de versículo

1. Abre un capítulo en [modo de estudio](theodia://help/study-mode).
2. Toca un versículo para abrir el menú de versículo.
3. Toca **Diccionario** (📖).

Se abre un panel con el título de la referencia del versículo (por ejemplo, "Juan 3:16"). El texto del versículo está en la parte superior con cada palabra tocable. Debajo del versículo hay una franja de chips que muestra cada diccionario instalado. Debajo está la definición, vacía hasta que toques una palabra.

### Desde una entrada del léxico

Cuando lees una entrada del léxico en el panel de Información de la palabra, algunas entradas contienen enlaces azules a artículos relacionados del diccionario. Toca cualquiera de esos enlaces. El léxico se cierra y el diccionario se abre en ese artículo. Esta es la forma más rápida de saltar de una palabra griega o hebrea a una explicación en lenguaje sencillo de lo que significa.

## Cómo funciona la vista del versículo

Cuando abres el diccionario desde el menú de versículo, el versículo aparece en la parte superior del panel como una lista de palabras tocables. Las palabras comunes en inglés como "the", "and", "of", "to" y "a" no son tocables. Todas las demás sí. Cada palabra tocable está coloreada y en negrita para destacar del resto del versículo.

Toca cualquier palabra del versículo. Theodia busca en cada diccionario instalado una coincidencia exacta con esa palabra. La franja de chips de la parte inferior se actualiza para mostrar qué diccionarios tienen una entrada: los diccionarios que no tienen una entrada para esa palabra aparecen atenuados. El primer diccionario con una entrada se selecciona automáticamente y su definición aparece debajo de la franja de chips.

La palabra que tocaste se resalta en el texto del versículo en la parte superior del panel, así que siempre sabes qué estás consultando.

## Cambiar entre diccionarios

Cada diccionario instalado aparece como un pequeño chip debajo del versículo. Después de tocar una palabra:

- Un chip de **color sólido** significa que este diccionario tiene una entrada para la palabra que tocaste. Tócalo para cambiar a la definición de ese diccionario.
- Un chip **atenuado** significa que este diccionario no tiene una entrada para esa palabra. Aparece atenuado para que veas de un vistazo qué diccionarios cubren la palabra, y no se puede tocar.

El diccionario seleccionado está resaltado. Toca cualquier otro chip sólido para leer la misma palabra en ese diccionario. La definición de abajo se actualiza inmediatamente.

Si la palabra existe solo en uno de tus diccionarios instalados, solo ese chip es sólido y los demás están atenuados.

## Qué muestra el panel

El panel del diccionario tiene tres partes, de arriba abajo:

- **El versículo** — el versículo desde el que abriste el diccionario. Las palabras son tocables, y la palabra que tocaste más recientemente está resaltada.
- **La franja de chips** — cada diccionario instalado. Sólido significa "tiene una entrada para la palabra tocada". Atenuado significa "no tiene entrada para esa palabra".
- **La definición** — el artículo del diccionario seleccionado. Texto plano, formateado con párrafos y encabezados. Los enlaces internos a otras entradas del diccionario son tocables; tocar uno abre esa entrada en el diccionario.

## Qué pasa si no se encuentra ninguna entrada

Si tocas una palabra que ninguno de tus diccionarios instalados cubre, el panel muestra un breve mensaje de "no se encontraron entradas" en lugar de una definición. Esto es común para palabras muy comunes como "year" o "come" que no son realmente palabras de teología bíblica, aunque aparezcan por toda la Biblia. Prueba con una palabra más específica, o usa la herramienta Información de la palabra del léxico, que funciona sobre el texto griego o hebreo subyacente.

## Qué pasa si no hay ningún diccionario instalado

El diccionario necesita al menos un archivo de recurso de diccionario para ser útil. Theodia incluye uno. Si lo eliminaste o estás ejecutando una instalación personalizada sin diccionarios, la vista del versículo sigue apareciendo y las palabras siguen siendo tocables, pero la franja de chips está vacía y cada búsqueda devuelve "no se encontraron entradas".

No se pueden instalar diccionarios adicionales por separado.

## Consejos

- El diccionario busca **coincidencias exactas de palabras**. Tocar "love" encuentra entradas tituladas "love" pero no "loved" ni "loving". Para buscar una forma relacionada, usa la herramienta Información de la palabra del léxico sobre la palabra griega o hebrea.
- La franja de chips es la misma en teléfonos y tabletas. En una tableta el diccionario se abre como un panel lateral junto al capítulo; en un teléfono se abre como una pantalla completa modal. Ambos tienen el mismo diseño de tres partes.
- Tocar una palabra en un versículo diferente abre un nuevo versículo en el panel. Tu selección anterior se borra. Toca una palabra en el nuevo versículo para empezar una nueva consulta.
- Algunas entradas del diccionario hacen referencia a la misma palabra en otro diccionario. Toca esos enlaces internos para seguir el rastro entre todos tus diccionarios instalados.

## Diferencias entre Diccionario e Información de la palabra

Ambas herramientas se abren desde el menú de versículo, pero hacen cosas diferentes:

- **Diccionario** (📖) lee la palabra en inglés que tocas y la busca en tus diccionarios en inglés instalados. Es la herramienta adecuada para definiciones en lenguaje sencillo de palabras de teología bíblica como "covenant", "atonement" o "Pharisee".
- **Información de la palabra** (?) lee la palabra griega o hebrea original detrás del versículo y la busca en tus léxicos instalados. Es la herramienta adecuada para estudios serios de palabras, encontrar cada lugar donde se usa una palabra griega, y leer definiciones en el idioma original.

En caso de duda, empieza con el diccionario. Si quieres profundizar en el idioma original, cambia a Información de la palabra. Consulta la guía [Comentarios y léxicos](theodia://help/commentaries-and-lexicons) para el recorrido completo de Información de la palabra.

## Guías relacionadas

- La guía [Modo de estudio](theodia://help/study-mode) explica con detalle el menú de versículo y dónde se sitúa la herramienta Diccionario (📖) junto a Marcador, Resaltar, Hablar, Comparar, Referencias cruzadas, Comentario de IA, Información de la palabra y Notas bíblicas.
- La guía [Comentarios y léxicos](theodia://help/commentaries-and-lexicons) cubre Información de la palabra y los léxicos del idioma original.
- La guía [Qué son los recursos](theodia://help/what-are-resources) explica los distintos tipos de archivos que usa Theodia, incluidos los recursos de diccionario.
- La guía [Solución de problemas comunes](theodia://help/common-problems) tiene soluciones para resultados vacíos y otros problemas del diccionario.
