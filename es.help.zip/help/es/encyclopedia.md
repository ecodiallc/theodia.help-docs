---
title: Enciclopedia
level: everyday
categories: study
summary: Cómo buscar artículos de enciclopedia y explorar obras de referencia.
---

# Enciclopedia

Theodia incluye una **Enciclopedia** integrada para consultar artículos relacionados con la Biblia, personas, lugares y temas. La app incluye _Kitto's Illustrated Commentary_ (KIT) incorporado, y puedes descargar enciclopedias adicionales desde el repositorio.

## Qué es una enciclopedia en Theodia?

Una enciclopedia es una obra de referencia compuesta por artículos cortos. Cada artículo cubre una persona, lugar, evento o tema bíblico. A diferencia de un comentario, que explica un versículo específico, un artículo de enciclopedia explica el tema en sí.

## Cómo abrir la Enciclopedia

1. Toca **Enciclopedia** en la barra inferior.
2. Elige una enciclopedia de la fila de abreviaturas de la parte superior.
3. Escribe un tema, persona o lugar en la caja de búsqueda.

La búsqueda requiere al menos **3 caracteres** antes de que aparezcan resultados y sugerencias de autocompletado.

## Leer un artículo

- En **teléfono**, toca cualquier resultado para abrir el artículo en una pantalla nueva.
- En **tableta**, el artículo se abre en el panel de la derecha mientras la lista permanece a la izquierda.

## Seleccionar enciclopedias

Toca un chip de abreviatura (como **KIT**) para cambiar a esa enciclopedia. Para buscar en varias enciclopedias a la vez, usa la pestaña **Buscar** y selecciona **Enciclopedia** como modo de búsqueda.

## Obtener más enciclopedias

1. Abre **Configuración**.
2. Toca **Gestionar recursos**.
3. Toca **Instalar desde GitHub**.
4. Selecciona la pestaña **Enciclopedias**.
5. Toca el botón de descarga junto a la enciclopedia que quieras.

Las enciclopedias se descargan desde el repositorio de GitHub de Theodia y se instalan automáticamente. Las enciclopedias instaladas aparecen en la pantalla de Enciclopedia y en Buscar.

También puedes instalar una enciclopedia desde un archivo local: en **Gestionar recursos**, toca **Instalar archivo local** y elige un archivo `.encyclopedia`. El archivo se copia en la carpeta de enciclopedias de la app y se añade al índice compartido de búsqueda.

## Mantener presionado para ver el título completo

En la pantalla de Buscar, los chips de enciclopedia muestran abreviaturas cortas. Mantén presionado un chip para ver el nombre completo de la enciclopedia.

## Cuándo usar la Enciclopedia

- Busca una persona, lugar o tema antes o mientras lees un pasaje.
- Obtén trasfondo sobre una palabra o concepto bíblico que abarca muchos versículos.
- Lee junto a un comentario para un estudio más profundo.
