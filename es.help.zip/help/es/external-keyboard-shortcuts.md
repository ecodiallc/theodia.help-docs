---
title: Atajos de teclado externo
level: everyday
categories: [tablet, settings]
summary: Referencia completa de atajos de teclado para iPad con teclado externo conectado.
---

# Atajos de teclado externo

Si usas Theodia en iPad con un teclado externo (Magic Keyboard, teclado Bluetooth o USB), puedes navegar la app sin tocar la pantalla.

> **Modo:** Algunos atajos solo funcionan cuando la función correspondiente está disponible en tu modo de usuario actual. Por ejemplo, `Cmd + Option + 6` (Marcadores) y `Cmd + Option + 7` (Resaltados) no hacen nada en el modo Lector. Cambia de modo en **Configuración** → **Modo de usuario de la app**.

Los atajos funcionan en **iPad**.

## Atajos globales (en cualquier parte)

| Atajo              | Acción                                              |
| ------------------ | --------------------------------------------------- |
| `Cmd + /`          | Mostrar esta ayuda de atajos de teclado             |
| `Cmd + .`          | Cerrar modal / panel (alternativa a Escape)         |
| `Cmd + Option + 1` | Ir a la pestaña Inicio                              |
| `Cmd + Option + 2` | Ir a la pestaña Biblias                             |
| `Cmd + Option + 3` | Ir a la pestaña Libros                              |
| `Cmd + Option + 4` | Ir a la pestaña Devocionales                        |
| `Cmd + Option + 5` | Ir a la pestaña Buscar                              |
| `Cmd + Option + 6` | Ir a la pestaña Marcadores (Estándar y Académico)   |
| `Cmd + Option + 7` | Ir a la pestaña Resaltados (Estándar y Académico)   |
| `Cmd + Option + 8` | Ir a la pestaña Notas bíblicas (Estándar y Académico) |
| `Cmd + Option + 9` | Ir a la pestaña IA (solo Académico, si está activada) |
| `Cmd + Option + 0` | Ir a la pestaña Ayuda                               |
| `Cmd + Option + I` | Ir a la pestaña Acerca de                           |
| `Cmd + [`          | Volver atrás                                        |
| `Cmd + F`          | Abrir búsqueda                                      |
| `Cmd + K`          | Abrir menú rápido (Académico)                      |
| `Cmd + ,`          | Abrir configuración                                 |
| `Cmd + Shift + M`  | Abrir menú rápido                                   |
| `Cmd + Shift + T`  | Alternar tema (predeterminado / oscuro)           |
| `Cmd + Shift + U`  | Abrir selector de modo de usuario                 |
| `Escape`           | Cerrar modal / panel                                |

## Atajos del lector bíblico

Funcionan tanto en el **Lector de estudio** como en el **Lector de enfoque**.

| Atajo              | Acción                                                          |
| ------------------ | --------------------------------------------------------------- |
| `← Left Arrow`     | Capítulo anterior                                               |
| `→ Right Arrow`    | Capítulo siguiente                                              |
| `Cmd + R`          | Alternar entre estudio y enfoque (Estándar y Académico)         |
| `Cmd + Option + V` | Abrir selector de versión                                       |
| `Cmd + Option + B` | Abrir selector de libro                                         |
| `Cmd + Option + C` | Abrir selector de capítulo                                      |
| `Cmd + T`          | Alternar texto a voz (detener si está sonando/pausado, empezar si está inactivo) |
| `Cmd + Option + T` | Reproducir / Pausar texto a voz                                |

## Solo lector de estudio

| Atajo              | Acción                                                                  |
| ------------------ | ----------------------------------------------------------------------- |
| `↑ Up Arrow`       | Seleccionar versículo anterior                                          |
| `↓ Down Arrow`     | Seleccionar versículo siguiente                                         |
| `Cmd + ↑`          | Seleccionar primer versículo                                            |
| `Cmd + ↓`          | Seleccionar último versículo                                            |
| `Cmd + ←`          | Saltar al capítulo 1                                                    |
| `Cmd + →`          | Saltar al último capítulo                                               |
| `Cmd + 0`–`9`      | Salto directo a versículo (escribe dígitos, p. ej. `Cmd + 1` `Cmd + 6` para el versículo 16) |
| `Cmd + P`          | Alternar Biblias paralelas (Estándar y Académico)                     |
| `Cmd + B`          | Guardar marcador del versículo seleccionado (Estándar y Académico)     |
| `Cmd + H`          | Resaltar versículo seleccionado (Estándar y Académico)                  |
| `Cmd + N`          | Añadir nota al versículo seleccionado (Estándar y Académico)            |
| `Cmd + C`          | Comparar traducciones del versículo seleccionado (Estándar y Académico) |
| `Cmd + X`          | Abrir referencias cruzadas del versículo seleccionado (Estándar y Académico) |
| `Cmd + I`          | Abrir información de palabra (Académico)                                |
| `Cmd + D`          | Abrir diccionario del versículo seleccionado (Académico)                |
| `Cmd + A`          | Abrir panel de IA del versículo seleccionado (Académico)                |
| `Cmd + Option + S` | Alternar títulos de sección                                             |
| `Cmd + Option + W` | Cerrar todos los paneles de estudio abiertos                            |
| `Cmd + Option + M` | Abrir menú de acciones del versículo                                    |

## Solo lector de enfoque

| Atajo          | Acción                  |
| -------------- | ----------------------- |
| `↑ Up Arrow`   | Desplazar hacia arriba  |
| `↓ Down Arrow` | Desplazar hacia abajo   |
| `Cmd + ↑`      | Desplazar al inicio     |
| `Cmd + ↓`      | Desplazar al final      |
| `Cmd + =`      | Ampliar                 |
| `Cmd + -`      | Reducir                 |

## Búsqueda

| Atajo              | Acción                              |
| ------------------ | ----------------------------------- |
| `Return`           | Ejecutar búsqueda                   |
| `Cmd + Return`     | Borrar búsqueda y enfocar entrada   |
| `Cmd + ↑`          | Desplazar resultados hacia arriba   |
| `Cmd + ↓`          | Desplazar resultados hacia abajo    |
| `Cmd + Option + A` | Seleccionar todos los elementos del ámbito |
| `Cmd + Option + C` | Deseleccionar todos los elementos del ámbito |
| `Cmd + Option + B` | Modo de búsqueda bíblica            |
| `Cmd + Option + O` | Modo de búsqueda de libros           |
| `Cmd + Option + D` | Modo de búsqueda de diccionario (Académico) |
| `Cmd + Option + X` | Modo de búsqueda de léxico (Académico) |

## Resultados de búsqueda

| Atajo     | Acción                      |
| --------- | --------------------------- |
| `Cmd + S` | Abrir hoja de guardar todo  |
| `Cmd + ↑` | Desplazar resultados hacia arriba |
| `Cmd + ↓` | Desplazar resultados hacia abajo  |

## Lector de libros

| Atajo              | Acción                      |
| ------------------ | --------------------------- |
| `← Left Arrow`     | Capítulo anterior           |
| `→ Right Arrow`    | Capítulo siguiente          |
| `Cmd + ↑`          | Capítulo anterior           |
| `Cmd + ↓`          | Capítulo siguiente          |
| `↑ Up Arrow`       | Desplazar hacia arriba      |
| `↓ Down Arrow`     | Desplazar hacia abajo       |
| `Cmd + B`          | Guardar marcador del capítulo actual |
| `Cmd + J`          | Abrir selector de capítulo  |
| `Cmd + L`          | Abrir selector de voz       |
| `Cmd + T`          | Alternar texto a voz        |
| `Cmd + Option + T` | Reproducir / Pausar texto a voz |

## Lector devocional

| Atajo              | Acción                       |
| ------------------ | ---------------------------- |
| `← Left Arrow`     | Día anterior                 |
| `→ Right Arrow`    | Día siguiente                |
| `↑ Up Arrow`       | Desplazar hacia arriba       |
| `↓ Down Arrow`     | Desplazar hacia abajo        |
| `Cmd + ↑`          | Desplazar hacia arriba (grande) |
| `Cmd + ↓`          | Desplazar hacia abajo (grande) |
| `Cmd + D`          | Abrir selector de fecha      |
| `Cmd + T`          | Alternar texto a voz         |
| `Cmd + Option + T` | Reproducir / Pausar texto a voz |

## Chat de IA

| Atajo              | Acción                          |
| ------------------ | ------------------------------- |
| `Cmd + Return`     | Enviar mensaje                  |
| `Cmd + N`          | Nuevo chat                      |
| `Cmd + D`          | Alternar cajón de conversaciones |
| `Cmd + Option + C` | Borrar chat actual              |
| `Cmd + S`          | Abrir menú de guardar           |
| `Escape`           | Cerrar cajón / menú             |

## Marcadores

| Atajo                         | Acción                                  |
| ----------------------------- | --------------------------------------- |
| `↑ Up Arrow` / `↓ Down Arrow` | Seleccionar marcador                    |
| `Return`                      | Abrir marcador (tableta: seleccionar)   |
| `Cmd + R`                     | Leer marcador en contexto               |
| `Cmd + M`                     | Mover marcador seleccionado a carpetas  |
| `Cmd + N`                     | Gestionar carpetas                      |
| `Escape`                      | Cerrar panel de detalle / selector de carpetas |

En el selector de **Mover a carpeta**, `↑ Up Arrow` / `↓ Down Arrow` mueve la selección, `Return` alterna la carpeta seleccionada o activa la acción resaltada, y `Escape` cierra el selector. La fila **+ Crear carpeta** está en la parte superior de la lista.

## Notas bíblicas

| Atajo                         | Acción                |
| ----------------------------- | --------------------- |
| `↑ Up Arrow` / `↓ Down Arrow` | Seleccionar nota      |
| `Return`                      | Abrir nota            |
| `Cmd + Return`                | Enfocar campo de filtro |
| `Escape`                      | Cerrar detalle / editor |

## Resaltados

| Atajo                         | Acción                |
| ----------------------------- | --------------------- |
| `↑ Up Arrow` / `↓ Down Arrow` | Seleccionar resaltado |
| `Return`                      | Abrir resaltado       |
| `Cmd + Return`                | Enfocar campo de filtro |
| `Escape`                      | Cerrar panel de detalle |

## Lista de Biblias

| Atajo                                    | Acción                              |
| ---------------------------------------- | ----------------------------------- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | Biblia siguiente                    |
| `← Left Arrow` / `↑ Up Arrow`            | Biblia anterior                     |
| `Return`                                 | Abrir Biblia enfocada               |
| `Cmd + Shift + S`                        | Alternar favorito de la Biblia enfocada |
| `Escape`                                 | Volver atrás                        |

## Pantalla de libros de la Biblia

| Atajo                | Acción                      |
| -------------------- | --------------------------- |
| `Tab` / `→ Right Arrow` | Libro siguiente             |
| `← Left Arrow`       | Libro anterior              |
| `↓ Down Arrow`       | Libro de abajo en la cuadrícula |
| `↑ Up Arrow`         | Libro de arriba en la cuadrícula |
| `Cmd + ↓`            | Siguiente sección (AT / NT) |
| `Cmd + ↑`            | Sección anterior (AT / NT)  |
| `Return`             | Abrir libro enfocado        |
| `Escape`             | Volver atrás                |

## Lista de libros

| Atajo                                    | Acción            |
| ---------------------------------------- | ----------------- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | Libro siguiente   |
| `← Left Arrow` / `↑ Up Arrow`            | Libro anterior    |
| `Return`                                 | Abrir libro enfocado |
| `Escape`                                 | Volver atrás      |

## Pantalla de capítulos de la Biblia

| Atajo                                    | Acción                 |
| ---------------------------------------- | ---------------------- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | Capítulo siguiente     |
| `← Left Arrow` / `↑ Up Arrow`            | Capítulo anterior      |
| `Return`                                 | Abrir capítulo enfocado |
| `Escape`                                 | Volver atrás           |

## Pantalla de capítulos de libros

| Atajo                | Acción                       |
| -------------------- | ---------------------------- |
| `Tab` / `↓ Down Arrow` | Capítulo siguiente           |
| `↑ Up Arrow`         | Capítulo anterior            |
| `Return`             | Abrir capítulo enfocado      |
| `Cmd + Return`       | Enfocar entrada de búsqueda/filtro |
| `Escape`             | Volver atrás                 |

## Lista de devocionales

| Atajo                                    | Acción                    |
| ---------------------------------------- | ------------------------- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | Devocional siguiente      |
| `← Left Arrow` / `↑ Up Arrow`            | Devocional anterior       |
| `Return`                                 | Abrir devocional enfocado |
| `Escape`                                 | Volver atrás              |

## Menú rápido (cuando está abierto)

| Atajo          | Acción                       |
| -------------- | ---------------------------- |
| `↑ Up Arrow`   | Elemento de menú anterior    |
| `↓ Down Arrow` | Elemento de menú siguiente   |
| `Return`       | Seleccionar elemento resaltado |
| `Escape`       | Cerrar menú                  |

## Configuración

| Atajo    | Acción                    |
| -------- | ------------------------- |
| `Escape` | Cerrar modal / selector abierto |

## Modales del editor

| Atajo     | Acción            |
| --------- | ----------------- |
| `Cmd + S` | Guardar           |
| `Escape`  | Cancelar / cerrar |

## Guarda de escritura

Cuando estás enfocado en un campo de texto (caja de búsqueda, editor de notas, entrada de IA), los atajos que no usan Cmd, como las flechas y `Espacio`, se suprimen para que no activen navegación accidentalmente. Los atajos que usan `Cmd` (p. ej. `Cmd + S`, `Cmd + B`) siguen funcionando mientras escribes.
