---
title: Preguntas frecuentes
level: everyday
categories: faq
summary: Respuestas a las preguntas más comunes sobre el uso de Theodia.
---

# Preguntas frecuentes

## ¿Theodia cuesta algo?

Theodia es una compra única. No hay suscripción, publicidad, compras dentro de la app ni solicitudes de donaciones. Todos los recursos adicionales disponibles en el catálogo son gratuitos para descargar después de comprar la app.

## ¿Necesito conexión a internet?

No. Una vez instalada la app y sus archivos de datos, todo funciona sin conexión. Puedes leer, buscar, resaltar, tomar notas y usar la mayoría de las herramientas de estudio sin señal.

La única función que necesita internet es descargar recursos nuevos.

## ¿Dónde se almacenan mis datos?

Todos tus marcadores, resaltados, notas y ajustes se guardan en tu dispositivo. No se suben a ningún servidor.

Puedes hacer copias de seguridad manualmente. Consulta la guía [Copias de seguridad de tus datos](theodia://help/backups) para saber cómo.

## ¿Puedo escuchar la Biblia en voz alta?

Sí. Abre cualquier capítulo, toca el menú y elige la opción de lectura en voz alta. Tu dispositivo debe tener instalada una voz de texto a voz. Consulta la guía [Lectura en voz alta](theodia://help/tts) para más información.

## ¿Cómo busco un versículo?

Puedes escribir una referencia como `John 3:16` en el Comando rápido de la pantalla de inicio, o usar la pestaña **Buscar** para buscar por palabra o frase.

## ¿Cómo reporto un error o sugiero una función?

Toca **Enviar sugerencia/problema** en la pantalla Acerca de, [repórtalo en GitHub](https://github.com/ecodiallc/theodia.app/issues/new), o visita la página de [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions).

## ¿Qué dispositivos son compatibles?

Theodia funciona en iPhone, iPad, y teléfonos y tabletas Android. Funciona mejor en dispositivos con al menos 2 GB de almacenamiento libre para los archivos de datos principales.

## ¿Puedo usar un teclado externo?

Sí. Theodia admite teclados Bluetooth y USB en iPad. La navegación, la búsqueda y muchas funciones de lectura tienen atajos de teclado. Consulta la guía [Atajos de teclado externo](theodia://help/external-keyboard-shortcuts) para la lista completa.

## ¿Qué idiomas admite la app?

La interfaz de la app está disponible en inglés, árabe, chino (simplificado y tradicional), checo, danés, neerlandés, filipino, francés, alemán, griego, hebreo, hindi, indonesio, italiano, japonés, coreano, polaco, portugués (Brasil), rumano, ruso, español, sueco, tailandés, turco, ucraniano y vietnamita.

El idioma del texto bíblico depende de las traducciones que tengas instaladas.

## ¿Cómo cambio el idioma?

Ve a **Configuración** y busca la opción de idioma.

## Mi pregunta no está aquí. ¿Dónde puedo obtener más ayuda?

Explora el resto de las guías de ayuda por tema, o haz una pregunta en la comunidad de [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions).

Consejo: En la pantalla principal de **Ayuda y guías**, usa la caja de búsqueda para escribir un tema como `notificaciones` o `búsqueda` y encontrar la guía correspondiente.
