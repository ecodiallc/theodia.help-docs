---
title: Leyendo tu primer capítulo
level: beginner
categories: [start, read]
summary: Un recorrido paso a paso para abrir y leer un capítulo.
---

# Leyendo tu primer capítulo

Esta guía te acompaña en la primera vez que abres un capítulo.

## Paso 1: Abre la pestaña Biblias

Mira la parte inferior de la pantalla. Verás una fila de pestañas. Toca la que dice **Biblias**.

## Paso 2: Elige un libro

Verás una lista de los libros de la Biblia. Génesis es el primero. Juan está cerca del centro. Apocalipsis es el último.

Toca el nombre del libro que quieras.

## Paso 3: Elige un capítulo

Verás los números del 1 hasta la cantidad de capítulos que tenga el libro. Toca el capítulo que quieras.

Se abre el capítulo. Los versículos aparecen en la pantalla.

## Paso 4: Muévete

- Desliza a la **izquierda** para ir al capítulo siguiente.
- Desliza a la **derecha** para volver.

## Paso 5: Interactúa con un versículo

Lo que puedes hacer con un versículo depende de tu modo de usuario.

### Modo Lector

El modo Lector es limpio y sin distracciones.

- Toca un versículo para resaltarlo brevemente.
- No hay herramientas de estudio, marcadores ni menús.
- Si quieres más funciones, cambia al modo **Estándar** o **Académico** en **Configuración**.

### Modo Estándar

El modo Estándar añade funciones cotidianas para el estudio personal de la Biblia.

Toca un versículo para abrir un menú con estas opciones:

- **Marcador** para guardar el versículo.
- **Resaltar** con un color.
- **Añadir nota** al versículo.
- **Copiar** el texto del versículo.
- **Comparar** el versículo en otra traducción.
- **Buscar referencias cruzadas** del versículo.

### Modo Académico

El modo Académico desbloquea todas las herramientas para el estudio profundo de la Biblia.

Toca un versículo para abrir un menú con todo lo del modo Estándar, más:

- **Comentario** del versículo.
- **Información de la palabra** y consultas del idioma original.
- **Diccionario** con definiciones.
- **Asistente de IA** para un estudio más profundo.

Puedes cambiar de modo en cualquier momento en **Configuración**.

## ¿Necesitas ayuda con una herramienta específica?

Cada herramienta tiene su propia guía. Toca **Ayuda** en la pantalla de inicio para verlas todas. La guía [Modo de estudio](theodia://help/study-mode) es un buen punto de partida: recorre cada herramienta del menú de versículo.

Si aún estás aprendiendo dónde está todo, consulta la guía [Diseño y navegación de la app](theodia://help/navigating-the-app). Explica la pantalla de inicio, el menú rápido y la barra inferior.

## ¿Quieres más recursos?

La aplicación incluye varias versiones de la Biblia disponibles libremente. Si quieres añadir más, o añadir comentarios, libros o devocionales, consulta la guía [Obtener recursos adicionales desde GitHub](theodia://help/getting-core-files). Te indica dónde encontrarlos y cómo añadirlos.
