---
title: Modo de enfoque
level: beginner
categories: [layout, read]
summary: Una forma limpia y sin distracciones de leer pasajes largos.
---

# Modo de enfoque

> **Modo:** El modo de enfoque es el lector del modo **Lector**. También está disponible en los modos **Estándar** y **Académico** como alternativa al modo de estudio. Puedes cambiar de modo en **Configuración** → **Modo de usuario de la app**.

El modo de enfoque te permite leer un capítulo bíblico sin botones ni menús en medio. Es bueno para sesiones de lectura largas.

## Cómo activarlo

1. Abre cualquier capítulo.
2. En la fila de iconos de la parte superior, toca el botón **📖**. Abre el mismo capítulo en modo de enfoque.
3. Los menús y botones se ocultan. Solo queda el texto bíblico.

En el modo **Lector**, los capítulos se abren automáticamente en modo de enfoque. El botón **📖** está oculto porque no hay modo de estudio al que cambiar.

## Qué puedes hacer en el modo de enfoque

- **Desplázate** para leer.
- **Desliza** para ir al capítulo siguiente o anterior.
- **Toca el botón 📖** en la barra inferior para volver al modo de estudio. (Oculto en el modo Lector.)
- **Toca el botón 🔊** en la barra inferior para escuchar el capítulo en voz alta. Aparece una mini barra de control con reproducir, pausar, retroceder, avanzar y selector de voz. (Oculto en el modo Lector: el texto a voz requiere Estándar o Académico.)

## Un buen uso para el modo de enfoque

- Leer un libro completo, capítulo por capítulo.
- Leer un pasaje largo para un devocional o un tiempo de quietud.
- Leer en voz alta y seguir el texto sin distracciones.

## Cambiar al modo de estudio

El modo de enfoque oculta todas las herramientas de estudio, pero están a un toque. Toca el botón **📖** en la parte superior de la pantalla para abrir el mismo capítulo en [modo de estudio](theodia://help/study-mode). El modo de estudio es el lector completo, con comentario, referencias cruzadas, consultas de léxico y notas. Para saber qué puede hacer el modo de estudio, consulta la guía [Modo de estudio](theodia://help/study-mode).

En el modo **Lector**, el botón **📖** está oculto porque el modo de estudio no está disponible.
