---
title: Cómo moverse rápidamente
level: beginner
categories: layout
summary: Todas las formas rápidas de saltar a un versículo, capítulo o pantalla en Theodia.
---

# Cómo moverte rápidamente

Esta guía es una hoja de referencia para la navegación. Cubre cada forma rápida de ir de donde estás a donde quieres estar.

## Salta directamente a un versículo

La forma más rápida de abrir cualquier versículo es el **Comando rápido** en la pantalla de inicio.

- Escribe `Juan 3:16` y toca Ir.
- Escribe `Salmos 23` y toca Ir.
- Escribe `Génesis 1` y toca Ir.

La aplicación abre el capítulo exacto (y se desplaza al versículo si lo incluiste).

## Desplázate entre capítulos

Cuando lees un capítulo:

- **Desliza a la izquierda** → capítulo siguiente.
- **Desliza a la derecha** → capítulo anterior.

Esto funciona entre libros. Después de Éxodo 40, deslizar a la izquierda te lleva a Levítico 1.

## Usa la barra superior

Mientras lees, la parte superior muestra la **traducción**, el **libro** y el **capítulo** actuales.

- Toca el nombre de la traducción para cambiar de Biblia.
- Toca el nombre del libro para elegir otro libro.
- Toca el número del capítulo para elegir otro capítulo.

## Salta desde un marcador

Si has guardado un versículo:

1. Abre la pestaña **Marcadores**.
2. Toca cualquier entrada.
3. Irás directamente a ese versículo.

## Salta desde la búsqueda

1. Abre la pestaña **Buscar**.
2. Escribe una palabra o frase.
3. Toca cualquier resultado.
4. La aplicación abre el capítulo y resalta en amarillo tus palabras de búsqueda.

## Cambia de modo de lectura

El lector de la Biblia tiene dos modos:

- **Modo de estudio** — muestra el capítulo con todas las herramientas de estudio a un toque.
- **Modo de enfoque** — oculta todas las herramientas y menús, dejando solo el texto.

Para cambiar: toca el botón **📖** en la parte superior mientras lees. Tócalo de nuevo para volver. (El modo Lector siempre permanece en el modo de enfoque.)

## Usa las pestañas inferiores

La fila de iconos en la parte inferior de la pantalla siempre es visible. Toca cualquier pestaña para cambiar de sección. Las pestañas exactas dependen de tu modo de usuario:

**Todos los modos:**

- **Inicio** — vuelve a la pantalla de inicio.
- **Biblias** — lista de traducciones.
- **Buscar** — búsqueda bíblica.
- **Configuración** — preferencias y recursos.

**Estándar y Académico también ven:**

- **Marcadores** — versículos guardados.
- **Resaltados** — versículos marcados con color.
- **Notas bíblicas** — tus notas privadas.

**Académico también ve:**

- **IA** — el asistente de IA (si está activado en Configuración).

### Recuerda dónde lo dejaste

Cada pestaña guarda su propio historial de navegación. Cuando vuelves a una pestaña, regresas **a donde la dejaste**, no a la pantalla inicial de esa sección.

- Abres la pestaña **Biblias**, eliges una traducción, abres un capítulo y luego cambias a **Buscar**. Más tarde tocas **Biblias** de nuevo y estás de vuelta en ese mismo capítulo.
- Abres la pestaña **Marcadores**, tocas un versículo marcado y luego cambias a **Configuración**. Al tocar **Marcadores** de nuevo vuelves a la lista de marcadores.

Esto aplica a cada pestaña. Cada una recuerda tu lugar hasta que navegues explícitamente a otra pantalla dentro de ella.

### Qué reinicia una pestaña

Una pestaña vuelve a su pantalla raíz solo cuando:

- Ya estás en esa pestaña y tocas el mismo icono de nuevo. Es una forma rápida de reiniciarla.
- La aplicación se cierra forzosamente y se vuelve a abrir.

### Pestañas inferiores vs. menú rápido

- **Pestañas inferiores** — cada pestaña recuerda su propia pila. Tocarla te devuelve a donde la dejaste.
- **Menú rápido** — tocar un elemento navega a esa pantalla. Es una lista desplegable, no una superposición.

Ejemplo:

- Estás leyendo Juan 3. Tocas la pestaña **Marcadores** y luego **Biblias** de nuevo. Vuelves a Juan 3.
- Estás leyendo Juan 3. Abres el menú y tocas **Notas bíblicas**. Revisa tus notas, luego toca la pestaña **Biblias** para volver a Juan 3.

## Consejos

- La pantalla de inicio recuerda qué secciones están expandidas o contraídas.
- Si falta una pestaña, revisa tu **modo de usuario** en **Configuración** → **Modo de usuario de la app**. El modo Lector oculta marcadores, resaltados, notas y la IA. El modo Estándar oculta la IA. También puede que necesites activar una función en **Configuración** o instalar un recurso.
