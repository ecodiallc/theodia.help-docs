---
title: Obtener recursos adicionales
level: everyday
categories: resources
summary: Cómo añadir Biblias, comentarios, libros y otros recursos a Theodia.
---

# Obtener recursos adicionales

Theodia viene con algunos recursos incorporados, pero puedes añadir más. La forma más fácil es a través de la pantalla **Gestionar recursos** dentro de la app.

## Qué puedes añadir

- **Biblias** — más traducciones en distintos idiomas
- **Comentarios** — notas de estudio que explican versículos
- **Libros** — clásicos cristianos y obras de consulta
- **Devocionales** — lecturas devocionales diarias
- **Archivos principales** — archivos de datos más grandes como morfología, referencias cruzadas y la Biblia interlineal Marvel (MIB)

## Cómo añadir recursos desde dentro de la app

1. Abre **Configuración**.
2. Toca **Gestionar recursos**.
3. Elige una pestaña: **Centro**, **Biblias**, **Comentarios**, **Libros** o **Devocionales**.
4. Explora la lista. Toca un recurso para leer más sobre él.
5. Toca la casilla para seleccionar lo que quieres.
6. Toca **Descargar** en la parte inferior. Los archivos se descargan e instalan automáticamente.

Una vez instalado, el recurso aparece en la app de inmediato. No necesitas reiniciar.

## Archivos principales

La pestaña **Centro** tiene archivos de datos grandes que potencian funciones de estudio más profundo. Incluyen:

- Datos de morfología (formas de palabras del idioma original)
- Bases de datos de referencias cruzadas
- La Biblia interlineal Marvel (MIB)

Solo necesitas descargar los archivos principales una vez. Permanecen en tu dispositivo y funcionan sin conexión.

## Biblias globales

La pestaña **Biblias globales** tiene traducciones de la Biblia de una colección más amplia. Si no ves una traducción que quieres en la pestaña principal **Biblias**, búscala aquí.

## Gestionar recursos instalados

En la pantalla principal de **Gestionar recursos** (no en la pestaña de descarga), puedes:

- **Activar o desactivar** un recurso sin eliminarlo. Los recursos desactivados permanecen en tu dispositivo pero están ocultos en los menús.
- **Eliminar** un recurso para liberar espacio. Puedes volver a descargarlo más tarde.

## Añadir tus propios archivos

Si tienes un archivo de recurso de otra parte —un amigo, otro proyecto o un sitio web— puedes importarlo directamente:

1. En **Gestionar recursos**, toca **Importar archivo local**.
2. Elige el archivo desde tu dispositivo.
3. La app lee el archivo y lo añade a tu biblioteca.

La app acepta estos tipos de archivo:

- `.bible` — traducciones de la Biblia
- `.commentary` — comentarios
- `.lexicon` — léxicos
- `.book` — libros
- `.devotional` — devocionales

## Conectar un repositorio personalizado de GitHub

Si alguien mantiene un repositorio de GitHub con recursos compatibles con Theodia, puedes añadirlo como fuente personalizada:

1. Ve a **Configuración → Repositorios personalizados**.
2. Toca **Añadir repositorio**.
3. Introduce la URL de GitHub (por ejemplo, `https://github.com/usuario/nombre-del-repo`).
4. Elige qué tipos de recursos contiene el repositorio (Biblias, comentarios o libros).
5. Guárdalo.
6. Vuelve a **Gestionar recursos**. Aparece una nueva pestaña con los recursos de ese repositorio.

Si el repositorio es privado, necesitarás añadir un **token de acceso personal** en **Configuración → Repositorios personalizados** para que la app pueda leerlo.

## Una nota sobre los tamaños de archivo

Los archivos de recursos pueden ser grandes. Las Biblias suelen ser pequeñas (unos pocos megabytes). Los comentarios y archivos principales pueden ser mucho más grandes (cientos de megabytes). Descarga por Wi-Fi siempre que sea posible.

## Resumen

- Usa **Configuración → Gestionar recursos** para explorar e instalar recursos.
- Los archivos principales desbloquean herramientas de estudio más profundo como morfología y referencias cruzadas.
- Importa archivos locales si tienes los tuyos propios.
- Añade repositorios personalizados de GitHub si quieres recursos de otra fuente.
