---
title: Dónde pedir ayuda
level: everyday
categories: trouble
summary: Cómo obtener ayuda del equipo y la comunidad de Theodia, y cómo encontrar temas de ayuda dentro de la app.
---

# Dónde pedir ayuda

Si estás atascado, hay varios lugares donde pedir ayuda.

## Encontrar un tema de ayuda

Si buscas información sobre una función específica, prueba uno de estos caminos:

- **Explorar por categoría.** Abre **Ayuda y guías** y toca una categoría como **Configuración y personalización** o **Solución de problemas**. Cada tarjeta lista guías relacionadas.
- **Buscar por palabra clave.** En la pantalla principal de **Ayuda y guías**, escribe una palabra en la caja de búsqueda de la parte superior. Por ejemplo, escribir `notificaciones` muestra la guía [Notificaciones y recordatorios](theodia://help/notifications); escribir `búsqueda` muestra la guía [Buscar en la Biblia](theodia://help/search-the-bible).
- **Revisar Configuración primero.** Muchas funciones se configuran en **Configuración**. Si quieres configurar recordatorios, abre **Configuración** → **Notificaciones**. La pantalla de configuración también tiene un enlace de **Ayuda** para cada sección.

## Dentro de la app

Abre la pantalla **Acerca de**. Verás dos botones:

- **Enviar sugerencia/problema** — abre un formulario para enviar al equipo una pregunta, idea o reporte de error.
- **Discusión / Comentarios** — abre el tablero de discusión de la comunidad.

## La página de GitHub

Puedes ver la lista de problemas conocidos y cambios recientes en [GitHub](https://github.com/ecodiallc/theodia.app).

## Discusión de la comunidad

Otras personas que usan Theodia hacen preguntas y comparten consejos en el [tablero de discusión de la comunidad](https://github.com/ecodiallc/theodia.app/discussions). Puedes leer conversaciones antiguas y empezar una nueva.

## Antes de preguntar

Algunas cosas nos ayudan a responderte más rápido:

- **¿Qué dispositivo tienes?** (por ejemplo, iPhone 13, Pixel 7)
- **¿Qué versión de la app?** (Abre **Acerca de** para verlo.)
- **¿Qué hiciste?** Una breve descripción de los pasos.
- **¿Qué pasó?** Lo que viste en la pantalla.
- **¿Qué esperabas que pasara?** Esta es a menudo la parte más útil.

## Qué esperar

- Para reportes de errores, el equipo suele responder en unos días.
- Para ideas, el equipo las lee todas. No podemos prometer cuándo se añadirá una idea.
- Para preguntas de la comunidad, otros usuarios suelen responder más rápido que el equipo.

## Una nota sobre privacidad

Cuando envíes una pregunta, no incluyas información privada. El equipo puede ver lo que envías.
