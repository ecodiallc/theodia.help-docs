---
title: GitHub Models
categories: ai
level: advanced
summary: Configura GitHub Models — una forma gratuita de empezar a explorar la IA en Theodia sin una suscripción de API existente.
---

# GitHub Models

> **Modo:** El asistente de IA requiere el modo **Académico**. Puedes cambiar de modo en **Configuración** → **Modo de usuario de la app**.

Si aún no pagas por un servicio de IA, **GitHub Models** es la forma más sencilla de empezar a explorar la IA de Theodia. Permite comenzar gratis, y solo necesitas una cuenta gratuita de GitHub.

## Qué es GitHub Models

GitHub Models es un servicio de GitHub que te permite ejecutar modelos de IA modernos a través de una API. Admite el mismo formato que OpenAI, así que funciona perfectamente con Theodia.

## Por qué elegir GitHub Models

- **No se requiere tarjeta de crédito** — Solo una cuenta de GitHub.
- **Modelos de alta calidad** — Obtienes acceso a GPT-4o, GPT-4.1 y otros modelos confiables que admiten las herramientas de Theodia.
- **Configuración sencilla** — Un token, una URL y listo.

## Paso 1: Crear una cuenta de GitHub

Si ya tienes una cuenta de GitHub, salta al paso 2.

1. Ve a [github.com](https://github.com).
2. Toca **Registrarse** y sigue las instrucciones para crear una cuenta gratuita.
3. Verifica tu dirección de correo electrónico cuando GitHub envíe la confirmación.

## Paso 2: Crear un token de acceso personal

Este token es tu clave API. Le dice a GitHub quién eres cuando Theodia envía preguntas.

1. Ve a [github.com/settings/tokens](https://github.com/settings/tokens).
2. Toca **Generar token nuevo** y elige **Generar token nuevo (classic)**.
3. Ponle un nombre al token, por ejemplo **Theodia IA**.
4. En **Seleccionar alcances**, marca la casilla de **`models:read`**.
   - Este es el único permiso que necesita Theodia.
5. Desplázate hasta abajo y toca **Generar token**.
6. **Copia el token inmediatamente.** GitHub solo lo muestra una vez. Pégalo en un lugar seguro (como la app de notas de tu teléfono) hasta que lo añadas a Theodia.

## Paso 3: Elegir un modelo

GitHub Models ofrece varios modelos. Para Theodia, estas son las mejores opciones:

| Modelo                | Límite gratuito diario | Mejor para                                |
| --------------------- | ---------------------- | ----------------------------------------- |
| `openai/gpt-4.1-nano` | 150 solicitudes / día  | Preguntas rápidas y explicaciones sencillas de versículos |
| `openai/gpt-4.1-mini` | 150 solicitudes / día  | Estudio general con buen soporte de herramientas |
| `openai/gpt-4.1`      | 50 solicitudes / día   | Estudio profundo y preguntas complejas de varios pasos |
| `openai/gpt-4o`       | 50 solicitudes / día   | Versátil, excelente soporte de herramientas |

Empieza con **`openai/gpt-4.1-mini`** — es rápido, confiable y ofrece un límite diario de solicitudes más alto.

## Paso 4: Configurar Theodia

1. Abre **Theodia**.
2. Ve a **Configuración** → **Asistente de IA**.
3. Asegúrate de que esté seleccionado **Modelo remoto**.
4. Toca el menú desplegable **Proveedor** y elige **GitHub Models**.
   - Si GitHub Models no aparece en la lista, toca **Personalizado** e introduce la URL base manualmente: `https://models.github.ai`
5. Pega tu token de acceso personal de GitHub en el campo **Clave de API**.
6. Introduce el ID del modelo elegido en el campo **Modelo** (por ejemplo: `openai/gpt-4.1-mini`).
7. Toca **Probar conexión**.
8. Espera a que termine la comprobación. Deberías ver:
   - **✓ Conexión exitosa**
   - **✓ Herramientas admitidas**

Si ves **✗ Herramientas no admitidas**, prueba con un ID de modelo diferente de la tabla de arriba.

## Paso 5: Empezar a chatear

1. Toca la pestaña **IA** en la parte inferior de la pantalla.
2. Escribe una pregunta y toca **Enviar**.
3. O, mientras lees cualquier capítulo de la Biblia, toca un número de versículo y elige **Comentario de IA** para iniciar un chat específico del versículo.

## Solución de problemas

### "Conexión fallida" o "HTTP 401"

- Asegúrate de haber copiado el **token completo**. Es una cadena larga que empieza con `ghp_`.
- Los tokens caducan si no se usan durante mucho tiempo. Vuelve a GitHub y genera uno nuevo.
- Comprueba que seleccionaste **`models:read`** al crear el token.

### "Herramientas no admitidas"

- Algunos modelos de GitHub Models no aceptan llamadas de herramienta. Prueba con **`openai/gpt-4o`** o **`openai/gpt-4.1-mini`**.
- Asegúrate de que el ID del modelo esté escrito exactamente como se muestra, incluyendo el prefijo `openai/`.

### Errores de límite de velocidad

- Si alcanzas el límite diario, cambia a un modelo con una cuota más alta (como `openai/gpt-4.1-nano` con 150 solicitudes por día).
- Los límites se reinician cada 24 horas.

## Resumen

- GitHub Models es la **forma recomendada de empezar a explorar la IA** en Theodia.
- Necesitas una **cuenta gratuita de GitHub** y un **token de acceso personal** con `models:read`.
- El mejor modelo para empezar es **`openai/gpt-4.1-mini`**.
- Introduce el token y el modelo en **Configuración → Asistente de IA**, toca **Probar conexión** y empieza a chatear.
