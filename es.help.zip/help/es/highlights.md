---
title: Resaltar versículos
level: everyday
categories: [annotate, read]
summary: Cómo marcar versículos con color y encontrarlos después.
---

# Resaltar versículos

> **Modo:** Los resaltados están disponibles en los modos **Estándar** y **Académico**. El modo de enfoque es solo para lectura limpia y sin distracciones. Puedes cambiar de modo en **Configuración** → **Modo de usuario de la app**.

Resaltar marca un versículo con un color. Funciona como un marcador amarillo en papel. El versículo permanece resaltado la próxima vez que lo abras.

## Cómo resaltar un versículo

1. Abre el versículo.
2. Toca el versículo para mostrar el menú.
3. Toca el icono de **Resaltar**.
4. Elige un color.

El versículo ahora está resaltado con ese color.

## Cómo cambiar el color del resaltado

1. Abre el versículo.
2. Toca el versículo y luego el icono de **Resaltar**.
3. Elige un color nuevo.

## Cómo quitar un resaltado

1. Abre el versículo.
2. Toca el versículo y luego **Resaltar** en el menú.
3. Toca **Quitar resaltado** en la parte inferior del selector de color.

## Una forma común de usar los colores

Muchos lectores usan un pequeño conjunto de colores para un pequeño conjunto de propósitos:

- **Amarillo** para favoritos generales.
- **Verde** para versículos sobre Dios.
- **Azul** para versículos sobre oración.
- **Rosa** para versículos sobre consuelo.
- **Naranja** para versículos de advertencia o corrección.
- **Morado** para versículos sobre profecía o tiempos finales.

Elige un sistema que te funcione.

## Cómo ver todos tus resaltados

Toca la pestaña **Resaltados** en la parte inferior. Verás una lista de cada versículo que has resaltado, el más reciente primero. Hay una fila de chips de colores en la parte superior: toca un color para mostrar solo los resaltados de ese color, o toca **Todo** para quitar el filtro.

## Importar resaltados

Puedes traer resaltados a Theodia desde otras apps y archivos.

Ve a **Configuración** → **Resaltados** → **Importar resaltados**. Elige **Importar desde archivo** o pega desde el portapapeles. La app detecta el formato automáticamente.

### Formatos admitidos

**Exportación JSON nativa** — El formato usado por la función de exportación propia de Theodia:

```json
{
  "/bible/KJV/John/3#v3_16": "yellow",
  "/bible/KJV/Genesis/1#v1_1": "green"
}
```

**CSV** — Una hoja de cálculo con columnas `url` y `color`. Ejemplo:

```csv
url,color
/bible/KJV/John/3#v3_16,yellow
/bible/KJV/Genesis/1#v1_1,green
```

**Texto plano** — Cada línea es una referencia bíblica o URL, opcionalmente seguida de un nombre de color. Ejemplo:

```
John 3:16 yellow
Genesis 1:1 green
Matthew 5:1
```

- Colores disponibles: `yellow`, `green`, `blue`, `pink`, `orange`, `purple`.
- Si no se indica color, el resaltado usa amarillo por defecto.
- Las líneas que empiezan con `#` o `//` se tratan como comentarios y se omiten.

## Consejos

- Los resaltados permanecen en tu dispositivo. No se sincronizan con la nube.
- Puedes resaltar un versículo en una traducción y aparecerá en tus otras traducciones del mismo versículo.
- Consulta la guía [Copias de seguridad de tus datos](theodia://help/backups) para mantenerlos a salvo.
