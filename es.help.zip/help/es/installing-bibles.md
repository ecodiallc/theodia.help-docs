---
title: Instalar traducciones de la Biblia
level: beginner
categories: start
summary: Cómo añadir una traducción de la Biblia a tu biblioteca.
---

# Instalar traducciones de la Biblia

Theodia viene con algunas traducciones de la Biblia listas para leer. Puedes añadir más en cualquier momento. Una "traducción" es una versión diferente del texto bíblico, como la King James Version.

## Cómo añadir una traducción

La pestaña Biblias muestra una lista de las traducciones ya instaladas. Para añadir más, abre el gestor de recursos:

1. Abre **Configuración**.
2. Toca **Gestionar recursos**.
3. Toca **Instalar desde GitHub**.
4. En la ventana de descarga, toca la pestaña **Biblias**.
5. Toca la casilla junto a cada traducción que quieras.
6. Toca **Instalar seleccionados** en la parte inferior.
7. Espera a que termine la descarga.

La traducción ya está en tu biblioteca. Para verla, abre la pestaña **Biblias**.

## Cómo cambiar entre traducciones

1. Abre un capítulo que quieras leer.
2. Toca el nombre de la traducción en la parte superior de la pantalla.
3. Elige la que quieras de la lista.

La app guarda tu elección para la próxima vez.

## Cómo quitar una traducción

1. Abre **Configuración**.
2. Toca **Gestionar recursos**.
3. Busca la traducción que quieres quitar.
4. Toca la **X** junto a ella.
5. Confirma que quieres eliminarla.

Quitar una traducción no elimina tus notas, resaltados ni marcadores. Esos permanecen a salvo.

## Cuánto espacio usan las traducciones?

La mayoría de las traducciones ocupan entre 2 y 10 MB. Se almacenan en tu dispositivo, no en la nube. Puedes guardar tantas como quieras, siempre que tu dispositivo tenga espacio.

## Qué hacer si una traducción no está en la app

Algunas traducciones no están en la lista integrada. Aún así puedes añadirlas.

1. Abre la app y ve a **Configuración** → **Gestionar recursos**.
2. Toca **Instalar desde GitHub**.
3. En la ventana de descarga, mira las pestañas **Biblias** y **Biblias globales**. Si tu traducción está allí, selecciónala y toca **Instalar seleccionados**.
4. Si no está, toca **Instalar archivo local** para importar un archivo `.bible`. Consigue el archivo desde la página de GitHub del proyecto. Consulta la guía [Obtener recursos adicionales desde GitHub](theodia://help/getting-core-files) para obtener ayuda paso a paso.
