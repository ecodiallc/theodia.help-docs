---
title: Añadir los archivos principales
level: beginner
categories: start
summary: Cómo descargar los archivos de datos grandes que la app necesita para estudiar la Biblia en profundidad.
---

# Añadir los archivos principales

Theodia viene con una Biblia y algunos pequeños extras listos para usar. Para sacar el máximo provecho de la app, también necesitas descargar los **archivos principales**. Son archivos de datos grandes que añaden herramientas de estudio como comentarios, consultas de palabras y notas de gramática. Sin ellos la app funciona, pero las funciones de estudio son limitadas.

## Por qué necesitas los archivos principales

Los archivos principales añaden:

- **Consultas de palabras.** Toca una palabra en cualquier versículo para ver el hebreo o griego original y qué significa.
- **Comentario.** Comentario de IA para cada versículo.
- **Gramática.** Información sobre cada palabra en el idioma original.
- **Biblia interlineal.** Lee el texto en el idioma original con el inglés debajo de cada palabra.

Puedes leer la Biblia sin ellos, pero la mayoría de las herramientas de estudio los necesitan.

## Cómo instalar los archivos principales

**[Instalar archivos principales](theodia://manage/core)**

1. Abre **Configuración**.
2. Toca **Gestionar recursos**.
3. Se abre la pestaña **Centro**. Ves una lista de los archivos principales. Cada uno tiene un nombre, un tamaño y una casilla.
4. Toca cada archivo que quieras instalar. Una marca de verificación indica que está seleccionado.
5. Toca **Instalar seleccionados**.
6. Espera a que los archivos se descarguen e instalen. Son grandes, así que puede tardar unos minutos en una conexión lenta.

Los archivos se descargan a tu dispositivo. Solo necesitas hacer esto una vez. La app usa los archivos de ahí en adelante, incluso cuando estás sin conexión.

## Consejos

- Usa Wi-Fi. Los archivos son grandes.
- Enchufa tu teléfono o tableta. Las descargas grandes usan batería.
- Si una descarga falla, toca el archivo de nuevo para reintentar.
- Puedes instalarlos todos o solo los que necesites.

## Qué pasa si falta un archivo en la lista?

La app obtiene la lista desde la página de GitHub del proyecto. Si la lista está vacía, comprueba tu conexión a internet e inténtalo de nuevo. Si sigue vacía, consulta la guía [Dónde pedir ayuda](theodia://help/getting-more-help).

Para formas más avanzadas de añadir recursos, consulta la guía [Obtener recursos adicionales desde GitHub](theodia://help/getting-core-files).
