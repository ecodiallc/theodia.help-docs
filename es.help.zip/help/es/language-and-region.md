---
title: Idioma y región de la app
level: everyday
categories: settings
summary: Cómo cambiar el idioma de la app.
---

# Idioma y región de la app

Theodia está disponible en muchos idiomas. La app puede cambiar el idioma de los menús y botones. El contenido de ayuda también se puede descargar en varios idiomas; abre **Configuración** → **Ayuda** o **Gestionar recursos** → **Descargar desde GitHub** → **Documentación de ayuda** para añadir un idioma.

## Cómo abrir los ajustes de idioma

1. Abre **Configuración**.
2. Toca **Idioma**.

## Cómo cambiar el idioma de la app

1. En la lista de **Idioma**, toca el idioma que quieres.
2. La app aplica el nuevo idioma de inmediato.

Las opciones que ves dependen de los idiomas que la app admite.

## Cómo se elige el idioma al instalar por primera vez

Cuando instalas Theodia por primera vez, la app elige un idioma basado en los ajustes de tu dispositivo. Puedes cambiarlo en cualquier momento.

## Qué se traduce

- Menús, botones y etiquetas.
- Pantallas de configuración.
- Mensajes de error.
- Herramientas de búsqueda y estudio.

## Qué permanece solo en inglés

- Algunos contenidos de libros y devocionales.
- Las guías de ayuda están disponibles en inglés y como paquetes descargables en otros idiomas. Añade un idioma en **Configuración** → **Ayuda** o **Gestionar recursos** → **Descargar desde GitHub** → **Documentación de ayuda**.

## Traducciones de la Biblia e idioma de la app

El idioma de la app y el idioma de la traducción de la Biblia son cosas diferentes. Puedes tener la app en español y la Biblia en inglés, o viceversa.

Para cambiar la traducción de la Biblia, consulta la guía [Instalar traducciones de la Biblia](theodia://help/installing-bibles).

## Consejos

- Si un botón o etiqueta está vacío, a la app le falta una traducción. La versión en inglés suele estar disponible como respaldo.
- Si te gustaría ayudar a traducir la app, consulta la guía [Dónde pedir ayuda](theodia://help/getting-more-help).
