---
title: El menú rápido
level: everyday
categories: layout
summary: Una forma rápida de saltar a versículos recientes, ejecutar comandos y cambiar la disposición de la Biblia sin salir de tu pantalla actual.
---

# El menú rápido

> **Modo:** El menú rápido requiere el modo **Académico**. Puedes cambiar de modo en **Configuración** → **Modo de usuario de la app**.

El menú rápido es un panel de acceso rápido que puedes abrir casi desde cualquier parte de la app. Guarda tus versículos recientes, comandos y configuraciones de Biblia guardadas en un solo lugar.

## Cómo abrirlo

Toca el **icono de expansión (⌄)** en la esquina superior derecha del encabezado de la pantalla de inicio. Un panel se desliza desde la parte superior.

## Qué hay dentro

### 1. Caja de comando

En la parte superior del panel hay una caja de texto con un icono de teclado. Escribe un comando y toca **Ir** en tu teclado. La app lee el comando y te lleva directamente allí.

Ejemplos:

- `John 3:16` — abre ese versículo.
- `search love` — busca en la Biblia la palabra "love".
- `bookmark psalms 23` — guarda el versículo como marcador.
- `kjv` — cambia a la traducción KJV.

Para ver la lista completa de comandos, consulta la guía [Comandos](theodia://help/commands).

### 2. Conjuntos paralelos

Si tienes conjuntos paralelos de Biblias guardados, aparecen aquí como una lista plegable. Toca uno para cargar esa configuración paralela al instante.

Para crear un conjunto paralelo:

1. Abre **Configuración** → **Biblia paralela**.
2. Añade traducciones y toca **Guardar conjunto**.
3. Ponle un nombre. Aparecerá en el menú rápido.

Mantén presionado un conjunto paralelo en el menú rápido para eliminarlo.

### 3. Colecciones de la Biblia

Las colecciones de la Biblia son accesos directos de un toque que cambian tu traducción y vista paralela al mismo tiempo. Si has creado alguna, aparecen aquí como una lista plegable.

Mantén presionada una colección para eliminarla.

### 4. Iconos de funciones

Debajo de la caja de comando puedes ver una fila de botones redondos con emojis. Son accesos directos de un toque a las funciones principales de la app.

Los iconos disponibles incluyen:

- **Acerca de**, **Biblias**, **Notas bíblicas**, **Marcadores**, **Libros**
- **Devocionales**, **Tarjetas de memoria**, **Ayuda**, **Resaltados**
- **Listas de reproducción**, **Complementos**, **Buscar**, **Configuración**, **Theoscript**

Para elegir qué iconos aparecen y en qué orden:

1. Abre **Configuración** → **Menú rápido**.
2. Toca **Iconos del menú rápido**.
3. Usa los interruptores para mostrar u ocultar cada icono.
4. Usa las flechas arriba/abajo para reordenar los que tienes activados.

El orden en la configuración es el orden en que aparecen en el menú rápido.

### 5. Versículos recientes

La app recuerda los últimos capítulos y versículos que abriste. Aparecen como una lista en la parte inferior del panel. Toca cualquier entrada para volver directamente.

- **Toca** para abrir.
- **Desliza a la izquierda** o **mantén presionado** para quitar de la lista.
- Toca **Borrar todo** para eliminar todas las entradas de una vez.

## Cuándo usar el menú rápido

Úsalo cuando quieras:

- Volver a un versículo que acabas de leer.
- Escribir un comando sin ir a la pantalla de inicio.
- Cambiar de traducción o configuración paralela con un toque.
- Abrir una función principal desde cualquier parte de la app.
- Consultar algo rápido sin navegar por menús.

## Consejos

- El menú rápido está disponible en casi todas las pantallas, así que puedes abrirlo mientras lees un capítulo.
- La caja de comando admite los mismos comandos que la caja de comando de la pantalla de inicio.
- Los iconos de funciones y su orden se guardan localmente en tu dispositivo. Sobreviven a reinicios de la app.
- Los versículos recientes se guardan localmente en tu dispositivo. Sobreviven a reinicios de la app.
