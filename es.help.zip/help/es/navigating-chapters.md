---
title: Navegar entre libros, capítulos y versículos
level: everyday
categories: [layout, read]
summary: Cómo moverte por la Biblia y saltar a donde quieras ir.
---

# Navegar entre libros, capítulos y versículos

Esta guía te muestra todas las formas de moverte por la Biblia.

## La forma fácil: deslizar

- Desliza a la **izquierda** en un capítulo para ir al siguiente.
- Desliza a la **derecha** para volver.
- Esto funciona también para el siguiente libro. Después del último capítulo de, digamos, Éxodo, el deslizamiento te lleva al primer capítulo de Levítico.

## La forma por menú

- Toca el nombre de la traducción en la parte superior para cambiar de Biblia.
- Toca el nombre del libro para elegir otro libro.
- Toca el número del capítulo para elegir otro capítulo.

## La forma rápida: escribir

- En la pantalla de inicio hay una caja en la parte superior. Escribe una referencia, como `John 3:16` o `psalms 23`, y toca la tecla **Ir** del teclado.
- La app abre el versículo.

## La forma por marcador

Si has guardado un versículo, abre la pestaña **Marcadores**. Toca cualquier entrada para saltar a él.

## La forma por búsqueda

Toca la pestaña **Buscar**. Escribe una palabra. La app te muestra cada versículo que la contiene. Toca cualquier resultado para abrirlo.

## La forma por historial

La app recuerda los capítulos que has abierto. Para encontrarlos de nuevo, mira la pestaña **Marcadores** (para los versículos que guardaste) o desplázate por la lista de libros en la pestaña **Biblias** para encontrar un libro que leíste recientemente.

## Consejos

- La pestaña Biblias muestra los libros en orden de Génesis a Apocalipsis.
- Para Salmos, Proverbios y otros libros largos, toca el libro y usa la lista de capítulos para saltar lejos.
