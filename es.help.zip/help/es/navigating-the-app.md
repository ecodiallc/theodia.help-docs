---
title: Diseño y navegación de la app
level: beginner
categories: layout
summary: Un recorrido por la pantalla de inicio, el menú rápido y la barra inferior: dónde está todo.
---

# Diseño y navegación de la app

Theodia tiene tres áreas principales entre las que puedes moverte: la **pantalla de inicio**, el **menú rápido** y la **barra inferior**. Esta guía recorre cada una para que siempre sepas a dónde ir.

## Mapa rápido

- La **pantalla de inicio** es la página que ves al abrir la aplicación. Tiene una caja de búsqueda, botones grandes para cada parte de la app y una lista de tus Biblias, libros y devocionales instalados.
- La **barra inferior** (también llamada barra de pestañas) es la fila de iconos en la parte inferior de la pantalla. Toca cualquiera para saltar directamente a esa parte de la app.
- El **menú rápido** es el icono con tres líneas (☰) en la esquina superior derecha de la pantalla de inicio. Tócalo para abrir una lista con todas las pantallas de la app, incluso las que no tienen su propia pestaña.

## La pantalla de inicio

Cuando abres Theodia, llegas a la pantalla de inicio. Está dividida en cuatro partes, de arriba abajo.

### El encabezado

En la parte superior hay una barra de color. A la izquierda están el icono de la app y el nombre "Theodia". A la derecha está el botón del menú rápido (☰). Cuando estás dentro de un libro o capítulo, la izquierda muestra un botón de atrás (←). Toca el menú rápido para abrir el menú (ver más abajo).

### El comando

Justo debajo del encabezado hay una caja de texto tipo búsqueda con la etiqueta **Comando rápido**. Escribe una instrucción corta y toca el botón de ir en tu teclado. La app lee la instrucción y te lleva a la pantalla correcta. Ejemplos:

- `salmos 23` — abre el capítulo 23 de Salmos
- `juan 3:16` — abre Juan 3:16
- `buscar amor` — busca en la Biblia la palabra "amor"
- `marcador juan 3:16` — guarda Juan 3:16 como marcador
- `comentario romanos 8:28` — abre el comentario de ese versículo
- `referencias` seguido de una referencia — abre las referencias cruzadas de ese versículo
- `ayuda` — abre la lista de comandos con ejemplos

Si la app no entiende lo que escribiste, muestra una pequeña alerta con una sugerencia. Consulta la guía [Solución de problemas comunes](theodia://help/common-problems) si los comandos no funcionan.

### La cuadrícula de botones

Debajo del comando hay una cuadrícula de botones grandes, dos por fila. Cada botón te lleva a una parte diferente de la app. Los botones son:

- 📖 **Biblias** — tu lista de traducciones de la Biblia
- 🔍 **Buscar** — busca en la Biblia una palabra o frase
- 📚 **Libros** — tu biblioteca de clásicos cristianos
- 📅 **Devocionales** — devocionales diarios
- 🔖 **Marcadores** — tus versículos y capítulos guardados
- 🖍 **Resaltados** — tus versículos marcados con color
- 📝 **Notas bíblicas** — tus notas privadas sobre versículos
- ⚙️ **Configuración** — idioma, tema, recursos y más
- ❓ **Ayuda** — el sistema de ayuda (esta página)
- ℹ️ **Acerca de** — versión de la app y créditos

### Las listas de recursos

Debajo de la cuadrícula de botones hay secciones expandibles: **Biblias**, **Libros** y **Devocionales**. Cada sección muestra los elementos que tienes instalados. Toca el encabezado de una sección para expandirla o contraerla. Toca cualquier elemento de una sección para abrirlo.

La sección de Biblias es la forma más rápida de saltar a una traducción específica: sin menús, solo toca.

## La barra inferior

La barra inferior (barra de pestañas) es la fila de iconos en la parte inferior de la pantalla. Es visible casi en todas partes de la app, así que siempre puedes saltar a otra sección. Las pestañas que ves dependen de tu modo de usuario.

**Todos los modos ven:**

- 🏠 **Inicio** — abre la pantalla de inicio
- 📖 **Biblias** — abre tu lista de traducciones de la Biblia
- 📚 **Libros** — abre tu biblioteca de libros
- 🔍 **Buscar** — abre la búsqueda bíblica
- ⚙️ **Configuración** — abre la configuración

**Estándar y Académico también ven:**

- 🔖 **Marcadores** — abre tus versículos guardados
- 🖍 **Resaltados** — abre tus versículos marcados con color
- 📝 **Notas bíblicas** — abre tus notas privadas

**Académico también ve:**

- 💻 **IA** — abre el asistente de IA (si lo has activado en Configuración)

La pestaña actual está resaltada. Toca cualquier otra pestaña para cambiar.

### Cómo se comporta la barra

Cada pestaña de la barra tiene su propia **pila** de pantallas. Cuando tocas una pestaña, vuelves **a donde la dejaste** en la pila de esa pestaña, no a la pantalla inicial. Por ejemplo:

- Toca **Biblias** → ves la lista de traducciones.
- Toca una traducción → ves la lista de libros.
- Toca un libro → ves la lista de capítulos.
- Toca un capítulo → estás leyendo el capítulo.
- Cambia a **Marcadores** para consultar algo.
- Toca **Biblias** de nuevo → regresas al capítulo que estabas leyendo.

Cada pestaña recuerda tu lugar. La app conserva tu historial de navegación dentro de cada pestaña, así que cambiar de pestaña no pierde tu progreso.

### Qué reinicia una pestaña

Una pestaña solo vuelve a su pantalla raíz cuando:

- Ya estás en esa pestaña y tocas el mismo icono de nuevo. Es una forma rápida de volver al inicio.
- La aplicación se cierra forzosamente y se vuelve a abrir.

### Barra inferior vs. menú rápido

- **Pestañas inferiores** — cada pestaña recuerda su propia pila. Tocarla te devuelve a donde la dejaste.
- **Menú rápido** — tocar un elemento navega a esa pantalla usando el mismo sistema de pestañas. No se abre como una superposición.

Usa las pestañas para cambiar de tarea. Usa el menú rápido cuando quieras una lista completa de todas las pantallas de la app.

### Cuándo usar la barra

Usa la barra cuando quieras cambiar lo que estás haciendo:

- Estás leyendo un capítulo y quieres buscar algo más → toca **Buscar**.
- Estás buscando y quieres revisar tus marcadores → toca **Marcadores**.
- Estás en cualquier parte de la app y quieres ir al inicio → toca **Inicio**.

## El menú rápido

El menú rápido es el botón con tres líneas horizontales (☰) en la esquina superior derecha de la pantalla de inicio. Tócalo y un panel se desliza desde la derecha. El panel muestra cada pantalla que tu modo actual admite:

- 🏠 **Inicio**
- 📖 **Biblias**
- 📚 **Libros**
- 🙏 **Devocionales**
- 🔍 **Buscar**
- 🔖 **Marcadores** (Estándar y Académico)
- 🖍 **Resaltados** (Estándar y Académico)
- 📝 **Notas bíblicas** (Estándar y Académico)
- 💻 **Asistente de IA** (solo Académico, y solo si la IA está activada)
- ⚙️ **Configuración**
- ❓ **Ayuda**
- ℹ️ **Acerca de**

El elemento que coincide con la pantalla actual está resaltado y tiene un punto pequeño a su lado. Toca cualquier elemento para ir directamente. Toca fuera del panel, la X superior o el botón de atrás de tu dispositivo para cerrarlo sin cambiar de pantalla.

### En qué se diferencia el menú rápido

El menú rápido es un panel desplegable, no una capa de navegación separada. Cuando tocas un elemento, la app navega a esa pantalla de la misma forma que si hubieras usado la pestaña inferior o el botón de la cuadrícula. Se conserva la pila de tu pestaña actual, así que puedes volver a donde estabas tocando de nuevo la pestaña original.

Por ejemplo:

- Estás leyendo Juan 3. Tocas la pestaña **Marcadores**. Vas a tus marcadores. Cuando tocas **Biblias** de nuevo, regresas a Juan 3, justo donde lo dejaste.
- Estás leyendo Juan 3. Abres el menú rápido y tocas **Notas bíblicas**. Se abren tus notas. Para volver a Juan 3, toca la pestaña **Biblias** y regresas automáticamente al capítulo.

Las pestañas cambian tu contexto y recuerdan tu lugar. El menú rápido es simplemente otra forma de llegar a las mismas pantallas.

### Cuándo usar el menú rápido

Usa el menú rápido cuando:

- Quieras abrir **Resaltados**, **Notas bíblicas**, **Devocionales**, **Ayuda** o **Acerca de**: pantallas que no tienen su propia pestaña en la barra.
- Estás profundo en un capítulo o búsqueda y quieres consultar algo rápido sin perder tu lugar.
- Quieres abrir **Configuración** sin salir de la pantalla en la que estás.

## Modo Académico

Si tu modo de usuario es **Académico**, el diseño gana pestañas, elementos de menú y herramientas de lectura adicionales que los modos Lector y Estándar ocultan. Consulta la guía [Modo académico](theodia://help/scholar-mode) para un recorrido completo de cada función.

## Cómo encajan las tres áreas

- **Cambiar a una sección principal diferente** (Biblias, Buscar, Marcadores, etc.) → Barra inferior
- **Saltar a un versículo o comando específico** → Comando rápido en la pantalla de inicio
- **Explorar todas las pantallas disponibles** → Cuadrícula de botones de la pantalla de inicio
- **Consultar Notas bíblicas, Resaltados o Ayuda sin salir de tu lugar** → Menú rápido
- **Abrir Configuración desde cualquier parte** → Menú rápido o barra inferior

Usarás las tres. Ninguna es "la forma correcta". Elige la que te resulte más fácil para lo que estás haciendo.

### Barra inferior vs. menú rápido: un ejemplo rápido

Imagina que estás leyendo Romanos 8 y quieres resaltar un versículo que te gusta.

**Usando la barra inferior:**

1. Toca el versículo para abrir el menú de versículo.
2. Toca **Resaltar** y elige un color.
3. Listo. Nunca saliste del capítulo.

**Usando el menú rápido (si quieres revisar tus resaltados):**

1. Toca ☰ para abrir el menú.
2. Toca **Resaltados**. Se abre tu lista de resaltados.
3. Revísalos, luego toca la pestaña **Biblias** para volver a Romanos 8.

**Usando la barra inferior (si quieres cambiar de tarea):**

1. Toca **Inicio** o **Marcadores** en la barra.
2. Sales de Romanos 8 y vas a la nueva pantalla.
3. Para volver a Romanos 8, toca **Biblias** de nuevo: regresas automáticamente al capítulo.

## Consejos

- La pantalla de inicio recuerda qué secciones están expandidas o contraídas. Solo tienes que configurarlo una vez.
- Si no ves una pestaña que esperas, revisa dos cosas:

1. **Tu modo de usuario** — el modo Lector oculta marcadores, resaltados, notas y la IA. El modo Estándar oculta la IA. Cambia de modo en **Configuración** → **Modo de usuario de la app**.
2. **Configuración de funciones** — algunas pestañas deben activarse en **Configuración** (por ejemplo, el asistente de IA).
