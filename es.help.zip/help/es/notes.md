---
title: Escribir notas
level: everyday
categories: [annotate, read]
summary: Cómo escribir tus propios pensamientos junto a un versículo.
---

# Escribir notas

> **Modo:** Las notas están disponibles en los modos **Estándar** y **Académico**. El modo de enfoque es solo para lectura limpia y sin distracciones. Puedes cambiar de modo en **Configuración** → **Modo de usuario de la app**.

Las notas son el lugar donde escribes tus propios pensamientos, oraciones o ideas de estudio junto a un versículo. Cada nota está vinculada a un versículo específico.

## Cómo añadir una nota

1. Abre el versículo.
2. Toca el versículo para mostrar el menú.
3. Toca **Nota bíblica** en el menú. Tiene un icono de lápiz.
4. Escribe tu nota.
5. Toca **Guardar**.

La nota se guarda ahora con el versículo.

## Cómo leer una nota

1. Abre el versículo.
2. Busca la marca de lápiz junto al versículo. Significa que hay una nota.
3. Toca el versículo. La nota aparece debajo.

## Cómo editar una nota

1. Abre el versículo con la nota.
2. Toca el versículo.
3. Toca **Nota bíblica** en el menú.
4. Haz tus cambios.
5. Toca **Guardar**.

## Cómo eliminar una nota

1. Abre el versículo con la nota.
2. Toca el versículo.
3. Toca **Nota bíblica** en el menú.
4. Toca **Eliminar**.

## Cómo ver todas tus notas

Toca la pestaña **Notas bíblicas** en la parte inferior. Verás una lista de cada nota que has escrito, ordenada por fecha.

## Buscar en tus notas

En la pestaña **Notas bíblicas**, toca la caja de **Buscar**. Escribe una palabra. La app encuentra cada nota que la contiene.

## Consejos

- Las notas son ideales para sermones, devocionales y preguntas de estudio.
- Las notas son privadas. Permanecen en tu dispositivo.
- Consulta la guía [Copias de seguridad de tus datos](theodia://help/backups) para mantenerlas a salvo.
