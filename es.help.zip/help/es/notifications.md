---
title: Notificaciones y recordatorios
level: everyday
categories: [settings]
summary: Cómo activar, personalizar y gestionar recordatorios sin conexión para oración, devocionales, planes bíblicos y más.
---

# Notificaciones y recordatorios

Theodia puede recordarte la oración, los devocionales, los planes bíblicos, las tarjetas de memoria y otras actividades —incluso cuando la app está sin conexión. Todos los recordatorios se programan en tu dispositivo; no se necesita conexión a internet ni servidor de notificaciones push.

## Cómo activar o desactivar los recordatorios

1. Abre **Configuración**.
2. Toca **Notificaciones**.
3. Activa o desactiva **Habilitar notificaciones**.

La primera vez que activas los recordatorios, la app pide permiso para enviar notificaciones. Toca **Permitir** para que los recordatorios puedan aparecer.

Si anteriormente denegaste el permiso, iOS o Android pueden bloquear la solicitud. En ese caso, ve a la app **Configuración** de tu dispositivo, busca **Theodia** y activa las notificaciones allí.

## Tipos de recordatorio

La pantalla de notificaciones se divide en canales. Cada canal es una familia de recordatorios que puedes activar o desactivar de forma independiente:

- **Recordatorios de oración** — recordatorios generales de oración.
- **Recordatorios de rutina** — recordatorios vinculados a una rutina de oración específica.
- **Versículo / devocional del día** — el versículo o devocional diario.
- **Recordatorios del plan bíblico** — recordatorios para un plan bíblico activo.
- **Recordatorios de Theoscript** — recordatorios para ejecutar un Theoscript.
- **Recordatorios de reflexiones de IA** — recordatorios generados por IA.
- **Recordatorios de repaso de tarjetas** — avisos para repasar tarjetas de memoria.
- **Recordatorios de hábito de lectura** — indicaciones diarias de hábito de lectura.
- **Recordatorios litúrgicos y de temporada** — recordatorios vinculados al calendario eclesial.
- **Mis recordatorios** — recordatorios creados desde marcadores, resaltados, listas de reproducción, capítulos de la Biblia o libros.
- **Recordatorios personalizados** — recordatorios totalmente personalizados que tú creas.

Toca cualquier canal para ver sus recordatorios, cambiar la hora, elegir en qué días se activan o desactivarlos.

## Recordatorios personalizados

Los recordatorios personalizados son recordatorios que construyes desde cero.

1. En **Configuración** → **Notificaciones**, toca **Recordatorios personalizados**.
2. Toca el botón **+**.
3. Introduce un **Título** y un **Mensaje**.
4. Elige una **Hora**.
5. Selecciona los **Días** en los que quieres que se repita.
6. Elige qué abre el recordatorio al tocarlo (opcional).
7. Toca **Guardar**.

Puedes editar o eliminar un recordatorio personalizado en cualquier momento tocándolo en la lista.

## Qué ocurre al tocar un recordatorio

La mayoría de los recordatorios abren una pantalla específica de la app. Por ejemplo, un recordatorio de rutina de oración abre esa rutina; un recordatorio de plan bíblico abre la siguiente lectura.

Si un recordatorio no tiene una pantalla vinculada, abre la app en la pantalla de inicio.

## Horas de silencio

Las horas de silencio apagan el sonido de las notificaciones mientras siguen mostrando recordatorios visuales.

1. En **Configuración** → **Notificaciones**, toca **Horas de silencio**.
2. Establece una hora de **Inicio** y una hora de **Fin**.

Los recordatorios programados durante las horas de silencio se mostrarán en pantalla sin sonido.

## Próximos recordatorios e historial

- **Próximos recordatorios** muestra todo lo que está programado para sonar a continuación.
- **Historial de notificaciones** muestra los recordatorios recientes entregados, programados y cancelados.

Usa estas listas para confirmar que un recordatorio está configurado correctamente o para ver por qué uno no apareció.

## Si los recordatorios no aparecen

- Asegúrate de que **Habilitar notificaciones** esté activado.
- Comprueba que las notificaciones están permitidas en los ajustes del sistema de tu dispositivo.
- Asegúrate de que el canal del recordatorio esté activado y de que al menos un día esté seleccionado.
- Si configuraste horas de silencio, el recordatorio puede estar en silencio.
- Algunos fabricantes de Android ponen las apps en suspensión. Añade Theodia a la lista de permitidos si tu dispositivo ofrece ajustes de optimización de batería.
- Si un recordatorio está vinculado a contenido que eliminaste (por ejemplo, un plan bíblico o una rutina borrados), el recordatorio puede no sonar hasta que vuelvas a seleccionar un destino válido.

## Sonidos de notificación

Puedes elegir el sonido que reproducen los recordatorios que admiten sonido. Toca **Sonido** dentro de un recordatorio o canal para elegir entre las opciones disponibles. Los sonidos van incluidos con la app, así que funcionan sin conexión.

Usa el botón **Vista previa del sonido** para escuchar el sonido seleccionado antes de guardar.

## Insignias

Algunos recordatorios pueden añadir una insignia al icono de la app. Toca **Borrar insignia** en la pantalla de notificaciones para restablecerla.
