---
title: PDF
level: everyday
categories: [read, resources]
summary: Importa, organiza y lee documentos PDF en Theodia.
---

# PDF

> **Modo:** Los PDF están disponibles en los modos **Estándar** y **Académico**. El modo de enfoque es solo para lectura limpia y sin distracciones. Puedes cambiar de modo en **Configuración** → **Modo de usuario de la app**.

Theodia puede almacenar y leer archivos PDF. Los PDF importados se quedan en tu dispositivo, por lo que funcionan sin conexión.

## Abrir la biblioteca de PDF

Toca la pestaña **PDF** en la parte inferior de la pantalla, o toca el mosaico **PDF** en la pantalla de inicio.

## Importar un PDF

1. Abre la pestaña **PDF**.
2. Toca el botón **+** en la esquina inferior derecha.
3. Elige un PDF de tu dispositivo.
4. (Opcional) Escribe o elige una categoría para organizarlo.

## Organizar los PDF

Mantén pulsada cualquier tarjeta de PDF para abrir un menú con estas opciones:

- **Renombrar** — cambia el título que se muestra en la biblioteca.
- **Cambiar categoría** — mueve el PDF a una categoría.
- **Eliminar** — quita el PDF de Theodia. Esto también elimina su posición de lectura guardada.

Las categorías son texto libre. Escribe un nombre nuevo o elige uno existente al importar o cambiar de categoría.

## Leer un PDF

Toca una tarjeta de PDF para abrirla. El lector muestra:

- El título del documento en una barra en la parte superior.
- Una fila de botones de página: **Primera página**, **Anterior**, la página actual («3 / 120»), **Siguiente** y **Última página**.
- Una barra de herramientas con las herramientas del documento: **Contenido**, **Alejar**, **Acercar**, **Restablecer zoom**, **Marcador**, **Buscar**, **Escuchar** y **Vista de texto**.

Algunas herramientas se atenúan cuando no se pueden usar; por ejemplo, **Buscar** y **Escuchar** están atenuadas hasta que se instala el texto buscable del PDF.

### Pasar páginas

- Toca la **flecha izquierda** o **derecha** para retroceder o avanzar una página.
- Toca **Primera página** o **Última página** para saltar a cualquiera de los extremos del documento.
- Toca el número de página (por ejemplo «3 / 120») para abrir una cuadrícula de páginas y luego toca la página que quieras. La cuadrícula se abre cerca de la página en la que estás.
- Usa las **teclas de flecha izquierda y derecha** de un teclado externo.

### Zoom

- Toca **Acercar** (+) o **Alejar** (−) para cambiar el tamaño de la página.
- Toca **Restablecer zoom** para devolver la página a su tamaño normal.
- Si acercas, pasas de página y luego alejas, Theodia te devuelve a la página que estabas leyendo.

## Buscar dentro de un PDF

1. Abre el PDF y toca el botón **Buscar** (lupa) de la barra de herramientas.
2. Escribe lo que buscas. Los resultados aparecen mientras escribes, con el número de página y un fragmento del texto circundante.
3. Toca un resultado para saltar a esa página.

Para buscar es necesario tener instalado el texto buscable del PDF. Si aún no está instalado, el botón Buscar está atenuado. Los PDF instalados desde el repositorio de GitHub de la comunidad incluyen texto buscable; los PDF que importas tú no lo tienen hasta que se añade.

## Contenido

Si el PDF tiene una tabla de contenido integrada, el botón **Contenido** de la barra de herramientas la muestra como un esquema. Toca el título de una sección para saltar a esa página. Las secciones se pueden expandir y contraer. Si el PDF no tiene tabla de contenido, el botón está atenuado.

## Marcadores en un PDF

1. Abre el PDF y toca el botón **Marcador** de la barra de herramientas.
2. Toca **Marcar página** para guardar la página actual. El nombre empieza siendo el número de página; escribe otro nombre si lo prefieres, y luego toca **Guardar**.
3. Toca cualquier marcador de la lista para saltar a su página.
4. Toca la **×** junto a un marcador para eliminarlo.

Los marcadores de PDF son independientes de tus marcadores de la Biblia. Cada PDF tiene su propia lista.

## Leer un PDF en voz alta

Si el texto buscable del PDF está instalado, Theodia puede leer en voz alta la página actual:

1. Abre el PDF y toca el botón **Escuchar** (altavoz) de la barra de herramientas.
2. Aparece una barra de control con **Reproducir/Pausar**, **Retroceder**, **Avanzar**, **Detener**, una barra de progreso que puedes tocar para saltar dentro de la página, la velocidad de lectura y la voz.
3. Cuando termina la página, la lectura continúa automáticamente en la página siguiente.

La voz y la velocidad son las mismas que se usan para la lectura de la Biblia; consulta [Lectura en voz alta](theodia://help/tts) para saber cómo cambiarlas.

## Copiar, compartir o guardar el texto de la página

Toca el botón **Vista de texto** de la barra de herramientas para ver la página actual como texto sin formato. Desde ahí puedes:

- **Copiar** — copiar el texto de la página al portapapeles.
- **Compartir** — compartir el texto de la página mediante cualquier aplicación de tu dispositivo.
- **Añadir a las notas de estudio** — abre un editor de notas con el texto de la página, la cita y un enlace de vuelta a esta página ya rellenados por ti.

## Reanudar la lectura

Theodia recuerda la última página que viste y abre el PDF en esa página la próxima vez.

## Descargar PDF desde GitHub

En modo **Académico**, aparece un botón **Descargar desde GitHub** en la parte inferior de la biblioteca. Se conecta al repositorio de PDF de la comunidad para que puedas instalar documentos PDF empaquetados de la misma forma en que instalas Biblias o libros.

## Notas

- Los PDF se guardan en la carpeta privada de documentos de Theodia. No se incluyen en las copias de seguridad, así que si pasas a un dispositivo nuevo tendrás que importarlos de nuevo.
