---
title: Listas de reproducción
level: everyday
categories: playlists
summary: Crea y escucha listas de reproducción habladas de pasajes bíblicos, texto plano o cualquier versículo que quieras oír.
---

# Listas de reproducción

Una **lista de reproducción** es una lista de pistas que Theodia puede leer en voz alta por ti. Cada pista es un pasaje bíblico o una breve nota de texto plano. Las listas son útiles para escuchar manos libres durante el trayecto, un paseo, el tiempo devocional o la práctica de memorización.

Las listas de reproducción aparecen en la app una vez que se ha creado o rellenado al menos una.

## Dónde encontrar las listas de reproducción

Cuando hay listas disponibles, puedes llegar a ellas de dos formas:

- **Pantalla de inicio:** En la sección **Complementos y más**, toca **Listas de reproducción**.
- **Menú principal:** Abre el menú (☰) y toca **Listas de reproducción**.

Si aún no existe ninguna lista, el mosaico y el elemento del menú permanecen ocultos.

## Qué contiene una lista de reproducción

Cada lista tiene:

- Un **nombre** — por ejemplo, "Versículos matutinos" o "Memorizar el Salmo 23".
- Una **categoría** opcional — útil para agrupar listas según su propósito.
- Una lista de **pistas** — los elementos que se leerán en voz alta.

Cada pista contiene:

- **Contenido** — un pasaje bíblico o texto plano.
- Una **etiqueta** — se muestra en pantalla mientras suena la pista.
- Una **voz** opcional — elige una voz diferente para esta pista si quieres.

## Crear una lista de reproducción

1. Abre la pantalla **Listas de reproducción**.
2. Toca **Crear lista** (o el botón **+**).
3. Ponle un nombre a la lista.
4. (Opcional) Elige o crea una categoría.
5. Empieza a añadir pistas.

### Añadir una pista desde un pasaje bíblico

1. Toca **Añadir pista**.
2. Elige **Pasaje bíblico** como tipo de contenido.
3. Introduce una referencia, como `John 3:16` o `Psalm 23:1-6`.
4. Añade una etiqueta si quieres, o déjala en blanco para usar la referencia.
5. Guarda la pista.

### Añadir una pista de texto plano

1. Toca **Añadir pista**.
2. Elige **Texto plano**.
3. Escribe el texto que quieres que Theodia lea.
4. Añade una etiqueta.
5. Guarda la pista.

### Añadir pistas en lote

Si tienes una lista de referencias o líneas de texto, usa **Añadir en lote**:

1. Abre una lista de reproducción.
2. Toca el menú y elige **Añadir en lote**.
3. Pega una referencia o línea de texto por línea.
4. Activa **Detectar referencias bíblicas** si la mayoría de las líneas son referencias de versículos.
5. Toca **Añadir**. Cada línea se convierte en una pista.

## Escuchar una lista de reproducción

1. Abre la lista que quieres escuchar.
2. Toca el botón **Reproducir** en la parte superior o al lado de una pista.
3. Theodia lee cada pista en orden.

Mientras suena una lista, aparece una barra de control con estos controles:

- **Reproducir / Pausar**
- **Pista siguiente**
- **Pista anterior**
- **Detener**

También puedes configurar:

- **Velocidad** — qué tan rápido habla la voz.
- **Repetir** — repetir toda la lista, repetir una pista o reproducir una vez.
- **Aleatorio** — reproducir pistas en orden aleatorio.
- **Ignorar paréntesis** — omitir texto dentro de paréntesis.
- **Pausa entre pistas** — añade un breve silencio entre pistas.
- **Temporizador de apagado** — detener la reproducción después de un tiempo determinado.

## Editar una lista de reproducción

Para cambiar una lista, primero pausa la reproducción si está sonando.

Puedes:

- **Cambiar el nombre** de la lista.
- **Reordenar pistas** — arrastra las pistas a un nuevo orden.
- **Editar una pista** — cambia su referencia, texto, etiqueta o voz.
- **Eliminar una pista** — quítala de la lista.
- **Eliminar toda la lista** — esto no se puede deshacer.

## Exportar e importar listas

Las listas se exportan como archivos JSON que incluyen todas las pistas, categorías y ajustes. Puedes compartir el archivo con otro dispositivo, guardarlo como copia de seguridad o editarlo en una computadora.

- **Exportar todas las listas** — crea un archivo `playlists-YYYY-MM-DD.json`.
- **Exportar una categoría** — crea un archivo JSON con solo las listas de una categoría.
- **Importar listas** — restaura listas desde un archivo de copia de seguridad JSON.

## Formas rápidas de construir una lista

También puedes crear una lista completa como JSON e importarla. Aquí tienes un ejemplo:

```json
{
  "playlists": [
    {
      "name": "Morning Verses",
      "category": "Devotional",
      "tracks": [
        {
          "info": "John 3:16",
          "contentSource": "passage",
          "content": "For God so loved the world...",
          "rawContent": "John 3:16"
        },
        {
          "info": "Psalm 23",
          "contentSource": "passage",
          "content": "The Lord is my shepherd...",
          "rawContent": "Psalm 23:1-6"
        }
      ]
    }
  ]
}
```

Guarda el archivo y luego usa **Importar listas** para cargarlo en Theodia.

## Consejos

- Las listas funcionan mejor con conjuntos cortos y enfocados de versículos.
- Usa categorías para separar listas devocionales de listas de memorización.
- Activa el temporizador de apagado si escuchas mientras te quedas dormido.
- Si una pista usa la voz incorrecta, comprueba que el idioma de la voz coincida con el idioma del texto.
- Theodia lee el texto plano exactamente como está escrito; revisa la ortografía para obtener los mejores resultados.
