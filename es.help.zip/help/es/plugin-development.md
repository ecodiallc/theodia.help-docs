---
title: Desarrollar complementos
categories: plugins
level: advanced
summary: Qué contiene un paquete de complemento de Theodia y cómo crear un manifiesto de complemento.
---

# Desarrollar complementos

Un complemento de Theodia es un paquete autónomo que añade superficies de interfaz, contenido o manejo de eventos a la app. Los complementos se crean fuera de la app principal y los usuarios los instalan a través de Configuración → Complementos.

## Estructura del paquete de complemento

Un paquete de complemento es un archivo ZIP con la extensión `.plugin.zip`. Dentro, los archivos deben estar en la raíz —no dentro de una carpeta anidada.

Un paquete típico contiene:

```
my-plugin.plugin.zip
├── plugin.json       (requerido)
├── data.sqlite       (opcional, para complementos de contenido/interfaz)
├── template.html     (opcional)
├── style.css         (opcional)
└── logo.png          (opcional)
```

Archivos requeridos:

- `plugin.json` — el manifiesto del complemento (ver más abajo).

Archivos opcionales:

- Una base de datos SQLite para complementos que almacenan contenido o datos de interfaz.
- Activos HTML, Markdown, imágenes o JSON referenciados por el manifiesto.

Todas las referencias a activos en `plugin.json` deben usar nombres de archivo planos exactos, sin rutas. Por ejemplo, usa `template.html` en lugar de `templates/template.html`.

## Lo básico del manifiesto

Un `plugin.json` mínimo se ve así:

```json
{
  "id": "org.example.myplugin",
  "name": "Example Plugin",
  "version": "0.1.0",
  "type": "ui",
  "description": "A short description of what the plugin does.",
  "extensions": [
    {
      "surface": "bible-verse-menu",
      "config": {
        "label": "Example",
        "icon": "🔌",
        "screenType": "template",
        "templateFile": "template.html"
      }
    }
  ]
}
```

### Campos comunes del manifiesto

| Campo           | Requerido                         | Descripción                                                          |
| --------------- | --------------------------------- | -------------------------------------------------------------------- |
| `id`            | Sí                                | Identificador estilo dominio invertido, por ejemplo `org.example.myplugin`. |
| `name`          | Sí                                | Nombre mostrado a los usuarios.                                      |
| `version`       | Sí                                | Versión semántica del complemento.                                   |
| `type`          | Sí                                | `ui`, `content` o `composite`.                                       |
| `description`   | No                                | Breve resumen de lo que hace el complemento.                         |
| `minAppVersion` | No                                | Versión mínima de la app de Theodia requerida.                       |
| `apiVersion`    | No                                | Versión de la API de complementos a la que apunta.                 |
| `extensions`    | Requerido para `ui` y `composite` | Matriz de declaraciones de superficie (ver más abajo).               |

### Superficies

Cada entrada de `extensions` declara dónde aparece el complemento y qué hace:

```json
{
  "surface": "home-screen",
  "config": {
    "title": "My Plugin",
    "icon": "📝",
    "screenType": "list",
    "dbTable": "Articles",
    "titleColumn": "Title"
  }
}
```

Superficies admitidas:

- `bottom-toolbar` — entrada en la pestaña inferior de Complementos.
- `home-screen` — mosaico en la pantalla de inicio.
- `hamburger-menu` — elemento en el menú principal.
- `bible-verse-menu` — acción de mantener presionado un versículo en el lector bíblico.
- `bible-chapter-toolbar` — acción en la barra de herramientas del capítulo del lector bíblico.
- `book-chapter-toolbar` — acción en la barra de herramientas del capítulo del lector de libros.
- `ai-verse-action` — acción de IA sobre un versículo (requiere que la IA esté activada).
- `ai-chapter-action` — acción de IA sobre un capítulo (requiere que la IA esté activada).
- `event` — manejador de eventos del ciclo de vida de la app.

### Tipos de pantalla

El `screenType` en la configuración de una superficie le dice a la app cómo renderizar la pantalla del complemento:

- `list` — lista desplazable de filas de base de datos.
- `data-list` — lista con agregar/editar/eliminar.
- `detail` — contenido de una sola fila o pasaje.
- `markdown` — archivo Markdown estático renderizado como HTML.
- `html` — archivo HTML estático renderizado con `react-native-render-html`.
- `template` — archivo HTML con reemplazo de marcadores `{{key}}`.
- `flashcard` — interfaz de tarjeta de memorización usando dos columnas de base de datos.

## Distribución

Una vez empaquetado como archivo `.plugin.zip`, un complemento puede:

- Importarse directamente por un usuario desde un archivo.
- Servirse desde un repositorio de catálogo.

## Consejos

- Mantén `plugin.json` como JSON válido. La app rechaza manifiestos inválidos durante la instalación.
- Usa nombres de archivo exactos para todos los activos referenciados.
- Los ID de complemento deben seguir el estilo de dominio invertido para evitar colisiones.
- Prueba el contenido del complemento sin conexión, ya que los usuarios pueden no tener conexión de red.
