---
title: Habilitar y configurar complementos
level: advanced
categories: plugins
summary: Cómo activar, desactivar e importar complementos.
---

# Habilitar y configurar complementos

Una vez instalado un complemento, puedes activarlo, desactivarlo o eliminarlo. Esta guía te muestra cómo.

## Cómo abrir los ajustes de complementos

1. Abre **Configuración**.
2. Toca **Complementos**.
3. Toca **Gestionar complementos**.

## Cómo activar o desactivar un complemento

En la lista de **Complementos instalados**, busca el complemento que quieras. Toca el interruptor de la derecha.

- **Activado** — el complemento está activo.
- **Desactivado** — el complemento está en pausa.

Algunos complementos también tienen un interruptor de activar/desactivar en la fila de **Complementos** de la pantalla de inicio.

## Cómo eliminar un complemento

1. Busca el complemento en la lista de **Complementos instalados**.
2. Toca **Desinstalar**.
3. Confirma.

## Cómo instalar un complemento nuevo

1. Abre los ajustes de complementos (arriba).
2. Toca **Importar desde archivo**.
3. Selecciona el archivo del complemento en tu dispositivo.

El complemento aparece en la lista de **Complementos instalados**. Actívalo para empezar a usarlo.

## Consejos

- Algunos complementos necesitan internet para funcionar. Es posible que no funcionen sin conexión.
- Algunos complementos necesitan una cuenta o una clave. La propia página del complemento lo explicará.
- Si un complemento causa problemas, desactívalo. Puedes seguir usando el resto de la app.
- Eliminar un complemento no borra tus notas, resaltados ni marcadores. Esos permanecen a salvo.
