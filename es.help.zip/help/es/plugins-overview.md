---
title: ¿Qué son los complementos?
level: advanced
categories: plugins
summary: Una guía en lenguaje sencillo sobre complementos y qué pueden añadir.
---

# ¿Qué son los complementos?

Un complemento es un pequeño añadido para Theodia. Los complementos añaden funciones, recursos o herramientas nuevas. Los crean personas de la comunidad de Theodia.

## Qué puede hacer un complemento

Los complementos pueden hacer muchas cosas. Algunos ejemplos:

- Añadir una nueva traducción de la Biblia.
- Añadir un comentario o léxico nuevo.
- Añadir un botón a la barra de herramientas inferior.
- Añadir un mosaico a la pantalla de inicio.
- Añadir una entrada al menú principal.
- Añadir una herramienta de estudio personalizada.

## Cómo encontrar complementos instalados

Los complementos pueden aparecer en tres lugares:

- **Barra de herramientas inferior** — una pestaña **Complementos** en la parte inferior de la pantalla.
- **Pantalla de inicio** — una cuadrícula de complementos en la pantalla de inicio.
- **Menú principal** — una entrada **Complementos** en el menú principal.

Dónde aparece un complemento depende de lo que su autor declaró en el manifiesto. Toca cualquier icono de complemento para abrirlo.

## Formatos de archivo de complemento

Theodia admite dos formatos de archivo de complemento:

- **`.plugin.zip`** — un archivo ZIP que contiene `plugin.json`, la base de datos del complemento y cualquier activo. Este es el formato recomendado. El nombre del archivo se ve como `org.example.myplugin.plugin.zip`.
- **Recursos heredados de un solo archivo** — archivos antiguos `.bible`, `.commentary`, `.lexicon`, `.book`, `.sqlite` o `.db` que incrustan el manifiesto dentro de la base de datos. Todavía funcionan, pero tienen menos funciones.

## Cómo instalar un complemento nuevo

Theodia no tiene una tienda de complementos dentro de la app. Para instalar un complemento:

1. Busca el archivo del complemento en tu dispositivo.
2. Abre **Configuración** → **Complementos** → **Gestionar complementos**.
3. Toca **Importar desde archivo**.
4. Selecciona el archivo del complemento.

El complemento aparece en la lista de **Complementos instalados**. Actívalo para empezar a usarlo.

## Cómo activar o desactivar un complemento

En **Configuración** → **Complementos** → **Gestionar complementos**, busca el complemento en la lista de **Complementos instalados**. Toca el interruptor de la derecha.

- **Activado** — el complemento está activo.
- **Desactivado** — el complemento está en pausa.

Desactivar un complemento oculta sus funciones. No elimina el complemento.

## Cómo eliminar un complemento

1. Abre **Configuración** → **Complementos** → **Gestionar complementos**.
2. Busca el complemento en la lista de **Complementos instalados**.
3. Toca **Desinstalar**.
4. Confirma.

## Qué hay dentro de un archivo `.plugin.zip`

Un archivo `.plugin.zip` es un archivo ZIP. Debe contener:

- `plugin.json` — el manifiesto del complemento.
- La base de datos del complemento, con el nombre exacto declarado en el manifiesto.

También puede contener:

- Activos HTML o Markdown referenciados por el manifiesto.

El manifiesto declara el `id`, `name`, `version` del complemento y lo que proporciona:

- `type`: `content`, `ui` o `composite`.
- `content`: una base de datos SQLite y esquema para contenido de Biblia, comentario, léxico, libro o devocional.
- `extensions`: superficies como `bottom-toolbar`, `home-screen`, `hamburger-menu`, acciones de versículo, botones de barra de herramientas del capítulo o manejadores de eventos.

## Una palabra de precaución

Los complementos los crean otras personas, no el equipo de Theodia. Lee la descripción del complemento antes de instalarlo. Algunos complementos pueden necesitar internet o pueden recopilar datos.

## Desarrollar complementos

Si quieres crear o editar complementos dentro del repositorio fuente de Theodia, consulta la guía [Desarrollar complementos](theodia://help/plugin-development). Explica cómo empaquetar complementos con `npm run package-plugins` e importarlos de nuevo para editarlos con `npm run import-plugin-dev`.

## ¿Dónde puedo obtener ayuda con un complemento?

Cada complemento tiene su propia página en **Gestionar complementos**. Mira allí primero. Si aún tienes una pregunta, consulta la guía [Dónde pedir ayuda](theodia://help/getting-more-help).
