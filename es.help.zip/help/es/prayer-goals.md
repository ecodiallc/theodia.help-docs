---
title: Objetivos de oración
level: everyday
categories: [prayer]
summary: Haz seguimiento de hábitos y objetivos personales de oración.
---

# Objetivos de oración

> **Modo:** Los objetivos de oración están disponibles en los modos **Estándar** y **Académico**. El modo Lector oculta las herramientas adicionales para una lectura sin distracciones. Puedes cambiar de modo en **Configuración** → **Modo de usuario de la app**.

Los objetivos de oración te permiten hacer seguimiento de los hábitos que te importan: leer una oración fija cada mañana, completar tres rutinas de oración al día, escribir en tu diario antes de dormir, pasar diez minutos en silencio, o cualquier otro patrón que elijas. Theodia ya registra tu actividad de oración, así que un objetivo simplemente observa esa actividad y te dice cómo vas.

## Qué mide un objetivo

Cuando creas un objetivo, eliges qué cuenta:

- **Rutinas** — completar cualquier rutina, una rutina específica, o una rutina que contenga un tipo de paso como silencio o lectio divina.
- **Entradas de diario** — escribir en tu diario de oración.
- **Minutos del temporizador** — pasar tiempo en el temporizador de oración.
- **Oraciones fijas** — leer una oración fija o credo.
- **Sesiones guiadas** — completar una oración guiada con audio.
- **Registro manual** — tú mismo tocas **Marcar hecho** cuando has orado.

También puedes establecer un objetivo numérico y un horario: diario, semanal, mensual, días específicos de la semana, o una sola vez.

## Crear un objetivo

1. Ve a la pestaña **Oración**.
2. Toca **Objetivos** (o el botón **+** si ya ves la fila de Objetivos).
3. Toca el botón flotante **+** para abrir el constructor de objetivos.
4. Elige una plantilla para empezar rápido, o selecciona **Empezar desde cero**.
5. Rellena los detalles: nombre, icono, color, objetivo, horario y hora del recordatorio.
6. Toca **Guardar objetivo**.

El primer objetivo que creas se fija automáticamente en la pantalla de inicio de Oración.

## Fijar un objetivo en la pantalla de inicio

Los objetivos fijados aparecen en la tarjeta **Objetivo activo** en la parte superior de la pestaña Oración y en la fila **Objetivos de oración** debajo de Estadísticas. Para fijar o desfijar un objetivo:

1. Abre la lista de objetivos.
2. Busca el objetivo que quieras.
3. Toca el objetivo y luego **Fijar en Inicio**. Toca de nuevo para **Desfijar de Inicio**.

Puedes fijar hasta dos objetivos. Solo se pueden fijar objetivos activos.

## Marcar un objetivo como hecho

Si un objetivo está configurado como **Registro manual**, Theodia no puede saber automáticamente cuándo has orado. En su lugar, lo marcas tú mismo:

1. Abre la pantalla de detalle del objetivo.
2. Toca **Marcar hecho hoy**.
3. Opcionalmente añade una breve nota, luego toca **Marcar hecho** de nuevo.

También puedes abrir el menú desbordado de la tarjeta Objetivo activo y tocar **Marcar hecho**.

## Leer tu progreso

Toca cualquier objetivo para abrir su pantalla de detalle. Verás:

- **Progreso de hoy** — qué tan cerca estás del objetivo ahora mismo.
- **Rachas** — racha actual y racha más larga.
- **Tasa de éxito** — porcentaje de días programados completados.
- **Mini calendario** — los días verdes están completados; el día contorneado es hoy.
- **Historial reciente** — últimas dos semanas de progreso.

### Acciones del objetivo

Desde la pantalla de detalle puedes:

- **Fijar** o **desfijar** de la pantalla de inicio.
- **Pausar** para dejar de hacer seguimiento por un tiempo (las rachas se congelan).
- **Reanudar** para volver a hacer seguimiento.
- **Editar** para cambiar el objetivo, horario, recordatorio o estilo.
- **Eliminar** para quitar el objetivo y su historial.

## Perspectivas

La pantalla **Perspectivas** muestra tendencias entre todos tus objetivos:

- Objetivos cumplidos hoy, esta semana y este mes.
- Racha más larga actual.
- Tasas de cumplimiento semanal y mensual.
- Tiempo promedio de oración (de objetivos de temporizador).
- Objetivo más constante.
- Distribución de tipos de objetivo.

Abre Perspectivas desde el menú desbordado de la lista de Objetivos de oración.

## Atajos de teclado

Si usas un teclado externo:

- **Escape** — volver atrás.
- **Cmd + S** (iOS) o **Ctrl + S** (Android) — guardar un objetivo en el constructor.
- **Cmd + E** (iOS) o **Ctrl + E** (Android) — copiar un resumen al portapapeles desde la pantalla de detalle o de perspectivas.

## Recordatorios y días de gracia

Un objetivo puede recordarte en los días seleccionados a la hora elegida. Los recordatorios usan las notificaciones locales de tu dispositivo y respetan el ajuste maestro de notificaciones en **Configuración** → **Notificaciones**.

Los **días de gracia** protegen una racha cuando falles un día. Si configuras 1 o 2 días de gracia, tu racha no se rompe hasta que falles esa cantidad de días programados seguidos.

## Consejos

- Empieza con un objetivo. Es más fácil construir un hábito cuando te enfocas.
- Usa plantillas para patrones comunes, luego personaliza el objetivo o el horario.
- Pausa un objetivo cuando viajes o estés enfermo en lugar de eliminarlo — tus rachas se congelan y se reanudan cuando vuelvas.
- Los objetivos de registro manual funcionan para cualquier cosa que Theodia no mida automáticamente, como orar por una persona o familia específica.
- Revisa Perspectivas una vez a la semana para ver qué objetivos te resultan más fáciles y cuáles necesitan atención.
