---
title: Descripción general de Oración
level: beginner
categories: prayer
summary: Una introducción rápida a la pestaña de Oración y sus secciones principales.
---

# Descripción general de Oración

La pestaña **Oración** es un espacio dedicado a la oración. Reúne listas, sesiones guiadas, un diario, un temporizador, horarios de lectura del leccionario y oraciones fijas clásicas.

## Las secciones principales

- **Lista de oración** — lleva un registro de personas, situaciones y temas por los que oras.
- **Diario** — anota reflexiones, respuestas y pensamientos con el tiempo.
- **Generar oración** — pídele a Theophilus que escriba una oración a partir de una petición o entrada de diario.
- **Credo y oraciones fijas** — oraciones clásicas y credos de la tradición cristiana.
- **Leccionario** — horarios de lectura de las Escrituras para la oración diaria o estacional.
- **Oración guiada** — sesiones de oración guiadas por audio con texto a voz.
- **Temporizador** — sesiones de oración temporizadas con campanas opcionales.
