---
title: Rutinas
level: everyday
categories: [prayer]
summary: Crea una rutina diaria para orar, leer la Biblia, leer devocionales, repasar marcadores, resaltados y más.
---

# Rutinas

Una **rutina** es una lista ordenada de pasos. Piensa en ella como una lista de reproducción para tu vida espiritual: puede incluir oración, un pasaje bíblico, un devocional, una oración fija como el Padrenuestro, silencio, reflexión, tus peticiones de oración, marcadores, resaltados, himnos y tarjetas de memoria.

Las rutinas viven en su propia pestaña **Rutinas**. Cuando la función de rutinas está activada, la pestaña Rutinas es visible en la parte inferior de la app.

## Por qué importan las rutinas

- **Hábitos:** Una rutina convierte momentos dispersos en una sola sesión cohesionada.
- **Flexibilidad:** Puedes crear rutinas para la oración de la mañana, la lectura bíblica de la noche, la adoración familiar, el diario de gratitud, el repaso de memorización o cualquier temporada.
- **Todo en un solo lugar:** Oración, Escritura, marcadores, resaltados y herramientas de estudio pueden fluir juntos en una sola rutina.

## Iniciar una rutina

1. Toca la pestaña **Rutinas**.
2. Toca la rutina que quieras ejecutar.
3. Toca **Iniciar** para abrir el ejecutor de rutinas y avanzar por cada paso.

## Construir una rutina

1. En la lista de **Rutinas**, toca el botón **+**.
2. Ponle un nombre a la rutina y, opcionalmente, una descripción.
3. Toca **Añadir paso** y elige un tipo de paso:
   - **Pasaje** — leer un pasaje bíblico.
   - **Oración fija** — un credo, oración o liturgia de la biblioteca.
   - **Peticiones de oración** — orar por tus peticiones activas.
   - **Silencio / Reflexión / Oración libre** — espacio temporizado o abierto.
   - **Sesión guiada** — una sesión de oración con voz.
   - **Himno** — leer o cantar un himno.
   - **Tarjetas de memoria** — repasar tarjetas de memorización.
   - **Devocional** — leer una entrada devocional.
   - **Repaso de marcadores** — revisitar marcadores guardados.
   - **Repaso de resaltados** — revisar versículos resaltados.
4. Reordena los pasos tocando las flechas arriba/abajo de cada paso. Establece una duración o etiqueta si quieres.
5. Toca **Guardar**.

## Fijar una rutina

Las rutinas fijadas aparecen en la parte superior de la lista de Rutinas.

1. Abre la lista de **Rutinas**.
2. Mantén presionada una rutina.
3. Toca **Fijar**.

## Añadir algo a una rutina

Casi cualquier cosa de la app puede convertirse en un paso de rutina:

- **Lector bíblico:** Toca un versículo, luego el botón **+** y elige una rutina.
- **Marcadores:** Mantén presionado un marcador bíblico, o toca el botón **+**, y elige una rutina.
- **Oraciones fijas:** Toca el botón **+** en cualquier fila de oración fija.
- **Peticiones de oración:** Toca el botón **+** en una fila de petición.
- **Resaltados:** Elige un paso de repaso de resaltados para revisitar versículos marcados.

Puedes insertar el elemento al inicio, al final o después de un paso específico.

## Completar una rutina

El ejecutor de rutinas te lleva por cada paso. Algunos pasos avanzan automáticamente; otros esperan a que toques **Siguiente**. Al final ves una pantalla de celebración con opciones para añadir la rutina a una lista de reproducción o empezar otra.

Una marca de verificación verde aparece en la tarjeta de la rutina durante el resto del día para mostrar que se completó.

## Eliminar o editar una rutina

- **Editar:** Abre la lista de rutinas, toca una rutina y luego **Editar**.
- **Eliminar:** Mantén presionada una rutina y toca **Eliminar**. Las rutinas integradas no se pueden eliminar, pero puedes ocultarlas desfijándolas.

## Nota de privacidad

Las rutinas y sus datos permanecen en tu dispositivo. Las estadísticas y las insignias son opcionales; para desactivarlas, ve a **Configuración** → **Oración** y desactiva las opciones de seguimiento.
