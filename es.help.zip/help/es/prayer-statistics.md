---
title: Estadísticas de oración y rachas
level: everyday
categories: prayer
summary: Cómo funcionan las rachas de oración y cómo desactivar estadísticas e insignias.
---

# Estadísticas de oración y rachas

La pantalla **Estadísticas** de la pestaña Oración hace seguimiento de tu actividad de oración y tus rachas cuando las **Estadísticas de oración** están habilitadas en **Configuración** → **Oración**. Está diseñada para fomentar un hábito diario de oración sin ser intrusiva.

## Qué cuenta como actividad

Se registran como actividad de oración las siguientes acciones:

- **Rutinas** de oración completadas
- **Sesiones guiadas** completadas
- **Sesiones del temporizador** completadas
- Peticiones de oración marcadas como **oradas**
- **Oraciones fijas** leídas
- Entradas del **leccionario** leídas
- **Entradas de diario** añadidas

Todas estas aparecen en tu resumen de actividad.

## Solo las rutinas extienden tu racha

Tu **racha de oración** es el número de días consecutivos en los que has completado al menos una rutina de oración.

- Completar una rutina extiende la racha.
- Otra actividad de oración se registra, pero por sí sola no extiende la racha.
- Si faltas un día, la racha se reinicia a cero.
- Completar más de una rutina en un día sigue contando como un solo día de racha.

> **Consejo:** Si quieres construir o mantener una racha, haz que las rutinas sean el centro de tu tiempo diario de oración.

## Qué muestra la pantalla de Estadísticas

- **Racha actual** — días consecutivos con una rutina completada.
- **Racha más larga** — tu mejor racha de todos los tiempos.
- **Resumen de actividad** — totales de esta semana, este mes y en total.
- **Calendario** — vista mes por mes de los días con actividad de oración.

## Insignias

Cuando **Mostrar insignias de oración** está habilitado, puedes ganar logros ocultos por hitos de oración. Las insignias son una función divertida tipo huevo de Pascua, no un requisito.

Las insignias requieren que las Estadísticas de oración estén habilitadas. Si las estadísticas están desactivadas, las insignias también se ocultan.

## Cómo desactivar estadísticas e insignias

Puedes desactivar estas funciones en cualquier momento:

1. Abre **Configuración** → **Oración**.
2. Desactiva **Habilitar estadísticas de oración**.
3. Desactiva **Mostrar insignias de oración**.

Cuando las estadísticas están desactivadas:

- Las rachas ya no se cuentan.
- La sección de Estadísticas desaparece de la pestaña Oración.
- Las insignias se ocultan.
- Los datos de oración existentes permanecen en tu dispositivo; no se elimina nada.

Para volver a habilitar las estadísticas más tarde, simplemente vuelve a activar el interruptor.
