---
title: Leer libros incorporados
level: beginner
categories: [content, read]
summary: Cómo leer los clásicos cristianos que vienen con la app.
---

# Leer libros incorporados

Theodia incluye una pequeña biblioteca de libros cristianos. Son clásicos que puedes leer en tu dispositivo.

## Cómo abrir la biblioteca

Toca la pestaña **Libros** en la parte inferior de la pantalla. Verás una lista de los libros de tu biblioteca.

## Cómo leer un libro

1. Toca el título del libro.
2. El libro se abre en el primer capítulo.
3. Usa los botones **Anterior** y **Siguiente** de la parte superior para moverte entre capítulos.

## Cómo saltar a un capítulo

Toca el nombre del capítulo en la parte superior de la pantalla. Aparece una lista de capítulos. Elige uno para saltar a él.

## Cómo cambiar el tamaño de fuente

Abre **Configuración** → **Apariencia** y elige un tamaño de fuente. El tamaño del texto cambia en toda la app, incluidos los libros.

## Cómo añadir un marcador en un libro

Toca el icono de **estrella** en la esquina superior derecha. Se guarda el capítulo actual. Toca la pestaña **Marcadores** para ver tus páginas guardadas.

## Cómo escuchar un libro

Toca el icono de **altavoz** en la esquina superior derecha. La app lee el capítulo en voz alta. Tócalo de nuevo para detener.

## Qué libros están disponibles?

La biblioteca tiene clásicos como:

- El progreso del peregrino
- La imitación de Cristo
- Práctica de la presencia de Dios
- El himnario

La lista de libros puede crecer con el tiempo. Las actualizaciones de la app pueden añadir más.

## Consejos

- Los libros se almacenan en tu dispositivo. No necesitas internet.
- Los libros no se sincronizan con la nube.
