---
title: Buscar recursos en GitHub
level: everyday
categories: resources
summary: Busca a la vez en todos los repositorios de GitHub que la app conoce, e instala lo que encuentres.
---

# Buscar recursos en GitHub

Theodia mantiene una lista de repositorios de GitHub que publican recursos: Biblias, comentarios, libros, devocionales, listas de reproducción, paquetes de oración y más. **Buscar repositorios de GitHub** busca en todos ellos a la vez, de modo que no tienes que abrir cada pestaña y explorarlas por separado.

> La sección de GitHub de Configuración solo está disponible en el **modo Académico**. Para activarlo, ve a **Configuración** → **Modo de usuario de la app** → **Académico**.

## Cómo buscar

1. Abre **Configuración**.
2. Toca **Buscar repositorios de GitHub**.
3. Escribe una palabra en el cuadro de búsqueda. La app busca esa palabra en el **nombre** y la **descripción** de cada paquete de cada repositorio.

Algunas cosas que conviene saber sobre la búsqueda:

- **Todas las palabras tienen que coincidir.** Buscar `morning evening` solo encuentra paquetes cuyo nombre o descripción contenga *ambas* palabras.
- **Las mayúsculas no importan.** `Morning` y `morning` encuentran los mismos paquetes.
- **La mejor coincidencia aparece primero.** Un paquete cuyo nombre *empieza* por tu búsqueda se muestra antes que uno que solo la menciona en la descripción.

## Filtrar

Toca la barra de filtros situada encima de los resultados para reducir aún más la lista. Hay dos filtros, y funcionan juntos:

- **Autor** — solo los paquetes de ese autor.
- **Tradición** — solo los paquetes de esa tradición.

Toca un filtro otra vez para quitarlo, o toca **Borrar filtros** para restablecer ambos.

## Instalar desde un resultado

Cada resultado muestra el nombre del paquete, qué tipo de recurso es, quién lo hizo y de qué repositorio procede. A la derecha de la fila hay un botón:

- **Instalar** — el paquete aún no está en tu dispositivo.
- **Actualizar** — hay una versión más reciente disponible. La app te pide confirmar primero, porque actualizar elimina la copia antigua junto con las notas, los resaltados o los marcadores que apunten a ella.
- **Abrir** — el paquete ya está instalado; al tocarlo vas a la pantalla donde lo usas.

Toca **Actualizar** en la parte superior para obtener la lista más reciente de GitHub de inmediato. La app actualiza la lista por sí sola una vez al día, así que solo necesitas una actualización manual cuando sabes que se ha publicado algo nuevo.

## Buscar sin conexión

La app guarda una copia de la lista en tu dispositivo, por lo que la búsqueda funciona incluso sin conexión. Si la app no puede comunicarse con GitHub para actualizar la lista, un banner en la parte superior te indica que estás viendo los resultados en caché.

## Si la búsqueda no encuentra nada

- Prueba con una palabra más corta, una sola.
- Comprueba que no haya un filtro de **Autor** o de **Tradición** aplicado; el botón **Borrar filtros** aparece siempre que haya alguno.
- Algunos repositorios publican sus paquetes en un idioma distinto al del nombre del paquete, por lo que buscar una palabra traducida puede no encontrarlos.
