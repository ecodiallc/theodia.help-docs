---
title: Modo académico
level: advanced
categories: [layout, read, study]
summary: El modo de estudio más profundo de Theodia, que desbloquea comentarios, léxicos, referencias cruzadas, herramientas de IA y el menú rápido.
---

# Modo académico

> **Modo:** El modo académico solo está disponible cuando tu modo de usuario está en **Académico**. Cambia de modo en **Configuración** → **Modo de usuario de la app**.

El modo académico desbloquea todas las herramientas de estudio de Theodia. Se construye sobre el modo de estudio, así que sigues teniendo el menú de versículo, Biblias paralelas, marcadores, resaltados y notas, más las herramientas avanzadas que se listan a continuación.

## Cómo abrir el modo académico

El modo académico no es una pantalla separada. Es un conjunto de herramientas extra que aparecen dentro del lector y la navegación existentes cuando tu modo de usuario es Académico.

1. Abre **Configuración**.
2. Toca **Modo de usuario de la app**.
3. Elige **Académico**.

El cambio surte efecto inmediatamente. Los menús y botones que estaban ocultos aparecen ahora.

## Herramientas extra del lector

Cuando abres un capítulo en [modo de estudio](theodia://help/study-mode), el modo académico añade estas herramientas al menú de versículo:

- **Comentario de IA** (◈) — pide al asistente de IA que escriba una nota de estudio para este versículo. (No disponible en todas las regiones.)
- **Información de la palabra** (?) — abre una entrada del léxico para la palabra original en hebreo o griego detrás del versículo. Consulta la guía [Comentarios y léxicos](theodia://help/commentaries-and-lexicons).
- **Diccionario** (📖) — busca palabras bíblicas generales en los recursos de diccionario que tengas instalados. Consulta la guía [Diccionario bíblico](theodia://help/dictionary).

Estas herramientas necesitan recursos instalados (comentarios, léxicos, archivos de diccionario). Si una herramienta aparece atenuada o muestra "no encontrado", abre **Configuración** → **Gestionar recursos** y añade el recurso que necesita.

## Navegación extra

### Pestaña adicional en la barra

La barra inferior gana una pestaña extra:

- 💻 **IA** — abre el asistente de IA (solo si has activado la IA en Configuración). Esta pestaña se sitúa a la derecha de Notas bíblicas.

### Elementos extra del menú rápido

El menú rápido incluye una entrada de **Asistente de IA** bajo las mismas condiciones.

## El menú rápido

El modo académico activa el **Menú rápido**, una forma rápida de saltar a versículos recientes, ejecutar comandos y cambiar la disposición de la Biblia sin salir de tu pantalla actual. Consulta la guía [Menú rápido](theodia://help/launcher-menu) para saber cómo usarlo.

## Cuándo usar el modo académico

- Quieres el asistente de IA, comentarios o consultas del idioma original mientras lees.
- Quieres el menú rápido para navegación rápida de versículos y chat con IA.
- Estás estudiando un pasaje en profundidad y necesitas todas las herramientas a un toque.

## Cambiar a un modo más ligero

Si quieres un lector más sencillo sin las herramientas avanzadas, cambia al modo **Estándar** en **Configuración** → **Modo de usuario de la app**. El modo Estándar conserva marcadores, resaltados, notas y el modo de estudio, pero oculta la IA, comentarios, léxicos y el menú rápido.

Si quieres la experiencia de lectura más limpia posible, abre un capítulo en [modo de enfoque](theodia://help/focus-mode).

Tus marcadores, resaltados y notas nunca se eliminan al cambiar de modo; simplemente se ocultan hasta que vuelvas a un modo que los soporte.

## Ayuda y preguntas

Si falta una herramienta o muestra un error, consulta la guía [Solución de problemas comunes](theodia://help/common-problems). Si eres nuevo en Theodia, la guía [Leyendo tu primer capítulo](theodia://help/first-read) te guía paso a paso por lo básico.
