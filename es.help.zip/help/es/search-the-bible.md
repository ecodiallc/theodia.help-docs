---
title: Buscar en la Biblia
level: everyday
categories: [study, read]
summary: Cómo encontrar versículos por palabra, frase o referencia.
---

# Buscar en la Biblia

La barra de búsqueda te ayuda a encontrar versículos rápido. Puedes buscar por una palabra, una frase o una referencia bíblica.

## Cómo empezar una búsqueda

1. Toca la pestaña **Buscar** en la parte inferior de la pantalla.
2. Escribe lo que quieres encontrar.
3. Toca **Buscar** en el teclado.

Los resultados aparecen como una lista de versículos. Cada resultado muestra el libro, el capítulo, el versículo y el texto del versículo.

## Buscar por combinación de palabras

Cuando escribes más de una palabra, como `love joy`, la app encuentra versículos que contienen **ambas** palabras. Esta es una búsqueda **AND**: todas las palabras deben aparecer en el versículo. **No** usa lógica **OR** (versículos con cualquiera de las palabras).

Para buscar versículos que contengan cualquiera de las palabras, debes usar la palabra clave `OR` explícitamente: `love OR joy`.

## Buscar por palabra

Escribe una sola palabra, como `love` o `mercy`. La app muestra cada versículo de la Biblia que la contiene.

## Buscar por frase

Escribe dos o tres palabras entre comillas, como `"do not be afraid"`. La app muestra los versículos que tienen esa frase exacta.

## Filtrar los resultados

Después de una búsqueda, los resultados se filtran según las traducciones de la Biblia que tengas instaladas. Para reducir más, abre la pestaña **Biblias** y consulta una traducción específica: las búsquedas se ejecutan contra las traducciones instaladas.

## Consejos para mejores búsquedas

- Usa palabras cortas. Buscar `love` encuentra más versículos que buscar `loving`.
- Las comillas alrededor de una frase hacen la búsqueda exacta.
- La app solo busca en las traducciones de la Biblia que tengas instaladas.
- Para saltar a un versículo específico por referencia (por ejemplo, `John 3:16`), usa la caja de **Comando rápido** en la pantalla de inicio en lugar de la pestaña Buscar.

## Historial de búsqueda

La app recuerda tus búsquedas más recientes. Cuando abres la pestaña **Buscar**, la lista muestra arriba tus búsquedas recientes. Toca una para volver a ejecutarla. Para borrar la lista, toca **Borrar todo** en la parte superior de las búsquedas recientes.

## Buscar en los PDF

La pestaña **Buscar** también puede buscar dentro de tus documentos PDF:

1. Toca la pestaña **Buscar** y luego toca el modo **PDF** en la parte superior.
2. Elige qué PDF buscar. Toca un PDF para incluirlo o excluirlo; usa **Todo** o **Limpiar** sobre la lista para incluirlos todos o empezar de nuevo. Solo se pueden elegir los PDF cuyo texto buscable esté instalado.
3. Escribe lo que quieres encontrar y toca **Buscar**.

Cada resultado muestra el título del PDF, el número de página y un fragmento del texto coincidente. Toca un resultado para abrir ese PDF en esa página.

Para buscar dentro de un solo PDF mientras lo lees, usa en su lugar el botón **Buscar** del lector de PDF; consulta [PDF](theodia://help/pdfs).
