---
title: Modo de estudio
level: everyday
categories: [layout, read]
summary: El lector bíblico completo de Theodia, con herramientas de estudio como comentario, referencias cruzadas, léxico y notas.
---

# Modo de estudio

> **Modo:** El modo de estudio está disponible en los modos **Estándar** y **Académico**. El modo Lector abre los capítulos en modo de enfoque. Puedes cambiar de modo en **Configuración** → **Modo de usuario de la app**.

El modo de estudio es el lector bíblico principal de Theodia. Tiene todas las herramientas de estudio integradas: comentario, referencias cruzadas, consultas de palabras, traducciones paralelas, notas y más.

El modo de enfoque es un lector más sencillo sin herramientas de estudio. Consulta la guía [Modo de enfoque](theodia://help/focus-mode) si solo quieres texto limpio. Esta guía es para el modo de estudio.

## Cómo abrir el modo de estudio

Hay varias formas de abrir un capítulo en modo de estudio:

- Toca la pestaña **Biblias** en la parte inferior. Elige una traducción, un libro y un capítulo.
- Toca un versículo en los resultados de **Buscar**.
- Toca un marcador de la pestaña **Marcadores**.
- Desde el modo de enfoque, toca el botón **📖** en la parte superior para cambiar al modo de estudio.

## Leyendo el capítulo

El capítulo se abre con los versículos en orden. En la parte superior hay botones para las acciones más comunes. En la parte inferior hay una barra de estado.

- **Desliza a la izquierda** para ir al capítulo siguiente.
- **Desliza a la derecha** para ir al capítulo anterior.
- **Toca un versículo** para abrir el menú de versículo con las herramientas de estudio (ver más abajo).
- **Toca un número de Strong en un versículo** (por ejemplo, G1234 o H1234) para abrir una consulta rápida del léxico de esa palabra.

Si tienes activada una traducción paralela, aparece una segunda copia del capítulo debajo de la principal, en la traducción elegida. Consulta **Leer dos traducciones a la vez** más abajo.

## El menú de versículo

Cuando tocas un versículo, se abre un menú con el título "Libro Capítulo:Versículo". Las herramientas que ves dependen de tu modo de usuario.

### Herramientas en los modos Estándar y Académico

- **Marcador** (★) — guarda el versículo para encontrarlo de nuevo. Tócalo otra vez para quitar el marcador. El primer toque lo añade. Consulta la guía [Guardar marcadores](theodia://help/bookmarks).
- **Resaltar** (□) — colorea el versículo para que resalte. Tócalo para abrir el selector de color. Toca el mismo color de nuevo para quitar el resaltado. Consulta la guía [Resaltar versículos](theodia://help/highlights).
- **Hablar** (🔊) — lee el versículo en voz alta con la voz de texto a voz de tu dispositivo. No se muestra para Biblias interlineales. Consulta la guía [Lectura en voz alta](theodia://help/tts) para saber cómo usarlo y elegir una voz.
- **Copiar** (⎘) — copia el texto del versículo al portapapeles para pegarlo donde quieras.
- **Comparar** (⇄) — abre un panel que muestra el mismo versículo en cada traducción instalada. Toca una traducción en el panel para leer el versículo en ella. Consulta la guía [Comparar traducciones](theodia://help/compare-translations).
- **Referencias cruzadas** (↗) — abre una lista de versículos relacionados de la base de datos de referencias cruzadas. Consulta la guía [Referencias cruzadas](theodia://help/cross-references).
- **Añadir/Editar nota bíblica** (✎) — escribe tu propia nota privada adjunta al versículo. Consulta la guía [Escribir notas](theodia://help/notes).

### Herramientas solo en modo Académico

- **Comentario de IA** (◈) — pide al asistente de IA que escriba una nota de estudio para este versículo. (No disponible en todas las regiones.)
- **Información de la palabra** (?) — abre una entrada del léxico para la palabra original en hebreo o griego detrás del versículo. Consulta la guía [Comentarios y léxicos](theodia://help/commentaries-and-lexicons).
- **Diccionario** (📖) — busca palabras bíblicas generales en los recursos de diccionario que tengas instalados. Consulta la guía [Diccionario bíblico](theodia://help/dictionary).

Algunas herramientas necesitan recursos adicionales instalados. Si una herramienta aparece atenuada o muestra "no encontrado", abre **Configuración** → **Gestionar recursos** y añade el recurso que necesita.

## Botones de la parte superior

Encima del texto del capítulo hay una fila de iconos. Son acciones rápidas:

- **Versión de la Biblia** — toca el nombre de la traducción (por ejemplo, "KJV") para cambiar a otra traducción.
- **Libro** — toca el nombre del libro para saltar a otro libro.
- **Capítulo** — toca el número del capítulo para saltar a otro capítulo.
- **Abrir en IA** (🤖) — envía el capítulo actual al asistente de IA con tu pregunta. (Solo modo Académico.)
- **Modo de enfoque** (📖) — cambia al modo de enfoque para lectura limpia.
- **Biblias paralelas** (🔵 / ⚪) — toca para activar o desactivar las traducciones paralelas. Cuando está activado, el mismo capítulo se muestra en las traducciones paralelas elegidas debajo del texto principal. Cuando está desactivado, solo se muestra la traducción principal. Consulta **Leer varias traducciones a la vez** más abajo.
- **Hablar** — lee todo el capítulo en voz alta. Consulta la guía [Lectura en voz alta](theodia://help/tts).
- **Más** — abre acciones adicionales del capítulo (nota bíblica del capítulo, comentario del capítulo, compartir, etc.).

## Leer varias traducciones a la vez

Puedes mostrar hasta cuatro traducciones adicionales junto a la principal. Esto se llama **vista paralela**.

1. Abre **Configuración**.
2. Activa **Biblia paralela**.
3. Toca **Añadir biblia paralela** y elige una traducción.
4. Repite para añadir más. Puedes tener hasta cuatro traducciones paralelas.

Cuando la vista paralela está activa, cada versículo del capítulo muestra primero tu traducción principal, seguido del mismo versículo en cada traducción paralela. Así es fácil comparar cómo distintos traductores manejan un versículo difícil sin salir del capítulo.

Puedes guardar tu configuración paralela actual como un **conjunto**. Toca el botón de guardar junto a tus traducciones seleccionadas, ponle un nombre y se convierte en una opción de cambio rápido. Toca cualquier conjunto después para cargar esa combinación al instante. Mantén presionado un conjunto para eliminarlo.

También puedes comparar un solo versículo a la vez con la herramienta **Comparar** (⇄) del menú de versículo. Eso abre un panel que muestra el versículo en cada traducción instalada.

## Títulos de sección

Algunas traducciones tienen encabezados de sección incorporados (por ejemplo, "El Sermón del Monte"). Si tu traducción los tiene, puedes mostrarlos u ocultarlos con el ajuste **Mostrar títulos de sección** en **Configuración**. Los títulos aparecen como pequeños títulos grises entre versículos.

## La nota del capítulo

Una nota de capítulo es una sola nota adjunta a todo el capítulo, no a un solo versículo. Es útil para una idea general sobre el capítulo.

Para abrir la nota del capítulo:

1. Toca el botón **Más** en la parte superior de la pantalla.
2. Toca **Nota de capítulo**.
3. Escribe tu nota. Toca **Guardar**.

La nota del capítulo se guarda con el capítulo. Aparece cada vez que abres ese capítulo.

## Resaltado de búsqueda

Si llegaste al capítulo desde una búsqueda, tus palabras de búsqueda se resaltan en amarillo en el texto del versículo. Esto facilita ver por qué un versículo coincidió.

También puedes volver a buscar en un capítulo que estás leyendo. Abre la pestaña **Buscar** y escribe una palabra. Los resultados te permiten tocar y volver al capítulo con las coincidencias resaltadas.

Las Biblias interlineales (MIB — Marvel Interlinear Bible — y OHGB) siempre se abren en modo de estudio porque necesitan el diseño a nivel de palabra.

## Cambiar al modo de enfoque para un solo capítulo

Desde cualquier capítulo en modo de estudio, toca el botón **📖** en la parte superior. El mismo capítulo se abre en modo de enfoque con todos los menús ocultos. Toca el botón **📖** en la barra inferior para volver al modo de estudio.

## Cuándo usar el modo de estudio

El modo de estudio es la opción correcta cuando quieras:

- **Leer y estudiar al mismo tiempo.** Todas las herramientas están a un toque.
- **Buscar una palabra que no conoces.** Toca un número de Strong en el versículo para una entrada del léxico rápida.
- **Comparar traducciones.** Usa la herramienta Comparar del menú de versículo o activa la vista paralela.
- **Ver cómo un versículo se conecta con el resto de la Biblia.** Usa Referencias cruzadas.
- **Tomar notas mientras lees.** El menú de versículo tiene una opción rápida para añadir notas.

Para lecturas largas sin distracciones, cambia al modo de enfoque.

## Cambiar al modo de enfoque

Desde cualquier capítulo en modo de estudio, toca el botón **📖** en la parte superior. El mismo capítulo se abre en [modo de enfoque](theodia://help/focus-mode) con los menús y herramientas de estudio ocultos. Toca el botón **📖** en la barra inferior para volver al modo de estudio. Para una descripción completa de lo que hace el modo de enfoque, consulta la guía [Modo de enfoque](theodia://help/focus-mode).

## Ayuda y preguntas

Si falta una herramienta o muestra un error, consulta la guía [Solución de problemas comunes](theodia://help/common-problems). Si eres nuevo en Theodia, la guía [Leyendo tu primer capítulo](theodia://help/first-read) te guía paso a paso por lo básico.
