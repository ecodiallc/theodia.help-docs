---
title: Funciones de la tableta
level: everyday
categories: [layout, tablet]
summary: Cómo se adapta el diseño de Theodia a tabletas y pantallas grandes, con vistas divididas, paneles laterales y modos de lectura de dos paneles.
---

# Funciones de la tableta

Theodia está diseñada para aprovechar las pantallas más grandes de las tabletas. En una tableta (o cualquier dispositivo de más de unos 700 píxeles de ancho), la app cambia automáticamente a un diseño de dos columnas en muchos lugares.

> **Modo:** Las funciones descritas aquí aparecen solo si tu modo de usuario actual las admite. Por ejemplo, los paneles laterales de comentario y el chat de IA solo están disponibles en modo Académico. Las vistas divididas de Marcadores, Resaltados y Notas requieren Estándar o Académico. El modo de enfoque muestra solo lectura limpia en una sola columna. Puedes cambiar de modo en **Configuración** → **Modo de usuario de la app**.

## Menú de versículo del lector

Cuando tocas un número de versículo (o mantienes presionado el texto del versículo), el **menú de versículo** aparece como una **tarjeta centrada** sobre un fondo oscuro.

- Los botones **Copiar** y **Compartir** siempre son visibles en la parte superior del menú.
- **Marcadores** y **Resaltados** se muestran con su estado actual.
- **Comentario**, **Diccionario** y **Comparar** se abren desde el menú. En una tableta estas herramientas pueden aparecer en un panel lateral o en una tarjeta amplia una vez seleccionadas.
- Toca el fondo o la flecha de cierre para descartar el menú.

## Panel de comentario del versículo

La herramienta **Comentario** abre un **panel lateral dedicado** en una tableta:

- El texto del comentario aparece junto al texto bíblico.
- Puedes desplazar el comentario independientemente de la Biblia.
- Toca la **X** o desliza para cerrar.
- Un **icono de libro** en la parte superior del panel te permite cambiar de fuente de comentario.
- Un **icono de capítulo** te permite ver el comentario a nivel de capítulo.

En un teléfono, el comentario se abre como una pantalla modal a pantalla completa.

## Comentario del capítulo

El **Comentario del capítulo** se accede desde el botón **Más** en la parte superior de la pantalla, no desde el menú de versículo. En una tableta se abre como un panel lateral igual que el Comentario del versículo, así que puedes leer el comentario y el texto bíblico juntos.

## Pestaña Comparar

La pestaña **Comparar** (en el menú de versículo) se abre como un **panel lateral** en una tableta. Muestra el versículo seleccionado en cada versión paralela que tengas activada. Puedes tocar cualquier versión para saltar a ese pasaje en el lector.

## Ventana emergente del diccionario / Strong

La herramienta **Diccionario** (menú de versículo → Diccionario) se abre como una tarjeta amplia en una tableta. Muestra la palabra griega o hebrea, su transliteración, definición y número de Strong. Toca el botón **Concordancia** para ver cada aparición de esa palabra en la Biblia.

## Toca una palabra para abrir su léxico

En el panel lateral de **Información de la palabra** en una tableta, cada tarjeta de palabra que tiene un número de Strong es tocable. Toca la tarjeta para abrir el panel **Léxico** de esa palabra directamente. El panel de Léxico reemplaza el panel de Información de la palabra para que puedas seguir estudiando sin cerrar el lector.

En un teléfono, las tarjetas de Información de la palabra no son tocables porque la pantalla es demasiado pequeña para dos paneles.

## Biblias paralelas lado a lado

En Configuración, toca **Biblias paralelas** y elige hasta tres versiones. En una tableta, las versiones aparecen como **paneles verticales** uno al lado del otro:

- Cada panel se desplaza independientemente.
- Puedes tocar un número de versículo para abrir un panel lateral con herramientas.
- La pestaña **Comparar** muestra todos los versículos seleccionados en un solo lugar.
- Toca la **X** de cualquier panel para cerrarlo y volver a la vista de una sola columna.
- Toca el icono de **Biblias paralelas** (🔵 / ⚪) en la barra de iconos superior para activar o desactivar la vista paralela sin abrir Configuración.

En un teléfono, las versiones paralelas se muestran una debajo de otra (verticalmente) en lugar de lado a lado. El mismo icono de alternancia funciona en teléfonos.

## Vista dividida de marcadores y resaltados

En una tableta, las pestañas **Marcadores** y **Resaltados** usan un diseño maestro-detalle:

- **Lado izquierdo** — la lista de marcadores o resaltados.
- **Lado derecho** — al tocar un elemento se abre un panel de vista previa con el texto del versículo o pasaje.

Puedes repasar tus elementos guardados y previsualizarlos sin salir de la pestaña. En un teléfono, tocar un elemento navega a la pantalla del lector.

## Vista dividida de notas

La pestaña **Notas bíblicas** en una tableta muestra tu lista de notas a la izquierda y la nota seleccionada a la derecha. Tocar una nota la abre en un panel lateral para que puedas repasar varias notas seguidas sin salir de la lista. Crear o editar una nota también usa un panel lateral.

## Vista dividida de búsqueda

En una tableta, la pestaña **Buscar** muestra el formulario de búsqueda a la izquierda y los resultados a la derecha tan pronto como ejecutas una búsqueda. Puedes refinar tu consulta y ver cómo se actualizan los resultados sin cambiar de pantalla. En un teléfono, los resultados de búsqueda se abren en una pantalla separada.

## Barra lateral de categorías de Configuración

La pantalla de **Configuración** en una tableta muestra una lista de categorías a la izquierda (IA, Apariencia, Copia de seguridad, Biblias, etc.). Toca una categoría para saltar directamente a sus ajustes a la derecha. Solo la categoría seleccionada está expandida, así que nunca necesitas desplazarte por toda la lista de ajustes.

## Navegación bíblica en tabletas

Las pantallas de **Lista de Biblias**, **Libros de la Biblia** y **Capítulos de la Biblia** permanecen en una sola columna en tabletas, pero usan áreas de toque más grandes, cuadrículas más anchas y más espacio entre elementos para que el contenido sea más fácil de leer y tocar. No usan diseño dividido porque cada paso necesita el ancho completo para mostrar su lista o cuadrícula claramente.

## Apaisado y vertical

Girar la tableta ajusta el diseño automáticamente. En **apaisado**, los paneles laterales tienen mucho espacio. En **vertical**, los paneles se hacen más estrechos pero siguen al lado del texto.

## Chat de IA del versículo seleccionado

El chat de **IA** se abre en el panel lateral del menú de versículo. Muestra una interfaz de conversación donde puedes hacer preguntas sobre el versículo seleccionado. La respuesta de la IA aparece en el panel, y puedes continuar la conversación sin salir del lector.

## Barra lateral de conversaciones en la pantalla de IA

En la pestaña **IA** de una tableta, la lista de conversaciones siempre es visible como una barra lateral izquierda persistente. Puedes cambiar entre chats sin abrir un menú. El botón **Nuevo chat** también siempre es visible. En un teléfono, la lista de conversaciones es un cajón emergente.

## Qué permanece igual

No todas las pantallas se dividen en dos paneles. Las siguientes permanecen en una sola columna en tabletas:

- **Lista de Biblias** — lista de versiones de la Biblia (ancho completo)
- **Libros de la Biblia** — cuadrícula de libros y secciones (ancho completo)
- **Capítulos de la Biblia** — cuadrícula de capítulos (ancho completo)
- **PDF** — la biblioteca de PDF usa una cuadrícula de tarjetas más ancha (ancho completo)
- **Configuración** — páginas de ajustes individuales (ancho completo)
- **Ayuda** — artículos de ayuda (ancho completo)

## Resumen

En una tableta obtienes:

- **Biblias paralelas** en paneles verticales lado a lado
- **Comentario** en paneles laterales persistentes
- **Comparar** y **Diccionario** en tarjetas anchas
- **Léxico** con un toque en cualquier tarjeta de Información de la palabra
- **Marcadores, Resaltados, Notas, Devocionales, Libros, Configuración** en vistas maestro-detalle
- **Buscar** con resultados en línea junto al formulario de búsqueda
- **Apaisado** y **vertical** compatibles, con cambios automáticos de diseño

En un teléfono, todo usa la navegación tradicional de una sola columna con niveles. La app detecta el ancho de pantalla al iniciarse y elige el diseño adecuado automáticamente.
