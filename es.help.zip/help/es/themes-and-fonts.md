---
title: Cambiar temas y fuentes
level: everyday
categories: settings
summary: Cómo cambiar la apariencia de la app.
---

# Cambiar temas y fuentes

Theodia te permite cambiar el aspecto de la app. Puedes elegir un tema (claro u oscuro) y un tamaño de fuente.

## Cómo abrir los ajustes de apariencia

1. Abre **Configuración**.
2. Toca **Apariencia**.

## Cómo cambiar el tema

En la sección **Apariencia**, ves dos botones de tema:

- **Predeterminado** — fondo claro con texto oscuro. Bueno para el día.
- **Oscuro** — fondo oscuro con texto claro. Bueno para la noche y ahorra batería.

Toca un tema para aplicarlo. El cambio es inmediato.

## Cómo cambiar el tamaño de fuente

En la sección **Apariencia**, toca uno de los botones de tamaño: **---**, **--**, **-**, **Normal**, **+**, **++**, **+++**. El texto se hace más pequeño o más grande en toda la app. Elige el tamaño que te resulte más fácil de leer.

## Consejos

- El tema oscuro ahorra batería en teléfonos con pantallas OLED.
- Si el texto es demasiado pequeño, aumenta el tamaño de fuente en la app, no en el dispositivo. El ajuste de la app es más preciso.
- Para lecturas largas, prueba el tema oscuro y una fuente más grande.
- [Activar el tema desierto](theodia://unlock-desert)
