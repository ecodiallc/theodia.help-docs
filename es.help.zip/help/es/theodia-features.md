---
title: Funciones de Theodia
level: beginner
categories: welcome
summary: Resumen rápido de lo que hace especial a Theodia y cómo te ayuda a estudiar la Biblia.
---

# Funciones de Theodia

Theodia está construida para ser un compañero completo de estudio bíblico. Esto es lo que la distingue.

## Primero sin conexión

Todo funciona sin internet. Las Biblias, comentarios, léxicos, libros y devocionales se almacenan en tu dispositivo. Puedes leer, buscar y estudiar en cualquier lugar —en un avión, en una zona remota o donde no haya señal.

## Enfocada en la privacidad

Tus datos se quedan contigo. Las notas, resaltados, marcadores e historial de lectura se guardan localmente en tu dispositivo. No se necesita cuenta, y no se envía nada a ningún servidor a menos que elijas usar el **Asistente de IA** opcional.

## Soporte para tabletas

Theodia está diseñada tanto para teléfonos como para tabletas. En una pantalla grande, tienes más espacio para leer, vistas paralelas de la Biblia y un diseño que aprovecha el espacio extra.

## Recursos instalables

No estás limitado a lo que viene con la app. Puedes añadir más versiones de la Biblia, comentarios, léxicos, libros y devocionales. Los recursos están disponibles en la página de GitHub del proyecto y se pueden instalar directamente en la app.

## Asistente de IA

El **Asistente de IA** opcional te ayuda a entender versículos, explicar contexto y responder preguntas. Solo está activo si lo enciendes. De forma predeterminada se conecta a un modelo remoto que tú proporcionas a través de un punto de acceso y una clave API que configures. La primera vez que usas la IA, la app pide tu permiso y te muestra exactamente qué se envía.

## Lectura paralela de la Biblia

Lee hasta cuatro versiones de la Biblia a la vez. Cuando abres un capítulo, tu traducción principal aparece primero, y cada versículo va seguido del mismo versículo en las traducciones paralelas que elegiste. Compara palabras, estudia las diferencias y obtén una imagen más completa del texto. Guarda tus combinaciones favoritas como preajustes y cámbialos rápidamente.

## Búsqueda de texto completo

Busca en cualquier versión de la Biblia. Busca palabras, frases o coincidencias parciales. También puedes limitar la búsqueda a un rango de libros.

## Referencias cruzadas

Toca una referencia de versículo para saltar directamente a ese pasaje. Las referencias cruzadas están integradas y funcionan en toda la Biblia.

## Léxico y números de Strong

Toca un número de Strong para ver la definición griega o hebrea original. Las entradas del léxico están incluidas para un estudio de palabras más profundo.

## Marcadores y resaltados

Guarda versículos con marcadores y márcalos con colores. Todo se almacena localmente y persiste entre sesiones.

## Notas

Escribe tus propios pensamientos junto a cualquier versículo. Las notas están vinculadas al versículo y son fáciles de encontrar más tarde.

## Devocional diario

Empieza tu día con una breve lectura devocional. La app incluye devocionales que abren automáticamente la entrada de hoy.

## Libros cristianos

Lee literatura cristiana clásica dentro de la app. Los libros están formateados para una lectura cómoda e incluyen una tabla de contenidos para una navegación rápida.

## Varios idiomas

Theodia admite muchos idiomas tanto para la interfaz de la app como para el contenido bíblico. Cambia de idioma en la configuración para estudiar en tu idioma preferido.

## Modo oscuro y temas

Elige entre modo claro u oscuro, o selecciona un tema que se adapte a tu preferencia. La comodidad de lectura importa, especialmente con poca luz.

## Copia de seguridad de datos

Haz una copia de seguridad de tus notas, marcadores y resaltados. Mantén tus datos a salvo y muévelos a un dispositivo nuevo cuando lo necesites.

## Sin anuncios, sin distracciones

Theodia está construida para la concentración. No hay anuncios, ni ventanas emergentes, ni interrupciones. Solo el texto y tus herramientas de estudio.
