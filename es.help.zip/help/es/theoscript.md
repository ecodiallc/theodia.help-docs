---
title: Theoscripts
level: everyday
categories: theoscript
summary: Automatiza la lectura de la Biblia, el habla, los marcadores y más con sencillos comandos de Theoscript.
---

# Theoscripts

Los **Theoscripts** son pequeños guiones que automatizan cosas dentro de Theodia. Un guión puede hablar un pasaje, abrir un capítulo, poner un marcador, mostrar un mensaje, ejecutar otro comando y más. Son una forma rápida de crear atajos personales o pequeños ayudantes devocionales sin salir de la app.

## Dónde viven los Theoscripts

Abre **Theoscript** desde la pantalla de inicio o el menú principal. La pantalla solo aparece cuando existe al menos un Theoscript.

La biblioteca muestra:

- **Guiones** — cada guión que has creado o importado.
- **Categorías** — carpetas opcionales que agrupan guiones relacionados.

Toca un guión para ejecutarlo. Mantén presionado un guión para editarlo, duplicarlo o eliminarlo.

## Crear un guión nuevo

1. Ve a **Theoscript**.
2. Toca **+ Añadir guión**.
3. Ponle un nombre al guión.
4. Escribe los comandos en el campo **Contenido del guión**.
5. Toca **Guardar**.

Cada comando va en su propia línea. Sangra las líneas dentro de un bloque con dos espacios.

## Comandos comunes

| Comando                | Qué hace                                   | Ejemplo                                       |
| ---------------------- | ------------------------------------------ | --------------------------------------------- |
| `speak`                | Lee en voz alta un texto o pasaje          | `speak "Good morning"` o `speak John 3:16`    |
| `open`, `read`, `show` | Abre un pasaje en el lector                | `open Psalm 23`                               |
| `bookmark`             | Guarda el pasaje actual como marcador      | `bookmark`                                    |
| `highlight`            | Resalta el versículo actual                | `highlight yellow`                            |
| `message`              | Muestra un mensaje emergente               | `message "Done reading"`                      |
| `set`                  | Cambia un ajuste o valor                   | `set theme dark`                              |
| `return`               | Detiene el guión antes de tiempo           | `return`                                      |
| `with playlist`        | Añade pistas a una lista de reproducción   | `with playlist "Morning" track John 3:16 end` |
| `start playlist`       | Reproduce una lista de reproducción        | `start playlist "Morning"`                    |
| `with note`            | Crea una nota                              | `with note "John 3:16" "My thoughts" end`     |

## Control de flujo

Usa `if` para ejecutar comandos solo cuando una condición es verdadera:

```text
if chapter == 1 {
  message "Starting a new book!"
}
```

Usa `repeat` para repetir un bloque de comandos:

```text
repeat 3 {
  speak "Peace be with you"
}
```

Usa `for` para recorrer una lista:

```text
for $ref in ["John 3:16", "Psalm 23:1", "Romans 8:28"] {
  open $ref
  speak $ref
}
```

Usa `function` y `call` para reutilizar bloques de código:

```text
function greet $name {
  message "Hello, " + $name
}
call greet "friend"
```

## Variables

Guarda un valor en una variable con `let`:

```text
let $name = "Theophilus"
message "Welcome, " + $name
```

Las cadenas literales en el lado derecho deben ir entre comillas simples o dobles. Esto evita confundir un valor literal con un comando o nombre de variable. Los números, las variables y las expresiones de comando no necesitan comillas:

```text
let $count = 42
let $text = $last.passageText
let $words = count words in $text
let $greeting = "Hello, " + $name
```

Las variables son útiles dentro de bucles, funciones y definiciones de listas de reproducción.

## Guiones de ejemplo

### Saludo y un versículo

```text
speak "Good morning. Here is your verse for today."
open John 3:16
speak John 3:16
```

### Marcar tres versículos favoritos

```text
open John 3:16
bookmark
open Psalm 23:1
bookmark
open Romans 8:28
bookmark
message "Favorites saved."
```

### Crear una lista de reproducción hablada

```text
with playlist "Commute" {
  track John 3:16
  track Psalm 23
  track Romans 8:28
}
start playlist "Commute"
```

### Mensaje condicional

```text
open Genesis 1:1
if book == "Genesis" {
  message "In the beginning..."
}
```

## Organizar guiones

Toca **Gestionar categorías** para crear categorías. Cuando editas un guión, elige la categoría en la que quieres que esté. Las categorías ayudan a mantener separados los guiones personales, de ejemplo y de voz.

## Exportar e importar

Toca el menú dentro de la biblioteca de Theoscript para:

- **Exportar Theoscripts** — guardar todos los guiones en un archivo.
- **Exportar esta categoría** — guardar solo la categoría seleccionada.
- **Importar Theoscripts** — cargar un archivo previamente exportado.

Los archivos exportados son texto plano y se pueden compartir con otros usuarios de Theodia.

## Ejecutar guiones desde Comandos

Los Theoscripts también se pueden ejecutar por nombre desde el **Menú rápido** o pidiéndolos con Comandos. Por ejemplo, decir o escribir `run My Morning Script` buscará y ejecutará el guión llamado _My Morning Script_ si existe.

## Solución de problemas

- **No ocurre nada al tocar Ejecutar.** Comprueba que el contenido del guión no esté vacío y que cada comando esté escrito correctamente.
- **Speak no lee nada.** Asegúrate de que un pasaje esté abierto, o pasa texto entre comillas directamente a `speak`.
- **Un comando aparece resaltado con un error.** Los Theoscripts muestran errores cuando un comando es desconocido o una referencia no es válida. Edita el guión e inténtalo de nuevo.
