---
title: Lectura en voz alta (texto a voz)
level: everyday
categories: tts
summary: Haz que Theodia lea la Biblia o un devocional en voz alta. Cómo usarlo, cómo elegir una voz y qué hacer cuando se queda en silencio.
---

# Lectura en voz alta (texto a voz)

> **Modo:** El texto a voz está disponible en los modos **Estándar** y **Académico**. El modo de enfoque es solo para lectura limpia y sin distracciones. Puedes cambiar de modo en **Configuración** → **Modo de usuario de la app**.

Theodia puede leer texto en voz alta usando la voz de texto a voz (TTS) de tu dispositivo. Puedes escuchar un solo versículo, un capítulo completo o un devocional. Es útil para leer sin usar las manos, escuchar mientras caminas o viajas, seguir el texto con audio o simplemente descansar los ojos.

## Dónde está el botón de escuchar

Encontrarás un botón de escuchar en tres lugares.

### 1. En el menú de versículo (un solo versículo)

Esta es la forma más rápida de escuchar un versículo a la vez. Abre un capítulo en [modo de estudio](theodia://help/study-mode), toca un versículo para abrir el menú de versículo y luego toca **Hablar** (🔊). La lectura empieza desde ese versículo. Aparece una pequeña barra de control en la parte inferior con reproducir, pausar, retroceder, avanzar y selector de voz.

La opción Hablar no se muestra para Biblias interlineales (MIB — Marvel Interlinear Bible — y OHGB), ya que muestran las palabras en una disposición diferente que no se lee de forma natural.

### 2. En la parte superior de un capítulo (capítulo completo)

Cuando lees un capítulo, mira la fila de iconos de la parte superior. Toca **Hablar** (🔊) para empezar a leer el capítulo completo desde el principio. El botón se convierte en un botón de detener (⏹) mientras el audio suena. Tócalo de nuevo para detener. Aparece la misma barra de control en la parte inferior.

Puedes saltar a otro versículo, y el botón Hablar de allí empezará desde ese versículo.

### 3. En un devocional

Abre cualquier día de un devocional y toca el botón **Hablar** (🔊) en la parte superior de la lectura. Se lee el texto completo del devocional, frase por frase. Una barra de control en la parte inferior te da reproducir, pausar, retroceder y controles de voz.

## Usar la barra de control

Mientras suena el audio, una pequeña barra permanece visible en la parte inferior de la pantalla. Tiene seis controles:

- ⏪ **Retroceder** — vuelve un versículo (o una frase en un devocional)
- ⏸ **Pausa / ▶ Reanudar** — pausa sin perder el lugar. Toca de nuevo para continuar desde el mismo punto.
- ⏩ **Avanzar** — salta al siguiente versículo (o frase siguiente en un devocional)
- 🎙 **Voz** — abre el selector de voz sin salir del capítulo (ver más abajo)
- ⚙ **Opciones** — abre el panel de opciones extendidas (ver más abajo)
- **Detener** — toca el botón 🔊 en la parte superior de la pantalla, o el ⏹ que lo reemplaza mientras suena el audio, para detener y cerrar la barra.

La barra de control se cierra cuando termina el capítulo o cuando tocas detener.

### Opciones extendidas

Toca ⚙ para expandir opciones adicionales de reproducción. Estos ajustes duran solo para el capítulo actual y se reinician al cambiar de capítulo o detener la lectura.

- ⏮ **Volver al inicio** — salta al primer versículo del rango que estableciste.
- **Inicio** — escribe un número de versículo para establecer dónde empieza la lectura.
- **Fin** — escribe un número de versículo para establecer dónde termina la lectura.
- **Todo** — restablece el rango al capítulo completo.
- **()** — alterna si se lee en voz alta el texto entre paréntesis.
- 🔁 **Repetir** — reinicia automáticamente al principio del rango cuando se llega al final, con una breve pausa entre medias. Si lo activas sin establecer un versículo de inicio o fin, se repite el capítulo completo.

## Cómo cambiar la voz

Puedes elegir qué voz usa Theodia para leer. Esto es útil si quieres otro acento, otro idioma, o una voz más rápida o lenta que la predeterminada del dispositivo.

1. Abre **Configuración**.
2. Busca la sección **Voz**.
3. Toca **Seleccionar voz**.
4. Aparece una lista de voces. La primera fila, **Voz predeterminada del sistema**, usa la voz que tu dispositivo prefiere. Elige cualquier otra fila para establecerla como nueva predeterminada.
5. Tu elección se guarda y se usa la próxima vez que toques **Hablar**.

También puedes tocar el icono 🎙 de la barra de control de lectura para abrir el mismo selector sin salir del capítulo.

La disponibilidad de voces depende completamente de tu dispositivo. iOS y Android incluyen un conjunto de voces integradas. Puedes instalar más voces desde los ajustes de **Accesibilidad** o **Idioma y entrada** de tu dispositivo. Theodia puede usar cualquier voz instalada en tu dispositivo.

## Voces favoritas

Si tu dispositivo tiene muchas voces, desplazarte por la lista completa cada vez puede ser lento. Puedes crear una lista corta de **voces favoritas** y los selectores de voz mostrarán solo esas voces.

1. Abre **Configuración**.
2. Busca la sección **Voz**.
3. Toca **Voces favoritas** (la primera fila superior de la sección).
4. Toca **Establecer voces favoritas** para abrir la pantalla de favoritos.
5. Toca el botón de reproducir junto a una voz para previsualizarla. Toca la estrella para añadirla a tus favoritos. Puedes marcar tantas voces como quieras.
6. Vuelve atrás. Los selectores de voz de Theodia ahora muestran solo tus voces favoritas.

Si quitas todos los favoritos, los selectores vuelven a mostrar todas las voces. Las voces favoritas se incluyen cuando haces una copia de seguridad y restauras la configuración de Theodia.

## Establecer una voz diferente por Biblia

Puedes asignar una voz propia a cada traducción de la Biblia. Esto es útil cuando cambias entre traducciones que se leen muy diferente — por ejemplo, una voz más formal para la King James Version y una más conversacional para una traducción moderna como NIV o NLT. También ayuda si escuchas Biblias en distintos idiomas y quieres que cada una hable con el acento correcto.

1. Abre **Configuración**.
2. Busca la sección **Voz**.
3. Busca **Voces de la Biblia**.
4. Toca cualquier Biblia de la lista.
5. Elige la voz que quieres para esa traducción. La primera fila, **Voz predeterminada del sistema**, usa tu voz TTS principal para esa Biblia.
6. Repite para cualquier otra Biblia.

La próxima vez que escuches un capítulo de esa Biblia, Theodia usará la voz que elegiste. Las demás Biblias siguen usando la voz predeterminada principal a menos que también la cambies.

## Continuar lectura en segundo plano

De forma predeterminada, Theodia detiene la lectura cuando sales de la pantalla del lector, cambias a otra app o bloqueas el teléfono. Esto evita audio inesperado cuando ya no estás leyendo activamente.

Para permitir que la lectura siga sonando en segundo plano:

1. Abre **Configuración**.
2. Busca la sección **Voz**.
3. Activa **Continuar lectura en segundo plano**.

Cuando esto está activado, puedes cambiar de pestaña, abrir otra app o bloquear la pantalla y el capítulo o devocional seguirá leyendo. La barra de control permanece activa para que puedas pausar o saltar desde el área de notificaciones (si tu dispositivo lo permite).

Apagar este interruptor **mientras la lectura ya está sonando** la detendrá inmediatamente.

## Qué hacer si no funciona

El texto a voz depende de tu dispositivo. Theodia envía el texto al sistema operativo, y este lo lee en voz alta con una voz. Si no funciona, prueba estos pasos en orden.

### Theodia dice que el TTS no está disponible

Algunos dispositivos no tienen TTS. Abre **Configuración** y busca la sección **Voz**. Si la sección no está, tu dispositivo no admite TTS en esta compilación.

### La lista de voces está vacía

El selector de voz puede mostrar "no se encontraron voces". Esto suele significar que el dispositivo aún no ha terminado de cargar sus voces.

1. Abre **Configuración → Voz → Seleccionar voz**.
2. Si la lista está vacía, busca un botón **Verificar de nuevo** justo debajo de la lista. Tócalo. Theodia vuelve a consultar al dispositivo por las voces.
3. Si sigue vacía, revisa los ajustes del sistema de tu dispositivo. En iOS, ve a **Ajustes → Accesibilidad → Contenido hablado → Voces** y descarga una voz para tu idioma. En Android, ve a **Ajustes → Idioma y entrada → Salida de texto a voz** y toca **Instalar datos de voz**.
4. Cierra y vuelve a abrir Theodia para que detecte la nueva voz.

Si has establecido voces favoritas y la lista está vacía, asegúrate de que al menos una de tus favoritas coincida con una voz instalada en este dispositivo.

### Tocas Hablar pero no pasa nada

- Comprueba que el dispositivo no esté en modo silencioso. La mayoría de los dispositivos no reproducen audio TTS en modo silencioso.
- Asegúrate de que el volumen del dispositivo esté subido.
- Prueba el botón **Verificar de nuevo** en **Configuración → Voz**.
- Abre **Configuración** y mira la sección **Sistema** en la parte inferior. La fila **Voz** debería decir **Disponible**. Si dice **No disponible**, el TTS está desactivado a nivel del sistema operativo. Reactívalo allí y luego vuelve a abrir Theodia.

### El audio suena pero en otro idioma

Theodia envía el texto en el idioma del contenido actual y pide la voz que seleccionaste. Si la voz elegida es de otro idioma, el dispositivo puede seguir leyendo el texto, pero sonará extraño.

1. Abre **Configuración → Voz → Seleccionar voz**.
2. Elige **Voz predeterminada del sistema** para que el dispositivo elija la correcta, o elige una voz cuyo idioma coincida con el texto que estás leyendo.

Theodia no lee en voz alta las Biblias interlineales en griego o hebreo. Los botones Hablar y Escuchar están ocultos en esas traducciones.

### El audio suena pero se detiene pronto

Si falta un versículo o es ilegible, el capítulo salta al siguiente. Si la barra se cierra sola después de unos versículos, toca el botón **Hablar** (🔊) en la parte superior de la pantalla para empezar de nuevo.

### La lectura suena pero no sé dónde empezó

Si activaste **Continuar lectura en segundo plano** y luego escuchas audio pero no encuentras la pantalla que lo inició, puedes detenerlo desde cualquier parte de la app.

1. Abre **Configuración**.
2. Busca la sección **Voz**.
3. Toca el botón rojo **Detener voz** en la parte inferior de la sección.

Esto detiene inmediatamente cualquier texto a voz en ejecución en Theodia. También puedes abrir el selector de apps de tu dispositivo y deslizar Theodia fuera para forzar la detención del audio.

### Lee demasiado rápido o lento

Theodia no controla la velocidad de lectura. La velocidad la establece la voz elegida. Para cambiarla:

- En iOS: **Ajustes → Accesibilidad → Contenido hablado → Velocidad de habla**.
- En Android: **Ajustes → Idioma y entrada → Salida de texto a voz → Velocidad de habla**.

## Consejos

- La barra de control permanece visible mientras navegas entre capítulos, así que puedes pausar, saltar o cambiar de voz sin perder el lugar.
- Theodia lee los números de versículo como pequeñas pausas. Puedes detener la barra, deslizar a otro versículo y luego tocar reproducir para continuar desde allí.
- Para escuchas largas, activa **No molestar** para que las notificaciones no interrumpan el audio.
- El botón 🔊 usa el volumen actual de tu dispositivo. Si conectas auriculares, el volumen cambia al nivel de los auriculares.

## Leer un PDF en voz alta

Theodia también puede leer en voz alta las páginas de un PDF. Abre un PDF y toca el botón **Escuchar** (altavoz) de su barra de herramientas. Aparece una barra de control con reproducir/pausar, retroceder, avanzar, detener, una barra de progreso y los selectores de velocidad y voz. Cuando termina una página, la lectura continúa automáticamente en la página siguiente.

La lectura de PDF usa el texto buscable instalado del PDF y las mismas voces y velocidad que la lectura de la Biblia.

## Guías relacionadas

- La guía [Modo de estudio](theodia://help/study-mode) cubre con más detalle el menú de versículo y los botones de la parte superior.
- La guía [Modo de enfoque](theodia://help/focus-mode) es una vista de lectura más limpia que también admite texto a voz mediante el botón 🔊 de la barra inferior.
- La guía [Solución de problemas comunes](theodia://help/common-problems) tiene soluciones para otros problemas de audio, voz e idioma.
- La guía [Devocionales diarios](theodia://help/daily-devotionals) cubre la lectura devocional y dónde está el botón de escuchar en esa pantalla.
- La guía [PDF](theodia://help/pdfs) cubre el lector de PDF y su botón de escuchar.
