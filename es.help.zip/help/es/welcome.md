---
title: Bienvenido a Theodia
level: beginner
categories: welcome
summary: Un breve recorrido por la aplicación y lo que puede hacer por ti.
---

# Bienvenido a Theodia

Theodia es una aplicación de estudio bíblico. Funciona en tu teléfono o tableta, incluso sin internet. Todo lo que lees, buscas y estudias se guarda en tu dispositivo.

## Qué puedes hacer

Theodia tiene tres modos de usuario. Cada uno muestra un conjunto diferente de funciones.

- **Lector** — lee la Biblia en una vista limpia y sin distracciones.
- **Estándar** — todo lo del modo Lector, más marcadores, resaltados, notas, texto a voz, búsqueda y devocionales diarios.
- **Académico** — todo lo del modo Estándar, más comentarios, léxicos, el diccionario bíblico, el asistente de IA y más.

Puedes cambiar de modo en cualquier momento en **Configuración** → **Modo de usuario de la app**.

### Funciones disponibles para ti

Independientemente del modo que elijas, siempre puedes:

- **Leer la Biblia.** Elige entre muchas traducciones. Cambia entre ellas en cualquier momento.
- **Buscar en la Biblia.** Busca una palabra o frase. La aplicación te muestra cada versículo que coincide.
- **Leer libros y devocionales.** La aplicación incluye clásicos cristianos y un devocional diario.

Según tu modo, también podrás:

- **Escuchar.** Escucha los versículos en voz alta con la función de lectura en voz alta. (Modos Estándar y Académico.)
- **Tomar notas.** Escribe tus propios pensamientos junto a un versículo. (Modos Estándar y Académico.)
- **Resaltar.** Marca tus versículos favoritos con color. (Modos Estándar y Académico.)
- **Guardar marcadores.** Guarda versículos para encontrarlos rápido. (Modos Estándar y Académico.)
- **Preguntar al asistente de IA.** Recibe ayuda para entender un versículo. (Solo modo Académico.)

## Por dónde empezar

1. Abre la pestaña **Biblias** en la parte inferior de la pantalla.
2. Elige una traducción.
3. Toca cualquier libro para empezar a leer.

Si quieres saber más, el resto de las guías de ayuda están aquí. Elige un tema de la lista en la pantalla de inicio de la ayuda.

## Algunas cosas que debes saber

- No necesitas una cuenta.
- Tus notas, resaltados y marcadores permanecen en tu dispositivo.
- Puedes hacer copias de seguridad. Consulta la guía [Copias de seguridad de tus datos](theodia://help/backups) para saber cómo.

## ¿Quieres más recursos?

La aplicación incluye varias versiones de la Biblia disponibles libremente. Para biblias, comentarios, léxicos, libros y devocionales adicionales, consulta la guía [Obtener recursos adicionales desde GitHub](theodia://help/getting-core-files). Te muestra cómo encontrar y añadir más recursos desde la página de GitHub del proyecto.

Bienvenido. Esperamos que Theodia te ayude a leer y estudiar.
