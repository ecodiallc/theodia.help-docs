---
title: Qué son los recursos?
level: beginner
categories: resources
summary: Una visión general de los distintos tipos de archivos que usa Theodia: Biblias, comentarios, libros y más.
---

# Qué son los recursos?

En Theodia, un "recurso" es cualquier archivo que añade material de lectura o estudio a la app. La propia app es solo un lector y un cuaderno. Las Biblias, comentarios, libros y otros materiales con los que estudias son archivos separados que cargas.

Esta guía explica los distintos tipos de recursos y para qué sirve cada uno.

## Por qué importa

Cuando abres Theodia por primera vez, ya tiene algunas cosas para leer. A medida que explores, verás botones para instalar más. Saber qué tipo de recurso es cada uno te ayudará a decidir qué añadir.

## Los distintos tipos de recursos

Theodia reconoce los archivos por su extensión. Cada extensión es un tipo diferente de recurso.

### `.bible` — una traducción de la Biblia

Una traducción de la Biblia es una copia completa de la Biblia en una versión particular, como la King James Version. Theodia viene con algunas traducciones y te permite añadir más.

Consulta la guía [Instalar traducciones de la Biblia](theodia://help/installing-bibles) para más detalles.

### `.commentary` — un comentario

Un comentario es un libro de notas de estudio escrito por un erudito de la Biblia. Para un versículo dado, un comentario te cuenta el trasfondo, el significado y cómo encaja el versículo en el resto de la Biblia.

Consulta la guía [Comentarios y léxicos](theodia://help/commentaries-and-lexicons) para más detalles.

### `.lexicon` — un léxico

Un léxico es un diccionario de palabras bíblicas. Te dice la palabra original en hebreo o griego, qué significa y cómo se usa en la Biblia.

Consulta la guía [Comentarios y léxicos](theodia://help/commentaries-and-lexicons) para más detalles.

### `.book` — un libro cristiano

Un libro es una obra cristiana más larga, como un clásico de la historia de la iglesia. Leer libros en la app funciona de forma muy parecida a leer la Biblia. Theodia incluye una pequeña biblioteca de clásicos cristianos disponibles libremente.

Consulta la guía [Leer libros incorporados](theodia://help/reading-books) para más detalles.

### `.devotional` — un devocional

Un devocional es una breve lectura diaria. Cada entrada suele tener un versículo, una breve reflexión y una oración o pregunta para pensar. Muchos devocionales están diseñados para leer una entrada por día durante un año.

Consulta la guía [Devocionales diarios](theodia://help/daily-devotionals) para más detalles.

### `.sqlite` — una base de datos de referencia

Una base de datos de referencia es un archivo de consulta grande que la app usa para darte información extra mientras lees. Hay dos tipos:

- **Referencias cruzadas** — listas de versículos que se conectan con el que estás leyendo.
- **Morfología** — información sobre las palabras originales en hebreo o griego del versículo.

No abres estos archivos directamente. Funcionan en segundo plano y añaden funciones al lector bíblico. Consulta la guía [Referencias cruzadas](theodia://help/cross-references) para más detalles.

### `.data` — datos de palabras

Un archivo de datos de palabras contiene información extra sobre las palabras originales de la Biblia. Lo usan el léxico y las herramientas de estudio. Al igual que las bases de datos de referencia, no lo abres directamente. La app lo usa en segundo plano.

## Cómo añadir un recurso

La pantalla **Gestionar recursos** de la app es la forma fácil de añadir un recurso.

1. Abre **Configuración**.
2. Toca **Gestionar recursos**.
3. Toca **Instalar desde GitHub**.
4. En la ventana de descarga, elige una pestaña — **Biblias**, **Comentarios**, **Libros**, **Devocionales** o **Centro** — luego selecciona lo que quieres y toca **Instalar seleccionados**.
5. O toca **Instalar archivo local** para importar un archivo que ya hayas descargado.

Para un recorrido paso a paso sobre cómo obtener archivos directamente desde GitHub, consulta la guía [Obtener recursos adicionales desde GitHub](theodia://help/getting-core-files).

## Cómo quitar un recurso

1. Abre **Configuración**.
2. Toca **Gestionar recursos**.
3. Busca el recurso que quieres quitar.
4. Toca el icono de papelera junto a él.
5. Confirma que quieres eliminarlo.

Quitar un recurso no elimina tus notas, resaltados ni marcadores. Esos permanecen a salvo.

## Dónde viven los recursos en tu dispositivo

Los recursos se almacenan en tu dispositivo, no en la nube. Una vez instalado un recurso, no necesitas internet para leerlo. Puedes hacer una copia de seguridad de tu dispositivo, pero los recursos en sí no se respaldan en la nube desde Theodia. Si desinstalas y vuelves a instalar la app, tendrás que volver a añadir los recursos que tenías instalados.

## Ayuda y preguntas

Si tienes problemas, consulta la guía [Dónde pedir ayuda](theodia://help/getting-more-help). El equipo y la comunidad pueden ayudarte.
