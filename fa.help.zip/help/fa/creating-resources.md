---
title: ساخت منابع خودتان
level: advanced
categories: resources
summary: چگونه منابع سفارشی کتاب مقدس، تفسیر، کتاب، دعای روزانه، و لغت‌نامه بسازید و آن‌ها را به Theodia وارد کنید.
---

# ساخت منابع خودتان

Theodia منابع سفارشی در قالب Unique Bible App را پشتیبانی می‌کند. هر منبع یک فایل SQLite با ساختار جدول خاص است. می‌توانید این فایل‌ها را روی رایانه بسازید و به اپ وارد کنید.

## نوع فایل‌ها و جدول‌های مورد نیاز

### کتاب مقدس (`.bible`)

یک فایل کتاب مقدس یک پایگاه دادهٔ SQLite است که حداقل یکی از این جدول‌ها را دارد:

- **`Verses`** — ستون‌ها: `Book` (عدد صحیح، ۱-۶۶)، `Chapter` (عدد صحیح)، `Verse` (عدد صحیح)، `Scripture` (متن)
- **`Bible`** — ستون‌ها: `Book` (عدد صحیح)، `Chapter` (عدد صحیح)، `Verse` (عدد صحیح)، `Scripture` (متن)

همچنین می‌توانید یک جدول **`Details`** با ستون‌های metadata مانند `Description`، `Abbreviation` و `Version` بگنجانید.

مثال SQL:

```sql
-- Main text table
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- Optional metadata table
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### تفسیرها (`.commentary`)

تفسیرها در سه نوع می‌آیند: **کتاب**، **فصل**، و **آیه**. نوع با **اولین حرف نام فایل** تعیین می‌شود.

#### تفسیرهای کتاب — نام فایل با `b` شروع می‌شود

یک تفسیر کتاب تمام یک کتاب کتاب مقدس را در یک ورودی پوشش می‌دهد. جدول `Commentary` به ستون‌های `Book` و `Scripture` (یا `Content`) نیاز دارد. ستون‌های `Chapter` یا `Verse` لازم نیستند.

- **`Commentary`** — ستون‌ها: `Book` (عدد صحیح)، `Scripture` (متن) یا `Content` (متن)

مثال SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

مثال نام فایل: `bMyCommentary.commentary`

#### تفسیرهای فصل — نام فایل با `c` شروع می‌شود

یک تفسیر فصل هر فصل یک کتاب کتاب مقدس را پوشش می‌دهد.

- **`Commentary`** — ستون‌ها: `Book` (عدد صحیح)، `Chapter` (عدد صحیح)، `Scripture` (متن) یا `Content` (متن)

مثال SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

مثال نام فایل: `cMyCommentary.commentary`

#### تفسیرهای آیه — نام فایل با `v` شروع می‌شود

یک تفسیر آیه آیات تکی را پوشش می‌دهد. جدول `Commentary` به ستون‌های `Book`، `Chapter`، `Verse` و `Scripture` (یا `Content`) نیاز دارد.

- **`Commentary`** — ستون‌ها: `Book` (عدد صحیح)، `Chapter` (عدد صحیح)، `Verse` (عدد صحیح)، `Scripture` (متن) یا `Content` (متن)

مثال SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

مثال نام فایل: `vMyCommentary.commentary`

### کتاب‌ها (`.book`)

یک فایل کتاب یک پایگاه دادهٔ SQLite با جدول `Reference` است.

- **`Reference`** — ستون‌ها: `id` (عدد صحیح)، `Chapter` (متن)، `Content` (متن)

هر ردیف یک فصل است. ستون `Chapter` عنوان فصل است. ستون `Content` بدنهٔ فصل است که می‌تواند شامل HTML باشد (`<b>`، `<i>`، `<br>` و غیره).

مثال SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

همچنین می‌توانید کتاب‌ها را از فایل‌های Markdown بسازید. اپ می‌تواند فایل‌های `.md` را وارد کند که `#` عنوان کتاب و `##` نشان‌گر فصل‌هاست. Markdown به صورت خودکار به HTML تبدیل می‌شود.

### دعاهای روزانه (`.devotional`)

یک فایل دعای روزانه یک پایگاه دادهٔ SQLite با جدول `devotional` است.

- **`devotional`** — ستون‌ها: `month` (عدد صحیح، ۱-۱۲)، `day` (عدد صحیح، ۱-۳۱)، `devotion` (متن)

هر ردیف خواندن یک روز است. اپ ورودی را بر اساس ماه و روز امروز پیدا می‌کند.

مثال SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### لغت‌نامه‌ها (`.lexicon`)

یک فایل لغت‌نامه یک پایگاه دادهٔ SQLite با جدول `Lexicon` است.

- **`Lexicon`** — ستون‌ها: `Topic` (متن، شمارهٔ strong's)، `Definition` (متن، ورودی لغت‌نامه)

ستون `Topic` شمارهٔ strong's را نگه می‌دارد (برای مثال `G1161` یا `H7225`). ستون `Definition` متن کامل ورودی را نگه می‌دارد که می‌تواند شامل HTML باشد.

مثال SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

لغت‌نامه‌ها ابزار Word Info را تغذیه می‌کنند. وقتی در یک کتاب مقدس میان‌خطی روی واژه‌ای می‌زنید، اپ شمارهٔ strong's را در لغت‌نامه‌های نصب‌شده جستجو می‌کند.

## ساخت فایل روی رایانهٔ خود

1. یک ویرایشگر SQLite نصب کنید (DB Browser for SQLite، SQLiteStudio، یا ابزار command-line `sqlite3`).
2. یک پایگاه دادهٔ جدید بسازید.
3. جدول مورد نیاز را بسازید و دادهٔ خود را درج کنید.
4. فایل را با پسوند درست (`.bible`، `.commentary`، `.book`، `.devotional`، یا `.lexicon`) ذخیره کنید.

## وارد کردن به Theodia

1. فایل را به دستگاه خود منتقل کنید (AirDrop، ایمیل، ذخیرهٔ ابری، یا USB).
2. **Theodia** را باز کنید.
3. به **تنظیمات** → **مدیریت منابع** بروید.
4. **وارد کردن از فایل** را بزنید.
5. فایل خود را انتخاب کنید.

اپ فایل را اعتبارسنجی می‌کند (وجود جدول مورد نیاز را بررسی می‌کند)، آن را به پوشهٔ دادهٔ اپ کپی می‌کند، و به صورت خودکار فعالش می‌کند. اگر فایل نامعتبر باشد، پیام خطا نشان می‌دهد که چه چیزی نادرست است.

## محدودیت‌ها

- نمی‌توانید منابع داخلی را جایگزین کنید. اگر تلاش کنید فایلی با نام یکسان با یک کتاب مقدس، تفسیر، یا کتاب داخلی وارد کنید، وارد کردن ناموفق می‌شود.
- فایل‌های کتاب مقدس به جدول `Verses` یا `Bible` نیاز دارند. اگر هیچ‌کدام وجود نداشته باشد، وارد کردن ناموفق می‌شود.
- فایل‌های تفسیر به جدول `Commentary` نیاز دارند.
  - تفسیرهای کتاب به ستون‌های `Book` و `Scripture` (یا `Content`) نیاز دارند.
  - تفسیرهای فصل به ستون‌های `Book`، `Chapter` و `Scripture` (یا `Content`) نیاز دارند.
  - تفسیرهای آیه به ستون‌های `Book`، `Chapter`، `Verse` و `Scripture` (یا `Content`) نیاز دارند.
- فایل‌های کتاب به جدول `Reference` نیاز دارند.
- فایل‌های لغت‌نامه به جدول `Lexicon` نیاز دارند.
- فایل‌های دعای روزانه به جدول `devotional` نیاز دارند.

## نکته‌ها

- حجم فایل‌ها را معقول نگه دارید. فایل‌های SQLite بسیار بزرگ ممکن است روی دستگاه‌های قدیمی مسائل حافظه ایجاد کنند.
- فایل خود را ابتدا روی رایانه آزمایش کنید. آن را در یک مرورگر SQLite باز کنید و `SELECT * FROM` جدول مورد نیاز را اجرا کنید تا تأیید کنید داده درست به نظر می‌رسد.
- برای کتاب مقدس، مطمئن شوید ستون `Book` از اعداد استفاده می‌کند (1 = پیدایش، 66 = مکاشفه).
- برای تفسیرها، می‌توانید از `Scripture` یا `Content` به عنوان ستون متن تفسیر استفاده کنید.
- برای کتاب‌ها، HTML در ستون `Content` هنگام خواندن نمایش داده می‌شود. آن را ساده نگه دارید: `<b>`، `<i>`، `<br>` و `<hr>` ایمن هستند.

## کجا منابع موجود را بیابید

Theodia می‌تواند منابع را از پروژهٔ [Unique Bible App](https://github.com/eliranwong/UniqueBible) بخواند. بسیاری از کتاب مقدس‌ها، تفسیرها، کتاب‌ها و سایر منابع آنجا در قالب SQLite صحیح در دسترس‌اند. برای یافتن و افزودن آن‌ها [راهنمای Getting Extra Resources](theodia://help/getting-core-files) را ببینید.