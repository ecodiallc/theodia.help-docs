---
title: پرسش‌های متداول
level: everyday
categories: faq
summary: پاسخ به متداول‌ترین پرسش‌ها دربارهٔ استفاده از Theodia.
---

# پرسش‌های متداول

## آیا Theodia هزینه دارد؟

Theodia یک خرید یک‌باره است. اشتراک، تبلیغات، خریدهای درون‌برنامه‌ای و درخواست کمک مالی ندارد. تمام resources اضافی موجود در کاتالوگ پس از خرید app به‌صورت رایگان قابل دانلود هستند.

## آیا به اتصال اینترنت نیاز دارم؟

نه. وقتی app و فایل‌های دادهٔ آن نصب شدند، همه‌چیز آفلاین کار می‌کند. می‌توانید بدون سیگنال بخوانید، جستجو کنید، هایلایت کنید، یادداشت بگیرید و از اکثر ابزارهای مطالعه استفاده کنید.

تنها قابلیتی که به اینترنت نیاز دارد دانلود resources جدید است.

## داده‌های من کجا ذخیره می‌شوند؟

همهٔ بوک‌مارک‌ها، هایلایت‌ها، یادداشت‌ها و تنظیمات شما روی دستگاهتان ذخیره می‌شوند. آنها روی هیچ سروری آپلود نمی‌شوند.

می‌توانید به‌صورت دستی از آنها پشتیبان بگیرید. راهنمای [Backing Up Your Data](theodia://help/backups) را ببینید.

## آیا می‌توانم کتاب مقدس را با صدای بلند بشنوم؟

بله. یک فصل را باز کنید، منو را تپ کنید و گزینهٔ read-aloud را انتخاب کنید. دستگاه شما باید صدای text-to-speech نصب‌شده داشته باشد. برای اطلاعات بیشتر راهنمای [Reading Out Loud](theodia://help/tts) را ببینید.

## چگونه یک پرسیجه را جستجو کنم؟

می‌توانید ارجاعی مانند `John 3:16` را در Command روی صفحهٔ خانه تایپ کنید، یا از تب **Search** برای جستجو بر اساس واژه یا عبارت استفاده کنید.

## چگونه یک باگ گزارش دهم یا ویژگی پیشنهاد دهم؟

روی **Submit Suggestion / Issue** در صفحهٔ About تپ کنید، آن را [در GitHub گزارش کنید](https://github.com/ecodiallc/theodia.app/issues/new)، یا به صفحهٔ [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions) سر بزنید.

## چه دستگاه‌هایی پشتیبانی می‌شوند؟

Theodia روی iPhone، iPad، و گوشی‌ها و تبلت‌های Android اجرا می‌شود. بهترین اجرا روی دستگاه‌هایی با حداقل ۲ GB فضای آزاد ذخیره‌سازی برای فایل‌های دادهٔ core است.

## آیا می‌توانم از کیبرد خارجی استفاده کنم؟

بله. Theodia کیبردهای Bluetooth و USB را روی iPad پشتیبانی می‌کند. ناوبری، جستجو و بسیاری از ویژگی‌های خواندن کلیدهای میانبر (shortcut) دارند. راهنمای [External Keyboard Shortcuts](theodia://help/external-keyboard-shortcuts) لیست کامل را دارد.

## چه زبان‌هایی پشتیبانی می‌شوند؟

رابط app به زبان‌های English، Arabic، Chinese (Simplified and Traditional)، Czech، Danish، Dutch، Filipino، French، German، Greek، Hebrew، Hindi، Indonesian، Italian، Japanese، Korean، Polish، Portuguese (Brazil)، Romanian، Russian، Spanish، Swahili، Swedish، Thai، Turkish، Ukrainian و Vietnamese در دسترس است.

زبان متن کتاب مقدس بستگی به ترجمه‌هایی دارد که نصب کرده‌اید.

## چگونه زبان را تغییر دهم؟

به **Settings** بروید و گزینهٔ زبان را پیدا کنید.

## پرسش من اینجا نیست. کجا کمک بیشتری بگیرم؟

بقیهٔ راهنماها را بر اساس موضوع مرور کنید، یا در صفحهٔ [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions) جامعه پرسشی بپرسید.

نکته: در صفحهٔ اصلی **Help & Guides**، از کادر جستجو استفاده کنید و موضوعی مانند `notifications` یا `search` تایپ کنید تا راهنمای مربوطه را پیدا کنید.
