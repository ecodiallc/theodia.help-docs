---
title: Bases de l'IA
level: advanced
categories: ai
summary: Comment utiliser l'assistant IA pour comprendre les versets.
---

# Bases de l'IA

> **Mode :** L'assistant IA nécessite le mode **Érudit**. Vous pouvez changer de mode dans **Paramètres** → **Mode utilisateur de l'app**.

Theodia dispose d'un assistant IA. Il peut vous aider à comprendre un verset, répondre à une question ou explorer un sujet biblique.

## Comment activer l'IA

L'IA est désactivée par défaut. Pour l'activer :

1. Ouvrez **Paramètres**.
2. Appuyez sur **Assistant IA**.
3. Appuyez sur le commutateur pour l'activer.

## Comment ouvrir l'IA

Appuyez sur l'onglet **IA** en bas de l'écran. Une fenêtre de discussion s'ouvre.

## Comment poser une question

Appuyez sur le champ en bas. Tapez votre question. Appuyez sur **Envoyer**.

Quelques exemples de questions :

- « Que signifie Jean 3:16 ? »
- « Parlez-moi de l'épître aux Romains. »
- « Quel est le fruit de l'Esprit ? »
- « Comparez le Sermon sur la montagne dans Matthieu et Luc. »

## Comment poser une question sur un verset précis

1. Ouvrez un chapitre.
2. Appuyez sur un verset pour afficher le menu du verset.
3. Appuyez sur **Commentaire IA**.

Le verset est envoyé à l'IA. Le panneau IA s'ouvre avec le verset pré-rempli. Vous pouvez ajouter une question, comme « Que cela signifie-t-il ? » ou « Comment puis-je appliquer cela ? »

## Points importants à retenir

- L'IA est un outil, pas une personne. Elle peut se tromper.
- Vérifiez toujours les réponses de l'IA par rapport à la Bible elle-même.
- L'IA peut avoir besoin d'Internet. Elle ne fonctionne pas hors ligne.
- Lorsque vous utilisez l'IA, vos questions, le contexte du verset et votre clé API sont envoyés au point de terminaison choisi. La première fois, l'application demande votre permission et indique exactement ce qui est envoyé. Vous pouvez modifier ou révoquer cette permission plus tard dans **Paramètres → Assistant IA → Partage de données IA à distance**.
- Certaines régions, comme la version du mainland chinois de l'App Store, ne proposent pas l'assistant IA. Seules les fonctionnalités bibliques hors ligne sont disponibles dans cette version.

## Comment gérer les conversations

L'écran IA conserve une liste des conversations passées. Depuis la liste, vous pouvez rouvrir une ancienne conversation, en commencer une nouvelle ou en supprimer une dont vous n'avez plus besoin.

## Aller plus loin avec l'IA

Cette page couvre l'essentiel. L'IA de Theodia peut faire bien plus que discuter. Voici où aller ensuite :

- **[Fonctionnalités IA](theodia://help/ai-features)** — Découvrez tout ce que Théophile peut faire : étude d'un verset en grec et en hébreu en un tap, chaînes de références croisées, plans de sermon, génération de prières, morphologie des langues originales, recherches lexicales et navigation mains libres dans l'application. Ce guide vous montre comment transformer l'IA d'un simple chatbot en un partenaire d'étude complet.
- **[Écrire de meilleures invites IA](theodia://help/ai-prompts)** — Apprenez l'art de poser des questions qui obtiennent des réponses riches et précises. Quelques ajustements dans la formulation de votre demande peuvent débloquer des réponses beaucoup plus approfondies de l'IA.
- **[Choisir un modèle IA](theodia://help/choosing-a-model)** — Tous les modèles d'IA ne se valent pas. Découvrez quels modèles prennent en charge les outils intégrés de Theodia (comme l'ouverture de versets et la recherche dans les Écritures) et lesquels transforment l'IA en un véritable assistant d'étude biblique mains libres.
- **[Modèles GitHub](theodia://help/github-models)** — Le fournisseur gratuit recommandé pour Theodia. Obtenez une clé API gratuite avec un compte GitHub et commencez à poser des questions avec un quota quotidien généreux. Pas de carte de crédit, pas d'abonnement.
- **[Clés API et coûts](theodia://help/ai-keys-and-costs)** — Comprenez comment fonctionne la tarification des API selon les fournisseurs et comment garder les coûts proches de zéro.
