---
title: Fonctionnalités IA
categories: ai
level: advanced
summary: Découvrez tout ce que l'IA de Theodia peut faire, de l'étude verset par verset à la préparation de sermon, en passant par l'exploration des langues originales et la navigation mains libres.
---

# Fonctionnalités IA

> **Mode :** L'assistant IA nécessite le mode **Érudit**. Vous pouvez changer de mode dans **Paramètres** → **Mode utilisateur de l'app**.

L'assistant IA de Theodia, Théophile, n'est pas qu'un simple chatbot. C'est un partenaire d'étude qui peut lire la Bible avec vous, consulter des commentaires, rechercher dans les Écritures, gérer vos notes et même naviguer dans l'application — tout cela par la voix ou le texte.

Avant que Théophile n'envoie des données à un point de terminaison IA pour la première fois, l'application affiche une demande de consentement expliquant ce qui est envoyé et demandant votre permission. Vous pouvez modifier ou révoquer cette permission à tout moment dans **Paramètres → Assistant IA → Partage de données IA à distance**.

## Discussion IA sur un verset : étudier un verset en profondeur

La **discussion IA sur un verset** est au cœur de l'expérience IA de Theodia. Pendant que vous lisez un chapitre, appuyez sur un numéro de verset (ou maintenez le texte du verset enfoncé) et choisissez **Commentaire IA**. Un panneau de discussion s'ouvre avec ce verset déjà chargé. L'IA sait exactement ce que vous lisez et est prête à l'explorer avec vous.

### Démarreurs en un tap

Vous ne savez pas quoi demander ? Le panneau affiche huit lanceurs instantanés :

- **Expliquez ce verset** — Obtenez une explication claire et réfléchie du sens et de la signification.
- **Analyser les mots et la grammaire grecs/hébreux** — Voyez les mots grecs ou hébreux, leurs translittérations et les définitions lexicales derrière le texte anglais.
- **Contexte historique et culturel** — Découvrez la culture, la politique et les événements entourant le verset.
- **Quel est le contexte textuel environnant ?** — Voyez comment le verset s'inscrit dans le paragraphe, le chapitre et le livre qui l'entourent.
- **Thèmes principaux de ce verset** — Découvrez les grandes idées que ce verset apporte à la théologie biblique.
- **Comment appliquer ce verset** — Obtenez des applications pratiques et personnelles que vous pouvez mettre en œuvre aujourd'hui.
- **Générez une prière à partir de ce verset** — Transformez le verset en une prière inspirée de son langage et de ses vérités.
- **Générez un plan de sermon à partir de ce verset** — Obtenez un plan en trois points avec introduction et conclusion, prêt à prêcher.

Appuyez sur n'importe quel lanceur et l'IA commence immédiatement. Vous pouvez ensuite poser vos propres questions, demander des clarifications ou orienter la conversation dans une nouvelle direction.

### Suivi comme dans une vraie conversation

L'IA se souvient des derniers messages de la discussion, donc vous pouvez creuser naturellement :

- « Peux-tu dire cela plus simplement ? »
- « Que dit le grec original ici ? »
- « Montre-moi des références croisées qui s'y rattachent. »
- « Compare ce verset dans trois traductions différentes. »
- « À quoi cela ressemblerait-il dans un milieu de travail moderne ? »
- « Donne-moi trois autres applications pour un parent. »

La conversation reste attachée au verset, donc chaque réponse est ancrée dans le texte que vous lisez.

### Appuyez sur n'importe quelle référence biblique

Quand l'IA mentionne un autre verset — par exemple, « Cela fait écho à Romains 8:28 » — la référence apparaît comme un **lien sur lequel on peut appuyer**. Appuyez dessus et l'application saute directement à ce passage dans le lecteur biblique. Vous pouvez explorer la chaîne de références sans jamais quitter la conversation.

## Ce que l'IA peut faire au-delà de la discussion sur un verset

Théophile a accès à l'ensemble du contenu de Theodia : Bibles, commentaires, lexiques, dictionnaires, livres, dévotionnels, vos notes, signets et surlignages. Voici ce que cela signifie en pratique.

### Lire et naviguer dans les Écritures

- **Lire n'importe quel verset ou chapitre** — « Lis Jean 3:16 dans la WEB » ou « Lis le Psaume 23 à haute voix. »
- **Ouvrir des passages dans le lecteur** — « Emmène-moi à Genèse 1 » ou « Ouvre Romains 8:28. »
- **Comparer les versions** — « Montre-moi Jean 3:16 dans toutes mes Bibles. »
- **Rechercher dans la Bible** — « Trouve des versets sur le pardon » ou « Cherche 'la paix qui surpasser toute intelligence.' »
- **Obtenir des références croisées** — « Quels autres versets se rattachent à Ésaïe 53:5 ? »
- **Lire les titres de section** — « Quels sont les sous-titres dans Matthieu 5 ? »

### Explorer les langues originales

- **Recherches lexicales** — « Que signifie le mot grec 'agapè' dans Jean 3:16 ? » ou « Cherche le Strong G26. »
- **Morphologie** — « Analyse les verbes grecs de Romains 8:28 » ou « Que signifie le code morphologique V-PAI-3S ? »
- **Infos sur le mot** — L'IA peut voir la même analyse mot à mot que vous voyez dans l'application : translittération, glose, grammaire et numéros de Strong.

### Lire des commentaires et des livres d'étude

- **Commentaire de verset** — « Que dit Matthew Henry sur Éphésiens 2:8 ? »
- **Commentaire de chapitre** — « Donne-moi l'aperçu du chapitre Romains 8. »
- **Commentaire de livre** — « Résume le commentaire au niveau du livre de l'Apocalypse. »
- **Livres d'étude** — « Lis-moi un chapitre de Hymn Lyrics English » ou « Cherche 'patience' dans mes livres. »
- **Dévotionnels** — « Lis le dévotionnel du jour » ou « Trouve un dévotionnel sur l'anxiété. »

### Rechercher dans les dictionnaires

- « Qui était Melchisédek ? »
- « Que dit le dictionnaire biblique sur Guilgal ? »
- « Cherche 'propitiation' dans Easton's. »

### Gérer votre vie d'étude

L'IA peut agir sur vos données personnelles — toujours stockées localement sur votre appareil :

- **Signets** — « Ajoute ce verset à mon dossier Préparation de sermon » ou « Liste mes signets. »
- **Surlignages** — « Surligne Jean 3:16 en jaune » ou « Montre-moi tous mes surlignages. »
- **Notes** — « Crée une note biblique sur ce verset » ou « Lis mes notes pour Genèse 1. »
- **Notes d'étude** — « Enregistre cette conversation comme une note d'étude » ou « Crée un nouveau cahier d'étude appelé Étude des Romains. »
- **Dossiers** — « Crée un dossier appelé Dévotion du matin » ou « Déplace mon signet de Jean 3:16 vers le dossier Prière. »

### Modifier les paramètres de l'application

- « Passe en mode sombre. »
- « Fais de la BSB ma Bible par défaut. »
- « Active les Bibles parallèles avec la NET. »
- « Augmente la taille de la police. »

### Lire à haute voix

- « Lis le Psaume 23 à haute voix » — L'IA peut déclencher la synthèse vocale pour n'importe quel passage, livre ou note.
- « Arrête de lire » — Mettez la synthèse vocale en pause à tout moment.

## Enregistrer vos conversations

Chaque discussion IA sur un verset peut être enregistrée. Appuyez sur le menu du panneau de discussion et choisissez :

- **Enregistrer comme note biblique** — Ajoute la conversation complète à la note du verset dans le lecteur biblique.
- **Enregistrer comme note d'étude** — Stocke la conversation dans votre livre de notes d'étude pour consultation ultérieure.

Cela transforme une rapide exploration IA en matériel d'étude permanent que vous pouvez revisiter, modifier ou utiliser pour construire des sermons.

## L'onglet IA complet

Au-delà du panneau de discussion sur un verset, Theodia dispose d'un onglet dédié **IA** dans la navigation inférieure. C'est une discussion libre où vous pouvez demander n'importe quoi — aucun verset n'est présélectionné. Utilisez-la pour :

- Des études thématiques dans toute la Bible
- La recherche et l'élaboration de sermons
- La comparaison de thèmes théologiques entre livres
- Le dévotionnel quotidien et les suggestions de prière
- Des quiz bibliques et des plans de lecture
- De l'aide sur l'application — « Comment fonctionnent les Bibles parallèles ? »

Vos conversations sont enregistrées automatiquement. Vous pouvez revenir aux discussions passées, en commencer de nouvelles et supprimer d'anciens fils.

## Idées pour commencer

Voici quelques façons passionnantes d'utiliser l'IA. Choisissez-en une et essayez-la aujourd'hui.

**Croissance personnelle**

- « Explique Philippiens 4:6–7 et donne-moi une prière pour quand je me sens anxieux. »
- « Que dit la Bible sur le repos ? Trouve-moi cinq versets et explique chacun. »

**Famille et parentalité**

- « Comment Éphésiens 6:4 devrait-il guider la parentalité moderne ? Donne-moi trois règles pratiques. »
- « Trouve des versets sur l'éducation des enfants et lis-les à haute voix. »

**Préparation de sermon et d'enseignement**

- « Esquisse un sermon de 25 minutes sur Romains 8:28 avec une introduction, trois points et une conclusion. »
- « Que disent mes commentaires sur l'armure de Dieu dans Éphésiens 6 ? »
- « Compare le Sermon sur la montagne dans Matthieu avec la version de Luc. Quelles sont les différences ? »

**Étude des langues originales**

- « Montre-moi la morphologie de chaque mot de Jean 1:1. »
- « Quelle est la différence entre 'agapè' et 'philia' dans le Nouveau Testament ? »

**Profondeur dévotionnelle**

- « Lis le dévotionnel du jour et connecte-le à un verset des Psaumes. »
- « Donne-moi un plan de dévotionnel de sept jours sur le fruit de l'Esprit. »

**Chaînes de références croisées**

- « Commence à Ésaïe 53:5 et suis le thème des 'blessures' et de la 'guérison' à travers le Nouveau Testament. »
- « Où le concept d'alliance apparaît-il de Genèse à Hébreux ? »

**Mémorisation et révision**

- « Interroge-moi sur les livres de la Bible dans l'ordre. »
- « Crée une note d'étude résumant l'idée principale de chaque chapitre des Romains. »

## Quelques notes importantes

- L'IA est un **outil**, pas un remplacement à la Bible ou aux conseils pastoraux. Comparez toujours ses réponses aux Écritures elles-mêmes.
- Lorsque vous utilisez l'IA, vos questions voyagent sur Internet vers les serveurs du fournisseur. La plupart des fournisseurs n'entraînent pas leurs modèles sur vos données, mais le texte quitte bien votre appareil.
- L'IA peut se tromper. Utilisez les commentaires, les lexiques et le texte biblique lui-même comme autorité finale.

## Résumé

L'IA de Theodia est conçue pour rendre l'étude biblique plus rapide, plus profonde et plus personnelle. Que vous souhaitiez une explication d'un verset déroutant en une phrase, un plan de sermon complet, une étude d'un mot grec ou une chaîne de références croisées couvrant toute la Bible, Théophile est prêt à vous aider. Appuyez sur un verset, posez une question et voyez où la conversation vous mène.
