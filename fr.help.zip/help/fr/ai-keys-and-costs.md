---
title: Clés API et coûts
level: advanced
categories: ai
summary: Pourquoi vous avez besoin d'une clé API, comment en obtenir une et ce que coûte généralement l'utilisation d'un modèle IA distant.
---

# Clés API et coûts

> **Mode :** L'assistant IA nécessite le mode **Érudit**. Vous pouvez changer de mode dans **Paramètres** → **Mode utilisateur de l'app**.

L'assistant IA se connecte à des modèles IA distants. Si vous voulez en utiliser un, vous avez besoin d'une clé API. Cette page explique pourquoi, comment en obtenir une et ce que cela coûte généralement.

## Pourquoi vous avez besoin d'une clé API

Un modèle IA distant réside sur un serveur sur Internet. La clé API est comme un mot de passe qui dit au serveur : « Cette personne est autorisée à poser des questions. » Sans elle, le serveur ne répondra pas.

L'application ne fournit pas de clé intégrée. Vous devez créer votre propre compte chez un fournisseur et coller votre clé dans l'application.

## Comment obtenir une clé API

1. Ouvrez **Paramètres** dans Theodia.
2. Appuyez sur **Assistant IA**.
3. Choisissez **Modèle distant**.
4. Sélectionnez un fournisseur dans la liste, ou choisissez **Personnalisé** et saisissez une URL de base.
5. Appuyez sur le lien vers la page de clés du fournisseur. Créez un compte si vous n'en avez pas.
6. Générez une nouvelle clé API sur le site du fournisseur.
7. Copiez la clé et collez-la dans Theodia.
8. Appuyez sur **Tester la connexion** pour vérifier que tout fonctionne.

## Fournisseurs pris en charge

Theodia peut se connecter à tout fournisseur utilisant une API compatible OpenAI. Voici ceux qui ont des liens prédéfinis dans l'application :

- **GitHub Models** — github.com/marketplace/models (niveau gratuit quotidien, recommandé)
- **OpenAI** — platform.openai.com
- **OpenRouter** — openrouter.ai
- **Anthropic** — console.anthropic.com
- **Groq** — console.groq.com
- **Mistral** — console.mistral.ai
- **Together AI** — api.together.xyz

Vous pouvez aussi utiliser une URL de base **Personnalisée** si vous exécutez votre propre serveur ou utilisez un autre service.

## Combien cela coûte ?

La plupart des fournisseurs facturent par **token**. Un token correspond approximativement à un mot ou à une partie d'un mot. Vous payez pour les tokens que vous envoyez (votre question) plus les tokens que l'IA renvoie (la réponse).

### Prix typiques

Les prix changent, mais voici une idée approximative à mi-2026 :

- **Petits modèles rapides** (comme les points de terminaison de classe GPT-3.5 moins chers) coûtent une fraction de cent par millier de tokens.
- **Modèles milieu de gamme** (comme GPT-4o ou Claude Sonnet) coûtent généralement quelques cents par millier de tokens.
- **Grands modèles de raisonnement** (comme GPT-4.5 ou Claude Opus) peuvent coûter de dix à vingt cents par millier de tokens.

Une question biblique typique dans Theodia peut utiliser de quelques centaines à quelques milliers de tokens au total. Cela signifie que la plupart des questions coûtent entre **moins d'un centime et quelques cents**.

### Conseils pour réduire les coûts

- Commencez par un modèle moins cher. La plupart des questions bibliques n'ont pas besoin du modèle le plus coûteux.
- Utilisez Groq ou OpenRouter si vous voulez essayer différents modèles et comparer les prix.
- Surveillez votre tableau de bord d'utilisation sur le site du fournisseur.

## GitHub Models

[GitHub Models](https://github.com/marketplace/models) propose un niveau gratuit sans abonnement requis. Il vous suffit d'un compte GitHub gratuit et d'un jeton d'accès personnel autorisé à lire les modèles.

**Comment le configurer :**

1. Allez sur [github.com/settings/tokens](https://github.com/settings/tokens) et créez un **Personal access token (classic)**.
2. Donnez-lui la portée `models:read` (ou sélectionnez simplement l'autorisation models).
3. Dans Theodia, choisissez **GitHub Models** comme fournisseur et collez votre jeton.

**Modèles du niveau gratuit :**

- `openai/gpt-4.1-nano` — **15 requêtes par minute, 150 requêtes par jour**
- `openai/gpt-4.1-mini` — **15 requêtes par minute, 150 requêtes par jour**
- `openai/gpt-4.1` — **10 requêtes par minute, 50 requêtes par jour**
- `openai/gpt-4o` — **10 requêtes par minute, 50 requêtes par jour**

Ces limites se réinitialisent chaque jour et sont largement suffisantes pour une étude biblique régulière.

Pour un guide étape par étape complet avec captures d'écran, consultez le guide dédié [GitHub Models](theodia://help/github-models).

## Note sur la confidentialité

Lorsque vous utilisez un modèle IA distant, l'application affiche d'abord une demande de consentement expliquant ce qui est envoyé : vos messages, le contexte du verset ou du chapitre, les appels d'outils et leurs résultats, le nom du modèle configuré et votre clé API dans l'en-tête de la requête. La requête va directement au point de terminaison que vous avez configuré, pas via Theodia. La plupart des fournisseurs n'utilisent pas vos données pour entraîner leurs modèles, mais le texte quitte votre appareil. Vous pouvez modifier ou révoquer l'autorisation à tout moment dans **Paramètres → Assistant IA → Partage de données IA à distance**.

## Résumé

- Vous avez besoin d'une clé API pour utiliser l'assistant IA.
- Créez un compte chez un fournisseur, générez une clé et collez-la dans Theodia.
- La plupart des questions coûtent quelques cents ou moins.
