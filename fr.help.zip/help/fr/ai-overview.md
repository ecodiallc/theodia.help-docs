---
title: L'Assistant IA
level: advanced
category: ai
summary: Comment utiliser l'assistant IA pour comprendre les versets.
---

# L'Assistant IA

Theodia dispose d'un assistant IA. Il peut vous aider à comprendre un verset, répondre à une question ou explorer un sujet biblique.

## Comment activer l'IA

L'IA est désactivée par défaut. Pour l'activer :

1. Ouvrez **Paramètres**.
2. Appuyez sur **Assistant IA**.
3. Appuyez sur le commutateur pour l'activer.

Vous devrez peut-être configurer un compte ou une clé. L'application vous guidera.

## Comment ouvrir l'IA

Appuyez sur l'onglet **IA** en bas de l'écran. Une fenêtre de discussion s'ouvre.

## Comment poser une question

Appuyez sur le champ en bas. Tapez votre question. Appuyez sur **Envoyer**.

Quelques exemples de questions :

- « Que signifie Jean 3:16 ? »
- « Parlez-moi de l'épître aux Romains. »
- « Quel est le fruit de l'Esprit ? »
- « Comparez le Sermon sur la montagne dans Matthieu et Luc. »

## Comment poser une question sur un verset précis

1. Ouvrez un chapitre.
2. Appuyez sur un verset pour afficher le menu du verset.
3. Appuyez sur **Commentaire IA**.

Le verset est envoyé à l'IA. Le panneau IA s'ouvre avec le verset pré-rempli. Vous pouvez ajouter une question, comme « Que cela signifie-t-il ? » ou « Comment dois-je l'appliquer ? »

## Points importants à retenir

- L'IA est un outil, pas une personne. Elle peut se tromper.
- Vérifiez toujours les réponses de l'IA par rapport à la Bible elle-même.
- L'IA peut avoir besoin d'Internet. Elle ne fonctionne pas hors ligne.
- Lorsque vous utilisez l'IA, vos questions, le contexte du verset et votre clé API sont envoyés au point de terminaison choisi. La première fois, l'application demande votre permission et indique exactement ce qui est envoyé. Vous pouvez modifier ou révoquer cette permission plus tard dans **Paramètres → Assistant IA → Partage de données IA à distance**.
- Certaines régions, comme la version du mainland chinois de l'App Store, ne proposent pas l'assistant IA. Seules les fonctionnalités bibliques hors ligne sont disponibles dans cette version.

## Comment gérer les conversations

L'écran IA conserve une liste des conversations passées. Depuis la liste, vous pouvez rouvrir une ancienne conversation, en commencer une nouvelle ou en supprimer une dont vous n'avez plus besoin.

Pour des conseils plus avancés, consultez le guide [Écrire de meilleures invites IA](theodia://help/ai-prompts).
