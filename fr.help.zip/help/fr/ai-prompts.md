---
title: Écrire de meilleures invites IA
level: advanced
categories: ai
summary: Comment interroger l'assistant IA pour obtenir de bonnes réponses.
---

# Écrire de meilleures invites IA

> **Mode :** L'assistant IA nécessite le mode **Érudit**. Vous pouvez changer de mode dans **Paramètres** → **Mode utilisateur de l'app**.

Une « invite » est la question ou l'instruction que vous donnez à l'IA. De meilleures invites donnent de meilleures réponses. Ce guide vous montre comment faire.

## Soyez précis

Mauvais : « Parle-moi de l'amour. »
Mieux : « Dans 1 Corinthiens 13, quel genre d'amour Paul décrit-il, et en quoi est-il différent de l'amour romantique ? »

Plus vous donnez de détails, plus la réponse est utile.

## Donnez du contexte

Mauvais : « Que signifie ce verset ? »
Mieux : « Je lis Romains 8 avec un petit groupe. Que signifie 'aucune condamnation' dans ce chapitre, et comment cela se relie au reste du chapitre ? »

Le contexte aide l'IA à adapter sa réponse à votre situation.

## Demandez une chose à la fois

Mauvais : « Parle-moi de la prière, de la foi et de la guérison. »
Mieux : « Parle-moi d'abord de la prière. Après cela, je demanderai la foi. »

Demander une chose à la fois permet de garder les réponses ciblées.

## Demandez à l'IA de prendre un rôle

Vous pouvez demander à l'IA de répondre avec une certaine voix. Par exemple :

- « Réponds comme si tu enseignais à un nouveau chrétien. »
- « Réponds comme un bibliste. »
- « Réponds pour un enfant de 10 ans. »

L'IA adapte sa réponse au rôle choisi.

## Utilisez des questions de suivi

Si la première réponse n'est pas tout à fait juste, posez une question de suivi :

- « Peux-tu dire cela plus simplement ? »
- « Peux-tu me donner un exemple ? »
- « Que dit le grec original ? »
- « Où ailleurs dans la Bible cela apparaît-il ? »

Une bonne conversation est un échange. L'IA se souvient des derniers messages.

## Vérifiez les réponses de l'IA

L'IA peut se tromper. C'est un outil, pas un enseignant.

- Comparez la réponse de l'IA aux versets auxquels elle vous renvoie.
- Utilisez les commentaires et les lexiques de l'application pour un deuxième avis.
- Si la réponse concerne la doctrine, demandez l'avis d'un pasteur ou d'un ami de confiance.

## Modèles d'invites courants

Voici quelques modèles qui fonctionnent bien :

- « Explique-moi ce verset comme si j'étais un nouveau chrétien. »
- « Quel est le point principal de ce chapitre en une phrase ? »
- « Liste trois applications pour ma vie quotidienne à partir de ce passage. »
- « Quelles questions devrais-je me poser sur ce verset avant de le prêcher ? »
