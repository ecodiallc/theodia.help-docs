---
title: Mode utilisateur de l'app
level: beginner
categories: [user-mode]
summary: Choisissez entre les modes Lecture, Standard et Érudit pour contrôler les fonctionnalités disponibles dans l'application.
---

# Mode utilisateur de l'app

Theodia propose trois modes utilisateur qui contrôlent les fonctionnalités affichées. Choisissez celui qui correspond à votre façon d'utiliser l'application.

## Lecture

Le mode le plus simple. Le mode Lecture est destiné à une lecture biblique sans distraction.

- Lisez n'importe quelle traduction biblique
- Utilisez le mode Concentration pour une lecture plein écran épurée
- Naviguez dans les livres et les chapitres
- Pas d'outils d'étude, pas d'IA, pas de signets, pas de surlignages

Le mode Lecture est idéal si vous voulez que Theodia ressemble à une Bible numérique propre, sans rien de superflu.

## Standard

Le mode Standard ajoute des fonctionnalités quotidiennes pour l'étude personnelle de la Bible.

Tout ce qui est dans le mode Lecture, plus :

- Signets, surlignages et notes
- Synthèse vocale
- Lecteur en mode Étude avec menu du verset
- Bibles parallèles
- Saisie de commande
- Recherche dans la Bible
- Dévotionnels quotidiens et livres intégrés

Le mode Standard est le bon choix pour la plupart des utilisateurs qui veulent lire, annoter et rechercher dans la Bible sans outils d'étude avancés.

## Érudit

Le mode le plus complet. Le mode Érudit débloque tous les outils de Theodia pour une étude biblique approfondie.

Tout ce qui est dans le mode Standard, plus :

- Commentaires et lexiques
- Références croisées
- Dictionnaire biblique
- Infos sur le mot (recherches Strong)
- Assistant IA et commentaire IA
- Menu de lanceur

Le mode Érudit est conçu pour les pasteurs, les étudiants en séminaire et tous ceux qui souhaitent des outils de langues originales et des aides à l'étude alimentées par l'IA.

## Comment changer de mode

1. Ouvrez **Paramètres**.
2. Appuyez sur **Mode utilisateur de l'app**.
3. Choisissez **Lecture**, **Standard** ou **Érudit**.

Le changement prend effet immédiatement. Les menus et boutons auxquels vous n'avez pas accès dans votre mode actuel sont masqués.

## Choisir un mode

- **Lecture** — Vous voulez uniquement lire la Bible, rien d'autre.
- **Standard** — Vous voulez des signets, des surlignages, des notes, la recherche et les dévotionnels.
- **Érudit** — Vous voulez tous les outils d'étude, y compris l'IA, les commentaires et les lexiques.

Vous pouvez changer de mode à tout moment. Vos signets, surlignages et notes ne sont jamais supprimés lorsque vous changez de mode ; ils sont simplement masqués jusqu'à ce que vous reveniez à un mode qui les prend en charge.
