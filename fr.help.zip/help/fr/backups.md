---
title: Sauvegarder vos données
level: everyday
categories: settings
summary: Comment enregistrer et restaurer vos notes, surlignages, signets et secrets.
---

# Sauvegarder vos données

Vos notes, surlignages, signets et paramètres sont enregistrés sur votre appareil. Si vous perdez votre téléphone, en obtenez un nouveau ou désinstallez l'application, ces données peuvent être perdues. Ce guide vous montre comment les sauvegarder.

## Comment ouvrir les paramètres de sauvegarde

1. Ouvrez **Paramètres**.
2. Appuyez sur **Sauvegarde**.

## Comment créer une sauvegarde de l'application

1. Ouvrez **Paramètres**.
2. Appuyez sur **Sauvegarde**.
3. Appuyez sur **Créer la sauvegarde de l'application**.
4. Choisissez un dossier sur votre appareil pour enregistrer le fichier. Vous pouvez aussi choisir un lecteur cloud.
5. L'application crée un seul fichier contenant toutes vos données. Le fichier se termine par `.zip`.

## À quelle fréquence faire une sauvegarde

Faites une sauvegarde :

- Après avoir écrit beaucoup de notes.
- Avant de mettre à jour le système d'exploitation de votre appareil.
- Avant de désinstaller l'application ou de changer de téléphone.

Une bonne habitude est une sauvegarde par mois. Certaines personnes sauvegardent chaque semaine.

## Comment restaurer depuis une sauvegarde de l'application

1. Ouvrez **Paramètres**.
2. Appuyez sur **Sauvegarde**.
3. Appuyez sur **Restaurer la sauvegarde d'application**.
4. Choisissez le fichier de sauvegarde `.zip`.
5. Pour chaque type de données (notes, surlignages, signets, etc.), choisissez si vous voulez conserver ce qui est sur l'appareil, le remplacer par la sauvegarde ou l'ignorer.
6. Appuyez sur **Restaurer**.

L'application remplace vos données par celles de la sauvegarde. Cela inclut :

- Les notes
- Les surlignages
- Les signets
- Les dossiers de signets
- Les paramètres (thème, taille de police, langue)

## Sauvegarde des secrets

Votre **Sauvegarde** d'application ne **comprend pas** les secrets sensibles comme votre clé API IA ou votre jeton GitHub. Pour les sauvegarder séparément, utilisez **Sauvegarde des secrets**.

### Enregistrer une sauvegarde des secrets

1. Ouvrez **Paramètres**.
2. Appuyez sur **Sauvegarde**.
3. Sous **Sauvegarde des secrets**, appuyez sur **Créer la sauvegarde des secrets**.
4. Saisissez un mot de passe fort et confirmez-le.
5. L'application chiffre vos secrets et partage le fichier chiffré. Enregistrez-le dans un endroit sûr.

### Restaurer une sauvegarde des secrets

1. Ouvrez **Paramètres**.
2. Appuyez sur **Sauvegarde**.
3. Sous **Sauvegarde des secrets**, appuyez sur **Restaurer les secrets**.
4. Choisissez le fichier de sauvegarde des secrets chiffré.
5. Saisissez le même mot de passe que celui utilisé lors de l'enregistrement.
6. Vos secrets sont restaurés.

> **Important :** Si vous oubliez le mot de passe, les secrets ne peuvent pas être récupérés. Il n'y a aucun moyen de réinitialisation.

## Points à retenir

- Une restauration **remplace** les catégories choisies. Tout ce que vous avez ajouté après la sauvegarde sera perdu pour ces catégories.
- Une sauvegarde d'application est un seul fichier `.zip`. Gardez-le dans un endroit sûr.
- Vous pouvez copier le fichier, le déplacer ou le stocker dans n'importe quel service cloud.
- Les sauvegardes d'application ne incluent pas les traductions bibliques elles-mêmes. Celles-ci peuvent être retéléchargées depuis **Paramètres** → **Gérer les ressources**.
- Les sauvegardes des secrets sont chiffrées avec votre mot de passe. Choisissez un mot de passe dont vous vous souviendrez.

## Astuce

Si vous avez plus d'un appareil, vous pouvez copier le fichier de sauvegarde sur chaque appareil et le restaurer. Vos données seront identiques sur les deux.
