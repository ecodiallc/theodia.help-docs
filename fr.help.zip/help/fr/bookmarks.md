---
title: Mettre des versets en signet
level: everyday
categories: [annotate, read]
summary: Comment enregistrer des versets pour les retrouver facilement.
---

# Mettre des versets en signet

> **Mode :** Les signets sont disponibles en mode **Standard** et **Érudit**. Le mode Concentration est réservé à une lecture propre et sans distraction. Vous pouvez changer de mode dans **Paramètres** → **Mode utilisateur de l'app**.

Un signet enregistre un verset ou un chapitre de livre pour que vous puissiez le retrouver. Les signets sont comme des marque-pages dans un livre.

## Comment mettre un verset en signet

1. Ouvrez le verset.
2. Appuyez sur le verset pour afficher le menu.
3. Appuyez sur **Signet** dans le menu. Une icône en forme d'étoile marque le verset comme enregistré.

Une coche sur l'icône signifie que le verset est maintenant en signet.

## Comment mettre un chapitre de livre en signet

Lorsque vous lisez un livre (pas une Bible), vous pouvez mettre tout le chapitre en signet :

1. Ouvrez le chapitre.
2. Appuyez sur l'icône **Signet** en haut de l'écran.

## Comment voir vos signets

Appuyez sur l'onglet **Signets** en bas. Vous voyez la liste de chaque verset et chapitre de livre que vous avez enregistrés.

## Comment supprimer un signet

- **Un verset :** Ouvrez le verset. Appuyez sur le verset, puis appuyez à nouveau sur l'icône **Signet**. La coche disparaît.
- **Depuis la liste :** Dans l'onglet **Signets**, maintenez un signet enfoncé. Un petit menu apparaît. Appuyez sur **Supprimer**. (Vous pouvez aussi appuyer sur le petit bouton × sur la ligne.)

## Organiser avec des dossiers

Vous pouvez ranger les signets dans des dossiers. Par exemple, vous pouvez avoir un dossier appelé « Préparation de sermon » et un autre appelé « Encouragement ».

Pour créer un dossier :

1. Ouvrez l'onglet **Signets**.
2. Appuyez sur **Gérer les dossiers** en haut.
3. Appuyez sur **+ Créer un dossier** en haut de la liste des dossiers.
4. Saisissez un nom et appuyez sur **Enregistrer**.

Vous ne pouvez pas créer deux dossiers avec le même nom. Si un nom existe déjà, une erreur apparaît dans la boîte de création de dossier pour que vous puissiez le modifier et réessayer.

Pour mettre un signet dans un dossier :

1. Dans l'onglet **Signets**, maintenez un signet enfoncé.
2. Appuyez sur **Déplacer vers le dossier**.
3. Choisissez le dossier, puis appuyez sur **Terminé**.

## Importer des signets

Vous pouvez importer des signets dans Theodia depuis d'autres applications et fichiers.

Allez dans **Paramètres** → **Signets** → **Importer des signets**. Choisissez **Importer depuis un fichier** ou collez depuis le presse-papiers. L'application détecte automatiquement le format.

### Formats pris en charge

**Export JSON natif** — Le format utilisé par la fonction d'exportation de Theodia. Il préserve les dossiers et les dates de création.

**Signets HTML Netscape** — Le format utilisé par Chrome, Firefox et Safari lorsque vous exportez des signets. Les dossiers sont préservés.

**CSV** — Un tableau avec des colonnes. L'application recherche les colonnes `url` et `folder` (ou `href` / `category`). Exemple :

```csv
url,folder
/bible/KJV/John/3,Favoris
/bible/KJV/Genesis/1,Préparation de sermon
```

**Texte brut** — Chaque ligne est soit une référence biblique, soit une URL d'application, soit une directive de dossier. Exemple :

```
folder: Favoris
John 3:16
Genesis 1:1
folder: Préparation de sermon
Matthew 5:1
```

- Les lignes commençant par `folder: <name>` définissent le dossier actif pour tous les signets suivants.
- Les références bibliques comme `John 3:16` sont converties en signets dans votre Bible par défaut.
- Les URL d'application comme `/bible/KJV/John/3#v3_16` ou `/book/MyBook/1` sont importées directement.
- Les lignes commençant par `#` ou `//` sont traitées comme des commentaires et ignorées.

### Conseils pour l'importation

- Les signets en double sont ignorés automatiquement.
- Les URL externes (comme les liens BibleGateway) sont converties en signets d'application lorsque possible.
- Si un dossier du fichier d'importation existe déjà, les signets sont placés dans le dossier existant.

## Conseils

- Vous pouvez mettre le même verset en signet dans plusieurs traductions. Ils apparaissent tous dans la liste.
- Les signets restent sur votre appareil. Ils ne se synchronisent pas avec le cloud.
- Consultez le guide [Sauvegarder vos données](theodia://help/backups) pour les protéger.
