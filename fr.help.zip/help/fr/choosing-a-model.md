---
title: Choisir un modèle IA
level: advanced
categories: ai
summary: Comment choisir un modèle qui fonctionne bien avec les outils et capacités intégrés de Theodia.
---

# Choisir un modèle IA

> **Mode :** L'assistant IA nécessite le mode **Érudit**. Vous pouvez changer de mode dans **Paramètres** → **Mode utilisateur de l'app**.

Tous les modèles d'IA ne fonctionnent pas de la même manière dans Theodia. La meilleure expérience vient d'un modèle qui prend en charge l'**appel d'outils** — la capacité de l'IA à utiliser les fonctionnalités intégrées de Theodia comme la recherche de versets bibliques, la recherche, la lecture de commentaires et la navigation dans l'application.

## Qu'est-ce que l'appel d'outils ?

Lorsque vous posez une question à l'IA de Theodia, celle-ci peut faire plus que parler. Elle peut aussi **agir**. Par exemple :

- Vous dites : « Montre-moi Jean 3:16 dans la ESV. » L'IA appelle un outil pour ouvrir ce verset dans le lecteur.
- Vous dites : « Que disent mes commentaires sur Romains 8:28 ? » L'IA appelle un outil pour récupérer le contenu du commentaire.
- Vous dites : « Enregistre ce verset comme signet. » L'IA appelle un outil pour créer un signet.

Les modèles qui ne prennent pas en charge l'appel d'outils ne peuvent vous donner que des réponses textuelles. Ils ne peuvent pas rechercher, naviguer ou modifier quoi que ce soit dans l'application.

## Quels modèles prennent en charge les outils ?

### Modèles distants

La plupart des modèles distants modernes des principaux fournisseurs prennent en charge l'appel d'outils compatible OpenAI. En général :

- **Les grands modèles** (comme GPT-4o, Claude Sonnet/Opus, Gemini Pro) gèrent les outils de manière fiable et peuvent enchaîner plusieurs appels d'outils dans une même conversation. Les noms des fournisseurs et les identifiants de modèles sont affichés dans l'application pour plus de commodité ; le service réel auquel vous vous connectez est celui dont vous configurez le point de terminaison et la clé.
- **Les modèles plus petits ou moins chers** peuvent prendre en charge les outils, mais de manière moins fiable. Ils peuvent ignorer un appel d'outil ou le formater incorrectement.
- **Les modèles très anciens ou spécialisés** ne prennent souvent pas du tout en charge les outils.

Si vous n'êtes pas sûr, testez le modèle dans Theodia. Demandez-lui « Montre-moi Genèse 1:1 » ou « Cherche dans la Bible des versets sur l'amour. » Si le verset s'ouvre ou si des résultats de recherche apparaissent, l'appel d'outils fonctionne.

## Modèles recommandés pour Theodia

Voici de bons choix qui équilibrent coût, qualité et prise en charge des outils :

- **OpenAI GPT-4o** — excellente prise en charge des outils, rapide, gère bien les questions complexes en plusieurs étapes.
- **Anthropic Claude Sonnet / Opus** — utilisation des outils très fiable, excellent pour les longs passages et l'étude détaillée.
- **Groq** (divers modèles) — inférence rapide, souvent gratuit ou très bon marché, la prise en charge des outils varie selon les modèles.
- **OpenRouter** — permet d'essayer de nombreux modèles avec un seul compte. Recherchez les modèles qui indiquent « function calling » ou « tools » dans leurs capacités.
- **[GitHub Models](theodia://help/github-models)** — le fournisseur gratuit recommandé. Accès aux modèles OpenAI, Anthropic et autres via votre compte GitHub avec un quota gratuit quotidien généreux. Utilise les mêmes identifiants de modèle de style `openai/gpt-4o`.

## Modèles à éviter

- **Les modèles de complétion de texte purs** (comme GPT-3 base ou LLaMA brut sans réglage d'instructions) ne prennent généralement pas en charge les outils.
- **Les modèles d'image uniquement ou de vision** centrés sur les images plutôt que sur le texte peuvent manquer de prise en charge des outils.
- **Les modèles extrêmement petits** de moins d'un milliard de paramètres sont peu susceptibles d'utiliser correctement les outils, même si l'API prétend qu'ils les prennent en charge.

## Comment tester la prise en charge des outils

Theodia vérifie automatiquement la prise en charge des outils. Après avoir configuré un modèle dans **Paramètres → Assistant IA**, appuyez sur **Tester la connexion**. Une fois la connexion réussie, l'application envoie une deuxième requête avec une définition d'outil d'exemple. Vous verrez l'un des deux résultats suivants :

- **✓ Outils pris en charge** — Le modèle accepte les appels d'outils et peut utiliser les fonctionnalités intégrées de Theodia.
- **✗ Outils non pris en charge** — Le modèle rejette la requête d'outil. Il répondra uniquement par du texte et ne pourra pas ouvrir de versets, rechercher ou gérer des signets pour vous.

Si vous voyez « Outils non pris en charge », le modèle peut toujours fonctionner comme un simple assistant de discussion textuel, mais vous ne bénéficierez pas de l'expérience intégrée et mains libres.

Vous pouvez aussi vérifier manuellement en demandant à l'IA de faire quelque chose :

- « Montre-moi Matthieu 5:3 dans la KJV. » — Devrait ouvrir le verset dans le lecteur.
- « Que dit le lexique du mot 'agapè' dans Jean 3:16 ? » — Devrait renvoyer des données lexicales.
- « Cherche dans la Bible des versets sur le pardon. » — Devrait renvoyer des résultats de recherche.
- « Mets Marc 12:30 en signet. » — Devrait créer un signet.

Si l'IA vous donne une description textuelle au lieu d'effectuer réellement l'action, le modèle a du mal à utiliser ses outils même si l'application a signalé leur prise en charge.

## Et si mon modèle ne prend pas en charge les outils ?

Vous pouvez toujours l'utiliser. L'IA répondra par du texte, et vous pourrez chercher manuellement des versets, effectuer des recherches et naviguer dans l'application vous-même. Mais vous manquerez l'expérience intégrée et mains libres qui rend Theodia puissant.

## Résumé

- Choisissez un modèle prenant en charge l'**appel d'outils / function calling** pour la meilleure expérience Theodia.
- **Les grands modèles distants** gèrent les outils le plus fiablement.
- Testez tout modèle avec des commandes simples comme « Montre-moi Genèse 1:1 » pour vérifier la prise en charge des outils.
