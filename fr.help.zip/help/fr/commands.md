---
title: Commandes
level: everyday
categories: [layout, study]
summary: La commande rapide vous permet d'accéder à n'importe quelle fonctionnalité en tapant une courte commande. Découvrez les formats pris en charge et des exemples.
---

# Commandes

La **Commande rapide** vous permet d'accéder à presque n'importe quelle partie de Theodia en tapant une courte instruction. Vous pouvez l'utiliser depuis l'onglet Accueil ou depuis le **Menu rapide** (l'icône **▼** dans l'en-tête).

## Comment ça marche

1. Appuyez sur le champ de commande.
2. Tapez une commande.
3. Appuyez sur la touche d'envoi de votre clavier.

L'application lit la commande et vous emmène directement à l'écran approprié.

## Pas de préfixe slash

Les commandes n'utilisent **pas** de préfixe `/`. Elles sont saisies comme du texte simple :

```
jean 3:16
recherche amour
sauvegarde
```

Si vous tapez `/parametres`, le `/` initial la rend non reconnaissable.

## Références bibliques

Tapez n'importe quelle référence biblique pour l'ouvrir dans le lecteur.

```
psaumes 23
jean 3:16
matthieu 5:1
1 cor 15:10
```

Les noms de livres peuvent être saisis par leur nom complet ou une abréviation. Dans les langues d'interface non anglaises, vous pouvez aussi taper les noms de livres dans la langue active.

## Recherche

```
chercher abraham
chercher amour
chercher foi pas oeuvres
```

## Signets, comparaison, commentaire, références croisées et infos sur le mot

```
signet jean 3:16
comparer genese 1:1
commentaire jean 1
commentaireia ep 2:8
références 1 cor 15:10
info mot jean 1:1
```

Ces commandes ouvrent l'outil nommé pour le passage donné.

## Lexique

Tapez un numéro de Strong pour ouvrir l'entrée lexicale.

```
g1161
h7225
```

## Dévotionnels

```
devotionnel
devotionnel smith
devotionnel quotidien
```

Sans nom, cela ouvre la liste des dévotionnels.

## Raccourcis de navigation

```
notes
surlignages
signets
fiches
playlist
theoscript
ressources
lire jean 3:16
```

Ces commandes accèdent directement à l'écran nommé ou ouvrent un passage dans le lecteur.

## Changement de traduction

Tapez une abréviation de traduction pour basculer vers celle-ci.

```
kjv
web
trlit
ohgb
```

Sur un écran de lecteur, la traduction change en place. Partout ailleurs, elle ouvre la traduction à votre passage le plus récent.

## Verbes de commande localisés

Les verbes de commande publics peuvent être tapés dans la langue active de l'interface **ou** en anglais. L'anglais fonctionne toujours comme solution de repli. Les commandes cachées (raccourcis de paramètres, commandes d'installation, Easter eggs) conservent uniquement la syntaxe anglaise.

## Aide

Tapez `aide` ou `commandes` dans le champ de commande pour ouvrir la référence des commandes intégrée à tout moment.
