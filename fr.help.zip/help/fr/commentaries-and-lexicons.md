---
title: Commentaires et lexiques
level: everyday
categories: study
summary: Comment rechercher le sens des mots et lire des notes d'étude.
---

# Commentaires et lexiques

> **Mode :** Les commentaires et les lexiques nécessitent le mode **Érudit**. Vous pouvez changer de mode dans **Paramètres** → **Mode utilisateur de l'app**.

Theodia comprend deux outils d'étude : les **commentaires** et les **lexiques**. Ils vous aident à comprendre la Bible en profondeur.

## Qu'est-ce qu'un commentaire ?

Un commentaire est un livre de notes d'étude écrit par un bibliste. Pour un verset donné, un commentaire vous donne le contexte, le sens et la place du verset dans le reste de la Bible.

## Qu'est-ce qu'un lexique ?

Un lexique est un dictionnaire de mots bibliques. Il indique le mot original en hébreu ou en grec, ce qu'il signifie et comment il est utilisé dans la Bible.

## Comment ouvrir un commentaire

1. Ouvrez un chapitre.
2. Appuyez sur un verset.
3. Appuyez sur **Commentaire**.

Un panneau s'ouvre. Il affiche des notes d'un bibliste sur ce verset.

## Comment ouvrir un lexique

1. Ouvrez un chapitre dans une Bible qui comprend les numéros de Strong.
2. Appuyez sur un numéro de Strong dans le verset (par exemple, G1234 ou H1234).
3. Un panneau s'ouvre montrant le mot original en hébreu ou en grec, son sens et d'autres versets qui utilisent ce mot.

Les numéros de Strong apparaissent dans une couleur différente dans le texte du verset pour se distinguer des mots ordinaires.

## Choisir un autre commentaire

Le commentaire est choisi dans un menu déroulant en haut du panneau de commentaire lui-même. Ouvrez le panneau, puis appuyez sur le menu déroulant pour voir les commentaires que vous avez installés. Choisissez-en un autre.

## Choisir un autre lexique

Le lexique est choisi dans un menu déroulant en haut du panneau de lexique. Ouvrez le panneau, puis appuyez sur le menu déroulant pour voir les lexiques que vous avez installés. Choisissez-en un autre.

## Ressources intégrées

Theodia est livré avec un ensemble intégré de commentaires et de lexiques. Ceux-ci sont inclus avec l'application et fonctionnent hors ligne. Des commentaires et lexiques supplémentaires ne peuvent pas être installés ou téléchargés séparément.

## Quand les utiliser

- Les **commentaires** sont utiles quand un verset est difficile à comprendre. Les notes vous donnent du contexte.
- Les **lexiques** sont utiles pour les études de mots. Ils vous disent le sens exact d'un mot dans la langue originale.

## Astuce

Si un verset contient une note que vous voulez conserver, faites une capture d'écran ou copiez le texte dans une note. (Voir le guide [Écrire des notes](theodia://help/notes).)

## Dictionnaire biblique en langage simple

Pour des définitions en anglais des mots et concepts bibliques (alliance, expiation, pharisiens, etc.), Theodia comprend aussi un outil Dictionnaire biblique. Ouvrez-le depuis le menu du verset en appuyant sur **Dictionnaire** (📖). Il diffère du lexique : les lexiques expliquent les mots originaux en hébreu et en grec, tandis que le dictionnaire explique le mot anglais en langage simple. Consultez le guide [Dictionnaire biblique](theodia://help/dictionary) pour savoir comment l'utiliser.
