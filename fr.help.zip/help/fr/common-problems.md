---
title: Problèmes courants
level: everyday
categories: trouble
summary: Solutions rapides aux problèmes que vous pouvez rencontrer.
---

# Problèmes courants

Ce guide couvre les problèmes les plus fréquents. Si votre problème n'est pas ici, consultez le guide [Où poser des questions](theodia://help/getting-more-help).

## L'application est lente

1. Fermez les autres applications en arrière-plan.
2. Redémarrez l'application.
3. Redémarrez votre appareil.

## Je ne trouve pas une traduction biblique

1. Ouvrez **Paramètres** → **Gérer les ressources** pour voir ce qui est installé.
2. Si la traduction n'y est pas, appuyez sur **Installer depuis GitHub**.
3. Dans le modal de téléchargement, appuyez sur l'onglet **Bible** (ou **Bibles mondiales**) et sélectionnez la traduction souhaitée.
4. Appuyez sur **Installer la sélection** et attendez la fin du téléchargement.
5. Vous avez besoin d'Internet pour télécharger une nouvelle traduction.

## Mes notes ou signets ont disparu

1. Vérifiez que vous êtes dans le bon onglet. Les notes sont dans l'onglet **Notes**. Les signets sont dans l'onglet **Signets**.
2. Si vous avez récemment restauré une sauvegarde, celle-ci a peut-être remplacé vos données. Vérifiez la date de la sauvegarde.
3. Si vous avez désinstallé et réinstallé l'application, vos données ont été perdues. La prochaine fois, faites d'abord une sauvegarde.

## La recherche ne trouve pas de versets

1. Assurez-vous d'avoir orthographié le mot correctement.
2. Essayez un mot plus court. « Amour » trouve plus de versets que « aimant ».
3. Assurez-vous d'avoir la bonne traduction biblique installée. La recherche ne fonctionne que dans les traductions que vous possédez.

## La lecture à haute voix ne fonctionne pas

1. Assurez-vous que le volume de votre appareil est suffisant.
2. Assurez-vous que l'application est autorisée à utiliser le haut-parleur.
3. Essayez une autre traduction. Certaines traductions fonctionnent mieux avec la lecture à haute voix que d'autres.
4. Pour une liste de vérification étape par étape, consultez le guide [Lire à haute voix](theodia://help/tts).

## L'application plante sans cesse

1. Redémarrez l'application.
2. Redémarrez votre appareil.
3. Si le problème persiste, veuillez le signaler. Consultez le guide [Où poser des questions](theodia://help/getting-more-help).

## Je veux désinstaller l'application

Vous pouvez désinstaller Theodia comme n'importe quelle autre application. Avant de le faire, faites une sauvegarde de vos données. Après la désinstallation, les données sur l'appareil sont perdues.

## Toujours bloqué ?

Consultez le guide [Où poser des questions](theodia://help/getting-more-help). Vous y trouverez des liens pour signaler un problème et poser des questions à la communauté.

Vous pouvez aussi rechercher dans les guides d'aide depuis l'écran principal **Aide**. Tapez un mot comme `notifications`, `recherche` ou `signets` pour trouver le guide correspondant.
