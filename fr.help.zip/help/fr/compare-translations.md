---
title: Comparer les traductions
level: everyday
categories: [read, study]
summary: Comment voir le même verset dans toutes les traductions que vous avez installées.
---

# Comparer les traductions

> **Mode :** L'outil **Comparer** est disponible en mode **Standard** et **Érudit**. Le mode **Se concentrer** est réservé à une lecture propre et sans distraction. Vous pouvez changer de mode dans **Paramètres** → **Mode utilisateur de l'app**.

L'outil **Comparer** affiche un seul verset dans toutes les traductions bibliques que vous avez installées, dans un seul panneau. Il est utile quand vous voulez voir comment différents traducteurs traitent un verset difficile, ou quand vous choisissez une traduction et voulez examiner le même verset dans chacune.

## Comment ouvrir Comparer

1. Ouvrez un chapitre dans n'importe quelle traduction.
2. Appuyez sur un verset pour afficher le menu du verset.
3. Appuyez sur **Comparer** (⇄).

Un panneau s'ouvre. La barre de titre affiche la référence (par exemple, « Jean 3:16 — Comparer »). Le panneau liste le même verset dans chaque traduction installée. Votre traduction actuelle apparaît en premier ; les autres sont triées par ordre alphabétique.

## À quoi ressemble le panneau

Le panneau est une **liste verticale**, pas une colonne côte à côte. Chaque ligne est une traduction :

- Le **nom de la traduction** (par exemple, « KJV ») se trouve en haut de la ligne. On peut appuyer dessus.
- Le **texte du verset** se trouve sous le nom.

Faites défiler le panneau pour voir toutes les traductions. Chaque traduction installée sur votre appareil apparaît ici. Si une traduction n'a pas ce livre ou ce verset, elle est omise.

## Comment lire le verset dans une autre traduction

Appuyez sur le nom de la traduction dans la ligne. Le panneau Comparer se ferme et le même chapitre s'ouvre avec le verset choisi affiché dans cette traduction. C'est le moyen le plus rapide de passer d'une comparaison à la lecture d'une traduction spécifique.

## Comment fermer Comparer

- **Sur un téléphone :** appuyez sur le X en haut à droite du panneau.
- **Sur une tablette :** appuyez sur le X dans l'en-tête du panneau, ou appuyez à l'extérieur du panneau.

Vous revenez à la vue du chapitre dans votre traduction d'origine.

## Quand utiliser Comparer

- **Choisir une traduction.** Ouvrez un verset que vous connaissez bien dans votre traduction actuelle, puis comparez-le dans les autres. Les différences ressortent clairement.
- **Versets difficiles.** Un verset déroutant dans une traduction est souvent plus clair dans une autre.
- **Études de mots.** Voyez comment différents traducteurs traitent un mot ou une phrase clé.

Pour une comparaison d'un coup d'œil de tout un chapitre dans plusieurs traductions à la fois, utilisez plutôt la **vue parallèle**. Consultez le guide [Mode Étude](theodia://help/study-mode) pour savoir comment l'activer.
