---
title: Créer vos propres ressources
level: advanced
categories: resources
summary: Comment créer des Bibles, commentaires, livres, dévotionnels et lexiques personnalisés et les importer dans Theodia.
---

# Créer vos propres ressources

Theodia prend en charge les ressources personnalisées au format Unique Bible App. Chaque ressource est un fichier SQLite avec une structure de table spécifique. Vous pouvez créer ces fichiers sur un ordinateur et les importer dans l'application.

## Types de fichiers et tables requises

### Bibles (`.bible`)

Un fichier Bible est une base de données SQLite avec au moins une de ces tables :

- **`Verses`** — colonnes : `Book` (entier, 1-66), `Chapter` (entier), `Verse` (entier), `Scripture` (texte)
- **`Bible`** — colonnes : `Book` (entier), `Chapter` (entier), `Verse` (entier), `Scripture` (texte)

Vous pouvez aussi inclure une table **`Details`** avec des colonnes de métadonnées comme `Description`, `Abbreviation` et `Version`.

Exemple SQL :

```sql
-- Main text table
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- Optional metadata table
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### Commentaires (`.commentary`)

Les commentaires se déclinent en trois types : **livre**, **chapitre** et **verset**. Le type est déterminé par la **première lettre du nom de fichier**.

#### Commentaires de livre — le nom de fichier commence par `b`

Un commentaire de livre couvre tout un livre de la Bible en une seule entrée. La table `Commentary` a besoin des colonnes `Book` et `Scripture` (ou `Content`). Aucune colonne `Chapter` ou `Verse` n'est nécessaire.

- **`Commentary`** — colonnes : `Book` (entier), `Scripture` (texte) ou `Content` (texte)

Exemple SQL :

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

Exemple de nom de fichier : `bMyCommentary.commentary`

#### Commentaires de chapitre — le nom de fichier commence par `c`

Un commentaire de chapitre couvre chaque chapitre d'un livre biblique.

- **`Commentary`** — colonnes : `Book` (entier), `Chapter` (entier), `Scripture` (texte) ou `Content` (texte)

Exemple SQL :

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

Exemple de nom de fichier : `cMyCommentary.commentary`

#### Commentaires de verset — le nom de fichier commence par `v`

Un commentaire de verset couvre des versets individuels. La table `Commentary` a besoin des colonnes `Book`, `Chapter`, `Verse` et `Scripture` (ou `Content`).

- **`Commentary`** — colonnes : `Book` (entier), `Chapter` (entier), `Verse` (entier), `Scripture` (texte) ou `Content` (texte)

Exemple SQL :

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

Exemple de nom de fichier : `vMyCommentary.commentary`

### Livres (`.book`)

Un fichier livre est une base de données SQLite avec une table `Reference`.

- **`Reference`** — colonnes : `id` (entier), `Chapter` (texte), `Content` (texte)

Chaque ligne est un chapitre. La colonne `Chapter` est le titre du chapitre. La colonne `Content` est le corps du chapitre, qui peut inclure du HTML (`<b>`, `<i>`, `<br>`, etc.).

Exemple SQL :

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

Vous pouvez aussi créer des livres à partir de fichiers Markdown. L'application peut importer des fichiers `.md` où `#` est le titre du livre et `##` marque les chapitres. Le Markdown est converti en HTML automatiquement.

### Dévotionnels (`.devotional`)

Un fichier dévotionnel est une base de données SQLite avec une table `devotional`.

- **`devotional`** — colonnes : `month` (entier, 1-12), `day` (entier, 1-31), `devotion` (texte)

Chaque ligne est la lecture d'un jour. L'application recherche l'entrée par le mois et le jour actuels.

Exemple SQL :

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### Lexiques (`.lexicon`)

Un fichier lexique est une base de données SQLite avec une table `Lexicon`.

- **`Lexicon`** — colonnes : `Topic` (texte, le numéro de Strong), `Definition` (texte, l'entrée lexicale)

La colonne `Topic` contient le numéro de Strong (par exemple, `G1161` ou `H7225`). La colonne `Definition` contient le texte complet de l'entrée, qui peut inclure du HTML.

Exemple SQL :

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

Les lexiques alimentent l'outil Info sur le mot. Quand vous appuyez sur un mot dans une Bible interlinéaire, l'application recherche le numéro de Strong dans les lexiques installés.

## Créer un fichier sur votre ordinateur

1. Installez un éditeur SQLite (DB Browser for SQLite, SQLiteStudio ou l'outil en ligne de commande `sqlite3`).
2. Créez un nouveau fichier de base de données.
3. Créez la table requise et insérez vos données.
4. Enregistrez le fichier avec l'extension correcte (`.bible`, `.commentary`, `.book`, `.devotional` ou `.lexicon`).

## Importer dans Theodia

1. Transférez le fichier sur votre appareil (AirDrop, e-mail, stockage cloud ou USB).
2. Ouvrez **Theodia**.
3. Allez dans **Paramètres** → **Gérer les ressources**.
4. Appuyez sur **Importer depuis un fichier**.
5. Sélectionnez votre fichier.

L'application valide le fichier (vérifie la présence de la table requise), le copie dans le dossier de données de l'application et l'active automatiquement. Si le fichier est invalide, un message d'erreur vous explique ce qui ne va pas.

## Limitations

- Vous ne pouvez pas écraser les ressources intégrées. Si vous essayez d'importer un fichier portant le même nom qu'une Bible, un commentaire ou un livre intégré, l'importation échoue.
- Les fichiers Bible ont besoin d'une table `Verses` ou `Bible`. Si aucune n'existe, l'importation échoue.
- Les fichiers de commentaire ont besoin d'une table `Commentary`.
  - Les commentaires de livre ont besoin des colonnes `Book` et `Scripture` (ou `Content`).
  - Les commentaires de chapitre ont besoin des colonnes `Book`, `Chapter` et `Scripture` (ou `Content`).
  - Les commentaires de verset ont besoin des colonnes `Book`, `Chapter`, `Verse` et `Scripture` (ou `Content`).
- Les fichiers livre ont besoin d'une table `Reference`.
- Les fichiers lexique ont besoin d'une table `Lexicon`.
- Les fichiers dévotionnel ont besoin d'une table `devotional`.

## Conseils

- Gardez une taille de fichier raisonnable. De très gros fichiers SQLite peuvent causer des problèmes de mémoire sur les appareils anciens.
- Testez d'abord votre fichier sur un ordinateur. Ouvrez-le dans un navigateur SQLite et exécutez `SELECT * FROM` la table requise pour vérifier que les données sont correctes.
- Pour les Bibles, assurez-vous que la colonne `Book` utilise des nombres (1 = Genèse, 66 = Apocalypse).
- Pour les commentaires, vous pouvez utiliser `Scripture` ou `Content` comme colonne de texte du commentaire.
- Pour les livres, le HTML dans la colonne `Content` est rendu à la lecture. Gardez-le simple : `<b>`, `<i>`, `<br>` et `<hr>` sont sûrs.

## Où trouver des ressources existantes

Theodia peut lire les ressources du projet [Unique Bible App](https://github.com/eliranwong/UniqueBible). De nombreuses Bibles, commentaires, livres et autres ressources y sont disponibles au format SQLite correct. Consultez le guide [Obtenir les ressources de base](theodia://help/getting-core-files) pour savoir comment les trouver et les ajouter.
