---
title: Références croisées
level: everyday
categories: study
summary: Comment trouver des versets qui se rattachent à celui que vous lisez.
---

# Références croisées

> **Mode :** Les références croisées sont disponibles en mode **Standard** et **Érudit**. Le mode **Se concentrer** est réservé à une lecture propre et sans distraction. Vous pouvez changer de mode dans **Paramètres** → **Mode utilisateur de l'app**.

Une « référence croisée » est un autre verset qui parle du même sujet que le verset que vous lisez. Le panneau de références croisées vous montre quels versets de la Bible sont connectés entre eux.

## Comment ouvrir les références croisées

1. Ouvrez un chapitre.
2. Appuyez sur un verset pour afficher le menu du verset.
3. Appuyez sur **Références croisées**.

Un panneau s'ouvre. Il affiche une liste d'autres versets connectés à celui sur lequel vous avez appuyé.

## Comment lire la liste

Chaque ligne est un verset connecté. Vous voyez :

- Le livre, le chapitre et le verset.
- Un court aperçu du texte du verset.
- Un score indiquant la force de la connexion.

## Comment sauter à un verset connecté

Appuyez sur n'importe quelle ligne. L'application ouvre ce verset pour vous. Quand vous avez terminé, appuyez sur le bouton retour pour revenir.

## Ce que signifie le score

Le score indique à quel point les versets sont étroitement connectés. Un score élevé signifie une connexion forte et directe. Un score faible signifie une connexion plus lâche.

## Utiliser les références croisées pour l'étude

Les références croisées sont utiles pour :

- **Les études de mots.** Voyez comment la Bible utilise un mot à différents endroits.
- **Les études thématiques.** Suivez un thème, comme « l'amour » ou « l'alliance », à travers les Écritures.
- **La préparation de sermon.** Trouvez rapidement des versets de soutien.

## Astuce

Les références croisées fonctionnent mieux avec une traduction mot à mot comme la WEB.
