---
title: Dévotionnels quotidiens
level: everyday
categories: [content, read]
summary: Comment lire un court dévotionnel chaque jour.
---

# Dévotionnels quotidiens

Un dévotionnel est une courte lecture pour une journée. Il contient souvent un verset, une brève réflexion et une question à méditer. Theodia est livré avec une petite bibliothèque de dévotionnels.

## Comment ouvrir un dévotionnel

1. Appuyez sur l'onglet **Dévotionnels** en bas de l'écran.
2. Vous voyez la liste des dévotionnels installés sur votre appareil.
3. Appuyez sur l'un d'eux pour l'ouvrir.

## Comment lire un dévotionnel

1. Ouvrez le dévotionnel.
2. Faites défiler pour lire.
3. Utilisez les boutons en haut pour :
   - Appuyez sur la **date** pour aller à un autre jour.
   - Appuyez sur l'**étoile** pour mettre le jour en signet.
   - Appuyez sur le **haut-parleur** pour le lire à haute voix (si votre appareil le prend en charge). Consultez le guide [Lire à haute voix](theodia://help/tts) pour savoir comment choisir une voix.
   - Appuyez sur **Précédent** ou **Suivant** pour passer au jour précédent ou suivant.

## Comment enregistrer un verset d'un dévotionnel

1. Ouvrez le dévotionnel.
2. Appuyez sur un verset.
3. Appuyez sur **Signet** ou **Surligner**.

Le verset est enregistré dans vos Signets ou Surlignages.

## Comment écrire une note sur un dévotionnel

1. Ouvrez le dévotionnel.
2. Appuyez sur un verset.
3. Appuyez sur **Note**. Tapez votre réflexion ou prière. Appuyez sur **Enregistrer**.

La note apparaît dans votre onglet Notes.

## Conseils

- Les dévotionnels n'ont pas besoin d'Internet. Ils fonctionnent hors ligne.
- Si vous voulez plus de dévotionnels, consultez le guide [Obtenir des ressources supplémentaires depuis GitHub](theodia://help/getting-core-files).
