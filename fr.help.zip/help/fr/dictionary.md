---
title: Dictionnaire biblique
level: everyday
categories: study
summary: Recherchez des mots et concepts bibliques dans les ressources de dictionnaire installées. Ouvrez-le depuis le menu du verset ou depuis une entrée de lexique, puis appuyez sur n'importe quel mot pour le voir dans chaque dictionnaire.
---

# Dictionnaire biblique

> **Mode :** Le Dictionnaire biblique nécessite le mode **Érudit**. Vous pouvez changer de mode dans **Paramètres** → **Mode utilisateur de l'app**.

L'outil Dictionnaire biblique recherche un mot ou une expression dans chaque ressource de dictionnaire que vous avez installée. Il est utile quand vous voulez une définition en langage simple d'un mot biblique, une description d'une personne ou d'un lieu, ou un court article sur un concept théologique.

Le Dictionnaire biblique est différent de l'outil **Info sur le mot**, qui recherche le mot original en hébreu ou en grec derrière un verset. Le dictionnaire lit le mot **anglais** sur lequel vous appuyez et vous montre ce que vos dictionnaires installés disent à son sujet. Pour des notes de traduction biblique mot à mot, consultez le guide [Commentaires et lexiques](theodia://help/commentaries-and-lexicons).

## Comment ouvrir le Dictionnaire

Il y a deux façons d'ouvrir le dictionnaire.

### Depuis le menu du verset

1. Ouvrez un chapitre en [Mode Étude](theodia://help/study-mode).
2. Appuyez sur un verset pour ouvrir le menu du verset.
3. Appuyez sur **Dictionnaire** (📖).

Un panneau s'ouvre intitulé avec la référence du verset (par exemple, « Jean 3:16 »). Le texte du verset se trouve en haut avec chaque mot sur lequel on peut appuyer. Sous le verset se trouve une bande de puces montrant chaque dictionnaire installé. En dessous se trouve la définition, vide jusqu'à ce que vous appuyiez sur un mot.

### Depuis une entrée de lexique

Quand vous lisez une entrée de lexique dans le panneau Info sur le mot, certaines entrées contiennent des liens bleus vers des articles de dictionnaire connexes. Appuyez sur l'un de ces liens. Le lexique se ferme et le dictionnaire s'ouvre à cet article. C'est le moyen le plus rapide de passer d'un mot grec ou hébreu à une explication en langage simple de ce qu'il signifie.

## Comment fonctionne la vue du verset

Quand vous ouvrez le dictionnaire depuis le menu d'un verset, le verset apparaît en haut du panneau sous forme de mots sur lesquels on peut appuyer. Les mots anglais courants comme « the », « and », « of », « to » et « a » ne sont pas cliquables. Tous les autres mots le sont. Chaque mot cliquable est coloré et en gras pour se distinguer du reste du verset.

Appuyez sur n'importe quel mot du verset. Theodia recherche dans chaque dictionnaire installé une correspondance exacte avec ce mot. La bande de puces en bas se met à jour pour montrer quels dictionnaires ont une entrée : les dictionnaires qui n'en ont pas sont estompés. Le premier dictionnaire ayant une entrée est sélectionné automatiquement, et sa définition apparaît sous la bande de puces.

Le mot sur lequel vous avez appuyé est mis en évidence dans le texte du verset en haut du panneau, pour que vous sachiez toujours ce que vous recherchez.

## Changer de dictionnaire

Chaque dictionnaire installé apparaît comme une petite puce sous le verset. Après avoir appuyé sur un mot :

- Une puce de **couleur pleine** — ce dictionnaire a une entrée pour le mot sur lequel vous avez appuyé. Appuyez dessus pour passer à la définition de ce dictionnaire.
- Une puce **estompée** — ce dictionnaire n'a pas d'entrée pour ce mot. Elle est grisée pour que vous voyiez d'un coup d'œil quels dictionnaires couvrent le mot, et la puce ne peut pas être appuyée.

Le dictionnaire sélectionné est mis en évidence. Appuyez sur n'importe quelle autre puce pleine pour lire le même mot dans ce dictionnaire. La définition ci-dessous se met à jour immédiatement.

Si le mot n'existe que dans l'un de vos dictionnaires installés, seule cette puce est pleine et les autres sont estompées.

## Ce que montre le panneau

Le panneau du dictionnaire a trois parties, de haut en bas :

- **Le verset** — le verset depuis lequel vous avez ouvert le dictionnaire. Les mots sont cliquables, et le mot que vous avez appuyé le plus récemment est mis en évidence.
- **La bande de puces** — chaque dictionnaire installé. Plein signifie « a une entrée pour le mot appuyé ». Estompé signifie « pas d'entrée pour ce mot ».
- **La définition** — l'article du dictionnaire sélectionné. Texte brut, formaté avec des paragraphes et des titres. Les liens internes vers d'autres entrées de dictionnaire sont cliquables ; appuyer sur l'un d'eux ouvre cette entrée dans le dictionnaire.

## Ce qui se passe si aucune entrée n'est trouvée

Si vous appuyez sur un mot qu'aucun de vos dictionnaires installés ne couvre, le panneau affiche un court message « aucune entrée trouvée » au lieu d'une définition. C'est courant pour des mots très communs comme « year » ou « come » qui ne sont pas vraiment des mots de théologie biblique, même s'ils apparaissent partout dans la Bible. Essayez un mot plus spécifique, ou utilisez plutôt l'outil Info sur le mot du lexique, qui fonctionne sur le texte grec et hébreu sous-jacent.

## Ce qui se passe si aucun dictionnaire n'est installé

Le dictionnaire a besoin d'au moins un fichier de ressource de dictionnaire pour être utile. Theodia en inclut un. Si vous l'avez supprimé ou si vous utilisez une installation personnalisée sans dictionnaire, la vue du verset apparaît toujours et les mots restent cliquables, mais la bande de puces est vide et chaque recherche renvoie « aucune entrée trouvée ».

Des dictionnaires supplémentaires ne peuvent pas être installés séparément.

## Conseils

- Le dictionnaire recherche des **correspondances exactes de mots**. Appuyer sur « love » trouve les entrées intitulées « love », mais pas « loved » ou « loving ». Pour chercher une forme apparentée, utilisez l'outil Info sur le mot du lexique sur le mot grec ou hébreu.
- La bande de puces est identique sur téléphone et tablette. Sur une tablette, le dictionnaire s'ouvre comme un panneau latéral à côté du chapitre ; sur un téléphone, il s'ouvre comme une modale plein écran. Les deux ont la même disposition en trois parties.
- Appuyer sur un mot dans un autre verset ouvre un nouveau verset dans le panneau. Votre sélection précédente est effacée. Appuyez sur un mot du nouveau verset pour lancer une nouvelle recherche.
- Certaines entrées de dictionnaire renvoient au même mot dans un autre dictionnaire. Appuyez sur ces liens internes pour suivre la piste à travers tous vos dictionnaires installés.

## Différences entre Dictionnaire et Info sur le mot

Les deux outils s'ouvrent depuis le menu du verset, mais ils font des choses différentes :

- **Dictionnaire** (📖) lit le mot anglais sur lequel vous appuyez et le trouve dans vos dictionnaires anglais installés. C'est le bon outil pour des définitions en langage simple de mots de théologie biblique comme « covenant », « atonement » ou « Pharisee ».
- **Info sur le mot** (?) lit le mot grec ou hébreu original derrière le verset et le trouve dans vos lexiques installés. C'est le bon outil pour les études de mots sérieuses, pour trouver chaque endroit où un mot grec est utilisé et pour lire les définitions en langue originale.

En cas de doute, commencez par le dictionnaire. Si vous voulez creuser la langue originale, passez à Info sur le mot. Consultez le guide [Commentaires et lexiques](theodia://help/commentaries-and-lexicons) pour la présentation complète de Info sur le mot.

## Guides connexes

- Le guide [Mode Étude](theodia://help/study-mode) explique en détail le menu du verset et où se trouve l'outil Dictionnaire (📖) à côté de Signet, Surligner, Écouter, Comparer, Références croisées, Commentaire IA, Info sur le mot et Notes.
- Le guide [Commentaires et lexiques](theodia://help/commentaries-and-lexicons) couvre Info sur le mot et les lexiques de langues originales.
- Le guide [Que sont les ressources ?](theodia://help/what-are-resources) explique les différents types de fichiers utilisés par Theodia, y compris les ressources de dictionnaire.
- Le guide [Problèmes courants](theodia://help/common-problems) propose des solutions pour les résultats vides et autres problèmes de dictionnaire.
