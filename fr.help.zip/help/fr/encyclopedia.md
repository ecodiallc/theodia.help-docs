---
title: Encyclopédie
level: everyday
categories: study
summary: Comment rechercher des articles d'encyclopédie et parcourir des ouvrages de référence.
---

# Encyclopédie

Theodia comprend une **Encyclopédie** intégrée pour rechercher des articles, des personnes, des lieux et des sujets bibliques. L'application est livrée avec le _Kitto's Illustrated Commentary_ (KIT) intégré, et vous pouvez télécharger des encyclopédies supplémentaires depuis le dépôt.

## Qu'est-ce qu'une encyclopédie dans Theodia ?

Une encyclopédie est un ouvrage de référence composé de courts articles. Chaque article couvre une personne, un lieu, un événement ou un sujet biblique. Contrairement à un commentaire, qui explique un verset spécifique, un article d'encyclopédie explique le sujet lui-même.

## Comment ouvrir l'Encyclopédie

1. Appuyez sur **Encyclopédies** dans la barre d'outils du bas.
2. Choisissez une encyclopédie dans la rangée d'abréviations en haut.
3. Tapez un sujet, une personne ou un lieu dans la boîte de recherche.

La recherche nécessite au moins **3 caractères** avant que les résultats et les suggestions d'autocomplétion n'apparaissent.

## Lire un article

- Sur **téléphone**, appuyez sur n'importe quel résultat pour ouvrir l'article dans un nouvel écran.
- Sur **tablette**, l'article s'ouvre dans le panneau de droite tandis que la liste reste à gauche.

## Sélectionner des encyclopédies

Appuyez sur une puce d'abréviation (comme **KIT**) pour passer à cette encyclopédie. Pour rechercher dans plusieurs encyclopédies à la fois, utilisez l'onglet **Recherche** et sélectionnez **Encyclopédie** comme mode de recherche.

## Obtenir plus d'encyclopédies

1. Ouvrez **Paramètres**.
2. Appuyez sur **Gérer les ressources**.
3. Appuyez sur **Installer depuis GitHub**.
4. Sélectionnez l'onglet **Encyclopédies**.
5. Appuyez sur le bouton de téléchargement à côté de l'encyclopédie souhaitée.

Les encyclopédies sont téléchargées depuis le dépôt GitHub d'encyclopédies de Theodia et installées automatiquement. Les encyclopédies installées apparaissent dans l'écran Encyclopédie et dans la Recherche.

Vous pouvez aussi installer une encyclopédie depuis un fichier local : dans **Gérer les ressources**, appuyez sur **Installer un fichier local** et choisissez un fichier `.encyclopedia`. Le fichier est copié dans le dossier des encyclopédies de l'application et ajouté à l'index de recherche partagé.

## Appui long pour le titre complet

Dans l'écran Recherche, les puces d'encyclopédie affichent de courtes abréviations. Maintenez une puce enfoncée pour voir le nom complet de l'encyclopédie.

## Quand utiliser l'Encyclopédie

- Cherchez une personne, un lieu ou un sujet avant ou pendant la lecture d'un passage.
- Obtenez des informations sur un mot ou un concept biblique qui s'étend sur de nombreux versets.
- Lisez en parallèle avec un commentaire pour une étude plus approfondie.
