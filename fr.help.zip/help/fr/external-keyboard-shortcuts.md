---
title: Raccourcis clavier externe
level: everyday
categories: [tablet, settings]
summary: Référence complète des raccourcis clavier pour iPad avec un clavier externe connecté.
---

# ⌨️ Raccourcis clavier externe

Si vous utilisez Theodia sur iPad avec un clavier externe (Magic Keyboard, clavier Bluetooth ou clavier USB), vous pouvez naviguer dans l'application sans toucher l'écran.

> **Mode :** Certains raccourcis ne fonctionnent que lorsque la fonctionnalité correspondante est disponible dans votre mode utilisateur actuel. Par exemple, `Cmd + Option + 6` (Signets) et `Cmd + Option + 7` (Surlignages) ne font rien en mode Lecture. Changez de mode dans **Paramètres** → **Mode utilisateur de l'app**.

Les raccourcis fonctionnent sur **iPad**.

## Raccourcis globaux (n'importe où)

| Raccourci          | Action                                              |
| ------------------ | --------------------------------------------------- |
| `Cmd + /`          | Afficher cette aide sur les raccourcis clavier      |
| `Cmd + .`          | Fermer la modale / le panneau (alternative à Échap) |
| `Cmd + Option + 1` | Aller à l'onglet Accueil                            |
| `Cmd + Option + 2` | Aller à l'onglet Bible                              |
| `Cmd + Option + 3` | Aller à l'onglet Livres                             |
| `Cmd + Option + 4` | Aller à l'onglet Dévotionnels                       |
| `Cmd + Option + 5` | Aller à l'onglet Rechercher                         |
| `Cmd + Option + 6` | Aller à l'onglet Signets (Standard et Érudit)       |
| `Cmd + Option + 7` | Aller à l'onglet Surlignages (Standard et Érudit)   |
| `Cmd + Option + 8` | Aller à l'onglet Notes (Standard et Érudit)         |
| `Cmd + Option + 9` | Aller à l'onglet IA (Érudit uniquement, si activé)  |
| `Cmd + Option + 0` | Aller à l'onglet Aide                               |
| `Cmd + Option + I` | Aller à l'onglet À propos                           |
| `Cmd + [`          | Revenir en arrière                                  |
| `Cmd + F`          | Ouvrir la recherche                                 |
| `Cmd + K`          | Ouvrir le Menu rapide (Érudit)                      |
| `Cmd + ,`          | Ouvrir les Paramètres                               |
| `Cmd + Shift + M`  | Ouvrir le menu principal                           |
| `Cmd + Shift + T`  | Alterner le thème (par défaut / sombre)             |
| `Cmd + Shift + U`  | Ouvrir le sélecteur de mode utilisateur             |
| `Escape`           | Fermer la modale / le panneau                       |

## Raccourcis du lecteur biblique

Ces raccourcis fonctionnent à la fois dans la **Bible d'étude** et la **Bible concentrée**.

| Raccourci          | Action                                                                  |
| ------------------ | ----------------------------------------------------------------------- |
| `← Flèche gauche`  | Chapitre précédent                                                      |
| `→ Flèche droite`  | Chapitre suivant                                                        |
| `Cmd + R`          | Basculer entre la Bible d'étude et la Bible concentrée (Standard et Érudit) |
| `Cmd + Option + V` | Ouvrir le sélecteur de version                                          |
| `Cmd + Option + B` | Ouvrir le sélecteur de livre                                            |
| `Cmd + Option + C` | Ouvrir le sélecteur de chapitre                                         |
| `Cmd + T`          | Basculer la synthèse vocale (arrêter si lecture, démarrer si inactif)   |
| `Cmd + Option + T` | Lire / Mettre en pause la synthèse vocale                               |

## Bible d'étude uniquement

| Raccourci          | Action                                                                                |
| ------------------ | ------------------------------------------------------------------------------------- |
| `↑ Flèche haut`    | Sélectionner le verset précédent                                                      |
| `↓ Flèche bas`     | Sélectionner le verset suivant                                                        |
| `Cmd + ↑`          | Sélectionner le premier verset                                                        |
| `Cmd + ↓`          | Sélectionner le dernier verset                                                        |
| `Cmd + ←`          | Aller au chapitre 1                                                                   |
| `Cmd + →`          | Aller au dernier chapitre                                                             |
| `Cmd + 0`–`9`      | Saut direct à un verset (taper les chiffres, par ex. `Cmd + 1` `Cmd + 6` pour le verset 16) |
| `Cmd + P`          | Basculer les Bibles parallèles (Standard et Érudit)                                   |
| `Cmd + B`          | Mettre le verset sélectionné en signet (Standard et Érudit)                           |
| `Cmd + H`          | Surligner le verset sélectionné (Standard et Érudit)                                  |
| `Cmd + N`          | Ajouter une note pour le verset sélectionné (Standard et Érudit)                      |
| `Cmd + C`          | Comparer les traductions du verset sélectionné (Standard et Érudit)                   |
| `Cmd + X`          | Ouvrir les références croisées du verset sélectionné (Standard et Érudit)              |
| `Cmd + I`          | Ouvrir les infos sur le mot (Érudit)                                                  |
| `Cmd + D`          | Ouvrir le dictionnaire pour le verset sélectionné (Érudit)                            |
| `Cmd + A`          | Ouvrir le panneau IA pour le verset sélectionné (Érudit)                              |
| `Cmd + Option + S` | Basculer les sous-titres                                                              |
| `Cmd + Option + W` | Fermer tous les panneaux d'étude ouverts                                              |
| `Cmd + Option + M` | Ouvrir le menu d'action du verset                                                     |

## Bible concentrée uniquement

| Raccourci          | Action                       |
| ------------------ | ---------------------------- |
| `↑ Flèche haut`    | Faire défiler vers le haut   |
| `↓ Flèche bas`     | Faire défiler vers le bas    |
| `Cmd + ↑`          | Aller en haut de page        |
| `Cmd + ↓`          | Aller en bas de page         |
| `Cmd + =`          | Zoomer                       |
| `Cmd + -`          | Dézoomer                     |

## Recherche

| Raccourci           | Action                                  |
| ------------------- | --------------------------------------- |
| `Return`            | Exécuter la recherche                   |
| `Cmd + Return`      | Effacer la recherche et focaliser le champ |
| `Cmd + ↑`           | Faire défiler les résultats vers le haut |
| `Cmd + ↓`           | Faire défiler les résultats vers le bas |
| `Cmd + Option + A`  | Sélectionner tous les éléments de la portée |
| `Cmd + Option + C`  | Désélectionner tous les éléments de la portée |
| `Cmd + Option + B`  | Mode de recherche Bible                 |
| `Cmd + Option + O`  | Mode de recherche Livre                 |
| `Cmd + Option + D`  | Mode de recherche Dictionnaire (Érudit) |
| `Cmd + Option + X`  | Mode de recherche Lexique (Érudit)      |

## Résultats de recherche

| Raccourci | Action                          |
| --------- | ------------------------------- |
| `Cmd + S` | Ouvrir la feuille d'enregistrement de tous les résultats |
| `Cmd + ↑` | Faire défiler les résultats vers le haut |
| `Cmd + ↓` | Faire défiler les résultats vers le bas |

## Lecteur de livre

| Raccourci          | Action                         |
| ------------------ | ------------------------------ |
| `← Flèche gauche`  | Chapitre précédent             |
| `→ Flèche droite`  | Chapitre suivant               |
| `Cmd + ↑`          | Chapitre précédent             |
| `Cmd + ↓`          | Chapitre suivant               |
| `↑ Flèche haut`    | Faire défiler vers le haut     |
| `↓ Flèche bas`     | Faire défiler vers le bas      |
| `Cmd + B`          | Mettre le chapitre actuel en signet |
| `Cmd + J`          | Ouvrir le sélecteur de chapitre |
| `Cmd + L`          | Ouvrir le sélecteur de voix    |
| `Cmd + T`          | Basculer la synthèse vocale    |
| `Cmd + Option + T` | Lire / Mettre en pause la synthèse vocale |

## Lecteur de dévotionnel

| Raccourci          | Action                           |
| ------------------ | -------------------------------- |
| `← Flèche gauche`  | Jour précédent                   |
| `→ Flèche droite`  | Jour suivant                     |
| `↑ Flèche haut`    | Faire défiler vers le haut       |
| `↓ Flèche bas`     | Faire défiler vers le bas        |
| `Cmd + ↑`          | Faire défiler vers le haut (grand) |
| `Cmd + ↓`          | Faire défiler vers le bas (grand) |
| `Cmd + D`          | Ouvrir le sélecteur de date      |
| `Cmd + T`          | Basculer la synthèse vocale      |
| `Cmd + Option + T` | Lire / Mettre en pause la synthèse vocale |

## Discussion IA

| Raccourci          | Action                            |
| ------------------ | --------------------------------- |
| `Cmd + Return`     | Envoyer le message                |
| `Cmd + N`          | Nouvelle discussion               |
| `Cmd + D`          | Basculer le tiroir de conversation |
| `Cmd + Option + C` | Effacer la discussion actuelle    |
| `Cmd + S`          | Ouvrir le menu d'enregistrement   |
| `Escape`           | Fermer le tiroir / le menu        |

## Signets

| Raccourci                          | Action                              |
| ---------------------------------- | ----------------------------------- |
| `↑ Flèche haut` / `↓ Flèche bas`   | Sélectionner un signet              |
| `Return`                           | Ouvrir le signet (tablette : sélectionner) |
| `Cmd + R`                          | Lire le signet dans son contexte    |
| `Cmd + M`                          | Déplacer le signet sélectionné vers les dossiers |
| `Cmd + N`                          | Gérer les dossiers                  |
| `Escape`                           | Fermer le panneau de détail / le sélecteur de dossier |

Dans le sélecteur **Déplacer vers le dossier**, `↑ Flèche haut` / `↓ Flèche bas` déplace la sélection, `Return` active/désactive le dossier sélectionné ou active l'action mise en évidence, et `Escape` ferme le sélecteur. La ligne **+ Créer un dossier** se trouve en haut de la liste.

## Notes bibliques

| Raccourci                          | Action                    |
| ---------------------------------- | ------------------------- |
| `↑ Flèche haut` / `↓ Flèche bas`   | Sélectionner une note     |
| `Return`                           | Ouvrir la note            |
| `Cmd + Return`                     | Focaliser le champ de filtre |
| `Escape`                           | Fermer le détail / l'éditeur |

## Surlignages

| Raccourci                          | Action                    |
| ---------------------------------- | ------------------------- |
| `↑ Flèche haut` / `↓ Flèche bas`   | Sélectionner un surlignage |
| `Return`                           | Ouvrir le surlignage      |
| `Cmd + Return`                     | Focaliser le champ de filtre |
| `Escape`                           | Fermer le panneau de détail |

## Liste des Bibles

| Raccourci                                | Action                                 |
| ---------------------------------------- | -------------------------------------- |
| `Tab` / `→ Flèche droite` / `↓ Flèche bas` | Bible suivante                         |
| `← Flèche gauche` / `↑ Flèche haut`       | Bible précédente                       |
| `Return`                                 | Ouvrir la Bible focalisée              |
| `Cmd + Shift + S`                        | Basculer le favori pour la Bible focalisée |
| `Escape`                                 | Revenir en arrière                     |

## Écran des livres bibliques

| Raccourci                | Action                         |
| ------------------------ | ------------------------------ |
| `Tab` / `→ Flèche droite` | Livre suivant                  |
| `← Flèche gauche`        | Livre précédent                |
| `↓ Flèche bas`           | Livre en dessous dans la grille |
| `↑ Flèche haut`          | Livre au-dessus dans la grille |
| `Cmd + ↓`                | Section suivante (AT / NT)     |
| `Cmd + ↑`                | Section précédente (AT / NT)   |
| `Return`                 | Ouvrir le livre focalisé       |
| `Escape`                 | Revenir en arrière             |

## Liste des livres

| Raccourci                                | Action                   |
| ---------------------------------------- | ------------------------ |
| `Tab` / `→ Flèche droite` / `↓ Flèche bas` | Livre suivant            |
| `← Flèche gauche` / `↑ Flèche haut`       | Livre précédent          |
| `Return`                                 | Ouvrir le livre focalisé |
| `Escape`                                 | Revenir en arrière       |

## Écran des chapitres bibliques

| Raccourci                                | Action                       |
| ---------------------------------------- | ---------------------------- |
| `Tab` / `→ Flèche droite` / `↓ Flèche bas` | Chapitre suivant             |
| `← Flèche gauche` / `↑ Flèche haut`       | Chapitre précédent           |
| `Return`                                 | Ouvrir le chapitre focalisé  |
| `Escape`                                 | Revenir en arrière           |

## Écran des chapitres de livre

| Raccourci              | Action                              |
| ---------------------- | ----------------------------------- |
| `Tab` / `↓ Flèche bas` | Chapitre suivant                    |
| `↑ Flèche haut`        | Chapitre précédent                  |
| `Return`               | Ouvrir le chapitre focalisé         |
| `Cmd + Return`         | Focaliser le champ de recherche/filtre |
| `Escape`               | Revenir en arrière                  |

## Liste des dévotionnels

| Raccourci                                | Action                          |
| ---------------------------------------- | ------------------------------- |
| `Tab` / `→ Flèche droite` / `↓ Flèche bas` | Dévotionnel suivant             |
| `← Flèche gauche` / `↑ Flèche haut`       | Dévotionnel précédent           |
| `Return`                                 | Ouvrir le dévotionnel focalisé  |
| `Escape`                                 | Revenir en arrière              |

## Menu principal (quand ouvert)

| Raccourci          | Action                          |
| ------------------ | ------------------------------- |
| `↑ Flèche haut`    | Élément de menu précédent       |
| `↓ Flèche bas`     | Élément de menu suivant         |
| `Return`           | Sélectionner l'élément mis en évidence |
| `Escape`           | Fermer le menu                  |

## Paramètres

| Raccourci | Action                           |
| --------- | -------------------------------- |
| `Escape`  | Fermer la modale / le sélecteur ouvert |

## Modales d'édition

| Raccourci | Action                  |
| --------- | ----------------------- |
| `Cmd + S` | Enregistrer             |
| `Escape`  | Annuler / fermer        |

## Garde de frappe

Quand vous êtes focalisé dans un champ de texte (boîte de recherche, éditeur de note, saisie IA), les raccourcis sans Cmd comme les flèches et `Espace` sont supprimés pour éviter de déclencher accidentellement la navigation. Les raccourcis utilisant la touche `Cmd` (par ex. `Cmd + S`, `Cmd + B`) fonctionnent toujours pendant la frappe.
