---
title: Questions fréquentes
level: everyday
categories: faq
summary: Réponses aux questions les plus courantes sur l'utilisation de Theodia.
---

# Questions fréquentes

## Theodia coûte-t-il quelque chose ?

Theodia est un achat unique. Il n'y a pas d'abonnement, pas de publicité, pas d'achat intégré et pas de demande de don. Toutes les ressources supplémentaires disponibles dans le catalogue sont gratuites à télécharger après l'achat de l'application.

## Ai-je besoin d'une connexion Internet ?

Non. Une fois l'application et ses fichiers de données installés, tout fonctionne hors ligne. Vous pouvez lire, rechercher, surligner, prendre des notes et utiliser la plupart des outils d'étude sans signal.

La seule fonctionnalité qui nécessite Internet est le téléchargement de nouvelles ressources.

## Où sont stockées mes données ?

Tous vos signets, surlignages, notes et paramètres sont enregistrés sur votre appareil. Ils ne sont téléchargés sur aucun serveur.

Vous pouvez les sauvegarder manuellement. Consultez le guide [Sauvegarder vos données](theodia://help/backups) pour savoir comment faire.

## Puis-je écouter la Bible à haute voix ?

Oui. Ouvrez n'importe quel chapitre, appuyez sur le menu et choisissez l'option de lecture à haute voix. Votre appareil doit avoir une voix de synthèse vocale installée. Consultez le guide [Lire à haute voix](theodia://help/tts) pour plus d'informations.

## Comment rechercher un verset ?

Vous pouvez taper une référence comme `Jean 3:16` dans la Commande rapide sur l'écran d'accueil, ou utiliser l'onglet **Rechercher** pour chercher par mot ou phrase.

## Comment signaler un bug ou suggérer une fonctionnalité ?

Appuyez sur **Soumettre une suggestion/un problème** dans l'écran **À propos**, [signalez-le sur GitHub](https://github.com/ecodiallc/theodia.app/issues/new), ou visitez la page [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions).

## Quels appareils sont pris en charge ?

Theodia fonctionne sur iPhone, iPad et téléphones et tablettes Android. Il fonctionne mieux sur des appareils disposant d'au moins 2 Go de stockage libre pour les fichiers de données de base.

## Puis-je utiliser un clavier externe ?

Oui. Theodia prend en charge les claviers Bluetooth et USB sur iPad. La navigation, la recherche et de nombreuses fonctionnalités de lecture disposent de raccourcis clavier. Consultez le guide [Raccourcis clavier externe](theodia://help/external-keyboard-shortcuts) pour la liste complète.

## Quelles langues sont prises en charge ?

L'interface de l'application est disponible en anglais, arabe, chinois (simplifié et traditionnel), tchèque, danois, néerlandais, filipino, français, allemand, grec, hébreu, hindi, indonésien, italien, japonais, coréen, polonais, portugais (Brésil), roumain, russe, espagnol, suédois, thaï, turc, ukrainien et vietnamien.

La langue du texte biblique dépend des traductions que vous avez installées.

## Comment changer la langue ?

Allez dans **Paramètres** et recherchez l'option de langue.

## Ma question n'est pas ici. Où puis-je obtenir plus d'aide ?

Parcourez le reste des guides d'aide par sujet, ou posez une question dans la communauté [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions).

Astuce : Sur l'écran principal **Aide**, utilisez la boîte de recherche pour taper un sujet comme `notifications` ou `recherche` pour trouver le guide correspondant.
