---
title: Lire votre premier chapitre
level: beginner
categories: [start, read]
summary: Un guide pas à pas pour ouvrir et lire un chapitre.
---

# Lire votre premier chapitre

Ce guide vous accompagne pour ouvrir un chapitre pour la toute première fois.

## Étape 1 : Ouvrir l'onglet Bible

Regardez le bas de l'écran. Vous voyez une rangée d'onglets. Appuyez sur celui qui indique **Bible**.

## Étape 2 : Choisir un livre

Vous voyez une liste des livres de la Bible. Genèse est le premier. Jean est vers le milieu. Apocalypse est le dernier.

Appuyez sur le nom du livre que vous voulez.

## Étape 3 : Choisir un chapitre

Vous voyez les numéros de 1 jusqu'au nombre de chapitres du livre. Appuyez sur le chapitre souhaité.

Le chapitre s'ouvre. Les versets apparaissent à l'écran.

## Étape 4 : Se déplacer

- Faites glisser vers la **gauche** pour aller au chapitre suivant.
- Faites glisser vers la **droite** pour revenir en arrière.

## Étape 5 : Interagir avec un verset

Ce que vous pouvez faire avec un verset dépend de votre mode utilisateur.

### Mode Lecture

Le mode Lecture est propre et sans distraction.

- Appuyez sur un verset pour le mettre brièvement en évidence.
- Il n'y a pas d'outils d'étude, de signets ni de menus.
- Si vous voulez plus de fonctionnalités, passez au mode **Standard** ou **Érudit** dans **Paramètres**.

### Mode Standard

Le mode Standard ajoute des fonctionnalités quotidiennes pour l'étude personnelle de la Bible.

Appuyez sur un verset pour ouvrir un menu avec ces options :

- Mettre le verset en **Signet**.
- Le **Surligner** d'une couleur.
- **Ajouter une note biblique**.
- **Copier** le texte du verset.
- **Comparer** le verset dans une autre traduction.
- **Consulter les références croisées** du verset.

### Mode Érudit

Le mode Érudit débloque tous les outils pour une étude biblique approfondie.

Appuyez sur un verset pour ouvrir un menu avec tout ce qui est dans le mode Standard, plus :

- Le **Commentaire** sur le verset.
- **Info sur le mot** et les recherches en langue originale.
- Les définitions du **Dictionnaire**.
- L'**Assistant IA** pour une étude plus approfondie.

Vous pouvez changer de mode à tout moment dans **Paramètres**.

## Besoin d'aide avec un outil spécifique ?

Chaque outil a son propre guide. Appuyez sur **Aide** sur la page d'accueil pour les voir tous. Le guide [Mode Étude](theodia://help/study-mode) est un bon point de départ — il passe en revue tous les outils du menu du verset.

Si vous apprenez encore où se trouvent les choses, consultez le guide [Disposition et navigation de l'application](theodia://help/navigating-the-app). Il explique l'écran d'accueil, le menu principal et la barre d'outils du bas.

## Vous voulez plus de ressources ?

L'application est livrée avec plusieurs versions bibliques librement disponibles. Si vous voulez en ajouter d'autres, ou ajouter des commentaires, des livres ou des dévotionnels, consultez le guide [Obtenir des ressources supplémentaires depuis GitHub](theodia://help/getting-core-files). Il vous montre où les trouver et comment les ajouter.
