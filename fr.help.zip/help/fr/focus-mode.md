---
title: Se concentrer
level: beginner
categories: [layout, read]
summary: Une façon propre et sans distraction de lire de longs passages.
---

# Se concentrer

> **Mode :** La fonction **Se concentrer** est le lecteur du mode **Lecture**. Elle est aussi disponible en mode **Standard** et **Érudit** comme alternative au Mode Étude. Vous pouvez changer de mode dans **Paramètres** → **Mode utilisateur de l'app**.

La fonction **Se concentrer** permet de lire un chapitre biblique sans boutons ni menus gênants. Elle est idéale pour les longues sessions de lecture.

## Comment l'activer

1. Ouvrez n'importe quel chapitre.
2. Dans la rangée d'icônes en haut de l'écran, appuyez sur le bouton 📖. Il ouvre le même chapitre en mode Se concentrer.
3. Les menus et les boutons se masquent. Seul le texte biblique reste.

En mode **Lecture**, les chapitres s'ouvrent automatiquement en mode Se concentrer. Le bouton 📖 est masqué car il n'y a pas de Mode Étude vers lequel basculer.

## Ce que vous pouvez faire en mode Se concentrer

- **Faire défiler** pour lire.
- **Faire glisser** pour passer au chapitre suivant ou précédent.
- **Appuyer sur le bouton 📖** dans la barre du bas pour revenir au Mode Étude. (Masqué en mode Lecture.)
- **Appuyer sur le bouton 🔊** dans la barre du bas pour faire lire le chapitre à haute voix. Une mini barre de contrôle apparaît avec lecture, pause, retour, avance rapide et sélecteur de voix. (Masqué en mode Lecture — la synthèse vocale nécessite le mode Standard ou Érudit.)

## Un bon usage du mode Se concentrer

- Lire un livre entier, chapitre par chapitre.
- Lire un long passage pour un dévotionnel ou un moment de silence.
- Lire à haute voix et suivre le texte sans distractions.

## Passer au Mode Étude

Le mode Se concentrer masque tous les outils d'étude, mais ils ne sont qu'à un tap de distance. Appuyez sur le bouton 📖 en haut de l'écran pour ouvrir le même chapitre en [Mode Étude](theodia://help/study-mode). Le Mode Étude est le lecteur complet, avec commentaire, références croisées, recherches lexicales et notes. Pour savoir ce que le Mode Étude peut faire, consultez le guide [Mode Étude](theodia://help/study-mode).

En mode **Lecture**, le bouton 📖 est masqué car le Mode Étude n'est pas disponible.
