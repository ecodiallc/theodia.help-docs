---
title: Se déplacer rapidement
level: beginner
categories: layout
summary: Tous les moyens rapides d'accéder à un verset, un chapitre ou un écran dans Theodia.
---

# Se déplacer rapidement

Ce guide est une antisèche pour la navigation. Il couvre tous les moyens rapides de passer d'où vous êtes à où vous voulez aller.

## Aller directement à un verset

Le moyen le plus rapide d'ouvrir n'importe quel verset est la **Commande rapide** sur l'écran d'accueil.

- Tapez `Jean 3:16` et appuyez sur Envoyer.
- Tapez `Psaumes 23` et appuyez sur Envoyer.
- Tapez `Genèse 1` et appuyez sur Envoyer.

L'application ouvre le chapitre exact (et défile jusqu'au verset si vous en avez précisé un).

## Glisser entre les chapitres

Quand vous lisez un chapitre :

- **Glisser vers la gauche** → chapitre suivant.
- **Glisser vers la droite** → chapitre précédent.

Cela fonctionne d'un livre à l'autre. Après Exode 40, glisser vers la gauche vous emmène à Lévitique 1.

## Utiliser la barre du haut

Pendant la lecture, le haut de l'écran affiche la **traduction**, le **livre** et le **chapitre** actuels.

- Appuyez sur le nom de la traduction pour changer de Bible.
- Appuyez sur le nom du livre pour choisir un autre livre.
- Appuyez sur le numéro du chapitre pour choisir un autre chapitre.

## Sauter depuis un signet

Si vous avez enregistré un verset :

1. Ouvrez l'onglet **Signets**.
2. Appuyez sur n'importe quelle entrée.
3. Vous allez directement à ce verset.

## Sauter depuis la recherche

1. Ouvrez l'onglet **Rechercher**.
2. Tapez un mot ou une phrase.
3. Appuyez sur n'importe quel résultat.
4. L'application ouvre le chapitre avec vos mots de recherche surlignés en jaune.

## Changer de disposition de lecture

Le lecteur biblique a deux dispositions :

- **Mode Étude** — affiche le chapitre avec tous les outils d'étude accessibles en un tap.
- **Mode Se concentrer** — masque tous les outils et menus, ne laissant que le texte.

Pour changer : appuyez sur le bouton **📖** en haut de l'écran pendant la lecture. Appuyez à nouveau pour revenir. (Le mode Lecture reste toujours en mode Se concentrer.)

## Utiliser les onglets du bas

La rangée d'icônes en bas de l'écran est toujours visible. Appuyez sur n'importe quel onglet pour passer à cette section. Les onglets exacts dépendent de votre mode utilisateur :

**Tous les modes :**

- **Accueil** — retour à l'écran d'accueil.
- **Bible** — liste des traductions.
- **Rechercher** — recherche dans la Bible, les livres, les dictionnaires, les lexiques et les PDF.
- **Paramètres** — préférences et ressources.

**Standard et Érudit voient aussi :**

- **Signets** — versets enregistrés.
- **Surlignages** — versets marqués d'une couleur.
- **Notes** — vos notes personnelles.
- **PDF** — vos documents PDF importés.

**Érudit voit aussi :**

- **IA** — l'assistant IA (si activé dans Paramètres).

### Se souvenir de l'endroit où vous vous êtes arrêté

Chaque onglet conserve son propre historique de navigation. Quand vous revenez à un onglet, vous retournez à **l'endroit où vous vous êtes arrêté**, pas à l'écran de départ de cette section.

- Vous ouvrez l'onglet **Bible**, choisissez une traduction, ouvrez un chapitre, puis passez à **Rechercher**. Plus tard, vous appuyez à nouveau sur **Bible** et vous retournez directement à ce même chapitre.
- Vous ouvrez l'onglet **Signets**, appuyez sur un verset en signet, puis passez à **Paramètres**. Appuyer à nouveau sur **Signets** vous ramène à la liste des signets.

Cela s'applique à chaque onglet. Chacun se souvient de votre place jusqu'à ce que vous naviguiez explicitement vers un autre écran dans cet onglet.

### Ce qui réinitialise un onglet

Un onglet ne revient à son écran racine que dans les cas suivants :

- Vous êtes déjà sur cet onglet et vous appuyez à nouveau sur la même icône d'onglet. C'est un moyen rapide de le réinitialiser.
- L'application est fermée de force et rouverte.

### Onglets du bas vs. menu principal

- **Onglets du bas** — chaque onglet se souvient de sa propre pile. Appuyer sur un onglet vous ramène là où vous vous êtes arrêté.
- **Menu principal** — appuyer sur un élément navigue vers cet écran. C'est une liste déroulante, pas une superposition.

Exemple :

- Vous lisez Jean 3. Vous appuyez sur l'onglet **Signets**, puis à nouveau sur **Bible**. Vous revenez à Jean 3.
- Vous lisez Jean 3. Vous ouvrez le menu et appuyez sur **Notes**. Vous consultez vos notes, puis appuyez sur l'onglet **Bible** pour revenir à Jean 3.

## Conseils

- L'écran d'accueil se souvient des sections développées ou réduites.
- Si un onglet manque, vérifiez votre **mode utilisateur** dans **Paramètres** → **Mode utilisateur de l'app**. Le mode Lecture masque les signets, les surlignages, les notes et l'IA. Le mode Standard masque l'IA. Vous devrez peut- aussi activer une fonctionnalité dans **Paramètres** ou installer une ressource.
