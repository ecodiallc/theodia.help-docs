---
title: Obtenir des ressources supplémentaires
level: everyday
categories: resources
summary: Comment ajouter des Bibles, commentaires, livres et autres ressources à Theodia.
---

# Obtenir des ressources supplémentaires

Theodia est livré avec certaines ressources intégrées, mais vous pouvez en ajouter d'autres. Le moyen le plus simple est l'écran **Gérer les ressources** dans l'application.

## Ce que vous pouvez ajouter

- **Bibles** — plus de traductions dans différentes langues
- **Commentaires** — notes d'étude qui expliquent les versets
- **Livres** — classiques chrétiens et ouvrages de référence
- **Dévotionnels** — lectures dévotionnelles quotidiennes
- **Fichiers de base** — plus gros fichiers de données comme la morphologie, les références croisées et la Marvel Interlinear Bible (MIB)

## Comment ajouter des ressources depuis l'application

1. Ouvrez **Paramètres**.
2. Appuyez sur **Gérer les ressources**.
3. Choisissez un onglet : **Cœur**, **Bible**, **Commentaires**, **Livres** ou **Dévotionnels**.
4. Parcourez la liste. Appuyez sur une ressource pour en savoir plus.
5. Appuyez sur la case à cocher pour sélectionner ce que vous voulez.
6. Appuyez sur **Télécharger** en bas. Les fichiers se téléchargent et s'installent automatiquement.

Une fois installée, la ressource apparaît immédiatement dans l'application. Vous n'avez pas besoin de redémarrer.

## Fichiers de base

L'onglet **Cœur** contient de gros fichiers de données qui alimentent les outils d'étude plus approfondis. Cela inclut :

- Données de morphologie (formes de mots en langue originale)
- Bases de données de références croisées
- La Marvel Interlinear Bible (MIB)

Vous n'avez besoin de télécharger les fichiers de base qu'une seule fois. Ils restent sur votre appareil et fonctionnent hors ligne.

## Bibles mondiales

L'onglet **Bibles mondiales** contient des traductions bibliques provenant d'une collection plus large. Si vous ne voyez pas la traduction souhaitée dans l'onglet principal **Bible**, cherchez ici.

## Gérer les ressources installées

Sur l'écran principal **Gérer les ressources** (pas l'onglet de téléchargement), vous pouvez :

- **Activer ou désactiver** une ressource sans la supprimer. Les ressources désactivées restent sur votre appareil mais sont masquées dans les menus.
- **Supprimer** une ressource pour libérer de l'espace. Vous pourrez la retélécharger plus tard.

## Ajouter vos propres fichiers

Si vous avez un fichier de ressource provenant d'ailleurs — un ami, un autre projet ou un site web — vous pouvez l'importer directement :

1. Dans **Gérer les ressources**, appuyez sur **Installer un fichier local**.
2. Choisissez le fichier sur votre appareil.
3. L'application lit le fichier et l'ajoute à votre bibliothèque.

L'application accepte ces types de fichiers :

- `.bible` — traductions bibliques
- `.commentary` — commentaires
- `.lexicon` — lexiques
- `.book` — livres
- `.devotional` — dévotionnels

## Connecter un dépôt GitHub personnalisé

Si quelqu'un maintient un dépôt GitHub avec des ressources compatibles Theodia, vous pouvez l'ajouter comme source personnalisée :

1. Allez dans **Paramètres → GitHub**.
2. Appuyez sur **Ajouter un dépôt**.
3. Saisissez l'URL GitHub (par exemple, `https://github.com/username/repo-name`).
4. Choisissez les types de ressources que le dépôt contient (Bibles, commentaires ou livres).
5. Enregistrez-le.
6. Retournez dans **Gérer les ressources**. Un nouvel onglet apparaît avec les ressources de ce dépôt.

Si le dépôt est privé, vous devrez ajouter un **Jeton d'accès personnel GitHub** dans **Paramètres → GitHub** pour que l'application puisse le lire.

## Note sur la taille des fichiers

Les fichiers de ressources peuvent être volumineux. Les Bibles sont généralement petites (quelques mégaoctets). Les commentaires et les fichiers de base peuvent être beaucoup plus gros (des centaines de mégaoctets). Téléchargez de préférence par Wi-Fi.

## Résumé

- Utilisez **Paramètres → Gérer les ressources** pour parcourir et installer des ressources.
- Les fichiers de base débloquent des outils d'étude plus approfondis comme la morphologie et les références croisées.
- Importez des fichiers locaux si vous en avez vos propres.
- Ajoutez des dépôts GitHub personnalisés si vous voulez des ressources d'une autre source.
