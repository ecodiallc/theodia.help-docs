---
title: Où poser des questions
level: everyday
categories: trouble
summary: Comment obtenir de l'aide de l'équipe et de la communauté Theodia, et comment trouver des sujets d'aide dans l'application.
---

# Où poser des questions

Si vous êtes bloqué, il y a plusieurs endroits où demander de l'aide.

## Trouver un sujet d'aide

Si vous cherchez des informations sur une fonctionnalité spécifique, essayez l'un de ces chemins :

- **Parcourir par catégorie.** Ouvrez **Aide** et appuyez sur une catégorie comme **Paramètres et personnalisation** ou **Dépannage**. Chaque carte liste les guides connexes.
- **Rechercher par mot-clé.** Sur l'écran principal **Aide**, tapez un mot dans la boîte de recherche en haut. Par exemple, taper `notifications` affiche le guide [Notifications et rappels](theodia://help/notifications) ; taper `recherche` affiche le guide [Rechercher dans la Bible](theodia://help/search-the-bible).
- **Vérifiez d'abord les Paramètres.** De nombreuses fonctionnalités se configurent dans **Paramètres**. Si vous voulez configurer des rappels, ouvrez **Paramètres** → **Notifications**. L'écran des paramètres a aussi un lien **Aide** pour chaque section.

## Dans l'application

Ouvrez l'écran **À propos**. Vous verrez deux boutons :

- **Soumettre une suggestion/un problème** — ouvre un formulaire pour envoyer à l'équipe une question, une idée ou un rapport de bug.
- **Discussion / Commentaires** — ouvre le tableau de discussion communautaire.

## La page GitHub

Vous pouvez voir la liste des problèmes connus et les changements récents sur [GitHub](https://github.com/ecodiallc/theodia.app).

## Discussion communautaire

D'autres personnes utilisant Theodia posent des questions et partagent des conseils sur le [tableau de discussion communautaire](https://github.com/ecodiallc/theodia.app/discussions). Vous pouvez lire les anciens fils et en commencer un nouveau.

## Avant de demander

Quelques informations nous aident à vous répondre plus vite :

- **Quel est votre appareil ?** (par ex. iPhone 13, Pixel 7)
- **Quelle version de l'application ?** (Ouvrez **À propos** pour le voir.)
- **Qu'avez-vous fait ?** Une courte description des étapes.
- **Que s'est-il passé ?** Ce que vous avez vu à l'écran.
- **Qu'attendiez-vous ?** C'est souvent la partie la plus utile.

## À quoi vous attendre

- Pour les rapports de bug, l'équipe répond généralement en quelques jours.
- Pour les idées, l'équipe les lit toutes. Nous ne pouvons pas promettre quand une idée sera ajoutée.
- Pour les questions communautaires, d'autres utilisateurs répondent souvent plus vite que l'équipe.

## Note sur la confidentialité

Quand vous soumettez une question, veuillez ne pas inclure d'informations privées. L'équipe peut voir ce que vous envoyez.
