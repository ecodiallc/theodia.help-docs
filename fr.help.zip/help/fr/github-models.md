---
title: GitHub Models
categories: ai
level: advanced
summary: Configurez GitHub Models — un moyen gratuit de commencer à explorer l'IA dans Theodia sans abonnement API existant.
---

# GitHub Models

> **Mode :** L'assistant IA nécessite le mode **Érudit**. Vous pouvez changer de mode dans **Paramètres** → **Mode utilisateur de l'app**.

Si vous ne payez pas déjà pour un service d'IA, **GitHub Models** est le moyen le plus simple de commencer à explorer l'IA de Theodia. C'est gratuit pour démarrer, et il vous suffit d'un compte GitHub gratuit.

## Qu'est-ce que GitHub Models ?

GitHub Models est un service de GitHub qui vous permet d'exécuter des modèles d'IA modernes via une API. Il prend en charge le même format qu'OpenAI, donc il fonctionne parfaitement avec Theodia.

## Pourquoi choisir GitHub Models ?

- **Pas de carte de crédit requise** — Juste un compte GitHub.
- **Modèles de haute qualité** — Vous avez accès à GPT-4o, GPT-4.1 et d'autres modèles fiables qui prennent en charge les outils de Theodia.
- **Configuration facile** — Un jeton, une URL, et c'est terminé.

## Étape 1 : Créer un compte GitHub

Si vous avez déjà un compte GitHub, passez à l'étape 2.

1. Allez sur [github.com](https://github.com).
2. Appuyez sur **Sign up** et suivez les instructions pour créer un compte gratuit.
3. Vérifiez votre adresse e-mail quand GitHub envoie la confirmation.

## Étape 2 : Créer un jeton d'accès personnel

Ce jeton est votre clé API. Il dit à GitHub qui vous êtes quand Theodia envoie des questions.

1. Allez sur [github.com/settings/tokens](https://github.com/settings/tokens).
2. Appuyez sur **Generate new token** et choisissez **Generate new token (classic)**.
3. Donnez au jeton un nom comme **Theodia AI**.
4. Sous **Select scopes**, cochez la case pour **`models:read`**.
   - C'est la seule permission dont Theodia a besoin.
5. Faites défiler vers le bas et appuyez sur **Generate token**.
6. **Copiez le jeton immédiatement.** GitHub ne l'affichera qu'une seule fois. Collez-le dans un endroit sûr (comme l'application Notes de votre téléphone) jusqu'à ce que vous l'ajoutiez à Theodia.

## Étape 3 : Choisir un modèle

GitHub Models propose plusieurs modèles. Pour Theodia, voici les meilleures options :

| Modèle                | Limite gratuite quotidienne | Idéal pour                                    |
| --------------------- | ----------------------------- | --------------------------------------------- |
| `openai/gpt-4.1-nano` | 150 requêtes / jour          | Questions rapides et explications simples de versets |
| `openai/gpt-4.1-mini` | 150 requêtes / jour          | Étude générale avec bonne prise en charge des outils |
| `openai/gpt-4.1`      | 50 requêtes / jour           | Étude approfondie et questions complexes en plusieurs étapes |
| `openai/gpt-4o`       | 50 requêtes / jour           | Polyvalent, excellente prise en charge des outils |

Commencez par **`openai/gpt-4.1-mini`** — il est rapide, fiable et offre une limite de requêtes quotidienne plus élevée.

## Étape 4 : Configurer Theodia

1. Ouvrez **Theodia**.
2. Allez dans **Paramètres** → **Assistant IA**.
3. Assurez-vous que **Modèle distant** est sélectionné.
4. Appuyez sur le menu déroulant **Fournisseur** et choisissez **GitHub Models**.
   - Si GitHub Models n'est pas dans la liste, appuyez sur **Personnalisé** et entrez l'URL de base manuellement : `https://models.github.ai`
5. Collez votre jeton d'accès personnel GitHub dans le champ **Clé API**.
6. Entrez l'ID du modèle choisi dans le champ **Modèle** (par exemple : `openai/gpt-4.1-mini`).
7. Appuyez sur **Tester la connexion**.
8. Attendez la fin de la vérification. Vous devriez voir :
   - **✓ Connexion réussie**
   - **✓ Outils pris en charge**

Si vous voyez **✗ Outils non pris en charge**, essayez un autre ID de modèle dans le tableau ci-dessus.

## Étape 5 : Commencer à discuter

1. Appuyez sur l'onglet **IA** en bas de l'écran.
2. Tapez une question et appuyez sur **Envoyer**.
3. Ou, pendant que vous lisez n'importe quel chapitre biblique, appuyez sur un numéro de verset et choisissez **Commentaire IA** pour démarrer une discussion spécifique au verset.

## Dépannage

### « Échec de la connexion » ou « HTTP 401 »

- Assurez-vous d'avoir copié la **totalité** du jeton. C'est une longue chaîne qui commence par `ghp_`.
- Les jetons expirent s'ils ne sont pas utilisés pendant longtemps. Retournez sur GitHub et générez-en un nouveau.
- Vérifiez que vous avez sélectionné **models:read** lors de la création du jeton.

### « Outils non pris en charge »

- Certains modèles sur GitHub Models n'acceptent pas les appels d'outils. Essayez plutôt **`openai/gpt-4o`** ou **`openai/gpt-4.1-mini`**.
- Assurez-vous que l'ID du modèle est orthographié exactement comme indiqué, y compris le préfixe `openai/`.

### Erreurs de limite de taux

- Si vous atteignez la limite quotidienne, passez à un modèle avec une limite plus élevée (comme `openai/gpt-4.1-nano` à 150 requêtes par jour).
- Les limites se réinitialisent toutes les 24 heures.

## Résumé

- GitHub Models est le **moyen recommandé pour commencer à explorer l'IA** dans Theodia.
- Vous avez besoin d'un **compte GitHub gratuit** et d'un **jeton d'accès personnel** avec `models:read`.
- Le meilleur modèle de démarrage est **`openai/gpt-4.1-mini`**.
- Entrez le jeton et le modèle dans **Paramètres → Assistant IA**, appuyez sur **Tester la connexion**, et commencez à discuter.
