---
title: Surligner des versets
level: everyday
categories: [annotate, read]
summary: Comment marquer des versets en couleur et les retrouver plus tard.
---

# Surligner des versets

> **Mode :** Les surlignages sont disponibles en mode **Standard** et **Érudit**. Le mode **Se concentrer** est réservé à une lecture propre et sans distraction. Vous pouvez changer de mode dans **Paramètres** → **Mode utilisateur de l'app**.

Le surlignage marque un verset d'une couleur. Cela fonctionne comme un surligneur jaune sur du papier. Le verset reste surligné la prochaine fois que vous l'ouvrez.

## Comment surligner un verset

1. Ouvrez le verset.
2. Appuyez sur le verset pour afficher le menu.
3. Appuyez sur l'icône **Surligner**.
4. Choisissez une couleur.

Le verset est maintenant surligné de cette couleur.

## Comment changer la couleur du surlignage

1. Ouvrez le verset.
2. Appuyez sur le verset, puis appuyez sur l'icône **Surligner**.
3. Choisissez une nouvelle couleur.

## Comment supprimer un surlignage

1. Ouvrez le verset.
2. Appuyez sur le verset, puis appuyez sur **Surligner** dans le menu.
3. Appuyez sur **Retirer le surlignage** en bas du sélecteur de couleur.

## Une façon courante d'utiliser les couleurs

De nombreux lecteurs utilisent un petit ensemble de couleurs pour un petit ensemble d'usages :

- **Jaune** pour les favoris généraux.
- **Vert** pour les versets sur Dieu.
- **Bleu** pour les versets sur la prière.
- **Rose** pour les versets sur le réconfort.
- **Orange** pour les versets sur l'avertissement ou la correction.
- **Violet** pour les versets sur la prophétie ou la fin des temps.

Choisissez un système qui fonctionne pour vous.

## Comment voir tous vos surlignages

Appuyez sur l'onglet **Surlignages** en bas. Vous voyez la liste de chaque verset que vous avez surligné, du plus récent au plus ancien. Il y a une rangée de puces de couleur en haut — appuyez sur une couleur pour n'afficher que les surlignages de cette couleur, ou appuyez sur **Tout** pour effacer le filtre.

## Importer des surlignages

Vous pouvez importer des surlignages dans Theodia depuis d'autres applications et fichiers.

Allez dans **Paramètres** → **Signets** → **Importer des surlignages**. Choisissez **Importer depuis un fichier** ou collez depuis le presse-papiers. L'application détecte automatiquement le format.

### Formats pris en charge

**Export JSON natif** — Le format utilisé par la fonction d'exportation de Theodia :

```json
{
  "/bible/KJV/John/3#v3_16": "yellow",
  "/bible/KJV/Genesis/1#v1_1": "green"
}
```

**CSV** — Un tableau avec les colonnes `url` et `color`. Exemple :

```csv
url,color
/bible/KJV/John/3#v3_16,yellow
/bible/KJV/Genesis/1#v1_1,green
```

**Texte brut** — Chaque ligne est une référence biblique ou une URL, suivie optionnellement d'un nom de couleur. Exemple :

```
John 3:16 yellow
Genesis 1:1 green
Matthew 5:1
```

- Couleurs disponibles : `yellow`, `green`, `blue`, `pink`, `orange`, `purple`.
- Si aucune couleur n'est donnée, le surlignage est jaune par défaut.
- Les lignes commençant par `#` ou `//` sont traitées comme des commentaires et ignorées.

## Conseils

- Les surlignages restent sur votre appareil. Ils ne se synchronisent pas avec le cloud.
- Vous pouvez surligner un verset dans une traduction et le voir apparaître dans vos autres traductions du même verset.
- Consultez le guide [Sauvegarder vos données](theodia://help/backups) pour les protéger.
