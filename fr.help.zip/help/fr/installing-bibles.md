---
title: Installer des traductions bibliques
level: beginner
categories: start
summary: Comment ajouter une traduction biblique à votre bibliothèque.
---

# Installer des traductions bibliques

Theodia est livré avec quelques traductions bibliques prêtes à lire. Vous pouvez en ajouter à tout moment. Une « traduction » est une version différente du texte biblique, comme la King James Version.

## Comment ajouter une traduction

L'onglet Bible affiche une liste des traductions déjà installées. Pour en ajouter d'autres, ouvrez le gestionnaire de ressources :

1. Ouvrez **Paramètres**.
2. Appuyez sur **Gérer les ressources**.
3. Appuyez sur **Installer depuis GitHub**.
4. Dans le modal de téléchargement, appuyez sur l'onglet **Bible**.
5. Cochez la case à côté de chaque traduction souhaitée.
6. Appuyez sur **Installer la sélection** en bas.
7. Attendez la fin du téléchargement.

La traduction est maintenant dans votre bibliothèque. Pour la voir, ouvrez l'onglet **Bible**.

## Comment passer d'une traduction à l'autre

1. Ouvrez le chapitre que vous voulez lire.
2. Appuyez sur le nom de la traduction en haut de l'écran.
3. Choisissez celle que vous voulez dans la liste.

L'application enregistre votre choix pour la prochaine fois.

## Comment supprimer une traduction

1. Ouvrez **Paramètres**.
2. Appuyez sur **Gérer les ressources**.
3. Trouvez la traduction que vous voulez supprimer.
4. Appuyez sur le **X** à côté.
5. Confirmez la suppression.

Supprimer une traduction ne supprime pas vos notes, surlignages ou signets. Ceux-ci restent en sécurité.

## Combien d'espace les traductions utilisent-elles ?

La plupart des traductions font entre 2 et 10 Mo. Elles sont stockées sur votre appareil, pas dans le cloud. Vous pouvez en garder autant que vous voulez, tant que votre appareil a de la place.

## Et si une traduction n'est pas dans l'application ?

Certaines traductions ne figurent pas dans la liste intégrée. Vous pouvez toujours les ajouter.

1. Ouvrez l'application et allez dans **Paramètres** → **Gérer les ressources**.
2. Appuyez sur **Installer depuis GitHub**.
3. Dans le modal de téléchargement, regardez l'onglet **Bible** et l'onglet **Bibles mondiales**. Si votre traduction s'y trouve, sélectionnez-la et appuyez sur **Installer la sélection**.
4. Sinon, appuyez sur **Installer un fichier local** pour importer un fichier `.bible`. Obtenez le fichier depuis la page GitHub du projet. Consultez le guide [Obtenir des ressources supplémentaires depuis GitHub](theodia://help/getting-core-files) pour une aide pas à pas.
