---
title: Ajouter les fichiers de base
level: beginner
categories: start
summary: Comment télécharger les gros fichiers de données dont l'application a besoin pour étudier la Bible en profondeur.
---

# Ajouter les fichiers de base

Theodia est livré avec une Bible et quelques petits extras prêts à l'emploi. Pour tirer le meilleur parti de l'application, vous devez aussi télécharger les **fichiers de base**. Ce sont de gros fichiers de données qui ajoutent des outils d'étude comme un commentaire, des recherches de mots et des notes de grammaire. Sans eux, l'application fonctionne, mais les fonctionnalités d'étude sont limitées.

## Pourquoi vous avez besoin des fichiers de base

Les fichiers de base ajoutent :

- **Recherches de mots.** Appuyez sur un mot dans n'importe quel verset pour voir l'hébreu ou le grec original et ce qu'il signifie.
- **Commentaire.** Commentaire IA sur chaque verset.
- **Grammaire.** Informations sur chaque mot dans la langue originale.
- **Bible interlinéaire.** Lisez le texte en langue originale avec l'anglais sous chaque mot.

Vous pouvez lire la Bible sans eux, mais la plupart des outils d'étude en ont besoin.

## Comment installer les fichiers de base

**[Installer les fichiers de base](theodia://manage/core)**

1. Ouvrez **Paramètres**.
2. Appuyez sur **Gérer les ressources**.
3. L'onglet **Cœur** s'ouvre. Vous voyez une liste des fichiers de base. Chacun a un nom, une taille et une case à cocher.
4. Appuyez sur chaque fichier que vous voulez installer. Une coche indique qu'il est sélectionné.
5. Appuyez sur **Installer la sélection**.
6. Attendez que les fichiers se téléchargent et s'installent. Ils sont volumineux, donc cela peut prendre quelques minutes sur une connexion lente.

Les fichiers se téléchargent sur votre appareil. Vous n'avez besoin de le faire qu'une seule fois. L'application utilise les fichiers ensuite, même hors ligne.

## Conseils

- Utilisez le Wi-Fi. Les fichiers sont volumineux.
- Branchez votre téléphone ou tablette. Les gros téléchargements utilisent la batterie.
- Si un téléchargement échoue, appuyez à nouveau sur le fichier pour réessayer.
- Vous pouvez tous les installer ou seulement ceux dont vous avez besoin.

## Et si un fichier manque dans la liste ?

L'application récupère la liste depuis la page GitHub du projet. Si la liste est vide, vérifiez votre connexion Internet et réessayez. Si elle est toujours vide, consultez le guide [Où poser des questions](theodia://help/getting-more-help).

Pour des moyens plus avancés d'ajouter des ressources, consultez le guide [Obtenir des ressources supplémentaires depuis GitHub](theodia://help/getting-core-files).
