---
title: Langue et région de l'application
level: everyday
categories: settings
summary: Comment changer la langue de l'application.
---

# Langue et région de l'application

Theodia est disponible dans de nombreuses langues. L'application peut changer la langue des menus et des boutons. Le contenu d'aide peut aussi être téléchargé dans plusieurs langues ; ouvrez **Paramètres** → **Aide** ou **Gérer les ressources** → **Installer depuis GitHub** → **Aide** pour ajouter une langue.

## Comment ouvrir les paramètres de langue

1. Ouvrez **Paramètres**.
2. Appuyez sur **Langue**.

## Comment changer la langue de l'application

1. Dans la liste **Langue**, appuyez sur la langue souhaitée.
2. L'application applique la nouvelle langue immédiatement.

Les choix proposés dépendent des langues prises en charge par l'application.

## Comment la langue est choisie à la première installation

Lors de la première installation de Theodia, l'application choisit une langue en fonction des paramètres de votre appareil. Vous pouvez la changer à tout moment.

## Ce qui est traduit

- Les menus, boutons et étiquettes.
- Les écrans des paramètres.
- Les messages d'erreur.
- Les outils de recherche et d'étude.

## Ce qui est uniquement en anglais

- Certains contenus de livres et de dévotionnels.
- Les guides d'aide sont disponibles en anglais et sous forme de paquets téléchargeables pour d'autres langues. Ajoutez une langue dans **Paramètres** → **Aide** ou **Gérer les ressources** → **Installer depuis GitHub** → **Aide**.

## Traductions bibliques et langue de l'application

La langue de l'application et la langue de la traduction biblique sont deux choses différentes. Vous pouvez avoir l'application en espagnol et la Bible en anglais, ou l'inverse.

Pour changer la traduction biblique, consultez le guide [Installer des traductions bibliques](theodia://help/installing-bibles).

## Conseils

- Si un bouton ou une étiquette est vide, l'application manque une traduction. La version anglaise est généralement disponible comme solution de repli.
- Si vous souhaitez aider à traduire l'application, consultez le guide [Où poser des questions](theodia://help/getting-more-help).
