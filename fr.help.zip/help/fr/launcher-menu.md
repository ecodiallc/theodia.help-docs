---
title: Le Menu rapide
level: everyday
categories: layout
summary: Un moyen rapide d'accéder aux versets récents, d'exécuter des commandes et de changer de disposition biblique sans quitter l'écran actuel.
---

# Le Menu rapide

> **Mode :** Le Menu rapide nécessite le mode **Érudit**. Vous pouvez changer de mode dans **Paramètres** → **Mode utilisateur de l'app**.

Le Menu rapide est un panneau d'accès rapide que vous pouvez ouvrir depuis presque n'importe où dans l'application. Il conserve vos versets récents, vos commandes et vos configurations bibliques enregistrées en un seul endroit.

## Comment l'ouvrir

Appuyez sur l'**icône d'expansion (⌄)** dans le coin supérieur droit de l'en-tête de l'écran d'accueil. Un panneau glisse depuis le haut.

## Ce qu'il contient

### 1. Champ de commande

En haut du panneau se trouve une boîte de texte avec une icône de clavier. Tapez une commande et appuyez sur **Envoyer** sur votre clavier. L'application lit la commande et vous y emmène directement.

Exemples :

- `Jean 3:16` — ouvre ce verset.
- `chercher amour` — recherche « amour » dans la Bible.
- `signet psaumes 23` — met le verset en signet.
- `kjv` — bascule vers la traduction KJV.

Pour la liste complète des commandes, consultez le guide [Commandes](theodia://help/commands).

### 2. Ensembles parallèles

Si vous avez enregistré des préréglages de Bibles parallèles, ils apparaissent ici sous forme de liste réductible. Appuyez sur l'un d'eux pour charger instantanément cette configuration parallèle.

Pour créer un préréglage parallèle :

1. Ouvrez **Paramètres** → **Bible parallèle**.
2. Ajoutez des traductions et appuyez sur **Enregistrer le préréglage**.
3. Donnez-lui un nom. Il apparaîtra dans le Menu rapide.

Maintenez un ensemble parallèle enfoncé dans le Menu rapide pour le supprimer.

### 3. Collections bibliques

Les Collections bibliques sont des raccourcis en un tap qui changent votre traduction et votre vue parallèle en même temps. Si vous en avez créé, elles apparaissent ici sous forme de liste réductible.

Maintenez une collection enfoncée pour la supprimer.

### 4. Icônes de fonctionnalités

Sous le champ de commande, vous pouvez voir une rangée de boutons ronds avec des emojis. Ce sont des raccourcis en un tap vers les principales fonctionnalités de l'application.

Les icônes disponibles incluent :

- **À propos**, **Bible**, **Notes bibliques**, **Signets**, **Livres**
- **Dévotionnels**, **Fiches**, **Aide**, **Surlignages**
- **Playlists**, **Plugins**, **Rechercher**, **Paramètres**, **Theoscript**

Pour choisir quelles icônes apparaissent et dans quel ordre :

1. Ouvrez **Paramètres** → **Menu rapide**.
2. Appuyez sur **Icônes du menu rapide**.
3. Utilisez les commutateurs pour afficher ou masquer chaque icône.
4. Utilisez les flèches haut/bas pour réorganiser celles que vous avez activées.

L'ordre dans les paramètres est l'ordre d'affichage dans le Menu rapide.

### 5. Versets récents

L'application se souvient des derniers chapitres et versets que vous avez ouverts. Ils apparaissent sous forme de liste en bas du panneau. Appuyez sur n'importe quelle entrée pour y revenir directement.

- **Appuyez** pour ouvrir.
- **Glissez vers la gauche** ou **appuyez longuement** pour supprimer de la liste.
- Appuyez sur **Tout effacer** pour supprimer toutes les entrées à la fois.

## Quand utiliser le Menu rapide

Utilisez-le quand vous voulez :

- Revenir à un verset que vous venez de lire.
- Taper une commande sans aller à l'écran d'accueil.
- Changer de traduction ou de configuration parallèle en un tap.
- Ouvrir une fonctionnalité principale depuis n'importe où dans l'application.
- Vérifier quelque chose rapidement sans naviguer dans les menus.

## Conseils

- Le Menu rapide est disponible sur presque chaque écran, donc vous pouvez l'ouvrir pendant la lecture d'un chapitre.
- Le champ de commande prend en charge les mêmes commandes que le champ de commande de l'écran d'accueil.
- Les icônes de fonctionnalités et leur ordre sont enregistrés localement sur votre appareil. Ils survivent aux redémarrages de l'application.
- Les versets récents sont enregistrés localement sur votre appareil. Ils survivent aux redémarrages de l'application.
