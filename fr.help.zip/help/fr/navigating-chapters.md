---
title: Naviguer entre les livres, chapitres et versets
level: everyday
categories: [layout, read]
summary: Comment se déplacer dans la Bible et sauter où vous voulez aller.
---

# Naviguer entre les livres, chapitres et versets

Ce guide vous montre toutes les façons de vous déplacer dans la Bible.

## Le moyen simple : glisser

- Faites glisser vers la **gauche** sur un chapitre pour aller au chapitre suivant.
- Faites glisser vers la **droite** pour revenir en arrière.
- Cela fonctionne aussi pour le livre suivant. Après le dernier chapitre d'Exode, par exemple, le glissement vous emmène au premier chapitre de Lévitique.

## Le moyen par le menu

- Appuyez sur le nom de la traduction en haut pour passer à une autre Bible.
- Appuyez sur le nom du livre en haut pour choisir un autre livre.
- Appuyez sur le numéro du chapitre pour choisir un autre chapitre.

## Le moyen rapide : taper

- Sur la page d'accueil, il y a un champ en haut. Tapez une référence, comme `Jean 3:16` ou `psaumes 23`, et appuyez sur la touche **Envoyer** du clavier.
- L'application ouvre le verset.

## Le moyen par les signets

Si vous avez enregistré un verset, ouvrez l'onglet **Signets**. Appuyez sur n'importe quelle entrée pour y accéder.

## Le moyen par la recherche

Appuyez sur l'onglet **Rechercher**. Tapez un mot. L'application vous montre chaque verset qui le contient. Appuyez sur n'importe quel résultat pour l'ouvrir.

## Le moyen par l'historique

L'application se souvient des chapitres que vous avez ouverts. Pour les retrouver, regardez dans l'onglet **Signets** (pour les versets que vous avez enregistrés) ou faites défiler la liste des livres dans l'onglet **Bible** pour trouver un livre que vous avez récemment lu.

## Conseils

- L'onglet Bible affiche les livres dans l'ordre, de Genèse à Apocalypse.
- Pour les Psaumes, les Proverbes et les autres livres longs, appuyez sur le livre et utilisez la liste des chapitres pour avancer rapidement.
