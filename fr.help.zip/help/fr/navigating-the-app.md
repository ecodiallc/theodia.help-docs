---
title: Disposition et navigation de l'application
level: beginner
categories: layout
summary: Une visite de l'écran d'accueil, du menu principal et de la barre d'outils du bas — où se trouve tout.
---

# Disposition et navigation de l'application

Theodia comporte trois zones principales entre lesquelles vous pouvez vous déplacer : l'**écran d'accueil**, le **menu principal** et la **barre d'outils du bas**. Ce guide passe en revue chacune d'elles pour que vous sachiez toujours où aller.

## Une carte rapide

- L'**écran d'accueil** est la page que vous voyez en ouvrant l'application. Il contient un champ de recherche, de grands boutons pour chaque partie de l'application, et une liste de vos Bibles, livres et dévotionnels installés.
- La **barre d'outils du bas** (aussi appelée barre d'onglets) est la rangée d'icônes en bas de l'écran. Appuyez sur l'une d'elles pour accéder directement à cette partie de l'application.
- Le **menu principal** est l'icône avec trois lignes (☰) dans le coin supérieur droit de l'écran d'accueil. Appuyez dessus pour ouvrir une liste de tous les écrans de l'application, y compris ceux qui n'ont pas leur propre onglet.

## L'écran d'accueil

Quand vous ouvrez Theodia pour la première fois, vous arrivez sur l'écran d'accueil. Il est divisé en quatre parties, de haut en bas.

### L'en-tête

Tout en haut se trouve une barre colorée. À gauche se trouvent l'icône de l'application et le nom « Theodia. » À droite se trouve le bouton du menu principal (☰). Quand vous êtes dans un livre ou un chapitre, le côté gauche affiche plutôt un bouton de retour (←). Appuyez sur le menu principal pour ouvrir le menu (voir ci-dessous).

### La commande rapide

Juste sous l'en-tête se trouve une boîte de texte de style recherche intitulée **Commande rapide**. Tapez une courte instruction et appuyez sur la touche **Envoyer** de votre clavier. L'application lit l'instruction et vous emmène au bon écran. Exemples :

- `psaumes 23` — ouvre le Psaume 23
- `jean 3:16` — ouvre Jean 3:16
- `chercher amour` — recherche « amour » dans la Bible
- `signet jean 3:16` — enregistre Jean 3:16 comme signet
- `commentaire romains 8:28` — ouvre le commentaire pour ce verset
- `références` (suivi d'une référence) — ouvre les références croisées pour ce verset
- `aide` — ouvre la liste des commandes avec des exemples

Si l'application ne comprend pas ce que vous avez tapé, elle affiche une petite alerte avec une astuce. Consultez le guide **Problèmes courants** si les commandes ne fonctionnent pas.

### La grille de boutons

Sous la commande rapide se trouve une grille de grands boutons, deux par ligne. Chaque bouton vous emmène dans une partie différente de l'application. Les boutons sont :

- 📖 **Bible** — votre liste de traductions bibliques
- 🔍 **Rechercher** — recherche dans la Bible par mot ou phrase
- 📚 **Livres** — votre bibliothèque de classiques chrétiens
- 📅 **Dévotionnels** — dévotionnels quotidiens
- 🔖 **Signets** — vos versets et chapitres enregistrés
- 🖍 **Surlignages** — vos versets marqués d'une couleur
- 📝 **Notes** — vos notes privées sur les versets
- ⚙️ **Paramètres** — langue, thème, ressources, et plus
- ❓ **Aide** — le système d'aide (cette page)
- ℹ️ **À propos** — version de l'application et crédits

### Les listes de ressources

Sous la grille de boutons se trouvent des sections réductibles : **Bible**, **Livres** et **Dévotionnels**. Chaque section affiche les éléments que vous avez installés. Appuyez sur l'en-tête d'une section pour l' développer ou la réduire. Appuyez sur n'importe quel élément d'une section pour l'ouvrir.

La section Bible est le moyen le plus rapide de plonger dans une traduction spécifique — pas de menus, il suffit d'appuyer.

## La barre d'outils du bas

La barre d'outils du bas (barre d'onglets) est la rangée d'icônes en bas de l'écran. Elle reste visible presque partout dans l'application, pour que vous puissiez toujours passer à une autre section. Les onglets que vous voyez dépendent de votre mode utilisateur.

**Tous les modes voient :**

- 🏠 **Accueil** — ouvre l'écran d'accueil
- 📖 **Bible** — ouvre votre liste de traductions bibliques
- 📚 **Livres** — ouvre votre bibliothèque de livres
- 🔍 **Rechercher** — ouvre la recherche biblique
- ⚙️ **Paramètres** — ouvre les paramètres

**Le mode Standard et Érudit voient aussi :**

- 🔖 **Signets** — ouvre vos versets enregistrés
- 🖍 **Surlignages** — ouvre vos versets marqués d'une couleur
- 📝 **Notes** — ouvre vos notes privées

**Le mode Érudit voit aussi :**

- 💻 **IA** — ouvre l'assistant IA (si vous l'avez activé dans Paramètres)

L'onglet actuel est mis en évidence. Appuyez sur n'importe quel autre onglet pour changer.

### Comment se comporte la barre d'outils

Chaque onglet de la barre d'outils a sa propre **pile** d'écrans. Quand vous appuyez sur un onglet, vous revenez à **l'endroit où vous vous êtes arrêté** dans la pile de cet onglet, pas à l'écran de départ. Par exemple :

- Appuyez sur **Bible** → vous voyez la liste des traductions bibliques.
- Appuyez sur une traduction → vous voyez la liste des livres.
- Appuyez sur un livre → vous voyez la liste des chapitres.
- Appuyez sur un chapitre → vous lisez le chapitre.
- Passez à **Signets** pour vérifier quelque chose.
- Appuyez à nouveau sur **Bible** → vous revenez au chapitre que vous lisiez.

Chaque onglet se souvient de votre place. L'application conserve votre historique de navigation dans chaque onglet, donc changer d'onglet ne fait pas perdre votre progression.

### Ce qui réinitialise un onglet

Un onglet ne revient à son écran racine que lorsque :

- Vous êtes déjà sur cet onglet et vous appuyez à nouveau sur la même icône d'onglet. C'est un moyen rapide de revenir au départ.
- L'application est fermée de force et rouverte.

### Onglets du bas vs. menu principal

- **Onglets du bas** — chaque onglet se souvient de sa propre pile. Appuyer sur un onglet vous ramène là où vous vous êtes arrêté.
- **Menu principal** — appuyer sur un élément navigue vers cet écran en utilisant le même système d'onglets. Il ne s'ouvre pas comme une superposition.

Utilisez les onglets pour changer de tâche. Utilisez le menu principal quand vous voulez une liste complète de tous les écrans de l'application.

### Quand utiliser la barre d'outils

Utilisez la barre d'outils quand vous voulez changer ce que vous faites :

- Vous lisez un chapitre et voulez rechercher autre chose → appuyez sur **Rechercher**.
- Vous faites une recherche et voulez consulter vos signets → appuyez sur **Signets**.
- Vous êtes n'importe où dans l'application et voulez rentrer à l'accueil → appuyez sur **Accueil**.

## Le menu principal

Le menu principal est le bouton avec trois lignes superposées (☰) dans le coin supérieur droit de l'écran d'accueil. Appuyez dessus et un panneau glisse depuis la droite. Le panneau affiche chaque écran pris en charge par votre mode actuel :

- 🏠 **Accueil**
- 📖 **Bible**
- 📚 **Livres**
- 🙏 **Dévotionnels**
- 🔍 **Rechercher**
- 🔖 **Signets** (Standard et Érudit)
- 🖍 **Surlignages** (Standard et Érudit)
- 📝 **Notes** (Standard et Érudit)
- 💻 **Assistant IA** (Érudit uniquement, et seulement si l'IA est activée)
- ⚙️ **Paramètres**
- ❓ **Aide**
- ℹ️ **À propos**

L'élément correspondant à l'écran sur lequel vous vous trouvez actuellement est mis en évidence et a un petit point à côté. Appuyez sur n'importe quel élément pour y aller directement. Appuyez à l'extérieur du panneau, sur le X en haut, ou sur le bouton retour de votre appareil pour le fermer sans changer d'écran.

### En quoi le menu principal est différent

Le menu principal est un panneau déroulant, pas une couche de navigation séparée. Quand vous appuyez sur un élément, l'application navigue vers cet écran de la même manière que si vous aviez utilisé l'onglet du bas ou la grille de boutons. La pile de votre onglet actuel est conservée, donc vous pouvez revenir où vous en étiez en appuyant à nouveau sur l'onglet d'origine.

Par exemple :

- Vous lisez Jean 3. Vous appuyez sur l'onglet **Signets**. Vous allez à vos signets. Quand vous appuyez à nouveau sur **Bible**, vous revenez à Jean 3 — exactement là où vous vous étiez arrêté.
- Vous lisez Jean 3. Vous ouvrez le menu principal et appuyez sur **Notes**. Vos notes s'ouvrent. Pour revenir à Jean 3, appuyez sur l'onglet **Bible** et vous revenez automatiquement au chapitre.

Les onglets changent votre contexte et se souviennent de votre place. Le menu principal est simplement un autre moyen d'accéder aux mêmes écrans.

### Quand utiliser le menu principal

Utilisez le menu principal quand :

- Vous voulez ouvrir **Surlignages**, **Notes**, **Dévotionnels**, **Aide** ou **À propos** — des écrans qui n'ont pas leur propre onglet dans la barre d'outils.
- Vous êtes profondément dans un chapitre ou une recherche et voulez vérifier quelque chose rapidement sans perdre votre place.
- Vous voulez ouvrir **Paramètres** sans quitter l'écran sur lequel vous êtes.

## Mode Érudit

Si votre mode utilisateur est réglé sur **Érudit**, la disposition gagne des onglets, des éléments de menu et des outils de lecteur supplémentaires que le mode Lecture et le mode Standard masquent. Consultez le guide [Mode Érudit](theodia://help/scholar-mode) pour une présentation complète de chaque fonctionnalité.

## Comment les trois zones s'assemblent

- **Passer à une section principale différente** (Bible, Rechercher, Signets, etc.) → Barre d'outils du bas
- **Sauter à un verset spécifique ou exécuter une commande** → Commande rapide de l'écran d'accueil
- **Parcourir tous les écrans disponibles** → Grille de boutons de l'écran d'accueil
- **Consulter Notes, Surlignages ou Aide sans quitter votre place** → Menu principal
- **Ouvrir Paramètres depuis n'importe où** → Menu principal ou barre d'outils

Vous utiliserez les trois. Aucun n'est « la bonne façon. » Choisissez celui qui est le plus facile pour ce que vous faites.

### Barre d'outils vs menu principal : un exemple rapide

Imaginez que vous lisez Romains 8 et que vous voulez surligner un verset que vous aimez.

**En utilisant la barre d'outils :**

1. Appuyez sur le verset pour ouvrir le menu du verset.
2. Appuyez sur **Surligner** et choisissez une couleur.
3. C'est fait. Vous n'avez jamais quitté le chapitre.

**En utilisant le menu principal (si vous voulez réviser vos surlignages) :**

1. Appuyez sur ☰ pour ouvrir le menu.
2. Appuyez sur **Surlignages**. Votre liste de surlignages s'ouvre.
3. Consultez-les, puis appuyez sur l'onglet **Bible** pour revenir à Romains 8.

**En utilisant la barre d'outils (si vous voulez changer de tâche) :**

1. Appuyez sur **Accueil** ou **Signets** dans la barre d'outils.
2. Vous quittez Romains 8 et allez au nouvel écran.
3. Pour revenir à Romains 8, appuyez à nouveau sur **Bible** — vous revenez automatiquement au chapitre.

## Conseils

- L'écran d'accueil se souvient des sections développées ou réduites. Vous ne devez le configurer qu'une seule fois.
- Si vous ne voyez pas un onglet auquel vous vous attendez, vérifiez deux choses :

1. **Votre mode utilisateur** — Le mode Lecture masque les signets, les surlignages, les notes et l'IA. Le mode Standard masque l'IA. Changez de mode dans **Paramètres** → **Mode utilisateur de l'app**.
2. **Paramètres des fonctionnalités** — certains onglets doivent être activés dans **Paramètres** (par exemple, l'assistant IA).
