---
title: Écrire des notes
level: everyday
categories: [annotate, read]
summary: Comment écrire vos propres réflexions à côté d'un verset.
---

# Écrire des notes

> **Mode :** Les notes sont disponibles en mode **Standard** et **Érudit**. Le mode **Se concentrer** est réservé à une lecture propre et sans distraction. Vous pouvez changer de mode dans **Paramètres** → **Mode utilisateur de l'app**.

Les notes sont l'endroit où vous écrivez vos propres réflexions, prières ou idées d'étude à côté d'un verset. Chaque note est liée à un verset spécifique.

## Comment ajouter une note

1. Ouvrez le verset.
2. Appuyez sur le verset pour afficher le menu.
3. Appuyez sur **Note** dans le menu. Elle a une icône de crayon.
4. Tapez votre note.
5. Appuyez sur **Enregistrer**.

La note est maintenant enregistrée avec le verset.

## Comment lire une note

1. Ouvrez le verset.
2. Cherchez la marque de crayon à côté du verset. Cela signifie qu'il y a une note.
3. Appuyez sur le verset. La note apparaît en dessous.

## Comment modifier une note

1. Ouvrez le verset avec la note.
2. Appuyez sur le verset.
3. Appuyez sur **Note** dans le menu.
4. Apportez vos modifications.
5. Appuyez sur **Enregistrer**.

## Comment supprimer une note

1. Ouvrez le verset avec la note.
2. Appuyez sur le verset.
3. Appuyez sur **Note** dans le menu.
4. Appuyez sur **Supprimer**.

## Comment voir toutes vos notes

Appuyez sur l'onglet **Notes** en bas. Vous voyez la liste de chaque note que vous avez écrite, triée par date.

## Rechercher dans vos notes

Dans l'onglet **Notes**, appuyez sur la boîte **Rechercher**. Tapez un mot. L'application trouve chaque note contenant ce mot.

## Conseils

- Les notes sont idéales pour les sermons, les dévotionnels et les questions d'étude.
- Les notes sont privées. Elles restent sur votre appareil.
- Consultez le guide [Sauvegarder vos données](theodia://help/backups) pour les protéger.
