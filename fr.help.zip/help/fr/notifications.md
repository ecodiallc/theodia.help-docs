---
title: Notifications et rappels
level: everyday
categories: [settings]
summary: Comment activer, personnaliser et gérer les rappels hors ligne pour la prière, les dévotionnels, les plans de lecture biblique, et plus.
---

# Notifications et rappels

Theodia peut vous rappeler la prière, les dévotionnels, les plans de lecture biblique, les fiches et d'autres activités — même hors ligne. Tous les rappels sont planifiés sur votre appareil ; aucune connexion Internet ni serveur de notifications push n'est nécessaire.

## Comment activer ou désactiver les rappels

1. Ouvrez **Paramètres**.
2. Appuyez sur **Notifications**.
3. Activez ou désactivez **Activer les notifications**.

La première fois que vous activez les rappels, l'application demande la permission d'envoyer des notifications. Appuyez sur **Autoriser** pour que les rappels puissent apparaître.

Si vous avez précédemment refusé la permission, iOS ou Android peut bloquer la demande. Dans ce cas, allez dans l'application **Paramètres** de votre appareil, trouvez **Theodia**, et activez les notifications là-bas.

## Types de rappels

L'écran des notifications est divisé en canaux. Chaque canal est une famille de rappels que vous pouvez activer ou désactiver indépendamment :

- **Rappels de prière** — rappels généraux de prière.
- **Routine de prière** — rappels liés à une routine de prière spécifique.
- **Dévotionnel** — le verset ou dévotionnel du jour.
- **Rappels de plan biblique** — rappels pour un plan de lecture biblique actif.
- **Rappels Theoscript** — rappels pour exécuter un Theoscript.
- **Rappels de perspicacité IA** — rappels générés par l'IA.
- **Rappels de révision de fiches** — invitations à réviser des fiches.
- **Rappels d'habitude de lecture** — invitations quotidiennes de lecture.
- **Rappels liturgiques et saisonniers** — rappels liés au calendrier de l'Église.
- **Mes rappels** — rappels créés à partir de signets, de surlignages, de playlists, de chapitres bibliques ou de livres.
- **Rappels personnalisés** — rappels entièrement personnalisés que vous créez vous-même.

Appuyez sur n'importe quel canal pour voir ses rappels, changer l'heure, choisir les jours d'activation ou le désactiver.

## Rappels personnalisés

Les rappels personnalisés sont des rappels que vous construisez de zéro.

1. Dans **Paramètres** → **Notifications**, appuyez sur **Rappels personnalisés**.
2. Appuyez sur le bouton **+**.
3. Saisissez un **Titre** et un **Message**.
4. Choisissez une **Heure**.
5. Sélectionnez les **Jours** où vous voulez qu'il se répète.
6. Choisissez ce que le rappel ouvre quand on appuie dessus (facultatif).
7. Appuyez sur **Enregistrer**.

Vous pouvez modifier ou supprimer un rappel personnalisé à tout moment en appuyant dessus dans la liste.

## Que se passe-t-il quand vous appuyez sur un rappel

La plupart des rappels ouvrent un écran spécifique dans l'application. Par exemple, un rappel de routine de prière ouvre cette routine ; un rappel de plan biblique ouvre la prochaine lecture.

Si un rappel n'a pas d'écran lié, il ouvre l'application à l'écran d'accueil.

## Heures de silence

Les heures de silence coupent le son des notifications tout en laissant apparaître les rappels visuels.

1. Dans **Paramètres** → **Notifications**, appuyez sur **Heures de silence**.
2. Définissez une heure de **Début** et de **Fin**.

Les rappels planifiés pendant les heures de silence apparaîtront à l'écran sans son.

## Rappels à venir et historique

- **Rappels à venir** montre tout ce qui est programmé pour se déclencher ensuite.
- **Historique des notifications** montre les rappels récemment livrés, planifiés et annulés.

Utilisez ces listes pour confirmer qu'un rappel est correctement réglé ou pour voir pourquoi un rappel n'est pas apparu.

## Si les rappels n'apparaissent pas

- Assurez-vous que **Activer les notifications** est activé.
- Vérifiez que les notifications sont autorisées dans les paramètres système de votre appareil.
- Assurez-vous que le canal du rappel est activé et qu'au moins un jour est sélectionné.
- Si vous avez défini des heures de silence, le rappel peut être silencieux.
- Certains fabricants Android mettent les applications en veille. Ajoutez Theodia à la liste autorisée si votre appareil propose des paramètres d'optimisation de la batterie.
- Si un rappel est lié à un contenu que vous avez supprimé (par exemple, un plan biblique ou une routine supprimée), le rappel peut ne pas se déclencher tant que vous n'aurez pas sélectionné une nouvelle cible valide.

## Sons de notification

Vous pouvez choisir le son joué par les rappels qui prennent en charge les sons. Appuyez sur **Son** à l'intérieur d'un rappel ou d'un canal pour choisir parmi les options disponibles. Les sons sont inclus avec l'application, donc ils fonctionnent hors ligne.

Utilisez le bouton **Aperçu du son** pour entendre le son sélectionné avant d'enregistrer.

## Badges

Certains rappels peuvent ajouter un badge à l'icône de l'application. Appuyez sur **Effacer le badge** sur l'écran des notifications pour le réinitialiser.
