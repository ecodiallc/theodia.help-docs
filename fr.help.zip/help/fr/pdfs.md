---
title: PDF
level: everyday
categories: [read, resources]
summary: Importez, organisez et lisez des documents PDF dans Theodia.
---

# PDF

> **Mode :** Les PDF sont disponibles en mode **Standard** et **Érudit**. Le mode Concentration est réservé à une lecture propre et sans distraction. Vous pouvez changer de mode dans **Paramètres** → **Mode utilisateur de l'app**.

Theodia peut stocker et lire des fichiers PDF. Les PDF importés restent sur votre appareil ; ils fonctionnent donc hors connexion.

## Ouvrir la bibliothèque de PDF

Touchez l'onglet **PDF** en bas de l'écran, ou la tuile **PDF** sur l'écran d'accueil.

## Importer un PDF

1. Ouvrez l'onglet **PDF**.
2. Touchez le bouton **+** en bas à droite.
3. Choisissez un PDF sur votre appareil.
4. (Facultatif) Saisissez ou choisissez une catégorie pour l'organiser.

## Organiser les PDF

Appuyez longuement sur une carte PDF pour ouvrir un menu avec ces options :

- **Renommer** — change le titre affiché dans la bibliothèque.
- **Changer de catégorie** — déplace le PDF dans une catégorie.
- **Supprimer** — retire le PDF de Theodia. Cela supprime aussi sa position de lecture enregistrée.

Les catégories sont du texte libre. Saisissez un nouveau nom ou choisissez en un existant lorsque vous importez ou changez de catégorie.

## Lire un PDF

Touchez une carte PDF pour l'ouvrir. Le lecteur affiche :

- Le titre du document dans une barre en haut.
- Une rangée de boutons de page : **Première page**, **Précédent**, la page actuelle (« 3 / 120 »), **Suivant** et **Dernière page**.
- Une barre d'outils avec les outils du document : **Table des matières**, **Zoom arrière**, **Zoom avant**, **Réinitialiser le zoom**, **Signet**, **Rechercher**, **Écouter** et **Vue texte**.

Certains outils sont grisés lorsqu'ils ne peuvent pas être utilisés — par exemple, **Rechercher** et **Écouter** sont grisés tant que le texte interrogeable du PDF n'est pas installé.

### Tourner les pages

- Touchez la **flèche gauche** ou **droite** pour reculer ou avancer d'une page.
- Touchez **Première page** ou **Dernière page** pour aller à l'un des deux bouts du document.
- Touchez le numéro de page (par exemple « 3 / 120 ») pour ouvrir une grille de pages, puis touchez la page souhaitée. La grille s'ouvre près de la page où vous vous trouvez.
- Utilisez les **touches fléchées gauche et droite** d'un clavier externe.

### Zoom

- Touchez **Zoom avant** (+) ou **Zoom arrière** (−) pour changer la taille de la page.
- Touchez **Réinitialiser le zoom** pour redonner à la page sa taille normale.
- Si vous zoomez, tournez la page puis dézoomez, Theodia vous ramène à la page que vous étiez en train de lire.

## Rechercher dans un PDF

1. Ouvrez le PDF et touchez le bouton **Rechercher** (loupe) dans la barre d'outils.
2. Saisissez ce que vous cherchez. Les résultats apparaissent au fil de la saisie, avec le numéro de page et un extrait du texte alentour.
3. Touchez un résultat pour aller à cette page.

La recherche nécessite que le texte interrogeable du PDF soit installé. S'il ne l'est pas encore, le bouton Rechercher est grisé. Les PDF installés depuis le dépôt GitHub communautaire incluent le texte interrogeable ; les PDF que vous importez vous-même ne l'ont pas tant qu'il n'a pas été ajouté.

## Table des matières

Si le PDF comporte une table des matières intégrée, le bouton **Table des matières** de la barre d'outils l'affiche sous forme de plan. Touchez le titre d'une section pour aller à cette page. Les sections peuvent être développées et réduites. Si le PDF n'a pas de table des matières, le bouton est grisé.

## Signets dans un PDF

1. Ouvrez le PDF et touchez le bouton **Signet** dans la barre d'outils.
2. Touchez **Marquer la page** pour enregistrer la page actuelle. Le nom commence comme le numéro de page — saisissez un autre nom si vous préférez — puis touchez **Enregistrer**.
3. Touchez n'importe quel signet de la liste pour aller à sa page.
4. Touchez le **×** à côté d'un signet pour le supprimer.

Les signets des PDF sont distincts de vos signets bibliques. Chaque PDF garde sa propre liste.

## Lire un PDF à haute voix

Si le texte interrogeable du PDF est installé, Theodia peut lire la page actuelle à voix haute :

1. Ouvrez le PDF et touchez le bouton **Écouter** (haut-parleur) dans la barre d'outils.
2. Une barre de commande apparaît avec **Lecture/Pause**, **Rembobiner**, **Avance rapide**, **Arrêter**, une barre de progression que vous pouvez toucher pour vous déplacer dans la page, la vitesse de lecture et la voix.
3. Quand la page est terminée, la lecture se poursuit automatiquement à la page suivante.

La voix et la vitesse sont les mêmes que celles utilisées pour la lecture biblique — voir [Lecture à haute voix](theodia://help/tts) pour savoir comment les changer.

## Copier, partager ou enregistrer le texte de la page

Touchez le bouton **Vue texte** dans la barre d'outils pour voir la page actuelle en texte brut. De là, vous pouvez :

- **Copier** — copier le texte de la page dans le presse-papiers.
- **Partager** — partager le texte de la page via n'importe quelle application de votre appareil.
- **Ajouter aux notes d'étude** — ouvre un éditeur de notes avec le texte de la page, la citation et un lien de retour vers cette page déjà remplis pour vous.

## Reprendre la lecture

Theodia se souvient de la dernière page consultée et rouvre le PDF à cette page la prochaine fois.

## Télécharger des PDF depuis GitHub

En mode **Érudit**, un bouton **Télécharger depuis GitHub** apparaît en bas de la bibliothèque. Il se connecte au dépôt communautaire de PDF afin que vous puissiez installer des documents PDF empaquetés de la même façon que les Bibles ou les livres.

## Remarques

- Les PDF sont stockés dans le dossier de documents privé de Theodia. Ils ne sont pas inclus dans les sauvegardes ; si vous passez à un nouvel appareil, vous devrez donc les importer à nouveau.
