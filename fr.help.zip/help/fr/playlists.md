---
title: Playlists
level: everyday
categories: playlists
summary: Créez et écoutez des playlists parlées de passages bibliques, de texte brut ou de n'importe quel verset que vous voulez entendre.
---

# Playlists

Une **playlist** est une liste de pistes que Theodia peut vous lire à haute voix. Chaque piste est soit un passage biblique, soit une courte note en texte brut. Les playlists sont utiles pour une écoute mains libres pendant les déplacements, une promenade, un moment de dévotion ou un travail de mémorisation.

Les playlists apparaissent dans l'application une fois qu'au moins une playlist a été créée ou peuplée.

## Où trouver les Playlists

Quand les playlists sont disponibles, vous pouvez y accéder de deux façons :

- **Écran d'accueil :** Dans la section **Plugins et plus**, appuyez sur **Playlists**.
- **Menu principal :** Ouvrez le menu (☰) et appuyez sur **Playlists**.

Si aucune playlist n'existe encore, la tuile et l'élément de menu Playlists sont masqués.

## Ce que contient une playlist

Chaque playlist comprend :

- Un **nom** — par exemple, « Versets du matin » ou « Mémoriser le Psaume 23 ».
- Une **catégorie** facultative — utile pour regrouper les playlists par usage.
- Une liste de **pistes** — les éléments à lire à haute voix.

Chaque piste contient :

- **Contenu** — soit une référence biblique, soit du texte brut.
- Une **étiquette** — affichée à l'écran pendant la lecture de la piste.
- Une **voix** facultative — choisissez une voix différente pour cette piste si vous le souhaitez.

## Créer une playlist

1. Ouvrez l'écran **Playlists**.
2. Appuyez sur **Créer une playlist** (ou le bouton **+**).
3. Donnez un nom à la playlist.
4. (Facultatif) Choisissez ou créez une catégorie.
5. Commencez à ajouter des pistes.

### Ajouter une piste depuis un passage biblique

1. Appuyez sur **Ajouter une piste**.
2. Choisissez **Passage biblique** comme type de contenu.
3. Entrez une référence, comme `Jean 3:16` ou `Psaume 23:1-6`.
4. Ajoutez une étiquette si vous le souhaitez, ou laissez vide pour utiliser la référence.
5. Enregistrez la piste.

### Ajouter une piste en texte brut

1. Appuyez sur **Ajouter une piste**.
2. Choisissez **Texte brut**.
3. Tapez le texte que vous voulez que Theodia lise.
4. Ajoutez une étiquette.
5. Enregistrez la piste.

### Ajouter des pistes en lot

Si vous avez une liste de références ou de lignes de texte, utilisez **Ajout en lot** :

1. Ouvrez une playlist.
2. Appuyez sur le menu et choisissez **Ajout en lot**.
3. Collez une référence ou une ligne de texte par ligne.
4. Activez **Détecter les références bibliques** si la plupart des lignes sont des références de versets.
5. Appuyez sur **Ajouter**. Chaque ligne devient une piste.

## Écouter une playlist

1. Ouvrez la playlist que vous voulez entendre.
2. Appuyez sur le bouton **Lecture** en haut ou à côté d'une piste.
3. Theodia lit chaque piste dans l'ordre.

Pendant la lecture d'une playlist, une barre de contrôle apparaît avec ces commandes :

- **Lecture / Pause**
- **Piste suivante**
- **Piste précédente**
- **Arrêter**

Vous pouvez aussi régler :

- **Vitesse** — la vitesse à laquelle la voix lit.
- **Répéter** — répéter toute la playlist, répéter une piste, ou lire une fois.
- **Aléatoire** — lire les pistes dans un ordre aléatoire.
- **Ignorer les parenthèses** — sauter le texte entre parenthèses.
- **Pause entre les pistes** — ajouter un court silence entre les pistes.
- **Minuteur de sommeil** — arrêter la lecture après un temps défini.

## Modifier une playlist

Pour modifier une playlist, mettez d'abord la lecture en pause si elle est en cours.

Vous pouvez :

- **Renommer** la playlist.
- **Réordonner les pistes** — faites glisser les pistes dans un nouvel ordre.
- **Modifier une piste** — changer sa référence, son texte, son étiquette ou sa voix.
- **Supprimer une piste** — la retirer de la playlist.
- **Supprimer toute la playlist** — cela ne peut pas être annulé.

## Exporter et importer des playlists

Les playlists sont exportées sous forme de fichiers JSON qui incluent toutes les pistes, les catégories et les paramètres. Vous pouvez partager le fichier avec un autre appareil, le conserver comme sauvegarde, ou le modifier sur un ordinateur.

- **Exporter toutes les playlists** — crée un fichier `playlists-AAAA-MM-JJ.json`.
- **Exporter une catégorie** — crée un fichier JSON contenant uniquement les playlists d'une catégorie.
- **Importer des playlists** — restaure des playlists depuis un fichier de sauvegarde JSON.

## Moyens rapides de construire une playlist

Vous pouvez aussi créer une playlist complète en JSON et l'importer. Voici un exemple :

```json
{
  "playlists": [
    {
      "name": "Morning Verses",
      "category": "Devotional",
      "tracks": [
        {
          "info": "John 3:16",
          "contentSource": "passage",
          "content": "For God so loved the world...",
          "rawContent": "John 3:16"
        },
        {
          "info": "Psalm 23",
          "contentSource": "passage",
          "content": "The Lord is my shepherd...",
          "rawContent": "Psalm 23:1-6"
        }
      ]
    }
  ]
}
```

Enregistrez le fichier, puis utilisez **Importer des playlists** pour le charger dans Theodia.

## Conseils

- Les playlists fonctionnent mieux avec des ensembles courts et ciblés de versets.
- Utilisez des catégories pour séparer les playlists de dévotion de celles de mémorisation.
- Réglez un minuteur de sommeil si vous écoutez en vous endormant.
- Si une piste utilise la mauvaise voix, vérifiez que la langue de la voix correspond à la langue du texte.
- Theodia lit le texte brut exactement comme écrit ; vérifiez l'orthographe pour les meilleurs résultats.
