---
title: Développer des plugins
categories: plugins
level: advanced
summary: Ce que contient un paquet de plugin Theodia et comment rédiger un manifeste de plugin.
---

# Développer des plugins

Un plugin Theodia est un paquet autonome qui ajoute des surfaces d'interface, du contenu ou de la gestion d'événements à l'application. Les plugins sont créés en dehors de l'application principale et installés par les utilisateurs via Paramètres → Plugins.

## Structure du paquet de plugin

Un paquet de plugin est une archive ZIP avec l'extension `.plugin.zip`. À l'intérieur, les fichiers se trouvent au niveau supérieur — pas dans un dossier imbriqué.

Un paquet typique contient :

```
my-plugin.plugin.zip
├── plugin.json       (requis)
├── data.sqlite       (facultatif, pour les plugins de contenu/interface)
├── template.html     (facultatif)
├── style.css         (facultatif)
└── logo.png          (facultatif)
```

Fichiers requis :

- `plugin.json` — le manifeste du plugin (voir ci-dessous).

Fichiers facultatifs :

- Une base de données SQLite pour les plugins qui stockent du contenu ou des données d'interface.
- Des ressources HTML, Markdown, image ou JSON référencées par le manifeste.

Toutes les références de ressources dans `plugin.json` doivent utiliser des noms de fichiers exacts et plats, sans chemin. Par exemple, utilisez `template.html` plutôt que `templates/template.html`.

## Bases du manifeste

Un `plugin.json` minimal ressemble à ceci :

```json
{
  "id": "org.example.myplugin",
  "name": "Example Plugin",
  "version": "0.1.0",
  "type": "ui",
  "description": "A short description of what the plugin does.",
  "extensions": [
    {
      "surface": "bible-verse-menu",
      "config": {
        "label": "Example",
        "icon": "🔌",
        "screenType": "template",
        "templateFile": "template.html"
      }
    }
  ]
}
```

### Champs courants du manifeste

| Champ           | Requis                            | Description                                                          |
| --------------- | --------------------------------- | -------------------------------------------------------------------- |
| `id`            | Oui                               | Identifiant en style domaine inversé, par exemple `org.example.myplugin`. |
| `name`          | Oui                               | Nom affiché aux utilisateurs.                                      |
| `version`       | Oui                               | Version semver du plugin.                                            |
| `type`          | Oui                               | `ui`, `content`, ou `composite`.                                       |
| `description`   | Non                               | Court résumé de ce que fait le plugin.                               |
| `minAppVersion` | Non                               | Version minimale de l'application Theodia requise.                   |
| `apiVersion`    | Non                               | Version de l'API plugin ciblée.                                      |
| `extensions`    | Requis pour `ui` et `composite` | Tableau de déclarations de surfaces (voir ci-dessous).               |

### Surfaces

Chaque entrée `extensions` déclare où le plugin apparaît et ce qu'il fait :

```json
{
  "surface": "home-screen",
  "config": {
    "title": "My Plugin",
    "icon": "📝",
    "screenType": "list",
    "dbTable": "Articles",
    "titleColumn": "Title"
  }
}
```

Surfaces prises en charge :

- `bottom-toolbar` — entrée dans l'onglet Plugins du bas.
- `home-screen` — tuile sur l'écran d'accueil.
- `hamburger-menu` — élément dans le menu principal.
- `bible-verse-menu` — action par appui long sur un verset dans le lecteur biblique.
- `bible-chapter-toolbar` — action dans la barre d'outils du chapitre du lecteur biblique.
- `book-chapter-toolbar` — action dans la barre d'outils du lecteur de livre.
- `ai-verse-action` — action IA sur un verset (nécessite que l'IA soit activée).
- `ai-chapter-action` — action IA sur un chapitre (nécessite que l'IA soit activée).
- `event` — gestionnaire d'événements du cycle de vie de l'application.

### Types d'écran

Le `screenType` dans une configuration de surface indique à l'application comment afficher l'écran du plugin :

- `list` — liste défilante de lignes de base de données.
- `data-list` — liste avec ajout/modification/suppression.
- `detail` — contenu d'une seule ligne ou d'un passage.
- `markdown` — fichier Markdown statique rendu en HTML.
- `html` — fichier HTML statique rendu avec `react-native-render-html`.
- `template` — fichier HTML avec remplacement de placeholders `{{key}}`.
- `flashcard` — interface de carte retournable utilisant deux colonnes de base de données.

## Distribution

Une fois empaqueté sous forme de fichier `.plugin.zip`, un plugin peut être :

- Importé directement par un utilisateur depuis un fichier.
- Servi depuis un dépôt de catalogue.

## Conseils

- Gardez `plugin.json` au format JSON valide. L'application rejette les manifestes invalides lors de l'installation.
- Utilisez des noms de fichiers exacts pour toutes les ressources référencées.
- Les ID de plugin doivent suivre le style domaine inversé pour éviter les collisions.
- Testez le contenu du plugin hors ligne, car les utilisateurs peuvent ne pas avoir de connexion réseau.
