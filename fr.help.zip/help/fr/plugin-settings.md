---
title: Activer et configurer les plugins
level: advanced
categories: plugins
summary: Comment activer, désactiver et importer de nouveaux plugins.
---

# Activer et configurer les plugins

Une fois un plugin installé, vous pouvez l'activer, le désactiver et le supprimer. Ce guide vous montre comment faire.

## Comment ouvrir les paramètres des plugins

1. Ouvrez **Paramètres**.
2. Appuyez sur **Extensions**.
3. Appuyez sur **Gérer les plugins**.

## Comment activer ou désactiver un plugin

Dans la liste **Plugins installés**, trouvez le plugin souhaité. Appuyez sur le commutateur à droite.

- **Activé** — le plugin est actif.
- **Désactivé** — le plugin est en pause.

Certains plugins ont aussi un commutateur activé/désactivé dans la rangée **Extensions** de la page d'accueil.

## Comment supprimer un plugin

1. Trouvez le plugin dans la liste **Plugins installés**.
2. Appuyez sur **Désinstaller**.
3. Confirmez.

## Comment installer un nouveau plugin

1. Ouvrez les paramètres des plugins (ci-dessus).
2. Appuyez sur **Importer depuis un fichier**.
3. Choisissez le fichier de plugin sur votre appareil.

Le plugin apparaît dans la liste **Plugins installés**. Activez-le pour commencer à l'utiliser.

## Conseils

- Certains plugins ont besoin d'Internet pour fonctionner. Ils peuvent ne pas fonctionner hors ligne.
- Certains plugins nécessitent un compte ou une clé. La page du plugin l'explique.
- Si un plugin cause des problèmes, désactivez-le. Vous pouvez toujours utiliser le reste de l'application.
- Supprimer un plugin ne supprime pas vos notes, surlignages ou signets. Ceux-ci restent en sécurité.
