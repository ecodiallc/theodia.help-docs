---
title: Que sont les plugins ?
level: advanced
categories: plugins
summary: Un guide simple sur les plugins et ce qu'ils peuvent ajouter.
---

# Que sont les plugins ?

Un plugin est un petit module complémentaire pour Theodia. Les plugins ajoutent de nouvelles fonctionnalités, de nouvelles ressources ou de nouveaux outils. Ils sont créés par des personnes de la communauté Theodia.

## Que peut faire un plugin ?

Les plugins peuvent faire beaucoup de choses. Quelques exemples :

- Ajouter une nouvelle traduction biblique.
- Ajouter un nouveau commentaire ou lexique.
- Ajouter un bouton dans la barre d'outils du bas.
- Ajouter une tuile sur l'écran d'accueil.
- Ajouter une entrée dans le menu principal.
- Ajouter un outil d'étude personnalisé.

## Comment trouver les plugins installés

Les plugins peuvent apparaître à trois endroits :

- **Barre d'outils du bas** — un onglet **Extensions** en bas de l'écran.
- **Écran d'accueil** — une grille de plugins sur l'écran d'accueil.
- **Menu principal** — une entrée **Extensions** dans le menu principal.

L'endroit où un plugin apparaît dépend de ce que son auteur a déclaré dans le manifeste. Appuyez sur n'importe quelle icône de plugin pour l'ouvrir.

## Formats de fichiers de plugin

Theodia prend en charge deux formats de fichiers de plugin :

- **`.plugin.zip`** — une archive ZIP contenant `plugin.json`, la base de données du plugin et les ressources. C'est le format recommandé. Le nom de fichier ressemble à `org.example.myplugin.plugin.zip`.
- **Ressources legacy à fichier unique** — d'anciens fichiers `.bible`, `.commentary`, `.lexicon`, `.book`, `.sqlite` ou `.db` qui intègrent le manifeste à l'intérieur de la base de données. Ils fonctionnent encore mais ont moins de fonctionnalités.

## Comment installer un nouveau plugin

Theodia n'a pas de magasin de plugins intégré. Pour installer un plugin :

1. Trouvez un fichier de plugin sur votre appareil.
2. Ouvrez **Paramètres** → **Extensions** → **Gérer les plugins**.
3. Appuyez sur **Importer depuis un fichier**.
4. Choisissez le fichier de plugin.

Le plugin apparaît dans la liste **Plugins installés**. Activez-le pour commencer à l'utiliser.

## Comment activer ou désactiver un plugin

Dans **Paramètres** → **Extensions** → **Gérer les plugins**, trouvez le plugin dans la liste **Plugins installés**. Appuyez sur le commutateur à droite.

- **Activé** — le plugin est actif.
- **Désactivé** — le plugin est en pause.

Désactiver un plugin masque ses fonctionnalités. Cela ne supprime pas le plugin.

## Comment supprimer un plugin

1. Ouvrez **Paramètres** → **Extensions** → **Gérer les plugins**.
2. Trouvez le plugin dans la liste **Plugins installés**.
3. Appuyez sur **Désinstaller**.
4. Confirmez.

## Que contient un fichier `.plugin.zip` ?

Un fichier `.plugin.zip` est une archive ZIP. Il doit contenir :

- `plugin.json` — le manifeste du plugin.
- La base de données du plugin, nommée exactement comme déclaré dans le manifeste.

Il peut aussi contenir :

- Des ressources HTML ou Markdown référencées par le manifeste.

Le manifeste déclare l'`id`, le `name`, la `version` du plugin et ce qu'il fournit :

- `type` : `content`, `ui`, ou `composite`.
- `content` : une base de données SQLite et un schéma pour du contenu Bible, commentaire, lexique, livre ou dévotionnel.
- `extensions` : des surfaces comme `bottom-toolbar`, `home-screen`, `hamburger-menu`, des actions sur les versets, des boutons dans la barre d'outils du chapitre, ou des gestionnaires d'événements.

## Un mot d'avertissement

Les plugins sont créés par d'autres personnes, pas par l'équipe Theodia. Lisez la description du plugin avant de l'installer. Certains plugins peuvent avoir besoin d'Internet ou collecter des données.

## Développer des plugins

Si vous voulez créer ou modifier des plugins dans le dépôt source de Theodia, consultez le guide [Développer des plugins](theodia://help/plugin-development). Il explique comment empaqueter des plugins avec `npm run package-plugins` et les réimporter pour modification avec `npm run import-plugin-dev`.

## Où puis-je obtenir de l'aide pour un plugin ?

Chaque plugin a sa propre page dans **Gérer les plugins**. Regardez d'abord là. Si vous avez encore une question, consultez le guide [Où poser des questions](theodia://help/getting-more-help).
