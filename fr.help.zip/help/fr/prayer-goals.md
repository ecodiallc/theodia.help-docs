---
title: Objectifs de prière
level: everyday
categories: [prayer]
summary: Suivez vos habitudes et objectifs de prière personnels.
---

# Objectifs de prière

> **Mode :** Les objectifs de prière sont disponibles en mode **Standard** et **Érudit**. Le mode **Se concentrer** masque les outils supplémentaires pour une lecture sans distraction. Vous pouvez changer de mode dans **Paramètres** → **Mode utilisateur de l'app**.

Les objectifs de prière vous permettent de suivre les habitudes qui vous tiennent à cœur — lire une prière fixe chaque matin, accomplir trois routines de prière par jour, tenir un journal avant le coucher, passer dix minutes en silence, ou tout autre modèle que vous choisissez. Theodia enregistre déjà votre activité de prière, donc un objectif observe simplement cette activité et vous indique comment vous vous en sortez.

## Ce qu'un objectif mesure

Quand vous créez un objectif, vous choisissez ce qu'il compte :

- **Routines** — accomplir n'importe quelle routine, une routine spécifique, ou une routine contenant un type d'étape comme le silence ou la lectio divina.
- **Entrées de journal** — écrire dans votre journal de prière.
- **Minutes du minuteur** — passer du temps avec le minuteur de prière.
- **Prières fixes** — lire une prière fixe ou un credo.
- **Sessions guidées** — accomplir une prière guidée audio.
- **Confirmation manuelle** — vous appuyez vous-même sur **Marquer comme fait** quand vous avez prié.

Vous pouvez aussi définir une cible numérique et un calendrier : quotidien, hebdomadaire, mensuel, jours spécifiques de la semaine, ou une seule fois.

## Créer un objectif

1. Allez dans l'onglet **Prière**.
2. Appuyez sur **Objectifs** (ou sur le bouton **+** si vous voyez déjà la rangée Objectifs).
3. Appuyez sur le bouton flottant **+** pour ouvrir le constructeur d'objectif.
4. Choisissez un modèle pour démarrer rapidement, ou choisissez **Commencer de zéro**.
5. Remplissez les détails : nom, icône, couleur, cible, calendrier et heure de rappel.
6. Appuyez sur **Enregistrer l'objectif**.

Le premier objectif que vous créez est automatiquement épinglé à l'écran d'accueil de Prière.

## Épingler un objectif à l'écran d'accueil

Les objectifs épinglés apparaissent dans la carte **Objectif actif** en haut de l'onglet Prière et dans la rangée **Objectifs de prière** sous les Statistiques. Pour épingler ou désépingler un objectif :

1. Ouvrez la liste des objectifs.
2. Trouvez l'objectif souhaité.
3. Appuyez sur l'objectif, puis appuyez sur **Épingler à l'accueil**. Appuyez à nouveau pour **Désépingler**.

Vous pouvez épingler jusqu'à deux objectifs. Seuls les objectifs actifs peuvent être épinglés.

## Marquer un objectif comme fait

Si un objectif est réglé sur **Confirmation manuelle**, Theodia ne peut pas savoir automatiquement quand vous avez prié. À la place, vous le marquez vous-même :

1. Ouvrez l'écran de détail de l'objectif.
2. Appuyez sur **Marquer comme fait aujourd'hui**.
3. Ajoutez éventuellement une courte note, puis appuyez à nouveau sur **Marquer comme fait**.

Vous pouvez aussi ouvrir le menu de débordement de la carte Objectif actif et appuyer sur **Marquer comme fait**.

## Lire votre progression

Appuyez sur n'importe quel objectif pour ouvrir son écran de détail. Vous y verrez :

- **Progression du jour** — à quel point vous êtes proche de la cible en ce moment.
- **Séries** — série actuelle et plus longue série.
- **Taux de réussite** — pourcentage de jours planifiés accomplis.
- **Mini-calendrier** — les jours verts sont accomplis, le jour encadré est aujourd'hui.
- **Historique récent** — les deux dernières semaines de progression.

### Actions sur un objectif

Depuis l'écran de détail, vous pouvez :

- **Épingler** ou **désépingler** de l'accueil.
- **Mettre en pause** pour arrêter le suivi pendant un moment (les séries sont gelées).
- **Reprendre** pour recommencer le suivi.
- **Modifier** pour changer la cible, le calendrier, le rappel ou le style.
- **Supprimer** pour supprimer l'objectif et son historique.

## Statistiques

L'écran **Statistiques** montre les tendances à travers tous vos objectifs :

- Objectifs atteints aujourd'hui, cette semaine et ce mois.
- Plus longue série actuelle.
- Taux d'achèvement hebdomadaire et mensuel.
- Temps de prière moyen (depuis les objectifs de minuteur).
- Objectif le plus régulier.
- Répartition des types d'objectifs.

Ouvrez les Statistiques depuis le menu de débordement de la liste des Objectifs de prière.

## Raccourcis clavier

Si vous utilisez un clavier externe :

- **Échap** — revenir en arrière.
- **Cmd + S** (iOS) ou **Ctrl + S** (Android) — enregistrer un objectif dans le constructeur.
- **Cmd + E** (iOS) ou **Ctrl + E** (Android) — copier un résumé dans le presse-papiers depuis l'écran de détail de l'objectif ou les Statistiques.

## Rappels et jours de grâce

Un objectif peut vous rappeler les jours sélectionnés à l'heure choisie. Les rappels utilisent les notifications locales de votre appareil et respectent le paramètre principal de notification dans **Paramètres** → **Notifications**.

Les **jours de grâce** protègent une série quand vous manquez un jour. Si vous définissez 1 ou 2 jours de grâce, votre série ne se brise pas tant que vous ne manquez pas autant de jours planifiés consécutifs.

## Conseils

- Commencez par un objectif. Il est plus facile de construire une habitude en se concentrant.
- Utilisez les modèles pour les modèles courants, puis personnalisez la cible ou le calendrier.
- Mettez un objectif en pause quand vous voyagez ou êtes malade au lieu de le supprimer — vos séries sont gelées et reprennent à votre retour.
- Les objectifs avec confirmation manuelle fonctionnent pour tout ce que Theodia ne mesure pas automatiquement, comme prier pour une personne ou une famille spécifique.
- Consultez les Statistiques une fois par semaine pour voir quels objectifs sont les plus faciles et lesquels ont besoin d'attention.
