---
title: Aperçu de Prière
level: beginner
categories: prayer
summary: Une rapide introduction à l'onglet Prière et à ses principales sections.
---

# Aperçu de Prière

L'onglet **Prière** est un espace dédié à la prière. Il rassemble des listes, des sessions guidées, un journal, un minuteur, des calendriers de lecture du lectionnaire et des prières fixes classiques.

## Les sections principales

- **Liste de prière** — suivez les personnes, les situations et les sujets pour lesquels vous priez.
- **Journal** — notez les réflexions, les réponses et les pensées au fil du temps.
- **Générer une prière** — demandez à Théophile d'écrire une prière à partir d'une demande ou d'une entrée de journal.
- **Credo et prières fixes** — prières classiques et credos de la tradition chrétienne.
- **Lectionnaire** — calendriers de lecture des Écritures pour la prière quotidienne ou saisonnière.
- **Prière guidée** — sessions de prière guidées audio avec synthèse vocale.
- **Minuteur** — sessions de prière chronométrées avec cloches optionnelles.
