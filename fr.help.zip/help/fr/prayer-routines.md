---
title: Routines
level: everyday
categories: [prayer]
summary: Créez et suivez des routines de prière, de lecture biblique, de lecture de dévotionnels, de signets, de surlignages, et bien plus.
---

# Routines

Une **routine** est une liste ordonnée d'étapes. Considérez-la comme une playlist pour votre vie spirituelle : elle peut inclure la prière, un passage biblique, un dévotionnel, une prière fixe comme la Prière du Seigneur, le silence, la réflexion, vos demandes de prière, des signets, des surlignages, des cantiques et des fiches.

Les routines se trouvent dans leur propre onglet **Routines**. Lorsque la fonctionnalité Routines est activée, l'onglet **Routines** est visible en bas de l'application.

## Pourquoi les routines comptent

- **Habitudes :** une routine transforme des moments épars en une session cohérente.
- **Flexibilité :** vous pouvez créer des routines pour la prière du matin, la lecture biblique du soir, le culte familial, un journal de gratitude, la révision de mémorisation, ou n'importe quelle saison.
- **Tout au même endroit :** la prière, les Écritures, les signets, les surlignages et les outils d'étude peuvent s'enchaîner dans une seule routine.

## Démarrer une routine

1. Appuyez sur l'onglet **Routines**.
2. Appuyez sur la routine que vous souhaitez exécuter.
3. Appuyez sur **Exécuter la routine** pour ouvrir le lecteur de routine et parcourir chaque étape.

## Construire une routine

1. Dans la liste des **Routines**, appuyez sur le bouton **+**.
2. Donnez un nom à la routine et ajoutez une description facultative.
3. Appuyez sur **Ajouter une étape** et choisissez un type d'étape :
   - **Passage** — lire un passage biblique.
   - **Prière fixe** — un credo, une prière ou une liturgie de la bibliothèque.
   - **Liste de prière** — prier en parcourant vos demandes actives.
   - **Silence / Réflexion / Prière libre** — un espace chronométré ou ouvert.
   - **Segment guidé** — une séance de prière enregistrée avec voix.
   - **Cantique** — lire ou chanter un cantique.
   - **Révision des fiches** — réviser des cartes de mémorisation.
   - **Dévotionnel** — lire une entrée de dévotionnel.
   - **Révision des signets** — revoir vos signets enregistrés.
   - **Révision des surlignages** — revoir les versets surlignés.
4. Réorganisez les étapes en appuyant sur les flèches haut/bas de chaque étape. Définissez une durée ou un libellé si vous le souhaitez.
5. Appuyez sur **Enregistrer**.

## Épingler une routine

Les routines épinglées apparaissent en haut de la liste des routines.

1. Ouvrez la liste des **Routines**.
2. Appuyez longuement sur une routine.
3. Appuyez sur **Épingler à l'accueil**.

## Ajouter quelque chose à une routine

Presque tout dans l'application peut devenir une étape de routine :

- **Lecteur biblique :** appuyez sur un verset, puis sur le bouton **+** et choisissez une routine.
- **Signets :** appuyez longuement sur un signet biblique, ou appuyez sur le bouton **+**, et choisissez une routine.
- **Prières fixes :** appuyez sur le bouton **+** sur n'importe quelle ligne de prière fixe.
- **Demandes de prière :** appuyez sur le bouton **+** sur une ligne de demande.
- **Surlignages :** choisissez une étape de révision des surlignages pour revoir les versets marqués.

Vous pouvez insérer l'élément au début, à la fin ou après une étape spécifique.

## Terminer une routine

Le lecteur de routine vous guide à travers chaque étape. Certaines étapes avancent automatiquement ; d'autres attendent que vous appuyiez sur **Suivant**. À la fin, un écran de célébration s'affiche avec des options pour ajouter la routine à une playlist ou en commencer une autre.

Un crochet vert apparaît sur la carte de la routine pour le reste de la journée pour indiquer qu'elle est terminée.

## Supprimer ou modifier une routine

- **Modifier :** ouvrez la liste des routines, appuyez sur une routine, puis appuyez sur **Modifier la routine**.
- **Supprimer :** appuyez longuement sur une routine et appuyez sur **Supprimer**. Les routines intégrées ne peuvent pas être supprimées, mais vous pouvez les masquer en les désépinglant.

## Note sur la confidentialité

Les routines et leurs données restent sur votre appareil. Les statistiques et les badges sont facultatifs ; pour les désactiver, allez dans **Paramètres** → **Prière** et désactivez les options de suivi.
