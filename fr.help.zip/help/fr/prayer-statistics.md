---
title: Statistiques de prière et séries
level: everyday
categories: prayer
summary: Comment fonctionnent les séries de prière et comment désactiver les statistiques et les badges.
---

# Statistiques de prière et séries

L'écran **Statistiques** dans l'onglet **Prière** suit votre activité de prière et vos séries lorsque les **Statistiques de prière** sont activées dans **Paramètres** → **Prière**. Il est conçu pour encourager une habitude de prière quotidienne sans être intrusif.

## Ce qui compte comme activité

Les éléments suivants sont enregistrés comme activité de prière :

- Les **routines** de prière terminées
- Les **sessions guidées** terminées
- Les **sessions de minuteur** terminées
- Les demandes de prière pour lesquelles vous avez **prié**
- Les **prières fixes** lues
- Les entrées du **lectionnaire** lues
- Les **entrées de journal** ajoutées

Tous ces éléments apparaissent dans votre résumé d'activité.

## Seules les routines prolongent votre série

Votre **série de prière** est le nombre de jours consécutifs où vous avez terminé au moins une routine de prière.

- Terminer une routine prolonge la série.
- Les autres activités de prière sont suivies, mais ne prolongent pas la série à elles seules.
- Si vous manquez un jour, la série revient à zéro.
- Terminer plusieurs routines dans une même journée compte toujours comme un seul jour de série.

> **Astuce :** si vous voulez créer ou conserver une série, faites des routines le centre de votre temps de prière quotidien.

## Ce que l'écran Statistiques affiche

- **Série actuelle** — les jours consécutifs avec une routine terminée.
- **Plus longue série** — votre meilleure série de tous les temps.
- **Résumé d'activité** — les totaux pour cette semaine, ce mois et depuis le début.
- **Calendrier** — une vue mois par mois des jours avec activité de prière.

## Badges

Lorsque l'option **Afficher les badges de prière** est activée, vous pouvez obtenir des réussites cachées pour des jalons de prière. Les badges sont une fonctionnalité ludique et discrète, pas une obligation.

Les badges nécessitent l'activation des statistiques de prière. Si les statistiques sont désactivées, les badges sont aussi masqués.

## Comment désactiver les statistiques et les badges

Vous pouvez désactiver ces fonctionnalités à tout moment :

1. Ouvrez **Paramètres** → **Prière**.
2. Désactivez **Activer les statistiques de prière**.
3. Désactivez **Afficher les badges de prière**.

Lorsque les statistiques sont désactivées :

- Les séries ne sont plus comptées.
- La section Statistiques disparaît de l'onglet Prière.
- Les badges sont masqués.
- Les données de prière existantes restent sur votre appareil ; rien n'est supprimé.

Pour réactiver les statistiques plus tard, réactivez simplement l'interrupteur.
