---
title: Lire les livres intégrés
level: beginner
categories: [content, read]
summary: Comment lire les classiques chrétiens fournis avec l'application.
---

# Lire les livres intégrés

Theodia comprend une petite bibliothèque de livres chrétiens. Ce sont des classiques que vous pouvez lire sur votre appareil.

## Comment ouvrir la bibliothèque

Appuyez sur l'onglet **Livres** en bas de l'écran. Vous voyez la liste des livres de votre bibliothèque.

## Comment lire un livre

1. Appuyez sur le titre du livre.
2. Le livre s'ouvre au premier chapitre.
3. Utilisez les boutons **Précédent** et **Suivant** en haut pour passer d'un chapitre à l'autre.

## Comment aller à un chapitre

Appuyez sur le nom du chapitre en haut de l'écran. Une liste de chapitres apparaît. Choisissez un chapitre pour y aller directement.

## Comment changer la taille de police

Ouvrez **Paramètres** → **Apparence** et choisissez une taille de police. La taille du texte change dans toute l'application, y compris dans les livres.

## Comment ajouter un signet dans un livre

Appuyez sur l'icône **étoile** en haut à droite. Le chapitre actuel est enregistré. Appuyez sur l'onglet **Signets** pour voir vos pages sauvegardées.

## Comment écouter un livre

Appuyez sur l'icône **Haut-parleur** en haut à droite. L'application lit le chapitre à voix haute. Appuyez à nouveau pour arrêter.

## Quels livres sont disponibles ?

La bibliothèque propose des classiques comme :

- Le Progrès du pèlerin
- L'Imitation de Jésus-Christ
- La Pratique de la présence de Dieu
- Le Livre de cantiques

La liste des livres peut s'enrichir au fil du temps. Les mises à jour de l'application peuvent en ajouter d'autres.

## Astuces

- Les livres sont stockés sur votre appareil. Aucune connexion internet n'est nécessaire.
- Les livres ne se synchronisent pas dans le cloud.
