---
title: Trouver des ressources sur GitHub
level: everyday
categories: resources
summary: Recherchez d'un coup tous les dépôts GitHub connus de l'app, puis installez ce que vous trouvez.
---

# Trouver des ressources sur GitHub

Theodia tient une liste de dépôts GitHub qui publient des ressources — Bibles, commentaires, livres, dévotionnels, listes de lecture, packs de prière et plus encore. **Rechercher des dépôts GitHub** les interroge tous d'un coup, inutile d'ouvrir chaque onglet et de naviguer séparément.

> La section GitHub des Paramètres n'est disponible qu'en mode **Érudit**. Pour l'activer, allez dans **Paramètres** → **Mode utilisateur de l'app** → **Érudit**.

## Comment rechercher

1. Ouvrez **Paramètres**.
2. Touchez **Rechercher des dépôts GitHub**.
3. Saisissez un mot dans le champ de recherche. L'app cherche ce mot dans le **nom** et la **description** de chaque paquet de chaque dépôt.

Quelques points à savoir sur la recherche :

- **Chaque mot doit correspondre.** Rechercher `morning evening` ne trouve que les paquets dont le nom ou la description contient *les deux* mots.
- **La casse n'a pas d'importance.** `Morning` et `morning` trouvent les mêmes paquets.
- **La meilleure correspondance arrive en premier.** Un paquet dont le nom *commence* par votre recherche s'affiche avant un paquet qui ne la mentionne que dans sa description.

## Filtrer

Touchez la barre de filtres au-dessus des résultats pour restreindre davantage la liste. Il y a deux filtres, et ils fonctionnent ensemble :

- **Auteur** — uniquement les paquets de cet auteur.
- **Tradition** — uniquement les paquets de cette tradition.

Touchez à nouveau un filtre pour le retirer, ou touchez **Effacer les filtres** pour réinitialiser les deux.

## Installer depuis un résultat

Chaque résultat montre le nom du paquet, le type de ressource, qui l'a créé et de quel dépôt il provient. À droite de la ligne se trouve un bouton :

- **Installer** — le paquet n'est pas encore sur votre appareil.
- **Mettre à jour** — une version plus récente est disponible. L'app vous demande d'abord de confirmer, car la mise à jour supprime l'ancienne copie ainsi que les notes, surlignages ou signets qui pointaient vers elle.
- **Ouvrir** — le paquet est déjà installé ; le toucher vous emmène à l'écran où vous l'utilisez.

Touchez **Actualiser** en haut pour récupérer tout de suite la dernière liste depuis GitHub. L'app actualise la liste d'elle-même une fois par jour ; une actualisation manuelle n'est nécessaire que lorsque vous savez que du nouveau vient d'être publié.

## Rechercher sans connexion

L'app conserve une copie de la liste sur votre appareil ; la recherche fonctionne donc même hors connexion. Si l'app ne peut pas joindre GitHub pour actualiser la liste, une bannière en haut vous indique que vous voyez les résultats en cache.

## Si la recherche ne trouve rien

- Essayez un mot plus court, un seul.
- Vérifiez qu'aucun filtre **Auteur** ou **Tradition** n'est encore appliqué — le bouton **Effacer les filtres** apparaît dès qu'il y en a un.
- Certains dépôts publient leurs paquets dans une langue différente du nom du paquet ; rechercher un mot traduit peut donc ne rien donner.
