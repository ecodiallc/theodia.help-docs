---
title: Mode Érudit
level: advanced
categories: [layout, read, study]
summary: Le mode d'étude le plus approfondi de Theodia, débloquant les commentaires, les lexiques, les références croisées, les outils IA et le Menu rapide.
---

# Mode Érudit

> **Mode :** le Mode Érudit n'est disponible que lorsque votre mode utilisateur est réglé sur **Érudit**. Changez de mode dans **Paramètres** → **Mode utilisateur de l'app**.

Le Mode Érudit débloque tous les outils d'étude de Theodia. Il repose sur le Mode Étude, vous bénéficiez donc toujours du menu du verset, des Bibles parallèles, des signets, des surlignages et des notes — plus les outils avancés listés ci-dessous.

## Comment ouvrir le Mode Érudit

Le Mode Érudit n'est pas un écran séparé. C'est un ensemble d'outils supplémentaires qui apparaissent dans le lecteur et la navigation existants lorsque votre mode utilisateur est réglé sur Érudit.

1. Ouvrez **Paramètres**.
2. Appuyez sur **Mode utilisateur de l'app**.
3. Choisissez **Érudit**.

Le changement prend effet immédiatement. Les menus et boutons auparavant masqués apparaissent maintenant.

## Outils supplémentaires du lecteur

Lorsque vous ouvrez un chapitre en [Mode Étude](theodia://help/study-mode), le Mode Érudit ajoute ces outils au menu du verset :

- **Commentaire IA** (◈) — demandez à l'assistant IA de rédiger une note d'étude pour ce verset. (Non disponible dans toutes les régions.)
- **Info mot** (?) — ouvre une entrée du lexique pour le mot hébreu ou grec original derrière le verset. Consultez le guide [Commentaires et lexiques](theodia://help/commentaries-and-lexicons).
- **Dictionnaire** (📖) — recherchez des mots bibliques généraux dans les dictionnaires que vous avez installés. Consultez le guide [Dictionnaire biblique](theodia://help/dictionary).

Ces outils nécessitent l'installation de ressources (commentaires, lexiques, fichiers de dictionnaire). Si un outil est grisé ou affiche « introuvable », ouvrez **Paramètres** → **Gérer les ressources** et ajoutez la ressource nécessaire.

## Navigation supplémentaire

### Onglet supplémentaire dans la barre d'outils

La barre d'outils du bas gagne un onglet supplémentaire :

- 💻 **IA** — ouvre l'assistant IA (uniquement si vous avez activé l'IA dans les Paramètres). Cet onglet se place à droite de Notes.

### Éléments supplémentaires du menu principal

Le menu principal comprend une entrée **Assistant IA** dans les mêmes conditions.

## Le Menu rapide

Le Mode Érudit active le **Menu rapide**, un moyen rapide d'accéder aux versets récents, d'exécuter des commandes et de changer de mise en page biblique sans quitter l'écran actuel. Consultez le guide [Menu rapide](theodia://help/launcher-menu) pour savoir comment l'utiliser.

## Quand utiliser le Mode Érudit

- Vous souhaitez l'assistant IA, les commentaires ou les recherches en langues originales pendant la lecture.
- Vous souhaitez le Menu rapide pour une navigation rapide entre les versets et les discussions avec l'IA.
- Vous étudiez un passage en profondeur et avez besoin de tous les outils à portée d'un appui.

## Passer à un mode plus léger

Si vous souhaitez un lecteur plus simple sans les outils avancés, passez au mode **Standard** dans **Paramètres** → **Mode utilisateur de l'app**. Le mode Standard conserve les signets, les surlignages, les notes et le Mode Étude, mais masque l'IA, les commentaires, les lexiques et le Menu rapide.

Si vous souhaitez l'expérience de lecture la plus épurée possible, ouvrez un chapitre en [Mode Concentration](theodia://help/focus-mode).

Vos signets, surlignages et notes ne sont jamais supprimés lorsque vous changez de mode ; ils sont simplement masqués jusqu'à ce que vous reveniez à un mode qui les prend en charge.

## Aide et questions

Si un outil manque ou affiche une erreur, consultez le guide [Problèmes courants](theodia://help/common-problems). Si vous débutez avec Theodia, le guide [Lire votre premier chapitre](theodia://help/first-read) vous guide pas à pas dans les bases.
