---
title: Rechercher dans la Bible
level: everyday
categories: [study, read]
summary: Comment trouver des versets par mot, phrase ou référence.
---

# Rechercher dans la Bible

La barre de recherche vous aide à trouver des versets rapidement. Vous pouvez chercher par mot, phrase ou référence biblique.

## Comment lancer une recherche

1. Appuyez sur l'onglet **Recherche** en bas de l'écran.
2. Saisissez ce que vous souhaitez trouver.
3. Appuyez sur **Rechercher** sur le clavier.

Les résultats apparaissent sous forme de liste de versets. Chaque résultat affiche le livre, le chapitre, le verset et le texte du verset.

## Rechercher par combinaison de mots

Lorsque vous saisissez plusieurs mots, comme `amour joie`, l'application trouve les versets qui contiennent **les deux** mots. Il s'agit d'une recherche **ET** — tous les mots doivent apparaître dans le verset. Elle n'utilise **pas** la logique **OU** (versets contenant n'importe lequel des mots).

Pour rechercher des versets contenant l'un ou l'autre mot, vous devez utiliser le mot-clé `OR` explicitement : `amour OR joie`.

## Rechercher par mot

Saisissez un seul mot, comme `amour` ou `miséricorde`. L'application affiche chaque verset de la Bible contenant ce mot.

## Rechercher par phrase

Saisissez deux ou trois mots entre guillemets, comme `"n'aie pas de crainte"`. L'application affiche les versets contenant cette phrase exacte.

## Filtrer les résultats

Après une recherche, les résultats sont filtrés selon les traductions bibliques que vous avez installées. Pour affiner davantage, ouvrez l'onglet **Bible** et consultez une traduction spécifique — les recherches portent sur les traductions que vous possédez.

## Astuces pour de meilleures recherches

- Utilisez des mots courts. Une recherche pour `amour` trouve plus de versets qu'une recherche pour `aimer`.
- Les guillemets autour d'une phrase rendent la recherche exacte.
- L'application ne recherche que dans les traductions bibliques que vous avez installées.
- Pour accéder directement à un verset par sa référence (par exemple `Jean 3:16`), utilisez la zone **Commande rapide** de l'écran d'accueil plutôt que l'onglet Recherche.

## Historique de recherche

L'application mémorise vos recherches les plus récentes. Lorsque vous ouvrez l'onglet **Recherche**, la liste affiche vos recherches récentes en haut. Appuyez sur l'une d'elles pour la relancer. Pour effacer la liste, appuyez sur **Tout effacer** en haut des recherches récentes.
