---
title: Mode Étude
level: everyday
categories: [layout, read]
summary: Le lecteur biblique complet de Theodia, avec outils d'étude intégrés comme les commentaires, les références croisées, le lexique et les notes.
---

# Mode Étude

> **Mode :** le Mode Étude est disponible en mode **Standard** et **Érudit**. Le mode Lecture ouvre les chapitres en Mode Concentration. Vous pouvez changer de mode dans **Paramètres** → **Mode utilisateur de l'app**.

Le Mode Étude est le lecteur biblique principal de Theodia. Il intègre tous les outils d'étude : commentaires, références croisées, définitions de mots, traductions parallèles, notes, et plus encore.

Le Mode Concentration est un lecteur plus simple sans outils d'étude. Consultez le guide [Mode Concentration](theodia://help/focus-mode) si vous souhaitez uniquement un texte épuré. Ce guide concerne le Mode Étude.

## Comment ouvrir le Mode Étude

Il y a plusieurs façons d'ouvrir un chapitre en Mode Étude :

- Appuyez sur l'onglet **Bible** en bas de l'écran. Choisissez une traduction, un livre et un chapitre.
- Appuyez sur un verset dans les résultats de **Recherche**.
- Appuyez sur un signet depuis l'onglet **Signets**.
- En Mode Concentration, appuyez sur le bouton 📖 en haut de l'écran pour passer en Mode Étude.

## Lire le chapitre

Le chapitre s'ouvre avec les versets dans l'ordre. En haut de l'écran se trouvent les boutons des actions les plus courantes. En bas de l'écran se trouve une barre d'état.

- **Glissez vers la gauche** pour passer au chapitre suivant.
- **Glissez vers la droite** pour revenir au chapitre précédent.
- **Appuyez sur un verset** pour ouvrir le menu du verset avec les outils d'étude (voir ci-dessous).
- **Appuyez sur un numéro de Strong dans un verset** (par exemple G1234 ou H1234) pour afficher rapidement l'entrée du lexique de ce mot.

Si vous avez activé une traduction parallèle, une seconde copie du chapitre apparaît sous la première, dans la traduction choisie. Voir **Lire deux traductions à la fois** ci-dessous.

## Le menu du verset

Lorsque vous appuyez sur un verset, un menu s'ouvre avec le titre « Livre Chapitre:Verset ». Les outils affichés dépendent de votre mode utilisateur.

### Outils en mode Standard et Érudit

- **Signet** (★) — enregistre le verset pour le retrouver plus tard. Appuyez à nouveau pour supprimer le signet. Le premier appui l'ajoute. Consultez le guide [Signets](theodia://help/bookmarks).
- **Surligner** (□) — colore le verset pour le faire ressortir. Appuyez pour ouvrir le sélecteur de couleur. Appuyez sur la même couleur pour retirer le surlignage. Consultez le guide [Surlignages](theodia://help/highlights).
- **Lire** (🔊) — fait lire le verset à voix haute avec la voix de synthèse vocale de votre appareil. Cet outil n'est pas affiché pour les Bibles interlinéaires. Consultez le guide [Lecture à haute voix](theodia://help/tts) pour savoir comment l'utiliser et choisir une voix.
- **Copier** (⎘) — copie le texte du verset dans le presse-papiers pour le coller ailleurs.
- **Comparer** (⇄) — ouvre un panneau affichant le même verset dans chaque traduction installée. Appuyez sur une traduction dans le panneau pour lire le verset dans cette traduction. Consultez le guide [Comparer les traductions](theodia://help/compare-translations).
- **Références croisées** (↗) — ouvre une liste de versets liés à partir de la base de données de références croisées. Consultez le guide [Références croisées](theodia://help/cross-references).
- **Ajouter/Modifier une note biblique** (✎) — écrivez votre propre note privée attachée au verset. Consultez le guide [Notes](theodia://help/notes).

### Outils en mode Érudit uniquement

- **Commentaire IA** (◈) — demandez à l'assistant IA de rédiger une note d'étude pour ce verset. (Non disponible dans toutes les régions.)
- **Info mot** (?) — ouvre une entrée du lexique pour le mot hébreu ou grec original derrière le verset. Consultez le guide [Commentaires et lexiques](theodia://help/commentaries-and-lexicons).
- **Dictionnaire** (📖) — recherchez des mots bibliques généraux dans les dictionnaires que vous avez installés. Consultez le guide [Dictionnaire biblique](theodia://help/dictionary).

Certains outils nécessitent l'installation de ressources supplémentaires. Si un outil est grisé ou affiche « introuvable », ouvrez **Paramètres** → **Gérer les ressources** et ajoutez la ressource nécessaire.

## Boutons en haut de l'écran

Au-dessus du texte du chapitre se trouve une rangée d'icônes. Ce sont les actions rapides :

- **Version biblique** — appuyez sur le nom de la traduction (par exemple « KJV ») pour changer de traduction.
- **Livre** — appuyez sur le nom du livre pour aller à un autre livre.
- **Chapitre** — appuyez sur le numéro du chapitre pour aller à un autre chapitre.
- **Ouvrir dans l'IA** (🤖) — envoie le chapitre actuel à l'assistant IA avec votre question. (Mode Érudit uniquement.)
- **Mode Concentration** (📖) — passe au Mode Concentration pour une lecture épurée.
- **Bibles parallèles** (🔵 / ⚪) — appuyez pour activer ou désactiver les traductions parallèles. Lorsqu'elles sont activées, le même chapitre est affiché dans les traductions parallèles choisies sous le texte principal. Lorsqu'elles sont désactivées, seule la traduction principale est affichée. Voir **Lire plusieurs traductions à la fois** ci-dessous.
- **Lire à haute voix** — fait lire l'ensemble du chapitre à voix haute. Consultez le guide [Lecture à haute voix](theodia://help/tts).
- **Plus** — ouvre des actions supplémentaires pour le chapitre (note de chapitre, commentaire de chapitre, partager, etc.).

## Lire plusieurs traductions à la fois

Vous pouvez afficher jusqu'à quatre traductions supplémentaires à côté de la principale. Cela s'appelle la **vue parallèle**.

1. Ouvrez **Paramètres**.
2. Activez **Bible parallèle**.
3. Appuyez sur **Ajouter une bible parallèle** et choisissez une traduction.
4. Répétez pour en ajouter d'autres. Vous pouvez avoir jusqu'à quatre traductions parallèles.

Lorsque la vue parallèle est active, chaque verset du chapitre affiche d'abord votre traduction principale, puis le même verset dans chaque traduction parallèle. Cela facilite la comparaison des choix des traducteurs pour un verset difficile sans quitter le chapitre.

Vous pouvez enregistrer votre configuration parallèle actuelle comme un **préréglage**. Appuyez sur le bouton d'enregistrement à côté de vos traductions sélectionnées, donnez-lui un nom, et il devient une option de basculement rapide. Appuyez sur n'importe quel préréglage plus tard pour charger instantanément cette combinaison. Appuyez longuement sur un préréglage pour le supprimer.

Vous pouvez aussi comparer un seul verset à la fois avec l'outil **Comparer** (⇄) du menu du verset. Cela ouvre un panneau affichant le verset dans toutes les traductions installées.

## Titres de section

Certaines traductions incluent des titres de section (par exemple, « Le Sermon sur la montagne »). Si votre traduction les propose, vous pouvez les afficher ou les masquer avec le réglage **Afficher les titres des sections** dans **Paramètres**. Les titres apparaissent comme de petits titres gris entre les versets.

## La note de chapitre

Une note de chapitre est une seule note attachée à l'ensemble du chapitre, et non à un verset particulier. Elle est utile pour une grande idée sur le chapitre.

Pour ouvrir la note de chapitre :

1. Appuyez sur le bouton **Plus** en haut de l'écran.
2. Appuyez sur **Note de chapitre**.
3. Écrivez votre note. Appuyez sur **Enregistrer**.

La note de chapitre est enregistrée avec le chapitre. Elle apparaît chaque fois que vous ouvrez ce chapitre.

## Mises en surbrillance de la recherche

Si vous arrivez au chapitre depuis une recherche, vos mots recherchés sont surlignés en jaune dans le texte du verset. Cela permet de voir facilement pourquoi un verset correspond.

Vous pouvez aussi relancer une recherche sur un chapitre que vous lisez. Ouvrez l'onglet **Recherche** et saisissez un mot. Les résultats vous permettent de revenir directement au chapitre avec les correspondances surlignées.

Les Bibles interlinéaires (MIB — Marvel Interlinear Bible — et OHGB) s'ouvrent toujours en Mode Étude car elles nécessitent une mise en page au niveau du mot.

## Passer au Mode Concentration pour un seul chapitre

Depuis n'importe quel chapitre en Mode Étude, appuyez sur le bouton 📖 en haut. Le même chapitre s'ouvre en Mode Concentration avec tous les menus masqués. Appuyez sur le bouton 📖 dans la barre du bas pour revenir au Mode Étude.

## Quand utiliser le Mode Étude

Le Mode Étude est le bon choix quand vous voulez :

- **Lire et étudier en même temps.** Tous les outils sont à portée d'un appui.
- **Chercher la signification d'un mot.** Appuyez sur un numéro de Strong dans le verset pour une entrée de lexique rapide.
- **Comparer des traductions.** Utilisez l'outil Comparer du menu du verset ou activez la vue parallèle.
- **Voir comment un verset se connecte au reste de la Bible.** Utilisez les Références croisées.
- **Prendre des notes en lisant.** Le menu du verset a une option rapide « Ajouter une note ».

Pour une longue lecture sans distractions, passez au Mode Concentration.

## Passer au Mode Concentration

Depuis n'importe quel chapitre en Mode Étude, appuyez sur le bouton 📖 en haut. Le même chapitre s'ouvre en [Mode Concentration](theodia://help/focus-mode) avec les menus et outils d'étude masqués. Appuyez sur le bouton 📖 dans la barre du bas pour revenir au Mode Étude. Pour une description complète du Mode Concentration, consultez le guide [Mode Concentration](theodia://help/focus-mode).

## Aide et questions

Si un outil manque ou affiche une erreur, consultez le guide [Problèmes courants](theodia://help/common-problems). Si vous débutez avec Theodia, le guide [Lire votre premier chapitre](theodia://help/first-read) vous guide pas à pas dans les bases.
