---
title: Fonctionnalités tablette
level: everyday
categories: [layout, tablet]
summary: Comment la mise en page de Theodia s'adapte aux tablettes et grands écrans, avec vues partagées, panneaux latéraux et modes de lecture en deux volets.
---

# 📱 Fonctionnalités tablette

Theodia est conçu pour tirer parti des grands écrans des tablettes. Sur une tablette (ou tout appareil d'une largeur supérieure à environ 700 pixels), l'application passe automatiquement à une mise en page à deux colonnes dans de nombreux endroits.

> **Mode :** les fonctionnalités décrites ici n'apparaissent que si votre mode utilisateur actuel les prend en charge. Par exemple, les panneaux latéraux de commentaire et la discussion IA ne sont disponibles qu'en mode Érudit. Les vues partagées des signets, surlignages et notes nécessitent le mode Standard ou Érudit. Le Mode Concentration affiche uniquement une lecture simple en une colonne. Vous pouvez changer de mode dans **Paramètres** → **Mode utilisateur de l'app**.

## Menu du verset du lecteur

Lorsque vous appuyez sur un numéro de verset (ou appuyez longuement sur le texte du verset), le **menu du verset** apparaît comme une **carte centrée** sur un fond sombre.

- Les boutons **Copier** et **Partager** sont toujours visibles en haut du menu.
- Les **Signets** et **Surlignages** sont affichés avec leur état actuel.
- **Commentaire**, **Dictionnaire** et **Comparer** s'ouvrent depuis le menu. Sur une tablette, ces outils peuvent apparaître dans un panneau latéral ou une carte large une fois sélectionnés.
- Appuyez sur le fond sombre ou sur la flèche de fermeture pour fermer le menu.

## Panneau de commentaire du verset

L'outil **Commentaire** ouvre un **panneau latéral dédié** sur une tablette :

- Le texte du commentaire apparaît à côté du texte biblique.
- Vous pouvez faire défiler le commentaire indépendamment de la Bible.
- Appuyez sur le **X** ou faites glisser pour fermer.
- Une **icône de livre** en haut du panneau permet de changer de source de commentaire.
- Une **icône de chapitre** permet d'afficher le commentaire au niveau du chapitre.

Sur un téléphone, le commentaire s'ouvre en mode plein écran.

## Commentaire de chapitre

Le **Commentaire de chapitre** est accessible depuis le bouton **Plus** en haut de l'écran, et non depuis le menu du verset. Sur une tablette, il s'ouvre comme un panneau latéral, comme le Commentaire du verset, pour que vous puissiez lire le commentaire et le texte biblique ensemble.

## Onglet Comparer

L'onglet **Comparer** (dans le menu du verset) s'ouvre comme un **panneau latéral** sur une tablette. Il affiche le verset sélectionné dans chaque version parallèle activée. Vous pouvez appuyer sur n'importe quelle version pour accéder au passage dans le lecteur.

## Popup Dictionnaire / Strong

L'outil **Dictionnaire** (menu du verset → Dictionnaire) s'ouvre comme une carte large sur une tablette. Il affiche le mot grec ou hébreu, sa translittération, sa définition et son numéro de Strong. Appuyez sur le bouton **Concordance** pour voir chaque occurrence de ce mot dans la Bible.

## Appuyer sur un mot pour ouvrir son Lexique

Dans le panneau **Info mot** sur une tablette, chaque carte de mot possédant un numéro de Strong est tactile. Appuyez sur la carte pour ouvrir directement le panneau **Lexique** de ce mot. Le panneau Lexique remplace le panneau Info mot pour que vous puissiez continuer à étudier sans fermer le lecteur.

Sur un téléphone, les cartes Info mot ne sont pas tactiles car l'écran est trop petit pour deux panneaux.

## Bibles parallèles côte à côte

Dans les Paramètres, appuyez sur **Bibles parallèles** et choisissez jusqu'à trois versions. Sur une tablette, les versions apparaissent comme **volets verticaux** les uns à côté des autres :

- Chaque volet défile indépendamment.
- Vous pouvez appuyer sur un numéro de verset pour ouvrir un panneau latéral avec les outils.
- L'onglet **Comparer** affiche tous les versets sélectionnés au même endroit.
- Appuyez sur le **X** d'un volet pour le fermer et revenir à une vue en colonne unique.
- Appuyez sur l'icône **Bibles parallèles** (🔵 / ⚪) dans la barre d'icônes du haut pour activer ou désactiver la vue parallèle sans ouvrir les Paramètres.

Sur un téléphone, les versions parallèles s'affichent les unes sous les autres (verticalement) plutôt que côte à côte. La même icône de bascule fonctionne aussi sur les téléphones.

## Vue partagée des signets et surlignages

Sur une tablette, les onglets **Signets** et **Surlignages** utilisent une mise en page maître-détail :

- **Côté gauche** — la liste des signets ou des surlignages.
- **Côté droit** — appuyer sur un élément ouvre un volet d'aperçu avec le texte du verset ou du passage.

Vous pouvez parcourir vos éléments sauvegardés et les prévisualiser sans quitter l'onglet. Sur un téléphone, appuyer sur un élément vous amène à l'écran du lecteur.

## Vue partagée des notes

L'onglet **Notes** sur une tablette affiche votre liste de notes à gauche et la note sélectionnée à droite. Appuyer sur une note l'ouvre dans un panneau latéral pour que vous puissiez parcourir plusieurs notes de suite sans quitter la liste. La création ou la modification d'une note utilise aussi un panneau latéral.

## Vue partagée de la recherche

Sur une tablette, l'onglet **Recherche** affiche le formulaire de recherche à gauche et les résultats à droite dès que vous lancez une recherche. Vous pouvez affiner votre requête et voir les résultats se mettre à jour sans changer d'écran. Sur un téléphone, les résultats de recherche s'ouvrent sur un écran séparé.

## Barre latérale des catégories des Paramètres

L'écran **Paramètres** sur une tablette affiche une liste de catégories à gauche (IA, Apparence, Sauvegarde, Bible, etc.). Appuyez sur une catégorie pour accéder directement à ses réglages à droite. Seule la catégorie sélectionnée est déployée, vous n'avez donc pas besoin de faire défiler toute la liste des paramètres.

## Navigation biblique sur tablette

Les écrans **Liste des Bibles**, **Livres bibliques** et **Chapitres bibliques** restent en une seule colonne sur les tablettes, mais ils utilisent des cibles tactiles plus grandes, des grilles plus larges et des espacements plus généreux pour que le contenu soit plus facile à lire et à toucher. Ils n'utilisent pas de mise en page partagée car chaque étape a besoin de toute la largeur pour afficher clairement sa liste ou sa grille.

## Paysage et portrait

La rotation de la tablette ajuste automatiquement la mise en page. En **paysage**, les panneaux latéraux disposent de beaucoup d'espace. En **portrait**, les panneaux deviennent plus étroits mais restent à côté du texte.

## Discussion IA du verset sélectionné

La discussion **IA** s'ouvre dans le panneau latéral du menu du verset. Elle affiche une interface de conversation où vous pouvez poser des questions sur le verset sélectionné. La réponse de l'IA apparaît dans le panneau, et vous pouvez continuer la conversation sans quitter le lecteur.

## Barre latérale des conversations dans l'écran IA

Dans l'onglet **IA** sur une tablette, la liste des conversations est toujours visible comme une barre latérale gauche permanente. Vous pouvez basculer entre les discussions sans ouvrir de menu. Le bouton **Nouvelle discussion** est également toujours visible. Sur un téléphone, la liste des conversations est un tiroir contextuel.

## Ce qui reste identique

Tous les écrans ne se divisent pas en deux volets. Les écrans suivants restent en une seule colonne sur les tablettes :

- **Liste des Bibles** — liste des versions bibliques (pleine largeur)
- **Livres bibliques** — grille des livres et sections (pleine largeur)
- **Chapitres bibliques** — grille des chapitres (pleine largeur)
- **PDF** — la bibliothèque de PDF utilise une grille de cartes plus large (pleine largeur)
- **Paramètres** — pages de paramètres individuelles (pleine largeur)
- **Aide** — articles d'aide (pleine largeur)

## Résumé

Sur une tablette, vous bénéficiez de :

- **Bibles parallèles** dans des volets verticaux côte à côte
- **Commentaire** dans des panneaux latéraux persistants
- **Comparer** et **Dictionnaire** dans des cartes larges
- **Lexique** d'un appui sur n'importe quelle carte Info mot
- **Signets, Surlignages, Notes, Dévotionnels, Livres, Paramètres** dans des vues maître-détail
- **Recherche** avec des résultats en ligne à côté du formulaire
- **Paysage** et **portrait** pris en charge avec des ajustements automatiques

Sur un téléphone, tout utilise la navigation traditionnelle en colonne unique par enchaînement d'écrans. L'application détecte la largeur de l'écran au lancement et choisit automatiquement la bonne mise en page.
