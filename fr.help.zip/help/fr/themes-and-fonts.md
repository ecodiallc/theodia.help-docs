---
title: Changer de thème et de police
level: everyday
categories: settings
summary: Comment modifier l'apparence de l'application.
---

# Changer de thème et de police

Theodia vous permet de modifier l'apparence de l'application. Vous pouvez choisir un thème (clair ou sombre) et une taille de police.

## Comment ouvrir les paramètres d'apparence

1. Ouvrez **Paramètres**.
2. Appuyez sur **Apparence**.

## Comment changer de thème

Dans la section **Apparence**, vous voyez deux boutons de thème :

- **Par défaut** — un fond clair avec du texte foncé. Idéal pour la journée.
- **Sombre** — un fond sombre avec du texte clair. Idéal pour la nuit et économise la batterie.

Appuyez sur un thème pour l'appliquer. Le changement est instantané.

## Comment changer la taille de la police

Dans la section **Apparence**, appuyez sur l'un des boutons de taille : **---**, **--**, **-**, **Normal**, **+**, **++**, **+++**. Le texte devient plus petit ou plus grand dans toute l'application. Choisissez la taille qui vous est le plus confortable.

## Astuces

- Le thème sombre économise la batterie sur les téléphones dotés d'écrans OLED.
- Si le texte est trop petit pour être lu, augmentez la taille de la police dans l'application plutôt que sur l'appareil. Le réglage de l'application est plus fin.
- Pour de longues lectures, essayez le thème sombre avec une police plus grande.
- [Activez le thème désert](theodia://unlock-desert)
