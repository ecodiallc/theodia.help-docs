---
title: Fonctionnalités de Theodia
level: beginner
categories: welcome
summary: Un aperçu rapide de ce qui rend Theodia spécial et comment il aide à étudier la Bible.
---

# Fonctionnalités de Theodia

Theodia est conçu comme un compagnon complet d'étude biblique. Voici ce qui le distingue.

## Hors ligne d'abord

Tout fonctionne sans internet. Les Bibles, commentaires, lexiques, livres et dévotionnels sont stockés sur votre appareil. Vous pouvez lire, rechercher et étudier n'importe où — dans un avion, dans une région éloignée, ou là où il n'y a pas de signal.

## Respectueux de la vie privée

Vos données restent avec vous. Les notes, surlignages, signets et historique de lecture sont stockés localement sur votre appareil. Aucun compte n'est nécessaire, et rien n'est envoyé à un serveur, sauf si vous choisissez d'utiliser l'assistant IA facultatif.

## Prise en charge des tablettes

Theodia est conçu pour les téléphones et les tablettes. Sur un grand écran, vous disposez de plus d'espace pour la lecture, de vues de Bible parallèle et d'une mise en page qui profite de l'espace supplémentaire.

## Ressources installables

Vous n'êtes pas limité à ce qui est fourni avec l'application. Vous pouvez ajouter d'autres versions bibliques, des commentaires, des lexiques, des livres et des dévotionnels. Les ressources sont disponibles sur la page GitHub du projet et peuvent être installées directement dans l'application.

## Assistant IA

L'assistant IA facultatif vous aide à comprendre les versets, explique le contexte et répond aux questions. Il n'est actif que si vous l'activez. Par défaut, il se connecte à un modèle distant que vous fournissez via un point de terminaison et une clé API que vous configurez. La première fois que vous utilisez l'IA, l'application demande votre permission et indique exactement ce qui est envoyé.

## Lecture biblique parallèle

Lisez jusqu'à quatre versions bibliques à la fois. Lorsque vous ouvrez un chapitre, votre traduction principale apparaît en premier, et chaque verset est suivi du même verset dans les traductions parallèles choisies. Comparez les formulations, étudiez les différences et obtenez une image plus complète du texte. Enregistrez vos combinaisons préférées sous forme de préréglages et basculez rapidement entre elles.

## Recherche en texte intégral

Recherchez dans n'importe quelle version biblique. Cherchez des mots, des phrases ou des correspondances partielles. Vous pouvez aussi limiter la recherche à une plage de livres.

## Références croisées

Appuyez sur une référence de verset pour accéder directement au passage. Les références croisées sont intégrées et fonctionnent dans toute la Bible.

## Lexique et numéros de Strong

Appuyez sur un numéro de Strong pour voir la définition grecque ou hébraïque originale. Les entrées du lexique sont incluses pour une étude approfondie des mots.

## Signets et surlignages

Enregistrez des versets avec des signets et marquez-les avec des couleurs. Tout est stocké localement et persiste entre les sessions.

## Notes

Écrivez vos propres réflexions à côté de n'importe quel verset. Les notes sont liées au verset et faciles à retrouver plus tard.

## Dévotionnel quotidien

Commencez votre journée avec une courte lecture de dévotionnel. L'application inclut des dévotionnels qui s'ouvrent automatiquement à l'entrée du jour.

## Livres chrétiens

Lisez des classiques de la littérature chrétienne dans l'application. Les livres sont mis en forme pour une lecture facile et incluent une table des matières pour une navigation rapide.

## Langues multiples

Theodia prend en charge de nombreuses langues pour l'interface de l'application et le contenu biblique. Changez de langue dans les paramètres pour étudier dans la langue de votre choix.

## Mode sombre et thèmes

Choisissez entre le mode clair ou sombre, ou sélectionnez un thème qui vous convient. Le confort de lecture compte, surtout dans la pénombre.

## Sauvegarde des données

Sauvegardez vos notes, signets et surlignages. Protégez vos données et transférez-les vers un nouvel appareil si nécessaire.

## Pas de publicité, pas de distractions

Theodia est conçu pour la concentration. Il n'y a pas de publicités, pas de fenêtres contextuelles et pas d'interruptions. Juste le texte et vos outils d'étude.
