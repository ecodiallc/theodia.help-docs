---
title: Theoscripts
level: everyday
categories: theoscript
summary: Automatisez la lecture biblique, la synthèse vocale, les signets, et bien plus avec de simples commandes Theoscript.
---

# Theoscripts

Les **Theoscripts** sont de petits scripts qui automatisent des actions dans Theodia. Un script peut lire un passage à voix haute, ouvrir un chapitre, créer un signet, afficher un message, exécuter une autre commande, et bien plus. C'est un moyen rapide de créer des raccourcis personnels ou de petits assistants dévotionnels sans quitter l'application.

## Où vivent les Theoscripts

Ouvrez **Theoscripts** depuis l'écran d'accueil ou le menu principal. L'écran n'apparaît que lorsqu'au moins un Theoscript existe.

La bibliothèque affiche :

- **Scripts** — chaque script que vous avez créé ou importé.
- **Catégories** — dossiers optionnels qui regroupent les scripts liés.

Appuyez sur un script pour l'exécuter. Appuyez longuement sur un script pour le modifier, le dupliquer ou le supprimer.

## Créer un nouveau script

1. Allez dans **Theoscripts**.
2. Appuyez sur **Ajouter un script**.
3. Donnez un nom au script.
4. Saisissez les commandes dans le champ **Contenu du script**.
5. Appuyez sur **Enregistrer**.

Chaque commande va sur sa propre ligne. Indentez les lignes à l'intérieur d'un bloc avec deux espaces.

## Commandes courantes

| Commande | Ce qu'elle fait | Exemple |
| --- | --- | --- |
| `speak` | Lit un texte ou un passage à voix haute | `speak "Good morning"` ou `speak John 3:16` |
| `open`, `read`, `show` | Ouvre un passage dans le lecteur | `open Psalm 23` |
| `bookmark` | Enregistre le passage actuel dans les signets | `bookmark` |
| `highlight` | Surligne le verset actuel | `highlight yellow` |
| `message` | Affiche un message contextuel | `message "Done reading"` |
| `set` | Change un paramètre ou une valeur | `set theme dark` |
| `return` | Arrête le script plus tôt | `return` |
| `with playlist` | Ajoute des pistes à une playlist | `with playlist "Morning" track John 3:16 end` |
| `start playlist` | Joue une playlist | `start playlist "Morning"` |
| `with note` | Crée une note | `with note "John 3:16" "My thoughts" end` |

## Contrôle de flux

Utilisez `if` pour exécuter des commandes uniquement si une condition est vraie :

```text
if chapter == 1 {
  message "Starting a new book!"
}
```

Utilisez `repeat` pour répéter un bloc de commandes :

```text
repeat 3 {
  speak "Peace be with you"
}
```

Utilisez `for` pour parcourir une liste :

```text
for $ref in ["John 3:16", "Psalm 23:1", "Romans 8:28"] {
  open $ref
  speak $ref
}
```

Utilisez `function` et `call` pour réutiliser des blocs de code :

```text
function greet $name {
  message "Hello, " + $name
}
call greet "friend"
```

## Variables

Stockez une valeur dans une variable avec `let` :

```text
let $name = "Theophilus"
message "Welcome, " + $name
```

Les chaînes littérales à droite du signe égal doivent être entourées de guillemets simples ou doubles. Cela évite de confondre une valeur littérale avec une commande ou un nom de variable. Les nombres, les variables et les expressions de commande n'ont pas besoin de guillemets :

```text
let $count = 42
let $text = $last.passageText
let $words = count words in $text
let $greeting = "Hello, " + $name
```

Les variables sont utiles à l'intérieur des boucles, des fonctions et des définitions de playlist.

## Exemples de scripts

### Salutation et un verset

```text
speak "Good morning. Here is your verse for today."
open John 3:16
speak John 3:16
```

### Trois versets favoris en signets

```text
open John 3:16
bookmark
open Psalm 23:1
bookmark
open Romans 8:28
bookmark
message "Favorites saved."
```

### Construire une playlist parlée

```text
with playlist "Commute" {
  track John 3:16
  track Psalm 23
  track Romans 8:28
}
start playlist "Commute"
```

### Message conditionnel

```text
open Genesis 1:1
if book == "Genesis" {
  message "In the beginning..."
}
```

## Organiser les scripts

Appuyez sur **Gérer les catégories** pour créer des catégories. Lorsque vous modifiez un script, choisissez la catégorie souhaitée. Les catégories aident à séparer les scripts personnels, les exemples et les scripts de synthèse vocale.

## Exporter et importer

Appuyez sur le menu dans la bibliothèque Theoscript pour :

- **Exporter les Theoscripts** — enregistrer tous les scripts dans un fichier.
- **Exporter cette catégorie** — enregistrer uniquement la catégorie sélectionnée.
- **Importer des Theoscripts** — charger un fichier précédemment exporté.

Les fichiers exportés sont en texte brut et peuvent être partagés avec d'autres utilisateurs de Theodia.

## Exécuter des scripts depuis les Commandes

Les Theoscripts peuvent aussi être exécutés par nom depuis le **Menu rapide** ou en les demandant via les Commandes. Par exemple, dire ou taper `run My Morning Script` trouvera et exécutera le script nommé _My Morning Script_ s'il existe.

## Dépannage

- **Rien ne se passe quand j'appuie sur Exécuter.** Vérifiez que le contenu du script n'est pas vide et que chaque commande est orthographiée correctement.
- **Speak ne lit rien.** Assurez-vous qu'un passage est ouvert, ou passez directement du texte entre guillemets à `speak`.
- **Une commande est surlignée avec une erreur.** Les Theoscripts affichent des erreurs lorsqu'une commande est inconnue ou qu'une référence est invalide. Modifiez le script et réessayez.
