---
title: Lecture à haute voix (synthèse vocale)
level: everyday
categories: tts
summary: Faites lire la Bible ou un dévotionnel à voix haute par Theodia. Comment l'utiliser, choisir une voix, et que faire en cas de silence.
---

# Lecture à haute voix (synthèse vocale)

> **Mode :** la synthèse vocale est disponible en mode **Standard** et **Érudit**. Le Mode Concentration est réservé à une lecture propre et sans distraction. Vous pouvez changer de mode dans **Paramètres** → **Mode utilisateur de l'app**.

Theodia peut lire du texte à voix haute à l'aide de la voix de synthèse vocale (TTS) de votre appareil. Vous pouvez écouter un seul verset, un chapitre entier ou un dévotionnel. C'est utile pour lire les mains libres, écouter en marchant ou en vous déplaçant, suivre le texte avec l'audio, ou simplement reposer vos yeux.

## Où se trouve le bouton de lecture

Vous trouverez un bouton de lecture à trois endroits.

### 1. Dans le menu du verset (un seul verset)

C'est le moyen le plus rapide d'écouter un verset à la fois. Ouvrez un chapitre en [Mode Étude](theodia://help/study-mode), appuyez sur un verset pour ouvrir le menu du verset, puis appuyez sur **Lire** (🔊). La lecture commence à ce verset. Une petite barre de contrôle apparaît en bas de l'écran avec lecture, pause, retour, avance rapide et un sélecteur de voix.

L'option **Lire** n'est pas affichée pour les Bibles interlinéaires (MIB — Marvel Interlinear Bible — et OHGB), car elles affichent les mots dans une mise en page qui ne se lit pas naturellement.

### 2. En haut d'un chapitre (chapitre entier)

Lorsque vous lisez un chapitre, regardez la rangée d'icônes en haut de l'écran. Appuyez sur **Lire à haute voix** (🔊) pour commencer la lecture du chapitre entier depuis le début. Le bouton devient un bouton d'arrêt (⏹) pendant la lecture audio. Appuyez à nouveau pour arrêter. La même barre de contrôle apparaît en bas.

Vous pouvez aller à un verset différent, et le bouton de lecture de ce verset démarrera à partir de celui-ci.

### 3. Dans un dévotionnel

Ouvrez n'importe quel jour d'un dévotionnel, puis appuyez sur le bouton **Lire à haute voix** (🔊) en haut de la lecture. Le texte complet du dévotionnel est lu à voix haute, phrase par phrase. Une barre de contrôle en bas offre les commandes de lecture, pause, retour et de choix de voix.

## Utiliser la barre de contrôle

Pendant la lecture audio, une petite barre reste visible en bas de l'écran. Elle comporte six commandes :

- ⏪ **Retour** — reculer d'un verset (ou d'une phrase dans un dévotionnel)
- ⏸ **Pause / ▶ Reprendre** — mettre en pause sans perdre votre position. Appuyez à nouveau pour reprendre au même endroit.
- ⏩ **Avance rapide** — passer au verset suivant (ou à la phrase suivante dans un dévotionnel)
- 🎙 **Voix** — ouvrir le sélecteur de voix sans quitter le chapitre (voir ci-dessous)
- ⚙ **Options** — ouvrir le panneau d'options étendues (voir ci-dessous)
- **Arrêter** — appuyez sur le bouton 🔊 en haut de l'écran, ou sur le ⏹ qui le remplace pendant la lecture, pour arrêter et fermer la barre.

La barre de contrôle se ferme lorsque le chapitre se termine ou lorsque vous appuyez sur arrêter.

### Options étendues

Appuyez sur ⚙ pour développer des options de lecture supplémentaires. Ces réglages ne durent que pour le chapitre en cours et se réinitialisent lorsque vous changez de chapitre ou arrêtez l'écoute.

- ⏮ **Retour au début** — sauter au premier verset de la plage définie.
- **Début** — saisissez un numéro de verset pour définir où commence la lecture.
- **Fin** — saisissez un numéro de verset pour définir où s'arrête la lecture.
- **Tout** — réinitialiser la plage au chapitre entier.
- **()** — basculer la lecture à voix haute du texte entre parenthèses.
- 🔁 **Répéter** — redémarrer automatiquement au début de la plage lorsque la fin est atteinte, avec une courte pause entre les deux. Si vous activez cette option sans définir de verset de début ou de fin, le chapitre entier se répète.

## Comment changer de voix

Vous pouvez choisir la voix que Theodia utilise pour la lecture. C'est utile si vous voulez un accent différent, une autre langue, ou une voix plus rapide ou plus lente que la voix par défaut de l'appareil.

1. Ouvrez **Paramètres**.
2. Trouvez la section **Synthèse vocale**.
3. Appuyez sur **Sélectionner la voix**.
4. Une liste de voix apparaît. La première ligne, **Voix par défaut**, utilise la voix préférée par votre appareil. Choisissez n'importe quelle autre ligne pour en faire la nouvelle voix par défaut.
5. Votre choix est enregistré et utilisé la prochaine fois que vous appuyez sur **Lire à haute voix** ou **Lire**.

Vous pouvez aussi appuyer sur l'icône 🎙 dans la barre de contrôle de lecture pour ouvrir le même sélecteur sans quitter le chapitre.

La disponibilité des voix dépend entièrement de votre appareil. iOS et Android fournissent chacun un ensemble de voix intégrées. Vous pouvez installer d'autres voix depuis les paramètres **Accessibilité** ou **Langue et saisie** de votre appareil. Theodia peut utiliser n'importe quelle voix installée sur votre appareil.

## Voix favorites

Si votre appareil dispose de nombreuses voix, faire défiler la liste complète à chaque fois peut être lent. Vous pouvez créer une courte liste de **voix favorites** et les sélecteurs de voix n'afficheront que ces voix.

1. Ouvrez **Paramètres**.
2. Trouvez la section **Synthèse vocale**.
3. Appuyez sur **Voix favorites** (la première ligne en haut de la section).
4. Appuyez sur **Définir les voix favorites** pour ouvrir l'écran des favorites.
5. Appuyez sur le bouton de lecture à côté d'une voix pour l'écouter. Appuyez sur l'étoile pour l'ajouter à vos favorites. Vous pouvez mettre autant de voix en favorites que vous le souhaitez.
6. Revenez en arrière. Les sélecteurs de voix dans Theodia n'affichent maintenant que vos voix favorites.

Si vous supprimez toutes les favorites, les sélecteurs affichent à nouveau toutes les voix. Les voix favorites sont incluses lorsque vous sauvegardez et restaurez les paramètres de Theodia.

## Définir une voix différente par Bible

Vous pouvez attribuer une voix propre à chaque traduction biblique. C'est utile lorsque vous basculez entre des traductions qui se lisent très différemment — par exemple une voix plus formelle pour la King James Version et une voix plus conversationnelle pour une traduction moderne comme la NIV ou la NLT. Cela aide aussi si vous écoutez des Bibles dans différentes langues et souhaitez que chacune soit parlée avec le bon accent.

1. Ouvrez **Paramètres**.
2. Trouvez la section **Synthèse vocale**.
3. Recherchez **Voix bibliques**.
4. Appuyez sur n'importe quelle Bible dans la liste.
5. Choisissez la voix souhaitée pour cette traduction. La première ligne, **Voix par défaut**, utilise votre voix TTS principale pour cette Bible.
6. Répétez pour les autres Bibles.

L'en-tête indique combien de traductions bibliques ont une voix personnalisée. **Sélectionner la voix**, **Voix de commentaire**, **Voix des notes bibliques** et **Voix de dévotion** affichent aussi un compteur lorsqu'une voix est définie.

La prochaine fois que vous écouterez un chapitre de cette Bible, Theodia utilisera la voix choisie. Toutes les autres Bibles continuent d'utiliser la voix par défaut principale, sauf si vous les modifiez aussi.

## Continuer la lecture en arrière-plan

Par défaut, Theodia arrête la lecture lorsque vous quittez l'écran du lecteur, basculez vers une autre application ou verrouillez votre téléphone. Cela évite l'audio inattendu lorsque vous n'êtes plus en train de lire activement.

Pour laisser la lecture continuer en arrière-plan :

1. Ouvrez **Paramètres**.
2. Trouvez la section **Synthèse vocale**.
3. Activez **Continuer la lecture en arrière-plan**.

Lorsque cette option est active, vous pouvez changer d'onglet, ouvrir une autre application ou verrouiller l'écran, et le chapitre ou le dévotionnel continue de se lire. La barre de contrôle reste active pour que vous puissiez mettre en pause ou sauter depuis la zone de notification (si votre appareil le prend en charge).

Désactiver cet interrupteur **pendant** la lecture arrête immédiatement la lecture.

## Que faire si cela ne fonctionne pas

La synthèse vocale dépend de votre appareil. Theodia envoie le texte au système d'exploitation, et le système d'exploitation le lit à voix haute à l'aide d'une voix. Si cela ne fonctionne pas, essayez ces étapes dans l'ordre.

### Theodia indique que la synthèse vocale n'est pas disponible

Certains appareils ne disposent pas du tout de TTS. Ouvrez **Paramètres** et cherchez la section **TTS**. Si la section n'est pas là, votre appareil ne prend pas en charge la TTS dans cette version.

### La liste des voix est vide

Le sélecteur de voix peut afficher « aucune voix trouvée ». Cela signifie généralement que l'appareil n'a pas encore terminé de charger ses voix.

1. Ouvrez **Paramètres → Synthèse vocale → Sélectionner la voix**.
2. Si la liste est vide, recherchez un bouton **Retester** juste sous le menu déroulant. Appuyez dessus. Theodia redemande à l'appareil la liste des voix.
3. Si elle est toujours vide, vérifiez les paramètres système de votre appareil. Sur iOS, allez dans **Réglages → Accessibilité → Contenu vocal → Voix** et téléchargez une voix pour votre langue. Sur Android, allez dans **Paramètres → Langue et saisie → Synthèse vocale** et appuyez sur **Installer des données vocales**.
4. Fermez et rouvrez Theodia pour qu'il détecte la nouvelle voix.

Si vous avez défini des voix favorites et que la liste est vide, assurez-vous qu'au moins l'une de vos favorites correspond à une voix installée sur cet appareil.

### J'appuie sur Lire mais rien ne se passe

- Vérifiez que l'appareil n'est pas en mode silencieux. La plupart des appareils ne lisent pas la TTS en mode silencieux.
- Assurez-vous que le volume de l'appareil est suffisant.
- Essayez le bouton **Retester** dans **Paramètres → Synthèse vocale**.
- Ouvrez **Paramètres** et regardez la section **Système** en bas. La ligne **TTS** doit indiquer **Disponible**. Si elle indique **Indisponible**, la TTS est désactivée au niveau du système d'exploitation. Réactivez-la là-bas, puis rouvrez Theodia.

### L'audio se lit mais dans la mauvaise langue

Theodia envoie le texte dans la langue du contenu actuel et demande la voix que vous avez sélectionnée. Si la voix sélectionnée est pour une langue différente, l'appareil peut toujours lire le texte, mais cela sonnera bizarre.

1. Ouvrez **Paramètres → Synthèse vocale → Sélectionner la voix**.
2. Choisissez **Voix par défaut** pour laisser l'appareil choisir la bonne voix, ou choisissez une voix dont la langue correspond au texte que vous lisez.

Theodia ne lit actuellement pas à voix haute les Bibles interlinéaires grecque ou hébraïque. Les boutons **Lire** et **Lire à haute voix** sont masqués sur ces traductions.

### L'audio se lit mais s'arrête prématurément

Si un verset est manquant ou illisible, le chapitre passe au suivant. Si la barre se ferme toute seule après quelques versets, appuyez sur le bouton **Lire à haute voix** (🔊) en haut de l'écran pour recommencer.

### La synthèse vocale est en cours mais je ne sais pas d'où elle vient

Si vous avez activé **Continuer la lecture en arrière-plan** et que vous entendez plus tard de l'audio sans trouver l'écran qui l'a démarré, vous pouvez l'arrêter de n'importe où dans l'application.

1. Ouvrez **Paramètres**.
2. Trouvez la section **Synthèse vocale**.
3. Appuyez sur le bouton rouge **Arrêter la synthèse vocale** en bas de la section.

Cela arrête immédiatement toute synthèse vocale en cours dans Theodia. Vous pouvez aussi ouvrir le sélecteur d'applications de votre appareil et faire glisser Theodia pour forcer l'arrêt de l'audio.

### Cela lit trop vite ou trop lentement

Theodia ne contrôle pas la vitesse de lecture. La vitesse est définie par la voix choisie. Pour la changer :

- Sur iOS : **Réglages → Accessibilité → Contenu vocal → Débit**.
- Sur Android : **Paramètres → Langue et saisie → Synthèse vocale → Débit de parole**.

## Astuces

- La barre de contrôle reste visible lorsque vous naviguez entre les chapitres, pour que vous puissiez mettre en pause, sauter ou changer de voix sans perdre votre position.
- Theodia lit les numéros de verset comme de petites pauses. Vous pouvez arrêter la barre, glisser vers un autre verset, puis appuyer sur lecture pour continuer à partir de là.
- Pour de longues sessions d'écoute, activez **Ne pas déranger** pour que les notifications n'interrompent pas l'audio.
- Le bouton 🔊 utilise le volume actuel de votre appareil. Si vous branchez des écouteurs, le volume passe au niveau des écouteurs.

## Lire un PDF à haute voix

Theodia peut aussi lire les pages d'un PDF à voix haute. Ouvrez un PDF et touchez le bouton **Écouter** (haut-parleur) dans sa barre d'outils. Une barre de commande apparaît avec lecture/pause, rembobiner, avance rapide, arrêt, une barre de progression, ainsi que les sélecteurs de vitesse et de voix. Quand une page est terminée, la lecture se poursuit automatiquement à la page suivante.

La lecture des PDF utilise le texte interrogeable installé du PDF et les mêmes voix et vitesse que la lecture biblique.

## Guides connexes

- Le guide [Mode Étude](theodia://help/study-mode) couvre en détail le menu du verset et les boutons en haut de l'écran.
- Le guide [Mode Concentration](theodia://help/focus-mode) présente une vue de lecture plus épurée qui prend aussi en charge la synthèse vocale via le bouton 🔊 dans la barre du bas.
- Le guide [Problèmes courants](theodia://help/common-problems) propose des solutions pour d'autres problèmes audio, vocaux et linguistiques.
- Le guide [Dévotionnels quotidiens](theodia://help/daily-devotionals) couvre la lecture de dévotionnels et l'emplacement du bouton de lecture sur cet écran.
- Le guide [PDF](theodia://help/pdfs) couvre le lecteur de PDF et son bouton d'écoute.
