---
title: Bienvenue dans Theodia
level: beginner
categories: welcome
summary: Une courte visite de l'application et de ce qu'elle peut faire pour vous.
---

# Bienvenue dans Theodia

Theodia est une application d'étude biblique. Elle fonctionne sur votre téléphone ou tablette, même sans internet. Tout ce que vous lisez, recherchez et étudiez est enregistré sur votre appareil.

## Ce que vous pouvez faire

Theodia propose trois modes utilisateurs. Chaque mode affiche un ensemble différent de fonctionnalités.

- **Lecture** — lire la Bible dans une vue propre et sans distraction.
- **Standard** — tout ce que propose le mode Lecture, plus les signets, les surlignages, les notes, la synthèse vocale, la recherche et les dévotionnels quotidiens.
- **Érudit** — tout ce que propose le mode Standard, plus les commentaires, les lexiques, le Dictionnaire biblique, l'assistant IA, et plus encore.

Vous pouvez changer de mode à tout moment dans **Paramètres** → **Mode utilisateur de l'app**.

### Fonctionnalités toujours disponibles

Quel que soit le mode choisi, vous pouvez toujours :

- **Lire la Bible.** Choisir parmi de nombreuses traductions. Basculer entre elles à tout moment.
- **Rechercher dans la Bible.** Chercher un mot ou une phrase. L'application vous montre chaque verset correspondant.
- **Lire des livres et des dévotionnels.** L'application comprend des classiques chrétiens et un dévotionnel quotidien.

Selon votre mode, vous pouvez aussi :

- **Écouter.** Faire lire les versets à voix haute avec la fonction de lecture à haute voix. (Standard et Érudit.)
- **Prendre des notes.** Écrire vos réflexions à côté d'un verset. (Standard et Érudit.)
- **Surligner.** Marquer vos versets préférés en couleur. (Standard et Érudit.)
- **Créer des signets.** Enregistrer des versets pour les retrouver rapidement. (Standard et Érudit.)
- **Demander à l'assistant IA.** Obtenir de l'aide pour comprendre un verset. (Érudit uniquement.)

## Par où commencer

1. Ouvrez l'onglet **Bible** en bas de l'écran.
2. Choisissez une traduction.
3. Appuyez sur n'importe quel livre pour commencer à lire.

Si vous souhaitez en savoir plus, les autres guides d'aide sont à votre disposition. Choisissez un sujet dans la liste de la page d'accueil de l'aide.

## Quelques choses à savoir

- Vous n'avez pas besoin de compte.
- Vos notes, surlignages et signets restent sur votre appareil.
- Vous pouvez les sauvegarder. Consultez le guide [Sauvegarder vos données](theodia://help/backups) pour savoir comment faire.

## Vous voulez plus de ressources ?

L'application est livrée avec plusieurs versions bibliques librement disponibles. Pour des Bibles, commentaires, lexiques, livres et dévotionnels supplémentaires, consultez le guide [Obtenir des ressources supplémentaires depuis GitHub](theodia://help/getting-core-files). Il explique comment trouver et ajouter d'autres ressources depuis la page GitHub du projet.

Bienvenue. Nous espérons que Theodia vous aidera à lire et à étudier.
