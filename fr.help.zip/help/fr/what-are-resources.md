---
title: Que sont les ressources ?
level: beginner
categories: resources
summary: Un aperçu des différents types de fichiers utilisés par Theodia — Bibles, commentaires, livres, et plus.
---

# Que sont les ressources ?

Dans Theodia, une « ressource » est tout fichier qui ajoute du matériel de lecture ou d'étude à l'application. L'application elle-même n'est qu'un lecteur et un carnet de notes. Les Bibles, commentaires, livres et autres matériaux que vous étudiez sont tous des fichiers séparés que vous chargez dans l'application.

Ce guide explique les différents types de ressources et à quoi sert chacun.

## Pourquoi est-ce important ?

Lorsque vous ouvrez Theodia pour la première fois, quelques éléments sont déjà disponibles. En explorant, vous verrez des boutons pour en installer davantage. Savoir à quoi sert chaque type de ressource vous aidera à décider quoi ajouter.

## Les différents types de ressources

Theodia reconnaît les fichiers par leur extension. Chaque extension correspond à un type de ressource différent.

### `.bible` — une traduction biblique

Une traduction biblique est une copie complète de la Bible dans une version particulière, comme la King James Version. Theodia est livré avec quelques traductions et vous permet d'en ajouter d'autres.

Consultez le guide [Installer des traductions bibliques](theodia://help/installing-bibles) pour plus de détails.

### `.commentary` — un commentaire

Un commentaire est un livre de notes d'étude écrit par un bibliste. Pour un verset donné, un commentaire donne le contexte, le sens et la place du verset dans le reste de la Bible.

Consultez le guide [Commentaires et lexiques](theodia://help/commentaries-and-lexicons) pour plus de détails.

### `.lexicon` — un lexique

Un lexique est un dictionnaire de mots bibliques. Il indique le mot hébreu ou grec original, ce qu'il signifie et comment il est utilisé dans la Bible.

Consultez le guide [Commentaires et lexiques](theodia://help/commentaries-and-lexicons) pour plus de détails.

### `.book` — un livre chrétien

Un livre est une œuvre chrétienne plus longue, comme un classique de l'histoire de l'Église. Lire des livres dans l'application fonctionne de manière similaire à la lecture de la Bible. Theodia comprend une petite bibliothèque de classiques chrétiens librement disponibles.

Consultez le guide [Lire les livres intégrés](theodia://help/reading-books) pour plus de détails.

### `.devotional` — un dévotionnel

Un dévotionnel est une courte lecture quotidienne. Chaque entrée contient généralement un verset, une brève réflexion, et une prière ou une question à méditer. De nombreux dévotionnels sont conçus pour être lus une entrée par jour pendant un an.

Consultez le guide [Dévotionnels quotidiens](theodia://help/daily-devotionals) pour plus de détails.

### `.sqlite` — une base de données de référence

Une base de données de référence est un grand fichier de consultation que l'application utilise pour vous donner des informations supplémentaires pendant la lecture. Il en existe deux types :

- **Références croisées** — des listes de versets liés au verset que vous lisez.
- **Morphologie** — des informations sur les mots hébreux ou grecs originaux du verset.

Vous ne les ouvrez pas directement. Elles fonctionnent en arrière-plan et ajoutent des fonctionnalités au lecteur biblique. Consultez le guide [Références croisées](theodia://help/cross-references) pour plus de détails.

### `.data` — des données de mots

Un fichier de données de mots contient des informations supplémentaires sur les mots bibliques originaux. Il est utilisé par le lexique et les outils d'étude. Comme les bases de données de référence, vous ne l'ouvrez pas directement. L'application l'utilise en arrière-plan.

## Comment ajouter une ressource

L'écran **Gérer les ressources** de l'application est le moyen simple d'ajouter une ressource.

1. Ouvrez **Paramètres**.
2. Appuyez sur **Gérer les ressources**.
3. Appuyez sur **Installer depuis GitHub**.
4. Dans le modal de téléchargement, choisissez un onglet — **Bible**, **Commentaires**, **Livres**, **Dévotionnels** ou **Cœur** — puis sélectionnez ce que vous voulez et appuyez sur **Installer la sélection**.
5. Ou appuyez sur **Installer un fichier local** pour importer un fichier que vous avez déjà téléchargé.

Pour un guide pas à pas pour obtenir des fichiers directement depuis GitHub, consultez le guide [Obtenir des ressources supplémentaires depuis GitHub](theodia://help/getting-core-files).

## Comment supprimer une ressource

1. Ouvrez **Paramètres**.
2. Appuyez sur **Gérer les ressources**.
3. Trouvez la ressource que vous souhaitez supprimer.
4. Appuyez sur l'icône de corbeille à côté.
5. Confirmez la suppression.

Supprimer une ressource ne supprime pas vos notes, surlignages ou signets. Ceux-ci restent en sécurité.

## Où les ressources sont stockées sur votre appareil

Les ressources sont stockées sur votre appareil, pas dans le cloud. Une fois une ressource installée, vous n'avez pas besoin d'internet pour la lire. Vous pouvez sauvegarder votre appareil, mais les ressources elles-mêmes ne sont pas sauvegardées dans le cloud par Theodia. Si vous désinstallez puis réinstallez l'application, vous devrez réajouter les ressources que vous aviez installées.

## Aide et questions

Si vous rencontrez des difficultés, consultez le guide [Où poser des questions](theodia://help/getting-more-help). L'équipe et la communauté pourront vous aider.
