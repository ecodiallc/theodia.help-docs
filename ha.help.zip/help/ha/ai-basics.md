---
title: AI na Asali
level: advanced
categories: ai
summary: Yadda za a yi amfani da mataimakin AI don fahimtar ayoyi.
---

# AI na Asali

> **Yanayi:** Mataimakin AI yana bukatar yanayin **Scholar**. Za ka iya canja yanayi a **Saitunan** → **Yanayin Mai Amfani da App**.

Theodia tana da mataimakin AI. Zai iya taimaka maka ka fahimci aya, ka amsa tambaya, ko ka tattauna batun Littafi Mai Tsarki.

## Yadda ake kunna AI

AI ne aka kashe da asali. Don kunnawa:

1. Bude **Saitunan**.
2. Danna **Mataimakin AI**.
3. Danna swichi don kunna shi.

## Yadda ake budewa AI

Danna tabon **AI** a kasa ta allon. Tagar tattaunawa za ta bude.

## Yadda ake yin tambaya

Danna akwatin a kasa. Rubuta tambayarka. Danna **Tumani**.

Wasu abubuwan da za ka iya tambaya:

- "John 3:16 yana nufi me?"
- "Fadi mini game da littafin Romawa."
- "Menene 'ya'yan Ruhu?"
- "Kwatanta Mahubiri a kan Dutsen a Mathu da Luka."

## Yadda ake tambaya game da aya ta musamman

1. Bude sura.
2. Danna aya don fito da menun aya.
3. Danna **Mafafani na AI**.

An tura aya zuwa AI. Panel din AI ya bude tare da aya da aka riga aka cika. Za ka iya kara tambaya, kamar "Wannan yana nufi me?" ko "Ta yaya zan yi amfani da wannan?"

## Abubuwan muhimman da za a sani

- AI zana ce, ba mutum ba. Zai iya kuskure.
- Kullum duba amsoshi na AI ta hanyar daidai ya Littafi Mai Tsarki kanta.
- AI na iya bukatar intanet. Bata aiki offline.
- Da kake amfani da AI, tambayoyinka, mahallin aya, da maɓallin API naka an aika zuwa ƙarshen da ka zaɓa. Karon farko da ka yi wannan, app ɗin zai nemi izininka kuma ya nuna ainihin abin da aka aika. Za ka iya canja ko soke wannan izinin daga baya a **Saitunan → Mataimakin AI → Raba Bayanan AI na Wurin**.
- Wasu yankuna, kamar sigar China mainland App Store, ba sa ba da mataimakin AI. A wannan sigar, kawai kaddarorin Littafi Mai Tsarki na offline ne ake samu.

## Yadda ake sarrafa tattaunawa

allon AI yana ajiye jerin tattaunawa da suka wuce. Daga jerin, za ka iya budewa tattaunawa ta dā, ka sabar sabuwa, ko ka share ɗaya da ba ka bukata.

## Kusa zuwa nahiya da AI

Wannan shafi ya rufe asali ne. AI na Theodia zai iya aiwatar da mengya fiye da tattaunawa. Ga inda za ka je gaba:

- **[Kaddororin AI](theodia://help/ai-features)** — Gano duk abin da Theophilus zai iya yi: karatun aya ɗaya ɗaya a Girkanci da Ibrananci, suniyyun giciye, tsarin wa'azi, shirin addu'a, morphology na harshen asali, nema a dictiona, da kuma lilo a cikin app ba tare da hannu ba. Wannan jagorar tana nuna maka yadda za a koma The AI daga chatbot zuwa abokiyar karatu cikakkiya.
- **[Rubuta Masu Almara Iya na AI](theodia://help/ai-prompts)** — Koyi fasahar yin tambayoyi masu ƙarfi da suke ba da amsoshi masu ƙarfi. 'Yan sauya-suya a yadda ka sabunta bukata zai iya buɗe amsoshi masu nisa daga AI.
- **[Zaɓar Model ɗin AI](theodia://help/choosing-a-model)** — Ba dukkan models ɗin AI suke daidai ba. Ga models ɗin da suke goyan bayan tools ɗin gina cikin (kamar bude ayoyi da neman ayoyi) da kuma waɗanda za su mayar da AI ya zama cikakktakkiyar aboki na karatun Littafi.
- **[GitHub Models](theodia://help/github-models)** — mai samar da free da Theodia ke ba da shawara. Samu free API key tare da asusun GitHub ka fara tambaya a rana ɗaya mai yawa. Ba kiredit kadi, ba biyan kuɗi.
- **[Maɓallan API da Kudinta](theodia://help/ai-keys-and-costs)** — Fahimci yadda farashin API ke aiki a cikin masu samarwa da yadda za a ci gaba da kudin ƙusa zuwa sifili.
