---
title: Kaddarorin AI
level: advanced
categories: ai
summary: Gano duk abin da AI na Theodia zai yi — daga karatun aya-aya zuwa shirya wa'azi, bincike na harshen asali, da lilo ba tare da hannu ba.
---

# Kaddarorin AI

> **Yanayi:** Mataimakin AI yana bukatar yanayin **Scholar**. Za ka iya canja yanayi a **Saitunan** → **Yanayin Mai Amfani da App**.

Mataimakin AI na Theodia, Theophilus, ba chatbot kawai ba ne. Abokiyar karatu ce zai iya karanta Littafi Mai Tsarki tare da ka, nema commentaries, neman ayoyi, sarrafa bayananka, da kuma lilowa a cikin app — duk ta murya ko rubutu.

Kafin Theophilus ya tura bayani zuwa ƙarshen AI karo na farko, app ɗin zai nuna tambayar izininta wacce ke bayani abin da aka tura, kuma ya nemi izininka. Zaka iya canja ko soke wannan izinin a kowane lokaci a **Saitunan → Mataimakin AI → Raba Bayanan AI na Wurin**.

## Tattaunawar Aya: Karatu Guda na Aya

**Tattaunawar Aya na AI** ita ce zuciyar kwarewar AI ta Theodia. Da kake karanta kowane sura, danna lamban aya (ko riƙe rubutun aya) kuma ka zaɓi **Mafafani na AI**. Panel din tattaunawa ya bude tare da wannan aya da aka riga aka loda. AI ɗin sanin daidai abin da ka ke karantawa, kuma ya shirye ya bincika tare da ka.

### Masu farawa ta danna guda

Ba ka tabbata abin da za ka tambaya? Panel ɗin yana nuna masu farawa takwas na nan take:

- **Fassara wannan aya** — Sami bayani mai haske game da ma'ana da muhimmancinta.
- **Harshen asali** — Ga kalmomin Girkanci ko Ibrananci, transliterations, da ma'anar lexical a bayan rubutun Ingilishi.
- **Mahallin tarihi** — Koyi game da al'adu, siyasa, da abubuwan da ke kewaye da aya.
- **Mahallin rubutu** — Ga yadda aya ta dace a cikin sakin layi, sura, da littafi kewaye da ita.
- **Babban jigogi** — Gano manyan ra'ayoyin da aya ta bayar ga ilimin tauhidin Littafi.
- **Yi amfani da rayuwata** — Sami aikace-aikace masu amfani, na mutum ɗaya da za ka iya yi a yau.
- **Shirya addu'a** — Canja aya zuwa addu'a wadda ta yi amfani da harshen da gaskiyoyinta.
- **Shirya tsarin wa'azi** — Sami tsarin maki uku tare da gabatarwa da ƙarshe, shirye don wa'azi.

Danna wani mai farawa kuma AI ɗin zai fara nan da nan. Za ka iya bin baya da tambayoyinka, ka nemi bayani, ko ka kai tattaunawar zuwa sabon shiri.

### Bin baya kamar tattaunawar gaskiya

AI ɗin yana tunawa da 'yan sakonnin karshe a tattaunawa, don haka za ka iya bincike ta hanyar halitta:

- "Za ka iya sa wannan sauƙi?"
- "Menene Girkanci na asali yake cewa a nan?"
- "Nuna mini suniyyun giciye masu danganta da wannan."
- "Kwatanta wannan aya a cikin nau'i uku daban daban."
- "Wannan zai yi yaya a cikin wurin aiki na zamani?"
- "Bani aikace guda uku na ƙarin don iyaye."

Tattaunawar tana tsotsa da aya, don haka kowane amsa yana dogara ne ga rubutun da ka ke karantawa.

### Danna kowanne nassararararararararararar Sarauniya zuwa Littafi Mai Tsarki

Lokacin da AI ɗin ya ambato wata iri (misali, "Wannan yana tunatar da Romawa 8:28"), nassarar ta bayyana kamar **taɓawa mai haɗi**. Danna ta, app ɗin zai tsallake zuwa wannan taɓun a cikin kaukarar Littafi Mai Tsarki. Za ka iya bincika suniyyar nassarararar r ba ka bar tattaunawa.

## Abin da AI zai iya yi a bayan Tattaunawa

Theophilus ya samu damar shiga dukkan abubuwan Theodia — Bibles, commentaries, lexicons, dictionaries, littattafai, devotionals, bayananka, bookmarks, da highlights. Ga abin da wannan ke nufi a aikace.

### Karanta da lilowa ayoyi

- **Karanta kowanne aya ko sura** — "Karanta John 3:16 a cikin WEB" ko "Karanta Zabura 23 a loud."
- **Bude taɓun a cikin kaukarar** — "Kai ni Genesis 1" ko "Bude Romawa 8:28."
- **Kwatanta nau'i** — "Nuna mini John 3:16 a cikin duk Bibles dina."
- **Nema Littafi Mai Tsarki** — "Nemo ayoyi game da gafartawa" ko "Nemo 'zaman lafiya da ya wuce fahimtar'."
- **Samu suniyyun giciye** — "Wani ayoyi masu danganta da Ishaya 53:5?"
- **Karanta kanun labarai** — "Menene ƙananan headings in Mathu 5?"

### Bincike harshen asali

- **Lexicon lookups** — "Me kalmomen Girkanci 'agape' yake nufi a cikin John 3:16?" ko "Nemo Strong's G26."
- **Morphology** — "Sakarar kalmomin Girkanci a cikin Romawa 8:28" ko "Me lambar morphology V-PAI-3S take nufi?"
- **Word Info** — AI ɗin zai iya ganin wannan breakdown na kalma-kalma wanda ka ke ganin a cikin app — transliteration, gloss, grammar, da Strong's numbers.

### Karanta commentaries da littattafan karatu

- **Mafafani na aya** — "Menene Matthew Henry ke cewa game da Efsosiyawa 2:8?"
- **Mafafani na sura** — "Bani taƙaitaccen mafafani na sura na Romawa 8."
- **Mafafani na littafi** — "Taƙaita mafafanin littafi na Apokalipsis."
- **Littattafan karatu** — "Karanta mini sura daga Hymn Lyrics English" ko "Nemo littattafaina akan 'takawa'."
- **Devotionals** — "Karanta yau dar boring devotional" ko "Nemo devotional akan damuwa."

### Nemo dictionaries

- "Wa Melkizedek yake?"
- "Menene dictionary na Littafi yake cewa game da Gilgal?"
- "Nemo 'propitiation' a cikin Easton's."

### Sarrafa rayuwar karatuka

AI na iya aiki akan bayananka na sirri — kullum ana adana locally a kan na'urarka:

- **Bookmarks** — "Bookmark wannan aya a cikin babban fayil da nake wa wa'azi" ko "Gano jerin bookmarks dina."
- **Highlights** — "Hilitahi John 3:16 a rawaya" ko "Nuna mini duk highlights dina."
- **Notes** — "Kallo bayanin Littafi akan wannan aya" ko "Karanta bayanina don a Genesis 1."
- **Bayanin karatu** — "Ajiye wannan tattaunawa a matsayina Bayanin Karatu" ko "Kallo sabon notebook na karatu mai suna Romawa Karatu."
- **Babbabn fayil** — "Kallo babban fayil mai suna Morning Devotion" ko "Kaiba bookmark na John 3:16 zuwa babban fayil na Addu'a."

### Canja saitunan app ɗin

- "Canja zuwa dark mode."
- "Sa BSB ya zama Littafi na farko."
- "Kunna parallel Bibles tare da NET."
- "Ka ƙara size na rubutu."

### Karanta da murya

- "Karanta Zabura 23 a loud" — AI na iya tunawa TTS na kowanne taɓun, littafi, ko bayananka.
- "Daina karatu" — Daina TTS a kowane lokaci.

## Ajiye Tattaunawarka

Kowane AI verse chat za a iya ajiyewa. Danna menudin a cikin panel tattaunawa kuma ka zaɓi:

- **Ajiye a matsayin Bayanin Littafi** — ƙara tattaunawar kammala ga bayanin aya a cikin kaukarar Littafi.
- **Ajiye a matsayin Bayanin Karatu** — Ajiye tattaunawar a cikin littafinka Bayanin Karatu don tunani daga baya.

Wannan yana juya farin tattaunawar AI zuwa kayan karatu na dindin wadda za ka iya tunawa, gyara, ko gina wa'azoku daga gare ta.

## Full AI Tab

A bayan panel na verse chat, Theodia tana da tab ɗin **AI** na makala a cikin bottom navigation. Wannan tattaunawa ce ta yadda za ka iya ina tambaya — ba aya da aka yi-pre-selected. Yi amfani da ita don:

- Karatun jigogi a kowane Littafi
- Binciken wa'azi da tsari
- Kwatanta jigogi na tauhidi tsakanin littattafai
- Devotional na rayuwa da addu'a prompts
- Trivia na Littafi da shirye-shirye na karatu
- Taimakon app — "Ta yaya parallel Bibles suke aiki?"

Tattaunawar ka na ajiye ta atomatik. Za ka iya koma ziyarar tattaunawa, ka sabar sabuwar, ka share threads da suka wuce.

## Ra'ayoyi don Fara

Ga wasu hanyoyi masu ban mamaki don amfani da AI. Zabi daya kuma gwada yau.

**Ci gaban Mutum**

- "Fassara Filibiyawa 4:6–7 kuma bani addu'a lokacin da nake damuwa."
- "Mene Littafi Mai Tsarki yake cewa game da hutu? Nemo mini ayoyi biyar kuma fassara kowanne."

**Iyalin da Uwaye**

- "Ta yaya Efsosiyawa 6:4 yake jagorantar uwaye na zamani? Bani dokoki masu amfani uku."
- "Nemo ayoyi game da girma yara kuma ka karanta mini su a loud."

**Shirin Wa'azi da Koyarwa**

- "Tsara 25-minuten wa'azi akan Romawa 8:28 tare da gabatarwa, maki uku, da ƙarshe."
- "Me commentaries dina ke cewa game da 'takin inset' a cikin Efsosiyawa 6?"
- "Kwatanta Mahubiri a kan Dutsen a Mathu da sigar Luka. Menene bambancin?"

**Karatun Harshen Asali**

- "Nuna mini morphology na kowanne kalma a cikin John 1:1."
- "Menene bambancin 'agape' da 'philia' a cikin Zamanin Ahadi Tuwai?"

**Tsawo na Devotional**

- "Karanta yau dar devotional kuma ka danganta da aya a cikin Zabura."
- "Bani makonkwana sabuwar matakin devotional bisa 'ya'yan Ruhu."

**Suniyyun Giciye**

- "Fara da Ishaya 53:5 kuma ka bin ajiyar 'rauni' da 'waraka' ta Zamanin Ahadi Kalli."
- "A ina kalmar 'alkawari' take faruwa daga Farko zuwa Ibriyawa?"

**Tunani da Bincike**

- "Quiz mini littattafai na Littafi Mai Tsarki a biyukux."
- "Kallo bayanin karatu mai taƙaita babban nuna na kowanne sura a cikin Romawa."

## Muhimman Kalmomi

- AI ɗin zana ce, ba mayewar Littafi Mai Tsarki ko jagorancin limamai ba. Kullum kwfdonza amsoshi zuwa Nassara kanta.
- Da kake amfani da AI, tambayoyinka suna tafiya a cikin intanet zuwa servers na mai samarwa. Dukkan masu samarwa ba su horar a kan bayananka ba, amma rubutun ya bar na'urarka.
- AI zai iya kuskure. Yi amfani da commentaries, lexicons, da rubutun Littafi da yalwa a matsayin ikon ƙarshe.

## Taƙaitawna

AI na Theodia an tsara ne don yin karatun Littafi Mai Tsarki ya zama da sauri, ƙuƙuku, da mutumtum. Ko ka ke son fassarar wannan setence na aya mai rikici, cikakktakkiyar tsarin wa'azi, karatun kalma Girkanci, ko suniyyar giciye wanda ya ƙunshi dukkan Littafi, Theophilus ya shirye don taimaka. Danna aya, tambaya, kuma duba inda tattaunawa za ta kai.
