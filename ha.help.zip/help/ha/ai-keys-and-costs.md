---
title: Maɓallan API da Kudinta
level: advanced
categories: ai
summary: Me ya sa za ka buƙachi maɓallin API, yadda za a samu, da abin da amfani da model ɗin AI na waje yake kudin kawo.
---

# Maɓallan API da Kudinta

> **Yanayi:** Mataimakin AI yana bukatar yanayin **Scholar**. Za ka iya canja yanayi a **Saitunan** → **Yanayin Mai Amfani da App**.

Mataimakin AI yana hadewa ga models ɗin AI na waje. Idan ka ke son amfani da ɗaya, ka buƙachi maɓallin API. Wannan shafi yana bayani me ya sa, yadda za a samu, da kudin da aka saba.

## Me ya sa za ka buƙachi maɓallin API

Model ɗin AI na waje yana ajiye a server a intanet. Maɓallin API ya kamar kalmar sirri wacce take fada server, "Wannan mutum an ba shi damar yin tambayoyi." Ba shi, server ba zai amsa ba.

App ɗin ba ya samar da built-in key. Dole ka ƙirƙiri asusun kanka tare da mai samarwa ka liƙa key naka a cikin app ɗin.

## Yadda za a samu maɓallin API

1. Bude **Saitunan** a cikin Theodia.
2. Danna **Mataimakin AI**.
3. Zaɓi **Model ɗin waje**.
4. Zaɓi mai samarwa daga jerin, ko zaɓi **Custom** ka shigar da base URL.
5. Danna link zuwa shafin key na mai samarwa. Ƙirƙiri asusu idan ba ka da ɗaya.
6. Ƙirƙiri sabon maɓallin API a shafin mai samarwa.
7. Kofi maɓallin ka liƙa a cikin Theodia.
8. Danna **Gwada connection** don tabbatar ta yi aiki.

## Masu samarwa da aka goyi

Theodia za a iya hadewa da kowanne mai samarwa wanda ke amfani da API mai kama da OpenAI. Ga masu samarwa masu presets a cikin app ɗin:

- **GitHub Models** — github.com/marketplace/models (rana free tier, an ba da shawara)
- **OpenAI** — platform.openai.com
- **OpenRouter** — openrouter.ai
- **Anthropic** — console.anthropic.com
- **Groq** — console.groq.com
- **Mistral** — console.mistral.ai
- **Together AI** — api.together.xyz

Ka kuma iya amfani da **Custom** base URL idan ka ke sarrafa server naka ko kuma amfani da wani sabis na daban.

## Nawa kudin?

Dukkan masu samarwa suna caji ta **token**. Token yana kusan da kashi na kalma ko wani ɓangaren kalma. Za ka biya tokens da ka tura (tambayarka) ƙari tokens ɗin da AI ɗin ya mayar (amsa).

### Farashi na yauk wata

Farashi na canzawa, amma ga ma'ana a tsakiyar 2026:

- **Models ƙanana masu sauri** (kamar endpoints masu araha na GPT-3.5) suna kudin zubin cent na naira (cent) a kowanne token 1000.
- **Models na tsakiyar mataki** (kamar GPT-4o ko Claude Sonnet) yawanci suna kudin 'yan cents a kowanne token 1000.
- **Models masu girman reasoning** (kamar GPT-4.5 ko Claude Opus) za su iya kudin goma zuwa kashi ashirin (20) cents a kowanne token 1000.

Tambayae yau na Littafi a cikin Theodia na iya amfani da 'yan ɗari zuwa taguwarma dubbai token gaba ɗaya. Wannan yana nufin yawancin tambayoyi suna kudin kasan **cent ɗaya zuwa 'yan cents**.

### Tuni don rage kudin

- Fara da model mai araha. Yawancin tambayoyin Littafi ba sa bukatar model mai tsada.
- Yi amfani da Groq ko OpenRouter idan ka ke son gwada models daban-daban kuma kwatonta farashi.
- Kalli dashboard ɗin amfani naka a shafin mai samarwa.

## GitHub Models

[GitHub Models](https://github.com/marketplace/models) yana ba da free tier tare da babu bukatar biyan kuɗi. Duk abin da ka bukata shi ne account GitHub mai free da personal access token mai izinin karanta models.

**Yadda ake saita:**

1. Ka je [github.com/settings/tokens](https://github.com/settings/tokens) ka ƙirƙiri **Personal access token (classic)**.
2. Ba shi scope `models:read` (ko kuma zaɓi izinin models kawai).
3. A cikin Theodia, zaɓi **GitHub Models** a matsayin mai samarwa ka liqa token naka.

**Models na free-tier:**

- `openai/gpt-4.1-nano` — **15 requests a minti, 150 requests a rana**
- `openai/gpt-4.1-mini` — **15 requests a minti, 150 requests a rana**
- `openai/gpt-4.1` — **10 requests a minti, 50 requests a rana**
- `openai/gpt-4o` — **10 requests a minti, 50 requests a rana**

Wannan iyakokin suna reset a rana kuma suna isar don karatun Littafi na yau da kullum.

Don cikakken wasa ta hanya tare da screenshots, duba jagorar musamman [GitHub Models](theodia://help/github-models).

## Bayanin sirri

Da kake amfani da remote AI model, app ɗin na nuna tambayar izininta da take bayanin abin da aka tura: saƙonninka, mahallin aya ko sura, tool calls da sakamakonsu, sunan model ɗin da aka saita, da maɓallin API ɗinka a cikin request header. Request ɗin yana tafiya kai tsaye zuwa ƙarshen da ka saita, ba ta Theodia ba. Dukkan masu samarwa ba su yi amfani da bayananka ba don horar da models ɗinsu, amma rubutun ya bar na'urarka. Za ka iya canja ko soke izini a kowane lokaci a **Saitunan → Mataimakin AI → Raba Bayanan AI na Wurin**.

## Taƙaitawna

- Ka buƙachi maɓallin API don amfani da mataimakin AI.
- Ƙirƙiri asusu tare da mai samarwa, ƙirƙiri key, ka liqa a Theodia.
- Yawancin tambayoyi suna kudin cent ɗaya ko ƙasa da haka.
