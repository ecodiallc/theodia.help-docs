---
title: Mataimakin AI
level: advanced
category: ai
summary: Yadda ake amfani da aiwatarwa don fahimtar ayoyi.
---

# Mataimakin AI

Theodia tana da mataimakin AI. Zai iya taimaka ka ka fahimci aya, ka amsa tambaya, ko ka tattauna batun Littafi Mai Tsarki.

## Yadda ake kunna AI

AI ne aka kashe da asali. Don kunnawa:

1. Bude **Saitunan**.
2. Danna **Mataimakin AI**.
3. Danna swichi don kunna shi.

Ka na iya bukatar ka ƙirƙiri asusu ko key. App ɗin zai jagorance ka.

## Yadda ake budewa AI

Danna tabon **AI** a kasa ta allon. Tagar tattaunawa za ta bude.

## Yadda ake yin tambaya

Danna akwatin a kasa. Rubuta tambayarka. Danna **Tumani**.

Wasu abubuwan da za ka iya tambaya:

- "John 3:16 yana nufi me?"
- "Fadi mini game da littafin Romawa."
- "Menene 'ya'yan Ruhu?"
- "Kwatanta Mahubiri a kin Dutsen a Mathu da Luka."

## Yadda ake tambaya game da aya ta musamman

1. Bude sura.
2. Danna aya don fito da menun aya.
3. Danna **Mafafani na AI**.

An tura aya zuwa AI. Panel din AI ya bude tare da aya da aka riga aka cika. Za ka iya kara tambaya, kamar "Wannan yana nufi me?" ko "Ta yaya zan yi amfani da wannan?"

## Abubuwan muhimman da za a sani

- AI zana ce, ba mutum ba. Zai iya kuskure.
- Kullum duba amsoshi na AI ta hanyar daidai ya Littafi Mai Tsarki kanta.
- AI na iya bukatar intanet. Bata aiki offline.
- Da kake amfani da AI, tambayoyinka, mahallin aya, da maɓallin API naka an aika zuwa ƙarshen da ka zaɓa. Karon farko da ka yi wannan, app ɗin zai nemi izininka kuma ya nuna ainihin abin da aka aika. Za ka iya canja ko soke wannan izinin daga baya a **Saitunan → Mataimakin AI → Raba Bayanan AI na Wurin**.
- Wasu yankuna, kamar sigar China mainland App Store, ba sa ba da mataimakin AI. A wannan sigar, kawai kaddarorin Littafi Mai Tsarki na offline ne ake samu.

## Yadda ake sarrafa tattaunawa

allon AI yana ajiye jerin tattaunawa da suka wuce. Daga jerin, za ka iya budewa tattaunawa ta dā, ka sabar sabuwa, ko ka share ɗaya da ba ka bukata.

Don ƙarin ƙanuki, duba jagorar [Rubuta Masu Almara Iya na AI](theodia://help/ai-prompts).
