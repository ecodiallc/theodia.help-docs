---
title: Rubuta Masu Almara Iya na AI
level: advanced
categories: ai
summary: Yadda za a yi tambayar mataimakin AI don samun amsoshi masu kyau.
---

# Rubuta Masu Almara Iya na AI

> **Yanayi:** Mataimakin AI yana bukatar yanayin **Scholar**. Za ka iya canja yanayi a **Saitunan** → **Yanayin Mai Amfani da App**.

"Prompt" yana nufin tambaya ko umarnin da ka ba AI. Masu almara iya suna ba da amsoshi iya. Wannan jagora tana nuna maka yadda za ka yi.

## Kasance da takamaiman

Muni: "Fadi mini game da so."
Mafi kyau: "A cikin 1 Korintiyawa 13, menene nau'in so Bulus ya bayyana, kuma ta yaya yake bambanta da so na giwa?"

Yadda ka ba da ƙarin bayani, haka amfani ya zama.

## Ba da mahallin

Muni: "Wannan aya yana nufi me?"
Mafi kyau: "Ina karanta Romawa 8 tare da ƙungiyar ƙarami. Me 'babu hukunci' take nufi a cikin wannan sura, kuma ta yaya ta danganta zuwa ɓangaren sura?"

Mahallin yana taimaka AI ɗin ya dace amsar da halin ka.

## Tambayi daya a lokaci

Muni: "Fadi mini game da addu'a, imani, da waraka."
Mafi kyau: "Fadi mini game da addu'a da farko. A nimsaanar, zan yi tambaya game da imani."

Tambayar daya a lokaci tana kiyaye amsoshi masu mayar da hankali.

## Ka tambayi AI ɗin ya ɗauki matsayi

Ka iya tambayi AI ɗin ya amsa a cikin murya ta musamman. Misali:

- "Amsa ka nuni ka ne ka ke koyar da Kirista sabo."
- "Amsa ka nuni masanin Littafi."
- "Amsa don shekara 10."

AI ɗin yana dace amsar da matsayin.

## Yi amfani da tambayoyin bin baya

Idan amsar farko ba ta dace gaba ɗaya ba, tambayi bin baya:

- "Za ka iya sa abin sauƙi?"
- "Za ka iya ba ni misali?"
- "Menene Girkanci na asali yake cewa?"
- "A ina ƙarar nan aka kuma ya faru a Littafi?"

Tattaunawa mai kyau tattaunawa-waya ne. AI ɗin yana tunawa da 'yan sakonnin karshe.

## Duba amsoshi na AI

AI zai iya kuskure. Zana ce, ba malami ba.

- Kwatanta amfani da ayoyi da ya ke nunawa.
- Yi amfani da commentaries da lexicons a cikin app ɗin don ra'ayi na biyu.
- Idan amsar tayi da doctrine, tambayi limanin ɗaya ko aboki da aka amince.

## Tsaruka na tambaya na yau da kullum

Ga 'yan wadanda suka yi aiki:

- "Fassara wannan aya mini ka nuni na Kirista sabo."
- "Menene babban nuna na wannan sura a cikin jamuna guda?"
- "Gano mutane uku masu amfani na yau da kullum daga wannan taɓin."
- "Menene tambayoyi da dashi nake bukatar tambaya game da wannan aya kafin in wa'azi?"

