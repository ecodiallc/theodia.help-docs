---
title: Yanayin Mai Amfani da App
level: beginner
categories: [user-mode]
summary: Zaɓi tsakanin yanayin Reader, Standard, da Scholar don sarrafa ƙarin kaddarorin da ake gani a cikin app.
---

# Yanayin Mai Amfani da App

Theodia tana da yanayin masu amfani guda uku masu sarrafa ƙarin kaddarorin da ka ke gani. Zaɓi wanda ya dace yadda ka ke son amfani da app.

## Reader

Mafi saŭkani. Yanayin Reader don karatun Littafi Mai Tsarki ba tare da tashin hankali ba.

- Karanta kowanne tarhin Littafi
- Yi amfani da Yanayin Focus don karatu a cikakken allo mai tsafta
- Lilowa littattafai da surori
- Babu ƙaddarorin karatu, babu AI, babu bookmarks, babu highlights

Yanayin Reader na musamman ne idan ka ke son Theodia ta yi kamar Littafi Mai Tsarki na dijital mai tsafta tare da Jim kari na ƙari.

## Standard

Yanayin Standard yana ƙara kaddarorin na yau da kullum don karatun Littafi na mutum.

Dukkanin abin Reader, ƙari:

- Bookmarks, highlights, da bayanai
- Text-to-speech
- Study Mode kaukarar da menun aya
- Parallel Bibles
- Command input
- Nema Littafi Mai Tsarki
- Devotionals na yau da kullum da littattafai na gina cikin

Yanayin Standard shi ne zaɓi mai kyau ga yawancin masu amfani kamar su karanta, taka, kuma su nema Littafi Mai Tsarki tare da wadanda ba su da ƙaddarorin karatu.

## Scholar

Yanayin cikakkiya. Yanayin Scholar ya buɗe dukkan ƙaddarorin Theodia don karatun Littafi mai ƙuƙuku.

Dukkanin abin Standard, ƙari:

- Commentaries da lexicons
- Suniyyun giciye
- Littafin Kone na Bible
- Word Info (Strong's lookups)
- Mataimakin AI da Mafafani na AI
- Launcher Menu

Yanayin Scholar an tsara ne don limamai, ɗaliban seminary, da kowanne wanda yake son ƙaddarorin harshen asali da AI-powered study aids.

## Yadda ake canja yanayi

1. Bude **Saitunan**.
2. Danna **Yanayin Mai Amfani da App**.
3. Zaɓi **Reader**, **Standard**, ko **Scholar**.

Canjin ya faru nan da nan. Menus da buttons ɗin da ba ka da damar su a cikin yanayin ka na gaba an ɓoye.

## Zaɓar yanayi

- **Reader** — Ka ke son kawai karanta Littafi Mai Tsarki, babu ƙari.
- **Standard** — Ka ke son bookmarks, highlights, bayanai, nema, da devotionals.
- **Scholar** — Ka ke son dukkan ƙaddarorin karatu, hadin daba AI, commentaries, da lexicons.

Za ka iya canja yanayi a kowane lokaci. Bayananka, highlights, da bayananka ba a share da ka canja yanayi ba; an ɓoye su har ka koma zuwa yanayin da yake ta samu.

- *saŭkani* layout typo okay. Ensure categories [user-mode] preserved exact. 
