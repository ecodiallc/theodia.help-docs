---
title: Backing Up Your Data
---

title Hausa: "Ajiye Bayananka" but keep keys. Let's write full.

---
title: Ajiye Bayananka
level: everyday
categories: settings
summary: Yadda za a ajiye da dawowa bayananka, highlights, bookmarks, da secrets.
---

# Ajiye Bayananka

Bayananka, highlights, bookmarks, da saitunanka ana cika argce a kan na'urarka. Idan ka rasa wayar ka, ka samu sabuwa, ko ka uninstall app ɗin, wadannan bayanai za su iya bata. Wannan jagora tana nuna maka yadda za a Ajiyesu.

## Yadda ake budewa saitunan ajiye

1. Bude **Saitunan**.
2. Danna **App Backup**.

## Yadda ake yin app backup

1. Bude **Saitunan**.
2. Danna **App Backup**.
3. Danna **Create App Backup**.
4. Zaɓi babbar fayil a kan na'urarka don ajiye fayil. Ka iya zaɓi cloud drive.
5. App ɗin yana yin fayil ɗaya tare da dukkan bayananka. Fayil ɗin yana ƙare da `.zip`.

## sau nawa za a yin backup

Yi backup:

- Bayan ka rubuta bayanai da yawa.
- Kafin sabuntar tsarin aiki na na'urarka.
- Kafin ka uninstall app ko ka canja wayar.

Kyawun addci ɗaya a wata. Wasu masu ajiya suna yin backup a kowane mako.

## Yadda ake dawowa daga app backup

1. Bude **Saitunan**.
2. Danna **App Backup**.
3. Danna **Restore from App Backup**.
4. Zaɓi fayil ɗin `.zip` backup.
5. Ga kowanne nau'in bayanai (bayanai, highlights, bookmarks, da dai sauransu), zaɓi ko ka riƙe abin da ke kan na'urarka, ka maye da backup, ko ka ɓuncila.
6. Danna **Restore**.

App ɗin yana maye wadannan bayananka da bayanan da ke cikin backup ɗin:

- Bayanai
- Highlights
- Bookmarks
- Babbabn fayil na Bookmarks
- Saituna (theme, size na rubutu, harshen)

## Secrets Backup

**App Backup** ɗinka ba ya ƙunsar secrets masu sensitive kamar maɓallin API naka na AI ko GitHub token. Don Ajiyesu su daban, yi amfani da **Secrets Backup**.

### Ajiye secrets backup

1. Bude **Saitunan**.
2. Danna **App Backup**.
3. A ƙarƙashin **Secrets Backup**, danna **Save Secrets Backup**.
4. Shigar da kalmar sirri mai ƙarfi ka tabbatar.
5. App ɗin yana tsotse secrets ɗinka ka raba fayil. Ajiyesu a waniwani mai aminci.

### Dawo secrets backup

1. Bude **Saitunan**.
2. Danna **App Backup**.
3. A ƙarƙashin **Secrets Backup**, danna **Restore Secrets Backup**.
4. Zaɓi fayil ɗin secrets backup mai tsotse.
5. Shigar da wannan kalmar sirri da ka yi amfani da ita lokacin ajiya.
6. Secrets ɗinka sun dawo.

> **Muhimmanci:** Idan ka motoca kalmar sirri, secrets ɗin ba za su iya dawwowa ba. Babu reset.

## Abubuwan da za a sani

- Restore yana **maye** da categories ɗin da ka zaɓa. Abin da ka ƙara bayan backup ɗin ya ɓatar ga wadannan categories.
- App backup yana ɗaya fayil ɗin `.zip`. Rike shi a waniwani mai aminci.
- Za ka iya kofi fayil ɗin, ka matsar, ko ka ajiye a cikin sabis na cloud.
- App backups ba ya ƙunsar tarhin Littafi Mainga kanta ba. Za a iya re-download su a **Saitunan** → **Manage Resources**.
- Secrets backups ana tsotsewa da kalmar sirri. Zaɓi kalmar sirri da za ka tuna.

## Tuni

Idan ka na da da yawa na'urori, ka iya kopi backup fayil ɗin zuwa kowanne na'urar ka dawo da shi. Bayananka za su zama iri ɗaya a kowanne.
