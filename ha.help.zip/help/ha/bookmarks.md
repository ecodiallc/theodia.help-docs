---
title: Bookmarking Ayoyi
level: everyday
categories: [annotate, read]
summary: Yadda ake ajiye ayoyi don ka sami su gaba ɗaya.
---

# Bookmarking Ayoyi

> **Yanayi:** Bookmarks suna samuwa a cikin yanayin **Standard** da **Scholar**. Yanayin Focus don karatu mai tsafta kawai. Za ka iya canja yanayi a **Saitunan** → **Yanayin Mai Amfani da App**.

Bookmark yana ajiye aya ko sura na littafi don ka sami shi gaba ɗaya. Bookmarks kamar tabs ne a cikin littafi.

## Yadda ake bookmark aya

1. Bude aya.
2. Danna aya don fito da menun.
3. Danna **Bookmark** a cikin menu. Tauraron icon ya nuna aya an ajiye.

Alamar check akan icon tana nufin aya an ajiye.

## Yadda ake bookmark sura na littafi

Da kake karanta littafi (ba Littafi Mai Tsarki ba), za ka iya bookmark cikakken sura:

1. Bude sura.
2. Danna icon ɗin **Bookmark** a saman allon.

## Yadda ake ganin bookmarks

Danna tabon **Bookmarks** a kasa. Za ka ga jerin dukkan ayoyi da surori da ka ajiye.

## Yadda ake removing bookmark

- **Aya guda:** Bude aya. Danna aya, ka danna icon ɗin **Bookmark** gaba ɗaya. Alamar check za ta ɓace.
- **Daga jerun:** A cikin tabon **Bookmarks**, riƙe bookmark. Ƙaramin menun ya bayyana. Danna **Delete**. (Ka kuma iya danna ƙaramin button × akan row.)

## Tsara da babbar fayil

Za ka iya sa bookmarks a cikin babbar fayil. Misali, "Sermon Prep" da "Encouragement".

Don ƙirƙiri babbar fayil:

1. Bude tabon **Bookmarks**.
2. Danna **Manage Folders** a saman.
3. Danna **+ Create Folder** a saman jerun babbabn fayil.
4. Rubuta suna ka danna **Save**.

Ba za ka iya ƙirƙiri babbar fayil guda biyu mai suna ɗaya ba. Idan sunan ya wuya, kuskure ya bayyana cikin akwatin ƙirakhir don ka canja ka gwada gaba ɗaya.

Don sa bookmark a cikin babbar fayil:

1. A cikin tabon **Bookmarks**, riƙe bookmark.
2. Danna **Save to Folder**.
3. Zaɓi babbar fayil, ka danna **Done**.

## Shigo da bookmarks

Za ka iya kawo bookmarks a Theodia daga wasu apps da fayiloli.

Je zuwa **Saitunan** → **Bookmarks** → **Import Bookmarks**. Zaɓi **Import from File** ko liqa daga clipboard. App ɗin yana gane format ta atomatik.

### Formats da aka goyi

**Native JSON export** — Format da Theodia's export ke amfani. Ya ci gaba babbabn fayil da kwanan ƙirƙira.

**Netscape Bookmark HTML** — Format da Chrome, Firefox, da Safari ke amfani da ka export bookmarks. Babbabn fayil an ci gaba.

**CSV** — Spreadsheet ɗin columns. App ɗin yana neman columns `url` da `folder` (ko `href` / `category`). Misali:

```csv
url,folder
/bible/KJV/John/3,Favorites
/bible/KJV/Genesis/1,Sermon Prep
```

**Plain text** — Kowane line yana ko ayoyi, app URL, ko bayanin babbar fayil. Misali:

```
folder: Favorites
John 3:16
Genesis 1:1
folder: Sermon Prep
Matthew 5:1
```

- Lines ɗin da suka fara da `folder: <name>` suna sa babbar fayil mai aiki don bookmarks masu biyuki.
- Ayoyi kamar `John 3:16` ana juya zuwa bookmarks a cikin Littafi na farko na ka.
- App URLs kamar `/bible/KJV/John/3#v3_16` ko `/book/MyBook/1` ana shigo direct.
- Lines ɗin da suka fara da `#` ko `//` ana ɗaukar su comments, an ɓuncila.

### Tuni don shigo

- Duplicate bookmarks an ɓuncila ta atomatik.
- External URLs (kamar BibleGateway links) ana juya zuwa app bookmarks idan zai yiwu.
- Idan babbar fayil ɗin daga import file ta wuya, bookmarks an sa a cikin babbabn fayil mai wuya.

## Tips

- Za ka iya bookmark aya daya a tarhin da yawa. Dukkansa sun bayyana a cikin jerun.
- Bookmarks suna allon ka. Ba su sync zuwa cloud ba.
- Duba jagorar [Ajiye Bayananka](theodia://help/backups) don kiyayewa su.

## Bookmarks a cikin PDFs

PDFs suna da bookmarks ɗinsu, wadanda aka ke tsotses daga Bible bookmarks ka. Da kake karanta PDF, danna buton **Bookmark** a cikin toolbar na kaukarar ka ajiye shafin ya yanzu, ka ba da suna, kuma ka komawa zuwa gaba ɗaya. Kowanne PDF yana ajiye nasa jerun — duba [PDFs](theodia://help/pdfs).
