---
title: Zaɓar Model ɗin AI
level: advanced
categories: ai
summary: Yadda za a ɗauko model ɗin da yake aiki da kyau tare da ƙaddarorin gina cikin Theodia.
---

# Zaɓar Model ɗin AI

> **Yanayi:** Mataimakin AI yana bukatar yanayin **Scholar**. Za ka iya canja yanayi a **Saitunan** → **Yanayin Mai Amfani da App**.

Ba kowanne model ɗin AI ya aiki ɗaya ba a Theodia. Mafi kyawun gasa ya samu ne daga model ɗin da yake goyan bayan **tool calling** — ikon AI ɗin yin amfani da ƙaddarorin gina cikin Theodia kamar neman ayoyi, nema, karanta commentaries, da lilo a app ɗin.

## Me yake tool calling?

Da ka tambayi AI na Theodia, AI ɗin zai iya ψ (fiye da magana). Zai iya **yin aiki**. Misali:

- Ka ce, "Nuna mini John 3:16 a cikin ESV." AI ɗin ya kira tool ɗin yin budɔ ɗin aya a cikin kaukarar.
- Ka ce, "Menene commentaries dina ke cewa game da Romawa 8:28?" AI ɗin ya kira tool ɗin nemo commentary.
- Ka ce, "Ajiye wannan ayawan a matsayin bookmark." AI ɗin ya kira tool ɗin ƙirƙirar bookmark.

Models ɗin da ba su goyan bayan tool calling ba za su iya ba ka kawai text amsoshi ba. Ba za su iya nemo abu, lilowa, ko canja wani abu a cikin app ɗin ba.

## Waɗanne models suke goyan bayan tools?

### Models ɗin waje

Yawancin models ɗin waje na zamani daga masu samarwa masu girma suna goyan bayan OpenAI-compatible tool calling. Gaba ɗaya:

- **Models masu girma** (kamar GPT-4o, Claude Sonnet/Opus, Gemini Pro) suna kula tools ɗin da ƙware, suna iya ɗaurin calls da yawa a cikin conversation ɗaya. Sunan mai samarwa da model ID an nuna ne kawai don sauki; sabis ɗin da ka hadewa da key ɗin ka kuwa shi kuwa.
- **Models ƙanana ko masu araha** na iya goyan bayan tools amma ƙasa da ƙware. Za su iya mantawa da tool call ko format lafiya.
- **Models da ka sosai tsofa ko na musamman** sau manyan ba su goyan bayan tools ɗin haka ba.

Idan ka shakku, gwada model ɗin a cikin Theodia. Tambaye shi ka "Nuna mini Farko 1:1" ko "Nemo ayoyi game da so a Littafi." Idan aya ta buɗe ko sakamakon neman su faru, tool calling yana aiki.

## Models da aka ba da shawara don Theodia

Waɗannan zaɓi ne masu kyau ta haɗa kudin, quality, da goyan bayan tool:

- **OpenAI GPT-4o** — ƙwarewar tool support, sauri, yana kula da tambayoyi masu canjin multi-step.
- **Anthropic Claude Sonnet / Opus** — amintattun amfani na tool, ƙwarai da passages da karatu mai taken.
- **Groq** (models daban-daban) — sauri inference, sau manyan free ko ƙari mai araha, goyan bayan tool yana canji ta model.
- **OpenRouter** — yana sa ka gwada models da duki lu daba hani. Nemo models masu bayanin "function calling" ko "tools" a cikin shelves.
- **[GitHub Models](theodia://help/github-models)** — mai samar da free da aka ba da shawara. Samun duka zuwa OpenAI, Anthropic, da wasu models ta asusun GitHub ɗin ka tare da rana free tier mai yawa. Yana amfani da `openai/gpt-4o` style model IDs.

## Models don ɓuncila

- **Models na pure text-completion** (kamar GPT-3 base ko raw LLaMA ba tare da instruction tuning) sau da yawa ba su goyan bayan tools ɗin.
- **Models masu heavy a kan pictures ko vision** da aka mai da hankali akan pictures maimakon text na iya rashin goyan bayan tool.
- **Models masu ƙanana sosai** a ƙasa da 1 biliyan paramters bai zama su iya amfani da tools ɗin daidai, ko da API ɗin ta ce suke goyan bayan.

## Yadda ake gwada goyan bayan tool

Theodia yana dubawa goyan bayan tool ta atomatik. Bayan ka saita model ɗin a **Saitunan → Mataimakin AI**, denna **Gwada connection**. Da kuma connection ya yi sauki, app ɗin ya tura request ɗin a biyu tare da sample tool definition. Za ka iya ganin ɗaya daga cikin su sakamako:

- **✓ Tools suna samuwa** — Model ɗin yana karɓe tool calls kuma zai iya amfani da ƙaddarorin Theodia.
- **✗ Tools ba a samu ba** — Model ɗin ya ni text kawai kuma ba zai iya budɔ ayoyi, nema, ko sarrafa bookmarks ba ka.

Idan ka ga "Tools ba a samu", model ɗin da mai zai iya aiki a matsayin plain text chat assistant, amma ba ka samar da gasa ta ɗauri, ba tare da hannu ba.

Ka kuma iya tabbatar da manual da ka tambayi AI ɗin ya yi wani abu:

- "Nuna mini Mathu 5:3 a cikin KJV." — Ya kamata ya budɔ aya a cikin kaukarar.
- "Menene lexicon ke cewa game da kalmar 'agape' a cikin John 3:16?" — Ya kamata ya mayar da lexicon data.
- "Nemo ayoyi game da gafartawa." — Ya kamata ya mayar da sakamako.
- "Bookmark Mark 12:30." — Ya kamata ya ƙirƙiri bookmark.

Idan AI ɗin ya ba ka bayani a rubutu maimakon yin abin, model ɗin yana fama da amfani da tools ɗinsa ko da app ɗin ta bayanin support.

## Me za a yi idan model ɗinka ba ya goyan bayan tools?

Ka iya kawai amfani da ita. AI ɗin zai amsa a cikin text, kuma za ka iya manually nemo ayoyi, nema, da lilo a app ɗin ka. Amma ba ka samu gasa mai ɗauri, ba tare da hannu ba wanda ya sa Theodia ƙwazo.

## Taƙaitawna

- Zaɓi model ɗin mai **tool calling / function calling** support don mafi kyawun gasa na Theodia.
- **Models masu girma na waje** suna kula tools ɗin da amincewa.
- Gwada kowanne model ɗin tare da sa'a commands kamar "Nuna mini Farko 1:1" don tabbatar goyan bayan tool.
