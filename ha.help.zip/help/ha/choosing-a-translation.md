---
title: Zaɓar Tarhin Littafi
level: beginner
categories: [read, study]
summary: Jagora mai alayya ta yau da kullum game da zaɓar tarhin da ya dace maka.
---

# Zaɓar Tarhin Littafi

Tarhin Littafi shine ƙoƙarin wani mutum don sa Littafi cikin kalmomin da za ka iya karantawa. Tarhin da yawa suna sauti daban-daban. Wasu tarhin kalmomi-watan-kalma ne. Wasu tarhin tunani-watan-tunani ne. Babu ra'ayi na ƙarshe. Zaɓi wanda reads ko mafi kyau maka.

## Nau'i biyu na Aiki

**Tarhin kalmomi-watan-kalma** (word-for-word) yana ƙoƙari ya riƙe same kalmomin kamar da harshen asali (Ibrananci da Girkanci). Zai iya zama wuya a karanta amma yana kusa da source. Misali: KJV, WEB.

**Tarhin tunani-watan-tunani** (thought-for-thought) yana ƙoƙari ya sa ma'ana na asali cikin kalmomin da mutane ke amfani a yau. Sauki a karanta. Misali: BSB, UST.

## Wasu tarhin da ba kammala ba

- **KJV (King James Version).** Salo Ingilishi tsofa. Mutane da yawa suna ganin ƙauna.
- **WEB (World English Bible).** Kalmomi-watan-kalma. Ingilishi na zamani mai public domain.
- **BSB (Berean Standard Bible).** tunani-watan-tunani. Sauki a karantakar.
- **UST (unfoldingWord Simplified Text).** tunani-watan-tunani. Amfani da Ingilishi mai sauƙi, mai iya.

## Yadda ake gwada ɗaya

Ka iya install tarhin da yawa da ka ke so. Karanta aya ta same a cikin biyu ko uku. Duba wanda yake taimaka maka mafi.

## Yadda ake kwatanta

Bude sura, kuma tap sunan tarhin a saman don canja. Wuri Wane na **Kwatanta** (duba jagorar [Kwatanta Tarhin](theodia://help/compare-translations)) yana nuna tarhin biyu na jikin kogin.
