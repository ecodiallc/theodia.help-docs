---
title: Commands
level: everyday
categories: [layout, study]
summary: Command input yana sa ka tsallake zuwa kowanne feature ta rubuta short command. Koyi supported formats da misali.
---

# Commands

**Command** input yana sa ka tsallake zuwa kusan kowanne ɓangaren Theodia ta rubuta short instruction. Zaka iya amfani da ita daga Home tab ko daga **Launcher Menu** (icon ɗin **▼** a header).

## Yadda yake aiki

1. Danna akwatin Command.
2. Rubuta command.
3. Danna key ɗin go a kan keyboard.

App ɗin ya karanta command ka ka tafi kuwa zuwa screen ɗin daidai.

## Babu slash prefix

Commands ba su yi amfani da `/` prefix. An shigar su a matsayin rubutun sunnah:

```
john 3:16
search love
backup
```

Idan ka rubuta `/settings`, leading `/` zai mayar da shi unrecognizable.

## Ayoyi na Littafi

Rubuta kowanne nassararar Littafi don buɗe a cikin kaukarar.

```
psalms 23
john 3:16
matthew 5:1
1 cor 15:10
```

Sunayen littafi za a iya dace ta cikakken suna ko abbreviation. A cikin harsunan UI na farin waje za ka iya rubuta sunayen littafi a harshe mai aiki.

## Nema

```
search abraham
search love
search faith not works
```

## Bookmarks, kwatanta, commentary, suniyyun, da word info

```
bookmark john 3:16
compare genesis 1:1
commentary john 1
aicommentary eph 2:8
xref 1 cor 15:10
word info john 1:1
```

Wadannan commands suna budɔ instrument da sunan passage.

## Lexicon

Rubuta Strong's number don budɔ lexicon entry.

```
g1161
h7225
```

## Devotionals

```
devotional
devotional smith
devotional daily
```

Ba tare da suna ba, wannan yana budɔ jerin devotional.

## Shortcuts na navigation

```
notes
highlights
bookmarks
flashcards
playlist
theoscript
resources
read john 3:16
```

Wadannan suna tsallake streaming zuwa screen ɗin da sunan ko buɗe passage a cikin kaukarar.

## Canja tarhin

Rubuta abbreviation tarhin don canja zuwa gare shi.

```
kjv
web
trlit
ohgb
```

A kan screen kaukarar, tarhin yana canja a wurin. A waniwani, yana buɗe tarhin a passage ɗin da ka haɗa na baya.

## Kalmomin command da aka fassara

Kalmomin command da aka sani za a iya rubuta su a cikin harshen UI mai aiki **ko** Ingilishi. Ingilishi yana aiki koyaushe a matsayin fallback. Kalmomin da su ke ɓoye (settings shortcuts, install commands, Easter eggs) keta kalmomin Ingilishi kawai.

## Taimako

Rubuta `help` ko `commands` a cikin Command box don budɔ in-app command reference a kowanne lokaci.
