---
title: Commentaries da Lexicons
level: everyday
categories: study
summary: Yadda ake nemo ma'anar kalma da karanta bayanin karatu.
---

# Commentaries da Lexicons

> **Yanayi:** Commentaries da lexicons suna bukatar yanayin **Scholar**. Za ka iya canja yanayi a **Saitunan** → **Yanayin Mai Amfani da App**.

Theodia tana da ƙaddarorin karatu biyu: **commentaries** da **lexicons**. Sune suna taimaka ka ka fahimci Littafi Mai Tsarki a ƙuƙwarma.

## Menene commentary?

Commentary shine littafin bayanin karatu da  masanin Littafi ya rubuta. Ga aya da ka ba, commentary tana fada ta gano bayot, ma'ana, da yadda aya ta dace a cikin sauran Littafi.

## Menene lexicon?

Lexicon shine dictionary na kalmomin Littafi. Yana fada maka kalmar Ibrananci ko Girkanci na asali, ma'ana, da yadda aka yi amfani da ita a cikin Littafi.

## Yadda ake budɔ commentary

1. Bude sura.
2. Danna aya.
3. Danna **Commentary**.

Panel ya buɗe. Yana nuna bayanin  masanin Littafi game da wannan aya.

## Yadda ake budɔ lexicon

1. Bude sura a cikin Littafi da ya ƙunshi Strong's numbers.
2. Danna Strong's number a cikin aya (misali, G1234 ko H1234).
3. Panel ya buɗe ya nuna kalmar Ibrananci ko Girkanci, ma'ana, da wasu ayoyi masu amfani da kalmar.

Strong's numbers sun bayyana a cikin launi daban daga regular words don su tsayar.

## Zaɓi commentary daban

Commentary ana zaɓi daga dropdown a saman paneli commentary ɗin kanta. Budɔ panel, ka danna dropdown don nemo commentaries ɗin da ka install. Zaɓi daban.

## Zaɓi lexicon daban

Lexicon ana zaɓi daga dropdown a saman paneli lexicon ɗin. Budɔ panel, ka danna dropdown don nemo lexicons ɗin da ka install. Zaɓi daban.

## Kayan gina cikin

Theodia tana tare da built-in set na commentaries da lexicons. An ƙunsa su cikin app ɗin kuma suna aiki offline. Karin commentaries da lexicons ba za a iya install ko download gaba daban ba.

## Səina lokaci

- **Commentaries** na kyau ne lokacin da aya ya sauri ga fahimta. Bayani ɗin sun ba da bayani.
- **Lexicons** na kyau ne don karatun kalma. Suna fada daidai ma'ana na kalma a harshen asali.

## Tuni

Idan ka kara bayanin da ka ke so ka rike, ka ɗauki screenshot ko ka kopi rubutun a cikin bayananka. (Duba jagorar [Bayanai](theodia://help/notes).)

## Bible Dictionary mai harshen plain

Don ma'anar kalmar Turanci na kalmar  Littafi da concepts (covenant, atonement, Farisawa, da dai sauransu), Theodia kuma tana da Bible Dictionary tool. Budɔ shi daga menun aya ta danna **Dictionary** (📖). Yana bambanta da lexicon: lexicons suna bayyana kalmomin Ibrananci da Girkanci, yayin da dictionary yana bayyana kalmar Ingilishi a harshen plain. Duba jagorar [Bible Dictionary](theodia://help/dictionary) don amfani.
