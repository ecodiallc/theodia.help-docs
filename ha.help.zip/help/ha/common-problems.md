---
title: Abubuwan da ake Kenan
level: everyday
categories: trouble
summary: Sauƙaƙewa don matsalolin da za ka iya ci karo.
---

# Abubuwan da ake Kenan

Wannan jagora tana rufe matsalolin da mutane suke ci karo da su sau ɗaya. Idan matsalanka ba ta nan, duba jagorar [Inda ake tambayayyar](theodia://help/getting-more-help).

## App na jinkiri

1. Rufe wasu apps ɗin da ke yin aiki a background.
2. Restart app ɗin.
3. Restart na'urarka.

## Ban iya samun tarhin Littafi

1. Bude **Saitunan** → **Manage Resources** don nemo abin da aka install.
2. Idan tarhin ba ya nan, danna **Install from GitHub**.
3. A cikin download modal, danna tabon **Bibles** (ko **Global Bibles**) ka zaɓi tarhin da ka ke so.
4. Danna **Install Selected** ka jira download ya ƙarshe.
5. Ka bukata intanet don download tarhin sabo.

## Bayanaina ko bookmarks na bata

1. Duba ka ko ka d)}> a ƙTabo ɗin daidai. Bayanai a cikin tabon **Bayanai**. Bookmarks a cikin tabon **Bookmarks**.
2. Idan ka sabunta backup kwanan nan, backup ya iya maye bayananka. Duba ranar backup ɗin.
3. Idan ka uninstall ka reinstall app ɗin, bayananka sun ɓace. Tura ta, yi backup da farko.

## Nema ba ya samun ayoyi

1. Duba ka ka rubuta kalmar daidai.
2. Gwada ƙaramin kalma. "So" yana samun ƙari ayoyi fiye da "mai so."
3. Duba ka ka da tarhin daidai da aka install. Nema yana aiki kawai a cikin tarhin da ka mallaka.

## Read-aloud ba ya aiki

1. Duba kada na'urarka ya yi ƙasa.
2. Duba app ɗin an ba shi damar amfani da speaker.
3. Gwada tarhin daban. Wasu tarhin suna aiki da kyau sms sauti fiye da wasu.
4. Don checklist ta mataki, duba jagorar [Karanta da Murya](theodia://help/tts).

## App ta kwakomore

1. Restart app ɗin.
2. Restart na'urarka.
3. Idan matsalar ta ƙare, report a. Duba jagorar [Inda ake tambayayyar](theodia://help/getting-more-help).

## Ina son uninstall app ɗin

Za ka iya uninstall Theodia kamar kowanne app. Kafin ka yi gayon, yi backup bayananka. Abata uninstall, bayanin ka  kan na'urarka ya ɓace.

## Har yakkin matsala?

Duba jagorar [Inda ake tambayayyar](theodia://help/getting-more-help). A nan za ka sami links don report matsala da tambayar al'umma.

Za ka iya nemo help guides daga **Help & Guides** main screen. Rubuta kalmar kamar `notifications`, `search`, ko `bookmarks` don nemo matching guide.
