---
title: Kwatanta Tarhin
level: everyday
categories: [read, study]
summary: Yadda ake ganin aya ɗaya a cikin dukkan tarhin da ka install.
---

# Kwatanta Tarhin

> **Yanayi:** Wuri Wane na Kwatanta yana samuwa a cikin yanayin **Standard** da **Scholar**. Yanayin Focus don karatu mai tsafta kawai. Za ka iya canja yanayi a **Saitunan** → **Yanayin Mai Amfani da App**.

Wuri **Wane** na kwatanta yana nuna aya guda a cikin dukkan tarhin Littafi da ka install a cikin one panel. Yana yi da kyau lokacin da ka ke so ka ga yadda translators da yawa sun yi da aya mai wuya, ko lokacin da ka ke zaɓar tarhin ka ke so ka duba aya ta same a cikin kowanne.

## Yadda ake budɔ Kwatanta

1. Bude sura a cikin hold tarhin.
2. Danna aya don fito da menun aya.
3. Danna **Kwatanta** (⇄).

Panel ya buɗe. Title bar yana nuna nassarar (misali, "John 3:16 — Kwatanta"). Panel ɗin yana loda aya ta same a cikin dukkan tarhin da ka install. Tarhin ka mai aiki an jira da farko; sauran suna  sorted alphabetically.

## Ta yaya panel ɗin yake kama

Panel ɗin **jerun jikin** ne, ba column jikin kogin. Kowane row shine ɗaya tarhin:

- **Sunan tarhin** (misali, "KJV") a saman row. Yana to  touch.
- **Rubutun aya** a ƙarƙashin suna.

Salki panel ɗin don nemo dukkan tarhin. Dukkan tarhin da aka install a kan na'urarka za su bayyana a nan. Idan tarhin ba ya da surar ko aya, an ɓoye.

## Yadda ake karantun aya a cikin tarhin daban

Touch sunan tarhin a cikin row. Panel na Kwatanta ya rufe kuma sura ta same ta buɗe tare da aya da ka zaɓa a cikin wannan tarhin. Wannan ita ce hanyar da sauri a tsallake daga kwatanta zuwa karantun tarhin da ka zaɓa.

## Yadda ake rufe Kwatanta

- **A kan wayar:** danna X a saman dama na panel.
- **A kan tablet:** danna X a kan header na panel, ko touch bayanin panel.

Ka koma cikin cikakken karatun a cikin tarhin asalin ka.

## Səina lokaci

- **Zaɓar tarhin.** Budɔ aya da ka sani a cikin tarhin ka na yanzu, kuma Kwatanta don nemo ta cikin wasu. Rikicewa suna ɗaukaka.
- **Ayoyi masu wuya.** Aya da suka rikice a cikin ɗaya tarhin yawanci suna haske a cikin ɗaya.
- **Karatun kalma.** Duba yadda translators da yawa sun yi da key word ko phrase.
- Don kwatance na whole sura a cikin tarhin da yawa a ɗaya, yi amfani da **parallel view** kawai. Duba jagorar [Study Mode](theodia://help/study-mode) don yadda ake kunna sa.
