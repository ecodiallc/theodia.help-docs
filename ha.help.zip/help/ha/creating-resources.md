---
title: Ƙirƙirar Kayan Hadinka
level: advanced
categories: resources
summary: Yadda ake ƙirƙirar Bibles da aka ƙirƙiro, commentaries, littattafai, devotionals, da lexicons ka shigo su cikin Theodia.
---

# Ƙirƙirar Kayan Hadinka

Theodia tana goyon bayan custom resources a cikin Unique Bible App format. Kowane resource yana zana SQLite file mai specific table structure. Ka iya ƙirƙirar wadannan files a kan computer ka ka shigo su cikin app ɗin.

## Nau'in file da tables masu buƙata

### Bibles (`.bible`)

Bible file shine SQLite database mai a kalla ɗaya daga cikin wadannan tables:

- **`Verses`** — columns: `Book` (integer, 1-66), `Chapter` (integer), `Verse` (integer), `Scripture` (text)
- **`Bible`** — columns: `Book` (integer), `Chapter` (integer), `Verse` (integer), `Scripture` (text)

Ka iya ƙunsa **`Details`** table mai metadata columns kamar `Description`, `Abbreviation`, da `Version`.

Misalin SQL:

```sql
-- Main text table
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- Optional metadata table
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### Commentaries (`.commentary`)

Commentaries sun zo da nau'i uku: **book**, **chapter**, da **verse**. Nau'in ya karimages ta **kudin harafin filename**.

#### Book commentaries — filename yana fara da `b`

Book commentary yana rufe littafi gaba daya a cikin entry guda. `Commentary` table yana bukatar columns `Book` da `Scripture` (ko `Content`). Babu bukatar `Chapter` ko `Verse` columns.

- **`Commentary`** — columns: `Book` (integer), `Scripture` (text) ko `Content` (text)

Misalin SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

Misalin filename: `bMyCommentary.commentary`

#### Chapter commentaries — filename yana fara da `c`

Chapter commentary yana rufe kowanne sura na littafi Littafi.

- **`Commentary`** — columns: `Book` (integer), `Chapter` (integer), `Scripture` (text) ko `Content` (text)

Misalin SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

Misalin filename: `cMyCommentary.commentary`

#### Verse commentaries — filename yana fara da `v`

Verse commentary yana rufe ayoyi da ɗaya-rabin. `Commentary` table yana bukatar columns `Book`, `Chapter`, `Verse`, da `Scripture` (ko `Content`).

- **`Commentary`** — columns: `Book` (integer), `Chapter` (integer), `Verse` (integer), `Scripture` (text) ko `Content` (text)

Misalin SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

Misalin filename: `vMyCommentary.commentary`

### Littattafai (`.book`)

Littafi file shine SQLite database mai `Reference` table.

- **`Reference`** — columns: `id` (integer), `Chapter` (text), `Content` (text)

Kowane row shine sura guda. Column `Chapter` shine taken sura. Column `Content` shine body na sura, ko ya ƙunshi HTML (`<b>`, `<i>`, `<br>`, da sauransu).

Misalin SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

Ka kuma iya ƙirƙirar littattafai daga Markdown files. App ɗin zai iya shigo `.md` files wanda `#` shine taken littafi da `##` ke nuna surori. Markdown na canza zuwa HTML ta atomatik.

### Devotionals (`.devotional`)

Devotional file shine SQLite database mai `devotional` table.

- **`devotional`** — columns: `month` (integer, 1-12), `day` (integer, 1-31), `devotion` (text)

Kowanne row shine karantun rana. App ɗin yana nemo entry ta ranar yau.

Misalin SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### Lexicons (`.lexicon`)

Lexicon file shine SQLite database mai `Lexicon` table.

- **`Lexicon`** — columns: `Topic` (text, Strong's number), `Definition` (text, lexicon entry)

Column `Topic` yana riƙe Strong's number (misali, `G1161` ko `H7225`). Column `Definition` yana riƙe cikakken entry, wanda zai iya ƙunshi HTML.

Misalin SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

Lexicons suke kunna Word Info tool. Da ka touch kalma a cikin interlinear Bible, app ɗin yana nemo Strong's number a cikin installed lexicons.

## Ƙirƙirar file a kan computer

1. Install SQLite editor (DB Browser for SQLite, SQLiteStudio, ko `sqlite3` command-line tool).
2. Ƙirƙiri sabon database file.
3. Ƙirƙiri required table ka insert bayanaka.
4. Ajiye file tare da correct extension (`.bible`, `.commentary`, `.book`, `.devotional`, ko `.lexicon`).

## Shigo a cikin Theodia

1. Ka matsar file zuwa na'urarka (AirDrop, email, cloud storage, ko USB).
2. Bude **Theodia**.
3. Je zuwa **Saitunan** → **Manage Resources**.
4. Danna **Import from File**.
5. Zaɓi file ɗinka.

App ɗin yana validate file ɗin (yana dubawa required table), ya kopi zuwa data folder na app ɗin, ya kunna ta atomatik. Idan file ɗin yana invalid, za ka ga error message bayanin abin da ya gaza.

## Limitations

- Ba za ka iya maye built-in resources ba. Idan ka gweje ka shigo file da same suna kamar built-in Bible, commentary, ko book, import yana ɗasu.
- Bible files suke bukatar `Verses` ko `Bible` table. Idan haka babu, import yana ɗasu.
- Commentary files suke bukatar `Commentary` table.
  - Book commentaries suna bukatar columns `Book` da `Scripture` (ko `Content`).
  - Chapter commentaries suna bukatar columns `Book`, `Chapter`, da `Scripture` (ko `Content`).
  - Verse commentaries suna bukatar columns `Book`, `Chapter`, `Verse`, da `Scripture` (ko `Content`).
- Book files suke bukatar `Reference` table.
- Lexicon files suke bukatar `Lexicon` table.
- Devotional files suke bukatar `devotional` table.

## Tuni

- Rika bayan fayloli dandamali. SQLite files masu girma na iya saba memory a kan na'urori da suka tsofa.
- Gwada fayl ɗinka a kan computer da farko. Budɔ shi a cikin SQLite browser ka run `SELECT * FROM` required table don tabbatar bayanuka ya kama na gaskiya.
- Don Bibles, tabbatar column `Book` yana amfani da lambobi (1 = Farko, 66 = Apokalipsis).
- Don Commentaries, ka iya amfani ko `Scripture` ko `Content` a matsayin commentary text column.
- Don Littattafai, HTML a cikin column `Content` ana render da kake karanta. Riƙi shi mai sauki: `<b>`, `<i>`, `<br>`, da `<hr>` suna safe.

## A ina za a samu existing resources

Theodia da iya karanta resources daga [Unique Bible App](https://github.com/eliranwong/UniqueBible) project. Many Bibles, commentaries, littattafai, da sauran resources suna samuwa a nan a cikin correct SQLite format. Duba jagorar [Getting Extra Resources](theodia://help/getting-core-files) don yadda za a samu ka kara.
