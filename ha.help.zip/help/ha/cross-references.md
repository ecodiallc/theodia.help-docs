---
title: Suniyyun giciye
level: everyday
categories: study
summary: Yadda ake samun ayoyi da suke dangunta da aya da ka ke karantawa.
---

# Suniyyun giciye

> **Yanayi:** Suniyyun giciye suna samuwa a cikin yanayin **Standard** da **Scholar**. Yanayin Focus don karatu mai tsafta kawai. Za ka iya canja yanayi a **Saitunan** → **Yanayin Mai Amfani da App**.

"Suniyyar giciye" shine wata aya da ta ke magana akan abu daya da aya da ka ke karantawa. Panel ɗin suniyyun giciye yana nuna maka wadannan ayoyi masu danganta.

## Yadda ake budɔ suniyyun giciye

1. Bude sura.
2. Danna aya don fito da menun aya.
3. Danna **Cross References**.

Panel ya buɗe. Yana nuna jerin wasu ayoyi masu danganta da wannan da ka touch.

## Yadda ake karantun jerun

Kowanne row shine ɗaya aya mai connecting. Ka ga:

- Littafi, sura, da aya.
- Ƙaramin preview na rubutun aya.
- Score mai nuna ƙarin ƙetaren connection ɗin.

## Yadda ake tsallake zuwa aya mai connecting

Danna wani row. App ɗin ya buɗe wannan aya. A nimsaanar, danna back button don koma.

## Menene score?

Score yana fada maka yadda aya suna close. High score yana nufin strong, direct connection. Low score yana nufin loose connection.

## Yi amfani da suniyyun giciye don karatu

Suniyyun giciye na yi da kyau don:

- **Karatun kalma.** Ga yadda Littafi yake amfani da kalma a manyan wurare.
- **Karatun jigogi.** Bin theme, kamar "so" ko "alkawari," ta cikin Nassara.
- **Shirin wa'azi.** Sami ayoyi masu  transverse da sanye.

## Tuni

Suniyyun giciye suna aiki mafi kyau tare da word-for-word translation kamar WEB.
