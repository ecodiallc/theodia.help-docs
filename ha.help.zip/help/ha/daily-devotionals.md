---
title: Devotionals na Yau da Kullum
level: everyday
categories: [content, read]
summary: Yadda ake karanta devotional mai karami a kowanne rana.
---

# Devotionals na Yau da Kullum

Devotional shine ƙaramin karantun domin rana. Sau da yawa yana da aya, ƙaramin thought, da tambaya don ka yi tunani akan ta. Theodia tana zuwa tare da small library na devotionals.

## Yadda ake budewa devotional

1. Danna tabon **Devotionals** a kasa ta allon.
2. Za ka ga jerin devotional da aka install a kan na'urarka.
3. Danna ɗaya don budewa.

## Yadda ake karanta devotional

1. Budɔ devotional ɗin.
2. Salki don karatu.
3. Yi amfani da buttons ɗin a saman don:
   - Tap the **date** don tsallake zuwa rana daban.
   - Tap the **star** don bookmark rana.
   - Tap the **speaker** don karanta shi loud (idan na'urarka ta goya sauti). Duba jagorar [Karanta da Murya](theodia://help/tts) don yadda ake zaɓar murya.
   - Tap **Previous** ko **Next** don matsa zuwa rana da ka addar ko gaba.

## Yadda ake ajiye aya daga devotional

1. Budɔ devotional ɗin.
2. Danna aya.
3. Danna **Bookmark** ko **Highlight**.

Aya ta ajiye a cikin Bookmarks ko Highlights naka.

## Yadda ake rubuta bayanin game da devotional

1. Budɔ devotional ɗin.
2. Danna aya.
3. Danna **Note**. Rubuta tunanika ko addu'arka. Danna **Save**.

Bayanin ya bayyana a cikin Notes tab ɗinka.

## Tips

- Devotionals ba sa bukatar intanet. Sune aiki offline.
- Idan ka ke so ka ƙara devotionals, duba jagorar [Getting Extra Resources from GitHub](theodia://help/getting-core-files).
