---
title: Kamus na Littafi Mai Tsarki
level: everyday
categories: study
summary: Nemo ma'anar kalmomin Littafi Mai Tsarki da ra'ayoyi acikin albarkatun kamus da aka shigar. Bude shi daga menu na ayarsa ko daga rubutun lexicon, sannan danna kowane kalma domis ganin wannan kalma a kowane kamus.
---

# Kamus na Littafi Mai Tsarki

> **Yadda za a yi:** Kamus na Littafi Mai Tsarki yana bukatar **Yanayin Malami (Scholar)**. Za ka iya canja yanayoyi a **Saituna** → **Yanayin Mai Amfani na App**.

Kamus na Littafi Mai Tsarki yana nemo kalma ko jumla a kowane albarkatun kamus da ka shigar. Yana amfani idan kana so ka sami ma'ana ta saukin fahimta na kalmar Littafi Mai Tsarki, bayanin mutum ko wuri, ko takaitaccen makala game da ra'ayin tauhidi.

Kamus ya bambanta da kayan aiki na **Bayanin Kalma (Word Info)**, wanda yake nemo kalmar Hebrew ko Girkanci ta asali a bayan ayarsa. Kamus yana karantun kalmar **Turanci** da ka danna sannan ya nuna maka abin da kamus din da ka shigar ke cewa game da ita. Don bayanan fassarar Littafi Mai Tsarki kalma da kalma, duba jagorar [Sharhin Babi da Lexicon (Commentaries and Lexicons)](theodia://help/commentaries-and-lexicons).

## Yadda ake bude Kamus

Akwai hanyoyi biyu na bude kamus.

### Daga menu na ayarsa

1. Bude sura a [Yanayin Karatu (Study Mode)](theodia://help/study-mode).
2. Danna ayarsa don bude menu na ayarsa.
3. Danna **Dictionary** (📖).

Panel ya bude wanda aka yi masa lakibi da nassarar ayarsa (misali, "John 3:16"). Rubutun ayarsa yana a saman tare da kalmomi masu danna kowa. A kasa da ayarsa wata layin chips suna nuna kowane kamus da aka shigar. A kasa da haka ma'anarsa ce, wacce za ta zama babu komai har sai ka danna kalma.

### Daga rubutun lexicon

Lokacin da kake karanta rubutun lexicon a cikin panel na Word Info, wasu rubutun suna ƙunshe da hanyoyi masu launin shuɗi zuwa makalolin kamus masu alaka. Danna kowane daga cikin wadancan hanyoyin. Lexicon din yana rufe kuma kamus yana budewa a wancan makala. Wannan shi ne hanyar da ta fi sauri na tsallakewa daga kalmar Girkanci ko Hebrew zuwa bayanin saukin fahimta na abin da take nufi.

## Yadda taga na ayarsa ke aiki

Lokacin da ka bude kamus daga menu na ayarsa, ayarsa ta bayyana a saman panel a matsayin jerin kalmomi masu danna. Kalmomin Turanci na yau da kullum kamar "the," "and," "of," "to," da "a" ba su da danna. Kowane kalma ta wuce haka take. Kowane kalma mai danna tana da launi da bold domin ta fito daga sauran ayarsa.

Danna kowane kalma a cikin ayarsa. Theodia yana bincika kowane kamus da aka shigar don daidaitaccen match na wannan kalma. Layin chips a kasan ya sabunta don nuna waɗanne kamus suna da rubutu: kamus din da ba su da rubutu na wannan kalmarsa suna ƙarewa. An zabi kamus na farko da ya da rubutu ta atomatik, kuma ma'anarsa tana bayyana a kasa da layin chips.

Kalmar da ka danna tana nuna a cikin rubutun ayarsa a saman panel, don haka koyaushe ka sani abin da kake bincikarsa.

## Canjawa tsakanin kamus

Kowane kamus da aka shigar an nuna shi a matsayin karamin chip a kasa da ayarsa. Bayan danna kalma:

- **Chip mai launin kauri** — wannan kamus yana da rubutu na kalmar da ka danna. Danna shi don canjawaa zuwa ma'anarsa ta wancan kamus.
- **Chip mai ƙarewa** — wannan kamus ba shi da rubutu na waccan kalma. An nuna shi cikin grey domin ka iya ganin a idanatawa waɗanne kamus suke rufe kalma, kuma chip ba za a iya dannawa ba.

An haskaka kamus da aka zaba. Danna wani chip mai kauri don karanta wannan kalma a wancan kamus. Ma'ana a kasa tana sabunta nan take.

Idan kalmar tana wanzu a kamus guda daga cikin wadanda ka shigar, chip guda ce kawai mai kauri kuma sauran suna ƙarewa.

## Abin da panel yake nuna

Panel na kamus yana da sassa uku, daga sama zuwa kasa:

- **Ayarsa** — ayarsa da ka bude kamus daga cikinta. Kalmomi suna da danna, kuma kalmar da ka danna karshe tana nuna.
- **Layin chips** — kowane kamus da aka shigar. Mai kauri yana nufin "yana da rubutu na kalmar da aka danna." Mai ƙarewa yana nufin "babu rubutu na waccan kalma."
- **Ma'ana** — makala daga kamus da aka zaba. Rubutu na yau da kullum, an tsara shi da sakin layi da headings. Hanyoyin cikin gida zuwa wasu rubutun kamus suna da danna; danna daya daga cikinsu yana bude wancan rubutu a kamus.

## Abin da yake faruwa idan ba a samo rubutu ba

Idan ka danna kalmar da babu daya daga cikin kamus din da ka shigar ya rufe, panel ya nuna takaitaccen saƙo na "babu rubutun da aka samo" maimakon ma'ana. Wannan yana yawan faruwa ga kalmomi na yau da kullum kamar "shekara" ko "zo" waɗanda ba su zama kalmomin Littafi Mai Tsarki na tauhidi ba, kodayake suna bayyana a ko'ina a cikin Littafi Mai Tsarki. Gwada kalma ta musamman, ko amfani da kayan aiki na Word Info na lexicon maimakon, wanda yake aiki akan rubutun asalin Girkanci da Hebrew.

## Abin da yake faruwa idan ba a shigar da kamus ba

Kamus yana bukatar a kalla daya tilo fayil din kamus don ya zama mai amfani. Theodia yana isar da daya. Idan ka cire shi ko kana gudanar da shigarwa ta musamman ba tare da kamus ba, taga na ayarsa har yanzu yana bayyana kuma kalmomi har yanzu suna da danna, amma layin chips yana babu komai kuma kowane bincike yana mayar da "babu rubutun da aka samo."

Ba za a iya shigar da wasu kamus dabam dabam.

## Tukuna

- Kamus yana bincika **daidaitaccen match na kalma**. Danna "love" yana samun rubutun da aka yi wa lakibi "love" amma ba "loved" ko "loving." Domin nemo kalmarsa mai alaqa, amfani da kayan aiki na Word Info na lexicon akan kalmar Girkanci ko Hebrew.
- Layin chips yana kasane a wayar da talet. A talet kamus yana budewa a matsayin panel ta gefe a kusa da sura; a wayar yana budewa a matsayin full-screen modal. Dukansu suna da wannan tsarin sassa uku.
- Danna kalma a ayarshara ta bude sabuwar ayarsa a panel. An share zabin baya. Danna kalma a sabuwar ayarsa don fara sabon bincike.
- Wasu rubutun kamus suna tunawa da wannan kalma a wani kamus dabam. Danna waɗancan hanyoyin cikin gida don bin hanya a cikin kowane kamus din da ka shigar.

## Bambanci tsakanin Kamus da Word Info

Kayan aiki biyu suna budewa daga menu na ayarsa, amma suna yin wani abu dabam:

- **Kamus** (📖) yana karantun kalmar Turanci da ka danna kuma yana nemo ta a kamus din Turanci da ka shigar. Ita ce kayan aiki mai daidai don ma'anar saukin fahimta na kalmomin Littafi Mai Tsarki na tauhidi kamar "covenant," "atonement," ko "Pharisee."
- **Word Info** (?) yana karantun kalmar Girkanci ko Hebrew ta asali a bayan ayarsa kuma yana nemo ta a lexicon din da ka shigar. Ita ce kayan aiki mai daidai don nazarin kalma mai zurfi, neman kowane wuri da kalmar Girkanci take, da karantun ma'anar asalin harshe.

Idan kana da shakku, fara da kamus. Idan kana so ka binciko asalin harshe, canja zuwa Word Info. Duba jagorar [Sharhin Babi da Lexicons (Commentaries and Lexicons)](theodia://help/commentaries-and-lexicons) domin cikakken walkthrough na Word Info.
