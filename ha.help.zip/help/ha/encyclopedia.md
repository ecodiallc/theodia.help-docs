---
title: Encyclopedia
level: everyday
categories: study
summary: Yadda ake nemo makalolin encyclopedia da binne yawancin ayyukan referens.
---

# Encyclopedia

Theodia ya ƙunshi **Encyclopedia** mai gini cikin don neman makalolin da suka shafi Littafi Mai Tsarki, mutane, wuriye, da batutuwa. App din yana isar da *Kitto's Illustrated Commentary* (KIT) mai gini, kuma za ka iya saukar da wasu encyclopedias daga repository.

## Menene encyclopedia a cikin Theodia?

Encyclopedia yake wani aikin referens da ya ƙunshi makaloli takaitacce. Kowane makala yana rufe mutum, wuri, taro, ko batun Littafi Mai Tsarki. Daban da sharhi, wanda yake bayyana ayarsa ta musamman, makalar encyclopedia yana bayyana batun da kansa.

## Yadda ake bude Encyclopedia

1. Danna **Encyclopedia** a cikin inuwar buttons na kasa.
2. Zabi encyclopedia daga layin rage-abbreviations a saman.
3. Rubuta batun, mutum, ko wuri a cikin search box.

Bincike yana bukatar a kalla **haruffa 3** kafin sakamakon da autocomplete suggestions su bayyana.

## Karantun makala

- A **wayar**, danna sakamako don bude makala a sabon screen.
- A **talet**, makala tana budewa a panel na dama yayin da jeri yake zama a hagu.

## Zabar encyclopedias

Danna chip na abbreviation (kamar **KIT**) don canjawa zuwa wannan encyclopedia. Domin neman fiye da encyclopedia daya lokaci daya, amfani da **Search** tab sannan zabi **Encyclopedia** a matsayin search mode.

## Samun more encyclopedias

1. Bude **Saituna (Settings)**.
2. Danna **Manage Resources**.
3. Danna **Install from GitHub**.
4. Zabi **Encyclopedias** tab.
5. Danna download button a kusa da encyclopedia da kake so.

Encyclopedias an sauke su daga GitHub repository na encyclopedia na Theodia kuma aka shigar su ta atomatik. Encyclopedias da aka shigar suna bayyana a cikin Encyclopedia screen da kuma Search.

Za ka iya shigar da encyclopedia daga fayil na gida ma: a cikin **Manage Resources**, danna **Install Local File** sannan zabi `.encyclopedia` fayil. An kwafe fayil din zuwa folder na encyclopedias na app sannan ya ƙara zuwa shared lookup index.

## Long-press domin cikakken take

A cikin Search screen, chips na encyclopedia suna nuna rage-abbreviations. Long-press chip don ganin cikakken sunan encyclopedia.

## Lokacin amfani da Encyclopedia

- Nemo mutum, wuri, ko batun kafin ko yayin karantun wani batun.
- Samun baya-baya akan kalmar Littafi Mai Tsarki ko ra'ayi wanda ke rufewa yawancin ayarsa.
- Karantawa tare da sharhi domin zurfin nazarin.
