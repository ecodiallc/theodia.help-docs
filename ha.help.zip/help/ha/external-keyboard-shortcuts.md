---
title: External Keyboard Shortcuts
level: everyday
categories: [tablet, settings]
summary: Cikakken referens na keyboard shortcuts na iPad da external keyboard attached.
---

# ⌨️ External Keyboard Shortcuts

Idan ka yi amfani da Theodia a iPad da external keyboard (Magic Keyboard, Bluetooth keyboard, ko USB keyboard), za ka iya bincika app din ba tare da taba screen ba.

> **Yadda za a yi:** Wasu shortcuts suna aiki kawai idan wannan feature din ya wanzu a yanayin mai amfani na yanzu. Misali, `Cmd + Option + 6` (Bookmarks) da `Cmd + Option + 7` (Highlights) ba su yin komai a Yanayin Karatu (Reader). Canja yanayoyi a **Saituna** → **Yanayin Mai Amfani na App**.

Shortcuts suna aiki a **iPad**.

## Global shortcuts (ko'ina)

| Shortcut           | Aiki                                      |
| ------------------ | ----------------------------------------- |
| `Cmd + /`          | Nuna wannan taimakon keyboard shortcuts   |
| `Cmd + .`          | Rufe modal / panel (Escape alternative)   |
| `Cmd + Option + 1` | Je zuwa Home tab                          |
| `Cmd + Option + 2` | Je zuwa Bibles tab                        |
| `Cmd + Option + 3` | Je zuwa Books tab                         |
| `Cmd + Option + 4` | Je zuwa Devotionals tab                   |
| `Cmd + Option + 5` | Je zuwa Search tab                        |
| `Cmd + Option + 6` | Je zuwa Bookmarks tab (Standard da Scholar) |
| `Cmd + Option + 7` | Je zuwa Highlights tab (Standard da Scholar) |
| `Cmd + Option + 8` | Je zuwa Notes tab (Standard da Scholar)   |
| `Cmd + Option + 9` | Je zuwa AI tab (Scholar kawai, idan ya ke) |
| `Cmd + Option + 0` | Je zuwa Help tab                          |
| `Cmd + Option + I` | Je zuwa About tab                         |
| `Cmd + [`          | Komawa baya                               |
| `Cmd + F`          | Bude Search                               |
| `Cmd + K`          | Bude Launcher Menu (Scholar)              |
| `Cmd + ,`          | Bude Saituna (Settings)                   |
| `Cmd + Shift + M`  | Bude main menu                            |
| `Cmd + Shift + T`  | Cycle theme (default / dark)             |
| `Cmd + Shift + U`  | Bude user mode picker                     |
| `Escape`           | Dismiss modal / rufe panel                |

## Bible Reader shortcuts

Suna aiki a cikin **Study Reader** da **Focus Reader**.

| Shortcut           | Aiki                                                      |
| ------------------ | --------------------------------------------------------- |
| `← Left Arrow`     | Sura ta baya (ta baya)                                    |
| `→ Right Arrow`    | Sura ta gaba (ta gaba)                                    |
| `Cmd + R`          | Canja tsakanin Study da Focus Reader (Standard da Scholar) |
| `Cmd + Option + V` | Bude version picker                                       |
| `Cmd + Option + B` | Bude book picker                                          |
| `Cmd + Option + C` | Bude chapter picker                                       |
| `Cmd + T`          | Toggle TTS (dakata yayin wasa/dakatawa, fara yayin rashin komai) |
| `Cmd + Option + T` | Play / Pause TTS                                          |

## Study Reader kawai

| Shortcut           | Aiki                                                                  |
| ------------------ | --------------------------------------------------------------------- |
| `↑ Up Arrow`       | Zabi ayarsa da ta baya                                                |
| `↓ Down Arrow`     | Zabi ayarsa da ta gaba                                                |
| `Cmd + ↑`          | Zabi ayarsa ta farko                                                  |
| `Cmd + ↓`          | Zabi ayarsa ta karshe                                                 |
| `Cmd + ←`          | Jump zuwa sura 1                                                      |
| `Cmd + →`          | Jump zuwa sura ta karshe                                              |
| `Cmd + 0`–`9`      | Direct verse jump (rubuta digits, misali `Cmd + 1` `Cmd + 6` don ayarsa 16) |
| `Cmd + P`          | Toggle parallel Bibles (Standard da Scholar)                          |
| `Cmd + B`          | Bookmark ayarsa da aka zaba (Standard da Scholar)                     |
| `Cmd + H`          | Highlight ayarsa da aka zaba (Standard da Scholar)                     |
| `Cmd + N`          | Ƙara note ga ayarsa da aka zaba (Standard da Scholar)                 |
| `Cmd + C`          | Kwatanta ayarsa translations da aka zaba (Standard da Scholar)        |
| `Cmd + X`          | Bude cross-references ga ayarsa da aka zaba (Standard da Scholar)     |
| `Cmd + I`          | Bude word info (Scholar)                                              |
| `Cmd + D`          | Bude dictionary ga ayarsa da aka zaba (Scholar)                        |
| `Cmd + A`          | Bude AI panel ga ayarsa da aka zaba (Scholar)                          |
| `Cmd + Option + S` | Toggle subheadings                                                    |
| `Cmd + Option + W` | Rufe duk open study panels                                            |
| `Cmd + Option + M` | Bude verse action menu                                                |

## Focus Reader kawai

| Shortcut       | Aiki           |
| -------------- | -------------- |
| `↑ Up Arrow`   | Scroll up      |
| `↓ Down Arrow` | Scroll down    |
| `Cmd + ↑`      | Scroll to top  |
| `Cmd + ↓`      | Scroll to bottom |
| `Cmd + =`      | Zoom in        |
| `Cmd + -`      | Zoom out       |

## Search

| Shortcut            | Aiki                                    |
| ------------------- | --------------------------------------- |
| `Return`            | Execute search                          |
| `Cmd + Return`      | Clear search kuma focus input          |
| `Cmd + ↑`           | Scroll results up                       |
| `Cmd + ↓`           | Scroll results down                     |
| `Cmd + Option + A`  | Select all scope items                  |
| `Cmd + Option + C`  | Deselect all scope items                |
| `Cmd + Option + B`  | Bible search mode                       |
| `Cmd + Option + O`  | Book search mode                        |
| `Cmd + Option + D`  | Dictionary search mode (Scholar)        |
| `Cmd + Option + X`  | Lexicon search mode (Scholar)           |

## Search Results

| Shortcut  | Aiki                |
| --------- | ------------------- |
| `Cmd + S` | Bude save-all sheet |
| `Cmd + ↑` | Scroll results up   |
| `Cmd + ↓` | Scroll results down |

## Book Reader

| Shortcut           | Aiki                    |
| ------------------ | ----------------------- |
| `← Left Arrow`     | Sura ta baya (ta baya)  |
| `→ Right Arrow`    | Sura ta gaba (ta gaba)  |
| `Cmd + ↑`          | Sura ta baya (ta baya)  |
| `Cmd + ↓`          | Sura ta gaba (ta gaba)  |
| `↑ Up Arrow`       | Scroll up               |
| `↓ Down Arrow`     | Scroll down             |
| `Cmd + B`          | Bookmark current chapter |
| `Cmd + J`          | Bude chapter picker     |
| `Cmd + L`          | Bude voice picker       |
| `Cmd + T`          | Toggle TTS              |
| `Cmd + Option + T` | Play / Pause TTS        |

## Devotional Reader

| Shortcut           | Aiki            |
| ------------------- | --------------- |
| `← Left Arrow`     | Rana ta baya    |
| `→ Right Arrow`    | Rana ta gaba     |
| `↑ Up Arrow`       | Scroll up        |
| `↓ Down Arrow`     | Scroll down      |
| `Cmd + ↑`          | Scroll up (large) |
| `Cmd + ↓`          | Scroll down (large) |
| `Cmd + D`          | Bude date picker |
| `Cmd + T`          | Toggle TTS       |
| `Cmd + Option + T` | Play / Pause TTS |

## AI Chat

| Shortcut           | Aiki                     |
| ------------------ | ------------------------ |
| `Cmd + Return`     | Aika sakon               |
| `Cmd + N`          | Sabon chat               |
| `Cmd + D`          | Toggle conversation drawer |
| `Cmd + Option + C` | Share current chat       |
| `Cmd + S`          | Bude save menu           |
| `Escape`           | Rufe drawer / menu       |

## Bookmarks

| Shortcut                                | Aiki                             |
| --------------------------------------- | -------------------------------- |
| `↑ Up Arrow` / `↓ Down Arrow`          | Zabi bookmark                    |
| `Return`                                | Bude bookmark (tablet: zabi)     |
| `Cmd + R`                               | Karanta bookmark a context       |
| `Cmd + M`                               | Motsa bookmark da aka zaba zuwa folders |
| `Cmd + N`                               | Manage folders                   |
| `Escape`                                | Rufe detail panel / folder picker |

A cikin **Save to Folder** picker, `↑ Up Arrow` / `↓ Down Arrow` yana motsa zaba, `Return` yana toggling selected folder ko activating highlighted action, kuma `Escape` yana rufe picker. Row din **+ Create Folder** yana a saman jeri.

## Bible Notes

| Shortcut                      | Aiki               |
| ----------------------------- | ------------------ |
| `↑ Up Arrow` / `↓ Down Arrow` | Zabi note          |
| `Return`                      | Bude note          |
| `Cmd + Return`                | Focus filter input |
| `Escape`                      | Rufe detail / editor |

## Highlights

| Shortcut                      | Aiki               |
| ----------------------------- | ------------------ |
| `↑ Up Arrow` / `↓ Down Arrow` | Zabi highlight     |
| `Return`                      | Bude highlight     |
| `Cmd + Return`                | Focus filter input |
| `Escape`                      | Rufe detail panel  |

## Bible List

| Shortcut                                 | Aiki                             |
| ---------------------------------------- | -------------------------------- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | Next Bible                       |
| `← Left Arrow` / `↑ Up Arrow`            | Previous Bible                   |
| `Return`                                 | Bude focused Bible               |
| `Cmd + Shift + S`                        | Toggle favorite for focused Bible |
| `Escape`                                 | Komawa baya                      |

## Bible Books Screen

| Shortcut                | Aiki                     |
| ----------------------- | ------------------------ |
| `Tab` / `→ Right Arrow` | Next book                |
| `← Left Arrow`          | Previous book            |
| `↓ Down Arrow`          | Book below in grid       |
| `↑ Up Arrow`            | Book above in grid       |
| `Cmd + ↓`               | Next section (OT / NT)   |
| `Cmd + ↑`               | Previous section (OT / NT) |
| `Return`                | Bude focused book        |
| `Escape`                | Komawa baya              |

## Book List

| Shortcut                                 | Aiki              |
| ---------------------------------------- | ----------------- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | Next book         |
| `← Left Arrow` / `↑ Up Arrow`            | Previous book     |
| `Return`                                 | Bude focused book |
| `Escape`                                 | Komawa baya       |

## Bible Chapters Screen

| Shortcut                                 | Aiki              |
| ---------------------------------------- | ----------------- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | Next chapter      |
| `← Left Arrow` / `↑ Up Arrow`            | Previous chapter  |
| `Return`                                 | Bude focused chapter |
| `Escape`                                 | Komawa baya       |

## Book Chapters Screen

| Shortcut               | Aiki                    |
| ---------------------- | ----------------------- |
| `Tab` / `↓ Down Arrow` | Next chapter            |
| `↑ Up Arrow`           | Previous chapter        |
| `Return`               | Bude focused chapter    |
| `Cmd + Return`         | Focus search/filter input |
| `Escape`               | Komawa baya             |

## Devotional List

| Shortcut                                 | Aiki                  |
| ---------------------------------------- | --------------------- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | Next devotional       |
| `← Left Arrow` / `↑ Up Arrow`            | Previous devotional   |
| `Return`                                 | Bude focused devotional |
| `Escape`                                 | Komawa baya           |

## Charts

A kan Statistics, Goals, da Concordance screens.

| Shortcut        | Aiki                                       |
| --------------- | ------------------------------------------ |
| `← Left Arrow`  | Zabi category ta baya a chart             |
| `→ Right Arrow` | Zabi category ta gaba a chart             |

Caption ƙarƙashin chart yana biyan zaba, kuma sabon value ana magana da shi.

## main menu (lokacin da ya bude)

| Shortcut       | Aiki                |
| -------------- | ------------------- |
| `↑ Up Arrow`   | Previous menu item  |
| `↓ Down Arrow` | Next menu item      |
| `Return`       | Zabi highlighted item |
| `Escape`       | Rufe menu           |

## Saituna (Settings)

| Shortcut | Aiki                    |
| -------- | ----------------------- |
| `Escape` | Rufe open modal / picker |

## Editor Modals

| Shortcut  | Aiki               |
| --------- | ------------------ |
| `Cmd + S` | Ajiye              |
| `Escape`  | Cancel / rufe      |

## Typing guard

Lokacin da kake mai da hankali a cikin text field (search box, note editor, AI input), non-Cmd shortcuts kamar arrow keys da `Space` suna hana domin kada su kauce sha'anin navigation gaba daya. Shortcuts da ke amfani da `Cmd` key (misali, `Cmd + S`, `Cmd + B`) har yanzu suna aiki yayin rubuta.
