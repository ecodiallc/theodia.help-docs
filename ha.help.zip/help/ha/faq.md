---
title: Frequently Asked Questions
level: everyday
categories: faq
summary: Amsoshi ga yawancin tambayoyin da suke yaduwa game da amfani da Theodia.
---

# Frequently Asked Questions

## Shin Theodia yana kan kudin?
Theodia daya-ce purchase ne. Babu subscription, babu talla, babu in-app purchases, kuma babu buƙatar gudummawa. Duk ƙarin albarkatun da aka samu a catalog suna free a sauke bayan ka sayi app din.

## Ina neman intanet?
A'a. Da zarar an shigar da app din da fayilolin datar sa, komai yana aiki offline. Za ka iya karantawa, bincikawa, nuna alama, ƙara notes, kuma amfani da yawancin kayan aiki na nazarin ba tare da sigina ba.

Abinda kawai yake bukatar intanet shi ne saukowa da sabon albarkatun.

## Ina data na ajiye?
Duk bookmarks, highlights, notes, da saitunan ka suna ajiye a kan na'urarka. Ba a upload su zuwa kowane server ba.

Za ka iya back su up da hannu. Dubi jagorar [Backing Up Your Data](theodia://help/backups) don yadda.

## Zan iya sauraren Littafi Mai Tsarki a loud?
Na'am. Bude kowane sura, danna menu, kuma zabi read-aloud option. Na'urarka dole ta da text-to-speech voice da aka shigar. Dubi jagorar [Reading Out Loud](theodia://help/tts) don more.

## Yadda nake bincika ayarsa?
Za ka iya rubuta reference kamar `John 3:16` a cikin Command a home screen, ko amfani da **Search** tab don bincikar kalma ko jumla.

## Yadda na bayar da bug ko ba da suggestion?
Danna **Submit Suggestion / Issue** a About screen, [bayar a GitHub](https://github.com/ecodiallc/theodia.app/issues/new), ko ziyarci [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions) page.

## Menene na'urori da aka samu?
Theodia yana aiki akan iPhone, iPad, da phones da tablets na Android. Yana aiki don ka-fi akan na'urori da a kalla 2 GB free storage don core data files.

## Zan iya amfani da external keyboard?
Na'am. Theodia yana goyan bayan Bluetooth da USB keyboards akan iPad. Navigation, search, da yawancin features na karatu suna da keyboard shortcuts. Dubi jagorar [External Keyboard Shortcuts](theodia://help/external-keyboard-shortcuts) don cikakken jeri.

## Menene harsunan da aka samu?
UI na app yanar samuwa a Turanci, Arab, Sin (Simplified da Traditional), Czech, Danish, Dutch, Filipino, Faransanci, German, Girkanci, Hebrew, Hindi, Indonesiya, Italiyanci, Jafananci, Koriyanci, Poland, Potigal (Brazil), Romanian, Russian, Spanish, Swahili, Swedish, Thai, Turkiyya, Ukrainian, da Vietnamese.

Harshe na Bible text yana dogara ne da fassarorin da ka shigar.

## Yadda nake canja harshe?
Je zuwa **Saituna (Settings)** kuma nemo language option.

## Tambayarina ba nan ba ne. Ina zan sami more help?
Binne sauran help guides ta topic, ko ka tambaya a [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions) community.

Tip: A kan **Help & Guides** main screen, amfani da search box don rubuta topic kamar `notifications` ko `search` don neman guide mai dacewa.
