---
title: Karantun Surar Ka ta Farko
level: beginner
categories: [start, read]
summary: Koyaya ci gaba wataci-wataci na bude da karanta sura.
---

# Karantun Surar Ka ta Farko

Wannan guide tana sanar da ka yadda ake bude sura don karo na farin ciki.

## Mataki 1: Bude Bible tab

Kalli ƙasa da screen. Za ka ga layin tabs. Danna ɗaya da take cewa **Bible**.

## Mataki 2: Zabi littafi

Za ka ga jerin Bible books. Genesis ya kusa gaba. John yana kusa tsakiya. Revelation ya kusa ƙarshe.

Danna sunan littafin da kake so.

## Mataki 3: Zabi sura

Za ka ga lsetattri 1 zuwa ga yawan surori da littafin ya da. Danna surar da kake so.

Sura tana budewa. Ayarshi suna a screen.

## Mataki 4: Motsawa

- Swipe **hagu** don je zuwa sura ta gaba.
- Swipe **dama** don komawa baya.

## Mataki 5: Mu'amala da ayarsa

Abin da za ka iya yin da ayarsa yana dogara ne akan yanayin mai amfani na ka.

### Reader mode

Reader mode yana tsabtacce kuma ba shi da wani abin da ya yaye hankali.

- Danna ayarsa don nuna shi na dan lokaci.
- Babu study tools, bookmarks, ko menus.
- Idan kana so more features, canja zuwa **Standard** ko **Scholar** mode a **Saituna (Settings)**.

### Standard mode

Standard mode yana yaduwa everyday features don personal Bible study.

Danna ayarsa don bude menu mai wadancan options:

- **Bookmark** ayarsa.
- **Highlight** ta a launi.
- **Add a note** zuwa gare ta.
- **Copy** rubutun ayarsa.
- **Compare** ayarsa a wani fassarar.
- **Look up cross-references** ga ayarsa.

### Scholar mode

Scholar mode yana ƙaddamar da kowane tool domin zurfin Bible study.

Danna ayarsa don bude menu mai komai a Standard mode, plus:

- **Commentary** akan ayarsa.
- **Word Info** da original-language lookups.
- **Dictionary** ma'anoni.
- **AI assistant** domin zurfin nazarin.

Za ka iya canja yanayoyi a kowane lokaci a **Saituna**.

## Ina abu shine taimakon musamman tool?

Kowane tool yana da nasa guide. Danna **Help** a home page don ganin su duka. Jagorar [Study Mode](theodia://help/study-mode) wuri ne mai kyau na farawa — tana sanar da kowane tool a cikin verse menu.

Idan har ka na koyon inda abubuwan suna, dubi jagorar [App Layout and Navigation](theodia://help/navigating-the-app). Tana sanar da home screen, main menu, da bottom toolbar.

## Ina so more resources?

App yana isar da wasu yayyagayyar Bible versions kyauta. Idan kana so ƙarin, ko ƙara commentaries, books, ko devotionals, dubi jagorar [Getting Extra Resources from GitHub](theodia://help/getting-core-files). Tana nuna maka inda za ka same su kuma yadda za ka ƙara su.
