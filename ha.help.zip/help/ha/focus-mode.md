---
title: Focus Mode
level: beginner
categories: [layout, read]
summary: Hanya mai tsabta da ba shi da wani abin da ya yaye hankali don karanta dogayen batutuwa.
---

# Focus Mode

> **Yadda za a yi:** Focus Mode shi ne reader a cikin **Reader** mode. Yana samuwa kuma a **Standard** da **Scholar** mode a matsayin madadin Study Mode. Za ka iya canja yanayoyi a **Saituna** → **Yanayin Mai Amfani na App**.

Focus Mode wuri ne na karanta surar Littafi Mai Tsarki ba tare da buttons ko menus cikin hanya ba. Yana da kyau domin dogon sessions na karatu.

## Yadda ake kunna shi

1. Bude kowane sura.
2. A cikin layin icons a saman screen, danna 📖 button. Yana bude wannan sura a Focus Mode.
3. Menus da buttons suna ɓuya. Kawai rubutun Littafi Mai Tsarki yana ragewa.

A cikin **Reader** mode, sura suna bude a Focus Mode ta atomatik. 📖 button yana ɓoye domin babu Study Mode don canja zuwa.

## Abin da za ka iya yi a Focus Mode

- **Scroll** don karantawa.
- **Swipe** don je zuwa next ko previous sura.
- **Danna 📖 button** a cikin bottom bar don canjawa baya zuwa Study Mode. (An ɓoye a Reader mode.)
- **Danna 🔊 button** a cikin bottom bar don da na'urarka ta karanta surar a loud. Mini control bar yana bayyana mai play, pause, rewind, fast-forward, da voice picker. (An ɓoye a Reader mode — TTS yana bukatar Standard ko Scholar.)

## Amfani mai kyau na Focus Mode

- Karanta duka littafi, sura daya bayan daya.
- Karanta dogon batun domin devotional ko quiet time.
- Saurari karantawa da bin ba tare da distractions ba.

## Canjawa zuwa Study Mode

Focus Mode yana ɓoye kowane study tool, amma suna kusa tap daya. Danna 📖 button a saman screen don bude wannan sura a [Study Mode](theodia://help/study-mode). Study Mode shine full reader, mai commentary, cross-references, lexicon lookups, da notes. Don sanin abin da Study Mode zai iya yi, dubi jagorar [Study Mode](theodia://help/study-mode).

A cikin **Reader** mode, 📖 button yana ɓoye domin Study Mode ba ya samuwa.
