---
title: Getting Around Quickly
level: beginner
categories: layout
summary: Kowane ta hanyar da ta yi sauri don jump zuwa ayarsa, sura, ko screen a Theodia.
---

# Getting Around Quickly

Wannan guide yana da cheat sheet na navigation. Yana rufe kowane ta hanyar da ta yi sauri don motsawa daga inda kake zuwa inda kake so ka je.

## Jump kai tsaye zuwa ayarsa

Fastest way don bude kowane ayarsa shi ne **Command** a kan home screen.

- Rubuta `John 3:16` sannan danna Go.
- Rubuta `Psalms 23` sannan danna Go.
- Rubuta `Genesis 1` sannan danna Go.

App yana bude exact sura (kuma zai scroll zuwa ayarsa idan ka nuna shi).

## Swipe tsakanin surori

Lokacin da kake karanta sura:

- **Swipe hagu** → next sura.
- **Swipe dama** → previous sura.

Wannan yana aiki a kusar littattafai. Bayan Exodus 40, swipe hagu yana kai ka zuwa Leviticus 1.

## Amfani da top bar

Yayin karanta, saman screen yana nuna current **translation**, **book**, da **chapter**.

- Danna translation name don canja Bibles.
- Danna book name don zabi littafi dabam.
- Danna chapter number don zabi sura dabam.

## Jump daga bookmark

Idan ka ajiye ayarsa:

1. Bude **Bookmarks** tab.
2. Danna kowane entry.
3. Ka je kai tsaye zuwa waccan ayarsa.

## Jump daga search

1. Bude **Search** tab.
2. Rubuta kalma ko jumla.
3. Danna kowane sakamako.
4. App yana bude sura yayin da ka nuna search words a yellow.

## Canja reading layouts

Bible reader yana da layouts guda biyu:

- **Study Mode** — yana nuna sura mai duk study tools a kusa da tap.
- **Focus Mode** — yana ɓoye kowane tool da menu, ya bar kawai rubutu.

Don canja: danna **📖** button a saman screen yayin karanta. Danna shi kuma don canjawa baya. (Reader mode har koyaushe yake zama a Focus Mode.)

## Amfani da bottom tabs

Layin icons a ƙasa na screen har koyaushe ya wanzu. Danna kowane tab don canjawa zuwa wannan section. Haruffi suna dogara ne da yanayin mai amfani na ka:

**All modes:**

- **Home** — komawa home screen.
- **Bibles** — jerin translations.
- **Search** — search Littafi Mai Tsarki, books, dictionaries, lexicons, PDFs.
- **Settings** — preferences da resources.

**Standard da Scholar suna ganin kuma:**

- **Bookmarks** — ayarsa da aka ajiye.
- **Highlights** — ayarsa da aka nuna launi.
- **Notes** — your private notes.
- **PDFs** — your imported PDF documents.

**Scholar kawai yana ganin:**

- **AI** — AI assistant (idan ya ke a Settings).

### Tunawar inda ka baruri

Kowane tab yana kiyaye nasa navigation history. Lokacin da ka komawa tab, za ka koma **inda ka baruri**, ba starting screen na wannan section ba.

- Ka bude **Bibles** tab, zabi translation, ka bude sura, sannan ka canja zuwa **Search**. Daga baya ka danna **Bibles** kuma za ka koma wannan sura daya.
- Ka bude **Bookmarks** tab, danna bookmarked ayarsa, sannan ka canja zuwa **Settings**. Danna **Bookmarks** kuma ka koma bookmark list.

Wannan yana aiki zuwa kowane tab. Kowanne yana tunawa da inda ka ce har sai ka kai kayar da kanka zuwa screen dabam a cikin wancan tab.

### Abin da yake reset daba tab

Tab yana koma zuwa root screen kawai lokacin da:

- Ka kewayance kan wancan tab kuma ka danna wancan tab icon akai-akai. Wannan yana da sauri don reset zuwa farawa.
- App ya force-closed kuma aka sake budewa.

### Bottom tabs vs main menu

- **Bottom tabs** — kowane tab yana tunawa da nasa stack. Danna tab yana komawa ka ne inda ka baruri.
- **Main menu** — danna item yana kai ka ne zuwa wancan screen. Ita ce dropdown list, ba overlay ba.

Misali:

- Kana karanta John 3. Danna **Bookmarks** tab, sannan danna **Bibles** akai-akai ka koma John 3.
- Kana karanta John 3. Bude menu sannan danna **Notes**. Bincika notes din, sannan danna **Bibles** tab don koma John 3.

## Tukuna

- Home screen yana tunawa da waɗanne sections an expanded ko collapsed.
- Idan tab ya ɓoye, kaada **yanayin mai amfani** a **Saituna** → **Yanayin Mai Amfani na App**. Reader mode yana ɓoye bookmarks, highlights, notes, da AI. Standard mode yana ɓoye AI. Kuma watakin za ka bukatar a kunna feature a **Saituna** ko shigar resource.
