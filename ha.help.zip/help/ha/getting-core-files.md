---
title: Getting Extra Resources
level: everyday
categories: resources
summary: Yadda ake ƙara Bibles, commentaries, books, da wasu albarkatun zuwa Theodia.
---

# Getting Extra Resources

Theodia yana isar da wasu albarkatun ginin ciki, amma za ka iya ƙara more. Mafi sauki ta hanyar ita ce ta **Manage Resources** screen cikin app din.

## Abin da za ka iya ƙara

- **Bibles** — more translations a cikin harshe dabam
- **Commentaries** — study notes da ke bayyana ayarsa
- **Books** — Christian classics da reference works
- **Devotionals** — daily devotional readings
- **Core files** — larger data files kamar morphology, cross-references, da Marvel Interlinear Bible (MIB)

## Yadda ake ƙara albarkatun daga cikin app

1. Bude **Saituna (Settings)**.
2. Danna **Manage Resources**.
3. Zabi tab: **Core**, **Bibles**, **Commentaries**, **Books**, ko **Devotionals**.
4. Binne jerin. Danna resource domin karanta more game da shi.
5. Danna checkbox don zabi abin da kake so.
6. Danna **Download** a ƙasa. Files suna saukar da shigar ta atomatik.

Da zarar an shigar, resource yana bayyana a cikin app nan take. Ba ka bukatar a restart.

## Core files

**Core** tab yana da large data files da ke ƙarƙashin deeper study features. Waɗannan sun haɗa da:

- Morphology data (original-language word forms)
- Cross-reference databases
- The Marvel Interlinear Bible (MIB)

Ka bukatar a sauke core files kawai sau daya. Suna zama a kan na'urarka kuma suna aiki offline.

## Global Bibles

**Global Bibles** tab yana da Bible translations daga broader collection. Idan ba ka ga translation da kake so a main **Bibles** tab ba, kaada a nan.

## Managing installed resources

A kan **Manage Resources** main screen (ba download tab ba), za ka iya:

- **Enable ko disable** resource ba tare da goge shi ba. Disabled resources suna zama a kan na'urarka amma an ɓoye su daga menus.
- **Delete** resource don free up space. Za ka iya re-download shi daga baya.

## ƙara your own files

Idan ka da file na resource daga wani wuri — aboki, wasu projects, ko website — za ka iya import shi kai tsaye:

1. A cikin **Manage Resources**, danna **Import Local File**.
2. Zabi file daga na'urarka.
3. App yana karanta file sannan ƙara ta zuwa library na ka.

App yana karɓa wadannan file types:

- `.bible` — Bible translations
- `.commentary` — commentaries
- `.lexicon` — lexicons
- `.book` — books
- `.devotional` — devotionals

## Connecting custom GitHub repository

Idan wani yana kula da GitHub repository mai Theodia-compatible resources, za ka iya ƙara shi a matsayin custom source:

1. Je zuwa **Settings → GitHub Repositories**.
2. Danna **Add Repository**.
3. Rubuta GitHub URL (misali, `https://github.com/username/repo-name`).
4. Zabi wadanne types na resources repo yana ƙunshe (Bibles, commentaries, ko books).
5. Ajiye.
6. Komawa **Manage Resources**. Sabon tab yana bayyana mai resources daga wancan repo.

Idan repository ya zama private, za ka bukatar a ƙara **Personal Access Token** a **Settings → GitHub Repositories** domin app ya iya karantusha.

## Bayanin file sizes

Resource files za su iya zama large. Bibles yawanci suna small (danshi-ны megabytes). Commentaries da core files za su iya zama much larger (danshini megabytes). Saukar da Wi-Fi idan akwai.

## Summary

- Amfani da **Settings → Manage Resources** don binne da shigar da resources.
- Core files yana  unlock deeper study tools kamar morphology da cross-references.
- Import local files idan ka da nasu.
- ƙara custom GitHub repos idan kana so resources daga wani source.
