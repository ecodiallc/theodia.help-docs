---
title: Where to Ask Questions
level: everyday
categories: trouble
summary: Yadda ake neman taimako daga Theodia team da community, da kuma yadda ake nemo help topics cikin app.
---

# Where to Ask Questions

Idan ka makale, akwai wasu wuraren neman taimako.

## Nemo help topic

Idan kana neman info game da feature musamman, gwada waɗannan hanyoyi:

- **Binne ta category.** Bude **Help & Guides** sannan danna category kamar **Settings & Customization** ko **Troubleshooting**. Kowane card yana jerin guides masu alaqa.
- **Search ta keyword.** A kan **Help & Guides** main screen, rubuta kalma a cikin search box a saman. Misali, rubuta `notifications` yana nuna jagora [Notifications and Reminders](theodia://help/notifications); rubuta `search` yana nuna [Searching the Bible](theodia://help/search-the-bible).
- **Kaada Settings fari.** Yawancin features an configured a cikin **Settings**. Idan kana so ka setup reminders, bude **Settings** → **Notifications**. Settings screen yana da **Help** link ga kowane section.

## Cikin app

Bude **About** screen. Za ka ga buttons biyu:

- **Submit Suggestion / Issue** — yana bude form don aika team tambaya, idea, ko bug report.
- **Discussion / Feedback** — yana bude community discussion board.

## GitHub page

Za ka iya ganin jerin known issues da recent changes a [GitHub](https://github.com/ecodiallc/theodia.app).

## Community discussion

Wasu yana amfani da Theodia suna tambayoyi da share tips a [community discussion board](https://github.com/ecodiallc/theodia.app/discussions). Za ka iya karanta old threads kuma ka fara sabon.

## Kafin ka tambaya

Waɗannan abubuwan suna taimakawa amsoshi nan take:

- **Menene na'urar ka?** (misali iPhone 13, Pixel 7)
- **Menene version na app?** (Bude **About** don gani.)
- **Menene ka yi?** Takaitaccen description na steps.
- **Menene ya faru?** Abin da ka gani a screen.
- **Menene kake tsammanin ya faru?** Wannan yana da amfani kamar yadda.

## Abin da aka tsammana

- Domin bug reports, team yawanci yana amsawa cikin 'yan kwanaki.
- Domin ideas, team yana karanta su duka. Ba za mu iya sealed lokacin da idea za a ƙara ba.
- Domin community questions, other users yawanci suna amsawa da sauri fiye da team.

## Bayanin privacy

Lokacin da ka aika tambaya, kar ka haɗa private information. Team yana iya ganin abin da ka aika.
