---
title: GitHub Models
categories: ai
level: advanced
summary: Setup GitHub Models — free way don fara nazarin AI a Theodia ba tare da existing API subscription ba.
---

# GitHub Models

> **Yadda za a yi:** AI assistant yana bukatar **Yanayin Malami (Scholar)**. Za ka iya canja yanayoyi a **Saituna** → **Yanayin Mai Amfani na App**.

Idan ba ka biya wani AI service ba, **GitHub Models** shi ne mafi sauki don fara nazarin AI na Theodia. Yana allows free way don fara, kuma duk abin da ka bukatar shi ne free GitHub account.

## Menene GitHub Models?

GitHub Models wani service ne daga GitHub da ke allows ka run modern AI models ta hanyar API. Yana supports wannan format kamar OpenAI, don haka yana aiki daidai tare da Theodia.

## Me yasa zabi GitHub Models?

- **Babu credit card** — Kawai GitHub account.
- **High-quality models** — Ka sami access zuwa GPT-4o, GPT-4.1, da wasu abokan reliable models da ke support Theodia's tools.
- **Easy setup** — One token, one URL, kuma ka gama.

## Mataki 1: Create GitHub account

Idan ka kera GitHub account, skip to Step 2.

1. Je zuwa [github.com](https://github.com).
2. Danna **Sign up** kuma biyu prompts don create free account.
3. Verify adireshin email naka lokacin da GitHub yana aika confirmation.

## Mataki 2: Create Personal Access Token

Wannan token shi ne API key na ka. Yana bane GitHub wane ke ne yayin da Theodia yana aika tambayoyi.

1. Je zuwa [github.com/settings/tokens](https://github.com/settings/tokens).
2. Danna **Generate new token** sannan zabi **Generate new token (classic)**.
3. Ba shi name kamar **Theodia AI**.
4. A ƙarƙashin **Select scopes**, kaada box don **`models:read`**.
   - Wannan shi ne kawai permission da Theodia needs.
5. Scroll zuwa ƙasa sannan danna **Generate token**.
6. **Kwafa token nan take.** GitHub zai only nuna shi da. Paste a sauquatile (kamar notes app na phone) har sai ka ƙara shi a Theodia.

## Mataki 3: Zabi model

GitHub Models yana offers wasu models. Don Theodia, waɗannan su ne best options:

| Model                 | Daily Free Limit   | Best For                                      |
| --------------------- | ------------------ | --------------------------------------------- |
| `openai/gpt-4.1-nano` | 150 requests / day | Tafiya tambayoyi da sauquatile verse explanations |
| `openai/gpt-4.1-mini` | 150 requests / day | General study mai kyau tool support          |
| `openai/gpt-4.1`      | 50 requests / day  | Zurfi nazarin da complex multi-step questions |
| `openai/gpt-4o`       | 50 requests / day  | Versatile, excellent tool support            |

Fara da **`openai/gpt-4.1-mini`** — yana da sauri, reliable, kuma ya offer higher daily request limit.

## Mataki 4: Configure Theodia

1. Bude **Theodia**.
2. Je zuwa **Saituna** → **AI Assistant**.
3. Kaada **Remote model** aka zaba.
4. Danna **Provider** dropdown sannan zabi **GitHub Models**.
   - Idan GitHub Models ba a cikin jeri ba, danna **Custom** sannan rubuta base URL manually: `https://models.github.ai`
5. Paste GitHub Personal Access Token na ka a cikin **API Key** field.
6. Rubuta chosen model ID a cikin **Model** field (misali: `openai/gpt-4.1-mini`).
7. Danna **Test connection**.
8. Jira check ya gama. Za ka ga:
   - **✓ Connection successful**
   - **✓ Tools supported**

Idan ka ga **✗ Tools not supported**, gwada model ID dabam daga table a kusa.

## Mataki 5: Farawa chat

1. Danna **AI** tab a ƙasa na screen.
2. Rubuta tambaya sannan danna **Send**.
3. Ko kuma, yayin karanta kowane Bible sura, danna ayarsa number sannan zabi **AI Commentary** don fara verse-specific chat.

## Troubleshooting

### "Connection failed" ko "HTTP 401"

- Kaada ka kwafa **duka** token. Ita ce long string da ke farawa da `ghp_`.
- Tokens suna expire idan ba a amfani da su cikin dogon lokaci. Komawa GitHub sannan ka sake generate na fresh.
- Kaada ka zabi **models:read** yayin create token.

### "Tools not supported"

- Wasu models a kan GitHub Models ba su karɓa tool calls. Gwanda **`openai/gpt-4o`** ko **`openai/gpt-4.1-mini`** instead.
- Kaada model ID ya yi nasara kamar yadda aka nuna, including `openai/` prefix.

### Rate limit errors

- Idan ka bug daily limit, canja zuwa model mai higher allowance (kamar `openai/gpt-4.1-nano` a 150 requests per day).
- Limits suna reset kowace awanni 24.

## Summary

- GitHub Models shi ne **recommended way don fara nazarin AI** a Theodia.
- Ka bukatar **free GitHub account** da **Personal Access Token** mai `models:read`.
- Best starter model shi ne **`openai/gpt-4.1-mini`**.
- Rubuta token da model a **Settings → AI Assistant**, danna **Test connection**, sannan ka fara chat.
