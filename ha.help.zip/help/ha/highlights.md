---
title: Highlighting Verses
level: everyday
categories: [annotate, read]
summary: Yadda ake nuna ayarsa a launi da kuma nemo su daga baya.
---

# Highlighting Verses

> **Yadda za a yi:** Highlights suna samuwa a cikin **Standard** da **Scholar** mode. Focus Mode kawai don clean, distraction-free reading. Za ka iya canja yanayoyi a **Saituna** → **Yanayin Mai Amfani na App**.

Highlighting yana nuna ayarsa a launi. Yana aiki kamar yellow highlighter a kan paper. Ayarsa tana zama highlighted next time ka bude ta.

## Yadda ake highlight ayarsa

1. Bude ayarsa.
2. Danna ayarsa don bude menu.
3. Danna **Highlight** icon.
4. Zabi launi.

Ayarsa din yanzu an highlighted a wancan launi.

## Yadda ake canja highlight launi

1. Bude ayarsa.
2. Danna ayarsa, sannan danna **Highlight** icon.
3. Zabi sabon launi.

## Yadda ake cire highlight

1. Bude ayarsa.
2. Danna ayarsa, sannan danna **Highlight** a menu.
3. Danna **Remove Highlight** a ƙasan color picker.

## Hanyan da yawan masu karanta ke amfani da launi

Yawancin masu karanta suna amfani da small set of launi domin small set of purposes:

- **Yellow** domin general favorites.
- **Green** domin ayarsa game da Allah.
- **Blue** domin ayarsa game da addu'a.
- **Pink** domin ayarsa game da comfort.
- **Orange** domin ayarsa game da warning ko correction.
- **Purple** domin ayarsa game da prophecy ko end times.

Zabi system din da ya dace maka.

## Yadda ake ganin duk highlights naka

Danna **Highlights** tab a ƙasa. Za ka ga jerin kowane ayarsa da ka highlighted, newest first. Akwai layin color chips a saman — danna launi don nuna highlights guda a wancan launi, ko danna **All** don clear filter.

## Importing highlights

Za ka iya ƙara highlights zuwa Theodia daga wasu apps da files.

Je zuwa **Saituna** → **Bookmarks** → **Import Highlights**. Zabi **Import from File** ko paste daga clipboard. App yana detect format ta atomatik.

### Supported formats

**Native JSON export** — Format da Theodia's own export feature yake amfani:

```json
{
  "/bible/KJV/John/3#v3_16": "yellow",
  "/bible/KJV/Genesis/1#v1_1": "green"
}
```

**CSV** — Spreadsheet mai `url` da `color` columns. Misali:

```csv
url,color
/bible/KJV/John/3#v3_16,yellow
/bible/KJV/Genesis/1#v1_1,green
```

**Plain text** — Kowane line shi ne Bible reference ko URL, optionally followed da color name. Misali:

```
John 3:16 yellow
Genesis 1:1 green
Matthew 5:1
```

- Available launi: `yellow`, `green`, `blue`, `pink`, `orange`, `purple`.
- Idan ba a bayar da launi ba, highlight yana default to yellow.
- Lines da ke farawa da `#` ko `//` an ƙidaya a matsayin comments sannan an skip.

## Tukuna

- Highlights suna zama a kan na'urarka. Ba su sync zuwa cloud ba.
- Za ka iya highlight ayarsa a cikin ɗaya translation sannan ya show up a cikin wasu translations na wannan ayarsa.
- Dubi jagorar [Backing Up Your Data](theodia://help/backups) domin su tsira.
