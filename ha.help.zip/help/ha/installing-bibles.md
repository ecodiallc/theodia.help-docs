---
title: Installing Bible Translations
level: beginner
categories: start
summary: Yadda ake ƙara Bible translation zuwa library naka.
---

# Installing Bible Translations

Theodia yana isar da few Bible translations ready don karantawa. Za ka iya ƙara more a kowane lokaci. "Fassarar" shine wani fassarar Bible text, kamar King James Version.

## Yadda ake ƙara fassarar

Bible tab yana nuna jerin translations da aka shigar. Domin ƙara more, bude resource manager:

1. Bude **Saituna (Settings)**.
2. Danna **Manage Resources**.
3. Danna **Install from GitHub**.
4. A cikin download modal, danna **Bibles** tab.
5. Danna checkbox a kusa da kowane translation da kake so.
6. Danna **Install Selected** a ƙasa.
7. Jira download ya gama.

Fassarar din yanzu yana cikin library na ka. Domin gani, bude **Bible** tab.

## Yadda ake canja tsakanin fassarori

1. Bude sura da kake so ka karanta.
2. Danna translation name a saman screen.
3. Zabi ɗaya da kake so daga jerin.

App yana ajiye zaɓin naka domin next time.

## Yadda ake cire fassarar

1. Bude **Saituna (Settings)**.
2. Danna **Manage Resources**.
3. Nemo fassarar da kake so ka cire.
4. Danna **X** a kusa da shi.
5. Confirm cewa kana so ka cire.

Cire fassarar ba ya goge notes, highlights, ko bookmarks naka. Waɗannan suna zama safe.

## Nawa ne space da fassarori suke amfani?

Yawancin fassarori suna tsakanin 2 zuwa 10 MB. An ajiye su a kan na'urarka, ba a cloud ba. Za ka iya kiyaye su nawa ka so, su kai na'urarka tana da sarari.

## Idan fassarar ba a cikin app ba?

Wasu fassarori ba a cikin in-app list ba. Za ka iya add su anyway.

1. Bude app sannan je zuwa **Saituna** → **Manage Resources**.
2. Danna **Install from GitHub**.
3. A cikin download modal, kaada **Bibles** tab da **Global Bibles** tab. Idan fassarar ka yana nan, zabi shi sannan danna **Install Selected**.
4. Idan ba nan ba, danna **Install Local File** don import `.bible` file. Samun file daga GitHub page na project. Dubi jagorar [Getting Extra Resources from GitHub](theodia://help/getting-core-files) don step-by-step taimako.
