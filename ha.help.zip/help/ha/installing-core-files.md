---
title: Adding the Core Files
level: beginner
categories: start
summary: Yadda ake sauke babban data files da app yake bukatar domin zurfin nazarin Littafi Mai Tsarki.
---

# Adding the Core Files

Theodia yana isar da Littafi Mai Tsarki da wasu small extras ready don amfani. Don ka sami fumta daga app din, ka bukatar a sauke **core files**. Waɗannan babban data files ne da ke ƙara study tools kamar commentary, word lookups, da grammar notes. Ba su ba su, app yana aiki, amma study features suna da kasa.

## Me yasa ka bukatar core files

Core files yana ƙara:

- **Word lookups.** Danna kalma a kowane ayarsa don ganin asalin Hebrew ko Girkanci da ma'anarsa.
- **Commentary.** AI Commentary akan kowane ayarsa.
- **Grammar.** Info game da kowane kalma a asalin harshe.
- **Interlinear Bible.** Karanta asalin-harshe text da Turanci ƙarƙashin kowane kalma.

Za ka iya karanta Littafi Mai Tsarki ba tare da su ba, amma yawancin study tools suna bukatar su.

## Yadda ake shigar core files

**[Install Core Files](theodia://manage/core)**

1. Bude **Saituna (Settings)**.
2. Danna **Manage Resources**.
3. **Core** tab yana bude. Za ka ga jerin core files. Kowane yana da name, size, da checkbox.
4. Danna kowane file da kake so ka shigar. Check mark yana nuna cewa an zabi.
5. Danna **Install Selected**.
6. Jira files sun sauke sannan aka shigar. Suna large, don haka wannan zai dauki 'yan mintoci a kan connection mai slow.

Files suna sauka zuwa na'urarka. Ka bukatar a yi wannan sau ɗaya kawai. App yana amfani da files daga nan goya da, har yayin da offline.

## Tukuna

- Amfani Wi-Fi. Files suna large.
- Connection ka phone ko tablet. Big downloads suna amfani da battery.
- Idan download ya fail, danna file akai-akai don retry.
- Za ka iya shigar da duka ko kawai wasu da kake bukatar.

## Idan file ya ɓace daga jeri?

App yana jawo jeri daga GitHub page na project. Idan jeri ya ɓace, kaada internet connection sannan gwanda kuma. Idan har yanzu ɓace, dubi jagorar [Where to Ask Questions](theodia://help/getting-more-help).

Domin more advanced ways don ƙara resources, dubi jagorar [Getting Extra Resources from GitHub](theodia://help/getting-core-files).
