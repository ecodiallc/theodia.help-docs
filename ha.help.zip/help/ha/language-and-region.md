---
title: App Language and Region
level: everyday
categories: settings
summary: Yadda ake canja harshe na app.
---

# App Language and Region

Theodia yana samuwa a harshe bututu. App zai iya canja harshe na menus da buttons. Help content kuma samuwa a yawancin wadannan harshe kuma an gini shi cikin app. Za ka iya download ko update help pack na harshe — bude **Saituna** → **Help** ko **Manage Resources** → **Install from GitHub** → **Help docs**.

## Yadda ake bude language settings

1. Bude **Saituna (Settings)**.
2. Danna **Language**.

## Yadda ake canja app language

1. A cikin **Language** list, danna harshe da kake so.
2. App yana apply sabon harshe nan take.

Zaɓuɓɓukan da ka ga sun dogara ne akan harshe da app yake support.

## Yadda harshe ya zaba a farko install

Lokacin da ka farko install Theodia, app yana zabi harshe dogara ne akan device settings na ka. Za ka iya canja shi a kowane lokaci.

## Abin da ake fassara

- Menus, buttons, da labels.
- Settings screens.
- Error messages.
- Search da study tools.

## Abin da ya kasance a Turanci kawai

- Wasu book da devotional content.

## Bible translations da app language

App language da Bible translation language su daban ne. Za ka iya samun app a Spanish da Bible a Turanci, ko akasin haka.

Don canja Bible translation, dubi jagorar [Installing Bible Translations](theodia://help/installing-bibles).

## Tukuna

- Idan button ko label gaba daya ne (пуст), app yana missing translation. English version yawanci yana nan a matsayin fallback.
- Idan kana so ka taimaka ka fassara app din, dubi jagorar [Where to Ask Questions](theodia://help/getting-more-help).
