---
title: The Launcher Menu
level: everyday
categories: layout
summary: Tafiya mai sauquatile don jump to recent verses, run commands, da switch Bible layouts ba tare da barin current screen ba.
---

# The Launcher Menu

> **Yadda za a yi:** The Launcher Menu yana bukatar **Yanayin Malami (Scholar)**. Za ka iya canja yanayoyi a **Saituna** → **Yanayin Mai Amfani na App**.

The Launcher Menu shi ne fast-access panel da za ka iya bude shi daga ko'ina cikin app din. Yana kiyaye recent verses, commands, da saved Bible setups a wuri daya.

## Yadda ake bude shi

Danna **expand icon (⌄)** a cikin top-right corner na home screen header. Panel yana slide in daga saman.

## Abin da yake ciki

### 1. Command Box

A saman panel akwai text box mai keyboard icon. Rubuta command sannan danna **Go** a kan keyboard na ka. App yana karanta command sannan kasa ka je direct.

Misalai:

- `John 3:16` — yana buɗe wannan ayarsa.
- `search love` — yana bincika Littafi Mai Tsarki domin "love".
- `bookmark psalms 23` — yana bookmark ayarsa.
- `kjv` — yana canja zuwa KJV translation.

Don full list of commands, dubi jagorar [Commands](theodia://help/commands).

### 2. Parallel Sets

Idan ka ajiye parallel Bible presets, suna bayyana a nan a matsayin collapsible list. Danna daya don instantly load wancan parallel setup.

Domin create parallel preset:

1. Bude **Saituna** → **Parallel Bible**.
2. ƙara translations sannan danna **Save Preset**.
3. Ba shi name. Yana bayyana a Launcher Menu.

Long-press parallel set a cikin Launcher Menu don goge shi.

### 3. Bible Collections

Bible Collections su ne one-tap shortcuts da ke switch translation ka da parallel view nan take. Idan ka create anya, suna bayyana a nan a matsayin collapsible list.

Long-press collection don goge shi.

### 4. Feature Icons

A ƙarƙashin command box za ka iya ganin layin round emoji buttons. Waɗannan one-tap shortcuts ne zuwa major features na app.

Available icons include:

- **About**, **Bibles**, **Bible Notes**, **Bookmarks**, **Books**
- **Devotionals**, **Flashcards**, **Help**, **Highlights**
- **Playlists**, **Plugins**, **Search**, **Settings**, **Theoscript**

Domin zabi waɗanne icons suke bayyana da a cikin wane order:

1. Bude **Saituna** → **Launcher Menu**.
2. Danna **Launcher Menu Icons**.
3. Amfani da switches don show / hide kowane icon.
4. Amfani da up/down arrows don reorder waɗanda ka enable.

Order a settings shine order da suke bayyana a Launcher Menu.

### 5. Recent Verses

App yana tunawa da last surori da ayarsa da ka bude. Suna bayyana a matsayin jeri a ƙasashen panel. Danna entry don jump kai tsaye baya.

- **Tap** don bude.
- **Swipe hagu** ko **long-press** don cire daga jeri.
- Danna **Clear all** don cire kowane entry nan take.

## Lokacin amfani da Launcher Menu

Amfani ne yayin da kake so ka:

- Jump baya zuwa ayarsa da ka karanta ka.
- Rubuta command ba tare da je home screen ba.
- Switch translation ko parallel setup a tap ɗaya.
- Bude major feature daga ko'ina cikin app din.
- Kaada yanzu ba tare da navigating ta menus ba.

## Tukuna

- The Launcher Menu yana samuwa a kan almost kowane screen, don haka za ka iya buɗe shi yayin karanta sura.
- Command box yana support same commands kamar home screen command box.
- Feature icons da nasa order suna ajiye locally a kan na'urarka. Suna survived app restarts.
- Recent verses suna ajiye locally a kan na'urarka. Suna survived app restarts.
