---
title: Navigating Between Books, Chapters, and Verses
level: everyday
categories: [layout, read]
summary: Yadda ake motsa a cikin Littafi Mai Tsarki da jump zuwa inda kake so ka je.
---

# Navigating Between Books, Chapters, and Verses

Wannan guide tana nuna maka duk hanyoyin don motsawa a cikin Littafi Mai Tsarki.

## Easy way: swipe

- Swipe **hagu** a kan sura don je zuwa sura ta gaba.
- Swipe **dama** don komawa baya.
- Wannan yana aiki a kusar littattafai. Bayan last sura na Exodus, swipe yana kai ka zuwa first sura na Leviticus.

## Menu way

- Danna translation name a saman don canja zuwa Bible dabam.
- Danna book name a saman don zabi littafi dabam.
- Danna chapter number don zabi sura dabam.

## Quick way: type

- A kan home page, akwai box a saman. Rubuta reference, kamar `John 3:16` ko `psalms 23`, sannan danna **Go** key a kan keyboard.
- App yana buɗe ayarsa.

## Bookmark way

Idan ka ajiye ayarsa, bude **Bookmarks** tab. Danna entry domin jump zuwa gare ta.

## Search way

Danna **Search** tab. Rubuta kalma. App yana nuna maka kowane ayarsa da ke da ita. Danna result don bude ta.

## History way

App yana tunawa da surori da ka bude. Domin nemo su akai-akai, duba a **Bookmarks** tab (domin kowane ayarsa da ka ajiye) ko scroll book list a **Bible** tab don neman littafin da ka karanta recently.

## Tukuna

- Bible tab yana nuna books a order daga Genesis to Revelation.
- Domin Psalms, Proverbs, da wasu long books, danna littafin sannan amfani da chapter list don jump far ahead.
