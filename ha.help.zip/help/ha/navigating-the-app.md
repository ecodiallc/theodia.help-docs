---
title: App Layout and Navigation
level: beginner
categories: layout
summary: Tour na home screen, main menu, da bottom toolbar — inda kowane abu yake.
---

# App Layout and Navigation

Theodia yana da main areas guda uku da za ka motsa cikinsu: **home screen**, **main menu**, da **bottom toolbar**. Wannan guide tana sanar da kowanne domin koyaushe ka san inda za ka je.

## Quick map

- **Home screen** ita ce page da ka ga yayin da ka farko bude app din. Yana da search box, big buttons don kowane part of app, da jerin installed Bibles, books, da devotionals.
- **Bottom toolbar** (wanda aka kira tab bar) shi ne layin icons a ƙasashen screen. Danna kowane domin jump straight zuwa wancan part of app.
- **Main menu** shine icon mai lines uku (☰) a top-right corner na home screen. Danna shi don bude jerin kowane screen a cikin app, including waɗanda ba su da own tab.

## Home screen

Lokacin da ka farko bude Theodia, ka landing a home screen. An rabe shi zuwa sassa hu'u, daga saman zuwa ƙasa.

### The header

A saman cikakken kauri bar yana. A hagu akwai app icon da name "Theodia." A dama akwai main menu button (☰). Lokacin da kake a cikin book ko chapter, hagu yana nuna back button (←) maimakon. Danna main menu don bude menu (duba ƙasa).

### The Command

Chok da header akwai search-style text box labeled **Command**. Rubuta short instruction sannan danna go key a kan keyboard. App yana karanta instruction sannan kasa ka je right screen. Misalai:

- `psalms 23` — yana buɗe Psalms chapter 23
- `john 3:16` — yana buɗe John 3:16
- `search love` — yana search Littafi Mai Tsarki domin "love"
- `bookmark john 3:16` — yana ajiye John 3:16 a matsayin bookmark
- `commentary romans 8:28` — yana buɗe commentary domin wancan ayarsa
- `xref` (followed by reference) — yana buɗe cross-references domin wancan ayarsa
- `help` — yana buɗe list of commands mai misalai

Idan app ba ya fahimci abin da ka rubuta ba, yana nuna small alert mai hint. Dubi **Common Problems** guide idan commands ba su aiki ba.

### Button grid

A ƙarƙashin Command akwai grid of large buttons, biyu per row. Kowane button yana kai ka ne zuwa part dabam na app. Buttons sun haɗa da:

- 📖 **Bibles** — jerin Bible translations naka
- 🔍 **Search** — search Littafi Mai Tsarki domin kalma ko jumla
- 📚 **Books** — library of Christian classics
- 📅 **Devotionals** — daily devotionals
- 🔖 **Bookmarks** — saved verses da chapters
- 🖍 **Highlights** — color-marked verses
- 📝 **Notes** — your private notes on verses
- ⚙️ **Settings** — language, theme, resources, da more
- ❓ **Help** — help system (wannan page)
- ℹ️ **About** — app version da credits

### Resource lists

A ƙarƙashin button grid akwai expandable sections: **Bibles**, **Books**, da **Devotionals**. Kowane section yana nuna items da ka shigar. Danna section header don expand ko collapse. Danna kowane item a section don bude shi.

Bibles section shine fastest way don jump into specific translation — no menus, kawai tap.

## Bottom toolbar

Bottom toolbar (tab bar) shine layin icons a ƙasashen screen. Yana zama visible kusan ko'ina cikin app din, don haka za ka iya koyaushe jump zuwa wasu section. Tabs da ka ga sun dogara ne da yanayin mai amfani na ka.

**All modes suna ganin:**

- 🏠 **Home** — yana buɗe home screen
- 📖 **Bibles** — yana buɗe list of Bible translations
- 📚 **Books** — yana buɗe library of books
- 🔍 **Search** — yana buɗe Bible search
- ⚙️ **Settings** — yana buɗe settings

**Standard da Scholar mode kuma suna ganin:**

- 🔖 **Bookmarks** — yana buɗe saved verses
- 🖍 **Highlights** — yana buɗe color-marked verses
- 📝 **Notes** — yana buɗe private notes

**Scholar mode kuma yana ganin:**

- 💻 **AI** — yana buɗe AI assistant (idan ka kunna she a Settings)

Current tab an haskaka. Danna kowane other tab don canja.

### Toolbar behavior

Kixin tab a cikin toolbar yana da own **stack** of screens. Lokacin da ka danna tab, za ka je baya zuwa **inda ka baruri** a cikin wannan tab's stack, ba starting screen ba. For example:

- Danna **Bibles** → ka ga list of Bible translations.
- Danna translation → ka ga list of books.
- Danna book → ka ga list of chapters.
- Danna sura → kana karanta sura.
- Switch zuwa **Bookmarks** don check wani abin.
- Danna **Bibles** akai-akai → ka koma sura da kake karanta.

Kixin tab yana tunawa da inda ka ce. App yana kiyaye navigation history cikin kixin tab, don haka switch tsakanin tabs ba ya rasa progress na ka.

### Abin da yake reset daba tab

Tab kawai yana reset zuwa root screen lokacin da:

- Ka kungu kan wancan tab kuma ka danna wancan tab icon akai-akai. Wannan yana da sauri don go back zuwa start.
- App ya force-closed kuma aka sake bude.

### Bottom tabs vs main menu

- **Bottom tabs** — kixin tab yana tunawa da own stack. Danna tab yana koma ka ne inda ka baruri.
- **Main menu** — danna item yana Navigate zuwa wancan screen ta amfani da same tab system. Ba ya buɗe a matsayin overlay.

Amfani tabs don switch tasks. Amfani main menu yayin da kake so full list of kowane screen a cikin app.

### Lokacin amfani da toolbar

Amfani toolbar yayin da kake so ka switch abin da kake aiki:

- Kana karanta sura kuma kana so ka search wani abu dabam → danna **Search**.
- Kana searching kuma kana so ka kaada bookmarks naka → danna **Bookmarks**.
- Kana ko'ina cikin app kuma kana so ka je home → danna **Home**.

## Main menu

Main menu shine button mai three stacked lines (☰) a top-right corner of home screen. Danna shi sannan panel yana slide in daga dama. Panel yana nuna kowane screen da yanayin ka na yanzu ya support:

- 🏠 **Home**
- 📖 **Bibles**
- 📚 **Books**
- 🙏 **Devotionals**
- 🔍 **Search**
- 🔖 **Bookmarks** (Standard da Scholar)
- 🖍 **Highlights** (Standard da Scholar)
- 📝 **Notes** (Standard da Scholar)
- 💻 **AI Assistant** (Scholar kawai, da kawai idan AI ya kunna)
- ⚙️ **Settings**
- ❓ **Help**
- ℹ️ **About**

Item da ya matches screen na yanzu an haskaka kuma yana da small dot a kusa da shi. Danna entry domin je straight zuwa gare shi. Danna outside panel, X a saman, ko device's back button don rufe shi ba tare da canja screens ba.

### Yadda main menu yake dabam

Main menu shine dropdown panel, ba wata separate navigation layer ba. Lokacin da ka danna item, app yana Navigate zuwa wancan screen kamar yadda ka yi amfani da bottom tab ko button grid. Current tab's stack an kiyaye, don haka za ka iya komawa inda ka baruri by danna original tab akai-akai.

Misali:

- Kana karanta John 3. Ka danna **Bookmarks** tab. Ka je zuwa bookmarks. Lokacin da ka danna **Bibles** akai-akai ka koma John 3 — right inda ka baruri.
- Kana karanta John 3. Ka bude main menu sannan danna **Notes**. Notes naka suna buɗewa. Don koma John 3, danna **Bibles** tab kuma ka koma sura ta atomatik.

Tabs suna switch context na ka kuma tunaws da inda ka ce. Main menu kawai another way ne don reach same screens.

### Lokacin amfani da main menu

Amfani main menu yayin da:

- Kana so ka buɗe **Highlights**, **Notes**, **Devotionals**, **Help**, ko **About** — screens da ba su da own toolbar tab.
- Kake deep a cikin sura ko search kuma kana so ka kaada wani abin quickly ba tare da rasa inda ka ce ba.
- Kana so ka buɗe **Settings** ba tare da barin screen da kake a ba.

## Scholar mode

Idan yanayin mai amfani na ka yana canja zuwa **Scholar**, layout yana samun extra tabs, menu items, da reader tools da Reader da Standard mode suke ɓoye. Dubi jagorar [Scholar Mode](theodia://help/scholar-mode) domin full walkthrough na kowane feature.

## Yadda areas guda uku suke tafiya tare

- **Switch to wata dabam main section** (Bibles, Search, Bookmarks, da sauransu) → Bottom toolbar
- **Jump zuwa specific ayarsa ko command** → Home screen Command
- **Browse kowane available screens** → Home screen button grid
- **Kaada Notes, Highlights, ko Help ba tare da barin inda kake ba** → main menu
- **Buɗe Settings daga ko'ina** → main menu ko toolbar

Za ka yi amfani da duka uku. Babu ɗaya da shine "right way." Zabi whichever ne easiest domin abin da kake aiki.

### Toolbar vs main menu: quick misali

Imagine kana karanta Romans 8 kuma kana so ka highlight ayarsa da kake so.

**Amfani toolbar:**

1. Danna ayarsa don bude verse menu.
2. Danna **Highlight** sannan zabi launi.
3. Gama. Ba ka barin sura ba.

**Amfani main menu (idan kana so ka review highlights naka):**

1. Danna ☰ don bude menu.
2. Danna **Highlights**. Highlights list naka ya buɗe.
3. Review su, sannan danna **Bibles** tab don koma Romans 8.

**Amfani toolbar (idan kana so ka switch tasks):**

1. Danna **Home** ko **Bookmarks** a cikin toolbar.
2. Ka barin Romans 8 sannan ka je new screen.
3. Don koma Romans 8, danna **Bibles** akai-akai — ka koma sura ta atomatik.

## Tukuna

- Home screen yana tunawa da waɗanne sections an expanded ko collapsed. Ka bukatar ka setup sau ɗaya kawai.
- Idan ba ka ga tab da ka tsammani ba, kaada abubuwa biyu:

1. **Yanayin mai amfani na ka** — Reader mode yana ɓoye bookmarks, highlights, notes, da AI. Standard mode yana ɓoye AI. Canja yanayoyi a **Saituna** → **Yanayin Mai Amfani na App**.
2. **Feature settings** — wasu tabs suna bukatar a kunna su a **Saituna** (misali, AI assistant).
