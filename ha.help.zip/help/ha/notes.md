---
title: Rubuta Rubuce-rubuce
level: everyday
categories: [annotate, read]
summary: Yadda ake rubuta tunaninka kusa da aya.
---

# Rubuta Rubuce-rubuce

> **Yanayi:** Rubuce-rubuce suna nan a cikin yanayin **Tsarin** da **Malami**. Yanayin mai mayar da hankali (Focus Mode) don karatu mai tsabta da bai damu ba ne kawai. Kana iya canza yanayin a **Saitunan** → **Yanayin Mai Amfani**.

Rubuce-rubuce wurin da kake rubutan tunaninka, addu'arka, ko ra'ayoyin karatu kusa da aya. Kowanne rubutu yana daura da wata aya ta musamman.

## Yadda ake ƙara rubutu

1. Buɗe ayar.
2. Taɓa ayar don bugo menyu.
3. Taɓa **Rubutu** a cikin menyu. Yana da hoton fensir.
4. Rubuta rubutcinka.
5. Taɓa **Ajiye**.

Rubutun yanzu an ajiye tare da ayar.

## Yadda ake karanta rubutu

1. Buɗe ayar.
2. Nemo alamtar fensir kusa da ayar. Yana nufin akwai rubutu.
3. Taɓa ayar. Rubutun zai bayyana a ƙasa.

## Yadda ake gyara rubutu

1. Buɗe ayar masu rubutu.
2. Taɓa ayar.
3. Taɓa **Rubutu** a cikin menyu.
4. Yi canje-canjenta.
5. Taɓa **Ajiye**.

## Yadda ake share rubutu

1. Buɗe ayar masu rubutu.
2. Taɓa ayar.
3. Taɓa **Rubutu** a cikin menyu.
4. Taɓa **Share**.

## Yadda ake ganin dukkan rubuce-rubucenka

Taɓa **Rubuce-rubuce** tab a ƙasa. Ka ga jerin kowane rubutun da ka yi, an tsara su bisa kwanan wata.

## Bincika rubuce-rubucenka

A cikin **Rubuce-rubuce** tab, taɓa **Bincika** akwati. Rubuta wata kalma. App ɗin zai samo kowane rubutu da ke da wannan kalma.

## Shawarwari

- Rubuce-rubuce suna da kyau don wa'azi, ibada, da tambayoyin karatu.
- Rubuce-rubuce masu zaman kansu suke. Suna kwance a na'urarka.
- Duba [Ajiye Bayananka](theodia://help/backups) jagorar don kiyaye su lafiya.
