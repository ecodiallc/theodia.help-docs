---
title: Sanarwa da Tunatarwa
level: everyday
categories: [settings]
summary: Yadda ake kunna, tsara, da sarrafa tunatarwa ba tare da intanet ba don addu'a, ibada, tsare-tsare na karatun Littafi Mai Tsarki, da sauransu.
---

# Sanarwa da Tunatarwa

Theodia na iya tunatar maka game da addu'a, ibada, tsare-tsaren karatun Littafi Mai Tsarki, katin farawa, da sauran ayyuka — har ma lokacin da app ɗin ya kasance ba tare da intanet ba. Dukkan tunatarwa suna ajiyewa a na'urarka; ba a bukatar intanet ko sabar sanarwa.

## Yadda ake kunna ko kashe tunatarwa

1. Buɗe **Saitunan**.
2. Taɓa **Sanarwa**.
3. Kunna ko kashe **Kunna tunatarwa**.

Farkon lokacin da ka kunna tunatarwa, app ɗin zai nemi izini don aikawa da sanarwa. Taɓa **Yarda** don tunatarwa su iya fitowa.

Idan ka ƙin yarda a da, iOS ko Android iya hanawa. A wannan sabili, je cikin app ɗin **Saitunan** na na'urarka, nemo **Theodia**, ka kunna sanarwa a can.

## Nau'in tunatarwa

Shafin sanarwa ya rabu zuwa tashoshi. Kowanne tasha iyali ne na tunatarwa da zaka iya kunna ko kashe daban:

- **Tunatarwar addu'a** — babbar tunatarwa ta addu'a.
- **Tsarin addu'a** — tunatarwa da ke daura da wani tsarin addu'a na musamman.
- **Ibada** — aya ta yau ko tunatarwar ibada ta yau.
- **Tunatarwar tsare-tsaren karatun Littafi Mai Tsarki** — tunatarwa don tsarin karatun Littafi Mai Tsarki da ake amfani da shi.
- **Tunatarwar Theoscript** — tunatarwa don aiwatar da Theoscript.
- **Tunatarwar fahimtar AI** — tunatarwar da aka samar ta AI.
- **Tunatarwar bita katin farawa** — bukatar bita katin farawa.
- **Tunatarwar al'adar karatu** — bukatar al'adar karatu na yau.
- **Tunatarwa ta ibada da kakara** — tunatarwa da ke daura da kalanda na coci.
- **Tunatarwata** — tunatarwar da kake samu daga alamta, haske, jerin waža, surori na Littafi Mai Tsarki, ko littattafai.
- **Tunatarwa ta musamman** — cikakken tunatarwar da kake kanka ka ƙirƙira.

Taɓa kowanne tasha don ganin tunatarwarta, canza lokaci, zaɓi kwanakin da zai buga, ko kashe ta.

## Tunatarwa ta musamman

Tunatarwar da kake gina daga farar laki.

1. A cikin **Saitunan** → **Sanarwa**, taɓa **Tunatarwa ta musamman**.
2. Taɓa button **+**.
3. Input **Shiryawa** da **Saƙo**.
4. Zaɓi **Lokaci**.
5. Zaɓi **Kwanaki** da kake so a maimaitawa.
6. Zaɓi abin da tunatarwar ta buɗe lokacin da aka taɓa (zaɓi ne kawai).
7. Taɓa **Ajiye**.

Kana iya gyara ko share tunatarwa ta musamman nan take ta hanyar taɓa ta a cikin jerin.

## Abin da ya faru idan ka taɓa tunatarwa

Yawancin tunatarwa suna buɗe wani shafin musamman a cikin app ɗin. Alal misali, tunatarwar tsarin addu'a takan buɗe wannan tsarin; tunatarwar tsarin karatun Littafi Mai Tsarki takan buɗe karatun gaba.

Idan tunatarwa ba ta da shafin da aka haɗa, takan buɗe app ɗin cikin Home screen.

## Lokacin shiru

Lokacin shiru yana hushing sautin sanarwa yayin har yanzu yana barin sanarwa na gani sananne.

1. A cikin **Saitunan** → **Sanarwa**, taɓa **Lokacin shiru**.
2. Saita **Fara** da **Ƙarshe**.

Tunatarwa da aka shirya a lokacin shiru zai nuna a allon ba tare da sauti ba.

## Tunatarwa masu dawowa da tarihi

- **Tunatarwa masu dawowa** suna nuna duk abin da aka shirya don bugawa nan gaba.
- **Tarihin sanarwa** yana nuna tunatarwa da aka yi kwanan nan, aka shirya, da aka soke.

Yi amfani da waɗannan jerin don tabbatar da cewa tunatarwa an saita gaba ɗaya ko ganin me ya sa bai fito ba.

## Idan tunatarwa ba sa fitowa

- Ku tabbata **Kunna tunatarwa** yana kan.
- Duba cewa sanarwa sun yarda a cikin saitunan na'urar.
- Ku tabbata tashar tunatarwar yana kunna kuma a zaɓi akalla wana rana.
- Idan ka saita shiru, tunatarwar iya zama ba tare da sauti ba.
- Wasu masassa na Android suna sa app din ya yi barci. Ƙara Theodia cikin jerin abubuwan da aka yarda idan na'urarka ya baiwa saitunan optimizayon baturi.
- Idan tunatarwa ta daura da abun da ka cire (alal misali, tsarin karatun Littafi Mai Tsarki da aka share ko tsarin addu'a), tunatarwar iya ba ta buga har sai ka sake zaɓi ƙwararrun manufa.

## Sautin sanarwa

Kana iya zaɓi sautin da tunatarwa ke bugawa da ke tallafawa sauti. Taɓa **Sauti** a cikin tunatarwa ko tasha don zaɓi daga zaɓuɓɓuka. Sautunan suna hadaka da app ɗin, don haka suna aiki harma lokacin ba tare da intanet ba.

Yi amfani da button **Ji sauti** don jin sautin da aka zaɓi kafin ajiye.

## Alamu

Wasu tunatarwa na iya ƙara alama a kan app icon. Taɓa **Clear badge** a cikin shafin sanarwa don sake saita shi.
