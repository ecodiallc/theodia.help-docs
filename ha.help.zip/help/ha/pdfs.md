---
title: Fayilolin PDF
level: everyday
categories: [read, resources]
summary: Shigarwa, tsari, da karatu na takardun PDF a Theodia.
---

# Fayilolin PDF

> **Yanayi:** Fayilolin PDF suna nan a cikin yanayin **Tsarin** da **Malami**. Yanayin mai mayar da hankali (Focus Mode) don karatu mai tsabta da bai damu ba ne kawai. Kana iya canza yanayin a **Saitunan** → **Yanayin Mai Amfani**.

Theodia na iya adana da karanta fayilolin PDF. PDF da aka shigar suna kwance a na'urarka, don haka suna aiki ba tare da intanet ba.

## Buɗe ɗakin karatu na PDF

Taɓa **PDFs** tab a ƙasa na allon, ko taɓa **PDFs** tile a kan Home screen.

## Shigar da PDF

1. Buɗe **PDFs** tab.
2. Taɓa button **+** a ƙasan gefen hannun dama.
3. Zaɓi PDF daga na'urarka.
4. (Zaɓi ne) Rubuta ko zaɓi rukuni don tsara shi.

## Tsara PDFs

Taɓa mai tsawo kowanne PDF card don buɗe menu tare da waɗannan zaɓuɓɓuka:

- **Canza suna** — canza taken da aka nuna a ɗakin karatu.
- **Canza rukuni** — tura PDF cikin rukuna.
- **Delete** — share PDF daga Theodia. Haka ma yana share matsayin karatu da aka ajiye.

Rukunan rubutun kyauta ne. Rubuta sabon suna ko zaɓi wanda ya rigaya yanda kake shigar ko canza rukuni.

## Karanta PDF

Taɓa PDF card don buɗe shi. Karatu yana nuna:

- Taken takarda a cikin bar a saman.
- Layin button na shafuka: **Shafa na farko**, **Bayan**, shafin yanzu ("3 / 120"), **Mai gaba**, da **Shafa na ƙarshe**.
- Toolbar tare da kayan aikin takarda: **Lissafi**, **Zoom out**, **Zoom in**, **Maya zurfi zuwa asali**, **Alamta**, **Bincika**, **Saurari**, da **Duba rubutu**.

Wasu kayan aiki suna haske-fuskata idan ba za a iya amfani da su ba — alal misali, **Bincika** da **Saurari** sukan haske-fuskata har sai an shigar da bincike-abin karatu na PDF ɗin.

### Mayar da shafuka

- Taɓa **chevron na hagu** ko **dama** don komawa ko gaba shafi guda.
- Taɓa **Shafa na farko** ko **Shafa na ƙarshe** don tsallakawa zuwa ƙuƙashin takarda.
- Taɓa lamban shafi (alal misali "3 / 120") don buɗe grid ɗin shafuka, sannan taɓa shafin da kake so. Grid ɗin ya buɗe kusa da shafin da kake kan shi.
- Yi amfani da **Majigi Left** da **Right arrow keys** a kan keyboard na waje.

### Zoom

- Taɓa **Zoom in** (+) ko **Zoom out** (−) don canza girman shafi.
- Taɓa **Maya zurfi zuwa asali** don mayar da shafi zuwa girman yau.
- Idan ka zurfi zuwa, ka mayar shafi, sannan ka koma, Theodia zai mayar maka zuwa shafin da kake karatu.

## Bincika a cikin PDF

1. Buɗe PDF ka taɓa **Bincika** (magnifying glass) button a cikin toolbar.
2. Rubuta abin da kake neman. Sakamakon bincike ya bayyana yayin da kake rubutu, tare da lamban shafi da ɓangare na rubutun da ke kewaye.
3. Taɓa sakamako don tsallakawa zuwa wancan shafi.

Binciken ya bukaci an shigar da bincike-abin karatu na PDF ɗin. Idan ba a shigar da shi ba tukuna, button ɗin Bincika yana haske-fuskata. PDF da aka shigar daga al'ummar GitHub repository suna da bincike-abin karatu; PDF da kake shigar da kanka ba su da shi har sai an ƙara.

## Lissafi

Idan PDF ɗin yana da table of contents (lissafi) na ciki, button ɗin **Lissafi** a cikin toolbar yana nuna shi kamar outline. Taɓa taken sashe don tsallakawa zuwa wancan shafi. Sashe iya buɗewa ko ɓoyewa. Idan PDF ɗin ba shi da table of contents, button ɗin yana haske-fuskata.

## Alamta a cikin PDF

1. Buɗe PDF ka taɓa button ɗin **Alamta** a cikin toolbar.
2. Taɓa **Alamta shafi** don ajiye shafin yanzu. Sunan yana farawa da lamban shafi — rubuta suna idan kana son — sannan taɓa **Ajiye**.
3. Taɓa kowanne alamta a cikin jerin don tsallakawa zuwa shafinsa.
4. Taɓa **×** kusa da alama don share ta.

Alamta ta PDF ɗin ba ta haɗa da alamtar Littafi Mai Tsarkinka. Kowanne PDF yana da nasu jerin.

## Karanta PDF da sauti

Idan bincike-abin karatu na PDF ɗin ya shigaru, Theodia na iya karanta shafin yanzu da sauti:

1. Buɗe PDF ka taɓa **Saurari** (speaker) button a cikin toolbar.
2. Gwaiwan sarrafa yawu tayyara tare da **Play/Pause**, **Jawo baya**, **Gaba da sauri**, **Dakata**, gwaiwan ci gaba da zaka iya taɓa da skipping a cikin shafi, saurin karatu, da murya.
3. Idan shafi ya ƙare, karatu ya ci gaba a shafin gaba da kansa.

Murya da sauri suke yauken abin da ake amfani dashi don karatun Littafi Mai Tsarki — duba [Karatu da Sauti](theodia://help/tts) don yadda ake canza su.

## Kwafi, rabawa, ko ajiye rubutun shafi

Taɓa button ɗin **Duba rubutu** a cikin toolbar don ganin shafin yanzu a matsayin rubutu mai tsabta. Daga can zaka iya:

- **Kwafi** — kwafa rubutun shafin zuwa clipboard.
- **Raba** — raba rubutun shafin ta wani app a na'urarka.
- **Ƙara a cikin bayanan karatu** — buɗe edita na rubutun tare da rubutun shafin, saitin citation, da hanyar haɗin baya zuwa wannan shafi wedd.

## Ci gaba da karatu

Theodia yana tunawa da shafin ƙarshe da ka kalli kuma yana buɗe PDF ɗin a can lokaci na gaba.

## Saukar da PDF daga GitHub

A cikin **Malami** yanayi, button ɗin **Saukar da daga GitHub** yana bayyana a ƙasan ɗakin karatu. Wannan yana haɗawa da al'ummar PDF repository don ka iya shigar da takardun PDF da aka hadaka kamar yadda kake shigar da Littafi Mai Tsarki ko littattafai.

## Bayanai

- PDFs suna adana a cikin Theodia's masu masunan fayilole. Ba a hada su a ajiyar, don haka idan ka koma zuwa sabuwar na'ura zaka bukaci ka sake shigar.
