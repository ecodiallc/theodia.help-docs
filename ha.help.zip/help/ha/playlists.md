---
title: Jerin playlist
level: everyday
categories: playlists
summary: Ƙirƙirar da sauraren jerin playlist da aka faɗi a haute na ayoyin Littafi Mai Tsarki, rubutun gari, ko kowanne aya da kake so ka ji.
---

# Jerin playlist

**Jerin playlist** jerin gwaya ne da Theodia zai iya karanta maka a haute. Kowanne gwaya ko aya ce ta Littafi Mai Tsarki ko rubutun gari mai gajere. Jerin playlist suna amfani lokacin da kake gaba da intanet, tafiya, ibada, ko aikin hadda to memory.

Jerin playlist suna bayyana a cikin app ɗin idan an ƙirƙira ko an cika akalla jagoran playlist guda.

## Inda ake samun Jerin playlist

Lokacin da akwai jerin playlist, zaka iya shiga cikinsu ta hanyar biyu:

- **Home screen:** A cikin ** Plugins & More **, taɓa ** Jerin playlist **.
- **main menu:** Buɗi menu (☰) ka taɓa ** Jerin playlist **.

Idan babu jerin playlist har ma, tile ɗin Jerin playlist da menu entry suna ɓoye.

## Abin da jerin playlist ke ƙunsawa

Kowanne jerin playlist yana da:

- **Sunan** — alal misali, "Aya ta safe" ko "Hadda Zabura 23".
- **Rukuni** (zaɓi ne) — yana taimaka tsara jerin playlist bisa manufa.
- **Jerin gwaya** — abubuwan da ake karanta a haute.

Kowanne gwaya yana ƙunshe da:

- **Abun da ke ciki** — ko dai nassi na aya ta Littafi Mai Tsarki ko rubutun gari.
- **Labari** — ana nuna shi a allon lokacin da gwaya take buga.
- **Murya** (zaɓi ne) — zaɓi wasu murya don wannan gwaya.

## Ƙirƙirar jerin playlist

1. Buɗe **Jerin playlist** screen.
2. Taɓa **Ƙirƙiri jerin playlist** (ko button **+**).
3. Ba wa jerin playlist suna.
4. (Zaɓi ne) Zaɓi ko ƙirƙiri rukuni.
5. Farawa ƙara gwaya.

### Ƙara gwaya daga aya ta Littafi Mai Tsarki

1. Taɓa **Ƙara gwaya**.
2. Zaɓi **Aya ta Littafi Mai Tsarki** a matsayin nau'in abun da ke ciki.
3. Input nassi, alal misali `Yohanna 3:16` ko `Zabura 23:1-6`.
4. Ƙara labari idan kana so, ko bar babu don amfani da nassin.
5. Ajiye gwaya.

### Ƙara gwaya ta gari

1. Taɓa **Ƙara gwaya**.
2. Zaɓi **Rubutun gari**.
3. Rubuta rubutun da kake so Theodia ya karanta.
4. Ƙara labari.
5. Ajiye gwaya.

### Batch ƙara gwaya

Idan kana da jerin nassoshi ko layukan rubutu, yi amfani da **Batch ƙara**:

1. Buɗe jerin playlist.
2. Taɓa menu ka zaɓi **Batch ƙara**.
3. Liƙa nassi guda ɗaya ko layukan rubutu a kowanne layi.
4. Kunna **Gano ayoyin Littafi Mai Tsarki** idan yawancin layukan su nassoshi ne.
5. Taɓa **Ƙara**. Kowanne layi yana zama gwaya.

## Sauraren jerin playlist

1. Buɗe jerin playlist da kake so ji.
2. Taɓa button ɗin **Play** a saman ko kusa da gwaya.
3. Theodia yana karanta kowanne gwaya a jere.

Yayin da jerin playlist ke buga, gwaiwan sarrafa yawu tayyara tare da waɗannan sarrafa:

- **Play / Pause**
- **Gwaya na gaba**
- **Gwaya na baya**
- **Dakata**

Kana iya saita kuma:

- **Sauri** — yadda murya ta karanta da sauri.
- **Maimaitawa** — maimaita cikakken jerin, gwaya guda, ko karanta sau ɗaya.
- **Gwaji** — buga gwaya da na sirri.
- **Ba a karanta abin da ke cikin kurakurai** — share rubutun da ke cikin parentheses.
- **Dakata tsakanin gwaya** — ƙara shiru gajere tsakanin gwaya.
- **Sleep timer** — dakata buga bayan lokaci da aka saita.

## Gyara jerin playlist

Don canza jerin playlist, farko dakata buga idan tune ke buga.

Kana iya:

- **Canza sunan** jerin playlist.
- **Canza jerin gwaya** — ja gwaya zuwa sabuwar matsayi.
- **Gyara gwaya** — canza nassin, rubutu, labari, ko murya.
- **Share gwaya** — cire shi daga jerin playlist.
- **Share cikakken jerin playlist** — wannan ba za a iya mayowa ba.

## Fitowa da shigar jerin playlist

Jerin playlist ana fitar da su azaman fayilolin JSON da ke ƙunshe da kowanne gwaya, rukuni, da saituna. Zaka iya rabawa fayil ɗin da wasu na'ura, kiyaye shi azaman ajiya, ko gyara shi a kwamfuta.

- **Fitowa dukkan jerin playlist** — ƙirƙiri `playlists-YYYY-MM-DD.json` file.
- **Fitowa rukuni** — ƙirƙiri JSON file da ke ƙunshe da jerin playlist a cikin rukuni guda kawai.
- **Shigar jerin playlist** — mayar da jerin playlist daga JSON backup file.

## Hanyoyin da sauri don ƙirƙirar jerin playlist

Zaka iya ƙirƙirar cikakken jerin playlist azaman JSON ka kuma shigar da shi. Ga misali:

```json
{
  "playlists": [
    {
      "name": "Morning Verses",
      "category": "Devotional",
      "tracks": [
        {
          "info": "John 3:16",
          "contentSource": "passage",
          "content": "For God so loved the world...",
          "rawContent": "John 3:16"
        },
        {
          "info": "Psalm 23",
          "contentSource": "passage",
          "content": "The Lord is my shepherd...",
          "rawContent": "Psalm 23:1-6"
        }
      ]
    }
  ]
}
```

Ajiye fayil ɗin, sannan yi amfani da **Shigar jerin playlist** don ɗaukar shi a Theodia.

## Shawarwari

- Jerin playlist suna aiki a mafi kyau tare da ƙananan, mai mayar da hankali ƙunshe na ayoyi.
- Yi amfani da rukuni don raba jerin playlist ta ibada daga jerin playlist ta hadda.
- Saita sleep timer idan kana sauraro yayin da kake barci.
- Idan gwaya ta yi amfani da murwar kamar rudewa, duba cewa yaren murya ta dace da yaren rubutu.
- Theodia yana karanta rubutun gari kamar yadda aka rubuta; duba fassarar don mafi kyawon sakamako.
