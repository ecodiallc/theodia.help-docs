---
title: Bayyanawar Addu'a
level: beginner
categories: prayer
summary: Gabatarwar taƙaice ga Prayer tab da manyan sashen ta.
---

# Bayyanawar Addu'a

**Addu'a** tab wurin da aka keɓe don addu'a. Ya haɗa jerin, zaman da aka bi da su, mujalla, timer, jadawalin karatun lectionary, da addu'ar tsari na gargaji.

## Manyan sashen

- **Jerin addu'a** — bi mutane, halaye, da batutuwa da kake addu'a a kansu.
- **Mujalla** — rubuta tunani, amsoshin, da ra'ayoyi a tsawon lokaci.
- **Samun Addu'a** — nemi Theophilus ya rubuta addu'a daga buƙata ko rubutun mujalla.
- **Creeds & Fixed Prayers** — addu'ar gargaji da creeds daga mutanen Kirista.
- **Lectionary** — jadawalin karatun Littafin Muqaddas don addu'a na yau ko na kakara.
- **Addu'a da aka bi da** — zaman addu'a mai sauti tare da text-to-speech.
- **Timer** — zaman addu'a da aka sa lokaci tare da kira na zaɓi.
