---
title: Karatun Littattafan da aka gina
level: beginner
categories: [content, read]
summary: Yadda ake karanta klasik na Kirista da suke tare da app ɗin.
---

# Karatun Littattafan da aka gina

Theodia tana zuwa tare da ƙaramin ɗakin karatu na littattafai na Kirista. Waɗannan klasik ne da zaka iya karanta a na'urarka.

## Yadda ake buɗe ɗakin karatu

Taɓa **Littattafai** tab a ƙasan allon. Ka ga jerin littattafai a cikin ɗakin karatunka.

## Yadda ake karanta littafi

1. Taɓa taken littafin.
2. Littafin ya buɗe zuwa sura na farko.
3. Yi amfani da button ɗin **Baya** da **Gaba** a saman don matsawa tsakanin surori.

## Yadda ake tsallakawa zuwa sura

Taɓa sunan sura a saman allon. Jerin surori yana bayyana. Zaɓi sura don tsallakawa zuwa ga ta.

## Yadda ake canza girman haruffa

Buɗe **Saitunan** → **Bayyanar** ka zaɓi girman haruffa. Girman rubutu yana canza a duk app ɗin, a cikin littattafai ma.

## Yadda ake ƙara alamta a cikin littafi

Taɓa icon **taya** a saman hannun dama. Suran yanzu ya ajiye. Taɓa **Alamta** tab don ganin shafukanka da aka ajiye.

## Yadda ake sauraren littafi

Taɓa icon **Mai magana** a saman hannun dama. App ɗin yana karanta suran a haute. Taɓa shi ƙara don dakatar.

## Waɗanne littattafai suke nan?

Ɗakin karatu yana da klasik kamar:

- Pilgrim's Progress
- The Imitation of Christ
- Practice of the Presence of God
- The Hymn Book

Jerin littattafai zai iya ƙaruwa tsawon lokaci. Sabuntawar app ɗin zai iya ƙara wasu.

## Shawarwari

- Littattafai suna adana a na'urarka. Ba a bukatar intanet.
- Littattafai ba sa sync zuwa cloud.
