---
title: Nemo Abubuwa A GitHub
level: everyday
categories: resources
summary: Bincika duk GitHub repos da app ɗin ya sani lokaci guda, sannan shigar da abin da ka sami.
---

# Nemo Abubuwa A GitHub

Theodia yana kiyaye jerin GitHub repos da suke wallafa abubuwa — Bibles, commentaries, books, devotionals, Jerin waža, prayer packages, da sauransu. **Search GitHub Repos** yana bincika dukkan su lokaci guda, don ba ka bukatar buɗe kowanne tab ka samu daban.

> Ɓangaren GitHub na Settings yana wanzu kawai a cikin **Malami** yanayi. Don kunnawa, je **Saitunan → Yanayin Mai Amfani → Malami**.

## Yadda ake bincika

1. Buɗe **Saitunan**.
2. Taɓa **Search GitHub Repos**.
3. Rubuta wata kalma a cikin akwatin binciken. App ɗin yana neman wannan kalma a cikin **sunan** da **bayanin** na kowanne package a cikin kowanne repo.

Wasu abubuwan da ya kamata ka sani a kan binciken:

- **Kowanne kalma dole ya dace.** Bincika `morning evening` kawai yana samun packages da sunan ko bayanin sa ke ƙunshe da kowanne kalmomin biyu.
- **Babu kula da manyan ko ƙananan haruffa.** `Morning` da `morning` suna samu packages ɗaya.
- **Mafi kyawon daidaitawa yana fara.** Package da sunansa *ya fara* da abin da kake bincika yana nuna kafin wanda ke ambata shi neawai a bayanin.

## Tace

Taɓa filter bar sama da sakamako don ƙwasan lissafin ƙari. Akwai filters guda biyu, kuma suna aiki tare:

- **Mai wallafa** — kawai packages na wannan mai wallafa.
- **Al'ada** — kawai packages na waccan al'ada.

Taɓa filter ƙara don share shi, ko taɓa **Share tace** don ajiye duka biyu.

## Shigarwa daga sakamakon

Kowanne sakamako yana nuna sunan package, nau'in resource, wanda ya yi shi, da repo da yake fitowa. A gefe na dama na layi akwai button guda:

- **Shigar** — package bai cikin na'urarka bai tukuna.
- **Sabunta** — sabon version ya nan. App ɗin yana neman tabbatar a da, domin sabuntawa yana share tsohon kwafi tare da kowanne rubutu, haske, ko alamta da ke nuna ga shi.
- **Bude** — package yana nan a na'urarka; taɓa ya sai ya kai ka zuwa shafin da ake amfani da shi.

Taɓa **Sabunta** a saman don neman sabon lissafin daga GitHub nan take. App ɗin yana sabunta lissafin da kansa sau ɗaya a rana, don haka manual refresh kawai yake bukatar idan ka san sabon abu ya wallafu.

## Bincika ba tare da intanet ba

App ɗin yana kiyaye kwafi na lissafin a na'urarka, don haka bincika yana aiki har ma lokacin da ka kasance ba tare da intanet. Idan app ɗin ba zai iya kaiwa GitHub don sabunta lissafin ba, bandar a saman zai gaya maka kana ganin sakamakon da aka adana.

## Idan binciken bai sami abu ba

- Gwada ƙarami, kalmar guda.
- Duba cewa babu filter na **Mai wallafa** ko **Al'ada** da ake amfani da shi — button ɗin **Share tace** yana bayyana lokacin da akwai ɗaya.
- Wasu repos suna wallafa packages a cikin harshe daban da sunan package, don haka bincika don kalmar da aka fassara iya ba ta samu ba.
