---
title: Yanayin Malami
level: advanced
categories: [layout, read, study]
summary: Yanayin karatu mafi zurfi a Theodia, yana buɗe commentaries, lexicons, cross-references, kayan aikin AI, da Launcher Menu.
---

# Yanayin Malami

> **Yanayi:** Yanayin Malami yana wanzu kawai lokacin da yanayin ku na mai amfani ya saita da **Malami**. Canza yanayin a **Saitunan** → **Yanayin Mai Amfani**.

Yanayin Malami yana buɗe kowanne kayan aikin karatu a Theodia. Ya ginu a kan Yanayin Karatu, don haka ka riƙe verse menu, parallel Bibles, alamta, haske, da rubuce-rubuce — ƙari da kayan aikin avansa da aka jera a ƙasa.

## Yadda ake buɗe Yanayin Malami

Yanayin Malami ba shafin daban ba ne. Saitin kayan aikin avansa ne da suke bayyana a cikin karatu da kuma navigation idan yanayin mai amfani ya saita zuwa Malami.

1. Buɗe **Saitunan**.
2. Taɓa **Yanayin Mai Amfani**.
3. Zaɓi **Malami**.

Canjin zai tasirin nan take. Menus da buttons da aka ɓoyu yanzu suna bayyana.

## Kayan aikin karatu na ƙari

Lokacin da ka buɗe sura a cikin [Yanayin Karatu](theodia://help/study-mode), Yanayin Malami yana ƙara waɗannan kayan aikin cikin verse menu:

- **AI Commentary** (◈) — nema AI assistant ya rubuta bayanin karatu don wannan aya. (Ba ya nan a duk yankuna.)
- **Word Info** (?) — buɗe lexicon entry don asalin kalmar Ibrananci ko Girik a bayan aya. Duba [Commentaries and Lexicons](theodia://help/commentaries-and-lexicons) jagorar.
- **Kamus** (📖) — nemo kalmomin Littafi Mai Tsarki a cikin kamus da ka shigar. Duba [Bible Dictionary](theodia://help/dictionary) jagorar.

Waɗannan kayan aiki suna bukatar an shigar da abubuwa (commentaries, lexicons, kamus). Idan kayan aiki yana haske-fuskata ko yana nuna "not found", buɗe **Saitunan** → **Manage Resources** ka ƙara resource ɗin da yake bukata.

## Navigation ƙari

### Extra toolbar tab

Bottom toolbar yana ƙara tab guda:

- 💻 **AI** — buɗe AI assistant (kawai idan ka kunna AI a Saitunan). Wannan tab yana nan da dama da Notes.

### Extra main menu items

Main menu yana ƙunshe da **AI Assistant** entry ƙarƙashin waccan sharuɗɗu.

## Launcher Menu

Yanayin Malami yana kunnar **Launcher Menu**, hanya mai sauri don tsallakawa zuwa ayoyin kwanan nan, gudanar da commands, da switching layouts na Littafi Mai Tsarki ba tare da barin shafinka na yanzu. Duba [Launcher Menu](theodia://help/launcher-menu) jagorar don yadda ake amfani da shi.

## Yaushe ake amfani da Yanayin Malami

- Kana so AI assistant, commentaries, ko asalin yaren lookups yayin da ka karanta.
- Kana so Launcher Menu don samun aya cikin sauri da chat na AI.
- Kana karantu wani makala a zurfi da kake bukatar kowanne kayan aiki daya tab away.

## Canza zuwa yanayi mafi sauƙi

Idan kana so karatu mai sauƙi ba tare da kayan aikin avansa, canza zuwa **Tsarin** yanayi a **Saitunan** → **Yanayin Mai Amfani**. Yanayin Tsarin yana kiyaye alamta, haske, rubuce-rubuce, da Yanayin Karatu amma yana ɓoye AI, commentaries, lexicons, da Launcher Menu.

Idan kana so karatu mafi tsabta, buɗe sura a cikin [Yanayin mayar da hankali](theodia://help/focus-mode).

Alamta, haskinka, da rubuce-rubucenka ba sa share idan ka canza yanayi; ana cire su daga gani har sai ka koma yanayin da ya taimaki su.

## Taimako da tambayoyi

Idan kayan aiki yana ɓoye ko ya nuna kuskure, duba [Matsalolin Gari](theodia://help/common-problems) jagorar. Idan ka sabo a Theodia, [Karatun Sura ta Farko](theodia://help/first-read) jagorar yana tafiya da kai mataki da mataki.
