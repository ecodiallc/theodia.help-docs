---
title: Bincika Littafi Mai Tsarki
level: everyday
categories: [study, read]
summary: Yadda ake samun ayoyi ta kalma, jumla, ko nassi.
---

# Bincika Littafi Mai Tsarki

Akwatin binciken yana taimaka maka ka samo ayoyi da sauri. Zaka iya bincika ta kalma, jumla, ko nassin Littafi Mai Tsarki.

## Yadda ake fara bincike

1. Taɓa **Bincika** tab a ƙasan allon.
2. Rubuta abin da kake nema.
3. Taɓa **Bincika** a kan keyboard.

Sakamakon bincike ya bayyana a matsayin jerin ayoyi. Kowanne sakamako yana nuna littafi, sura, da aya, ƙari da rubutun ayar.

## Bincika ta haɗin kalmomi

Idan ka rubuta fiye da kalma guda, kamar `soyayya farin ciki`, app ɗin zai sami ayoyi da suke ƙunshe da **kowanne** kalmomin biyu. Wannan **AND** search ne — dukkan kalmomin dole sun bayyana a cikin ayar. Ba yin amfani da **OR** logic (ayoyi masu kowanne kalma).

Don bincika ayoyi masu ko wannan kalma, dole ka yi amfani da kalmar `OR` a fili: `soyayya OR farin ciki`.

## Bincika ta kalma

Rubuta kalma guda, kamar `soyayya` ko `rahama`. App ɗin zai nuna kowanne aya a cikin Littafi Mai Tsarki da ke da wannan kalma.

## Bincika ta jumla

Rubuta kalmomi biyu ko uku a cikin quotes, kamar `"kar ka ji tsoro"`. App ɗin zai nuna ayoyi da ke ƙunshe da wannan jumla ta musamman.

## Tace sakamakon

Bayan binciken, an tace sakamakon zuwa fassarorin Littafi Mai Tsarki da ka shigar. Don ƙarin ƙwasan, buɗe **Littafi Mai Tsarki** tab ka kalli fassarar musamman — binciken yana gudana a kan fassarorin da kake da su.

## Shawarwari don binciken mafi kyau

- Yi amfani da ƙananan kalmomi. Binciken `soyayya` zai samo ƙarin ayoyi fiye da binciken `soyayya`.
- Quotes a kusa da jumla zai sa binciken ya zama daidai.
- App ɗin yana bincika kawai fassarorin Littafi Mai Tsarki da ka shigar.
- Don tsallakawa zuwa aya ta musamman ta nassi (alal misali, `Yohanna 3:16`), yi amfani da **Command** box a kan Home screen maimakon Search tab.

## Tarihin bincike

App ɗin yana tunawa da kwanan nan bincike. Lokacin da ka buɗe **Bincika** tab, jerin yana nuna kwanan nan bincike a saman. Taɓa ɗaya don gudanar da shi ƙara. Don share lissafin, taɓa **Share Duka** a saman kwanan nan binciken.

## Bincika PDFs

Search tab iya bincika cikin takardun PDF ɗinka:

1. Taɓa **Bincika** tab, sannan taɓa **PDFs** mode a saman.
2. Zaɓi PDFs da za a bincika. Taɓa PDF don hada ko rabu da shi; yi amfani da **Duka** ko **Share** sama da lissafi don hada duka ko farawa ƙara. Kawai PDFs da suke das bincike-abin karatu da aka shigar za a iya zaɓi.
3. Rubuta abin da kake nema ka taɓa **Bincika**.

Kowanne sakamako yana nuna taken PDF, lamban shafi, da ɓangaren rubutun da ya dace. Taɓa sakamako don buɗe wannan PDF a waccan shafi.

Don bincika cikin PDF ɗaya lokacin da kake karanta shi, yi amfani da button ɗin **Bincika** a cikin PDF reader — duba [PDFs](theodia://help/pdfs).
