---
title: Yanayin Karatu
level: everyday
categories: [layout, read]
summary: Cikakken karatu na Littafi Mai Tsarki a Theodia, mai ƙunshe da kayan aikin karatu kamar commentary, cross-references, lexicon, da rubuce-rubuce.
---

# Yanayin Karatu

> **Yanayi:** Yanayin Karatu yana wanzu a cikin **Tsarin** da **Malami** yanayi. Reader mode yana buɗe surori a cikin Yanayin mayar da hankali (Focus Mode) maimakon haka. Kana iya canza yanayin a **Saitunan** → **Yanayin Mai Amfani**.

Yanayin Karatu shine babban karatu na Littafi Mai Tsarki a Theodia. Yana ƙunshe da dukkan kayan aikin karatu: commentary, cross-references, lookups na kalmomi, fassarori na parallel, rubuce-rubuce, da sauransu.

Yanayin mayar da hankali (Focus Mode) karatu mai sauakhir ne ba tare da kayan aikin karatu ba. Duba [Yanayin mayar da hankali](theodia://help/focus-mode) jagorar idan kana son karatu mai tsabta kawai. Wannan jagorar don Yanayin Karatu ce.

## Yadda ake buɗe Yanayin Karatu

Akwai hanyoyi da dama don buɗe sura a cikin Yanayin Karatu:

- Taɓa **Littafi Mai Tsarki** tab a ƙasan allon. Zaɓi fassara, littafi, da sura.
- Taɓa aya a cikin sakamakon **Bincika**.
- Taɓa alamta daga **Alamta** tab.
- Daga Yanayin mayar da hankali, taɓa button 📖 a saman allon don switching zuwa Yanayin Karatu.

## Karatun sura

Sura ta buɗe tare da ayoyi an jera su a jere. A saman allon akwai buttons don ayyuka da suke amfani. A ƙasan allon akwai status bar.

- **Gwaji na hagu** don zuwa suura gaba.
- **Gwaji na dama** don zuwa suura ɓangare.
- **Taɓa aya** don buɗe verse menu tare da kayan aikin karatu (duba ƙasa).
- **Taɓa Strong's number a cikin aya** (alal misali, G1234 ko H1234) don buɗe quick lexicon lookup don wannan kalma.

Idan ka kunna fassara parallel, kwafi na sura zai bayyana a ƙasan shiryayyen, a cikin fassarar da ka zaɓa. Duba **Karatun fassarori biyu lokaci guda** a ƙasa.

## Verse menu

Lokacin da ka taɓa aya, menu yana buɗe tare da taken "Book Chapter:Verse". Kayan aikin da ka gani sun dogara ne da yanayin mai amfani.

### Kayan aikin a Tsarin da Malami yanayi

- **Alamta** (★) — ajiye aya don samunta ƙara. Taɓa shi ƙara don cire alamta. Taɓa na farko yana ƙara shi. Duba [Alamta Ayoyi](theodia://help/bookmarks) jagorar.
- **Haske** (□) — sa ayar launi don ta hasken. Taɓa shi don buɗe color picker. Taɓa wannan launi ƙara don cire haske. Duba [Haske Ayoyi](theodia://help/highlights) jagorar.
- **Saurari** (🔊) — karanta ayar a haute ta yi amfani da voice na text-to-speech na na'urarka. Wannan ba a nuna don Bibles na interlinear. Duba [Karatun da Sauti](theodia://help/tts) jagorar don yadda ake amfani da shi da yadda ake zaɓi murya.
- **Kwaliya** (⎘) — sanya rubutun ayar a clipboard don ka iya manna shi duk inda.
- **Kai** (⇄) — buɗe panel da ke nuna wannan aya a cikin kowanne fassara da ka shigar. Taɓa fassara a cikin panel don karanta ayar a waccan fassara. Duba [Kullayi Fassarori](theodia://help/compare-translations) jagorar.
- **Cross-References** (↗) — buɗe jerin ayoyi masu alaƙa daga cross-reference database. Duba [Cross-References](theodia://help/cross-references) jagorar.
- **Ƙara/Gyara Bayanin Littafi** (✎) — rubuta your private note tare da ayar. Duba [Rubuta Rubuce-rubuce](theodia://help/notes) jagorar.

### Kayan aikin Malami kawai

- **AI Commentary** (◈) — nema AI assistant ya rubuta bayanin karatu don wannan aya. (Ba ya nan a duk yankuna.)
- **Word Info** (?) — buɗe entry na lexicon don asalin kalmar Ibrananci ko Giriki a bayan aya. Duba [Commentaries and Lexicons](theodia://help/commentaries-and-lexicons) jagorar.
- **Kamus** (📖) — nemo kalmomin Littafi Mai Tsarki a cikin kamus da ka shigar. Duba [Bible Dictionary](theodia://help/dictionary) jagorar.

Wasu kayan aiki suna bukatar ƙwararrun abubuwa a shigar. Idan kayan aiki yana haske-fuskata ko yana nuna "not found", buɗe **Saitunan** → **Manage Resources** ka ƙara resource ɗin da yake bukata.

## Buttons a saman allon

Sama da rubutun sura akwai layi na icons. Waɗannan suke azumci ayyuka:

- **Version na Littafi Mai Tsarki** — taɓa sunan fassara (alal misali, "KJV") don switching zuwa wasu fassarori.
- **Littafi** — taɓa sunan littafi don tsallakawa ga wasu littattafai.
- **Sura** — taɓa lamba sura don tsallakawa ga wasu surori.
- **Buɗe a AI** (🤖) — aika sura ta yanzu zuwa AI assistant tare da tambayarka. (Yanayin Malami kawai.)
- **Yanayin mayar da hankali** (📖) — switching zuwa Yanayin mayar da hankali don karatu mai tsabta.
- **Fassarori na parallel** (🔵 / ⚪) — taɓa don kunna ko kashe fassarori na parallel. Lokacin da aka kunnar, sura ɗaya yana bayyana cikin fassarorin parallel da ka zaɓa a ƙasan rubutun shiryayyen. Lokacin da aka kashe, kawai shiryayyen fassara yana bayyana. Duba **Karatun fassarori fiye da ɗaya lokaci guda** a ƙasa.
- **Saurari** — karanta cikakken sura a haute. Duba [Karatun da Sauti](theodia://help/tts) jagorar.
- **Mai ƙari** — buɗe ƙarin ayyukan sura (bayyani sura na Littafi, commentary sura, raba, da sauransu).

## Karatun fassarori fiye da ɗaya lokaci guda

Zaka iya nuna har zuwa fassarori ƙari guda huɗu kusa da shiryayyen. Ana kira wannan **parallel view**.

1. Buɗe **Saitunan**.
2. Kunna **Fassara na parallel**.
3. Taɓa **Ƙara Fassara na parallel** ka zaɓi fassara.
4. Maimaita don ƙara wasu. Zaka iya samun har zuwa fassarori parallel guda huɗu.

Lokacin da parallel view yana kan, kowanne aya a cikin sura yana nuna shiryayyen fassara a farko, sannan wannan aya a cikin kowanne fassara parallel. Wannan yana sauƙaƙa kwatau yadda fassarori daban suka aiki da ayar mai wahala ba tare da barin sura.

Zaka iya ajiye miryarka ta parallel na yanzu azaman **preset**. Taɓa button ajiyar kusa da fassarorin da ka zaɓa, bai suna, kuma zai zama zaɓi na cikakken switching. Taɓa kowanne preset daga baya don ɗaukar wannan hadaka nan take. Taɓa mai tsawo preset don share shi.

Zaka iya kuma kwatantawa kawai wata aya a lokaci guda tare da **Kwata** (⇄) kayan aiki a cikin verse menu. Wannan yana buɗe panel da ke nuna ayar a cikin kowanne fassara da aka shigar.

## Subheadings

Wasu fassarori suna ƙunshe da section headings na ciki (alal misali, "Wa'azin kan Tudu"). Idan fassararka tana dasu, zaka iya nuna ko ɓoye su tare da saitin **Nuna Subheadings** a cikin **Saitunan**. Subheadings suna bayyana kamar ƙananun fararen rubutu tsakanin ayoyi.

## Bayanin sura

Bayanin sura rubutu ne guda attached ga cikakken sura, ba ga aya guda. Yana amfani don babban ra'ayi guda game da sura.

Don buɗe bayanin sura:

1. Taɓa button ɗin **Mai ƙari** a saman allon.
2. Taɓa **Bayanin Sura**.
3. Rubuta bayaninka. Taɓa **Ajiye**.

Bayanin sura ya ajiye tare da sura. Yana bayyana duk lokacin da ka buɗe waccan sura.

## Haske na bincike

Idan ka zo sura daga bincike, kalmar bincikenka ta haske a rawaya a cikin rubutun ayar. Wannan yana sauƙaƙa ganin me ya sa aya ta dace.

Zaka iya gudanar da binciken ƙara a kan surar da ka karantawa. Buɗe **Bincika** tab ka input kalma. Sakamakon binciken yana barin ka tsallake ƙara zuwa sura tare da matches da aka haske.

Bibles na interlinear (MIB — Marvel Interlinear Bible — da OHGB) koyaushe suna buɗe a cikin Yanayin Karatu domin suna bukatar layout na kalma.

## Switching zuwa Yanayin mayar da hankali don sura guda

Daga kowanne sura a cikin Yanayin Karatu, taɓa button 📖 a saman. Waccan sura tayyara buɗe a cikin Yanayin mayar da hankali tare da dukkan menus da aka ɓoye. Taɓa button 📖 a cikin bottom bar don switching ƙara zuwa Yanayin Karatu.

## Yaushe ake amfani da Yanayin Karatu

Yanayin Karatu shine zaɓi da ya dace lokacin da kake so:

- **Karatun da karatu a lokaci guda.** Dukkan kayan aiki tab guda suke.
- **Nemo kalma da ba ka sani ba.** Taɓa Strong's number a cikin aya don quick lexicon entry.
- **Kwatantawa fassarori.** Yi amfani da Kwata kayan aiki na verse menu ko kunna parallel view.
- **Ganin yadda aya ta haɗa da sauran Littafi Mai Tsarki.** Yi amfani da Cross-References.
- **Ci gaba da karatu yayin da ka ɗauki bayanai.** Verse menu yana da sauri "Ƙara rubutu".

Don karatu mai tsawon lokaci da ba a damu ba, switching zuwa Yanayin mayar da hankali.

## Canza zuwa Yanayin mayar da hankali

Daga kowanne sura a cikin Yanayin Karatu, taɓa button 📖 a saman. Waccan sura tayyara buɗe a cikin [Yanayin mayar da hankali](theodia://help/focus-mode) tare da menus da kayan aikin karatu da aka ɓoye. Taɓa button 📖 a cikin bottom bar don switching ƙara zuwa Yanayin Karatu. Don cikakken bayanin abin da Yanayin mayar da hankali yake, duba [Yanayin mayar da hankali](theodia://help/focus-mode) jagorar.

## Taimako da tambayoyi

Idan kayan aiki yana ɓoye ko ya nuna kuskure, duba [Matsalolin Gari](theodia://help/common-problems) jagorar. Idan ka sabo a Theodia, [Karatun Sura ta Farko](theodia://help/first-read) jagorar yana tafiya da kai mataki da mataki.
