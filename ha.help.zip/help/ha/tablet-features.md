---
title: Fasalan Tablet
level: everyday
categories: [layout, tablet]
summary: Yadda Theodia's layout ya dace da tablets da allon babba, tare da split views, side panels, da modes karatu na panes biyu.
---

# 📱 Fasalan Tablet

Theodia an tsara shi domin amfani da allon babba a tablets. A tablet (ko kowanne na'ura wani tsube fiye da pixels 700), app ɗin yana switching da kansa zuwa layout na columns biyu a wurare da dama.

> **Yanayi:** Fasalan da aka bayyana a nan suna bayyana kawai idan yanayin mai amfani ɗin ku ya taimaka su. Alal misali, side panels na commentary da chat na AI suna nan kawai a Malami yanayi. Split views na alamta, haske, da rubuce-rubuce suna bukatar Tsarin ko Malami yanayi. Yanayin mayar da hankali yana nuna karatu mai tsabta, na column ɗaya kawai. Kana iya canza yanayin a **Saitunan** → **Yanayin Mai Amfani**.

## Verse menu na karatu

Lokacin da ka taɓa lamban aya (ko taɓa mai tsawo rubutun ayar), **verse menu** ya bayyana azaman **centered card** a kan dark backdrop.

- Buttons **Kwaliya** da **Raba** suna bayyanan a saman menu.
- **Alamta** da **Haske** suna nuna stato na yanzu.
- **Commentary**, **Kamus**, da **Kwata** suna buɗewa daga menu. A tablet waɗannan kayan aiki iya bayyana a cikin side panel ko wide card bayan zaɓi.
- Taɓa backdrop ko close arrow don ajiye menu.

## Panel na Verse Commentary

Kayan aikin **Commentary** yana buɗe **dedicated side panel** a tablet:

- Rubutun commentary yana bayyana kusa da rubutun Littafi Mai Tsarki.
- Zaka iya tallata commentary daban daga Littafi Mai Tsarki.
- Taɓa **X** ko swipe don ajiye.
- icon ɗin **littafi** a saman panel yana barin ka switching sources na commentary.
- icon ɗin **sura** yana barin ka ganin commentary na sura.

A phone, commentary yana buɗe azaman full-screen modal.

## Commentary na sura

**Commentary na sura** an isa daga button ɗin **Mai ƙari** a saman allon, ba verse menu. A tablet yana buɗe azaman side panel kamar Verse Commentary, don ka karanta commentary da rubutun Littafi Mai Tsarki tare.

## Tab din Kwata

**Kwata** tab (a cikin verse menu) yana buɗe azaman **side panel** a tablet. Yana nuna aya da aka zaɓa a cikin kowanne parallel version da ka kunnar. Zaka iya taɓa kowanne version don tsallakawa zuwa waccan makalar a cikin karatu.

## Popup na Kamus / Strong's

Kayan aikin **Kamus** (verse menu → Kamus) yana buɗe azaman wide card a tablet. Yana nuna kalmar Giriki ko Ibrananci, transliteration na ta, ma'ana, da lamban Strong's. Taɓa button ɗin **Concordance** don ganin kowanne bayyanar wannan kalma a cikin Littafi Mai Tsarki.

## Taɓa kalma don buɗe Lexicon

A cikin **Word Info** side panel a tablet, kowande word card da ke da lamban Strong's yana taɓuwa. Taɓa card don buɗe **Lexicon** panel don wannan kalma a fili. Lexicon panel yana maye gurbin Word Info panel don ka ci gaba da karatu ba tare da ajiye karatu ba.

A phone, Word Info cards ba sa taɓuwa domin allon ya yi ƙarami ga panels biyu.

## Parallel Bibles a side by side

A Saitunan, taɓa **Parallel Bibles** ka zaɓi har zuwa fassarori uku. A tablet, fassarorin suna bayyana azaman **vertical panes** kusa da juna:

- Kowanne pane yana tallata daban.
- Zaka iya taɓa lamban aya don buɗe side panel tare da kayan aikin.
- **Kwata** tab yana nuna kowanne aya da aka zaɓa a wuri guda.
- Taɓa **X** a kowanne pane don ajiye shi ka mayowa zuwa view na column ɗaya.
- Taɓa icon ɗin **Parallel Bibles** (🔵 / ⚪) a cikin top icon bar don toggle parallel view on ko off ba tare da buɗe Saitunan.

A phone, fassarori na parallel suna nuna guda ɗaya bayan ɗaya (a tsaye) maimakon side by side. Wannan icon toggle yana aiki a phones kuma.

## Alamta da Haske split view

A tablet, **Alamta** da **Haske** tabs suna amfani da layout na master-detail:

- **Hagu** — jerin alamta ko haske.
- **Dama** — taɓa item yana buɗe preview pane tare da rubutun ayar ko makalar.

Zaka iya kalli abubuwan da ka ajiyewa ka kuma preview su ba tare da barin tab ba. A phone, taɓa item yana navigating zuwa karatu screen.

## Rubuce-rubuce split view

**Rubuce-rubuce** tab a tablet yana nuna jerin rubuce-rubucenka a hagu da rubutu da aka zaɓa a dama. Taɓa rubutu yana buɗe shi a cikin side panel don ka iya kallon da yawa a jere ba tare da barin jerin. Ƙirƙira ko gyara rubutu kuma yana amfani da side panel.

## Bincika split view

A tablet, **Bincika** tab yana nuna binciken a hagu da sakamakon a dama nan take da ka gudanar da binciken. Zaka iya refine tambayarka ka kuma kalli sakamakon update ba tare da canza screens. A phone, sakamakon binciken yana buɗe a cikin screen daban.

## Settings category sidebar

**Saitunan** screen a tablet yana nuna category list a hagu (AI, Appearance, Backup, Bibles, da sauransu). Taɓa category don tsallakawa a fili zuwa saitunanta a dama. Kawai category da aka zaɓa yana buɗewa, don za ka banza scrolling cikin dukkan lissafin saitunan.

## Bible navigation a tablets

**Bible List**, **Bible Books**, da **Bible Chapters** screens suna ƙuƙushin column a tablets, amma suna amfani da larger touch targets, grids masu faɗi, da padding mai sarari domin abun da suke sauƙin karatu da taɓa. Ba sa amfani da split-view layout domin kowanne mataki yana bukatar full width don nuna jerinsa ko grid clearly.

## Landscape da portrait

Juya tablet yana adjust layout da kansa. A **landscape**, side panels suna da isasshen wuri. A **portrait**, panels suna zama masu ƙarami amma har yanzu suna bayyana kusa da rubutu.

## Selected verse AI chat

**AI** chat yana buɗe a cikin verse menu side panel. Yana nuna conversation interface inda zaka iya neman tambayoyi game da aya da aka zaɓa. AI response yana bayyana a cikin panel, kuma zaka iya ci gaba da conversation ba tare da barin karatu ba.

## Conversation sidebar a AI screen

A **AI** tab a tablet, conversation list koyaushe yana bayyana azaman persistent left sidebar. Zaka iya switching tsakanin chats ba tare da buɗe menu. Button ɗin **New Chat** koyaushe yana bayyana. A phone, conversation list yana da popup drawer.

## Abin da yake ƙuƙuwar

Ba kowanne screen yake split into biyu panes. Waɗannan screens suna ƙuƙuwar column a tablets:

- **Bible List** — jerin fassarorin Littafi Mai Tsarki (full width)
- **Bible Books** — grid littattafai da sashe (full width)
- **Bible Chapters** — grid surori (full width)
- **PDFs** — ɗakin karatu na PDF yana amfani da wider card grid (full width)
- **Saitunan** — shafuka na saitunan kowane (full width)
- **Taimako** — labaran taimako (full width)

## Taƙaice

A tablet, zaka samu:

- **Parallel Bibles** a cikin vertical panes kusa da juna
- **Commentary** a cikin persistent side panels
- **Kwata** da **Kamus** a cikin wide cards
- **Lexicon** daga taɓa kowanne Word Info card
- **Alamta, Haske, Rubuce-rubuce, Devotionals, Littattafai, Saitunan** a cikin master-detail split views
- **Bincika** tare da sakamakon a cikin line kusa da binciken
- **Landscape** da **portrait** duk an tallafa su tare da automatic layout changes

A phone, duk yana amfani da traditional single-column drill-down navigation. App ɗin yana gano allon ƙungiya a lokacin launch ka kuma zaɓi correct layout a kan kansa.
