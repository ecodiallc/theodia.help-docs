---
title: Canza Themes da Fonts
level: everyday
categories: settings
summary: Yadda ake canza bayyanar app ɗin.
---

# Canza Themes da Fonts

Theodia na barin ka canza yadda app ɗin ya bayyana. Zaka iya zaɓi theme (light ko dark) da girman haruffa.

## Yadda ake buɗe saitunan bayyanar

1. Buɗe **Saitunan**.
2. Taɓa **Bayyanar**.

## Yadda ake canza theme

A cikin **Bayyanar** section, zaka ga buttons theme biyu:

- **Default** — background mai haske tare da rubutun dark. Mai kyau domin rana.
- **Dark** — background dark tare da rubutun haske. Mai kyau domin dare kuma yana aje baturi.

Taɓa theme don aiwatar da shi. Canjin yana aiwatar da nan take.

## Yadda ake canza girman haruffa

A cikin **Bayyanar** section, taɓa ɗaya daga size buttons: **---**, **--**, **-**, **Normal**, **+**, **++**, **+++**. Rubutu yana ƙaruwa ko ƙaraira a cikin app ɗin. Zaɓi girman da yake sauƙin karanta maka.

## Shawarwari

- Dark theme yana aje baturi a kan phones masu OLED screens.
- Idan rubutu ya yi ƙarami da za a karanta, ƙara girman haruffa a cikin app ɗin, ba a cikin na'urar. Saitin app ɗin yana ƙarfin.
- Don karatu mai tsawon lokaci, gwada dark theme da girman haruffa mai girma.
- [Budewa desert theme](theodia://unlock-desert)
