---
title: Fasalin Theodia
level: beginner
categories: welcome
summary: Gabatarwar taƙaice na abin da ya sanya Theodia na musamman da yadda ya taimaka maka karanta Littafi Mai Tsarki.
---

# Fasalin Theodia

Theodia an gina shi don zama cikakken abokin karatun Littafi Mai Tsarki. Ga abin da ya sanya ya musamman.

## Offline First

Dukkan abu yana aiki ba tare da intanet ba. Bibles, commentaries, lexicons, littattafai, da devotionals suna adana a na'urarka. Zaka iya karatu, bincika, da karatu a duk inda — a cikin jirgi, a yanki mai nisa, ko kowanne wuri ba tare da signal ba.

## Mai mayar da hankali ga sirri

Bayananka suna tare da kai. Rubuce-rubuce, haske, alamta, da tarihin karatu suna adana locally a na'urarka. Ba a bukatar account, kuma babu abu da aka aika zuwa sabar sai dai idan ka zaɓi amfani da AI assistant na zaɓi.

## Tallafawa Tablet

Theodia an tsara shi domin gaba da phones da tablets. A allon babba, zaka sami ƙari wuri don karatu, parallel Bible views, da layout da ke amfani da ƙarin wuri.

## Installable Resources

Ba ka ƙaranci ga abin da ke tare da app ɗin ba. Zaka iya ƙara ƙarin fassarorin Littafi Mai Tsarki, commentaries, lexicons, littattafai, da devotionals. Abubuwa suna nan a project's GitHub page kuma ana iya shigar da su kai tsaye cikin app ɗin.

## AI Assistant

AI assistant na zaɓi yana taimakawa wajen fahimtar ayoyi, bayyana context, da amsa tambayoyi. Yana aiki kawai idan ka kunna shi. Na asali yana haɗuwa da remote model da kake bayarwa ta hanyar endpoint da API key da ka tsara. Lokaci na farko da ka yi amfani da AI, app ɗin yana neman izininka kuma yana nuna daidai abin da aka aika.

## Parallel Bible Reading

Karanta har zuwa fassarori huɗu na Littafi Mai Tsarki lokaci guda. Lokacin da ka buɗe sura, shiryayyen fassararka yana bayyana a farko, kuma kowanne aya yana biye da wannan aya a cikin fassarorin parallel da ka zaɓa. Kwatau wording, karatu bambance-bambance, ka kuma sami cikakken hoton yarfin. Ajiye hadakarka ta favorite azaman presets ka kuma switch tsakaninsu cikin sauri.

## Full-Text Search

Bincika a cikin kowanne fassara na Littafi Mai Tsarki. Nemo kalmomi, jumla, ko matches. Zaka iya kuma ƙwasan binciken zuwa kewayon littattafai.

## Cross-References

Taɓa nassi na aya don tsallakawa a fili zuwa wannan makala. Cross-references an gina su ciki kuma suna aiki a cikin dukkan Littafi Mai Tsarki.

## Lexicon da Strong’s Numbers

Taɓa Strong’s number don ganin asalin ma'anar Giriki ko Ibrananci. Lexicon entries an hada su don deeper word study.

## Alamta da Haske

Ajiye ayoyi tare da alamta ka kuma nuna su tare da launi. Dukkan abu yana adana locally kuma yana ci gaba tsakanin zaman masu.

## Rubuce-rubuce

Rubuta ra'ayoyinka kusa da kowanne aya. Rubuce-rubuce suna hada da aya kuma sauƙin samun later.

## Daily Devotional

Fara rana tare da karatu ɗan gajeren devotional. App ɗin yana ƙunshe da devotionals da ke buɗewa cikin entry na yau da kansu.

## Christian Books

Karanta klasik na adabin Kirista a cikin app ɗin. Books an tsara su don karatu mai sauƙi kuma suna ƙunshe da table of contents don navigation mai sauri.

## Karatun PDF

Shigar da your own takardun PDF ka kuma karanta su ba tare da intanet ba, an tsara su cikin rukuni. Karatu yana tallafawa bincike, table of contents, alamta, zoom, da karatu a haute. Zaka iya kuma shigar packaged PDF collections daga al'ummar repository.

## Harsuna da dama

Theodia yana tallafawa harsuna da dama domin duka interface na app ɗin da abun Littafi Mai Tsarki. Switch harsuna a saitunan don karatu cikin harshen da kake son.

## Dark Mode da Themes

Zaɓi daga light ko dark mode, ko zaɓi theme da ya dace da son ka. Jima karatu yana ƙunshe na ƙima, musamman a low light.

## Ajiyar Bayanai

Ajiyewa bayananka, alamta, da haske. Kiyaye bayananka lafiya ka kuma motsa su zuwa sabuwar na'ura lokacin bukata.

## Ba Ads, Ba Damuwa

Theodia an gina shi domin mai mayar da hankali. Ba ads, ba pop-ups, ba interruptions. Kawai rubutu da kayan aikin karatu.
