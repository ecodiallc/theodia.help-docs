---
title: Karatu da Sauti (Text-to-Speech)
level: everyday
categories: tts
summary: Yi Theodia ya karanta Littafi Mai Tsarki ko devotional a haute. Yadda ake amfani, yadda ake zaɓir murya, da abin da za a yi idan ya kasance shayu.
---

# Karatu da Sauti (Text-to-Speech)

> **Yanayi:** Text-to-speech yana wanzu a cikin **Tsarin** da **Malami** yanayi. Yanayin mayar da hankali (Focus Mode) don karatu mai tsabta da bai damu ba kawai. Kana iya canza yanayin a **Saitunan** → **Yanayin Mai Amfani**.

Theodia na iya karanta rubutu a haute ta yi amfani da voice na text-to-speech (TTS) na na'urarka. Zaka iya saurarar aya guda, sura cika, ko devotionals. Wannan yana amfani don karatu ba tare da hannu, sauraro yayin da kake tafiya ko tafiya da motar, karatu tare da audio, ko sauƙa ciwon idanu.

## Inda listen button ke
Zaka sami listen button a wurare guda uku.

### 1. A cikin verse menu (aya guda)

Hanya mafi sauri don saurarar aya guda. Buɗe sura a cikin [Yanayin Karatu](theodia://help/study-mode), taɓa aya don buɗe verse menu, sannan taɓa **Saurari** (🔊). Karatu ya fara daga waccan aya. Gwaiwan sarrafa yawu yana bayyana a ƙasan allon tare da play, pause, rewind, fast-forward, da voice picker.

Zaɓin Saurari ba a nuna don Bibles na interlinear (MIB — Marvel Interlinear Bible — da OHGB), domin suna nuna kalmomi cikin layout ɗin da ba a karanta a hankali ba.

### 2. A saman sura (cikakken sura)

Lokacin da kake karatun sura, duba layi na icons a saman allon. Taɓa **Saurari** (🔊) don fara karatun cikakken sura daga farawa. Button ɗin ya zama stop button (⏹) yayin da audio ke buga. Taɓa shi ƙara don dakatarwa. Gwaiwan sarrafa yawu yana bayyana a ƙasa.

Zaka iya tsallakawa zuwa wasu aya, kuma button ɗin Saurari a can zai fara daga waccan aya.

### 3. A cikin devotional

Buɗe kowanne rana na devotional, sannan taɓa **Saurari** (🔊) button a saman karatu. Cikakken rubutun devotional yana karantu a haute, sentence by sentence. Gwaiwan sarrafa yawu a ƙasa yana ba ku play, pause, rewind, da controls na murya.

## Amfani da gwaiwan sarrafa yawu

Yayin da audio ke buga, ƙaramin bar yana kasancewa a bayyana a ƙasan allon. Yana ƙunshe da sarrafa guda shida:

- ⏪ **Rewind** — komawa biyar ayar (ko sentence a devotional)
- ⏸ **Pause / ▶ Resume** — dakatarwa ba tare da rasa matsayinka ba. Taɓa ƙara don ci gaba daga same spot.
- ⏩ **Fast forward** — tsallaki zuwa ayar gaba (ko sentence gaba a devotional)
- 🎙 **Murya** — budewa voice picker ba tare da barin sura ba (duba ƙasa)
- ⚙ **Zaɓuɓɓuka** — budewa panel ɗin zaɓuɓɓukan ƙari (duba ƙasa)
- **Dakata** — taɓa button 🔊 a saman allon, ko ⏹ wanda ya maye gurbinsa yayin da audio ke buga, don dakatarwa ka ajiye bar.

Gwaiwan sarrafa yawu yana ajiye lokacin da sura ya ƙare ko da ka taɓa daktata.

### Zaɓuɓɓuka ƙari

Taɓa ⚙ don fata zaɓuɓɓukan buga ƙari. Waɗannan saituna suna kasancewa ne kawai domin sura ta yanzu kuma suna reset lokacin da ka canza sura ko dakata.

- ⏮ **Back to begin** — tsallaki zuwa ayar farko na kewayon da ka saita.
- **Begin** — rubuta lamban aya don saita inda karatu ya fara.
- **End** — rubuta lamban aya don saita inda karatu ya tsaya.
- **All** — reset kewayon zuwa cikakken sura.
- **()** — toggle idan rubutun da ke cikin parentheses yana karantu a haute.
- 🔁 **Repeat** — a fara ƙara zuwa farawa na kewayon lokacin da ƙarshen ya isa, tare da short pause a tsakani. Idan ka kunna wannan ba tare da saitin begin ko end aya ba, cikakken sura yana maimaituwa.

### A cikin shafukan addu'a

Creeds da fixed prayers, generated prayers, da prayer routines suna da nasu saitin zaɓuɓɓukan ƙari. Taɓa ⚙ a cikin gwaiwan sarrafa yawu don fata su:

- **Sauri** — taɓa rate (alal misali `1x`) don zaɓi saurin karatu daga 0.1x zuwa 1.5x. Zaɓinka yana ajiyewa kuma ana amfani da shi lokacin na gaba da ka karanta wani abu a haute.
- **()** — toggle idan rubutun da ke cikin parentheses yana karantu a haute.
- 🔁 **Repeat** — a fara addu'a daga farawa lokacin da ta ƙare, tare da short pause a tsakani. Wannan yana amfani don koyon creed ko fixed prayer by heart.

Canza sauri yana aiwatarwa nan take, ba tare da rasa matsayi ba. Kunna ko kashe zaɓin parentheses yana fara addu'a ƙara daga farawa domin canjin za a iya ji daga farawa.

## Yadda ake canza murya

Zaka iya zaɓi muryar da Theodia ke amfani da ita don karatu. Wannan yana amfani idan kana so accent daban, harshen daban, ko murya mai sauri ko ƙaro fiye da device default.

1. Buɗe **Saitunan**.
2. Nemo **Speech** section.
3. Taɓa **Select Voice**.
4. Jerin muryoyi ya bayyana. Fara row, **System Default**, yana amfani da muryar da device ya fi so. Zaɓi wani row don sanya shi new default.
5. Zaɓinka yana ajiyewa kuma ana amfani da shi lokaci na gaba lokacin da ka taɓa **Saurari** ko **Saurari**.

Zaka iya kuma taɓa icon 🎙 a cikin gwaiwan karatu don buɗe picker ɗin nan take ba tare da barin sura ba.

Daidaito na murya ya dogara gaba ɗaya da na'urar. iOS da Android kowanne ya zo tare da saitin muryoyin da aka gina. Zaka iya shigar ƙarin muryoyi daga **Accessibility** ko **Language & Input** saitunan na'urar. Theodia zai iya amfani da kowanne murya da aka shigar a na'urar.

## Murya masu favorite

Idan na'urarka tana da muryoyi da yawa, tallata cikakken jerin kowanne lokaci za a iya shayu. Zaka iya ƙirƙirar ƙaramin jerin **murya masu favorite** kuma voice pickers zai nuna kawai waɗannan muryoyin.

1. Buɗe **Saitunan**.
2. Nemo **Speech** section.
3. Taɓa **Favorite Voices** (fara row a saman section).
4. Taɓa **Set Favorite Voices** don buɗe shafin favorites.
5. Taɓa play button kusa da murya don preview ta. Taɓa taya don ƙara shi ga favorites ɗin ku. Zaka iya favorite muryoyi da yawa da kake so.
6. Komawa. Voice pickers a cikin Theodia yanzu suna nuna kawai murya masu favorite ɗin ku.

Idan ka cire dukkan favorites, pickers zai koma nuna kowanne murya. Murya masu favorite suna hada lokacin da ka ajiye ka kuma mayar saitunan Theodia.

## Saita wasu murya ga kowanne Littafi

Zaka iya ba kowanne fassara na Littafi Mai Tsarki nasu murya. Wannan yana amfani lokacin da ka canza tsakanin fassarori da ke karatu da bambance-bambance mai fegu — alal misali, murya mai formal ga King James Version da murya mai conversation ga NIV ko NLT. Har ya yi amfani idan ka saurara Littafi Mai Tsarki a harshuna daban kuma kana so kowanne a aika a cikin accent ɗin na harshen.

1. Buɗe **Saitunan**.
2. Nemo **Speech** section.
3. Nemo **Bible Voices**.
4. Taɓa wani Littafi a cikin jerin.
5. Zaɓi muryar da kake so ga waccan fassara. Fara row, **System Default**, yana amfani da main TTS murya ɗin ku ga waccan Littafi.
6. Maimaita ga wasu Littattafai.

Header yana nuna adadin fassarorin Littafi Mai Tsarki da suke da custom voice da aka saita. **Select Voice**, **Commentary Voice**, **Bible Notes Voice**, da **Devotional Voice** kuma suna nuna count lokacin da aka saita murya.

Lokaci na gaba da ka saurara sura daga waccan Littafi, Theodia zai yi amfani da murya da ka zaɓa. Sauran fassarori suna ci gaba da amfani da main default voice sai ka canza su.

## Ci gaba da karatu a baya

Na asali, Theodia yana dakatar da karatu lokacin da ka bar karatu screen, ka switching zuwa wasu app, ko ka kulle phone ɗin ka. Wannan yana hanna audio mara tsammanin lokacin da ba ka karatu actively.

Don barin karatu ya ci gaba a baya:

1. Buɗe **Saitunan**.
2. Nemo **Speech** section.
3. Kunna **Ci gaba da karatu a baya**.

Lokacin da aka kunna, zaka iya switching tabs, budewa wasu app, ko kulle screen, kuma sura ko devotional zai ci gaba da karanta. Gwaiwan sarrafa yawu yana kasancewa mai aiki domin ka iya dakatarwa ko tsallakawa daga notification area (idan na'urar ka ke taimakawa).

Kashe wannan toggle yayin da karatu yanzu ke buga zai dakatarwa doki.

## Abin da za a yi idan ba ya aiki

TTS yana dogara da na'urar. Theodia yana aika rubutun zuwa operating system, kuma operating system ya karanta shi a haute ta yi amfani da murya. Idan ba ya aiki, gwada waɗannan matakan a jere.

### Theodia yana cewa TTS ba ya nan

Wasu na'urorin ba su da TTS gaba ɗaya. Buɗe **Saitunan** ka duba **TTS** section. Idan section ɗin ba ya nan, na'urarka ba ta taimakawa TTS a cikin wannan build ba.

### Jerin muryoyi ya kunce

Voice picker iya nuna "no voices found". Wannan yawanci yana nufin na'urar ba ta ƙware da loading muryoyin ta tukuna.

1. Buɗe **Saitunan → Speech → Select Voice**.
2. Idan jerin ya kunce, nemo button **Retest** ƙarƙashin dropdown. Taɓa shi. Theodia yana re-query na'urar domin muryoyi.
3. Idan har yanzu ya kunce, duba saitunan na'urar ka. A kan iOS, je zuwa **Settings → Accessibility → Spoken Content → Voices** ka sauke muryar ga harshen ka. A kan Android, je kuwa **Settings → Language & Input → Text-to-Speech Output** ka taɓa **Install voice data**.
4. Rufe ka kuma budewa Theodia don ya ɗauki sabon murya.

Idan ka saita murya masu favorite kuma jerin ya kunce, tabbata akalla ɗaya daga cikin favorites ɗin ku ya dace da muryar da aka shigar a wannan na'urar.

### Taɓa Saurari amma babu abin da ya faru

- Duba cewa na'urar ba tana cikin silent mode. Mafi yawan na'urorin ba za su buga TTS audio lokacin da silent mode ba.
- Tabbata volume na'urar na ƙaru.
- Gwada button **Retest** a **Saitunan → Speech**.
- Buɗe **Saitunan** ka duba **System** section a ƙasa. Row na **TTS** ya kamata ya ce **Available**. Idan ya ce **Unavailable**, TTS ya kashe a operating-system level. Kunna shi a can, sannan kuma buɗe Theodia.

### Audio ya buga amma harshen yana ƙyale

Theodia yana aika rubutun a cikin harshen abu da ake karantu ka kuma nemi muryar da ka zaɓa daga na'ura. Idan muryar da aka zaɓa tana ga wani harshen daban, na'ura zai iya karanta rubutun, amma zai ji ƙyale.

1. Buɗe **Saitunan → Speech → Select Voice**.
2. Zaɓi **System Default** don barin na'urar ya zaɓi wanda ya dace, ko zaɓi muryar da harshenta ya dace da rubutun da kake karantu.

Theodia ba ya karanta Giriki ko Ibrananci interlinear Bibles a haute. Saurari da Listen buttons suna ɓoye a cikin waccan fassarori.

### Audio ya buga amma yana tsaya da wuri

Idan aya tana ɓoye ko ba a karantawa, sura yana tsallake zuwa gaba ɗaya. Idan bar ya ajiye da kansa bayan ayar 'yan, taɓa button **Saurari** (🔊) a saman allon don farawa ƙara.

### Karatu ke buga amma ban san inda ya fara ba

Idan ka kunna **Ci gaba da karatu a baya** kuma da baya ka ji audio amma ba za ka sami shafin da ya fara ba, zaka iya dakatar da shi daga kowanne wuri a app ɗin.

1. Buɗe **Saitunan**.
2. Nemo **Speech** section.
3. Taɓa red **Dakatar Karatu** button a ƙasa na section.

Wannan zai dakatar da kowanne TTS da ke buga a Theodia nan take. Zaka iya kuma buɗe app switcher na na'urarka ka swipe Theodia away don force-stop audio.

### Yana karanta da sauri ko ƙaro

Theodia ba yana sarrafa saurin karatu ba. Sauri yana ƙwale daga muryar da aka zaɓa. Don canza shi:

- A kan iOS: **Saitunan → Accessibility → Spoken Content → Speaking Rate**.
- A kan Android: **Settings → Language & Input → Text-to-Speech Output → Speech Rate**.

## Shawarwari

- Gwaiwan sarrafa yawu yana kasancewa a bayyana yayin da kake navigate tsakanin surori, don ka iya dakatarwa, tsallaki, ko canza murya ba tare da rasa matsayi ba.
- Theodia yana karanta lamban ayoyi azaman small pauses. Zaka iya dakatar bar, swipe zuwa aya daban, sannan taɓa play don ci gaba daga can.
- Don sauraro mai tsawo, kunna **Do Not Disturb** domin sanarwa ba za su katse audio ba.
- Button 🔊 yana amfani da volume na na'ura a yanzu. Idan ka shigar headphones, volume zai switching zuwa volume na headphones.

## Karatun PDF da sauti

Theodia na iyan karanta shafukan PDF aloud. Buɗe wani PDF ka taɓa **Saurari** (speaker) button a cikin toolbar na shi. Gwaiwan sarrafa yawu yana bayyana tare da play/pause, rewind, fast forward, stop, progress bar, da speed da voice pickers. Lokacin da shafi ya ƙare, karatu ya ci gaba a shafi gaba da kansa.

Karatun PDF yana amfani da searchable text ɗin PDF ɗin da aka shigar da same murya da sauri kamar karatun Littafi Mai Tsarki.

## Related guides

- [Yanayin Karatu](theodia://help/study-mode) jagorar yana rufe verse menu da top-of-screen buttons cikin detail.
- [Yanayin mayar da hankali](theodia://help/focus-mode) jagorar shine cleaner karatu view wanda kuma yake taimakawa TTS ta hanyar 🔊 button a cikin bottom bar.
- [Matsalolin Gari](theodia://help/common-problems) jagorar yana da fixes ga wasu audio, murya, da harshen.
- [Devotionals na Yau](theodia://help/daily-devotionals) jagorar yana rufe karatun devotional da inda listen button ke a wancan screen.
- [PDFs](theodia://help/pdfs) jagorar yana rufe karatun PDF da listen button nasa.
