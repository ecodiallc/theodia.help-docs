---
title: Barka Da Zuwa Theodia
level: beginner
categories: welcome
summary: Wani short tour na app ɗin da abin da ya iya yi maka.
---

# Barka Da Zuwa Theodia

Theodia app ɗin karatun Littafi Mai Tsarki ne. Yana buga a phone ko tablet, har ma lokacin da ba ka da intanet. Dukkan abin da ka karanta, ka bincika, ka karanta, yana adana a na'urarka.

## Abin da zaka iya yi

Theodia yana da yanayin mai amfani guda uku. Kowanne yanayi yana nuna wani saitin fasali.

- **Mai karatu** — karanta Littafi Mai Tsarki a cikin view mai tsabta da bai damu ba.
- **Tsarin** — dukkan abin da ke a Mai karatu, ƙari da alamta, haske, rubuce-rubuce, text-to-speech, bincike, da daily devotionals.
- **Malami** — dukkan abin da ke a Tsarin, ƙari da commentaries, lexicons, Bible Dictionary, AI assistant, da sauransu.

Zaka iya switching yanayi kowanne lokaci a **Saitunan** → **Yanayin Mai Amfani**.

### Fasalan da ke nan maka

Ba tare da la'akari da yanayi da ka zaɓa ba, zaka iya koyaushe:

- **Karanta Littafi Mai Tsarki.** Zaɓi daga fassarori da dama. Canza tsakaninsu kowanne lokaci.
- **Bincika Littafi Mai Tsarki.** Nemo kalma ko jumla. App ɗin yana nuna maka kowanne aya da ya dace.
- **Karanta littattafai da devotionals.** App ɗin ya zo tare da klasik na Kirista da devotional na yau da yau.

Dangane da yanayinka, zaka iya kuma:

- **Saurari.** Saurari ayoyi a haute tare da read-aloud feature. (Tsarin da Malami.)
- **Ci gaba da bayanai.** Rubuta ra'ayoyinka kusa da aya. (Tsarin da Malami.)
- **Haske.** Nuna ayoyinka masu so tare da launi. (Tsarin da Malami.)
- **Alamta.** Ajiye ayoyi domin sauri samun su daga baya. (Tsarin da Malami.)
- **Nemi AI assistant.** Sami taimako wajen fahimtar aya. (Malami kawai.)

## Inda za a fara

1. Buɗe **Littafi Mai Tsarki** tab a ƙasan allon.
2. Zaɓi fassara.
3. Taɓa kowanne littafi don fara karatu.

Idan kana so ka koyi ƙara, sauran jagororin taimako suna nan maka. Zaɓi topic daga jerin a kan shafin taimako na home.

## Wasu abubuwan da ya kamata ka sani

- Ba a bukatar account.
- Rubuce-rubucenka, haske, da alamta suna kwanciyar a na'urarka.
- Zaka iya ajiye su. Duba [Ajiyar Bayanaka](theodia://help/backups) jagorar don yadda.

## Kana so ƙarin abubuwa?

App ɗin ya zo tare da fassarori na Littafi Mai Tsarki da dama da aka bayar don kyauta. Don ƙarin Bibles, commentaries, lexicons, littattafai, da devotionals, duba [Samun Ƙarin Abubuwa Daga GitHub](theodia://help/getting-core-files) jagorar. Yana nuna maka yadda ake samu da ƙara ƙarin abubuwa daga project's GitHub page.

Barka da zuwa. Muna fatan Theodia zai taimaka maka karantawa da karatu.
