---
title: Menene albarkatu (Resources)?
level: beginner
categories: resources
summary: Tattaunawa game da irin fayilolin da Theodia ke amfani da su — Littafi Mai Tsarki, sharhi (commentary), littattafai, da sauransu.
---

# Menene albarkatu (Resources)?

A Theodia, "albarkatu" (resource) shi ne duk wani fayil da ke ƙara kayan karatu ko karatun nazari cikin manhaja. Manhaja ita kanta kawai mai karatu ne da kuma takarda (notebook). Littafi Mai Tsarki, sharhi (commentary), littattafai da sauran kayan da kuke nazarin su tare da su duk fayiloli ne dake da kansu waɗanda kuke loda cikin app ɗin.

Wannan jagora yana bayyana irin albarkatun da ake da su da kuma amfanin kowanne.

## Don me wannan yake da muhimmanci?

Lokacin da ka bude Theodia a karon farko, yana da wasu kayan karatu a shiye. Yayinda kake bincike, za ka ga maɓallan da za ka sanya ƙarin. Sanin irin albarkatu da kowanne yake ba zai taimaka maka wajen yanke shawarar abin da za a ƙara.

## Irin albarkatun dake akwai

Theodia tana gane fayiloli ta hanyar ƙarshen sunansu (extension). Kowace ƙarshen suna wani irin albarkatu ne.

### `.bible` — fassarar Littafi Mai Tsarki

Fassarar Littafi Mai Tsarki kwafin Littafi Mai Tsarki ne cikakke a cikin wani bugu, kamar King James Version. Theodia tana zuwa tare da wasu fassarori kuma tana ba da izinin ƙara ƙarin.

Duba jagorar [Installing Bible Translations](theodia://help/installing-bibles) don ƙarin bayani.

### `.commentary` — sharhi (commentary)

Sharhi littafi ne na bayanai na nazarin Littafi Mai Tsarki da ɗan ilimin tauhidi ya rubuta. Don aya ta ba, sharhi yana gayyat tarihin baya, ma'anarsa, da kuma yadda ayar ke dacewa cikin sauran Littafi Mai Tsarki.

Duba jagorar [Commentaries and Lexicons](theodia://help/commentaries-and-lexicons) don ƙarin bayani.

### `.lexicon` — ƙamus (lexicon)

Lexicon ƙamus ne na kalmomin Littafi Mai Tsarki. Yana gayyat kalmar Ibrananci ko Girkanci asali, ma'anar ta, da yadda ake amfani da ita a Littafi Mai Tsarki.

Duba jagorar [Commentaries and Lexicons](theodia://help/commentaries-and-lexicons) don ƙarin bayani.

### `.book` — littafi na Kirista

Littafi dogon aiki ne na Kirista, kamar classic daga tarihin coci. Karatu littattafai a app ɗin yana aiki irin karatun Littafi Mai Tsarki. Theodia tana zuwa tare da ƙaramin ɗakin karatu na classics na Kirista kyauta.

Duba jagorar [Reading Built-in Books](theodia://help/reading-books) don ƙarin bayani.

### `.devotional` — devotional

Devotional ƙaramin karatu ne na kowace rana. Kowace shigarwa yawanci tana da aya, ƙaramin tunani, da addu'a ko tambaya. Devotionals da yawa an tsara su da aka karanta shigarwa ɗaya a kowace rana na shekara.

Duba jagorar [Daily Devotionals](theodia://help/daily-devotionals) don ƙarin bayani.

### `.sqlite` — bayanin bayanai (reference database)

Bayanin bayanai ƙa'ida ce mai girma wadda app ɗin ke amfani don ba ka ƙarin bayani yayinda kake karatu. Akwai nau'i biyu:

- **Cross-references** — jerin ayoyi da ke haɗa da ayar da kake karatu.
- **Morphology** — bayani game da kalmomin Ibrananci ko Girkanci na asali a cikin ayar.

Ba ka buɗe waɗannan kai tsaye. Suka yi aiki a bayan fage kuma suna ƙara fasali cikin mai karatun Littafi Mai Tsarki. Duba jagorar [Cross-References](theodia://help/cross-references) don ƙarin bayani.

### `.data` — bayanin kalmomin (word data)

Fayil ɗin bayanin kalmomin yana riƙe ƙarin bayani game da kalmomin asalin Littafi Mai Tsarki. Ana amfani da shi ta lexicon da kayan nazarin. Kamar bayanin bayanai, ba ka buɗe shi kai tsaye. App ɗin yana amfani da shi a bayan fage.

## Yadda ake ƙara albarkatu

Screen ɗin **Manage Resources** na app ɗin shine hanyar sauki ta ƙara albarkatu.

1. Bude **Settings**.
2. Danna **Manage Resources**.
3. Danna **Install from GitHub**.
4. A cikin modal ɗin download, zaɓi tab — **Bibles**, **Commentaries**, **Books**, **Devotionals**, ko **Core** — sannan zaɓi abin da kake so kuma danna **Install Selected**.
5. Ko danna **Install Local File** don shigo da fayil ɗin da ka riga ka sauke.

Don jagorar mataki-mataki na samun fayiloli kai tsaye daga GitHub, duba jagorar [Getting Extra Resources from GitHub](theodia://help/getting-core-files).

## Yadda ake cire albarkatu

1. Bude **Settings**.
2. Danna **Manage Resources**.
3. Nemo albarkatun da kake son cire.
4. Danna alamar kwandon shara kusa da shi.
5. Tabbatar kana son cire shi.

Cire albarkatu ba ya share bayanunka, highlights ko bookmarks. Suna nan cikin aminci.

## Ina albarkatu ke zaune a kan na'urarka

Albarkatu ana adana su a kan na'urarka, ba a cloud ba. Da zarar albarkatu an shigar, ba ka buƙatar internet don karanta shi. Zaka iya adana na'urarka, amma albarkatun ba a adana su a cloud ta Theodia. Idan ka cire app ɗin kuma ka sake shigarwa, za ka buƙaci ƙara kowace irin albarkatu da ka riga ka shigar.

## Taimako da tambayoyi

Idan ka sami wahala, duba jagorar [Where to Ask Questions](theodia://help/getting-more-help). Ƙungiya da al'umma za su iya taimakawa.
