---
title: יצירת משאבים משלכם
level: advanced
categories: resources
summary: איך ליצור תנ"כים, פירושים, ספרים, תרגולים יומיים ולקסיקונים מותאמים ולייבא אותם ל-Theodia.
---

# יצירת משאבים משלכם

Theodia תומכת במשאבים מותאמים בפורמט Unique Bible App. כל משאב הוא קובץ SQLite עם מבנה טבלה ספציפי. אפשר ליצור את הקבצים האלה במחשב ולייבא אותם לאפליקציה.

## סוגי קבצים וטבלאות נדרשות

### תנ"כים (`.bible`)

קובץ תנ"ך הוא מסד נתונים SQLite עם לפחות אחת מהטבלאות האלה:

- **`Verses`** — עמודות: `Book` (מספר שלם, 1-66), `Chapter` (מספר שלם), `Verse` (מספר שלם), `Scripture` (טקסט)
- **`Bible`** — עמודות: `Book` (מספר שלם), `Chapter` (מספר שלם), `Verse` (מספר שלם), `Scripture` (טקסט)

אפשר גם לכלול טבלת **`Details`** עם עמודות מטא-נתונים כמו `Description`, `Abbreviation` ו-`Version`.

דוגמת SQL:

```sql
-- Main text table
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- Optional metadata table
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### פירושים (`.commentary`)

פירושים מגיעים בשלושה סוגים: **ספר**, **פרק** ו**פסוק**. הסוג נקבע לפי **האות הראשונה של שם הקובץ**.

#### פירושי ספר — שם הקובץ מתחיל ב-`b`

פירוש ספר מכסה ספר שלם בתנ"ך בערך אחד. הטבלה `Commentary` צריכה עמודות `Book` ו-`Scripture` (או `Content`). אין צורך בעמודות `Chapter` או `Verse`.

- **`Commentary`** — עמודות: `Book` (מספר שלם), `Scripture` (טקסט) או `Content` (טקסט)

דוגמת SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

דוגמת שם קובץ: `bMyCommentary.commentary`

#### פירושי פרק — שם הקובץ מתחיל ב-`c`

פירוש פרק מכסה כל פרק בספר תנ"ך.

- **`Commentary`** — עמודות: `Book` (מספר שלם), `Chapter` (מספר שלם), `Scripture` (טקסט) או `Content` (טקסט)

דוגמת SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

דוגמת שם קובץ: `cMyCommentary.commentary`

#### פירושי פסוק — שם הקובץ מתחיל ב-`v`

פירוש פסוק מכסה פסוקים בודדים. הטבלה `Commentary` צריכה את העמודות `Book`, `Chapter`, `Verse` ו-`Scripture` (או `Content`).

- **`Commentary`** — עמודות: `Book` (מספר שלם), `Chapter` (מספר שלם), `Verse` (מספר שלם), `Scripture` (טקסט) או `Content` (טקסט)

דוגמת SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

דוגמת שם קובץ: `vMyCommentary.commentary`

### ספרים (`.book`)

קובץ ספר הוא מסד נתונים SQLite עם טבלת `Reference`.

- **`Reference`** — עמודות: `id` (מספר שלם), `Chapter` (טקסט), `Content` (טקסט)

כל שורה היא פרק אחד. העמודה `Chapter` היא כותרת הפרק. העמודה `Content` היא גוף הפרק, שיכול לכלול HTML (`<b>`, `<i>`, `<br>` וכו').

דוגמת SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

אפשר גם ליצור ספרים מקובצי Markdown. האפליקציה יכולה לייבא קובצי `.md` שבהם `#` הוא כותרת הספר ו-`##` מסמן פרקים. ה-Markdown מומר ל-HTML אוטומטית.

### תרגולים יומיים (`.devotional`)

קובץ תרגול יומי הוא מסד נתונים SQLite עם טבלת `devotional`.

- **`devotional`** — עמודות: `month` (מספר שלם, 1-12), `day` (מספר שלם, 1-31), `devotion` (טקסט)

כל שורה היא קריאת יום אחד. האפליקציה מאתרת את הערך לפי החודש והיום של היום.

דוגמת SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### לקסיקונים (`.lexicon`)

קובץ לקסיקון הוא מסד נתונים SQLite עם טבלת `Lexicon`.

- **`Lexicon`** — עמודות: `Topic` (טקסט, מספר ה-Strong), `Definition` (טקסט, ערך הלקסיקון)

העמודה `Topic` מחזיקה את מספר ה-Strong (לדוגמה, `G1161` או `H7225`). העמודה `Definition` מחזיקה את טקסט הערך המלא, שיכול לכלול HTML.

דוגמת SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

לקסיקונים מפעילים את כלי מידע על מילה. כשאתם מקישים על מילה בתנ"ך בין-ליניארי, האפליקציה מחפשת את מספר ה-Strong בלקסיקונים המותקנים.

## יצירת קובץ במחשב שלכם

1. התקינו עורך SQLite (DB Browser for SQLite, SQLiteStudio, או כלי שורת הפקודה `sqlite3`).
2. צרו קובץ מסד נתונים חדש.
3. צרו את הטבלה הנדרשת והזינו את הנתונים שלכם.
4. שמרו את הקובץ עם הסיומת הנכונה (`.bible`, `.commentary`, `.book`, `.devotional` או `.lexicon`).

## יבוא ל-Theodia

1. העבירו את הקובץ אל המכשיר שלכם (AirDrop, דואר אלקטרוני, אחסון ענן או USB).
2. פתחו את **Theodia**.
3. עברו אל **הגדרות** ← **ניהול משאבים**.
4. הקישו על **יבוא מקובץ**.
5. בחרו את הקובץ שלכם.

האפליקציה מאמתת את הקובץ (בודקת את הטבלה הנדרשת), מעתיקה אותו לתיקיית הנתונים של האפליקציה ומפעילה אותו אוטומטית. אם הקובץ שגוי, אתם רואים הודעת שגיאה שמסבירה מה שגוי.

## מגבלות

- אי אפשר לדרוס משאבים מובנים. אם תנסו לייבא קובץ באותו שם כמו תנ"ך, פירוש או ספר מובנה, היבוא נכשל.
- קובצי תנ"ך צריכים טבלת `Verses` או `Bible`. אם אף אחת מהן לא קיימת, היבוא נכשל.
- קובצי פירוש צריכים טבלת `Commentary`.
  - פירושי ספר צריכים עמודות `Book` ו-`Scripture` (או `Content`).
  - פירושי פרק צריכים עמודות `Book`, `Chapter` ו-`Scripture` (או `Content`).
  - פירושי פסוק צריכים עמודות `Book`, `Chapter`, `Verse` ו-`Scripture` (או `Content`).
- קובצי ספר צריכים טבלת `Reference`.
- קובצי לקסיקון צריכים טבלת `Lexicon`.
- קובצי תרגול יומי צריכים טבלת `devotional`.

## עצות

- שמרו על גדלי קבצים סבירים. קובצי SQLite גדולים מאוד עשויים לגרום לבעיות זיכרון במכשירים ישנים.
- בדקו את הקובץ שלכם במחשב קודם. פתחו אותו בדפדפן SQLite והריצו `SELECT * FROM` על הטבלה הנדרשת כדי לוודא שהנתונים נראים נכון.
- עבור תנ"כים, ודאו שהעמודה `Book` משתמשת במספרים (1 = בראשית, 66 = ההתגלות).
- עבור פירושים, אפשר להשתמש ב-`Scripture` או ב-`Content` כעמודת טקסט הפירוש.
- עבור ספרים, HTML בעמודה `Content` מוצג בזמן קריאה. שמרו על פשטות: `<b>`, `<i>`, `<br>` ו-`<hr>` בטוחים.

## איפה למצוא משאבים קיימים

Theodia יכולה לקרוא משאבים מפרויקט [Unique Bible App](https://github.com/eliranwong/UniqueBible). תנ"כים, פירושים, ספרים ומשאבים אחרים רבים זמינים שם בפורמט SQLite הנכון. ראו את המדריך [השגת משאבים נוספים](theodia://help/getting-core-files) לאופן המציאה וההוספה שלהם.
