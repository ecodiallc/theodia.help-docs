---
title: अपने संसाधन बनाना
level: advanced
categories: resources
summary: Theodia के लिए कस्टम बाइबिल, टीका, पुस्तकें, भक्तिपूर्ण पाठ और लेक्सिकॉन कैसे बनाएँ और आयात करें।
---

# अपने संसाधन बनाना

Theodia Unique Bible App प्रारूप में कस्टम संसाधनों का समर्थन करता है। प्रत्येक संसाधन एक विशिष्ट तालिका संरचना वाली SQLite फ़ाइल होती है। आप इन फ़ाइलों को कंप्यूटर पर बना सकते हैं और ऐप में आयात कर सकते हैं।

## फ़ाइल प्रकार और आवश्यक तालिकाएँ

### बाइबिल (`.bible`)

बाइबिल फ़ाइल कम से कम एक इन तालिकाओं वाली SQLite डेटाबेस है:

- **`Verses`** — कॉलम: `Book` (पूर्णांक, 1-66), `Chapter` (पूर्णांक), `Verse` (पूर्णांक), `Scripture` (पाठ)
- **`Bible`** — कॉलम: `Book` (पूर्णांक), `Chapter` (पूर्णांक), `Verse` (पूर्णांक), `Scripture` (पाठ)

आप `Description`, `Abbreviation` और `Version` जैसे मेटाडेटा कॉलम के साथ **`Details`** तालिका भी शामिल कर सकते हैं।

उदाहरण SQL:

```sql
-- मुख्य पाठ तालिका
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- वैकल्पिक मेटाडेटा तालिका
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### टीकाएँ (`.commentary`)

टीकाएँ तीन प्रकार की होती हैं: **पुस्तक**, **अध्याय** और **वचन**। प्रकार **फ़ाइलनाम के पहले अक्षर** से निर्धारित होता है।

#### पुस्तक टीका — फ़ाइलनाम `b` से शुरू होता है

पुस्तक टीका पूरी बाइबिल पुस्तक को एक ही प्रवेश में कवर करता है। `Commentary` तालिका को `Book` और `Scripture` (या `Content`) कॉलम की आवश्यकता होती है। `Chapter` या `Verse` कॉलम की आवश्यकता नहीं है।

- **`Commentary`** — कॉलम: `Book` (पूर्णांक), `Scripture` (पाठ) या `Content` (पाठ)

उदाहरण SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

फ़ाइलनाम उदाहरण: `bMyCommentary.commentary`

#### अध्याय टीका — फ़ाइलनाम `c` से शुरू होता है

अध्याय टीका बाइबिल पुस्तक के प्रत्येक अध्याय को कवर करता है।

- **`Commentary`** — कॉलम: `Book` (पूर्णांक), `Chapter` (पूर्णांक), `Scripture` (पाठ) या `Content` (पाठ)

उदाहरण SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

फ़ाइलनाम उदाहरण: `cMyCommentary.commentary`

#### वचन टीका — फ़ाइलनाम `v` से शुरू होता है

वचन टीका व्यक्तिगत वचनों को कवर करता है। `Commentary` तालिका को `Book`, `Chapter`, `Verse` और `Scripture` (या `Content`) कॉलम की आवश्यकता होती है।

- **`Commentary`** — कॉलम: `Book` (पूर्णांक), `Chapter` (पूर्णांक), `Verse` (पूर्णांक), `Scripture` (पाठ) या `Content` (पाठ)

उदाहरण SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

फ़ाइलनाम उदाहरण: `vMyCommentary.commentary`

### पुस्तकें (`.book`)

पुस्तक फ़ाइल `Reference` तालिका वाली SQLite डेटाबेस है।

- **`Reference`** — कॉलम: `id` (पूर्णांक), `Chapter` (पाठ), `Content` (पाठ)

प्रत्येक पंक्ति एक अध्याय है। `Chapter` कॉलम अध्याय शीर्षक है। `Content` कॉलम अध्याय का मुख्य भाग है, जिसमें HTML (`<b>`, `<i>`, `<br>`, आदि) शामिल हो सकता है।

उदाहरण SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

आप Markdown फ़ाइलों से भी पुस्तकें बना सकते हैं। ऐप `.md` फ़ाइलें आयात कर सकता है जहाँ `#` पुस्तक का शीर्षक है और `##` अध्यायों को चिह्नित करता है। Markdown स्वचालित रूप से HTML में बदल जाता है।

### भक्तिपूर्ण पाठ (`.devotional`)

भक्तिपूर्ण पाठ फ़ाइल `devotional` तालिका वाली SQLite डेटाबेस है।

- **`devotional`** — कॉलम: `month` (पूर्णांक, 1-12), `day` (पूर्णांक, 1-31), `devotion` (पाठ)

प्रत्येक पंक्ति एक दिन का पाठण है। ऐप आज के महीने और दिन के अनुसार प्रवेश देखता है।

उदाहरण SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### लेक्सिकॉन (`.lexicon`)

लेक्सिकॉन फ़ाइल `Lexicon` तालिका वाली SQLite डेटाबेस है।

- **`Lexicon`** — कॉलम: `Topic` (पाठ, Strong's संख्या), `Definition` (पाठ, लेक्सिकॉन प्रवेश)

`Topic` कॉलम Strong's संख्या रखता है (उदाहरण के लिए, `G1161` या `H7225`)। `Definition` कॉलम पूर्ण प्रवेश पाठ रखता है, जिसमें HTML शामिल हो सकता है।

उदाहरण SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

लेक्सिकॉन शब्द जानकारी उपकरण को शक्ति देते हैं। जब आप इंटरलिनियर बाइबिल में कोई शब्द टैप करते हैं, तो ऐप इंस्टॉल किए गए लेक्सिकॉन में Strong's संख्या देखता है।

## अपने कंप्यूटर पर फ़ाइल बनाना

1. SQLite संपादक इंस्टॉल करें (DB Browser for SQLite, SQLiteStudio, या `sqlite3` कमांड-लाइन उपकरण)।
2. एक नई डेटाबेस फ़ाइल बनाएँ।
3. आवश्यक तालिका बनाएँ और अपना डेटा डालें।
4. फ़ाइल को सही एक्सटेंशन (`.bible`, `.commentary`, `.book`, `.devotional` या `.lexicon`) के साथ सहेजें।

## Theodia में आयात करना

1. फ़ाइल को अपने डिवाइस पर स्थानांतरित करें (AirDrop, ईमेल, क्लाउड स्टोरेज या USB)।
2. **Theodia** खोलें।
3. **सेटिंग्स** → **संसाधन प्रबंधित करें** में जाएँ।
4. **फ़ाइल से आयात करें** पर टैप करें।
5. अपनी फ़ाइल चुनें।

ऐप फ़ाइल को मान्य करता है (आवश्यक तालिका के लिए जाँच करता है), इसे ऐप के डेटा फ़ोल्डर में कॉपी करता है, और इसे स्वचालित रूप से सक्षम कर देता है। यदि फ़ाइल अमान्य है, तो आपको एक त्रुटि संदेश दिखाई देता है जो बताता है कि क्या गलत है।

## सीमाएँ

- आप निर्मित संसाधनों को अधिलेखित नहीं कर सकते। यदि आप किसी निर्मित बाइबिल, टीका या पुस्तक के समान नाम वाली फ़ाइल आयात करने का प्रयास करते हैं, तो आयात विफल हो जाता है।
- बाइबिल फ़ाइलों को `Verses` या `Bible` तालिका की आवश्यकता होती है। यदि कोई भी मौजूद नहीं है, तो आयात विफल हो जाता है।
- टीका फ़ाइलों को `Commentary` तालिका की आवश्यकता होती है।
  - पुस्तक टीकों को `Book` और `Scripture` (या `Content`) कॉलम की आवश्यकता होती है।
  - अध्याय टीकों को `Book`, `Chapter` और `Scripture` (या `Content`) कॉलम की आवश्यकता होती है।
  - वचन टीकों को `Book`, `Chapter`, `Verse` और `Scripture` (या `Content`) कॉलम की आवश्यकता होती है।
- पुस्तक फ़ाइलों को `Reference` तालिका की आवश्यकता होती है।
- लेक्सिकॉन फ़ाइलों को `Lexicon` तालिका की आवश्यकता होती है।
- भक्तिपूर्ण पाठ फ़ाइलों को `devotional` तालिका की आवश्यकता होती है।

## सुझाव

- फ़ाइल आकारों को उचित रखें। बहुत बड़ी SQLite फ़ाइलें पुराने डिवाइसों पर मेमोरी समस्याएँ पैदा कर सकती हैं।
- पहले अपनी फ़ाइल का कंप्यूटर पर परीक्षण करें। इसे SQLite ब्राउज़र में खोलें और आवश्यक तालिका से `SELECT * FROM` चलाकर सत्यापित करें कि डेटा सही दिखता है।
- बाइबिल के लिए, सुनिश्चित करें कि `Book` कॉलम संख्याएँ उपयोग करता है (1 = उत्पत्ति, 66 = प्रकाशितवाक्य)।
- टीकों के लिए, आप टीका पाठ कॉलम के रूप में `Scripture` या `Content` का उपयोग कर सकते हैं।
- पुस्तकों के लिए, `Content` कॉलम में HTML पढ़ते समय रेंडर किया जाता है। इसे सरल रखें: `<b>`, `<i>`, `<br>` और `<hr>` सुरक्षित हैं।

## मौजूदा संसाधन कहाँ खोजें

Theodia [Unique Bible App](https://github.com/eliranwong/UniqueBible) परियोजना के संसाधन पढ़ सकता है। वहाँ कई बाइबिल, टीकाएँ, पुस्तकें और अन्य संसाधन सही SQLite प्रारूप में उपलब्ध हैं। उन्हें खोजने और जोड़ने का तरीका [अतिरिक्त संसाधन प्राप्त करना](theodia://help/getting-core-files) गाइड में देखें।
