---
title: PDF फ़ाइलें
level: everyday
categories: [read, resources]
summary: Theodia में PDF documents इंपोर्ट करें, व्यवस्थित करें और पढ़ें।
---

# PDF फ़ाइलें

> **मोड:** PDFs **मानक** और **विद्वान** मोड में उपलब्ध हैं। फोकस मोड केवल साफ़, बिना व्यवधान के पढ़ने के लिए है। मोड बदलने के लिए **सेटिंग्स** → **ऐप उपयोगकर्ता मोड** में जाएँ।

Theodia PDF फ़ाइलें सेव और पढ़ सकता है। इंपोर्ट की गई PDFs आपके डिवाइस पर रहती हैं, इसलिए वे offline काम करती हैं।

## PDF library खोलें

स्क्रीन के नीचे **PDFs** टैब पर टैप करें, या Home screen पर **PDFs** tile पर टैप करें।

## PDF इंपोर्ट करना

1. **PDFs** टैब खोलें।
2. नीचे-दाएँ **+** बटन पर टैप करें।
3. अपने डिवाइस से एक PDF चुनें।
4. (वैकल्पिक) उसे व्यवस्थित करने के लिए एक category टाइप करें या चुनें।

## PDF व्यवस्थित करना

किसी भी PDF card को long-press करें ताकि इन विकल्पों वाला मेनू खुल जाए:

- **Rename** — library में दिखाया जाने वाला शीर्षक बदलें।
- **Change category** — PDF को एक category में ले जाएँ।
- **Delete** — PDF को Theodia से हटाएँ। इससे उसकी सेव की गई reading position भी हट जाती है।

Categories free-form text हैं। इंपोर्ट करते या category बदलते समय नया नाम टाइप करें या कोई मौजूदा चुनें।

## PDF पढ़ना

किसी PDF card पर टैप करें ताकि वह खुल जाए। Reader में होता है:

- ऊपर एक bar में document का शीर्षक।
- page buttons की एक row: **First page**, **Previous**, current page ("3 / 120"), **Next**, और **Last page**।
- document के tools के साथ एक toolbar: **Contents**, **Zoom out**, **Zoom in**, **Reset zoom**, **Bookmark**, **Search**, **Listen**, और **Text view**।

कुछ tools dimmed होते हैं जब उनका उपयोग नहीं हो सकता — उदाहरण के लिए, **Search** और **Listen** तब तक dimmed रहते हैं जब तक PDF का searchable text इंस्टॉल न हो जाए।

### Pages बदलना

- एक page पीछे या आगे जाने के लिए **बायाँ** या **दायाँ chevron** टैप करें।
- Document के किसी भी सिरे पर जाने के लिए **First page** या **Last page** टैप करें।
- Page number (उदाहरण के लिए "3 / 120") टैप करें ताकि pages की एक grid खुल जाए, फिर जिस page पर जाना है उस पर टैप करें। Grid आपके current page के पास खुलती है।
- External keyboard पर **Left** और **Right arrow keys** का उपयोग करें।

### Zoom

- Page का आकार बदलने के लिए **Zoom in** (+) या **Zoom out** (−) टैप करें।
- Page को सामान्य आकार पर लौटाने के लिए **Reset zoom** टैप करें।
- यदि आप zoom in करते हैं, page बदलते हैं, और फिर zoom out करते हैं, तो Theodia आपको उसी page पर लौटा देता है जहाँ आप पढ़ रहे थे।

## PDF में खोज

1. PDF खोलें और toolbar में **Search** (magnifying glass) बटन पर टैप करें।
2. जो खोज रहे हैं वह टाइप करें। टाइप करते ही results दिखाई देते हैं, page number और आस-पास के text के snippet के साथ।
3. उस page पर पहुँचने के लिए किसी result पर टैप करें।

खोज के लिए PDF का searchable text इंस्टॉल होना ज़रूरी है। यदि वह अभी इंस्टॉल नहीं है, तो **Search** बटन dimmed रहता है। Community GitHub repository से इंस्टॉल की गई PDFs में searchable text होता है; आपके द्वारा खुद इंपोर्ट की गई PDFs में वह तब तक नहीं होता जब तक जोड़ा न जाए।

## Contents

यदि PDF में built-in table of contents है, तो toolbar का **Contents** बटन उसे outline के रूप में दिखाता है। उस page पर पहुँचने के लिए किसी section के शीर्षक पर टैप करें। Sections को expand और collapse किया जा सकता है। यदि PDF में table of contents नहीं है, तो बटन dimmed रहता है।

## PDF में bookmarks

1. PDF खोलें और toolbar में **Bookmark** बटन पर टैप करें।
2. Current page सेव करने के लिए **Bookmark page** टैप करें। नाम शुरू में page number होता है — चाहें तो अपना नाम टाइप करें — फिर **Save** टैप करें।
3. उसके page पर पहुँचने के लिए सूची में किसी भी bookmark पर टैप करें।
4. Bookmark हटाने के लिए उसके बगल में **×** टैप करें।

PDF bookmarks आपके Bible bookmarks से अलग होते हैं। हर PDF की अपनी सूची होती है।

## PDF ज़ोर से पढ़ना

यदि PDF का searchable text इंस्टॉल है, तो Theodia current page ज़ोर से पढ़ सकता है:

1. PDF खोलें और toolbar में **Listen** (speaker) बटन पर टैप करें।
2. एक control bar दिखाई देता है जिसमें **Play/Pause**, **Rewind**, **Fast forward**, **Stop**, एक progress bar (जिस पर टैप करके page के भीतर skip कर सकते हैं), reading speed, और voice होते हैं।
3. Page पूरा होने पर reading अपने आप अगले page पर चलती रहती है।

Voice और speed वही हैं जो Bible reading के लिए उपयोग होते हैं — उन्हें बदलने का तरीका [ज़ोर से पढ़ना (TTS)](theodia://help/tts) गाइड में देखें।

## Page का text copy, share, या save करना

Current page को सादे text के रूप में देखने के लिए toolbar का **Text view** बटन टैप करें। वहाँ से आप:

- **Copy** — page का text clipboard पर copy करें।
- **Share** — page का text अपने डिवाइस के किसी भी ऐप से share करें।
- **Add to study notes** — एक note editor खुलता है जिसमें page का text, एक citation, और इस page पर वापस जाने का link आपके लिए पहले से भरा हुआ होता है।

## Reading जारी रखना

Theodia आख़िरी page याद रखता है जिसे आपने देखा था, और अगली बार PDF वहीं से खोलता है।

## GitHub से PDFs डाउनलोड करना

**विद्वान** मोड में, library के नीचे एक **Download from GitHub** बटन दिखाई देता है। यह community PDF repository से जुड़ता है ताकि आप packaged PDF documents उसी तरह इंस्टॉल कर सकें जिस तरह Bibles या books इंस्टॉल करते हैं।

## Notes

- PDF फ़ाइलें Theodia के private documents folder में सेव होती हैं। वे backups में शामिल नहीं होतीं, इसलिए यदि आप नए डिवाइस पर जाते हैं तो उन्हें फिर से इंपोर्ट करना होगा।
