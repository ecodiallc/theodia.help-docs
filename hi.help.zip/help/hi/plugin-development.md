---
title: प्लगइन विकसित करना
categories: plugins
level: advanced
summary: Theodia plugin package में क्या होता है और plugin manifest कैसे लिखें।
---

# प्लगइन विकसित करना

एक Theodia plugin एक स्वयं-निहित package है जो ऐप में UI surfaces, content या event handling जोड़ता है। Plugins मुख्य ऐप के बाहर authored किए जाते हैं और उपयोगकर्ताओं द्वारा Settings → Plugins के माध्यम से इंस्टॉल किए जाते हैं।

## Plugin package संरचना

एक plugin package `.plugin.zip` extension वाला ZIP archive है। अंदर, files शीर्ष स्तर पर रहती हैं — nested folder के अंदर नहीं।

एक typical package में ये होते हैं:

```
my-plugin.plugin.zip
├── plugin.json       (required)
├── data.sqlite       (optional, for content/ui plugins)
├── template.html     (optional)
├── style.css         (optional)
└── logo.png          (optional)
```

Required files:

- `plugin.json` — plugin manifest (नीचे देखें)।

Optional files:

- Content या UI data संग्रहीत करने वाले plugins के लिए एक SQLite database।
- HTML, Markdown, image या JSON assets जिनका manifest द्वारा संदर्भ दिया जाता है।

`plugin.json` में सभी asset references को path के बिना exact, flat file names का उपयोग करना चाहिए। उदाहरण के लिए, `templates/template.html` के बजाय `template.html` का उपयोग करें।

## Manifest मूल बातें

एक minimal `plugin.json` इस तरह दिखता है:

```json
{
  "id": "org.example.myplugin",
  "name": "Example Plugin",
  "version": "0.1.0",
  "type": "ui",
  "description": "A short description of what the plugin does.",
  "extensions": [
    {
      "surface": "bible-verse-menu",
      "config": {
        "label": "Example",
        "icon": "🔌",
        "screenType": "template",
        "templateFile": "template.html"
      }
    }
  ]
}
```

### सामान्य manifest fields

| Field           | Required                          | Description                                                          |
| --------------- | --------------------------------- | -------------------------------------------------------------------- |
| `id`            | Yes                               | Reverse-domain-style identifier, उदाहरण `org.example.myplugin`। |
| `name`          | Yes                               | उपयोगकर्ताओं को दिखाया जाने वाला display name।                      |
| `version`       | Yes                               | Plugin का Semver version।                                           |
| `type`          | Yes                               | `ui`, `content`, या `composite`।                                  |
| `description`   | No                                | Plugin क्या करता है, इसका संक्षिप्त सारांश।                         |
| `minAppVersion` | No                                | आवश्यक minimum Theodia app version।                                 |
| `apiVersion`    | No                                | Targeted plugin API version।                                         |
| `extensions`    | Required for `ui` and `composite` | Surface declarations का array (नीचे देखें)।                       |

### Surfaces

प्रत्येक `extensions` entry यह घोषित करती है कि plugin कहाँ दिखाई देता है और यह क्या करता है:

```json
{
  "surface": "home-screen",
  "config": {
    "title": "My Plugin",
    "icon": "📝",
    "screenType": "list",
    "dbTable": "Articles",
    "titleColumn": "Title"
  }
}
```

Supported surfaces:

- `bottom-toolbar` — नीचे Plugins tab में entry।
- `home-screen` — Home screen पर tile।
- `hamburger-menu` — मुख्य मेनू में item।
- `bible-verse-menu` — Bible reader में long-press verse action।
- `bible-chapter-toolbar` — Bible reader में chapter toolbar action।
- `book-chapter-toolbar` — Book reader में toolbar action।
- `ai-verse-action` — verse पर AI action (AI सक्षम होना चाहिए)।
- `ai-chapter-action` — chapter पर AI action (AI सक्षम होना चाहिए)।
- `event` — app lifecycle event handler।

### Screen types

Surface config में `screenType` ऐप को बताता है कि plugin screen कैसे render करना है:

- `list` — database rows की scrollable list।
- `data-list` — add/edit/delete के साथ list।
- `detail` — single-row या passage content।
- `markdown` — static Markdown file, HTML के रूप में rendered।
- `html` — static HTML file, `react-native-render-html` के साथ rendered।
- `template` — `{{key}}` placeholder replacement वाली HTML file।
- `flashcard` — दो database columns का उपयोग करते हुए flip-card UI।

## Distribution

एक बार `.plugin.zip` फ़ाइल के रूप में package हो जाने के बाद, plugin को:

- सीधे file से user द्वारा import किया जा सकता है।
- catalog repository से serve किया जा सकता है।

## सुझाव

- `plugin.json` को valid JSON रखें। ऐप इंस्टॉल के दौरान invalid manifests अस्वीकार कर देता है।
- सभी referenced assets के लिए exact file names का उपयोग करें।
- Plugin IDs collision से बचने के लिए reverse-domain style का पालन करनी चाहिए।
- Plugin content को offline test करें, क्योंकि उपयोगकर्ताओं के पास network connection नहीं हो सकता।
