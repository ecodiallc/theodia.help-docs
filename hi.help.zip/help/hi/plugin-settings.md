---
title: प्लगइन सक्षम और कॉन्फ़िगर करना
level: advanced
categories: plugins
summary: Plugins को चालू, बंद और नए import करना।
---

# प्लगइन सक्षम और कॉन्फ़िगर करना

एक बार plugin इंस्टॉल हो जाने के बाद, आप उसे चालू, बंद और हटा सकते हैं। यह गाइड दिखाती है कि कैसे।

## Plugin settings कैसे खोलें

1. **सेटिंग्स** खोलें।
2. **Plugins** पर टैप करें।
3. **Manage Plugins** पर टैप करें।

## Plugin चालू या बंद कैसे करें

**Installed Plugins** सूची में, वांछित plugin ढूँढें। दाईं ओर के switch पर टैप करें।

- **On** — plugin सक्रिय है।
- **Off** — plugin रोका गया है।

कुछ plugins के home page के **Plugins** row पर भी एक on/off switch होता है।

## Plugin कैसे हटाएँ

1. **Installed Plugins** सूची में plugin ढूँढें।
2. **Uninstall** पर टैप करें।
3. पुष्टि करें।

## नया plugin कैसे install करें

1. ऊपर दिए गए अनुसार plugin settings खोलें।
2. **Import from File** पर टैप करें।
3. अपने डिवाइस से plugin file चुनें।

Plugin **Installed Plugins** सूची में दिखाई देता है। इसे उपयोग करना शुरू करने के लिए चालू करें।

## सुझाव

- कुछ plugins को काम करने के लिए इंटरनेट की आवश्यकता होती है। वे ऑफ़लाइन काम नहीं कर सकते।
- कुछ plugins को account या key की आवश्यकता होती है। Plugin का अपना page इसे समझाएगा।
- यदि कोई plugin समस्या पैदा कर रहा है, तो उसे बंद कर दें। आप बाकी ऐप का उपयोग करना जारी रख सकते हैं।
- किसी plugin को हटाने से आपके notes, highlights या bookmarks नहीं हटते। वे सुरक्षित रहते हैं।
