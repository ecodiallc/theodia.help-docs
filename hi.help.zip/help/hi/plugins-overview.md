---
title: Plugins क्या हैं?
level: advanced
categories: plugins
summary: Plugins और वे क्या जोड़ सकते हैं, इसका सादा-भाषा गाइड।
---

# Plugins क्या हैं?

एक plugin Theodia के लिए एक छोटा add-on है। Plugins नई सुविधाएँ, नए संसाधन या नए उपकरण जोड़ते हैं। इन्हें Theodia community में लोग बनाते हैं।

## एक plugin क्या कर सकता है?

Plugins कई चीज़ें कर सकते हैं। कुछ उदाहरण:

- एक नया बाइबिल अनुवाद जोड़ें।
- एक नया commentary या lexicon जोड़ें।
- नीचे के toolbar में एक बटन जोड़ें।
- Home screen पर एक tile जोड़ें।
- मुख्य मेनू में एक entry जोड़ें।
- एक custom study tool जोड़ें।

## Installed plugins कैसे ढूँढें

Plugins तीन स्थानों पर दिखाई दे सकते हैं:

- **Bottom toolbar** — स्क्रीन के नीचे एक **Plugins** tab।
- **Home screen** — Home screen पर plugin grid।
- **Main menu** — मुख्य मेनू में एक **Plugins** entry।

Plugin कहाँ दिखता है यह इस बात पर निर्भर करता है कि उसके author ने manifest में क्या घोषित किया है। किसी भी plugin icon पर टैप करके उसे खोलें।

## Plugin file formats

Theodia दो plugin file formats का समर्थन करता है:

- **`.plugin.zip`** — `plugin.json`, plugin database और किसी भी assets युक्त ZIP archive। यह recommended format है। File name इस तरह दिखता है: `org.example.myplugin.plugin.zip`।
- **Legacy single-file resources** — पुरानी `.bible`, `.commentary`, `.lexicon`, `.book`, `.sqlite` या `.db` files जो database के अंदर ही manifest embed करती हैं। ये अभी भी काम करती हैं लेकिन कम features होते हैं।

## नया plugin कैसे install करें

Theodia में in-app plugin store नहीं है। Plugin install करने के लिए:

1. अपने डिवाइस पर एक plugin file ढूँढें।
2. **सेटिंग्स** → **Plugins** → **Manage Plugins** खोलें।
3. **Import from File** पर टैप करें।
4. Plugin file चुनें।

Plugin **Installed Plugins** सूची में दिखाई देता है। इसका उपयोग शुरू करने के लिए उसे चालू करें।

## Plugin चालू या बंद कैसे करें

**सेटिंग्स** → **Plugins** → **Manage Plugins** में, **Installed Plugins** सूची में plugin ढूँढें। दाईं ओर के switch पर टैप करें।

- **On** — plugin सक्रिय है।
- **Off** — plugin रोका गया है।

Plugin को बंद करना उसकी सुविधाओं को छिपा देता है। यह plugin को delete नहीं करता।

## Plugin कैसे हटाएँ

1. **सेटिंग्स** → **Plugins** → **Manage Plugins** खोलें।
2. **Installed Plugins** सूची में plugin ढूँढें।
3. **Uninstall** पर टैप करें।
4. पुष्टि करें।

## `.plugin.zip` file के अंदर क्या होता है?

एक `.plugin.zip` file एक ZIP archive है। इसमें ये होना चाहिए:

- `plugin.json` — plugin manifest।
- Manifest में घोषित नाम वाला plugin database।

इसमें ये भी हो सकते हैं:

- Manifest द्वारा referenced HTML या Markdown assets।

Manifest plugin `id`, `name`, `version` और यह घोषित करता है कि यह क्या provide करता है:

- `type`: `content`, `ui`, या `composite`।
- `content`: Bible, commentary, lexicon, book, या devotional content के लिए SQLite database और schema।
- `extensions`: `bottom-toolbar`, `home-screen`, `hamburger-menu`, verse actions, chapter toolbar buttons या event handlers जैसी surfaces।

## सावधानी का एक शब्द

Plugins दूसरे लोगों द्वारा, Theodia team द्वारा नहीं बनाए जाते। Install करने से पहले plugin का description पढ़ें। कुछ plugins को इंटरनेट की आवश्यकता हो सकती है या data collect कर सकते हैं।

## Plugins विकसित करना

यदि आप Theodia source repository के अंदर plugins बनाना या संपादित करना चाहते हैं, तो [Plugins विकसित करना](theodia://help/plugin-development) गाइड देखें। यह समझाता है कि `npm run package-plugins` के साथ plugins कैसे package करें और `npm run import-plugin-dev` के साथ editing के लिए वापस कैसे import करें।

## Plugin से संबंधित सहायता कहाँ मिलेगी?

प्रत्येक plugin का **Manage Plugins** में अपना page होता है। पहले वहाँ देखें। यदि अभी भी कोई प्रश्न है, तो [सहायता कहाँ माँगें](theodia://help/getting-more-help) गाइड देखें।
