---
title: प्रार्थना लक्ष्य
level: everyday
categories: [prayer]
summary: व्यक्तिगत प्रार्थना आदतों और लक्ष्यों को ट्रैक करें।
---

# प्रार्थना लक्ष्य

> **मोड:** Prayer Goals **मानक** और **विद्वान** मोड में उपलब्ध हैं। फोकस मोड अतिरिक्त उपकरणों को छिपाकर बिना व्यवधान के पढ़ने के लिए होता है। मोड बदलने के लिए **सेटिंग्स** → **ऐप उपयोगकर्ता मोड** में जाएँ।

Prayer Goals आपको उन आदतों को ट्रैक करने देते हैं जिनकी आप परवाह करते हैं — हर सुबह एक fixed prayer पढ़ना, दिन में तीन prayer routines पूरी करना, सोने से पहले journal लिखना, दस मिनट शांति में बिताना, या आपकी चुनी हुई कोई भी अन्य pattern। Theodia पहले से ही आपकी प्रार्थना गतिविधि record करता है, इसलिए एक goal बस उस गतिविधि को देखता है और आपको बताता है कि आप कैसे कर रहे हैं।

## एक goal क्या मापता है

जब आप एक goal बनाते हैं, तो आप चुनते हैं कि यह क्या गिनता है:

- **Routines** — कोई भी routine, कोई विशिष्ट routine, या कोई ऐसी routine जिसमें silence या lectio divina जैसा step type हो।
- **Journal entries** — अपनी prayer journal में लिखें।
- **Timer minutes** — prayer timer में समय बिताएँ।
- **Fixed prayers** — कोई fixed prayer या creed पढ़ें।
- **Guided sessions** — एक audio-guided prayer पूरी करें।
- **Manual check-in** — जब आपने प्रार्थना की हो तो स्वयं **Mark Done** पर टैप करें।

आप एक संख्यात्मक target और schedule भी सेट कर सकते हैं: दैनिक, साप्ताहिक, मासिक, सप्ताह के विशिष्ट दिन, या एक बार।

## Goal बनाना

1. **Prayer** टैब पर जाएँ।
2. **Goals** पर टैप करें (या यदि आप पहले से Goals row देखते हैं तो **+** बटन पर टैप करें)।
3. Goal builder खोलने के लिए floating **+** बटन पर टैप करें।
4. तेज़ी से शुरू करने के लिए कोई template चुनें, या **Start from Scratch** चुनें।
5. विवरण भरें: नाम, आइकन, रंग, target, schedule और reminder समय।
6. **Save Goal** पर टैप करें।

आपके द्वारा बनाया गया पहला goal Prayer home screen पर स्वचालित रूप से pinned हो जाता है।

## Goal को home screen पर pin करना

Pinned goals Prayer tab के शीर्ष पर **Active Goal** card और Statistics के नीचे **Prayer Goals** row में दिखाई देते हैं। किसी goal को pin या unpin करने के लिए:

1. Goal list खोलें।
2. वांछित goal ढूँढें।
3. Goal पर टैप करें, फिर **Pin to Home** पर टैप करें। Unpin करने के लिए फिर से टैप करें।

आप अधिकतम दो goals pin कर सकते हैं। केवल active goals ही pin किए जा सकते हैं।

## Goal को done के रूप में mark करना

यदि कोई goal **Manual check-in** पर सेट है, तो Theodia स्वचालित रूप से नहीं जान सकता कि आपने कब प्रार्थना की। इसके बजाय, आप स्वयं इसे mark करते हैं:

1. Goal detail screen खोलें।
2. **Mark Done Today** पर टैप करें।
3. वैकल्पिक रूप से एक छोटा note जोड़ें, फिर **Mark Done** पर फिर से टैप करें।

Active Goal card पर overflow menu खोलकर **Mark Done** पर टैप करके भी आप ऐसा कर सकते हैं।

## अपनी progress पढ़ना

किसी भी goal पर टैप करके उसका detail screen खोलें। आप देखेंगे:

- **Today’s progress** — अभी target से आप कितने करीब हैं।
- **Streaks** — current streak और longest streak।
- **Success rate** — scheduled days के completion का प्रतिशत।
- **Mini calendar** — हरे दिन completed हैं, outlined day आज है।
- **Recent history** — पिछले दो हफ्तों की progress।

### Goal actions

Detail screen से आप:

- Home से **Pin** या **Unpin** कर सकते हैं।
- Tracking रोकने के लिए **Pause** (streaks freeze)।
- फिर से शुरू करने के लिए **Resume**।
- Target, schedule, reminder या style बदलने के लिए **Edit**।
- Goal और उसके इतिहास को हटाने के लिए **Delete**।

## Insights

**Insights** स्क्रीन आपके सभी goals में trends दिखाती है:

- आज, इस सप्ताह और इस महीने met goals।
- Current longest streak।
- साप्ताहिक और मासिक completion rates।
- औसत प्रार्थना समय (timer goals से)।
- सबसे consistent goal।
- Goal types का distribution।

Prayer Goals list पर overflow menu से Insights खोलें।

## Keyboard shortcuts

यदि आप external keyboard का उपयोग करते हैं:

- **Escape** — वापस जाएँ।
- **Cmd + S** (iOS) या **Ctrl + S** (Android) — builder में goal save करें।
- **Cmd + E** (iOS) या **Ctrl + E** (Android) — goal detail या insights screen से summary क्लिपबोर्ड पर copy करें।

## Reminders और grace days

एक goal चुने गए दिनों पर चुने गए समय पर आपको याद दिला सकता है। Reminders आपके डिवाइस की local notifications का उपयोग करते हैं और **सेटिंग्स** → **सूचनाएँ** में master notification setting का सम्मान करते हैं।

**Grace days** तब streak की रक्षा करते हैं जब आप कोई दिन miss करते हैं। यदि आप grace days को 1 या 2 पर सेट करते हैं, तो लगातार उतने scheduled days miss करने तक आपकी streak नहीं टूटती।

## सुझाव

- एक goal से शुरू करें। जब आप ध्यान केंद्रित करते हैं तो आदत बनाना आसान होता है।
- सामान्य patterns के लिए templates का उपयोग करें, फिर target या schedule अनुकूलित करें।
- यात्रा या बीमारी के दौरान goal को pause करें, delete करें नहीं — आपकी streaks freeze हो जाती हैं और वापसी पर resume हो जाती हैं।
- Manual check-in goals उन चीज़ों के लिए काम करते हैं जिन्हें Theodia स्वचालित रूप से नहीं मापता, जैसे किसी विशिष्ट व्यक्ति या परिवार के लिए प्रार्थना करना।
- हर सप्ताह Insights जाँचें ताकि यह देख सकें कि कौन से goals सबसे आसान हैं और किन पर ध्यान देने की आवश्यकता है।
