---
title: प्रार्थना अवलोकन
level: beginner
categories: prayer
summary: Prayer tab और उसके मुख्य भागों का संक्षिप्त परिचय।
---

# प्रार्थना अवलोकन

**Prayer** tab प्रार्थना के लिए एक समर्पित स्थान है। यह lists, guided sessions, journal, timer, lectionary reading schedules और classical fixed prayers को एक साथ लाता है।

## मुख्य भाग

- **Prayer List** — उन लोगों, परिस्थितियों और विषयों का ट्रैक रखें जिनके लिए आप प्रार्थना कर रहे हैं।
- **Journal** — समय के साथ प्रतिबिंब, उत्तर और विचार लिखें।
- **Generate Prayer** — Theophilus से किसी request या journal entry से प्रार्थना लिखने के लिए कहें।
- **Creeds & Fixed Prayers** — ईसरी परंपरा से classical prayers और creeds।
- **Lectionary** — दैनिक या मौसमी प्रार्थना के लिए scripture reading schedules।
- **Guided Prayer** — text-to-speech के साथ audio-guided prayer sessions।
- **Timer** — वैकल्पिक घंटियों के साथ timed prayer sessions।
