---
title: प्रार्थना Statistics और Streaks
level: everyday
categories: prayer
summary: Prayer streaks कैसे काम करते हैं और statistics और badges कैसे बंद करें।
---

# प्रार्थना Statistics और Streaks

Prayer tab पर **Statistics** स्क्रीन आपकी प्रार्थना गतिविधि और streaks को तब ट्रैक करती है जब **सेटिंग्स** → **Prayer** में **Prayer Statistics** सक्षम होता है। यह दैनिक प्रार्थना आदत को प्रोत्साहित करने के लिए डिज़ाइन किया गया है, बिना घुसपैठ किए।

## क्या गतिविधि के रूप में गिना जाता है

निम्नलिखित को प्रार्थना गतिविधि के रूप में recorded किया जाता है:

- पूरी की गई prayer **routines**
- पूरी की गई **guided sessions**
- पूरी की गई **timer sessions**
- **Prayed** prayer requests
- पढ़ी गई **fixed prayers**
- पढ़े गए **lectionary** entries
- **Journal entries** जोड़े जाना

ये सभी आपकी गतिविधि सारांश में दिखाई देते हैं।

## केवल routines ही आपकी streak बढ़ाती हैं

आपकी **prayer streak** लगातार दिनों की संख्या है जिनमें आपने कम से कम एक prayer routine पूरी की है।

- कोई routine पूरी करने से streak बढ़ती है।
- अन्य प्रार्थना गतिविधि tracked है, लेकिन यह स्वयं streak नहीं बढ़ाती।
- यदि आप कोई दिन miss करते हैं, तो streak शून्य पर reset हो जाती है।
- एक दिन में एक से अधिक routine पूरी करना अभी भी एक streak day के रूप में गिना जाता है।

> **सुझाव:** यदि आप streak बनाना या बनाए रखना चाहते हैं, तो अपने दैनिक प्रार्थना समय के केंद्र में routines बनाएँ।

## Statistics screen क्या दिखाती है

- **Current streak** — पूरी की गई routine वाले लगातार दिन।
- **Longest streak** — आपका सर्वकालिक best run।
- **Activity summary** — इस सप्ताह, इस महीने और सभी समय के totals।
- **Calendar** — प्रार्थना गतिविधि वाले दिनों का month-by-month दृश्य।

## Badges

जब **Show Prayer Badges** सक्षम होता है, तो आप प्रार्थना milestones के लिए hidden achievements अर्जित कर सकते हैं। Badges एक हल्की Easter-egg feature है, कोई आवश्यकता नहीं।

Badges के लिए Prayer Statistics सक्षम होना आवश्यक है। यदि statistics बंद हैं, तो badges भी छिपे होते हैं।

## Statistics और badges कैसे अक्षम करें

आप इन सुविधाओं को किसी भी समय बंद कर सकते हैं:

1. **सेटिंग्स** → **Prayer** खोलें।
2. **Enable Prayer Statistics** बंद करें।
3. **Show Prayer Badges** बंद करें।

जब statistics अक्षम होते हैं:

- Streaks अब नहीं गिने जाते।
- Prayer tab से Statistics अनुभाग गायब हो जाता है।
- Badges छिपे होते हैं।
- मौजूदा प्रार्थना डेटा आपके डिवाइस पर बना रहता है; कुछ भी हटाया नहीं जाता।

Statistics बाद में फिर से सक्षम करने के लिए, बस toggle वापस चालू करें।
