---
title: GitHub पर संसाधन खोजना
level: everyday
categories: resources
summary: ऐप की जानी हुई हर GitHub repo में एक साथ खोजें, फिर जो मिले उसे इंस्टॉल करें।
---

# GitHub पर संसाधन खोजना

Theodia उन GitHub repos की एक सूची रखता है जहाँ संसाधन publish होते हैं — Bibles, commentaries, books, भक्तिपूर्ण पाठ, playlists, prayer packages, और बहुत कुछ। **Search GitHub Repos** इन सबमें एक साथ खोजता है, इसलिए आपको हर टैब अलग-अलग खोलकर देखना नहीं पड़ता।

> Settings का GitHub अनुभाग केवल **विद्वान** मोड में उपलब्ध है। उसे चालू करने के लिए **सेटिंग्स → ऐप उपयोगकर्ता मोड → विद्वान** में जाएँ।

## कैसे खोजें

1. **सेटिंग्स** खोलें।
2. **Search GitHub Repos** पर टैप करें।
3. Search box में एक शब्द टाइप करें। ऐप हर repo के हर package के **name** और **description** में वह शब्द ढूँढता है।

खोज के बारे में कुछ बातें जान लें:

- **हर शब्द का match होना ज़रूरी है।** `morning evening` खोजने पर केवल वही packages मिलते हैं जिनके name या description में *दोनों* शब्द हों।
- **Case मायने नहीं रखता।** `Morning` और `morning` एक ही packages देते हैं।
- **सबसे अच्छा match पहले आता है।** जिस package का name आपकी search से *शुरू* होता है वह उस package से पहले दिखाया जाता है जो उसे केवल description में बताता है।

## Filtering

सूची को और छोटा करने के लिए results के ऊपर filter bar पर टैप करें। दो filters हैं, और वे साथ काम करते हैं:

- **Author** — केवल उस author के packages।
- **Tradition** — केवल उस tradition के packages।

Filter को फिर से टैप करके हटाएँ, या दोनों reset करने के लिए **Clear filters** टैप करें।

## Result से इंस्टॉल करना

हर result दिखाता है package का नाम, वह किस तरह का संसाधन है, उसे किसने बनाया, और वह किस repo से आता है। Row के दाएँ एक बटन होता है:

- **Install** — package अभी आपके डिवाइस पर नहीं है।
- **Update** — नया version उपलब्ध है। ऐप पहले confirm करने को कहता है, क्योंकि update पुरानी copy को उस पर point करने वाले notes, highlights, या bookmarks के साथ हटा देता है।
- **Open** — package पहले से इंस्टॉल है; टैप करने पर आप उस स्क्रीन पर पहुँच जाते हैं जहाँ उसका उपयोग होता है।

ताज़ा सूची GitHub से तुरंत लाने के लिए ऊपर **Refresh** टैप करें। ऐप दिन में एक बार सूची अपने आप refresh कर देता है, इसलिए manual refresh केवल तब ज़रूरी है जब आप जानते हों कि कुछ नया publish हुआ है।

## बिना connection के खोज

ऐप सूची की एक copy आपके डिवाइस पर रखता है, इसलिए offline रहने पर भी खोज काम करती है। यदि ऐप सूची refresh करने के लिए GitHub तक नहीं पहुँच पाता, तो ऊपर एक banner बताता है कि आप cached results देख रहे हैं।

## यदि खोज कुछ न दे

- छोटा, एक ही शब्द आज़माएँ।
- जाँचें कि कोई **Author** या **Tradition** filter लागू तो नहीं रह गया — जब कोई लागू होता है तब **Clear filters** बटन दिखाई देता है।
- कुछ repos अपने packages को package के नाम से अलग भाषा में publish करते हैं, इसलिए अनुवादित शब्द से खोजने पर वे मिल नहीं सकते।
