---
title: टैबलेट सुविधाएँ
level: everyday
categories: [layout, tablet]
summary: Theodia का लेआउट टैबलेट और बड़ी स्क्रीनों पर split views, side panels और two-pane reading modes के साथ कैसे ढलता है।
---

# 📱 टैबलेट सुविधाएँ

Theodia टैबलेट पर बड़ी स्क्रीनों के फायदे उठाने के लिए डिज़ाइन किया गया है। टैबलेट (या लगभग 700 पिक्सेल से चौड़े किसी भी डिवाइस) पर, ऐप कई जगहों पर स्वचालित रूप से दो-कॉलम लेआउट में स्विच कर जाता है।

> **मोड:** यहाँ वर्णित सुविधाएँ केवल तभी दिखाई देती हैं जब आपका वर्तमान उपयोगकर्ता मोड उन्हें समर्थन करता हो। उदाहरण के लिए, commentary side panels और AI chat केवल विद्वान मोड में उपलब्ध हैं। Bookmarks, highlights और notes split views के लिए मानक या विद्वान मोड आवश्यक हैं। फोकस मोड केवल साफ़, single-column पढ़ने को दिखाता है। मोड बदलने के लिए **सेटिंग्स** → **ऐप उपयोगकर्ता मोड** में जाएँ।

## Reader verse मेनू

जब आप किसी वचन संख्या पर टैप करते हैं (या verse text को देर तक दबाते हैं), तो **verse मेनू** एक dark backdrop के ऊपर एक **centered card** के रूप में दिखाई देता है।

- मेनू के शीर्ष पर **Copy** और **Share** बटन हमेशा दिखाई देते हैं।
- **Bookmarks** और **Highlights** अपनी वर्तमान स्थिति के साथ दिखाए जाते हैं।
- **Commentary**, **Dictionary** और **Compare** मेनू से खुलते हैं। टैबलेट पर ये उपकरण चुनने के बाद एक side panel या wide card में दिखाई दे सकते हैं।
- मेनू को dismiss करने के लिए backdrop या close arrow पर टैप करें।

## Verse Commentary panel

**Commentary** उपकरण टैबलेट पर एक **dedicated side panel** खोलता है:

- Commentary text बाइबिल text के बगल में दिखाई देता है।
- आप बाइबिल से स्वतंत्र रूप से commentary scroll कर सकते हैं।
- बंद करने के लिए **X** पर टैप करें या swipe away करें।
- पैनल के शीर्ष पर एक **book icon** आपको commentary sources बदलने देता है।
- एक **chapter icon** chapter-level commentary देखने देता है।

फोन पर commentary एक full-screen modal के रूप में खुलता है।

## Chapter Commentary

**Chapter Commentary** स्क्रीन के शीर्ष पर **More** बटन से access किया जाता है, verse मेनू से नहीं। टैबलेट पर यह Verse Commentary की तरह ही एक side panel के रूप में खुलता है, इसलिए आप commentary और बाइबिल text को एक साथ पढ़ सकते हैं।

## Compare tab

**Compare** tab (verse मेनू में) टैबलेट पर एक **side panel** के रूप में खुलता है। यह आपके द्वारा सक्षम किए गए हर parallel version में चुने गए verse को दिखाता है। किसी भी version पर टैप करके reader में उस passage पर कूद सकते हैं।

## Dictionary / Strong's popup

**Dictionary** उपकरण (verse मेनू → Dictionary) टैबलेट पर एक wide card के रूप में खुलता है। यह Greek या Hebrew word, उसका transliteration, definition और Strong's number दिखाता है। शब्द के हर occurrence को बाइबिल में देखने के लिए **Concordance** बटन पर टैप करें।

## किसी शब्द पर टैप करके उसका Lexicon खोलना

टैबलेट पर **Word Info** side panel में, प्रत्येक word card जिसमें Strong's number हो, वह tappable होती है। Card पर टैप करके सीधे उस शब्द के लिए **Lexicon** panel खोलें। Lexicon panel Word Info panel को बदल देता है ताकि आप reader बंद किए बिना अध्ययन जारी रख सकें।

फोन पर, स्क्रीन छोटी होने के कारण Word Info cards tappable नहीं होतीं।

## Parallel Bibles side by side

सेटिंग्स में, **Parallel Bibles** पर टैप करें और अधिकतम तीन versions चुनें। टैबलेट पर, versions **vertical panes** के रूप में एक-दूसरे के बगल में दिखाई देते हैं:

- प्रत्येक pane स्वतंत्र रूप से scroll करता है।
- आप किसी verse number पर टैप करके tools के साथ एक side panel खोल सकते हैं।
- **Compare** tab सभी चुने गए verses को एक ही जगह दिखाता है।
- किसी pane पर **X** पर टैप करके उसे बंद करें और single-column view पर वापस जाएँ।
- सेटिंग्स खोले बिना parallel view चालू या बंद करने के लिए शीर्ष icon bar में **Parallel Bibles** icon (🔵 / ⚪) पर टैप करें।

फोन पर, parallel versions एक के नीचे एक (vertically) दिखाए जाते हैं। वही toggle icon फोन पर भी काम करता है।

## Bookmarks और Highlights split view

टैबलेट पर, **Bookmarks** और **Highlights** tabs master-detail layout का उपयोग करते हैं:

- **बाईं ओर** — bookmarks या highlights की सूची।
- **दाईं ओर** — किसी आइटम पर टैप करने से verse या passage text के साथ एक preview pane खुलता है।

आप अपने सहेजे गए आइटम्स को skim कर सकते हैं और tab छोड़े बिना उन्हें preview कर सकते हैं। फोन पर, किसी आइटम पर टैप करने से reader screen पर नेविगेट होता है।

## Notes split view

टैबलेट पर **Notes** tab बाईं ओर आपकी notes सूची और दाईं ओर चयनित note दिखाता है। किसी note पर टैप करने से यह एक side panel में खुलता है ताकि आप सूची छोड़े बिना कई notes को क्रम में देख सकें। Note बनाना या संपादित करना भी एक side panel का उपयोग करता है।

## Search split view

टैबलेट पर, **Search** tab खोज form को बाईं ओर और जैसे ही आप खोज चलाते हैं, परिणामों को दाईं ओर दिखाता है। आप अपनी query को refine कर सकते हैं और स्क्रीन बदले बिना परिणामों को update होते देख सकते हैं। फोन पर, search results एक अलग screen पर खुलते हैं।

## Settings category sidebar

टैबलेट पर **Settings** screen बाईं ओर category list दिखाता है (AI, Appearance, Backup, Bibles, आदि)। किसी category पर टैप करने से उसके settings दाईं ओर सीधे खुल जाते हैं। केवल चयनित category ही expand होती है, इसलिए आपको पूरी settings सूची से scroll करने की आवश्यकता नहीं है।

## Bible navigation on tablets

**Bible List**, **Bible Books** और **Bible Chapters** screens टैबलेट पर single-column रहती हैं, लेकिन वे larger touch targets, wider grids और अधिक spacious padding का उपयोग करती हैं ताकि content पढ़ने और टैप करने में आसान हो। वे split-view layout का उपयोग नहीं करती हैं क्योंकि प्रत्येक step को अपनी सूची या grid स्पष्ट रूप से दिखाने के लिए पूरी चौड़ाई की आवश्यकता होती है।

## Landscape और portrait

टैबलेट को घुमाने से लेआउट स्वचालित रूप से adjust होता है। **Landscape** में, side panels को भरपूर जगह मिलती है। **Portrait** में, panels संकरी हो जाती हैं लेकिन फिर भी text के बगल में रहती हैं।

## Selected verse AI chat

**AI** chat verse मेनू side panel में खुलता है। यह एक conversation interface दिखाता है जहाँ आप चुने गए verse के बारे में प्रश्न पूछ सकते हैं। AI response panel में दिखाई देता है, और आप reader छोड़े बिना conversation जारी रख सकते हैं।

## AI screen में conversation sidebar

टैबलेट पर **AI** tab में conversation list एक persistent left sidebar के रूप में हमेशा दिखाई देती है। आप बिना कोई menu खोले chats के बीच स्विच कर सकते हैं। **New Chat** बटन भी हमेशा दिखाई देता है। फोन पर, conversation list एक popup drawer होती है।

## क्या वैसा ही रहता है

हर screen दो panes में विभाजित नहीं होती। निम्नलिखित screens टैबलेट पर single-column रहती हैं:

- **Bible List** — बाइबिल versions की सूची (पूरी चौड़ाई)
- **Bible Books** — पुस्तक grid और sections (पूरी चौड़ाई)
- **Bible Chapters** — अध्याय grid (पूरी चौड़ाई)
- **Settings** — individual settings pages (पूरी चौड़ाई)
- **Help** — सहायता articles (पूरी चौड़ाई)

## सारांश

टैबलेट पर आपको मिलता है:

- **Parallel Bibles** side-by-side vertical panes में
- **Commentary** persistent side panels में
- **Compare** और **Dictionary** wide cards में
- किसी भी Word Info card पर टैप करके **Lexicon**
- **Bookmarks, Highlights, Notes, Devotionals, Books, Settings** master-detail split views में
- **Search** inline results के साथ search form के बगल में
- **Landscape** और **portrait** दोनों समर्थित, स्वचालित layout changes के साथ

फोन पर, सब कुछ पारंपरिक single-column drill-down navigation का उपयोग करता है। ऐप launch पर screen width का पता लगाता है और स्वचालित रूप से सही लेआउट चुनता है।
