---
title: थीम और फ़ॉन्ट बदलना
level: everyday
categories: settings
summary: ऐप का रूप कैसे बदलें।
---

# थीम और फ़ॉन्ट बदलना

Theodia आपको ऐप का दिखना बदलने की अनुमति देता है। आप एक theme (light या dark) और font size चुन सकते हैं।

## Appearance settings कैसे खोलें

1. **सेटिंग्स** खोलें।
2. **Appearance** पर टैप करें।

## Theme कैसे बदलें

**Appearance** अनुभाग में, आपको दो theme buttons दिखाई देते हैं:

- **Default** — हल्का background गहरे text के साथ। दिन के समय के लिए अच्छा।
- **Dark** — गहरा background हल्के text के साथ। रात के समय के लिए अच्छा और बैटरी बचाता है।

लागू करने के लिए किसी theme पर टैप करें। परिवर्तन तुरंत होता है।

## Font size कैसे बदलें

**Appearance** अनुभाग में, size buttons में से एक पर टैप करें: **---**, **--**, **-**, **Normal**, **+**, **++**, **+++**। पाठ पूरे ऐप में छोटा या बड़ा हो जाता है। अपने लिए सबसे आसान size चुनें।

## सुझाव

- OLED screens वाले phones पर Dark theme बैटरी बचाता है।
- यदि text पढ़ने के लिए बहुत छोटा है, तो device में नहीं, ऐप में font size बढ़ाएँ। ऐप की setting अधिक fine-grained है।
- लंबे पढ़ने के लिए, dark theme और बड़े font को आज़माएँ।
- [Activate the desert theme](theodia://unlock-desert)
