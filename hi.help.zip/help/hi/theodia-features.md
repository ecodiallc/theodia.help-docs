---
title: Theodia की सुविधाएँ
level: beginner
categories: welcome
summary: Theodia को क्या खास बनाता है और यह बाइबिल अध्ययन में आपकी कैसे मदद करता है, इसका त्वरित अवलोकन।
---

# Theodia की सुविधाएँ

Theodia एक पूर्ण बाइबिल अध्ययन साथी बनने के लिए बनाया गया है। यहाँ वह है जो इसे विशिष्ट बनाता है।

## ऑफ़लाइन प्रथम

सब कुछ इंटरनेट के बिना काम करता है। बाइबिल, commentary, lexicon, पुस्तकें और भक्तिपूर्ण पाठ आपके डिवाइस पर संग्रहीत होते हैं। आप कहीं भी — हवाई जहाज़ में, दूरदराज के क्षेत्र में, या किसी भी बिना सिग्नल वाली जगह — पढ़, खोज और अध्ययन कर सकते हैं।

## गोपनीयता केंद्रित

आपका डेटा आपके साथ रहता है। Notes, highlights, bookmarks और reading history आपके डिवाइस पर स्थानीय रूप से संग्रहीत होते हैं। कोई account आवश्यक नहीं है, और कुछ भी server पर नहीं भेजा जाता जब तक आप वैकल्पिक AI सहायक का उपयोग करना न चुनें।

## टैबलेट समर्थन

Theodia phones और tablets दोनों के लिए डिज़ाइन किया गया है। बड़ी स्क्रीन पर, आपको पढ़ने के लिए अधिक जगह, parallel Bible views और extra room का फायदा उठाने वाला layout मिलता है।

## इंस्टॉल करने योग्य संसाधन

आप उसी तक सीमित नहीं हैं जो ऐप के साथ आता है। आप और Bible versions, commentaries, lexicons, पुस्तकें और भक्तिपूर्ण पाठ जोड़ सकते हैं। संसाधन प्रोजेक्ट के GitHub page से उपलब्ध हैं और सीधे ऐप में इंस्टॉल किए जा सकते हैं।

## AI सहायक

वैकल्पिक AI सहायक आपको verses समझने, context समझाने और प्रश्नों के उत्तर देने में मदद करता है। यह केवल तभी सक्रिय होता है जब आप इसे चालू करते हैं। डिफ़ॉल्ट रूप से यह आपके द्वारा कॉन्फ़िगर किए गए endpoint और API key के माध्यम से remote model से जुड़ता है। पहली बार AI का उपयोग करते समय, ऐप आपकी अनुमति माँगता है और यह स्पष्ट रूप से दिखाता है क्या भेजा जा रहा है।

## Parallel Bible Reading

एक साथ अधिकतम चार Bible versions पढ़ें। जब आप कोई अध्याय खोलते हैं, तो आपका मुख्य अनुवाद पहले दिखाई देता है, और प्रत्येक verse के बाद आपके चुने गए parallel translations में वही verse होता है। wording की तुलना करें, अंतर का अध्ययन करें और text का fuller picture प्राप्त करें। अपने पसंदीदा combinations को presets के रूप में सहेजें और उनके बीच तेज़ी से स्विच करें।

## Full-Text Search

किसी भी Bible version में खोजें। शब्द, वाक्यांश या partial matches खोजें। आप खोज को किताबों की एक range तक सीमित भी कर सकते हैं।

## क्रॉस-संदर्भ

किसी verse reference पर टैप करके सीधे उस passage पर कूदें। क्रॉस-संदर्भ पूरे बाइबिल में built in हैं और काम करते हैं।

## Lexicon और Strong’s Numbers

Strong’s number पर टैप करके मूल Greek या Hebrew definition देखें। Lexicon entries गहरे word study के लिए शामिल हैं।

## Bookmarks और Highlights

Bookmarks के साथ verses सहेजें और उन्हें रंगों से चिह्नित करें। सब कुछ स्थानीय रूप से संग्रहीत होता है और sessions के बीच बना रहता है।

## Notes

किसी भी verse के बगल में अपने विचार लिखें। Notes verse से बंधे होते हैं और बाद में ढूँढना आसान होता है।

## Daily Devotional

एक छोटे भक्तिपूर्ण पाठ के साथ अपने दिन की शुरुआत करें। ऐप में devotionals शामिल हैं जो स्वचालित रूप से आज की entry खोलते हैं।

## ईसाई पुस्तकें

ऐप के अंदर classical ईसाई literature पढ़ें। पुस्तकें आसान पढ़ने के लिए formatted हैं और quick navigation के लिए table of contents शामिल करती हैं।

## PDF पढ़ना

अपने PDF documents इंपोर्ट करें और उन्हें offline, categories में व्यवस्थित करके पढ़ें। Reader में search, table of contents, bookmarks, zoom और ज़ोर से पढ़ना उपलब्ध है। आप community repository से packaged PDF collections भी इंस्टॉल कर सकते हैं।

## Multiple Languages

Theodia ऐप interface और बाइबिल content दोनों के लिए कई भाषाओं का समर्थन करता है। अपनी पसंदीदा भाषा में अध्ययन करने के लिए settings में भाषा बदलें।

## Dark Mode और Themes

Light या dark mode चुनें, या अपनी पसंद के अनुसार कोई theme चुनें। कम रोशनी में reading comfort मायने रखता है।

## Data Backup

अपने notes, bookmarks और highlights का बैकअप लें। अपने डेटा को सुरक्षित रखें और जरूरत पड़ने पर नए डिवाइस पर ले जाएँ।

## कोई विज्ञापन नहीं, कोई व्यवधान नहीं

Theodia focus के लिए बनाया गया है। कोई विज्ञापन नहीं, कोई pop-ups नहीं, कोई बाधाएँ नहीं। बस text और आपके अध्ययन उपकरण।
