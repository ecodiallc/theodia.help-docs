---
title: Theoscripts
level: everyday
categories: theoscript
summary: सरल Theoscript commands के साथ बाइबिल पढ़ना, speech, bookmarks और अधिक को automate करें।
---

# Theoscripts

**Theoscripts** छोटे scripts हैं जो Theodia के अंदर चीज़ों को automate करते हैं। एक script किसी passage को बोल सकता है, कोई अध्याय खोल सकता है, bookmark set कर सकता है, message दिखा सकता है, दूसरी command चला सकता है, और अधिक। वे व्यक्तिगत shortcuts या छोटे भक्तिपूर्ण helpers बनाने का एक तेज़ तरीका हैं, ऐप छोड़े बिना।

## Theoscripts कहाँ रहते हैं

होम स्क्रीन या मुख्य मेनू से **Theoscripts** खोलें। स्क्रीन केवल तभी दिखाई देती है जब कम से कम एक Theoscript मौजूद हो।

लाइब्रेरी दिखाती है:

- **Scripts** — आपके द्वारा बनाए या import किए गए हर script।
- **Categories** — संबंधित scripts को समूहीकृत करने वाले वैकल्पिक folders।

किसी script को चलाने के लिए टैप करें। संपादित करने, duplicate करने या हटाने के लिए किसी script को देर तक दबाएँ।

## नया script बनाना

1. **Theoscripts** पर जाएँ।
2. **+ Add Script** पर टैप करें।
3. Script को एक नाम दें।
4. **Script content** फ़ील्ड में commands टाइप करें।
5. **Save** पर टैप करें।

प्रत्येक command अपनी पंक्ति पर जाती है। Block के अंदर की पंक्तियों को दो spaces से indent करें।

## सामान्य commands

| Command                | What it does                           | Example                                       |
| ---------------------- | -------------------------------------- | --------------------------------------------- |
| `speak`                | text या passage को ज़ोर से पढ़ता है     | `speak "Good morning"` या `speak John 3:16`   |
| `open`, `read`, `show` | Reader में कोई passage खोलता है        | `open Psalm 23`                               |
| `bookmark`             | वर्तमान passage को bookmarks में सहेजता है | `bookmark`                                    |
| `highlight`            | वर्तमान verse को हाइलाइट करता है        | `highlight yellow`                            |
| `message`              | एक popup message दिखाता है             | `message "Done reading"`                      |
| `set`                  | कोई setting या value बदलता है           | `set theme dark`                              |
| `return`               | Script को जल्दी रोकता है                | `return`                                      |
| `with playlist`        | playlist में tracks जोड़ता है          | `with playlist "Morning" track John 3:16 end` |
| `start playlist`       | playlist चलाता है                      | `start playlist "Morning"                    |
| `with note`            | एक note बनाता है                       | `with note "John 3:16" "My thoughts" end`     |

## Flow control

केवल तभी commands चलाने के लिए `if` का उपयोग करें जब कोई शर्त true हो:

```text
if chapter == 1 {
  message "Starting a new book!"
}
```

commands के block को दोहराने के लिए `repeat` का उपयोग करें:

```text
repeat 3 {
  speak "Peace be with you"
}
```

किसी सूची से loop के लिए `for` का उपयोग करें:

```text
for $ref in ["John 3:16", "Psalm 23:1", "Romans 8:28"] {
  open $ref
  speak $ref
}
```

code blocks को पुनः उपयोग करने के लिए `function` और `call` का उपयोग करें:

```text
function greet $name {
  message "Hello, " + $name
}
call greet "friend"
```

## Variables

`let` के साथ किसी value को variable में संग्रहीत करें:

```text
let $name = "Theophilus"
message "Welcome, " + $name
```

दाईं ओर के literal strings को single या double quotes में लपेटना चाहिए। यह किसी literal value को command या variable name से भ्रमित होने से बचाता है। Numbers, variables और command expressions को quotes की आवश्यकता नहीं होती:

```text
let $count = 42
let $text = $last.passageText
let $words = count words in $text
let $greeting = "Hello, " + $name
```

Variables loops, functions और playlist definitions के अंदर उपयोगी होते हैं।

## उदाहरण scripts

### Greeting और एक verse

```text
speak "Good morning. Here is your verse for today."
open John 3:16
speak John 3:16
```

### तीन पसंदीदा verses बुकमार्क करना

```text
open John 3:16
bookmark
open Psalm 23:1
bookmark
open Romans 8:28
bookmark
message "Favorites saved."
```

### एक spoken playlist बनाना

```text
with playlist "Commute" {
  track John 3:16
  track Psalm 23
  track Romans 8:28
}
start playlist "Commute"
```

### Conditional message

```text
open Genesis 1:1
if book == "Genesis" {
  message "In the beginning..."
}
```

## Scripts व्यवस्थित करना

Categories बनाने के लिए **Manage Categories** पर टैप करें। जब आप किसी script को संपादित करते हैं, तो वह category चुनें जिसमें आप इसे रखना चाहते हैं। Categories व्यक्तिगत, example और speech scripts को अलग रखने में मदद करती हैं।

## निर्यात और आयात

Theoscript library के अंदर मेनू पर टैप करके:

- **Export Theoscripts** — सभी scripts को एक फ़ाइल में सहेजें।
- **Export This Category** — केवल चयनित category सहेजें।
- **Import Theoscripts** — पहले निर्यात की गई फ़ाइल लोड करें।

निर्यात की गई फ़ाइलें plain text होती हैं और अन्य Theodia उपयोगकर्ताओं के साथ साझा की जा सकती हैं।

## Commands से scripts चलाना

Theoscripts को **Launcher Menu** से नाम से चलाया जा सकता है या Commands में उन्हें माँगकर। उदाहरण के लिए, `run My Morning Script` कहने या टाइप करने से _My Morning Script_ नाम का script ढूँढा और चलाया जाएगा यदि वह मौजूद हो।

## समस्या निवारण

- **Run पर टैप करने पर कुछ नहीं होता।** सुनिश्चित करें कि script content खाली नहीं है और प्रत्येक command सही तरीके से spelled है।
- **Speak कुछ नहीं पढ़ता।** सुनिश्चित करें कि कोई passage खुला है, या `speak` को सीधे quotes में text pass करें।
- **कोई command error के साथ हाइलाइट किया गया है।** Theoscripts तब errors दिखाते हैं जब कोई command unknown हो या कोई reference invalid हो। Script संपादित करें और फिर से प्रयास करें।
