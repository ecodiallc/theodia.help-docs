---
title: ज़ोर से पढ़ना (Text-to-Speech)
level: everyday
categories: tts
summary: Theodia को बाइबिल या भक्तिपूर्ण पाठ ज़ोर से पढ़वाएँ। इसका उपयोग, आवाज़ चुनना और जब यह चुप हो तो क्या करें।
---

# ज़ोर से पढ़ना (Text-to-Speech)

> **मोड:** Text-to-speech **मानक** और **विद्वान** मोड में उपलब्ध है। फोकस मोड केवल साफ़, बिना व्यवधान के पढ़ने के लिए है। मोड बदलने के लिए **सेटिंग्स** → **ऐप उपयोगकर्ता मोड** में जाएँ।

Theodia आपके डिवाइस की text-to-speech (TTS) आवाज़ का उपयोग करके text को ज़ोर से पढ़ सकता है। आप एक verse, पूरा अध्याय या एक भक्तिपूर्ण पाठ सुन सकते हैं। यह hands-free पढ़ने, चलते या commute करते समय सुनने, audio के साथ पढ़ने के अनुसरण करने या बस आंखों को आराम देने के लिए उपयोगी है।

## Listen button कहाँ है

आप Listen button तीन जगहों पर पाएँगे।

### 1. Verse मेनू में (single verse)

एक समय में एक verse सुनने का सबसे तेज़ तरीका यह है। [अध्ययन मोड](theodia://help/study-mode) में कोई अध्याय खोलें, verse menu खोलने के लिए किसी verse पर टैप करें, फिर **Speak** (🔊) पर टैप करें। Reading उस verse से शुरू होती है। स्क्रीन के नीचे play, pause, rewind, fast-forward और voice picker के साथ एक छोटा control bar दिखाई देता है।

Speak विकल्प interlinear Bibles (MIB — Marvel Interlinear Bible — और OHGB) के लिए नहीं दिखाया जाता, क्योंकि वे शब्दों को एक अलग layout में प्रदर्शित करते हैं जो प्राकृतिक रूप से नहीं पढ़ता।

### 2. अध्याय के शीर्ष पर (पूरा अध्याय)

जब आप कोई अध्याय पढ़ रहे हों, तो स्क्रीन के शीर्ष पर icons की पंक्ति देखें। पूरा अध्याय शुरू से पढ़ने के लिए **Listen** (🔊) पर टैप करें। जब audio चल रहा हो तो यह button stop button (⏹) में बदल जाता है। रोकने के लिए फिर से टैप करें। वही control bar नीचे दिखाई देता है।

आप किसी अलग verse पर कूद सकते हैं, और वहाँ का Listen button उस verse से शुरू करेगा।

### 3. भक्तिपूर्ण पाठ में

कोई भी भक्तिपूर्ण दिन खोलें, फिर पढ़ने के शीर्ष पर **Listen** (🔊) बटन पर टैप करें। पूरा भक्तिपूर्ण text वाक्य-दर-वाक्य ज़ोर से पढ़ा जाता है। नीचे का control bar आपको play, pause, rewind और voice controls देता है।

## Control bar का उपयोग

जब audio चल रहा हो, तो स्क्रीन के नीचे एक छोटी पट्टी दिखाई देती है। इसमें छह नियंत्रण होते हैं:

- ⏪ **Rewind** — एक verse पीछे जाएँ (या भक्तिपूर्ण पाठ में एक वाक्य)
- ⏸ **Pause / ▶ Resume** — बिना अपनी जगह खोए रोकें। फिर से टैप करें ताकि उसी स्थान से जारी रखें।
- ⏩ **Fast forward** — अगले verse पर जाएँ (या भक्तिपूर्ण पाठ में अगले वाक्य पर)
- 🎙 **Voice** — chapter छोड़े बिना voice picker खोलें (नीचे देखें)
- ⚙ **Options** — extended options panel खोलें (नीचे देखें)
- **Stop** — स्क्रीन के शीर्ष पर 🔊 button पर टैप करें, या audio चलते समय इसके स्थान पर आने वाले ⏹ पर, पट्टी बंद करने के लिए।

Control bar अध्याय समाप्त होने पर या stop पर टैप करने पर बंद हो जाता है।

### Extended options

अतिरिक्त playback options के लिए ⚙ पर टैप करें। ये settings केवल वर्तमान अध्याय के लिए रहती हैं और chapter स्विच करने या सुनना बंद करने पर reset हो जाती हैं।

- ⏮ **Back to begin** — उस range के पहले verse पर कूदें जो आपने सेट की है।
- **Begin** — पढ़ना कहाँ से शुरू हो, यह verse number टाइप करें।
- **End** — पढ़ना कहाँ रुके, यह verse number टाइप करें।
- **All** — range को पूरे अध्याय पर reset करें।
- **()** — parenthetical text (कोष्ठकों के अंदर का text) को ज़ोर से पढ़ा जाए या नहीं, टॉगल करें।
- 🔁 **Repeat** — अंत पर पहुँचने पर स्वचालित रूप से range की शुरुआत में फिर से शुरू करें, बीच में थोड़ी रुकावट के साथ। यदि आप इसे चालू करते हैं बिना begin या end verse सेट किए, तो पूरा अध्याय repeat होता है।

## आवाज़ कैसे बदलें

आप चुन सकते हैं कि Theodia पढ़ने के लिए कौन सी आवाज़ का उपयोग करे। यह उपयोगी है यदि आप एक अलग accent, एक अलग भाषा, या device default से तेज़ या धीमी आवाज़ चाहते हैं।

1. **सेटिंग्स** खोलें।
2. **Speech** अनुभाग ढूँढें।
3. **Select Voice** पर टैप करें।
4. आवाज़ों की सूची दिखाई देती है। पहली पंक्ति, **System Default**, आपके डिवाइस द्वारा पसंद की गई आवाज़ का उपयोग करती है। कोई अन्य पंक्ति चुनें ताकि यह नया default बन जाए।
5. आपकी पसंद सहेजी जाती है और अगली बार जब आप **Listen** या **Speak** पर टैप करते हैं तो उपयोग की जाती है।

आप सुनते समय control bar में 🎙 icon पर टैप करके भी उसी picker को chapter छोड़े बिना खोल सकते हैं।

आवाज़ की उपलब्धता पूरी तरह आपके डिवाइस पर निर्भर करती है। iOS और Android दोनों built-in voices का एक सेट लेकर आते हैं। आप अपने डिवाइस की **Accessibility** या **Language & Input** settings से और voices install कर सकते हैं। Theodia आपके डिवाइस पर install की गई कोई भी आवाज़ उपयोग कर सकता है।

## पसंदीदा आवाजें

यदि आपके डिवाइस में कई आवाज़ें हैं, तो हर बार पूरी सूची से scroll करना धीमा हो सकता है। आप **favorite voices** की एक छोटी सूची बना सकते हैं और voice pickers केवल उन्हीं आवाज़ों को दिखाएँगे।

1. **सेटिंग्स** खोलें।
2. **Speech** अनुभाग ढूँढें।
3. **Favorite Voices** पर टैप करें (अनुभाग के शीर्ष पर पहली पंक्ति)।
4. **Set Favorite Voices** पर टैप करके favorites screen खोलें।
5. किसी आवाज़ के बगल में play button पर टैप करके उसे preview करें। उसे अपने favorites में जोड़ने के लिए star पर टैप करें। आप जितनी चाहें उतनी voices favorite कर सकते हैं।
6. वापस जाएँ। Theodia भर के voice pickers अब केवल आपकी पसंदीदा आवाज़ें दिखाएँगे।

यदि आप सभी favorites हटा देते हैं, तो pickers फिर से हर आवाज़ दिखाना शुरू कर देते हैं। Favorite voices Theodia settings के बैकअप और पुनर्स्थापना में शामिल होती हैं।

## प्रति Bible एक अलग आवाज़ सेट करना

आप प्रत्येक Bible translation को अपनी आवाज़ दे सकते हैं। यह उपयोगी है जब आप ऐसे translations के बीच स्विच करते हैं जो बहुत अलग पढ़ते हैं — उदाहरण के लिए, King James Version के लिए अधिक formal आवाज़ और NIV या NLT जैसे modern translation के लिए अधिक conversational आवाज़। यह तब भी मदद करता है जब आप विभिन्न भाषाओं में Bibles सुनते हैं और चाहते हैं कि प्रत्येक सही accent में बोला जाए।

1. **सेटिंग्स** खोलें।
2. **Speech** अनुभाग ढूँढें।
3. **Bible Voices** खोजें।
4. सूची में किसी भी Bible पर टैप करें।
5. उस translation के लिए वांछित आवाज़ चुनें। पहली पंक्ति, **System Default**, उस Bible के लिए आपकी मुख्य TTS आवाज़ का उपयोग करती है।
6. किसी अन्य Bible के लिए दोहराएँ।

Header दिखाता है कि कितनी Bible translations के पास custom voice सेट है। जब कोई voice सेट होती है, तो **Select Voice**, **Commentary Voice**, **Bible Notes Voice** और **Devotional Voice** भी एक count दिखाते हैं।

अगली बार जब आप उस Bible से कोई अध्याय सुनते हैं, तो Theodia आपके द्वारा चुनी गई आवाज़ का उपयोग करेगा। अन्य Bibles मुख्य default आवाज़ का उपयोग करना जारी रखेंगे जब तक आप उन्हें भी न बदलें।

## Background में speech जारी रखना

डिफ़ॉल्ट रूप से, Theodia तब speech रोक देता है जब आप reader screen छोड़ते हैं, दूसरे ऐप पर स्विच करते हैं, या अपना phone lock करते हैं। यह रोकता है कि जब आप अब सक्रिय रूप से नहीं पढ़ रहे हों तो अप्रत्याशित audio न चले।

Background में प्ले जारी रखने के लिए:

1. **सेटिंग्स** खोलें।
2. **Speech** अनुभाग ढूँढें।
3. **Continue speech in background** चालू करें।

जब यह चालू हो, तो आप tabs स्विच कर सकते हैं, दूसरा ऐप खोल सकते हैं, या screen lock कर सकते हैं और अध्याय या भक्तिपूर्ण पाठ पढ़ता रहेगा। Control bar सक्रिय रहता है ताकि आप notification area से pause या skip कर सकें (यदि आपका डिवाइस इसका समर्थन करता है)।

यदि speech पहले से चल रहा हो तो इस toggle को **off** करने से यह तुरंत रुक जाएगा।

## यदि यह काम न करे तो क्या करें

Text-to-speech आपके डिवाइस पर निर्भर करता है। Theodia text को operating system को भेजता है, और operating system आवाज़ का उपयोग करके इसे ज़ोर से पढ़ता है। यदि यह काम नहीं कर रहा है, तो क्रम में ये steps आज़माएँ।

### Theodia कहता है TTS उपलब्ध नहीं है

कुछ devices और web build में TTS बिल्कुल नहीं होता। **सेटिंग्स** खोलें और **TTS** अनुभाग देखें। यदि अनुभाग वहाँ नहीं है, तो आपका डिवाइस इस build में TTS का समर्थन नहीं करता।

### आवाज़ सूची खाली है

Voice picker "no voices found" दिखा सकता है। इसका आम तौर पर अर्थ है कि device अभी तक अपनी voices load नहीं कर पाया है।

1. **सेटिंग्स → Speech → Select Voice** खोलें।
2. यदि सूची खाली है, तो dropdown के ठीक नीचे **Retest** बटन देखें। उस पर टैप करें। Theodia device से voices को फिर से पूछता है।
3. यदि अभी भी खाली है, तो अपने डिवाइस की system settings जाँचें। iOS पर, **सेटिंग्स → Accessibility → Spoken Content → Voices** पर जाएँ और अपनी भाषा के लिए एक voice download करें। Android पर, **सेटिंग्स → Language & Input → Text-to-Speech Output** पर जाएँ और **Install voice data** पर टैप करें।
4. Theodia को नई आवाज़ उठाने के लिए close और reopen करें।

यदि आपने favorite voices सेट की हैं और सूची खाली है, तो सुनिश्चित करें कि आपके favorites में से कम से कम एक इस डिवाइस पर install की गई आवाज़ से मेल खाता है।

### Speak पर टैप करें लेकिन कुछ न हो

- सुनिश्चित करें कि डिवाइस silent mode में न हो। अधिकांश devices silent mode में TTS audio नहीं चलाते।
- सुनिश्चित करें कि डिवाइस का volume ऊपर हो।
- **सेटिंग्स → Speech** में **Retest** बटन आज़माएँ।
- **सेटिंग्स** खोलें और नीचे **System** अनुभाग देखें। **TTS** पंक्ति को **Available** कहना चाहिए। यदि यह **Unavailable** कहती है, तो TTS operating-system level पर बंद है। उसे वहाँ फिर से सक्षम करें, फिर Theodia reopen करें।

### Audio चलता है लेकिन गलत भाषा में

Theodia वर्तमान content की भाषा में text भेजता है और आपके द्वारा चुनी गई आवाज़ माँगता है। यदि चयनित आवाज़ किसी अलग भाषा के लिए है, तो device फिर भी text पढ़ सकता है, लेकिन यह अजीब लगेगा।

1. **सेटिंग्स → Speech → Select Voice** खोलें।
2. सही आवाज़ चुनने के लिए **System Default** चुनें, या जो आवाज़ आप जो text पढ़ रहे हैं उसकी भाषा से मेल खाती हो।

Theodia वर्तमान में Greek या Hebrew interlinear Bibles को ज़ोर से नहीं पढ़ता। उन translations पर Speak और Listen buttons छिपे होते हैं।

### Audio चलता है लेकिन जल्दी रुक जाता है

यदि कोई verse गायब या unreadable है, तो अध्याय अगले verse पर skip कर जाता है। यदि पट्टी कुछ verses के बाद अपने आप बंद हो जाती है, तो फिर से शुरू करने के लिए स्क्रीन के शीर्ष पर **Listen** (🔊) बटन पर टैप करें।

### Speech चल रहा है लेकिन मुझे नहीं पता कि यह कहाँ से शुरू हुआ

यदि आपने **Continue speech in background** चालू किया है और बाद में audio सुनते हैं लेकिन screen नहीं ढूँढ पा रहे हैं जिसने इसे शुरू किया, तो आप ऐप में कहीं से भी इसे रोक सकते हैं।

1. **सेटिंग्स** खोलें।
2. **Speech** अनुभाग ढूँढें।
3. अनुभाग के नीचे लाल **Stop Speech** बटन पर टैप करें।

यह Theodia में कोई भी चल रहा text-to-speech तुरंत रोक देता है। आप अपने डिवाइस पर app switcher खोलकर और Theodia को swipe away करके भी audio force-stop कर सकते हैं।

### बहुत तेज़ या बहुत धीमा पढ़ता है

Theodia पढ़ने की गति नियंत्रित नहीं करता। गति चुनी गई आवाज़ द्वारा निर्धारित होती है। इसे बदलने के लिए:

- iOS पर: **सेटिंग्स → Accessibility → Spoken Content → Speaking Rate**।
- Android पर: **सेटिंग्स → Language & Input → Text-to-Speech Output → Speech Rate**।

## सुझाव

- Control bar अध्यायों के बीच navigate करते समय दिखाई देता रहता है, इसलिए आप अपनी जगह खोए बिना pause, skip या voice बदल सकते हैं।
- Theodia verse numbers को छोटी रुकावटों के रूप में पढ़ता है। आप पट्टी रोक सकते हैं, किसी अलग verse पर swipe कर सकते हैं, फिर वहाँ से जारी रखने के लिए play पर टैप कर सकते हैं।
- लंबे listen-throughs के लिए, **Do Not Disturb** चालू करें ताकि notifications audio को बीच में न रोकें।
- 🔊 button आपके डिवाइस के वर्तमान volume का उपयोग करता है। यदि आप headphones plug in करते हैं, तो volume headphone level पर स्विच हो जाता है।

## संबंधित गाइड

- [अध्ययन मोड](theodia://help/study-mode) गाइड verse menu और स्क्रीन के शीर्ष के buttons के बारे में और विस्तार से बताती है।
- [फोकस मोड](theodia://help/focus-mode) गाइड एक cleaner reading view है जो नीचे के बार में 🔊 button के माध्यम से TTS का भी समर्थन करता है।
- [सामान्य समस्याएँ](theodia://help/common-problems) गाइड में अन्य audio, voice और भाषा issues के लिए fixes हैं।
- [दैनिक भक्तिपूर्ण पाठ](theodia://help/daily-devotionals) गाइड devotional reading और उस screen पर Listen button कहाँ है, इसे कवर करती है।
