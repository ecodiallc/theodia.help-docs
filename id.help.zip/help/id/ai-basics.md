---
title: Dasar-Dasar AI
level: advanced
categories: ai
summary: Cara memakai pembantu AI untuk memahami ayat-ayat.
---

# Dasar-Dasar AI

> **Mode:** Asisten AI membutuhkan mode **Pelajar**. Anda bisa mengganti mode di **Pengaturan** → **Mode Pengguna Aplikasi**.

Theodia memiliki asisten AI. Asisten bisa membantu Anda memahami sebuah ayat, menjawab sebuah pertanyaan, atau membahas sebuah topik Alkitab.

## Cara menyalakan AI

AI dimatikan secara bawaan. Untuk menyalakannya:

1. Buka **Pengaturan**.
2. Ketuk **Asisten AI**.
3. Ketuk sakelarnya untuk menyalakannya.

## Cara membuka AI

Ketuk tab **AI** di bagian bawah layar. Sebuah jendela obrolan terbuka.

## Cara mengajukan pertanyaan

Ketuk kotak di bagian bawah. Ketik pertanyaan Anda. Ketuk **Kirim**.

Beberapa hal yang bisa Anda tanyakan:

- "Apa arti Yohanes 3:16?"
- "Ceritakan tentang kitab Roma."
- "Apa itu buah Roh?"
- "Bandingkan Khotbah di Bukit dalam Matius dan Lukas."

## Cara bertanya tentang sebuah ayat tertentu

1. Buka sebuah pasal.
2. Ketuk sebuah ayat untuk memunculkan menu ayat.
3. Ketuk **Komentar AI**.

Ayat itu dikirim ke AI. Panel AI terbuka dengan ayat yang telah terisi. Anda bisa menambahkan sebuah pertanyaan, seperti "Apa arti ini?" atau "Bagaimana saya harus menerapkannya?"

## Hal-hal penting yang perlu diketahui

- AI adalah sebuah alat, bukan seorang pribadi. AI bisa melakukan kesalahan.
- Selalu periksa jawaban AI terhadap Alkitab itu sendiri.
- AI mungkin membutuhkan internet. AI tidak bekerja luring.
- Saat Anda memakai AI, pertanyaan Anda, konteks ayat, dan kunci API dikirim ke titik akhir yang Anda pilih. Pertama kali Anda melakukan ini, aplikasi meminta izin Anda dan menunjukkan persis apa yang dikirim. Anda bisa mengubah atau mencabut izin itu nanti di **Pengaturan → Asisten AI → Berbagi Data AI Jarak Jauh**.
- Beberapa wilayah, seperti build App Store daratan Tiongkok, tidak menawarkan asisten AI. Di build itu hanya fitur Alkitab luring yang tersedia.

## Cara mengelola percakapan

Layar AI menyimpan daftar percokapan lampau. Dari daftar itu Anda bisa membuka percakapan lama, memulai yang baru, atau menghapus yang tidak lagi Anda perlukan.

## Menyelam lebih dalam dengan AI

Halaman ini membahas dasar-dasarnya. AI Theodia bisa melakukan jauh lebih dari sekadar obrolan. Berikut langkah selanjutnya:

- **[Fitur AI](theodia://help/ai-features)** — Temukan semua yang bisa dilakukan Theophilus: studi ayat satu ketukan dalam bahasa Yunani dan Ibrani, rangkaian referensi silang, kerangka khotbah, pembuatan doa, morfologi bahasa asli, pencarian kamus, dan navigasi aplikasi tanpa tangan. Ini panduan yang menunjukkan cara mengubah AI dari chatbot menjadi mitra studi penuh.
- **[Menulis Prompt AI yang Lebih Baik](theodia://help/ai-prompts)** — Pelajari seni mengajukan pertanyaan yang mendapat jawaban kaya dan akurat. Beberapa penyesuaian kecil pada cara Anda merumuskan permintaan bisa membuka jawaban yang jauh lebih mendalam dari AI.
- **[Memilih Model AI](theodia://help/choosing-a-model)** — Tidak semua model AI sama. Cari tahu model mana yang mendukung alat bawaan Theodia (seperti membuka ayat dan mencari Kitab Suci) dan model mana yang mengubah AI menjadi asisten studi Alkitab tanpa tangan yang sesungguhnya.
- **[GitHub Models](theodia://help/github-models)** — Penyedia gratis yang direkomendasikan untuk Theodia. Dapatkan kunci API gratis dengan akun GitHub dan mulai bertanya dengan kuota harian yang besar. Tanpa kartu kredit, tanpa langganan.
- **[Kunci API dan Biaya](theodia://help/ai-keys-and-costs)** — Pahami cara kerja harga API di berbagai penyedia dan cara menjaga biaya mendekati nol.
