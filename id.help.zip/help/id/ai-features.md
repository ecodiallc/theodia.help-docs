---
title: Fitur AI
categories: ai
level: advanced
summary: Temukan semua yang bisa dilakukan AI Theodia — dari studi ayat demi ayat hingga persiapan khotbah, penjelajahan bahasa asli, dan navigasi tanpa tangan.
---

# Fitur AI

> **Mode:** Asisten AI membutuhkan mode **Pelajar**. Anda bisa mengganti mode di **Pengaturan** → **Mode Pengguna Aplikasi**.

Asisten AI Theodia, Theophilus, bukan sekadar chatbot. Ini adalah mitra studi yang bisa membaca Alkitab bersama Anda, mencari komentar, menelusuri Kitab Suci, mengelola catatan Anda, dan bahkan menavigasi aplikasi — semuanya lewat suara atau teks.

Sebelum Theophilus mengirim data ke sebuah titik akhir AI untuk pertama kalinya, aplikasi menampilkan dialog persetujuan yang menjelaskan apa yang dikirim dan meminta izin Anda. Anda bisa mengubah atau mencabut izin itu kapan saja di **Pengaturan → Asisten AI → Berbagi Data AI Jarak Jauh**.

## Obrolan Ayat AI: Mempelajari Satu Ayat Secara Mendalam

**Obrolan Ayat AI** adalah inti pengalaman AI Theodia. Saat Anda membaca pasal mana pun, ketuk sebuah nomor ayat (atau tekan lama teks ayat) dan pilih **Komentar AI**. Sebuah panel obrolan terbuka dengan ayat itu sudah termuat. AI tahu persis apa yang sedang Anda baca dan siap menjelajahinya bersama Anda.

### Pemicu satu ketukan

Bingung mau bertanya apa? Panel menampilkan delapan pemicu instan:

- **Jelaskan ayat ini** — Dapatkan penjabaran makna dan pentingnya yang jelas dan bijak.
- **Bahasa asli** — Lihat kata-kata Yunani atau Ibrani, transliterasinya, dan definisi leksikalnya di balik teks Inggris.
- **Konteks sejarah** — Pelajari budaya, politik, dan peristiwa yang mengelilingi ayat itu.
- **Konteks teks** — Lihat bagaimana ayat itu berada dalam paragraf, pasal, dan kitab di sekitarnya.
- **Tema utama** — Temukan gagasan-gagasan besar yang disumbangkan ayat ini bagi teologi Alkitab.
- **Terapkan dalam hidup saya** — Dapatkan penerapan praktis dan personal yang bisa Anda lakukan hari ini.
- **Buat sebuah doa** — Ubah ayat itu menjadi sebuah doa yang meneladan bahasa dan kebenarannya.
- **Buat kerangka khotbah** — Dapatkan kerangka tiga poin dengan pengantar dan penutup, siap dikhotbahkan.

Ketuk pemicu mana pun dan AI langsung mulai bekerja. Anda bisa melanjutkan dengan pertanyaan sendiri, meminta klarifikasi, atau mengarahkan percakapan ke arah baru.

### Melanjutkan seperti percakapan sungguhan

AI mengingat beberapa pesan terakhir dalam obrolan, sehingga Anda bisa mendalami secara alami:

- "Bisakah kamu mengatakannya dengan lebih sederhana?"
- "Apa kata Yunani aslinya di sini?"
- "Tunjukkan referensi silang yang terhubung dengan ini."
- "Bandingkan ayat ini dalam tiga terjemahan yang berbeda."
- "Bagaimana wujudnya di tempat kerja modern?"
- "Beri saya tiga penerapan lagi untuk seorang orang tua."

Percakapan tetap melekat pada ayat itu, sehingga setiap jawaban berpijak pada teks yang sedang Anda baca.

### Ketuk referensi Alkitab mana pun

Saat AI menyebut ayat lain — misalnya, "Ini sejalan dengan Roma 8:28" — referensinya muncul sebagai **tautan yang bisa diketuk**. Ketuk itu dan aplikasi melompat ke bagian tersebut di pembaca Alkitab. Anda bisa menjelajahi rangkaian referensi tanpa pernah meninggalkan percakapan.

## Apa yang Bisa Dilakukan AI di Luper Obrolan Ayat

Theophilus memiliki akses ke seluruh isi Theodia — Alkitab, komentar, leksikon, kamus, buku, renungan, catatan Anda, penanda, dan sorotan. Berikut artinya dalam praktik.

### Membaca dan menavigasi Kitab Suci

- **Baca ayat atau pasal mana pun** — "Baca Yohanes 3:16 dalam WEB" atau "Bacakan Mazmur 23."
- **Buka bagian di pembaca** — "Bawa saya ke Kejadian 1" atau "Buka Roma 8:28."
- **Bandingkan versi** — "Tunjukkan Yohanes 3:16 di semua Alkitab saya."
- **Cari di Alkitab** — "Temukan ayat-ayat tentang pengampunan" atau "Cari 'damai yang melampaui akal'."
- **Dapatkan referensi silang** — "Ayat apa lagi yang berkaitan dengan Yesaya 53:5?"
- **Baca judul bagian** — "Apa saja subjudul dalam Matius 5?"

### Menjelajah bahasa asli

- **Pencarian leksikon** — "Apa arti kata Yunani 'agape' dalam Yohanes 3:16?" atau "Cari Strong's G26."
- **Morfologi** — "Analisis kata kerja Yunani dalam Roma 8:28" atau "Apa arti kode morfologi V-PAI-3S?"
- **Info Kata** — AI bisa melihat rincian kata demi kata yang sama dengan yang Anda lihat di aplikasi — transliterasi, padanan makna, tata bahasa, dan angka Strong.

### Membaca komentar dan buku studi

- **Komentar ayat** — "Apa kata Matthew Henry tentang Efesus 2:8?"
- **Komentar pasal** — "Beri saya ikhtisar pasal untuk Roma 8."
- **Komentar kitab** — "Ringkas komentar level kitab tentang Wahyu."
- **Buku studi** — "Bacakan sebuah pasal dari Hymn Lyrics English" atau "Cari di buku-buku saya kata 'kesabaran'."
- **Renungan** — "Baca renungan hari ini" atau "Temukan renungan tentang kecemasan."

### Mencari di kamus

- "Siapakah Melkisedek?"
- "Apa kata kamus Alkitab tentang Gilgal?"
- "Cari 'propitiation' di Easton's."

### Mengelola kehidupan studi Anda

AI dapat bertindak atas data pribadi Anda — semuanya selalu tersimpan lokal di perangkat Anda:

- **Penanda** — "Tandai ayat ini di folder Persiapan Khotbah saya" atau "Daftar penanda saya."
- **Sorotan** — "Sorot Yohanes 3:16 dengan warna kuning" atau "Tunjukkan semua sorotan saya."
- **Catatan** — "Buat catatan Alkitab pada ayat ini" atau "Baca catatan saya untuk Kejadian 1."
- **Catatan studi** — "Simpan percakapan ini sebagai catatan studi" atau "Buat buku catatan studi baru bernama Studi Roma."
- **Folder** — "Buat folder bernama Renungan Pagi" atau "Pindahkan penanda Yohanes 3:16 saya ke folder Doa."

### Mengubah setelan aplikasi

- "Beralih ke mode gelap."
- "Jadikan BSB Alkitab bawaan saya."
- "Nyalakan Alkitab paralel dengan NET."
- "Perbesar ukuran hurufnya."

### Membacakan dengan suara

- "Bacakan Mazmur 23" — AI bisa memicu teks-ke-suara untuk bagian, buku, atau catatan mana pun.
- "Berhenti membaca" — Jeda TTS kapan saja.

## Menyimpan Percakapan Anda

Setiap obrolan ayat AI bisa disimpan. Ketuk menu di panel obrolan dan pilih:

- **Simpan sebagai Catatan Alkitab** — Menambahkan seluruh percakapan ke catatan ayat di pembaca Alkitab.
- **Simpan sebagai Catatan Studi** — Menyimpan percakapan itu di buku Catatan Studi Anda untuk rujukan nanti.

Ini mengubah penjelajahan AI yang singkat menjadi bahan studi permanen yang bisa Anda buka lagi, sunting, atau jadikan dasar khotbah.

## Tab AI yang Penuh

Di luar panel obrolan ayat, Theodia memiliki tab **AI** tersendiri di navigasi bawah. Ini adalah obrolan bebas tempat Anda bisa menanyakan apa saja — tanpa ayat yang sudah dipilih. Gunakan untuk:

- Studi tematik di seluruh Alkitab
- Riset dan penyusunan kerangka khotbah
- Membandingkan tema teologis antarkitab
- Renungan harian dan pemicu doa
- Kuis Alkitab dan rencana baca
- Bantuan aplikasi — "Bagaimana cara kerja Alkitab paralel?"

Percakapan Anda tersimpan secara otomatis. Anda bisa kembali ke obrolan lampau, memulai yang baru, dan menghapus utas lama.

## Ide untuk Memulai

Berikut beberapa cara menarik memakai AI. Pilih satu dan coba hari ini.

**Pertumbuhan Pribadi**

- "Jelaskan Filipi 4:6–7 dan beri saya doa untuk saat saya merasa cemas."
- "Apa kata Alkitab tentang istirahat? Temukan lima ayat dan jelaskan masing-masing."

**Keluarga dan Pengasuhan**

- "Bagaimana Efesus 6:4 seharusnya membimbing pengasuhan modern? Beri saya tiga aturan praktis."
- "Temukan ayat-ayat tentang membesarkan anak dan bacakan untuk saya."

**Persiapan Khotbah dan Pengajaran**

- "Susun kerangka khotbah 25 menit tentang Roma 8:28 dengan pengantar, tiga poin, dan penutup."
- "Apa kata komentar-komentar saya tentang 'perlengkapan senjata Allah' dalam Efesus 6?"
- "Bandingkan Khotbah di Bukit dalam Matius dengan versi Lukas. Apa perbedaannya?"

**Studi Bahasa Asli**

- "Tunjukkan morfologi setiap kata dalam Yohanes 1:1."
- "Apa perbedaan antara 'agape' dan 'philia' dalam Perjanjian Baru?"

**Kedalaman Renungan**

- "Baca renungan hari ini dan hubungkan dengan sebuah ayat di Mazmur."
- "Beri saya kerangka renungan tujuh hari tentang buah Roh."

**Rangkaian Referensi Silang**

- "Mulailah dari Yesaya 53:5 dan telusuri tema 'luka' dan 'kesembuhan' di sepanjang Perjanjian Baru."
- "Di mana konsep 'perjanjian' muncul dari Kejadian hingga Ibrani?"

**Menghafal dan Mengulang**

- "Kuis saya tentang kitab-kitab Alkitab secara berurutan."
- "Buat catatan studi yang merangkum poin utama setiap pasal dalam Roma."

## Beberapa Catatan Penting

- AI adalah sebuah **alat**, bukan pengganti Alkitab atau bimbingan pastoral. Selalu bandingkan jawabannya dengan Kitab Suci itu sendiri.
- Saat Anda memakai AI, pertanyaan Anda menempuh perjalanan lewat internet ke server penyedia. Sebagian besar penyedia tidak melatih model dengan data Anda, tetapi teksnya memang meninggalkan perangkat Anda.
- AI bisa melakukan kesalahan. Gunakan komentar, leksikon, dan teks Alkitab itu sendiri sebagai otoritas akhir Anda.

## Ringkasan

AI Theodia dirancang untuk membuat studi Alkitab lebih cepat, lebih mendalam, dan lebih personal. Baik Anda menginginkan penjelasan satu kalimat atas sebuah ayat yang membingungkan, kerangka khotbah yang lengkap, studi kata Yunani, atau rangkaian referensi silang yang membentang di seluruh Alkitab, Theophilus siap membantu. Ketuk sebuah ayat, ajukan sebuah pertanyaan, dan lihat ke mana percakapan itu mengarah.
