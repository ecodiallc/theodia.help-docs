---
title: Kunci API dan Biaya
level: advanced
categories: ai
summary: Mengapa Anda membutuhkan kunci API, cara mendapatkannya, dan berapa biasanya biaya memakai model AI jarak jauh.
---

# Kunci API dan Biaya

> **Mode:** Asisten AI membutuhkan mode **Pelajar**. Anda bisa mengganti mode di **Pengaturan** → **Mode Pengguna Aplikasi**.

Asisten AI terhubung ke model-model AI jarak jauh. Jika Anda ingin memakai satu, Anda membutuhkan sebuah kunci API. Halaman ini menjelaskan mengapa, cara mendapatkannya, dan biasanya berapa biayanya.

## Mengapa Anda membutuhkan kunci API

Sebuah model AI jarak jauh berada di sebuah server di internet. Kunci API itu seperti kata sandi yang memberi tahu server, "Orang ini diizinkan bertanya." Tanpa itu, server tidak akan menjawab.

Aplikasi tidak menyediakan kunci bawaan. Anda harus membuat akun sendiri dengan sebuah penyedia dan menempelkan kunci Anda ke aplikasi.

## Cara mendapatkan kunci API

1. Buka **Pengaturan** di Theodia.
2. Ketuk **Asisten AI**.
3. Pilih **Model jarak jauh**.
4. Pilih penyedia dari daftar, atau pilih **Khusus** dan masukkan URL dasar.
5. Ketuk tautan ke halaman kunci penyedia. Buat akun jika Anda belum memilikinya.
6. Buat kunci API baru di situs penyedia.
7. Salin kuncinya dan tempelkan ke Theodia.
8. Ketuk **Uji koneksi** untuk memastikannya bekerja.

## Penyedia yang didukung

Theodia bisa terhubung ke penyedia mana pun yang memakai API kompatibel OpenAI. Berikut yang memiliki tautan prasetel di aplikasi:

- **GitHub Models** — github.com/marketplace/models (kuota harian gratis, direkomendasikan)
- **OpenAI** — platform.openai.com
- **OpenRouter** — openrouter.ai
- **Anthropic** — console.anthropic.com
- **Groq** — console.groq.com
- **Mistral** — console.mistral.ai
- **Together AI** — api.together.xyz

Anda juga bisa memakai URL dasar **Khusus** jika Anda menjalankan server sendiri atau memakai layanan yang berbeda.

## Berapa biayanya?

Sebagian besar penyedia menagih per **token**. Token kira-kira berupa satu kata atau bagian dari sebuah kata. Anda membayar token yang Anda kirim (pertanyaan Anda) ditambah token yang dikirim balik oleh AI (jawabannya).

### Harga tipikal

Harga berubah, tetapi ini gambaran kasar per pertengahan 2026:

- **Model kecil yang cepat** (seperti titik akhir kelas GPT-3.5 yang lebih murah) berbiaya sepeoratusan sen per seribu token.
- **Model kelas menengah** (seperti GPT-4o atau Claude Sonnet) biasanya berbiaya beberapa sen per seribu token.
- **Model penalaran besar** (seperti GPT-4.5 atau Claude Opus) bisa berbiaya sepuluh sampai dua puluh sen per seribu token.

Sebuah pertanyaan Alkitab tipikal di Theodia mungkin memakai total beberapa ratus hingga beberapa ribu token. Artinya, sebagian besar pertanyaan berbiaya dari **di bawah satu sen sampai beberapa sen**.

### Tips menjaga biaya tetap rendah

- Mulailah dengan model yang lebih murah. Sebagian besar pertanyaan Alkitab tidak membutuhkan model termahal.
- Gunakan Groq atau OpenRouter jika Anda ingin mencoba model-model berbeda dan membandingkan harga.
- Pantau dasbor pemakaian Anda di situs penyedia.

## GitHub Models

[GitHub Models](https://github.com/marketplace/models) menawarkan kuota gratis tanpa langganan. Anda hanya butuh akun GitHub gratis dan personal access token dengan izin membaca model.

**Cara menyiapkannya:**

1. Pergi ke [github.com/settings/tokens](https://github.com/settings/tokens) dan buat **Personal access token (classic)**.
2. Beri token itu scope `models:read` (atau cukup pilih izin models).
3. Di Theodia, pilih **GitHub Models** sebagai penyedia dan tempelkan token Anda.

**Model kuota gratis:**

- `openai/gpt-4.1-nano` — **15 permintaan per menit, 150 permintaan per hari**
- `openai/gpt-4.1-mini` — **15 permintaan per menit, 150 permintaan per hari**
- `openai/gpt-4.1` — **10 permintaan per menit, 50 permintaan per hari**
- `openai/gpt-4o` — **10 permintaan per menit, 50 permintaan per hari**

Batas-batas ini diatur ulang setiap hari dan sangat cukup untuk studi Alkitab rutin.

Untuk penuntunan lengkap langkah demi langkah dengan tangkapan layar, lihat panduan [GitHub Models](theodia://help/github-models) tersendiri.

## Catatan privasi

Saat Anda memakai model AI jarak jauh, aplikasi terlebih dahulu menampilkan dialog persetujuan yang menjelaskan apa yang dikirim: pesan Anda, konteks ayat atau pasal, panggilan alat dan hasilnya, nama model yang dikonfigurasi, dan kunci API Anda di kepala permintaan. Permintaan berjalan langsung ke titik akhir yang Anda konfigurasi, bukan melalui Theodia. Sebagian besar penyedia tidak memakai data Anda untuk melatih model mereka, tetapi teksnya memang meninggalkan perangkat Anda. Anda bisa mengubah atau mencabut izin kapan saja di **Pengaturan → Asisten AI → Berbagi Data AI Jarak Jauh**.

## Ringkasan

- Anda membutuhkan kunci API untuk memakai asisten AI.
- Buat akun dengan sebuah penyedia, buat kuncinya, dan tempelkan ke Theodia.
- Sebagian besar pertanyaan berbiaya beberapa sen atau kurang.
