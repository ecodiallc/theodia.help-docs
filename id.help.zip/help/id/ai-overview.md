---
title: Asisten AI
level: advanced
category: ai
summary: Cara menggunakan pembantu AI untuk memahami ayat-ayat.
---

# Asisten AI

Theodia memiliki asisten AI. Asisten bisa membantu Anda memahami sebuah ayat, menjawab sebuah pertanyaan, atau membahas sebuah topik Alkitab.

## Cara menyalakan AI

AI dimatikan secara bawaan. Untuk menyalakannya:

1. Buka **Pengaturan**.
2. Ketuk **Asisten AI**.
3. Ketuk sakelarnya untuk menyalakannya.

Anda mungkin perlu menyiapkan sebuah akun atau kunci. Aplikasi akan memandu Anda.

## Cara membuka AI

Ketuk tab **AI** di bagian bawah layar. Sebuah jendela obrolan terbuka.

## Cara mengajukan pertanyaan

Ketuk kotak di bagian bawah. Ketik pertanyaan Anda. Ketuk **Kirim**.

Beberapa hal yang bisa Anda tanyakan:

- "Apa arti Yohanes 3:16?"
- "Ceritakan tentang kitab Roma."
- "Apa itu buah Roh?"
- "Bandingkan Khotbah di Bukit dalam Matius dan Lukas."

## Cara bertanya tentang sebuah ayat tertentu

1. Buka sebuah pasal.
2. Ketuk sebuah ayat untuk memunculkan menu ayat.
3. Ketuk **Komentar AI**.

Ayat itu dikirim ke AI. Panel AI terbuka dengan ayat yang telah terisi. Anda bisa menambahkan sebuah pertanyaan, seperti "Apa arti ini?" atau "Bagaimana saya harus menerapkannya?"

## Hal-hal penting yang perlu diketahui

- AI adalah sebuah alat, bukan seorang pribadi. AI bisa melakukan kesalahan.
- Selalu periksa jawaban AI terhadap Alkitab itu sendiri.
- AI mungkin membutuhkan internet. AI tidak bekerja luring.
- Saat Anda memakai AI, pertanyaan Anda, konteks ayat, dan kunci API dikirim ke titik akhir yang Anda pilih. Pertama kali Anda melakukan ini, aplikasi meminta izin Anda dan menunjukkan persis apa yang dikirim. Anda bisa mengubah atau mencabut izin itu nanti di **Pengaturan → Asisten AI → Berbagi Data AI Jarak Jauh**.
- Beberapa wilayah, seperti build App Store daratan Tiongkok, tidak menawarkan asisten AI. Di build itu hanya fitur Alkitab luring yang tersedia.

## Cara mengelola percakapan

Layar AI menyimpan daftar percakapan lampau. Dari daftar itu Anda bisa membuka percakapan lama, memulai yang baru, atau menghapus yang tidak lagi Anda perlukan.

Untuk tips yang lebih lanjut, lihat panduan [Menulis Prompt AI yang Lebih Baik](theodia://help/ai-prompts).
