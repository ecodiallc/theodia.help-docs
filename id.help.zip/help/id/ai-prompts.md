---
title: Menulis Prompt AI yang Lebih Baik
level: advanced
categories: ai
summary: Cara bertanya kepada asisten AI dengan cara yang mendapat jawaban bagus.
---

# Menulis Prompt AI yang Lebih Baik

> **Mode:** Asisten AI membutuhkan mode **Pelajar**. Anda bisa mengganti mode di **Pengaturan** → **Mode Pengguna Aplikasi**.

Sebuah "prompt" adalah pertanyaan atau instruksi yang Anda berikan kepada AI. Prompt yang lebih baik mendapat jawaban yang lebih baik. Panduan ini menunjukkan caranya.

## Jadilah spesifik

Buruk: "Ceritakan tentang kasih."
Lebih baik: "Dalam 1 Korintus 13, kasih macam apa yang digambarkan Paulus, dan apa bedanya dengan kasih romantis?"

Semakin banyak rincian yang Anda berikan, semakin berguna jawabannya.

## Berikan konteks

Buruk: "Apa arti ayat ini?"
Lebih baik: "Saya sedang membaca Roma 8 bersama kelompok kecil. Apa arti 'tanpa penghukuman' dalam pasal ini, dan bagaimana itu terhubung dengan bagian lain pasalnya?"

Konteks membantu AI menyesuaikan jawabannya dengan situasi Anda.

## Minta satu hal dalam satu waktu

Buruk: "Ceritakan tentang doa, iman, dan kesembuhan."
Lebih baik: "Ceritakan tentang doa lebih dulu. Setelah itu saya akan bertanya tentang iman."

Meminta satu hal dalam satu waktu menjaga jawaban tetap fokus.

## Minta AI memerankan sebuah peran

Anda bisa meminta AI menjawab dengan gaya tertentu. Misalnya:

- "Jawablah seolah kamu sedang mengajar seorang Kristen baru."
- "Jawablah sebagai seorang pakar Alkitab."
- "Jawablah untuk anak berusia 10 tahun."

AI menyesuaikan jawabannya dengan peran itu.

## Gunakan pertanyaan lanjutan

Jika jawaban pertama belum tepat, ajukan pertanyaan lanjutan:

- "Bisakah kamu mengatakannya dengan lebih sederhana?"
- "Bisakah kamu memberi saya contoh?"
- "Apa kata Yunani aslinya?"
- "Di bagian mana lagi dalam Alkitab hal ini muncul?"

Percakapan yang baik berlangsung bolak-balik. AI mengingat beberapa pesan terakhir.

## Periksa jawaban AI

AI bisa melakukan kesalahan. AI adalah sebuah alat, bukan seorang guru.

- Bandingkan jawaban AI dengan ayat-ayat yang ditunjukkannya.
- Gunakan komentar dan leksikon di aplikasi untuk pendapat kedua.
- Jika jawabannya menyangkut doktrin, tanyakan kepada pendeta atau teman tepercaya.

## Pola prompt yang umum

Berikut beberapa yang bekerja baik:

- "Jelaskan ayat ini kepadaku seolah aku seorang Kristen baru."
- "Apa poin utama pasal ini dalam satu kalimat?"
- "Buatkan daftar tiga penerapan untuk kehidupan sehari-hari saya dari bagian ini."
- "Pertanyaan apa yang sebaiknya saya ajukan tentang ayat ini sebelum mengkhotbahkannya?"
