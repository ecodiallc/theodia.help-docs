---
title: Mode Pengguna Aplikasi
level: beginner
categories: [user-mode]
summary: Pilih antara mode Pembaca, Standar, dan Pelajar untuk mengatur fitur mana saja yang tersedia di aplikasi.
---

# Mode Pengguna Aplikasi

Theodia menawarkan tiga mode pengguna yang mengatur fitur mana saja yang Anda lihat. Pilih yang cocok dengan cara Anda ingin memakai aplikasi.

## Pembaca

Mode yang paling sederhana. Mode Pembaca untuk membaca Alkitab tanpa gangguan.

- Membaca terjemahan Alkitab mana pun
- Memakai Mode Fokus untuk membaca bersih layar penuh
- Menavigasi kitab dan pasal
- Tanpa alat studi, tanpa AI, tanpa penanda, tanpa sorotan

Mode Pembaca ideal jika Anda ingin Theodia terasa seperti Alkitab digital yang bersih tanpa tambahan apa pun.

## Standar

Mode Standar menambahkan fitur sehari-hari untuk studi Alkitab pribadi.

Semua yang ada di Pembaca, ditambah:

- Penanda halaman, sorotan, dan catatan
- Teks-ke-suara
- Pembaca Mode Studi dengan menu ayat
- Alkitab paralel
- Masukan perintah
- Mencari di Alkitab
- Renungan harian dan buku bawaan

Mode Standar adalah pilihan yang tepat bagi kebanyakan pengguna yang ingin membaca, menandai, dan mencari di Alkitab tanpa alat studi tingkat lanjut.

## Pelajar

Mode dengan fitur lengkap. Mode Pelajar membuka setiap alat di Theodia untuk studi Alkitab yang mendalam.

Semua yang ada di Standar, ditambah:

- Komentar dan leksikon
- Referensi silang
- Kamus Alkitab
- Info Kata (pencarian angka Strong)
- Asisten AI dan Komentar AI
- Menu Peluncur

Mode Pelajar dirancang untuk pendeta, mahasiswa seminari, dan siapa pun yang menginginkan alat bahasa asli dan bantuan studi bertenaga AI.

## Cara mengganti mode

1. Buka **Pengaturan**.
2. Ketuk **Mode Pengguna Aplikasi**.
3. Pilih **Pembaca**, **Standar**, atau **Pelajar**.

Perubahan berlaku dengan segera. Menu dan tombol yang tidak bisa Anda akses di mode Anda saat ini disembunyikan.

## Memilih sebuah mode

- **Pembaca** — Anda hanya ingin membaca Alkitab, tidak yang lain.
- **Standar** — Anda ingin penanda, sorotan, catatan, pencarian, dan renungan.
- **Pelajar** — Anda ingin setiap alat studi, termasuk AI, komentar, dan leksikon.

Anda bisa mengganti mode kapan saja. Penanda, sorotan, dan catatan Anda tidak pernah dihapus saat Anda mengganti mode; semuanya hanya disembunyikan sampai Anda kembali ke mode yang mendukungnya.
