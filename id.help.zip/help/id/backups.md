---
title: Mencadangkan Data Anda
level: everyday
categories: settings
summary: Cara menyimpan dan memulihkan catatan, sorotan, penanda, dan rahasia Anda.
---

# Mencadangkan Data Anda

Catatan, sorotan, penanda, dan setelan Anda tersimpan di perangkat Anda. Jika Anda kehilangan ponsel, mendapat yang baru, atau menghapus aplikasi, data itu bisa hilang. Panduan ini menunjukkan cara mencadangkannya.

## Cara membuka setelan cadangan

1. Buka **Pengaturan**.
2. Ketuk **Cadangan Aplikasi**.

## Cara membuat cadangan aplikasi

1. Buka **Pengaturan**.
2. Ketuk **Cadangan Aplikasi**.
3. Ketuk **Buat Cadangan Aplikasi**.
4. Pilih folder di perangkat Anda untuk menyimpan berkasnya. Anda juga bisa memilih sebuah drive awan.
5. Aplikasi membuat satu berkas berisi semua data Anda. Berkasnya berekstensi `.zip`.

## Seberapa sering membuat cadangan

Buat cadangan:

- Setelah Anda menulis banyak catatan.
- Sebelum memperbarui sistem operasi perangkat Anda.
- Sebelum menghapus aplikasi atau mengganti ponsel.

Kebiasaan yang baik adalah satu cadangan sebulan. Ada orang yang mencadangkan setiap minggu.

## Cara memulihkan dari cadangan aplikasi

1. Buka **Pengaturan**.
2. Ketuk **Cadangan Aplikasi**.
3. Ketuk **Pulihkan dari Cadangan Aplikasi**.
4. Pilih berkas cadangan `.zip` itu.
5. Untuk setiap jenis data (catatan, sorotan, penanda, dan seterusnya), pilih apakah mempertahankan yang ada di perangkat, menggantinya dengan cadangan, atau melewatinya.
6. Ketuk **Pulihkan**.

Aplikasi mengganti data Anda dengan data dalam cadangan. Ini meliputi:

- Catatan
- Sorotan
- Penanda
- Folder penanda
- Setelan (tema, ukuran huruf, bahasa)

## Cadangan Rahasia

**Cadangan Aplikasi** Anda **tidak** menyertakan rahasia yang sensitif seperti kunci API AI atau token GitHub Anda. Untuk mencadangkannya secara terpisah, gunakan **Cadangan Rahasia**.

### Menyimpan cadangan rahasia

1. Buka **Pengaturan**.
2. Ketuk **Cadangan Aplikasi**.
3. Di bagian **Cadangan Rahasia**, ketuk **Simpan Cadangan Rahasia**.
4. Masukkan kata sandi yang kuat dan konfirmasikan.
5. Aplikasi mengenkripsi rahasia Anda dan membagikan berkas terenkripsinya. Simpan di tempat yang aman.

### Memulihkan cadangan rahasia

1. Buka **Pengaturan**.
2. Ketuk **Cadangan Aplikasi**.
3. Di bagian **Cadangan Rahasia**, ketuk **Pulihkan Cadangan Rahasia**.
4. Pilih berkas cadangan rahasia terenkripsinya.
5. Masukkan kata sandi yang sama dengan yang Anda pakai saat menyimpannya.
6. Rahasia Anda dipulihkan.

> **Penting:** Jika Anda lupa kata sandinya, rahasianya tidak bisa dipulihkan. Tidak ada pengaturan ulang.

## Hal-hal yang perlu diketahui

- Pemulihan **mengganti** kategori yang Anda pilih. Apa pun yang Anda tambahkan setelah cadangan akan hilang untuk kategori itu.
- Cadangan aplikasi berupa satu berkas `.zip`. Simpan di tempat yang aman.
- Anda bisa menyalin berkasnya, memindahkannya, atau menyimpannya di layanan awan mana pun.
- Cadangan aplikasi tidak menyertakan berkas terjemahan Alkitab itu sendiri. Berkas itu bisa diunduh lagi dari **Pengaturan** → **Kelola Sumber Daya**.
- Cadangan rahasia dienkripsi dengan kata sandi Anda. Pilih kata sandi yang akan Anda ingat.

## Tips

Jika Anda memiliki lebih dari satu perangkat, Anda bisa menyalin berkas cadangannya ke setiap perangkat dan memulihkannya. Data Anda akan sama di keduanya.
