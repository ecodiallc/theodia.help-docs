---
title: Menandai Ayat
level: everyday
categories: [annotate, read]
summary: Cara menyimpan ayat agar bisa ditemukan kembali.
---

# Menandai Ayat

> **Mode:** Penanda halaman tersedia di mode **Standar** dan **Pelajar**. Mode Fokus hanya untuk membaca yang bersih tanpa gangguan. Anda bisa mengganti mode di **Pengaturan** → **Mode Pengguna Aplikasi**.

Sebuah penanda halaman menyimpan sebuah ayat atau pasal sebuah buku agar bisa ditemukan lagi. Penanda halaman itu seperti pembatas buku.

## Cara menandai sebuah ayat

1. Buka ayatnya.
2. Ketuk ayat itu untuk memunculkan menu.
3. Ketuk **Penanda halaman** di menu. Ikon bintang menandai ayat sebagai tersimpan.

Tanda centang pada ikon berarti ayat kini telah ditandai.

## Cara menandai pasal sebuah buku

Saat membaca sebuah buku (bukan Alkitab), Anda bisa menandai seluruh pasalnya:

1. Buka pasalnya.
2. Ketuk ikon **Penanda halaman** di bagian atas layar.

## Cara melihat penanda halaman Anda

Ketuk tab **Penanda** di bagian bawah. Anda melihat daftar setiap ayat dan pasal buku yang telah Anda simpan.

## Cara menghapus penanda halaman

- **Satu ayat:** Buka ayatnya. Ketuk ayat itu, lalu ketuk ikon **Penanda halaman** lagi. Tanda centangnya hilang.
- **Dari daftar:** Di tab **Penanda**, tekan lama sebuah penanda. Menu kecil muncul. Ketuk **Hapus**. (Anda juga bisa mengetuk tombol × kecil pada barisnya.)

## Mengatur dengan folder

Anda bisa memasukkan penanda ke dalam folder. Misalnya, Anda mungkin punya folder bernama "Persiapan Khotbah" dan lainnya bernama "Penyejuk Lelang."

Cara membuat folder:

1. Buka tab **Penanda**.
2. Ketuk **Kelola Folder** di bagian atas.
3. Ketuk **+ Buat Folder** di bagian atas daftar folder.
4. Ketik sebuah nama dan ketuk **Simpan**.

Anda tidak bisa membuat dua folder dengan nama sama. Jika nama sudah ada, pesan kesalahan muncul di dalam kotak pembuatan folder agar Anda bisa mengubahnya dan mencoba lagi.

Cara memasukkan penanda ke folder:

1. Di tab **Penanda**, tekan lama sebuah penanda.
2. Ketuk **Simpan ke Folder**.
3. Pilih foldernya, lalu ketuk **Selesai**.

## Mengimpor penanda halaman

Anda bisa membawa penanda halaman ke Theodia dari aplikasi dan berkas lain.

Buka **Pengaturan** → **Penanda** → **Impor Penanda Halaman**. Pilih **Impor dari Berkas** atau tempel dari papan klip. Aplikasi mendeteksi formatnya secara otomatis.

### Format yang didukung

**Ekspor JSON bawaan** — Format yang digunakan fitur ekspor milik Theodia sendiri. Format ini mempertahankan folder dan tanggal pembuatan.

**HTML Bookmark Netscape** — Format yang digunakan Chrome, Firefox, dan Safari saat mengekspor penanda halaman. Folder dipertahankan.

**CSV** — Lembar sebar dengan kolom-kolom. Aplikasi mencari kolom `url` dan `folder` (atau `href` / `category`). Contoh:

```csv
url,folder
/bible/KJV/John/3,Favorites
/bible/KJV/Genesis/1,Sermon Prep
```

**Teks biasa** — Setiap baris berupa referensi Alkitab, URL aplikasi, atau arahan folder. Contoh:

```
folder: Favorites
John 3:16
Genesis 1:1
folder: Sermon Prep
Matthew 5:1
```

- Baris yang diawali `folder: <name>` menetapkan folder aktif untuk semua penanda berikutnya.
- Referensi Alkitab seperti `John 3:16` diubah menjadi penanda di Alkitab bawaan Anda.
- URL aplikasi seperti `/bible/KJV/John/3#v3_16` atau `/book/MyBook/1` diimpor langsung.
- Baris yang diawali `#` atau `//` diperlakukan sebagai komentar dan dilewati.

### Tips mengimpor

- Penanda yang ganda dilewati secara otomatis.
- URL eksternal (seperti tautan BibleGateway) diubah menjadi penanda aplikasi bila memungkinkan.
- Jika folder dari berkas impor sudah ada, penanda ditempatkan di folder yang sudah ada itu.

## Tips

- Anda bisa menandai ayat yang sama di banyak terjemahan. Semuanya tampil dalam daftar.
- Penanda halaman tetap ada di perangkat Anda. Penanda tidak tersinkron ke awan.
- Lihat panduan [Mencadangkan Data Anda](theodia://help/backups) untuk menjaganya tetap aman.

## Penanda di PDF

PDF memiliki penanda halaman sendiri, yang dipisahkan dari penanda Alkitab Anda. Saat membaca sebuah PDF, ketuk tombol **Penanda halaman** di bilah alat pembaca untuk menyimpan halaman saat ini, memberinya nama, dan kembali ke sana nanti. Setiap PDF menyimpan daftarnya sendiri — lihat [PDF](theodia://help/pdfs).
