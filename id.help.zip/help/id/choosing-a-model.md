---
title: Memilih Model AI
level: advanced
categories: ai
summary: Cara memilih model yang bekerja baik dengan alat dan kemampuan bawaan Theodia.
---

# Memilih Model AI

> **Mode:** Asisten AI membutuhkan mode **Pelajar**. Anda bisa mengganti mode di **Pengaturan** → **Mode Pengguna Aplikasi**.

Tidak semua model AI bekerja dengan cara yang sama di Theodia. Pengalaman terbaik datang dari sebuah model yang mendukung **tool calling** — kemampuan AI untuk memakai fitur-fitur bawaan Theodia seperti mencari ayat Alkitab, mencari (search), membaca komentar, dan menavigasi aplikasi.

## Apa itu tool calling?

Saat Anda bertanya kepada AI Theodia, AI bisa melakukan lebih dari sekadar berbicara. AI juga bisa **bertindak**. Misalnya:

- Anda berkata, "Tunjukkan Yohanes 3:16 dalam ESV." AI memanggil sebuah alat untuk membuka ayat itu di pembaca.
- Anda berkata, "Apa kata komentar-komentar saya tentang Roma 8:28?" AI memanggil sebuah alat untuk mengambil isi komentar.
- Anda berkata, "Simpan ayat ini sebagai penanda." AI memanggil sebuah alat untuk membuat penanda.

Model-model yang tidak mendukung tool calling hanya bisa memberi Anda jawaban berupa teks. Mereka tidak bisa mencari sesuatu, menavigasi, atau mengubah apa pun di aplikasi.

## Model mana yang mendukung alat?

### Model jarak jauh

Sebagian besar model jarak jauh modern dari penyedia besar mendukung tool calling kompatibel OpenAI. Secara umum:

- **Model besar** (seperti GPT-4o, Claude Sonnet/Opus, Gemini Pro) menangani alat dengan andal dan bisa merangkai beberapa panggilan alat dalam satu percakapan. Nama penyedia dan ID model ditampilkan di aplikasi untuk memudahkan; layanan yang benar-benar Anda hubungi adalah yang titik akhir dan kuncinya Anda konfigurasikan.
- **Model yang lebih kecil atau lebih murah** mungkin mendukung alat tetapi bisa kurang andal. Model bisa mengabaikan panggilan alat atau memformatnya salah.
- **Model yang sangat tua atau khusus** sering kali tidak mendukung alat sama sekali.

Jika Anda tidak yakin, uji modelnya di Theodia. Minta dia "Tunjukkan Kejadian 1:1" atau "Cari di Alkitab ayat-ayat tentang kasih." Jika ayatnya terbuka atau hasil pencarian muncul, tool calling bekerja.

## Model yang direkomendasikan untuk Theodia

Berikut pilihan-pilihan bagus yang menyeimbangkan biaya, kualitas, dan dukungan alat:

- **OpenAI GPT-4o** — dukungan alat yang sangat baik, cepat, menangani pertanyaan multi-langkah yang rumit dengan baik.
- **Anthropic Claude Sonnet / Opus** — pemakaian alat yang sangat andal, bagus untuk bagian panjang dan studi terperinci.
- **Groq** (berbagai model) — inferensi cepat, sering gratis atau sangat murah, dukungan alat bervariasi menurut model.
- **OpenRouter** — memungkinkan Anda mencoba banyak model dari satu akun. Cari model yang mencantumkan "function calling" atau "tools" di kemampuannya.
- **[GitHub Models](theodia://help/github-models)** — penyedia gratis yang direkomendasikan. Akses ke OpenAI, Anthropic, dan model lain melalui akun GitHub Anda dengan kuota harian gratis yang besar. Memakai ID model bergaya `openai/gpt-4o` yang sama.

## Model yang sebaiknya dihindari

- **Model pelengkapan teks murni** (seperti GPT-3 base atau LLaMA mentah tanpa instruction tuning) biasanya tidak mendukung alat.
- **Model khusus gambar atau visi** yang berfokus pada gambar, bukan teks, bisa kekurangan dukungan alat.
- **Model yang sangat kecil** di bawah 1 miliar parameter kecil kemungkinan memakai alat dengan benar, meskipun API mengklaim mendukungnya.

## Cara menguji dukungan alat

Theodia memeriksa dukungan alat secara otomatis. Setelah Anda menyiapkan sebuah model di **Pengaturan → Asisten AI**, ketuk **Uji koneksi**. Setelah koneksi berhasil, aplikasi mengirim permintaan kedua dengan definisi alat contoh. Anda akan melihat salah satu dari dua hasil:

- **✓ Alat didukung** — Model menerima panggilan alat dan bisa memakai fitur-fitur bawaan Theodia.
- **✗ Alat tidak didukung** — Model menolak permintaan alat. Model akan menjawab hanya dalam teks dan tidak bisa membuka ayat, mencari, atau mengelola penanda untuk Anda.

Jika Anda melihat "Alat tidak didukung", model itu mungkin masih bisa bekerja sebagai asisten obrolan teks biasa, tetapi Anda tidak akan mendapatkan pengalaman terpadu tanpa tangan yang membuat Theodia hebat.

Anda juga bisa memverifikasinya secara manual dengan meminta AI melakukan sesuatu:

- "Tunjukkan Matius 5:3 dalam KJV." — Harusnya membuka ayat itu di pembaca.
- "Apa kata leksikon tentang kata 'agape' dalam Yohanes 3:16?" — Harusnya mengembalikan data leksikon.
- "Cari di Alkitab ayat-ayat tentang pengampunan." — Harusnya mengembalikan hasil pencarian.
- "Tandai Markus 12:30." — Harusnya membuat penanda.

Jika AI memberi Anda deskripsi teks alih-alih benar-benar melakukan hal itu, model sedang kesulitan memakai alatnya meskipun aplikasi melaporkan dukungan.

## Bagaimana jika model saya tidak mendukung alat?

Anda tetap bisa memakainya. AI akan menjawab dalam teks, dan Anda bisa mencari ayat, mencari (search), dan menavigasi aplikasi sendiri secara manual. Tetapi Anda akan melewatkan pengalaman tanpa tangan dan terpadu yang membuat Theodia hebat.

## Ringkasan

- Pilih model dengan dukungan **tool calling / function calling** untuk pengalaman Theodia terbaik.
- **Model jarak jauh yang besar** menangani alat paling andal.
- Uji model mana pun dengan perintah sederhana seperti "Tunjukkan Kejadian 1:1" untuk memverifikasi dukungan alat.
