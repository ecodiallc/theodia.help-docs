---
title: Perintah
level: everyday
categories: [layout, study]
summary: Masukan Perintah memungkinkan Anda melompat ke fitur mana pun dengan mengetik perintah singkat. Pelajari format yang didukung dan contohnya.
---

# Perintah

Masukan **Perintah** memungkinkan Anda melompat ke hampir semua bagian Theodia dengan mengetik sebuah instruksi singkat. Anda bisa memakainya dari tab Beranda atau dari **Menu Peluncur** (ikon **▼** di kepala layar).

## Cara kerjanya

1. Ketuk kotak Perintah.
2. Ketik sebuah perintah.
3. Ketuk tombol go di papan ketik Anda.

Aplikasi membaca perintahnya dan langsung membawa Anda ke layar yang tepat.

## Tanpa awalan garis miring

Perintah **tidak** memakai awalan `/`. Perintah diketik sebagai teks biasa:

```
john 3:16
search love
backup
```

Jika Anda mengetik `/settings`, awalan `/` membuatnya tidak dikenali.

## Referensi Alkitab

Ketik referensi Alkitab mana pun untuk membukanya di pembaca.

```
psalms 23
john 3:16
matthew 5:1
1 cor 15:10
```

Nama kitab bisa dicocokkan dengan nama lengkap atau singkatannya. Dalam bahasa antarmuka selain Inggris, Anda juga bisa mengetik nama kitab dalam bahasa aktif.

## Pencarian

```
search abraham
search love
search faith not works
```

## Penanda, bandingkan, komentar, referensi silang, dan info kata

```
bookmark john 3:16
compare genesis 1:1
commentary john 1
aicommentary eph 2:8
xref 1 cor 15:10
word info john 1:1
```

Perintah-perintah ini membuka alat yang disebut untuk bagian yang diberikan.

## Leksikon

Ketik sebuah angka Strong untuk membuka entri leksikonnya.

```
g1161
h7225
```

## Renungan

```
devotional
devotional smith
devotional daily
```

Tanpa nama, ini membuka daftar renungan.

## Pintasan navigasi

```
notes
highlights
bookmarks
flashcards
playlist
theoscript
resources
read john 3:16
```

Perintah-perintah ini melompat langsung ke layar yang disebut atau membuka sebuah bagian di pembaca.

## Pergantian terjemahan

Ketik singkatan sebuah terjemahan untuk beralih ke sana.

```
kjv
web
trlit
ohgb
```

Di layar pembaca, terjemahannya ditukar di tempat. Di tempat lain, ini membuka terjemahan pada bagian terakhir Anda.

## Kata kerja perintah terlokalisasi

Kata kerja perintah publik bisa diketik dalam bahasa antarmuka aktif **atau** dalam bahasa Inggris. Bahasa Inggris selalu bekerja sebagai cadangan. Perintah tersembunyi (pintasan pengaturan, perintah pemasangan, telur Paskah) hanya mempertahankan sintaks bahasa Inggris.

## Bantuan

Ketik `help` atau `commands` di kotak Perintah untuk membuka referensi perintah dalam aplikasi kapan saja.
