---
title: Komentar dan Leksikon
level: everyday
categories: study
summary: Cara mencari arti kata dan membaca catatan studi.
---

# Komentar dan Leksikon

> **Mode:** Komentar dan leksikon membutuhkan mode **Pelajar**. Anda bisa mengganti mode di **Pengaturan** → **Mode Pengguna Aplikasi**.

Theodia menyertakan dua alat studi: **komentar** dan **leksikon**. Keduanya membantu Anda memahami Alkitab dengan lebih mendalam.

## Apa itu komentar?

Komentar adalah buku catatan studi yang ditulis oleh seorang pakar Alkitab. Untuk sebuah ayat tertentu, komentar memberi tahu Anda latar belakangnya, maknanya, dan bagaimana ayat itu berada dalam keseluruhan Alkitab.

## Apa itu leksikon?

Leksikon adalah kamus kata-kata Alkitab. Leksikon memberi tahu Anda kata asli dalam bahasa Ibrani atau Yunaninya, artinya, dan bagaimana kata itu digunakan dalam Alkitab.

## Cara membuka sebuah komentar

1. Buka sebuah pasal.
2. Ketuk sebuah ayat.
3. Ketuk **Komentar**.

Sebuah panel terbuka. Panel menampilkan catatan dari seorang pakar Alkitab tentang ayat itu.

## Cara membuka sebuah leksikon

1. Buka sebuah pasal di Alkitab yang menyertakan angka Strong.
2. Ketuk sebuah angka Strong dalam ayat itu (misalnya, G1234 atau H1234).
3. Sebuah panel terbuka menampilkan kata asli dalam bahasa Ibrani atau Yunani, artinya, dan ayat-ayat lain yang menggunakan kata itu.

Angka Strong tampil dengan warna berbeda di teks ayat sehingga menonjol dari kata-kata biasa.

## Memilih komentar yang lain

Komentar dipilih dari menu tarik-turun di bagian atas panel komentar itu sendiri. Buka panelnya, lalu ketuk menu tarik-turun untuk melihat komentar-komentar yang telah Anda pasang. Pilih yang lain.

## Memilih leksikon yang lain

Leksikon dipilih dari menu tarik-turun di bagian atas panel leksikon. Buka panelnya, lalu ketuk menu tarik-turun untuk melihat leksikon-leksikon yang telah Anda pasang. Pilih yang lain.

## Sumber daya bawaan

Theodia dibundel dengan satu set komentar dan leksikon bawaan. Semuanya disertakan bersama aplikasi dan bekerja luring. Komentar dan leksikon tambahan tidak bisa dipasang atau diunduh secara terpisah.

## Kapan menggunakan keduanya

- **Komentar** bagus dipakai saat sebuah ayat sulit dipahami. Catatannya memberi Anda latar belakang.
- **Leksikon** bagus untuk studi kata. Leksikon memberi tahu Anda arti persis sebuah kata dalam bahasa aslinya.

## Tips

Jika sebuah ayat memiliki catatan yang ingin Anda simpan, ambil tangkapan layar atau salin teksnya ke dalam sebuah catatan. (Lihat panduan [Menulis Catatan](theodia://help/notes).)

## Kamus Alkitab berbahasa sederhana

Untuk definisi dalam bahasa Inggris atas kata dan konsep Alkitab (perjanjian, pendamaian, orang Farisi, dan sebagainya), Theodia juga menyertakan alat Kamus Alkitab. Buka dari menu ayat dengan mengetuk **Kamus** (📖). Alat ini berbeda dari leksikon: leksikon menjelaskan kata-kata asli Ibrani dan Yunani, sedangkan kamus menjelaskan kata dalam bahasa Inggris dengan bahasa sederhana. Lihat panduan [Kamus Alkitab](theodia://help/dictionary) untuk cara menggunakannya.
