---
title: Masalah Umum
level: everyday
categories: trouble
summary: Perbaikan cepat untuk masalah yang mungkin Anda temui.
---

# Masalah Umum

Panduan ini membahas masalah-masalah yang paling sering ditemui orang. Jika masalah Anda tidak ada di sini, lihat panduan [Tempat Mengajukan Pertanyaan](theodia://help/getting-more-help).

## Aplikasi lambat

1. Tutup aplikasi-aplikasi lain yang berjalan di latar belakang.
2. Mulai ulang aplikasinya.
3. Mulai ulang perangkat Anda.

## Saya tidak menemukan sebuah terjemahan Alkitab

1. Buka **Pengaturan** → **Kelola Sumber Daya** untuk melihat apa yang terpasang.
2. Jika terjemahannya tidak ada di sana, ketuk **Pasang dari GitHub**.
3. Di jendela unduhan, ketuk tab **Alkitab** (atau **Alkitab Global**) dan pilih terjemahan yang Anda inginkan.
4. Ketuk **Pasang yang Dipilih** dan tunggu unduhannya selesai.
5. Anda membutuhkan internet untuk mengunduh sebuah terjemahan baru.

## Catatan atau penanda saya hilang

1. Periksa bahwa Anda melihat tab yang benar. Catatan ada di tab **Catatan**. Penanda ada di tab **Penanda**.
2. Jika Anda baru saja memulihkan sebuah cadangan, cadangan itu mungkin telah mengganti data Anda. Periksa tanggal cadangannya.
3. Jika Anda menghapus dan memasang lagi aplikasinya, data Anda hilang. Lain kali, buat cadangan lebih dulu.

## Pencarian tidak menemukan ayat

1. Pastikan Anda mengeja kata itu dengan benar.
2. Coba kata yang lebih pendek. "Love" menemukan lebih banyak ayat daripada "loving."
3. Pastikan Anda memasang terjemahan Alkitab yang tepat. Pencarian hanya bekerja pada terjemahan yang Anda miliki.

## Pembacaan tegak tidak bekerja

1. Pastikan volume perangkat Anda sudah tinggi.
2. Pastikan aplikasi diizinkan memakai pengeras suara.
3. Coba terjemahan yang berbeda. Beberapa terjemahan bekerja lebih baik dengan pembacaan tegak daripada yang lain.
4. Untuk daftar periksa langkah demi langkah, lihat panduan [Membaca Tegak](theodia://help/tts).

## Aplikasi terus mogok

1. Mulai ulang aplikasinya.
2. Mulai ulang perangkat Anda.
3. Jika masalahnya terus terjadi, silakan laporkan. Lihat panduan [Tempat Mengajukan Pertanyaan](theodia://help/getting-more-help).

## Saya ingin menghapus aplikasi

Anda bisa menghapus Theodia seperti aplikasi lain mana pun. Sebelum melakukannya, buat cadangan data Anda. Setelah Anda menghapusnya, data di perangkat hilang.

## Masih terjebak?

Lihat panduan [Tempat Mengajukan Pertanyaan](theodia://help/getting-more-help). Di sana, Anda bisa menemukan tautan untuk melaporkan sebuah masalah dan bertanya kepada komunitas.

Anda juga bisa mencari panduan-panduan bantuan dari layar utama **Bantuan & Panduan**. Ketik sebuah kata seperti `notifications`, `search`, atau `bookmarks` untuk menemukan panduan yang cocok.
