---
title: Membandingkan Terjemahan
level: everyday
categories: [read, study]
summary: Cara melihat ayat yang sama di setiap terjemahan yang telah Anda pasang.
---

# Membandingkan Terjemahan

> **Mode:** Alat Bandingkan tersedia di mode **Standar** dan **Pelajar**. Mode Fokus hanya untuk membaca yang bersih tanpa gangguan. Anda bisa mengganti mode di **Pengaturan** → **Mode Pengguna Aplikasi**.

Alat **Bandingkan** menampilkan satu ayat di setiap terjemahan Alkitab yang telah Anda pasang, semuanya dalam satu panel. Ini berguna saat Anda ingin melihat bagaimana penerjemah yang berbeda menangani ayat yang sulit, atau saat Anda sedang memilih terjemahan dan ingin melihat ayat yang sama di masing-masingnya.

## Cara membuka Bandingkan

1. Buka sebuah pasal di terjemahan mana pun.
2. Ketuk sebuah ayat untuk memunculkan menu ayat.
3. Ketuk **Bandingkan** (⇄).

Sebuah panel terbuka. Bilah judul menampilkan referensinya (misalnya, "Yohanes 3:16 — Bandingkan"). Panel menampilkan ayat yang sama di setiap terjemahan yang terpasang. Terjemahan Anda saat ini tercantum lebih dulu; sisanya diurutkan menurut abjad.

## Bentuk panel

Panel berupa **daftar vertikal**, bukan kolom berdampingan. Setiap baris adalah satu terjemahan:

- **Nama terjemahan** (misalnya, "KJV") berada di bagian atas baris. Nama itu bisa diketuk.
- **Teks ayat** berada di bawah namanya.

Gulir panelnya untuk melihat semua terjemahan. Setiap terjemahan yang terpasang di perangkat Anda akan muncul di sini. Jika sebuah terjemahan tidak memiliki kitab atau ayat itu, terjemahan itu dilewati.

## Cara membaca ayat itu di terjemahan lain

Ketuk nama terjemahan pada barisnya. Panel Bandingkan tertutup dan pasal yang sama terbuka dengan ayat pilihan ditampilkan dalam terjemahan itu. Ini cara tercepat untuk melompat dari perbandingan langsung ke membaca sebuah terjemahan tertentu.

## Cara menutup Bandingkan

- **Di ponsel:** ketuk tanda × di kanan atas panel.
- **Di tablet:** ketuk tanda × pada kepala panel, atau ketuk di luar panel.

Anda kembali ke tampilan pasal dalam terjemahan asal Anda.

## Kapan menggunakan Bandingkan

- **Memilih terjemahan.** Buka sebuah ayat yang Anda kenal baik dalam terjemahan Anda saat ini, lalu Bandingkan untuk melihatnya di terjemahan lain. Perbedaannya mudah terlihat.
- **Ayat-ayat sulit.** Ayat yang membingungkan dalam satu terjemahan sering kali lebih jelas di terjemahan lain.
- **Studi kata.** Lihat bagaimana penerjemah yang berbeda menangani sebuah kata atau frasa kunci.

Untuk perbandingan sekilas satu pasal utuh di beberapa terjemahan sekaligus, gunakan **tampilan paralel** sebagai gantinya. Lihat panduan [Mode Studi](theodia://help/study-mode) untuk cara menyalakannya.
