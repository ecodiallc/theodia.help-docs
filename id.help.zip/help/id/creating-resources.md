---
title: Membuat Sumber Daya Anda Sendiri
level: advanced
categories: resources
summary: Cara membuat Alkitab, komentar, buku, renungan, dan leksikon khusus serta mengimpornya ke Theodia.
---

# Membuat Sumber Daya Anda Sendiri

Theodia mendukung sumber daya khusus dalam format Unique Bible App. Setiap sumber daya adalah berkas SQLite dengan struktur tabel tertentu. Anda bisa membuat berkas-berkas ini di komputer dan mengimpornya ke aplikasi.

## Jenis berkas dan tabel yang dibutuhkan

### Alkitab (`.bible`)

Berkas Alkitab adalah basis data SQLite dengan setidaknya salah satu tabel berikut:

- **`Verses`** — kolom: `Book` (bilangan bulat, 1-66), `Chapter` (bilangan bulat), `Verse` (bilangan bulat), `Scripture` (teks)
- **`Bible`** — kolom: `Book` (bilangan bulat), `Chapter` (bilangan bulat), `Verse` (bilangan bulat), `Scripture` (teks)

Anda juga bisa menyertakan tabel **`Details`** dengan kolom metadata seperti `Description`, `Abbreviation`, dan `Version`.

Contoh SQL:

```sql
-- Main text table
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- Optional metadata table
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### Komentar (`.commentary`)

Komentar hadir dalam tiga jenis: **kitab**, **pasal**, dan **ayat**. Jenisnya ditentukan oleh **huruf pertama nama berkas**.

#### Komentar kitab — nama berkas diawali `b`

Komentar kitab membahas satu kitab Alkitab utuh dalam satu entri. Tabel `Commentary` membutuhkan kolom `Book` dan `Scripture` (atau `Content`). Kolom `Chapter` atau `Verse` tidak diperlukan.

- **`Commentary`** — kolom: `Book` (bilangan bulat), `Scripture` (teks) atau `Content` (teks)

Contoh SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

Contoh nama berkas: `bMyCommentary.commentary`

#### Komentar pasal — nama berkas diawali `c`

Komentar pasal membahas setiap pasal sebuah kitab Alkitab.

- **`Commentary`** — kolom: `Book` (bilangan bulat), `Chapter` (bilangan bulat), `Scripture` (teks) atau `Content` (teks)

Contoh SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

Contoh nama berkas: `cMyCommentary.commentary`

#### Komentar ayat — nama berkas diawali `v`

Komentar ayat membahas ayat-ayat individual. Tabel `Commentary` membutuhkan kolom `Book`, `Chapter`, `Verse`, dan `Scripture` (atau `Content`).

- **`Commentary`** — kolom: `Book` (bilangan bulat), `Chapter` (bilangan bulat), `Verse` (bilangan bulat), `Scripture` (teks) atau `Content` (teks)

Contoh SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

Contoh nama berkas: `vMyCommentary.commentary`

### Buku (`.book`)

Berkas buku adalah basis data SQLite dengan tabel `Reference`.

- **`Reference`** — kolom: `id` (bilangan bulat), `Chapter` (teks), `Content` (teks)

Setiap baris adalah satu pasal. Kolom `Chapter` adalah judul pasalnya. Kolom `Content` adalah isi pasal, yang bisa menyertakan HTML (`<b>`, `<i>`, `<br>`, dan seterusnya).

Contoh SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

Anda juga bisa membuat buku dari berkas Markdown. Aplikasi bisa mengimpor berkas `.md` di mana `#` adalah judul bukunya dan `##` menandai pasal-pasal. Markdown dikonversi ke HTML secara otomatis.

### Renungan (`.devotional`)

Berkas renungan adalah basis data SQLite dengan tabel `devotional`.

- **`devotional`** — kolom: `month` (bilangan bulat, 1-12), `day` (bilangan bulat, 1-31), `devotion` (teks)

Setiap baris adalah bacaan satu hari. Aplikasi mencari entri berdasarkan bulan dan hari ini.

Contoh SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### Leksikon (`.lexicon`)

Berkas leksikon adalah basis data SQLite dengan tabel `Lexicon`.

- **`Lexicon`** — kolom: `Topic` (teks, angka Strong), `Definition` (teks, entri leksikon)

Kolom `Topic` menyimpan angka Strong (misalnya, `G1161` atau `H7225`). Kolom `Definition` menyimpan teks entri lengkap, yang bisa menyertakan HTML.

Contoh SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

Leksikon mendukung alat Info Kata. Saat Anda mengetuk sebuah kata di Alkitab interlinear, aplikasi mencari angka Strongnya di leksikon-leksikon terpasang.

## Membuat berkas di komputer Anda

1. Pasang penyunting SQLite (DB Browser for SQLite, SQLiteStudio, atau alat baris perintah `sqlite3`).
2. Buat berkas basis data baru.
3. Buat tabel yang dibutuhkan dan masukkan data Anda.
4. Simpan berkasnya dengan ekstensi yang benar (`.bible`, `.commentary`, `.book`, `.devotional`, atau `.lexicon`).

## Mengimpor ke Theodia

1. Pindahkan berkasnya ke perangkat Anda (AirDrop, surel, penyimpanan awan, atau USB).
2. Buka **Theodia**.
3. Pergi ke **Pengaturan** → **Kelola Sumber Daya**.
4. Ketuk **Impor dari Berkas**.
5. Pilih berkas Anda.

Aplikasi memvalidasi berkasnya (memeriksa tabel yang dibutuhkan), menyalinnya ke folder data aplikasi, dan menyalakannya secara otomatis. Jika berkasnya tidak sah, Anda melihat pesan kesalahan yang menjelaskan apa yang salah.

## Batasan

- Anda tidak bisa menimpa sumber daya bawaan. Jika Anda mencoba mengimpor berkas dengan nama sama dengan Alkitab, komentar, atau buku bawaan, impor itu gagal.
- Berkas Alkitab membutuhkan tabel `Verses` atau `Bible`. Jika keduanya tidak ada, impor itu gagal.
- Berkas komentar membutuhkan tabel `Commentary`.
  - Komentar kitab membutuhkan kolom `Book` dan `Scripture` (atau `Content`).
  - Komentar pasal membutuhkan kolom `Book`, `Chapter`, dan `Scripture` (atau `Content`).
  - Komentar ayat membutuhkan kolom `Book`, `Chapter`, `Verse`, dan `Scripture` (atau `Content`).
- Berkas buku membutuhkan tabel `Reference`.
- Berkas leksikon membutuhkan tabel `Lexicon`.
- Berkas renungan membutuhkan tabel `devotional`.

## Tips

- Jaga ukuran berkas tetap masuk akal. Berkas SQLite yang sangat besar bisa menyebabkan masalah memori di perangkat yang lebih tua.
- Uji berkas Anda di komputer lebih dulu. Buka di peramban SQLite dan jalankan `SELECT * FROM` pada tabel yang dibutuhkan untuk memastikan datanya tampak benar.
- Untuk Alkitab, pastikan kolom `Book` memakai bilangan (1 = Kejadian, 66 = Wahyu).
- Untuk Komentar, Anda bisa memakai `Scripture` atau `Content` sebagai kolom teks komentarnya.
- Untuk Buku, HTML dalam kolom `Content` dirender saat membaca. Jaga agar tetap sederhana: `<b>`, `<i>`, `<br>`, dan `<hr>` aman dipakai.

## Di mana menemukan sumber daya yang sudah ada

Theodia bisa membaca sumber daya dari proyek [Unique Bible App](https://github.com/eliranwong/UniqueBible). Banyak Alkitab, komentar, buku, dan sumber daya lain tersedia di sana dalam format SQLite yang benar. Lihat panduan [Mendapatkan Sumber Daya Tambahan](theodia://help/getting-core-files) untuk cara menemukan dan menambahkannya.
