---
title: Referensi Silang
level: everyday
categories: study
summary: Cara menemukan ayat-ayat yang terhubung dengan ayat yang sedang Anda baca.
---

# Referensi Silang

> **Mode:** Referensi silang tersedia di mode **Standar** dan **Pelajar**. Mode Fokus hanya untuk membaca yang bersih tanpa gangguan. Anda bisa mengganti mode di **Pengaturan** → **Mode Pengguna Aplikasi**.

"Referensi silang" adalah ayat lain yang berbicara tentang hal yang sama dengan ayat yang sedang Anda baca. Panel referensi silang menunjukkan ayat-ayat mana di Alkitab yang saling terhubung.

## Cara membuka referensi silang

1. Buka sebuah pasal.
2. Ketuk sebuah ayat untuk memunculkan menu ayat.
3. Ketuk **Referensi Silang**.

Sebuah panel terbuka. Panel menampilkan daftar ayat-ayat lain yang terhubung dengan ayat yang Anda ketuk.

## Cara membaca daftarnya

Setiap baris adalah satu ayat terhubung. Anda melihat:

- Kitab, pasal, dan ayatnya.
- Cuplikan singkat teks ayat.
- Skor yang menunjukkan seberapa kuat keterhubungannya.

## Cara melompat ke ayat terhubung

Ketuk baris mana pun. Aplikasi membuka ayat itu untuk Anda. Setelah selesai, ketuk tombol kembali untuk kembali.

## Arti skor

Skor memberi tahu Anda seberapa erat ayat-ayat itu terhubung. Skor tinggi berarti keterhubungan yang kuat dan langsung. Skor rendah berarti keterhubungan yang lebih longgar.

## Menggunakan referensi silang untuk studi

Referensi silang berguna untuk:

- **Studi kata.** Lihat bagaimana Alkitab menggunakan sebuah kata di tempat-tempat berbeda.
- **Studi tema.** Telusuri sebuah tema, seperti "kasih" atau "perjanjian", di sepanjang Kitab Suci.
- **Persiapan khotbah.** Temukan ayat-ayat pendukung dengan cepat.

## Tips

Referensi silang bekerja paling baik dengan terjemahan kata-per-kata seperti WEB.
