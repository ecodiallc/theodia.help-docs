---
title: Renungan Harian
level: everyday
categories: [content, read]
summary: Cara membaca renungan singkat setiap hari.
---

# Renungan Harian

Renungan adalah bacaan singkat untuk satu hari. Renungan biasanya memuat sebuah ayat, sebuah pemikiran singkat, dan sebuah pertanyaan untuk dipikirkan. Theodia hadir dengan pustaka kecil berisi renungan.

## Cara membuka renungan

1. Ketuk tab **Renungan** di bagian bawah layar.
2. Anda melihat daftar renungan yang terpasang di perangkat Anda.
3. Ketuk salah satu untuk membukanya.

## Cara membaca renungan

1. Buka renungannya.
2. Gulir untuk membaca.
3. Gunakan tombol-tombol di bagian atas untuk:
   - Ketuk **tanggal** untuk melompat ke hari yang berbeda.
   - Ketuk **bintang** untuk menandai hari itu.
   - Ketuk **pengeras suara** untuk membacakannya dengan suara (jika perangkat Anda mendukung). Lihat panduan [Membaca Tegak](theodia://help/tts) untuk cara memilih suara.
   - Ketuk **Sebelumnya** atau **Berikutnya** untuk pindah ke hari sebelum atau sesudahnya.

## Cara menyimpan sebuah ayat dari renungan

1. Buka renungannya.
2. Ketuk sebuah ayat.
3. Ketuk **Penanda halaman** atau **Sorotan**.

Ayat itu tersimpan di Penanda atau Sorotan Anda.

## Cara menulis catatan pada renungan

1. Buka renungannya.
2. Ketuk sebuah ayat.
3. Ketuk **Catatan**. Ketik renungan batin atau doa Anda. Ketuk **Simpan**.

Catatan itu tampil di tab Catatan Anda.

## Tips

- Renungan tidak membutuhkan internet. Renungan bekerja luring.
- Jika Anda ingin lebih banyak renungan, lihat panduan [Mendapatkan Sumber Daya Tambahan dari GitHub](theodia://help/getting-core-files).
