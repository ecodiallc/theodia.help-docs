---
title: Kamus Alkitab
level: everyday
categories: study
summary: Cari kata dan konsep Alkitab di sumber daya kamus yang terpasang. Buka dari menu ayat atau dari entri leksikon, lalu ketuk kata mana pun untuk melihat kata yang sama di setiap kamus.
---

# Kamus Alkitab

> **Mode:** Kamus Alkitab membutuhkan mode **Pelajar**. Anda bisa mengganti mode di **Pengaturan** → **Mode Pengguna Aplikasi**.

Alat Kamus Alkitab mencari sebuah kata atau frasa di setiap sumber daya kamus yang telah Anda pasang. Alat ini berguna saat Anda menginginkan definisi berbahasa sederhana atas sebuah kata Alkitab, deskripsi tentang seorang tokoh atau tempat, atau artikel singkat tentang sebuah konsep teologis.

Kamus Alkitab berbeda dari alat **Info Kata**, yang mencari kata asli Ibrani atau Yunani di balik sebuah ayat. Kamus membaca kata dalam **bahasa Inggris** yang Anda ketuk dan menunjukkan apa kata itu menurut kamus-kamus terpasang Anda. Untuk catatan terjemahan Alkitab kata demi kata, lihat panduan [Komentar dan Leksikon](theodia://help/commentaries-and-lexicons).

## Cara membuka Kamus

Ada dua cara membuka kamus.

### Dari menu ayat

1. Buka sebuah pasal di [Mode Studi](theodia://help/study-mode).
2. Ketuk sebuah ayat untuk membuka menu ayat.
3. Ketuk **Kamus** (📖).

Sebuah panel terbuka dengan judul berupa referensi ayat (misalnya, "John 3:16"). Teks ayat berada di bagian atas dengan setiap kata bisa diketuk. Di bawah ayat ada strip segmen yang menampilkan setiap kamus terpasang. Di bawahnya adalah definisi, yang kosong sampai Anda mengetuk sebuah kata.

### Dari sebuah entri leksikon

Saat Anda membaca sebuah entri leksikon di panel Info Kata, beberapa entri memuat tautan biru ke artikel kamus terkait. Ketuk salah satu tautan itu. Leksikon tertutup dan kamus terbuka pada artikel itu. Ini cara tercepat untuk melompat dari sebuah kata Yunani atau Ibrani ke penjelasan berbahasa sederhana tentang artinya.

## Cara kerja tampilan ayat

Saat Anda membuka kamus dari sebuah menu ayat, ayat itu muncul di bagian atas panel sebagai daftar kata yang bisa diketuk. Kata-kata Inggris umum seperti "the," "and," "of," "to," dan "a" tidak bisa diketuk. Kata lain semuanya bisa. Setiap kata yang bisa diketuk diberi warna dan dicetak tebal sehingga menonjol dari bagian lain ayat itu.

Ketuk kata mana pun dalam ayat. Theodia menelusuri setiap kamus terpasang untuk kecocokan persis pada kata itu. Strip segmen di bagian bawah diperbarui untuk menunjukkan kamus mana yang memiliki entri: kamus yang tidak memiliki entri untuk kata itu diredupkan. Kamus pertama yang memiliki entri dipilih secara otomatis, dan definisinya muncul di bawah strip segmen.

Kata yang Anda ketuk disorot dalam teks ayat di bagian atas panel, sehingga Anda selalu tahu apa yang sedang Anda cari.

## Beralih antarkamus

Setiap kamus terpasang ditampilkan sebagai segmen kecil di bawah ayat. Setelah mengetuk sebuah kata:

- Segmen **berwarna penuh** — kamus ini memiliki entri untuk kata yang Anda ketuk. Ketuk untuk beralih ke definisi kamus itu.
- Segmen **diredupkan** — kamus ini tidak memiliki entri untuk kata itu. Segmen ditampilkan berwarna abu-abu sehingga Anda bisa melihat sekilas kamus mana yang mencakup kata itu, dan segmen tidak bisa diketuk.

Kamus yang terpilih disorot. Ketuk segmen penuh lainnya untuk membaca kata yang sama di kamus itu. Definisi di bawahnya langsung diperbarui.

Jika kata itu hanya ada di salah satu kamus terpasang Anda, hanya satu segmen itu yang penuh warna dan sisanya diredupkan.

## Apa yang ditampilkan panel

Panel kamus memiliki tiga bagian, dari atas ke bawah:

- **Ayatnya** — ayat yang menjadi asal Anda membuka kamus. Kata-katanya bisa diketuk, dan kata yang terakhir Anda ketuk disorot.
- **Strip segmen** — setiap kamus terpasang. Penuh warna berarti "punya entri untuk kata yang diketuk." Diredupkan berarti "tidak ada entri untuk kata itu."
- **Definisinya** — artikel dari kamus yang terpilih. Teks biasa, diformat dengan paragraf dan judul. Tautan internal ke entri kamus lain bisa diketuk; mengetuk salah satunya membuka entri itu di kamus.

## Apa yang terjadi jika tidak ada entri yang ditemukan

Jika Anda mengetuk sebuah kata yang tidak dicakup oleh kamus terpasang mana pun, panel menampilkan pesan singkat "tidak ada entri ditemukan" sebagai ganti definisi. Ini umum terjadi untuk kata-kata yang sangat umum seperti "year" atau "come" yang bukan benar-benar kata teologi Alkitab, meskipun muncul di mana-mana dalam Alkitab. Coba kata yang lebih spesifik, atau gunakan alat Info Kata pada leksikon sebagai gantinya, yang bekerja pada teks Yunani dan Ibrani di baliknya.

## Apa yang terjadi jika tidak ada kamus yang terpasang

Kamus membutuhkan setidaknya satu berkas sumber daya kamus agar berguna. Theodia membundel satu. Jika Anda telah menghapusnya atau menjalankan pemasangan khusus tanpa kamus, tampilan ayat tetap muncul dan kata-kata tetap bisa diketuk, tetapi strip segmennya kosong dan setiap pencarian mengembalikan "tidak ada entri ditemukan."

Kamus tambahan tidak bisa dipasang secara terpisah.

## Tips

- Kamus mencari **kecocokan kata persis**. Mengetuk "love" menemukan entri berjudul "love" tetapi tidak "loved" atau "loving." Untuk mencari bentuk terkait, gunakan alat Info Kata pada leksikon untuk kata Yunani atau Ibraninya.
- Strip segmennya sama di ponsel dan tablet. Di tablet, kamus terbuka sebagai panel samping di sebelah pasal; di ponsel, kamus terbuka sebagai jendela layar penuh. Keduanya memiliki tata letak tiga bagian yang sama.
- Mengetuk sebuah kata di ayat lain membuka ayat baru di panel. Pilihan Anda sebelumnya dihapus. Ketuk sebuah kata di ayat baru untuk memulai pencarian baru.
- Beberapa entri kamus merujuk ke kata yang sama di kamus lain. Ketuk tautan internal itu untuk mengikuti jejaknya di seluruh kamus terpasang Anda.

## Perbedaan antara Kamus dan Info Kata

Kedua alat dibuka dari menu ayat, tetapi keduanya melakukan hal berbeda:

- **Kamus** (📖) membaca kata Inggris yang Anda ketuk dan menemukannya di kamus-kamus Inggris terpasang Anda. Ini alat yang tepat untuk definisi berbahasa sederhana atas kata-kata teologi Alkitab seperti "covenant," "atonement," atau "Pharisee."
- **Info Kata** (?) membaca kata Yunani atau Ibrani asli di balik ayat dan menemukannya di leksikon terpasang Anda. Ini alat yang tepat untuk studi kata yang serius, menemukan setiap tempat sebuah kata Yunani digunakan, dan membaca definisi dalam bahasa aslinya.

Bila ragu, mulailah dari kamus. Jika Anda ingin mendalami bahasa aslinya, beralihlah ke Info Kata. Lihat panduan [Komentar dan Leksikon](theodia://help/commentaries-and-lexicons) untuk penjelasan lengkap Info Kata.

## Panduan terkait

- Panduan [Mode Studi](theodia://help/study-mode) menjelaskan menu ayat secara detail dan posisi alat Kamus (📖) di samping Penanda halaman, Sorotan, Bacakan, Bandingkan, Referensi Silang, Komentar AI, Info Kata, dan Catatan.
- Panduan [Komentar dan Leksikon](theodia://help/commentaries-and-lexicons) membahas Info Kata dan leksikon bahasa asli.
- Panduan [Apa Itu Sumber Daya?](theodia://help/what-are-resources) menjelaskan berbagai jenis berkas yang dipakai Theodia, termasuk sumber daya kamus.
- Panduan [Masalah Umum](theodia://help/common-problems) memuat perbaikan untuk hasil yang kosong dan masalah kamus lainnya.
