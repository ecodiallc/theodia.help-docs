---
title: Ensiklopedia
level: everyday
categories: study
summary: Cara mencari artikel ensiklopedia dan menelusuri karya rujukan.
---

# Ensiklopedia

Theodia menyertakan **Ensiklopedia** bawaan untuk mencari artikel terkait Alkitab, tokoh, tempat, dan topik. Aplikasi membundel _Kitto's Illustrated Commentary_ (KIT) secara bawaan, dan Anda bisa mengunduh ensiklopedia tambahan dari repositori.

## Apa itu ensiklopedia di Theodia?

Ensiklopedia adalah karya rujukan yang tersusun dari artikel-artikel pendek. Setiap artikel membahas seorang tokoh, sebuah tempat, sebuah peristiwa, atau sebuah topik Alkitab. Berbeda dari komentar yang menjelaskan ayat tertentu, artikel ensiklopedia menjelaskan topiknya sendiri.

## Cara membuka Ensiklopedia

1. Ketuk **Ensiklopedia** di bilah alat bawah.
2. Pilih sebuah ensiklopedia dari baris singkatan di bagian atas.
3. Ketik sebuah topik, tokoh, atau tempat ke dalam kotak pencarian.

Pencarian membutuhkan setidaknya **3 karakter** sebelum hasil dan saran pelengkapan otomatis muncul.

## Membaca sebuah artikel

- Di **ponsel**, ketuk hasil mana pun untuk membuka artikelnya di layar baru.
- Di **tablet**, artikel terbuka di panel di sebelah kanan sementara daftarnya tetap di sebelah kiri.

## Memilih ensiklopedia

Ketuk sebuah segmen singkatan (seperti **KIT**) untuk beralih ke ensiklopedia itu. Untuk mencari di lebih dari satu ensiklopedia sekaligus, gunakan tab **Pencarian** dan pilih **Ensiklopedia** sebagai mode pencarian.

## Mendapatkan lebih banyak ensiklopedia

1. Buka **Pengaturan**.
2. Ketuk **Kelola Sumber Daya**.
3. Ketuk **Pasang dari GitHub**.
4. Pilih tab **Ensiklopedia**.
5. Ketuk tombol unduh di sebelah ensiklopedia yang Anda inginkan.

Ensiklopedia diunduh dari repositori GitHub ensiklopedia milik Theodia dan dipasang secara otomatis. Ensiklopedia terpasang muncul di layar Ensiklopedia dan di Pencarian.

Anda juga bisa memasang ensiklopedia dari berkas lokal: di **Kelola Sumber Daya**, ketuk **Pasang Berkas Lokal** dan pilih sebuah berkas `.encyclopedia`. Berkas disalin ke folder ensiklopedia aplikasi dan ditambahkan ke indeks pencarian bersama.

## Tekan lama untuk judul lengkap

Di layar Pencarian, segmen ensiklopedia menampilkan singkatan pendek. Tekan lama sebuah segmen untuk melihat nama lengkap ensiklopedianya.

## Kapan menggunakan Ensiklopedia

- Mencari seorang tokoh, tempat, atau topik sebelum atau saat membaca sebuah bagian.
- Mendapatkan latar belakang atas sebuah kata atau konsep Alkitab yang membentang di banyak ayat.
- Membaca bersama sebuah komentar untuk studi yang lebih mendalam.
