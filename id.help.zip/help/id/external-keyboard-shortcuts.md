---
title: Pintasan Papan Ketik Eksternal
level: everyday
categories: [tablet, settings]
summary: Referensi lengkap pintasan papan ketik untuk iPad dengan papan ketik eksternal terpasang.
---

# ⌨️ Pintasan Papan Ketik Eksternal

Jika Anda memakai Theodia di iPad dengan papan ketik eksternal (Magic Keyboard, papan ketik Bluetooth, atau papan ketik USB), Anda bisa menavigasi aplikasi tanpa menyentuh layar.

> **Mode:** Beberapa pintasan hanya bekerja ketika fitur yang bersangkutan tersedia di mode pengguna Anda saat ini. Misalnya, `Cmd + Option + 6` (Penanda) dan `Cmd + Option + 7` (Sorotan) tidak melakukan apa pun di mode Pembaca. Ganti mode di **Pengaturan** → **Mode Pengguna Aplikasi**.

Pintasan bekerja di **iPad**.

## Pintasan global (di mana saja)

| Pintasan           | Tindakan                                      |
| ------------------ | ------------------------------------------- |
| `Cmd + /`          | Menampilkan bantuan pintasan papan ketik ini |
| `Cmd + .`          | Menutup jendela munculan / panel (alternatif Escape)    |
| `Cmd + Option + 1` | Pergi ke tab Beranda                              |
| `Cmd + Option + 2` | Pergi ke tab Alkitab                            |
| `Cmd + Option + 3` | Pergi ke tab Buku                             |
| `Cmd + Option + 4` | Pergi ke tab Renungan                       |
| `Cmd + Option + 5` | Pergi ke tab Pencarian                            |
| `Cmd + Option + 6` | Pergi ke tab Penanda (Standar dan Pelajar)  |
| `Cmd + Option + 7` | Pergi ke tab Sorotan (Standar dan Pelajar) |
| `Cmd + Option + 8` | Pergi ke tab Catatan (Standar dan Pelajar)      |
| `Cmd + Option + 9` | Pergi ke tab AI (hanya Pelajar, jika diaktifkan)     |
| `Cmd + Option + 0` | Pergi ke tab Bantuan                              |
| `Cmd + Option + I` | Pergi ke tab Tentang                             |
| `Cmd + [`          | Kembali                                     |
| `Cmd + F`          | Membuka Pencarian                                 |
| `Cmd + K`          | Membuka Menu Peluncur (Pelajar)                |
| `Cmd + ,`          | Membuka Pengaturan                               |
| `Cmd + Shift + M`  | Membuka menu utama                              |
| `Cmd + Shift + T`  | Menggilir tema (bawaan / gelap)                |
| `Cmd + Shift + U`  | Membuka pemilih mode pengguna                       |
| `Escape`           | Menutup jendela munculan / panel                 |

## Pintasan Pembaca Alkitab

Pintasan ini bekerja di **Pembaca Studi** maupun **Pembaca Fokus**.

| Pintasan           | Tindakan                                                       |
| ------------------ | ------------------------------------------------------------ |
| `← Left Arrow`     | Pasal sebelumnya                                             |
| `→ Right Arrow`    | Pasal berikutnya                                                 |
| `Cmd + R`          | Berganti antara Pembaca Studi dan Fokus (Standar dan Pelajar) |
| `Cmd + Option + V` | Membuka pemilih versi                                          |
| `Cmd + Option + B` | Membuka pemilih kitab                                             |
| `Cmd + Option + C` | Membuka pemilih pasal                                          |
| `Cmd + T`          | Mengalihkan TTS (berhenti saat berputar/dijeda, mulai saat menganggur)       |
| `Cmd + Option + T` | Putar / Jeda TTS                                             |

## Hanya Pembaca Studi

| Pintasan           | Tindakan                                                                 |
| ------------------ | ---------------------------------------------------------------------- |
| `↑ Up Arrow`       | Memilih ayat sebelumnya                                                  |
| `↓ Down Arrow`     | Memilih ayat berikutnya                                                      |
| `Cmd + ↑`          | Memilih ayat pertama                                                     |
| `Cmd + ↓`          | Memilih ayat terakhir                                                      |
| `Cmd + ←`          | Melompat ke pasal 1                                                      |
| `Cmd + →`          | Melompat ke pasal terakhir                                                   |
| `Cmd + 0`–`9`      | Lompat langsung ke ayat (ketik digitnya, mis. `Cmd + 1` `Cmd + 6` untuk ayat 16) |
| `Cmd + P`          | Mengalihkan Alkitab paralel (Standar dan Pelajar)                          |
| `Cmd + B`          | Menandai ayat terpilih (Standar dan Pelajar)                         |
| `Cmd + H`          | Menyorot ayat terpilih (Standar dan Pelajar)                        |
| `Cmd + N`          | Menambah catatan untuk ayat terpilih (Standar dan Pelajar)                     |
| `Cmd + C`          | Membandingkan terjemahan ayat terpilih (Standar dan Pelajar)             |
| `Cmd + X`          | Membuka referensi silang untuk ayat terpilih (Standar dan Pelajar)        |
| `Cmd + I`          | Membuka info kata (Pelajar)                                               |
| `Cmd + D`          | Membuka kamus untuk ayat terpilih (Pelajar)                           |
| `Cmd + A`          | Membuka panel AI untuk ayat terpilih (Pelajar)                             |
| `Cmd + Option + S` | Mengalihkan subjudul                                                     |
| `Cmd + Option + W` | Menutup semua panel studi yang terbuka                                            |
| `Cmd + Option + M` | Membuka menu tindakan ayat                                                 |

## Hanya Pembaca Fokus

| Pintasan       | Tindakan           |
| -------------- | ---------------- |
| `↑ Up Arrow`   | Menggulir ke atas        |
| `↓ Down Arrow` | Menggulir ke bawah      |
| `Cmd + ↑`      | Menggulir ke paling atas    |
| `Cmd + ↓`      | Menggulir ke paling bawah |
| `Cmd + =`      | Memperbesar          |
| `Cmd + -`      | Memperkecil         |

## Pencarian

| Pintasan           | Tindakan                           |
| ------------------ | -------------------------------- |
| `Return`           | Menjalankan pencarian                   |
| `Cmd + Return`     | Membersihkan pencarian dan memfokuskan masukan     |
| `Cmd + ↑`          | Menggulir hasil ke atas                |
| `Cmd + ↓`          | Menggulir hasil ke bawah              |
| `Cmd + Option + A` | Memilih semua butir lingkup           |
| `Cmd + Option + C` | Membatalkan pilihan semua butir lingkup         |
| `Cmd + Option + B` | Mode pencarian Alkitab                |
| `Cmd + Option + O` | Mode pencarian buku                 |
| `Cmd + Option + D` | Mode pencarian kamus (Pelajar) |
| `Cmd + Option + X` | Mode pencarian leksikon (Pelajar)    |

## Hasil Pencarian

| Pintasan  | Tindakan              |
| --------- | ------------------- |
| `Cmd + S` | Membuka lembar simpan-semua |
| `Cmd + ↑` | Menggulir hasil ke atas   |
| `Cmd + ↓` | Menggulir hasil ke bawah |

## Pembaca Buku

| Pintasan           | Tindakan                   |
| ------------------ | ------------------------ |
| `← Left Arrow`     | Pasal sebelumnya         |
| `→ Right Arrow`    | Pasal berikutnya             |
| `Cmd + ↑`          | Pasal sebelumnya         |
| `Cmd + ↓`          | Pasal berikutnya             |
| `↑ Up Arrow`       | Menggulir ke atas                |
| `↓ Down Arrow`     | Menggulir ke bawah             |
| `Cmd + B`          | Menandai pasal saat ini |
| `Cmd + J`          | Membuka pemilih pasal      |
| `Cmd + L`          | Membuka pemilih suara        |
| `Cmd + T`          | Mengalihkan TTS               |
| `Cmd + Option + T` | Putar / Jeda TTS         |

## Pembaca Renungan

| Pintasan           | Tindakan              |
| ------------------ | ------------------- |
| `← Left Arrow`     | Hari sebelumnya        |
| `→ Right Arrow`    | Hari berikutnya            |
| `↑ Up Arrow`       | Menggulir ke atas           |
| `↓ Down Arrow`     | Menggulir ke bawah         |
| `Cmd + ↑`          | Menggulir ke atas (jauh)   |
| `Cmd + ↓`          | Menggulir ke bawah (jauh) |
| `Cmd + D`          | Membuka pemilih tanggal    |
| `Cmd + T`          | Mengalihkan TTS          |
| `Cmd + Option + T` | Putar / Jeda TTS    |

## Obrolan AI

| Pintasan           | Tindakan                     |
| ------------------ | -------------------------- |
| `Cmd + Return`     | Mengirim pesan               |
| `Cmd + N`          | Obrolan baru                   |
| `Cmd + D`          | Mengalihkan laci percakapan |
| `Cmd + Option + C` | Membersihkan obrolan saat ini         |
| `Cmd + S`          | Membuka menu simpan             |
| `Escape`           | Menutup laci / menu        |

## Penanda

| Pintasan                      | Tindakan                             |
| ----------------------------- | ---------------------------------- |
| `↑ Up Arrow` / `↓ Down Arrow` | Memilih penanda                    |
| `Return`                      | Membuka penanda (tablet: memilih)     |
| `Cmd + R`                     | Membaca penanda dalam konteksnya           |
| `Cmd + M`                     | Memindahkan penanda terpilih ke folder  |
| `Cmd + N`                     | Mengelola folder                     |
| `Escape`                      | Menutup panel detail / pemilih folder |

Di pemilih **Simpan ke Folder**, `↑ Up Arrow` / `↓ Down Arrow` memindahkan pilihan, `Return` mengalihkan folder terpilih atau mengaktifkan tindakan yang disorot, dan `Escape` menutup pemilihnya. Baris **+ Buat Folder** berada di bagian atas daftar.

## Catatan Alkitab

| Pintasan                      | Tindakan                |
| ----------------------------- | --------------------- |
| `↑ Up Arrow` / `↓ Down Arrow` | Memilih catatan           |
| `Return`                      | Membuka catatan             |
| `Cmd + Return`                | Memfokuskan masukan penyaring    |
| `Escape`                      | Menutup detail / penyunting |

## Sorotan

| Pintasan                      | Tindakan             |
| ----------------------------- | ------------------ |
| `↑ Up Arrow` / `↓ Down Arrow` | Memilih sorotan   |
| `Return`                      | Membuka sorotan     |
| `Cmd + Return`                | Memfokuskan masukan penyaring |
| `Escape`                      | Menutup panel detail |

## Daftar Alkitab

| Pintasan                                 | Tindakan                            |
| ---------------------------------------- | --------------------------------- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | Alkitab berikutnya                        |
| `← Left Arrow` / `↑ Up Arrow`            | Alkitab sebelumnya                    |
| `Return`                                 | Membuka Alkitab yang difokuskan                |
| `Cmd + Shift + S`                        | Mengalihkan favorit untuk Alkitab yang difokuskan |
| `Escape`                                 | Kembali                           |

## Layar Kitab-Kitab Alkitab

| Pintasan                | Tindakan                     |
| ----------------------- | -------------------------- |
| `Tab` / `→ Right Arrow` | Kitab berikutnya                  |
| `← Left Arrow`          | Kitab sebelumnya              |
| `↓ Down Arrow`          | Kitab di bawahnya dalam kisi         |
| `↑ Up Arrow`            | Kitab di atasnya dalam kisi         |
| `Cmd + ↓`               | Bagian berikutnya (PT / PB)     |
| `Cmd + ↑`               | Bagian sebelumnya (PT / PB) |
| `Return`                | Membuka kitab yang difokuskan          |
| `Escape`                | Kembali                    |

## Daftar Buku

| Pintasan                                 | Tindakan            |
| ---------------------------------------- | ----------------- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | Buku berikutnya         |
| `← Left Arrow` / `↑ Up Arrow`            | Buku sebelumnya     |
| `Return`                                 | Membuka buku yang difokuskan |
| `Escape`                                 | Kembali           |

## Layar Pasal-Pasal Alkitab

| Pintasan                                 | Tindakan               |
| ---------------------------------------- | -------------------- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | Pasal berikutnya         |
| `← Left Arrow` / `↑ Up Arrow`            | Pasal sebelumnya     |
| `Return`                                 | Membuka pasal yang difokuskan |
| `Escape`                                 | Kembali              |

## Layar Pasal Buku

| Pintasan               | Tindakan                    |
| ---------------------- | ------------------------- |
| `Tab` / `↓ Down Arrow` | Pasal berikutnya              |
| `↑ Up Arrow`           | Pasal sebelumnya          |
| `Return`               | Membuka pasal yang difokuskan      |
| `Cmd + Return`         | Memfokuskan masukan pencarian/penyaring |
| `Escape`               | Kembali                   |

## Daftar Renungan

| Pintasan                                 | Tindakan                  |
| ---------------------------------------- | ----------------------- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | Renungan berikutnya         |
| `← Left Arrow` / `↑ Up Arrow`            | Renungan sebelumnya     |
| `Return`                                 | Membuka renungan yang difokuskan |
| `Escape`                                 | Kembali                 |

## Diagram

Di layar Statistik, Sasaran, dan Konkordansi.

| Pintasan        | Tindakan                                 |
| --------------- | -------------------------------------- |
| `← Left Arrow`  | Memilih kategori sebelumnya dalam sebuah diagram |
| `→ Right Arrow` | Memilih kategori berikutnya dalam sebuah diagram     |

Kapsi di bawah diagram mengikuti pilihan itu, dan nilai barunya dibacakan.

## Menu utama (saat terbuka)

| Pintasan       | Tindakan                  |
| -------------- | ----------------------- |
| `↑ Up Arrow`   | Butir menu sebelumnya      |
| `↓ Down Arrow` | Butir menu berikutnya          |
| `Return`       | Memilih butir yang disorot |
| `Escape`       | Menutup menu              |

## Pengaturan

| Pintasan | Tindakan                    |
| -------- | ------------------------- |
| `Escape` | Menutup jendela munculan / pemilih yang terbuka |

## Jendela Penyunting

| Pintasan  | Tindakan         |
| --------- | -------------- |
| `Cmd + S` | Simpan           |
| `Escape`  | Batal / tutup |

## Penjaga pengetikan

Saat Anda berfokus di sebuah kolom teks (kotak pencarian, penyunting catatan, masukan AI), pintasan non-Cmd seperti tombol panah dan `Space` ditekan agar tidak secara tak sengaja memicu navigasi. Pintasan yang memakai tombol `Cmd` (mis., `Cmd + S`, `Cmd + B`) tetap bekerja saat mengetik.
