---
title: Pertanyaan yang Sering Diajukan
level: everyday
categories: faq
summary: Jawaban atas pertanyaan-pertanyaan paling umum tentang pemakaian Theodia.
---

# Pertanyaan yang Sering Diajukan

## Apakah Theodia berbayar?

Theodia dibayar sekali saja. Tidak ada langganan, tidak ada iklan, tidak ada pembelian dalam aplikasi, dan tidak ada permintaan donasi. Semua sumber daya tambahan yang tersedia dalam katalog gratis diunduh setelah Anda membeli aplikasinya.

## Apakah saya membutuhkan koneksi internet?

Tidak. Setelah aplikasi dan berkas datanya terpasang, semuanya bekerja luring. Anda bisa membaca, mencari, menyorot, membuat catatan, dan memakai sebagian besar alat studi tanpa sinyal.

Satu-satunya fitur yang membutuhkan internet adalah mengunduh sumber daya baru.

## Di mana data saya disimpan?

Semua penanda, sorotan, catatan, dan setelan Anda tersimpan di perangkat Anda. Semuanya tidak diunggah ke server mana pun.

Anda bisa mencadangkannya secara manual. Lihat panduan [Mencadangkan Data Anda](theodia://help/backups) untuk caranya.

## Bisakah saya mendengarkan Alkitab dibacakan?

Bisa. Buka pasal mana pun, ketuk menunya, dan pilih opsi pembacaan tegak. Perangkat Anda harus memiliki suara teks-ke-suara yang terpasang. Lihat panduan [Membaca Tegak](theodia://help/tts) untuk selengkapnya.

## Bagaimana cara mencari sebuah ayat?

Anda bisa mengetik sebuah referensi seperti `John 3:16` ke kotak Perintah di layar beranda, atau memakai tab **Pencarian** untuk mencari berdasarkan kata atau frasa.

## Bagaimana melaporkan kutu atau mengusulkan fitur?

Ketuk **Kirim Saran / Masalah** di layar Tentang, [laporkan di GitHub](https://github.com/ecodiallc/theodia.app/issues/new), atau kunjungi halaman [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions).

## Perangkat apa saja yang didukung?

Theodia berjalan di iPhone, iPad, serta ponsel dan tablet Android. Aplikasi bekerja paling baik di perangkat dengan setidaknya 2 GB penyimpanan bebas untuk berkas data inti.

## Bisakah saya memakai papan ketik eksternal?

Bisa. Theodia mendukung papan ketik Bluetooth dan USB di iPad. Navigasi, pencarian, dan banyak fitur membaca memiliki pintasan papan ketik. Lihat panduan [Pintasan Papan Ketik Eksternal](theodia://help/external-keyboard-shortcuts) untuk daftar lengkapnya.

## Bahasa apa saja yang didukung?

Antarmuka aplikasi tersedia dalam bahasa Inggris, Arab, Mandarin (Sederhana dan Tradisional), Ceko, Denmark, Belanda, Filipina, Prancis, Jerman, Yunani, Ibrani, Hindi, Indonesia, Italia, Jepang, Korea, Polandia, Portugis (Brasil), Rumania, Rusia, Spanyol, Swahili, Swedia, Thai, Turki, Ukraina, dan Vietnam.

Bahasa teks Alkitab bergantung pada terjemahan mana yang Anda pasang.

## Bagaimana cara mengganti bahasa?

Pergi ke **Pengaturan** dan cari opsi bahasanya.

## Pertanyaan saya tidak ada di sini. Di mana saya bisa mendapat bantuan lagi?

Telusuri panduan-panduan bantuan lainnya menurut topik, atau ajukan sebuah pertanyaan di komunitas [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions).

Tips: Di layar utama **Bantuan & Panduan**, gunakan kotak pencarian untuk mengetik sebuah topik seperti `notifications` atau `search` guna menemukan panduan yang cocok.
