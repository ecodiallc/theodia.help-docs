---
title: Membaca Pasal Pertama Anda
level: beginner
categories: [start, read]
summary: Panduan langkah demi langkah membuka dan membaca sebuah pasal.
---

# Membaca Pasal Pertama Anda

Panduan ini menuntun Anda membuka sebuah pasal untuk pertama kalinya.

## Langkah 1: Buka tab Alkitab

Lihat bagian bawah layar. Anda akan melihat deretan tab. Ketuk yang bertuliskan **Alkitab**.

## Langkah 2: Pilih sebuah buku

Anda akan melihat daftar kitab Alkitab. Kejadian ada di awal. Yohanes ada di dekat tengah. Wahyu ada di akhir.

Ketuk nama buku yang Anda inginkan.

## Langkah 3: Pilih sebuah pasal

Anda akan melihat angka 1 sampai sebanyak pasal yang dimiliki buku itu. Ketuk pasal yang Anda inginkan.

Pasal terbuka. Ayat-ayatnya ada di layar.

## Langkah 4: Berpindah-pindah

- Geser ke **kiri** untuk pindah ke pasal berikutnya.
- Geser ke **kanan** untuk kembali.

## Langkah 5: Berinteraksi dengan sebuah ayat

Apa yang bisa Anda lakukan pada sebuah ayat tergantung mode pengguna Anda.

### Mode Pembaca (Reader)

Mode Pembaca bersih dan bebas gangguan.

- Ketuk sebuah ayat untuk menyorotnya sebentar.
- Tidak ada alat belajar, penanda halaman, atau menu.
- Jika Anda ingin lebih banyak fitur, beralihlah ke mode **Standar** atau **Pelajar** di **Pengaturan**.

### Mode Standar (Standard)

Mode Standar menambahkan fitur harian untuk belajar Alkitab pribadi.

Ketuk sebuah ayat untuk membuka menu dengan opsi berikut:

- **Menandai** ayat itu (bookmark).
- **Menyorotnya** dengan sebuah warna.
- **Menambahkan catatan** padanya.
- **Menyalin** teks ayat.
- **Membandingkan** ayat dalam terjemahan lain.
- **Mencari referensi silang** untuk ayat itu.

### Mode Pelajar (Scholar)

Mode Pelajar membuka semua alat untuk studi Alkitab mendalam.

Ketuk sebuah ayat untuk membuka menu berisi semuanya di mode Standar, ditambah:

- **Komentar** tentang ayat itu.
- **Info Kata** dan pencarian bahasa asli.
- **Definisi Kamus**.
- **Asisten AI** untuk studi yang lebih mendalam.

Anda bisa mengganti mode kapan saja di **Pengaturan**.

## Butuh bantuan dengan alat tertentu?

Setiap alat memiliki panduannya sendiri. Ketuk **Bantuan** di beranda untuk melihat semuanya. Panduan [Mode Studi](theodia://help/study-mode) adalah tempat mulai yang bagus — panduan itu menuntun melalui setiap alat di menu ayat.

Jika Anda masih belajar letak berbagai hal, lihat panduan [Tata Letak dan Navigasi Aplikasi](theodia://help/navigating-the-app). Panduan itu menjelaskan layar beranda, menu utama, dan bilah alat bawah.

## Ingin sumber daya lebih banyak?

Aplikasi ini dilengkapi beberapa versi Alkitab yang tersedia bebas. Jika Anda ingin menambahkan lebih banyak, atau menambahkan komentar, buku, atau renungan, lihat panduan [Mendapatkan Sumber Daya Tambahan dari GitHub](theodia://help/getting-core-files). Panduan itu menunjukkan di mana menemukannya dan cara menambahkannya.
