---
title: Mode Fokus
level: beginner
categories: [layout, read]
summary: Cara bersih tanpa gangguan untuk membaca bagian yang panjang.
---

# Mode Fokus

> **Mode:** Mode Fokus adalah pembaca di mode **Pembaca (Reader)**. Mode ini juga tersedia di mode **Standar** dan **Pelajar** sebagai alternatif Mode Studi. Anda bisa mengganti mode di **Pengaturan** → **Mode Pengguna Aplikasi**.

Mode Fokus adalah cara membaca pasal Alkitab tanpa tombol atau menu yang mengganggu. Mode ini bagus untuk sesi membaca yang panjang.

## Cara menyalakannya

1. Buka pasal mana pun.
2. Di deretan ikon di bagian atas layar, ketuk tombol 📖. Tombol itu membuka pasal yang sama dalam Mode Fokus.
3. Menu dan tombol disembunyikan. Hanya teks Alkitab yang tersisa.

Di mode **Pembaca**, pasal terbuka dalam Mode Fokus secara otomatis. Tombol 📖 disembunyikan karena tidak ada Mode Studi untuk dituju.

## Apa yang bisa Anda lakukan di Mode Fokus

- **Gulir** untuk membaca.
- **Geser** untuk pindah ke pasal berikutnya atau sebelumnya.
- **Ketuk tombol 📖** di bilah bawah untuk kembali ke Mode Studi. (Tersembunyi di mode Pembaca.)
- **Ketuk tombol 🔊** di bilah bawah untuk membacakan pasal. Bilah kontrol mini muncul berisi putar, jeda, mundur, maju cepat, dan pemilih suara. (Tersembunyi di mode Pembaca — TTS membutuhkan Standar atau Pelajar.)

## Penggunaan yang baik untuk Mode Fokus

- Membaca satu kitab utuh, satu pasal demi satu pasal.
- Membaca bagian panjang untuk renungan atau waktu tenang.
- Membacakan tegak dan mengikuti bacaan tanpa gangguan.

## Beralih ke Mode Studi

Mode Fokus menyembunyikan semua alat belajar, tetapi semuanya hanya satu ketukan jauhnya. Ketuk tombol 📖 di bagian atas layar untuk membuka pasal yang sama dalam [Mode Studi](theodia://help/study-mode). Mode Studi adalah pembaca penuh, dengan komentar, referensi silang, pencarian leksikon, dan catatan. Untuk mengetahui apa yang bisa dilakukan Mode Studi, lihat panduan [Mode Studi](theodia://help/study-mode).

Di mode **Pembaca**, tombol 📖 disembunyikan karena Mode Studi tidak tersedia.
