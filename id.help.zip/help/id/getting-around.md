---
title: Berpindah Tempat dengan Cepat
level: beginner
categories: layout
summary: Semua cara cepat untuk melompat ke ayat, pasal, atau layar di Theodia.
---

# Berpindah Tempat dengan Cepat

Panduan ini adalah lembar contekan untuk navigasi. Panduan ini mencakup semua cara cepat berpindah dari tempat Anda sekarang ke tempat yang Anda tuju.

## Langsung melompat ke sebuah ayat

Cara tercepat membuka ayat mana pun adalah dengan **Perintah (Command)** di layar beranda.

- Ketik `John 3:16` lalu ketuk Mulai (Go).
- Ketik `Psalms 23` lalu ketuk Mulai (Go).
- Ketik `Genesis 1` lalu ketuk Mulai (Go).

Aplikasi membuka pasal tepat itu (dan menggulir ke ayatnya jika Anda menyertakannya).

## Geser antar pasal

Saat Anda membaca sebuah pasal:

- **Geser ke kiri** → pasal berikutnya.
- **Geser ke kanan** → pasal sebelumnya.

Ini berlaku lintas kitab. Setelah Keluaran 40, menggeser ke kiri membawa Anda ke Imamat 1.

## Gunakan bilah atas

Saat membaca, bagian atas layar menampilkan **terjemahan**, **kitab**, dan **pasal** saat ini.

- Ketuk nama terjemahan untuk mengganti Alkitab.
- Ketuk nama kitab untuk memilih kitab lain.
- Ketuk nomor pasal untuk memilih pasal lain.

## Melompat dari penanda halaman

Jika Anda pernah menyimpan sebuah ayat:

1. Buka tab **Penanda**.
2. Ketuk entri mana pun.
3. Anda langsung menuju ayat itu.

## Melompat dari pencarian

1. Buka tab **Pencarian**.
2. Ketik sebuah kata atau frasa.
3. Ketik salah satu hasil.
4. Aplikasi membuka pasal dengan kata-kata pencarian Anda disorot berwarna kuning.

## Mengganti tata letak bacaan

Pembaca Alkitab memiliki dua tata letak:

- **Mode Studi** — menampilkan pasal dengan semua alat belajar hanya satu ketukan jauhnya.
- **Mode Fokus** — menyembunyikan semua alat dan menu, menyisakan hanya teksnya.

Untuk berganti: ketuk tombol **📖** di bagian atas layar saat membaca. Ketuk lagi untuk kembali. (Mode Pembaca selalu tetap di Mode Fokus.)

## Gunakan tab bawah

Deretan ikon di bagian bawah layar selalu terlihat. Ketuk tab mana pun untuk beralih ke bagian itu. Tab yang persis ada tergantung mode pengguna Anda:

**Semua mode:**

- **Beranda** — kembali ke layar beranda.
- **Alkitab** — daftar terjemahan.
- **Pencarian** — cari di Alkitab, buku, kamus, leksikon, dan PDF.
- **Pengaturan** — preferensi dan sumber daya.

**Standar dan Pelajar juga melihat:**

- **Penanda** — ayat tersimpan.
- **Sorotan** — ayat bertanda warna.
- **Catatan** — catatan pribadi Anda.
- **PDF** — dokumen PDF yang Anda impor.

**Pelajar juga melihat:**

- **AI** — asisten AI (jika dinyalakan di Pengaturan).

### Mengingat tempat Anda berhenti

Setiap tab menyimpan riwayat navigasinya sendiri. Saat Anda kembali ke sebuah tab, Anda kembali ke **tempat Anda berhenti**, bukan layar awal bagian itu.

- Anda membuka tab **Alkitab**, memilih sebuah terjemahan, membuka sebuah pasal, lalu beralih ke **Pencarian**. Nanti Anda mengetuk **Alkitab** lagi dan Anda langsung kembali ke pasal yang sama.
- Anda membuka tab **Penanda**, mengetuk sebuah ayat yang ditandai, lalu beralih ke **Pengaturan**. Mengetuk **Penanda** lagi mengembalikan Anda ke daftar penanda.

Ini berlaku untuk setiap tab. Setiap tab mengingat posisi Anda sampai Anda secara eksplisit bernavigasi ke layar berbeda di dalam tab itu.

### Apa yang mereset sebuah tab

Sebuah tab kembali ke layar akarnya hanya jika:

- Anda sudah berada di tab itu dan mengetuk ikon tab yang sama sekali lagi. Ini cara cepat meresetnya ke awal.
- Aplikasi dipaksa menutup lalu dibuka kembali.

### Tab bawah vs. menu utama

- **Tab bawah** — setiap tab menyimpan tumpukannya sendiri. Mengetuk sebuah tab mengembalikan Anda ke tempat Anda berhenti.
- **Menu utama** — mengetuk sebuah item menavigasi ke layar itu. Ini adalah daftar dropdown, bukan overlay.

Contoh:

- Anda sedang membaca Yohanes 3. Ketuk tab **Penanda**, lalu ketuk **Alkitab** lagi. Anda kembali ke Yohanes 3.
- Anda sedang membaca Yohanes 3. Buka menu dan ketuk **Catatan**. Tinjau catatan Anda, lalu ketuk tab **Alkitab** untuk kembali ke Yohanes 3.

## Tips

- Layar beranda mengingat bagian mana yang sedang dibuka atau dilipat.
- Jika sebuah tab tidak ada, periksa **mode pengguna** Anda di **Pengaturan** → **Mode Pengguna Aplikasi**. Mode Pembaca menyembunyikan penanda, sorotan, catatan, dan AI. Mode Standar menyembunyikan AI. Anda mungkin juga perlu mengaktifkan sebuah fitur di **Pengaturan** atau memasang sebuah sumber daya.
