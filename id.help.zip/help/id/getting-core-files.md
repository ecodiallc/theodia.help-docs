---
title: Mendapatkan Sumber Daya Tambahan
level: everyday
categories: resources
summary: Cara menambahkan Alkitab, komentar, buku, dan sumber daya lain ke Theodia.
---

# Mendapatkan Sumber Daya Tambahan

Theodia hadir dengan beberapa sumber daya bawaan, tetapi Anda bisa menambahkan lebih banyak. Cara termudah adalah melalui layar **Kelola Sumber Daya** di dalam aplikasi.

## Apa saja yang bisa ditambahkan

- **Alkitab** — lebih banyak terjemahan dalam bahasa-bahasa berbeda
- **Komentar** — catatan studi yang menjelaskan ayat-ayat
- **Buku** — karya klasik Kristen dan buku rujukan
- **Renungan** — bacaan renungan harian
- **Berkas inti** — berkas data besar seperti morfologi, referensi silang, dan Marvel Interlinear Bible (MIB)

## Cara menambahkan sumber daya dari dalam aplikasi

1. Buka **Pengaturan**.
2. Ketuk **Kelola Sumber Daya**.
3. Pilih sebuah tab: **Inti**, **Alkitab**, **Komentar**, **Buku**, atau **Renungan**.
4. Telusuri daftarnya. Ketuk sebuah sumber daya untuk membaca lebih lanjut tentangnya.
5. Ketuk kotak centang untuk memilih yang Anda inginkan.
6. Ketuk **Unduh** di bagian bawah. Berkas-berkasnya diunduh dan dipasang secara otomatis.

Setelah terpasang, sumber daya itu langsung muncul di aplikasi. Anda tidak perlu memulai ulang.

## Berkas inti

Tab **Inti** memiliki berkas-berkas data besar yang mendukung fitur studi yang lebih mendalam. Ini meliputi:

- Data morfologi (bentuk kata dalam bahasa asli)
- Basis data referensi silang
- Marvel Interlinear Bible (MIB)

Anda hanya perlu mengunduh berkas inti sekali. Berkas tetap berada di perangkat Anda dan bekerja luring.

## Alkitab Global

Tab **Alkitab Global** memiliki terjemahan-terjemahan Alkitab dari koleksi yang lebih luas. Jika Anda tidak melihat terjemahan yang Anda inginkan di tab **Alkitab** utama, periksa di sini.

## Mengelola sumber daya yang terpasang

Pada layar utama **Kelola Sumber Daya** (bukan tab unduhan), Anda bisa:

- **Menyalakan atau mematikan** sebuah sumber daya tanpa menghapusnya. Sumber daya yang dimatikan tetap berada di perangkat Anda tetapi disembunyikan dari menu.
- **Menghapus** sebuah sumber daya untuk membebaskan ruang. Anda bisa mengunduhnya lagi nanti.

## Menambahkan berkas Anda sendiri

Jika Anda memiliki berkas sumber daya dari tempat lain — dari seorang teman, proyek lain, atau sebuah situs web — Anda bisa mengimpornya langsung:

1. Di **Kelola Sumber Daya**, ketuk **Impor Berkas Lokal**.
2. Pilih berkasnya dari perangkat Anda.
3. Aplikasi membaca berkas itu dan menambahkannya ke pustaka Anda.

Aplikasi menerima jenis berkas berikut:

- `.bible` — terjemahan Alkitab
- `.commentary` — komentar
- `.lexicon` — leksikon
- `.book` — buku
- `.devotional` — renungan

## Menghubungkan repositori GitHub khusus

Jika seseorang memelihara repositori GitHub berisi sumber daya yang kompatibel dengan Theodia, Anda bisa menambahkannya sebagai sumber khusus:

1. Pergi ke **Pengaturan → Repositori GitHub**.
2. Ketuk **Tambah Repositori**.
3. Masukkan URL GitHub-nya (misalnya, `https://github.com/username/repo-name`).
4. Pilih jenis sumber daya apa saja yang dimuat repositori itu (Alkitab, komentar, atau buku).
5. Simpan.
6. Kembali ke **Kelola Sumber Daya**. Tab baru muncul berisi sumber daya-sumber daya dari repositori itu.

Jika repositorinya privat, Anda perlu menambahkan **Personal Access Token** di **Pengaturan → Repositori GitHub** agar aplikasi bisa membacanya.

## Catatan tentang ukuran berkas

Berkas sumber daya bisa berukuran besar. Alkitab biasanya kecil (beberapa megabita). Komentar dan berkas inti bisa jauh lebih besar (ratusan megabita). Unduh melalui Wi-Fi bila memungkinkan.

## Ringkasan

- Gunakan **Pengaturan → Kelola Sumber Daya** untuk menelusuri dan memasang sumber daya.
- Berkas inti membuka alat studi yang lebih mendalam seperti morfologi dan referensi silang.
- Impor berkas lokal jika Anda memiliki berkas sendiri.
- Tambahkan repositori GitHub khusus jika Anda menginginkan sumber daya dari sumber lain.
