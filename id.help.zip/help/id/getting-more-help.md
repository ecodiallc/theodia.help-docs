---
title: Tempat Mengajukan Pertanyaan
level: everyday
categories: trouble
summary: Cara mendapatkan bantuan dari tim dan komunitas Theodia, dan cara menemukan topik bantuan di dalam aplikasi.
---

# Tempat Mengajukan Pertanyaan

Jika Anda terjebak, ada beberapa tempat untuk meminta bantuan.

## Menemukan sebuah topik bantuan

Jika Anda mencari informasi tentang sebuah fitur tertentu, coba salah satu jalan ini:

- **Telusuri menurut kategori.** Buka **Bantuan & Panduan** dan ketuk sebuah kategori seperti **Pengaturan & Kustomisasi** atau **Pemecahan Masalah**. Setiap kartu mencantumkan panduan-panduan terkait.
- **Cari menurut kata kunci.** Di layar utama **Bantuan & Panduan**, ketik sebuah kata di kotak pencarian di bagian atas. Misalnya, mengetik `notifications` menampilkan panduan [Pemberitahuan dan Pengingat](theodia://help/notifications); mengetik `search` menampilkan panduan [Mencari di Alkitab](theodia://help/search-the-bible).
- **Periksa Pengaturan lebih dulu.** Banyak fitur dikonfigurasi di **Pengaturan**. Jika Anda ingin menyiapkan pengingat, buka **Pengaturan** → **Pemberitahuan**. Layar pengaturan juga memiliki tautan **Bantuan** untuk setiap bagian.

## Di dalam aplikasi

Buka layar **Tentang**. Anda akan melihat dua tombol:

- **Kirim Saran / Masalah** — membuka formulir untuk mengirim pertanyaan, gagasan, atau laporan kutu kepada tim.
- **Diskusi / Umpan Balik** — membuka papan diskusi komunitas.

## Halaman GitHub

Anda bisa melihat daftar masalah yang diketahui dan perubahan terbaru di [GitHub](https://github.com/ecodiallc/theodia.app).

## Diskusi komunitas

Orang-orang lain yang memakai Theodia mengajukan pertanyaan dan berbagi tips di [papan diskusi komunitas](https://github.com/ecodiallc/theodia.app/discussions). Anda bisa membaca utas-utas lama dan memulai yang baru.

## Sebelum Anda bertanya

Beberapa hal membantu kami menjawab Anda lebih cepat:

- **Apa perangkat Anda?** (mis. iPhone 13, Pixel 7)
- **Versi aplikasi berapa?** (Buka **Tentang** untuk melihatnya.)
- **Apa yang Anda lakukan?** Deskripsi singkat langkah-langkahnya.
- **Apa yang terjadi?** Apa yang Anda lihat di layar.
- **Apa yang Anda harapkan terjadi?** Ini sering kali bagian yang paling berguna.

## Apa yang bisa diharapkan

- Untuk laporan kutu, tim biasanya membalas dalam beberapa hari.
- Untuk gagasan, tim membacanya semua. Kami tidak bisa menjanjikan kapan sebuah gagasan akan ditambahkan.
- Untuk pertanyaan komunitas, pengguna lain sering membalas lebih cepat daripada tim.

## Catatan tentang privasi

Saat Anda mengirimkan sebuah pertanyaan, mohon jangan sertakan informasi pribadi. Tim bisa melihat apa yang Anda kirim.
