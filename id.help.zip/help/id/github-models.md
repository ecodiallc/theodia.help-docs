---
title: GitHub Models
categories: ai
level: advanced
summary: Siapkan GitHub Models — cara gratis untuk mulai menjelajah AI di Theodia tanpa langganan API yang sudah ada.
---

# GitHub Models

> **Mode:** Asisten AI membutuhkan mode **Pelajar**. Anda bisa mengganti mode di **Pengaturan** → **Mode Pengguna Aplikasi**.

Jika Anda belum membayar sebuah layanan AI, **GitHub Models** adalah cara termudah untuk mulai menjelajah AI Theodia. Ini memungkinkan awal yang gratis, dan Anda hanya butuh akun GitHub gratis.

## Apa itu GitHub Models?

GitHub Models adalah layanan dari GitHub yang memungkinkan Anda menjalankan model-model AI modern melalui sebuah API. Layanan ini mendukung format yang sama dengan OpenAI, sehingga bekerja mulus dengan Theodia.

## Mengapa memilih GitHub Models?

- **Tanpa kartu kredit** — Cukup akun GitHub.
- **Model berkualitas tinggi** — Anda mendapat akses ke GPT-4o, GPT-4.1, dan model andal lain yang mendukung alat-alat Theodia.
- **Penyiapan mudah** — Satu token, satu URL, dan selesai.

## Langkah 1: Membuat akun GitHub

Jika Anda sudah punya akun GitHub, lewati ke Langkah 2.

1. Pergi ke [github.com](https://github.com).
2. Ketuk **Sign up** dan ikuti petunjuk untuk membuat akun gratis.
3. Verifikasi alamat email Anda ketika GitHub mengirim konfirmasinya.

## Langkah 2: Membuat Personal Access Token

Token ini adalah kunci API Anda. Token memberi tahu GitHub siapa Anda saat Theodia mengirim pertanyaan.

1. Pergi ke [github.com/settings/tokens](https://github.com/settings/tokens).
2. Ketuk **Generate new token** dan pilih **Generate new token (classic)**.
3. Beri token itu nama seperti **Theodia AI**.
4. Di bagian **Select scopes**, centang kotak **`models:read`**.
   - Ini satu-satunya izin yang dibutuhkan Theodia.
5. Gulir ke bagian bawah dan ketuk **Generate token**.
6. **Salin tokennya segera.** GitHub hanya menampilkannya sekali. Tempelkan di tempat aman (seperti aplikasi catatan ponsel Anda) sampai Anda menambahkannya ke Theodia.

## Langkah 3: Memilih model

GitHub Models menawarkan beberapa model. Untuk Theodia, berikut pilihan terbaiknya:

| Model                 | Batas Gratis Harian | Paling Cocok Untuk                                |
| --------------------- | ------------------ | --------------------------------------------- |
| `openai/gpt-4.1-nano` | 150 permintaan/hari | Pertanyaan singkat dan penjelasan ayat sederhana |
| `openai/gpt-4.1-mini` | 150 permintaan/hari | Studi umum dengan dukungan alat yang baik        |
| `openai/gpt-4.1`      | 50 permintaan/hari  | Studi lebih mendalam dan pertanyaan multi-langkah yang rumit |
| `openai/gpt-4o`       | 50 permintaan/hari  | Serbaguna, dukungan alat yang sangat baik        |

Mulailah dengan **`openai/gpt-4.1-mini`** — model ini cepat, andal, dan menawarkan batas permintaan harian yang lebih tinggi.

## Langkah 4: Mengonfigurasi Theodia

1. Buka **Theodia**.
2. Pergi ke **Pengaturan** → **Asisten AI**.
3. Pastikan **Model jarak jauh** terpilih.
4. Ketuk menu tarik-turun **Penyedia** dan pilih **GitHub Models**.
   - Jika GitHub Models tidak ada dalam daftar, ketuk **Khusus** dan masukkan URL dasar secara manual: `https://models.github.ai`
5. Tempelkan GitHub Personal Access Token Anda ke kolom **Kunci API**.
6. Masukkan ID model pilihan Anda di kolom **Model** (misalnya: `openai/gpt-4.1-mini`).
7. Ketuk **Uji koneksi**.
8. Tunggu pemeriksaannya selesai. Anda seharusnya melihat:
   - **✓ Koneksi berhasil**
   - **✓ Alat didukung**

Jika Anda melihat **✗ Alat tidak didukung**, coba ID model lain dari tabel di atas.

## Langkah 5: Mulai mengobrol

1. Ketuk tab **AI** di bagian bawah layar.
2. Ketik sebuah pertanyaan dan ketuk **Kirim**.
3. Atau, saat membaca pasal Alkitab mana pun, ketuk sebuah nomor ayat dan pilih **Komentar AI** untuk memulai obrolan khusus ayat.

## Pemecahan masalah

### "Koneksi gagal" atau "HTTP 401"

- Pastikan Anda menyalin **seluruh** token. Token adalah untai panjang yang diawali `ghp_`.
- Token kedaluwarsa jika lama tidak dipakai. Kembali ke GitHub dan buat yang baru.
- Periksa bahwa Anda memilih **models:read** saat membuat token.

### "Alat tidak didukung"

- Beberapa model di GitHub Models tidak menerima panggilan alat. Coba **`openai/gpt-4o`** atau **`openai/gpt-4.1-mini`** sebagai gantinya.
- Pastikan ID model dieja persis seperti yang ditampilkan, termasuk awalan `openai/`.

### Kesalahan batas laju

- Jika Anda mencapai batas harian, beralihlah ke model dengan jatah lebih besar (seperti `openai/gpt-4.1-nano` dengan 150 permintaan per hari).
- Batas diatur ulang setiap 24 jam.

## Ringkasan

- GitHub Models adalah **cara yang direkomendasikan untuk mulai menjelajah AI** di Theodia.
- Anda membutuhkan **akun GitHub gratis** dan **Personal Access Token** dengan `models:read`.
- Model pemula terbaik adalah **`openai/gpt-4.1-mini`**.
- Masukkan token dan modelnya di **Pengaturan → Asisten AI**, ketuk **Uji koneksi**, dan mulailah mengobrol.
