---
title: Menyorot Ayat
level: everyday
categories: [annotate, read]
summary: Cara menandai ayat dengan warna dan menemukannya kembali.
---

# Menyorot Ayat

> **Mode:** Sorotan tersedia di mode **Standar** dan **Pelajar**. Mode Fokus hanya untuk membaca yang bersih tanpa gangguan. Anda bisa mengganti mode di **Pengaturan** → **Mode Pengguna Aplikasi**.

Menyorot menandai sebuah ayat dengan sebuah warna. Cara kerjanya seperti stabilo kuning di atas kertas. Ayat tetap tersorot saat Anda membukanya berikutnya.

## Cara menyorot sebuah ayat

1. Buka ayatnya.
2. Ketuk ayat itu untuk memunculkan menu.
3. Ketuk ikon **Sorotan**.
4. Pilih sebuah warna.

Ayat kini tersorot dengan warna itu.

## Cara mengganti warna sorotan

1. Buka ayatnya.
2. Ketuk ayat itu, lalu ketuk ikon **Sorotan**.
3. Pilih warna baru.

## Cara menghapus sorotan

1. Buka ayatnya.
2. Ketuk ayat itu, lalu ketuk **Sorotan** di menu.
3. Ketuk **Hapus Sorotan** di bagian bawah pemilih warna.

## Cara umum menggunakan warna

Banyak pembaca memakai sedikit warna untuk sedikit keperluan:

- **Kuning** untuk favorit umum.
- **Hijau** untuk ayat-ayat tentang Allah.
- **Biru** untuk ayat-ayat tentang doa.
- **Merah muda** untuk ayat-ayat tentang penghiburan.
- **Oranye** untuk ayat-ayat tentang peringatan atau teguran.
- **Ungu** untuk ayat-ayat tentang nubuat atau akhir zaman.

Pilih sistem yang cocok bagi Anda.

## Cara melihat semua sorotan Anda

Ketuk tab **Sorotan** di bagian bawah. Anda melihat daftar setiap ayat yang telah Anda sorot, yang terbaru lebih dulu. Ada baris segmen warna di bagian atas — ketuk sebuah warna untuk menampilkan hanya sorotan dengan warna itu, atau ketuk **Semua** untuk menghapus penyaringan.

## Mengimpor sorotan

Anda bisa membawa sorotan ke Theodia dari aplikasi dan berkas lain.

Buka **Pengaturan** → **Penanda** → **Impor Sorotan**. Pilih **Impor dari Berkas** atau tempel dari papan klip. Aplikasi mendeteksi formatnya secara otomatis.

### Format yang didukung

**Ekspor JSON bawaan** — Format yang digunakan fitur ekspor milik Theodia sendiri:

```json
{
  "/bible/KJV/John/3#v3_16": "yellow",
  "/bible/KJV/Genesis/1#v1_1": "green"
}
```

**CSV** — Lembar sebar dengan kolom `url` dan `color`. Contoh:

```csv
url,color
/bible/KJV/John/3#v3_16,yellow
/bible/KJV/Genesis/1#v1_1,green
```

**Teks biasa** — Setiap baris berupa referensi Alkitab atau URL, secara opsional diikuti nama warna. Contoh:

```
John 3:16 yellow
Genesis 1:1 green
Matthew 5:1
```

- Warna yang tersedia: `yellow`, `green`, `blue`, `pink`, `orange`, `purple`.
- Jika tidak ada warna yang diberikan, sorotan menjadi kuning secara bawaan.
- Baris yang diawali `#` atau `//` diperlakukan sebagai komentar dan dilewati.

## Tips

- Sorotan tetap ada di perangkat Anda. Sorotan tidak tersinkron ke awan.
- Anda bisa menyorot sebuah ayat dalam satu terjemahan dan biarkan sorotan itu tampil di terjemahan lain Anda untuk ayat yang sama.
- Lihat panduan [Mencadangkan Data Anda](theodia://help/backups) untuk menjaganya tetap aman.
