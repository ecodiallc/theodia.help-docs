---
title: Memasang Terjemahan Alkitab
level: beginner
categories: start
summary: Cara menambahkan sebuah terjemahan Alkitab ke pustaka Anda.
---

# Memasang Terjemahan Alkitab

Theodia hadir dengan beberapa terjemahan Alkitab siap dibaca. Anda bisa menambahkan lebih banyak kapan saja. Sebuah "terjemahan" adalah versi lain dari teks Alkitab, seperti King James Version.

## Cara menambahkan sebuah terjemahan

Tab Alkitab menampilkan daftar terjemahan yang sudah terpasang. Untuk menambahkan lebih banyak, buka pengelola sumber daya:

1. Buka **Pengaturan**.
2. Ketuk **Kelola Sumber Daya**.
3. Ketuk **Pasang dari GitHub**.
4. Di jendela unduhan, ketuk tab **Alkitab**.
5. Ketuk kotak centang di sebelah setiap terjemahan yang Anda inginkan.
6. Ketuk **Pasang yang Dipilih** di bagian bawah.
7. Tunggu unduhannya selesai.

Terjemahan itu kini ada di pustaka Anda. Untuk melihatnya, buka tab **Alkitab**.

## Cara berganti-ganti terjemahan

1. Buka sebuah pasal yang ingin Anda baca.
2. Ketuk nama terjemahan di bagian atas layar.
3. Pilih yang Anda inginkan dari daftar.

Aplikasi menyimpan pilihan Anda untuk waktu berikutnya.

## Cara menghapus sebuah terjemahan

1. Buka **Pengaturan**.
2. Ketuk **Kelola Sumber Daya**.
3. Temukan terjemahan yang ingin Anda hapus.
4. Ketuk tanda **X** di sebelahnya.
5. Konfirmasikan bahwa Anda ingin menghapusnya.

Menghapus sebuah terjemahan tidak menghapus catatan, sorotan, atau penanda Anda. Semuanya tetap aman.

## Berapa banyak ruang yang dipakai terjemahan?

Sebagian besar terjemahan berukuran antara 2 dan 10 MB. Terjemahan tersimpan di perangkat Anda, bukan di awan. Anda bisa menyimpan sebanyak yang Anda suka, selama perangkat Anda masih punya ruang.

## Bagaimana jika sebuah terjemahan tidak ada di aplikasi?

Beberapa terjemahan tidak ada dalam daftar di dalam aplikasi. Anda tetap bisa menambahkannya.

1. Buka aplikasi dan pergi ke **Pengaturan** → **Kelola Sumber Daya**.
2. Ketuk **Pasang dari GitHub**.
3. Di jendela unduhan, lihat tab **Alkitab** dan tab **Alkitab Global**. Jika terjemahan Anda ada di sana, pilih dan ketuk **Pasang yang Dipilih**.
4. Jika tidak ada, ketuk **Pasang Berkas Lokal** untuk mengimpor sebuah berkas `.bible`. Dapatkan berkasnya dari halaman GitHub proyek. Lihat panduan [Mendapatkan Sumber Daya Tambahan dari GitHub](theodia://help/getting-core-files) untuk bantuan langkah demi langkah.
