---
title: Menambahkan Berkas Inti
level: beginner
categories: start
summary: Cara mengunduh berkas data besar yang dibutuhkan aplikasi untuk mempelajari Alkitab secara mendalam.
---

# Menambahkan Berkas Inti

Theodia hadir dengan sebuah Alkitab dan beberapa ekstra kecil yang siap dipakai. Untuk memanfaatkan aplikasi secara maksimal, Anda juga perlu mengunduh **berkas inti**. Ini adalah berkas-berkas data besar yang menambah alat studi seperti komentar, pencarian kata, dan catatan tata bahasa. Tanpa berkas itu, aplikasi tetap berfungsi, tetapi fitur studinya terbatas.

## Mengapa Anda membutuhkan berkas inti

Berkas inti menambahkan:

- **Pencarian kata.** Ketuk sebuah kata di ayat mana pun untuk melihat bahasa Ibrani atau Yunani aslinya dan artinya.
- **Komentar.** Komentar AI pada setiap ayat.
- **Tata bahasa.** Informasi tentang setiap kata dalam bahasa asli.
- **Alkitab interlinear.** Baca teks dalam bahasa asli dengan terjemahan Inggris di bawah setiap kata.

Anda bisa membaca Alkitab tanpa berkas itu, tetapi sebagian besar alat studi membutuhkannya.

## Cara memasang berkas inti

**[Pasang Berkas Inti](theodia://manage/core)**

1. Buka **Pengaturan**.
2. Ketuk **Kelola Sumber Daya**.
3. Tab **Inti** terbuka. Anda melihat daftar berkas-berkas inti. Setiap berkas memiliki nama, ukuran, dan kotak centang.
4. Ketuk setiap berkas yang ingin Anda pasang. Tanda centang menunjukkan bahwa berkas itu terpilih.
5. Ketuk **Pasang yang Dipilih**.
6. Tunggu berkas-berkasnya diunduh dan dipasang. Berkasnya besar, jadi ini bisa memakan waktu beberapa menit di koneksi yang lambat.

Berkas-berkasnya diunduh ke perangkat Anda. Anda hanya perlu melakukannya sekali. Aplikasi memakai berkas-berkas itu mulai saat itu, bahkan saat Anda luring.

## Tips

- Gunakan Wi-Fi. Berkasnya besar.
- Sambungkan ponsel atau tablet Anda ke pengisi daya. Unduhan besar menghabiskan baterai.
- Jika sebuah unduhan gagal, ketuk berkasnya lagi untuk mencoba ulang.
- Anda bisa memasang semuanya atau hanya yang Anda butuhkan.

## Bagaimana jika sebuah berkas hilang dari daftar?

Aplikasi menarik daftarnya dari halaman GitHub proyek. Jika daftarnya kosong, periksa koneksi internet Anda dan coba lagi. Jika masih kosong, lihat panduan [Tempat Mengajukan Pertanyaan](theodia://help/getting-more-help).

Untuk cara menambahkan sumber daya yang lebih lanjut, lihat panduan [Mendapatkan Sumber Daya Tambahan dari GitHub](theodia://help/getting-core-files).
