---
title: Bahasa dan Wilayah Aplikasi
level: everyday
categories: settings
summary: Cara mengganti bahasa aplikasi.
---

# Bahasa dan Wilayah Aplikasi

Theodia tersedia dalam banyak bahasa. Aplikasi bisa mengganti bahasa menu dan tombol. Konten bantuan juga tersedia dalam banyak dari bahasa-bahasa ini dan sudah terpasang di dalam aplikasi. Anda juga bisa mengunduh atau memperbarui paket bantuan sebuah bahasa — buka **Pengaturan** → **Bantuan** atau **Kelola Sumber Daya** → **Pasang dari GitHub** → **Dokumen bantuan**.

## Cara membuka setelan bahasa

1. Buka **Pengaturan**.
2. Ketuk **Bahasa**.

## Cara mengganti bahasa aplikasi

1. Di daftar **Bahasa**, ketuk bahasa yang Anda inginkan.
2. Aplikasi menerapkan bahasa baru itu dengan segera.

Pilihan yang Anda lihat bergantung pada bahasa-bahasa yang didukung aplikasi.

## Bagaimana bahasa dipilih saat pemasangan pertama

Saat Anda pertama kali memasang Theodia, aplikasi memilih sebuah bahasa berdasarkan setelan perangkat Anda. Anda bisa menggantinya kapan saja.

## Apa saja yang diterjemahkan

- Menu, tombol, dan label.
- Layar-layar pengaturan.
- Pesan kesalahan.
- Alat pencarian dan studi.

## Apa saja yang hanya dalam bahasa Inggris

- Sebagian isi buku dan renungan.

## Terjemahan Alkitab dan bahasa aplikasi

Bahasa aplikasi dan bahasa terjemahan Alkitab adalah dua hal yang berbeda. Anda bisa menjalankan aplikasi dalam bahasa Spanyol dengan Alkitab dalam bahasa Inggris, atau sebaliknya.

Untuk mengganti terjemahan Alkitab, lihat panduan [Memasang Terjemahan Alkitab](theodia://help/installing-bibles).

## Tips

- Jika sebuah tombol atau label kosong, aplikasi kehilangan sebuah terjemahan. Versi bahasa Inggrisnya biasanya ada sebagai cadangan.
- Jika Anda ingin membantu menerjemahkan aplikasi, lihat panduan [Tempat Mengajukan Pertanyaan](theodia://help/getting-more-help).
