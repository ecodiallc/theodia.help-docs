---
title: Menu Peluncur
level: everyday
categories: layout
summary: Cara cepat untuk melompat ke ayat terakhir, menjalankan perintah, dan mengganti tata letak Alkitab tanpa meninggalkan layar Anda saat ini.
---

# Menu Peluncur

> **Mode:** Menu Peluncur membutuhkan mode **Pelajar**. Anda bisa mengganti mode di **Pengaturan** → **Mode Pengguna Aplikasi**.

Menu Peluncur adalah panel akses cepat yang bisa Anda buka dari hampir semua tempat di aplikasi. Menu ini menyimpan ayat-ayat terakhir Anda, perintah, dan susunan Alkitab tersimpan dalam satu tempat.

## Cara membukanya

Ketuk **ikon perluas (⌄)** di pojok kanan atas kepala layar beranda. Sebuah panel masuk meluncur dari atas.

## Apa saja isinya

### 1. Kotak Perintah

Di bagian atas panel ada kotak teks dengan ikon papan ketik. Ketik sebuah perintah dan ketuk **Go** di papan ketik Anda. Aplikasi membaca perintahnya dan langsung membawa Anda ke sana.

Contoh:

- `John 3:16` — membuka ayat itu.
- `search love` — mencari "love" di Alkitab.
- `bookmark psalms 23` — menandai ayatnya.
- `kjv` — beralih ke terjemahan KJV.

Untuk daftar perintah lengkap, lihat panduan [Perintah](theodia://help/commands).

### 2. Set Paralel

Jika Anda menyimpan prasetel Alkitab paralel, semuanya muncul di sini sebagai daftar yang bisa dilipat. Ketuk salah satu untuk langsung memuat susunan paralel itu.

Cara membuat prasetel paralel:

1. Buka **Pengaturan** → **Alkitab Paralel**.
2. Tambahkan terjemahan dan ketuk **Simpan Prasetel**.
3. Beri nama. Prasetel akan muncul di Menu Peluncur.

Tekan lama sebuah set paralel di Menu Peluncur untuk menghapusnya.

### 3. Koleksi Alkitab

Koleksi Alkitab adalah pintasan satu ketukan yang mengganti terjemahan dan tampilan paralel Anda sekaligus. Jika Anda telah membuatnya, semuanya muncul di sini sebagai daftar yang bisa dilipat.

Tekan lama sebuah koleksi untuk menghapusnya.

### 4. Ikon Fitur

Di bawah kotak perintah Anda mungkin melihat deretan tombol emoji bulat. Ini adalah pintasan satu ketukan ke fitur-fitur utama aplikasi.

Ikon yang tersedia meliputi:

- **Tentang**, **Alkitab**, **Catatan Alkitab**, **Penanda**, **Buku**
- **Renungan**, **Kartu Hafalan**, **Bantuan**, **Sorotan**
- **Playlist**, **Plugin**, **Pencarian**, **Pengaturan**, **Theoscript**

Untuk memilih ikon mana yang muncul dan dalam urutan apa:

1. Buka **Pengaturan** → **Menu Peluncur**.
2. Ketuk **Ikon Menu Peluncur**.
3. Gunakan sakelarnya untuk menampilkan atau menyembunyikan setiap ikon.
4. Gunakan panah atas/bawah untuk mengurutkan ulang ikon yang Anda aktifkan.

Urutan di pengaturan adalah urutan kemunculannya di Menu Peluncur.

### 5. Ayat Terakhir

Aplikasi mengingat pasal dan ayat terakhir yang Anda buka. Semuanya muncul sebagai daftar di bagian bawah panel. Ketuk entri mana pun untuk langsung kembali ke sana.

- **Ketuk** untuk membuka.
- **Geser ke kiri** atau **tekan lama** untuk mengeluarkannya dari daftar.
- Ketuk **Bersihkan semua** untuk mengeluarkan setiap entri sekaligus.

## Kapan memakai Menu Peluncur

Gunakan saat Anda ingin:

- Kembali ke sebuah ayat yang baru Anda baca.
- Mengetik sebuah perintah tanpa pergi ke layar beranda.
- Mengganti terjemahan atau susunan paralel dalam satu ketukan.
- Membuka sebuah fitur utama dari mana saja di aplikasi.
- Memeriksa sesuatu dengan cepat tanpa menelusuri menu.

## Tips

- Menu Peluncur tersedia di hampir setiap layar, jadi Anda bisa membukanya saat membaca sebuah pasal.
- Kotak perintahnya mendukung perintah yang sama dengan kotak perintah di layar beranda.
- Ikon fitur dan urutannya tersimpan lokal di perangkat Anda. Semuanya bertahan melalui pemulaian ulang aplikasi.
- Ayat-ayat terakhir tersimpan lokal di perangkat Anda. Semuanya bertahan melalui pemulaian ulang aplikasi.
