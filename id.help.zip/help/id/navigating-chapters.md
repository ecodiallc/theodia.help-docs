---
title: Navigasi Antar Kitab, Pasal, dan Ayat
level: everyday
categories: [layout, read]
summary: Cara berkeliling di Alkitab dan melompat ke tempat yang Anda tuju.
---

# Navigasi Antar Kitab, Pasal, dan Ayat

Panduan ini menunjukkan semua cara berpindah-pindah di Alkitab.

## Cara mudah: menggeser

- Geser ke **kiri** pada sebuah pasal untuk pindah ke pasal berikutnya.
- Geser ke **kanan** untuk kembali.
- Ini berlaku untuk pindah kitab juga. Setelah pasal terakhir, misalnya, Keluaran, geseran membawa Anda ke pasal pertama Imamat.

## Cara menu

- Ketuk nama terjemahan di bagian atas untuk mengganti Alkitab.
- Ketuk nama kitab di bagian atas untuk memilih kitab lain.
- Ketuk nomor pasal untuk memilih pasal lain.

## Cara cepat: mengetik

- Di beranda, ada kotak di bagian atas. Ketik sebuah referensi, seperti `John 3:16` atau `psalms 23`, lalu ketuk tombol **Mulai (Go)** di papan ketik.
- Aplikasi membuka ayat itu.

## Cara penanda halaman

Jika Anda pernah menyimpan sebuah ayat, buka tab **Penanda**. Ketuk entri mana pun untuk melompat ke sana.

## Cara pencarian

Ketuk tab **Pencarian**. Ketik sebuah kata. Aplikasi menampilkan setiap ayat yang memuatnya. Ketuk salah satu hasil untuk membukanya.

## Cara riwayat

Aplikasi mengingat pasal-pasal yang telah Anda buka. Untuk menemukannya lagi, lihat di tab **Penanda** (untuk ayat yang pernah Anda simpan) atau gulir daftar kitab di tab **Alkitab** untuk menemukan kitab yang baru Anda baca.

## Tips

- Tab Alkitab menampilkan kitab berurutan dari Kejadian hingga Wahyu.
- Untuk Mazmur, Amsal, dan kitab panjang lainnya, ketuk kitabnya dan gunakan daftar pasal untuk melompat jauh ke depan.
