---
title: Tata Letak dan Navigasi Aplikasi
level: beginner
categories: layout
summary: Tur ke layar beranda, menu utama, dan bilah alat bawah — tempat semua hal berada.
---

# Tata Letak dan Navigasi Aplikasi

Theodia memiliki tiga area utama yang bisa Anda pindahi: **layar beranda**, **menu utama**, dan **bilah alat bawah**. Panduan ini menuntun melalui masing-masing agar Anda selalu tahu ke mana harus pergi.

## Peta singkat

- **Layar beranda** adalah halaman yang Anda lihat saat pertama kali membuka aplikasi. Berisi kotak pencarian, tombol besar untuk setiap bagian aplikasi, dan daftar Alkitab, buku, serta renungan yang Anda pasang.
- **Bilah alat bawah** (juga disebut bilah tab) adalah deretan ikon di bagian bawah layar. Ketuk salah satunya untuk langsung melompat ke bagian aplikasi itu.
- **Menu utama** adalah ikon dengan tiga garis (☰) di sudut kanan atas layar beranda. Ketuk untuk membuka daftar semua layar di aplikasi, termasuk yang tidak memiliki tab sendiri.

## Layar beranda

Saat pertama kali membuka Theodia, Anda mendarat di layar beranda. Layar ini terbagi menjadi empat bagian, dari atas ke bawah.

### Bagian kepala (header)

Di bagian paling atas ada bilah berwarna. Di kiri terdapat ikon aplikasi dan nama "Theodia." Di kanan terdapat tombol menu utama (☰). Saat Anda berada di dalam sebuah buku atau pasal, sisi kiri menampilkan tombol kembali (←). Ketuk menu utama untuk membuka menu (lihat di bawah).

### Perintah (Command)

Tepat di bawah header ada kotak teks bergaya pencarian berlabel **Perintah (Command)**. Ketik instruksi singkat dan ketuk tombol mulai di papan ketik Anda. Aplikasi membaca instruksi itu dan membawa Anda ke layar yang tepat. Contoh:

- `psalms 23` — membuka Mazmur pasal 23
- `john 3:16` — membuka Yohanes 3:16
- `search love` — mencari "love" di Alkitab
- `bookmark john 3:16` — menyimpan Yohanes 3:16 sebagai penanda halaman
- `commentary romans 8:28` — membuka komentar untuk ayat itu
- `xref` (diikuti sebuah referensi) — membuka referensi silang untuk ayat itu
- `help` — membuka daftar perintah beserta contohnya

Jika aplikasi tidak memahami yang Anda ketik, aplikasi menampilkan peringatan kecil berisi petunjuk. Lihat panduan **Masalah Umum** jika perintah tidak bekerja.

### Kisi tombol

Di bawah Perintah ada kisi tombol besar, dua per baris. Setiap tombol membawa Anda ke bagian aplikasi yang berbeda. Tombol-tombolnya adalah:

- 📖 **Alkitab** — daftar terjemahan Alkitab Anda
- 🔍 **Pencarian** — mencari kata atau frasa di Alkitab
- 📚 **Buku** — perpustakaan karya klasik Kristen Anda
- 📅 **Renungan** — renungan harian
- 🔖 **Penanda** — ayat dan pasal tersimpan Anda
- 🖍 **Sorotan** — ayat bertanda warna Anda
- 📝 **Catatan** — catatan pribadi Anda tentang ayat
- ⚙️ **Pengaturan** — bahasa, tema, sumber daya, dan lainnya
- ❓ **Bantuan** — sistem bantuan (halaman ini)
- ℹ️ **Tentang** — versi aplikasi dan kredit

### Daftar sumber daya

Di bawah kisi tombol ada bagian yang bisa dibuka: **Alkitab**, **Buku**, dan **Renungan**. Setiap bagian menampilkan item yang telah Anda pasang. Ketuk kepala bagian untuk membuka atau melipatnya. Ketuk item mana pun dalam sebuah bagian untuk membukanya.

Bagian Alkitab adalah cara tercepat melompat ke terjemahan tertentu — tanpa menu, cukup ketuk.

## Bilah alat bawah

Bilah alat bawah (bilah tab) adalah deretan ikon di bagian bawah layar. Bilah ini tetap terlihat hampir di mana saja di aplikasi, sehingga Anda selalu bisa melompat ke bagian lain. Tab yang Anda lihat tergantung mode pengguna Anda.

**Semua mode melihat:**

- 🏠 **Beranda** — membuka layar beranda
- 📖 **Alkitab** — membuka daftar terjemahan Alkitab Anda
- 📚 **Buku** — membuka perpustakaan buku Anda
- 🔍 **Pencarian** — membuka pencarian Alkitab
- ⚙️ **Pengaturan** — membuka pengaturan

**Mode Standar dan Pelajar juga melihat:**

- 🔖 **Penanda** — membuka ayat tersimpan Anda
- 🖍 **Sorotan** — membuka ayat bertanda warna Anda
- 📝 **Catatan** — membuka catatan pribadi Anda

**Mode Pelajar juga melihat:**

- 💻 **AI** — membuka asisten AI (jika Anda menyalakannya di Pengaturan)

Tab saat ini disorot. Ketuk tab lain untuk beralih.

### Cara bilah alat berperilaku

Setiap tab di bilah alat memiliki **tumpukan** layarnya sendiri. Saat Anda mengetuk sebuah tab, Anda kembali ke **tempat Anda berhenti** di tumpukan tab itu, bukan layar awal. Misalnya:

- Ketuk **Alkitab** → Anda melihat daftar terjemahan Alkitab.
- Ketuk sebuah terjemahan → Anda melihat daftar kitab.
- Ketuk sebuah kitab → Anda melihat daftar pasal.
- Ketuk sebuah pasal → Anda sedang membaca pasal itu.
- Beralih ke **Penanda** untuk memeriksa sesuatu.
- Ketuk **Alkitab** lagi → Anda kembali ke pasal yang sedang Anda baca.

Setiap tab mengingat posisi Anda. Aplikasi menyimpan riwayat navigasi Anda di dalam setiap tab, sehingga beralih antar tab tidak menghilangkan kemajuan Anda.

### Apa yang mereset sebuah tab

Sebuah tab hanya direset ke layar akarnya jika:

- Anda sudah berada di tab itu dan mengetuk ikon tab yang sama sekali lagi. Ini cara cepat kembali ke awal.
- Aplikasi dipaksa menutup lalu dibuka kembali.

### Tab bawah vs. menu utama

- **Tab bawah** — setiap tab menyimpan tumpukannya sendiri. Mengetuk sebuah tab mengembalikan Anda ke tempat Anda berhenti.
- **Menu utama** — mengetuk sebuah item menavigasi ke layar itu menggunakan sistem tab yang sama. Menu tidak terbuka sebagai overlay.

Gunakan tab untuk berganti tugas. Gunakan menu utama saat Anda menginginkan daftar lengkap semua layar di aplikasi.

### Kapan menggunakan bilah alat

Gunakan bilah alat saat Anda ingin berganti kegiatan:

- Anda sedang membaca sebuah pasal dan ingin mencari sesuatu yang lain → ketuk **Pencarian**.
- Anda sedang mencari dan ingin memeriksa penanda Anda → ketuk **Penanda**.
- Anda berada di mana saja di aplikasi dan ingin pulang ke beranda → ketuk **Beranda**.

## Menu utama

Menu utama adalah tombol dengan tiga garis bertumpuk (☰) di sudut kanan atas layar beranda. Ketuk dan sebuah panel meluncur masuk dari sisi kanan. Panel menampilkan setiap layar yang didukung mode Anda saat ini:

- 🏠 **Beranda**
- 📖 **Alkitab**
- 📚 **Buku**
- 🙏 **Renungan**
- 🔍 **Pencarian**
- 🔖 **Penanda** (Standar dan Pelajar)
- 🖍 **Sorotan** (Standar dan Pelajar)
- 📝 **Catatan** (Standar dan Pelajar)
- 💻 **Asisten AI** (hanya Pelajar, dan hanya jika AI dinyalakan)
- ⚙️ **Pengaturan**
- ❓ **Bantuan**
- ℹ️ **Tentang**

Item yang cocok dengan layar tempat Anda berada saat ini disorot dan memiliki titik kecil di sebelahnya. Ketuk item mana pun untuk langsung menujunya. Ketuk di luar panel, ikon X di atas, atau tombol kembali perangkat Anda untuk menutupnya tanpa berganti layar.

### Cara menu utama berbeda

Menu utama adalah panel dropdown, bukan lapisan navigasi terpisah. Saat Anda mengetuk sebuah item, aplikasi menavigasi ke layar itu dengan cara yang sama seolah Anda menggunakan tab bawah atau kisi tombol. Tumpukan tab Anda saat ini tetap terjaga, sehingga Anda bisa kembali ke tempat semula dengan mengetuk tab asli lagi.

Misalnya:

- Anda sedang membaca Yohanes 3. Anda mengetuk tab **Penanda**. Anda menuju penanda Anda. Saat Anda mengetuk **Alkitab** lagi, Anda kembali ke Yohanes 3 — tepat di tempat Anda berhenti.
- Anda sedang membaca Yohanes 3. Anda membuka menu utama dan mengetuk **Catatan**. Catatan Anda terbuka. Untuk kembali ke Yohanes 3, ketuk tab **Alkitab** dan Anda kembali ke pasal itu secara otomatis.

Tab mengganti konteks Anda dan mengingat posisi Anda. Menu utama hanyalah cara lain untuk mencapai layar yang sama.

### Kapan menggunakan menu utama

Gunakan menu utama saat:

- Anda ingin membuka **Sorotan**, **Catatan**, **Renungan**, **Bantuan**, atau **Tentang** — layar yang tidak memiliki tab bilah alat sendiri.
- Anda sedang jauh di dalam sebuah pasal atau pencarian dan ingin memeriksa sesuatu dengan cepat tanpa kehilangan posisi Anda.
- Anda ingin membuka **Pengaturan** tanpa meninggalkan layar tempat Anda berada.

## Mode Pelajar

Jika mode pengguna Anda disetel ke **Pelajar**, tata letak mendapatkan tab, item menu, dan alat pembaca tambahan yang disembunyikan oleh mode Pembaca dan Standar. Lihat panduan [Mode Pelajar](theodia://help/scholar-mode) untuk penuntunan lengkap setiap fitur.

## Bagaimana ketiga area saling terkait

- **Beralih ke bagian utama berbeda** (Alkitab, Pencarian, Penanda, dll.) → Bilah alat bawah
- **Melompat ke ayat atau perintah tertentu** → Perintah di layar beranda
- **Menelusuri semua layar yang tersedia** → Kisi tombol layar beranda
- **Memeriksa Catatan, Sorotan, atau Bantuan tanpa kehilangan posisi** → menu utama
- **Membuka Pengaturan dari mana saja** → menu utama atau bilah alat

Anda akan menggunakan ketiganya. Tidak ada yang "cara yang benar." Pilih mana yang paling mudah untuk kegiatan yang sedang Anda lakukan.

### Bilah alat vs menu utama: contoh singkat

Bayangkan Anda sedang membaca Roma 8 dan ingin menyorot sebuah ayat yang Anda sukai.

**Menggunakan bilah alat:**

1. Ketuk ayat untuk membuka menu ayat.
2. Ketuk **Sorotan** dan pilih warna.
3. Selesai. Anda tidak pernah meninggalkan pasal itu.

**Menggunakan menu utama (jika Anda ingin meninjau sorotan Anda):**

1. Ketuk ☰ untuk membuka menu.
2. Ketuk **Sorotan**. Daftar sorotan Anda terbuka.
3. Tinjau sorotan, lalu ketuk tab **Alkitab** untuk kembali ke Roma 8.

**Menggunakan bilah alat (jika Anda ingin berganti tugas):**

1. Ketuk **Beranda** atau **Penanda** di bilah alat.
2. Anda meninggalkan Roma 8 dan menuju layar baru.
3. Untuk kembali ke Roma 8, ketuk **Alkitab** lagi — Anda kembali ke pasal itu secara otomatis.

## Tips

- Layar beranda mengingat bagian mana yang sedang dibuka atau dilipat. Anda hanya perlu menyetelnya sekali.
- Jika Anda tidak melihat tab yang Anda harapkan, periksa dua hal:

1. **Mode pengguna Anda** — Mode Pembaca menyembunyikan penanda, sorotan, catatan, dan AI. Mode Standar menyembunyikan AI. Ganti mode di **Pengaturan** → **Mode Pengguna Aplikasi**.
2. **Setelan fitur** — beberapa tab perlu dinyalakan di **Pengaturan** (misalnya, asisten AI).
