---
title: Menulis Catatan
level: everyday
categories: [annotate, read]
summary: Cara menulis pemikiran Anda sendiri di samping sebuah ayat.
---

# Menulis Catatan

> **Mode:** Catatan tersedia di mode **Standar** dan **Pelajar**. Mode Fokus hanya untuk membaca yang bersih tanpa gangguan. Anda bisa mengganti mode di **Pengaturan** → **Mode Pengguna Aplikasi**.

Catatan adalah tempat Anda menulis pemikiran, doa, atau gagasan studi Anda sendiri di samping sebuah ayat. Setiap catatan terkait dengan ayat tertentu.

## Cara menambah catatan

1. Buka ayatnya.
2. Ketuk ayat itu untuk memunculkan menu.
3. Ketuk **Catatan** di menu. Ikonnya bergambar pensil.
4. Ketik catatan Anda.
5. Ketuk **Simpan**.

Catatan kini tersimpan bersama ayat itu.

## Cara membaca catatan

1. Buka ayatnya.
2. Perhatikan tanda pensil di sebelah ayat. Tanda itu berarti ada catatan.
3. Ketuk ayat itu. Catatan muncul di bawah.

## Cara mengubah catatan

1. Buka ayat yang ada catatannya.
2. Ketuk ayat itu.
3. Ketuk **Catatan** di menu.
4. Lakukan perubahan Anda.
5. Ketuk **Simpan**.

## Cara menghapus catatan

1. Buka ayat yang ada catatannya.
2. Ketuk ayat itu.
3. Ketuk **Catatan** di menu.
4. Ketuk **Hapus**.

## Cara melihat semua catatan Anda

Ketuk tab **Catatan** di bagian bawah. Anda melihat daftar setiap catatan yang telah Anda tulis, diurutkan menurut tanggal.

## Mencari di catatan Anda

Di tab **Catatan**, ketuk kotak **Cari**. Ketik sebuah kata. Aplikasi menemukan setiap catatan yang memuat kata itu.

## Tips

- Catatan sangat berguna untuk khotbah, renungan, dan pertanyaan studi.
- Catatan bersifat pribadi. Catatan tetap ada di perangkat Anda.
- Lihat panduan [Mencadangkan Data Anda](theodia://help/backups) untuk menjaganya tetap aman.
