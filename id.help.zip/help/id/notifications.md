---
title: Pemberitahuan dan Pengingat
level: everyday
categories: [settings]
summary: Cara menyalakan, menyesuaikan, dan mengelola pengingat luring untuk doa, renungan, rencana Alkitab, dan lainnya.
---

# Pemberitahuan dan Pengingat

Theodia bisa mengingatkan Anda tentang doa, renungan, rencana Alkitab, kartu hafalan, dan aktivitas lain — bahkan saat aplikasi luring. Semua pengingat dijadwalkan di perangkat Anda; tidak dibutuhkan koneksi internet atau server pemberitahuan dorong.

## Cara menyalakan atau mematikan pengingat

1. Buka **Pengaturan**.
2. Ketuk **Pemberitahuan**.
3. Nyalakan atau matikan **Aktifkan pengingat**.

Pertama kali Anda mengaktifkan pengingat, aplikasi meminta izin mengirim pemberitahuan. Ketuk **Izinkan** agar pengingatnya bisa muncul.

Jika sebelumnya Anda menolak izinnya, iOS atau Android bisa memblokir permintaan itu. Dalam hal itu, pergi ke aplikasi **Pengaturan** perangkat Anda, cari **Theodia**, dan aktifkan pemberitahuannya di sana.

## Jenis pengingat

Layar pemberitahuan terbagi ke dalam kanal-kanal. Setiap kanal adalah satu keluarga pengingat yang bisa Anda nyalakan atau matikan secara terpisah:

- **Pengingat doa** — pengingat doa umum.
- **Rutinitas doa** — pengingat yang terkait dengan rutinitas doa tertentu.
- **Renungan** — pengingat ayat harian atau renungan.
- **Pengingat rencana Alkitab** — pengingat untuk rencana Alkitab yang aktif.
- **Pengingat Theoscript** — pengingat untuk menjalankan sebuah Theoscript.
- **Pengingat wawasan AI** — pengingat yang dihasilkan AI.
- **Pengingat tinjauan kartu hafalan** — pemicu untuk meninjau kartu hafalan.
- **Pengingat kebiasaan membaca** — pemicu kebiasaan membaca harian.
- **Pengingat liturgis & musiman** — pengingat yang terkait dengan kalender gereja.
- **Pengingat saya** — pengingat yang Anda buat dari penanda, sorotan, playlist, pasal Alkitab, atau buku.
- **Pengingat khusus** — pengingat sepenuhnya khusus yang Anda buat sendiri.

Ketuk kanal mana pun untuk melihat pengingat-pengingatnya, mengganti waktunya, memilih hari-hari penyalaannya, atau mematikannya.

## Pengingat khusus

Pengingat khusus adalah pengingat yang Anda bangun dari nol.

1. Di **Pengaturan** → **Pemberitahuan**, ketuk **Pengingat khusus**.
2. Ketuk tombol **+**.
3. Masukkan **Judul** dan **Pesan**.
4. Pilih sebuah **Waktu**.
5. Pilih **Hari-hari** yang Anda inginkan untuk pengulangannya.
6. Pilih apa yang dibuka pengingat itu saat diketuk (opsional).
7. Ketuk **Simpan**.

Anda bisa menyunting atau menghapus pengingat khusus kapan saja dengan mengetuknya dalam daftar.

## Apa yang terjadi saat Anda mengetuk sebuah pengingat

Sebagian besar pengingat membuka layar tertentu di aplikasi. Misalnya, pengingat rutinitas doa membuka rutinitas itu; pengingat rencana Alkitab membuka bacaan berikutnya.

Jika sebuah pengingat tidak memiliki layar terkait, pengingat membuka aplikasi ke layar Beranda.

## Jam tenang

Jam tenang membisikan suara pemberitahuan sambil tetap membiarkan pengingat visual muncul.

1. Di **Pengaturan** → **Pemberitahuan**, ketuk **Jam tenang**.
2. Tetapkan waktu **Mulai** dan **Selesai**.

Pengingat yang dijadwalkan selama jam tenang akan tampil di layar tanpa suara.

## Pengingat mendatang dan riwayat

- **Pengingat mendatang** menampilkan semuanya yang dijadwalkan menyala berikutnya.
- **Riwayat pemberitahuan** menampilkan pengingat yang baru dikirim, dijadwalkan, dan dibatalkan.

Gunakan daftar-daftar ini untuk memastikan sebuah pengingat ditetapkan dengan benar atau untuk melihat mengapa sebuah pengingat tidak muncul.

## Jika pengingat tidak muncul

- Pastikan **Aktifkan pengingat** menyala.
- Periksa bahwa pemberitahuan diizinkan di setelan sistem perangkat Anda.
- Pastikan kanal pengingatnya diaktifkan dan setidaknya satu hari terpilih.
- Jika Anda menetapkan jam tenang, pengingatnya bisa jadi senyap.
- Beberapa pabrikan Android menggiring aplikasi ke tidur. Tambahkan Theodia ke daftar yang diizinkan jika perangkat Anda menawarkan setelan pengoptimalan baterai.
- Jika sebuah pengingat terkait dengan konten yang Anda hapus (misalnya, rencana Alkitab atau rutinitas yang dihapus), pengingat itu mungkin tidak menyala sampai Anda memilih ulang sasaran yang sah.

## Suara pemberitahuan

Anda bisa memilih suara yang diputarkan oleh pengingat yang mendukung suara. Ketuk **Suara** di dalam sebuah pengingat atau kanal untuk memilih dari opsi yang tersedia. Suara-suara dibundel bersama aplikasi, jadi semuanya bekerja luring.

Gunakan tombol **Pratinjau suara** untuk mendengarkan suara terpilih sebelum menyimpan.

## Lencana

Beberapa pengingat bisa menambahkan sebuah lencana ke ikon aplikasi. Ketuk **Bersihkan lencana** di layar pemberitahuan untuk mengatur ulangnya.
