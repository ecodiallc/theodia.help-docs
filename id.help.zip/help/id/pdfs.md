---
title: PDF
level: everyday
categories: [read, resources]
summary: Impor, atur, dan baca dokumen PDF di Theodia.
---

# PDF

> **Mode:** PDF tersedia di mode **Standar** dan **Pelajar**. Mode Fokus hanya untuk membaca yang bersih tanpa gangguan. Anda bisa mengganti mode di **Pengaturan** → **Mode Pengguna Aplikasi**.

Theodia bisa menyimpan dan membaca berkas PDF. PDF yang diimpor tetap berada di perangkat Anda, sehingga bekerja luring.

## Membuka pustaka PDF

Ketuk tab **PDF** di bagian bawah layar, atau ketuk ubin **PDF** di layar Beranda.

## Mengimpor sebuah PDF

1. Buka tab **PDF**.
2. Ketuk tombol **+** di kanan bawah.
3. Pilih sebuah PDF dari perangkat Anda.
4. (Opsional) Ketik atau pilih sebuah kategori untuk mengaturnya.

## Mengatur PDF

Tekan lama kartu PDF mana pun untuk membuka menu berisi opsi-opsi ini:

- **Ganti nama** — ubah judul yang ditampilkan di pustaka.
- **Ganti kategori** — pindahkan PDF ke dalam sebuah kategori.
- **Hapus** — keluarkan PDF dari Theodia. Ini juga menghapus posisi bacaan tersimpannya.

Kategori berupa teks bebas. Ketik nama baru atau pilih nama yang sudah ada saat Anda mengimpor atau mengganti kategori.

## Membaca sebuah PDF

Ketuk kartu PDF untuk membukanya. Pembaca menampilkan:

- Judul dokumen dalam bilah di bagian atas.
- Deretan tombol halaman: **Halaman pertama**, **Sebelumnya**, halaman saat ini ("3 / 120"), **Berikutnya**, dan **Halaman terakhir**.
- Bilah alat berisi alat-alat dokumen: **Daftar Isi**, **Perkecil**, **Perbesar**, **Atur ulang zum**, **Penanda halaman**, **Cari**, **Dengarkan**, dan **Tampilan teks**.

Beberapa alat diredupkan saat tidak bisa digunakan — misalnya, **Cari** dan **Dengarkan** diredupkan sampai teks yang dapat dicari dari PDF itu terpasang.

### Membalik halaman

- Ketuk **tanda chevron kiri** atau **kanan** untuk mundur atau maju satu halaman.
- Ketuk **Halaman pertama** atau **Halaman terakhir** untuk melompat ke salah satu ujung dokumen.
- Ketuk nomor halaman (misalnya "3 / 120") untuk membuka kisi halaman, lalu ketuk halaman yang Anda inginkan. Kisi terbuka di dekat halaman tempat Anda berada.
- Gunakan **tombol panah Kiri** dan **Kanan** pada papan ketik eksternal.

### Zum

- Ketuk **Perbesar** (+) atau **Perkecil** (−) untuk mengubah ukuran halaman.
- Ketuk **Atur ulang zum** untuk mengembalikan halaman ke ukuran normalnya.
- Jika Anda memperbesar, membalik halaman, lalu memperkecil, Theodia membawa Anda kembali ke halaman yang sedang Anda baca.

## Mencari di dalam sebuah PDF

1. Buka PDF itu dan ketuk tombol **Cari** (kaca pembesar) di bilah alat.
2. Ketik apa yang Anda cari. Hasil muncul saat Anda mengetik, dengan nomor halaman dan cuplikan teks di sekitarnya.
3. Ketuk sebuah hasil untuk melompat ke halaman itu.

Mencari membutuhkan teks yang dapat dicari dari PDF itu terpasang. Jika belum terpasang, tombol Cari diredupkan. PDF yang dipasang dari repositori GitHub komunitas menyertakan teks yang dapat dicari; PDF yang Anda impor sendiri belum memilikinya sampai ditambahkan.

## Daftar Isi

Jika PDF memiliki daftar isi bawaan, tombol **Daftar Isi** di bilah alat menampilkannya sebagai kerangka. Ketuk judul sebuah bagian untuk melompat ke halamannya. Bagian-bagian bisa dibuka dan ditutup. Jika PDF tidak memiliki daftar isi, tombolnya diredupkan.

## Penanda halaman di sebuah PDF

1. Buka PDF itu dan ketuk tombol **Penanda halaman** di bilah alat.
2. Ketuk **Tandai halaman ini** untuk menyimpan halaman saat ini. Namanya awalnya berupa nomor halaman — ketik nama lain jika Anda mau — lalu ketuk **Simpan**.
3. Ketuk penanda mana pun dalam daftar untuk melompat ke halamannya.
4. Ketuk tanda **×** di sebelah penanda untuk menghapusnya.

Penanda PDF terpisah dari penanda Alkitab Anda. Setiap PDF menyimpan daftarnya sendiri.

## Membacakan sebuah PDF dengan suara

Jika teks yang dapat dicari dari PDF itu terpasang, Theodia bisa membacakan halaman saat ini dengan suara:

1. Buka PDF itu dan ketuk tombol **Dengarkan** (pengeras suara) di bilah alat.
2. Sebuah bilah kontrol muncul berisi **Putar/Jeda**, **Mundur**, **Maju cepat**, **Berhenti**, bilah kemajuan yang bisa Anda ketuk untuk melompat di dalam halaman, kecepatan baca, dan suaranya.
3. Saat halaman selesai, pembacaan berlanjut ke halaman berikutnya secara otomatis.

Suara dan kecepatannya sama dengan yang dipakai untuk membaca Alkitab — lihat [Membaca Tegak](theodia://help/tts) untuk cara menggantinya.

## Menyalin, membagikan, atau menyimpan teks halaman

Ketuk tombol **Tampilan teks** di bilah alat untuk melihat halaman saat ini sebagai teks biasa. Dari sana Anda bisa:

- **Salin** — salin teks halaman ke papan klip.
- **Bagikan** — bagikan teks halaman melalui aplikasi mana pun di perangkat Anda.
- **Tambahkan ke catatan studi** — membuka penyunting catatan berisi teks halaman, sitasi, dan tautan kembali ke halaman ini yang telah diisi untuk Anda.

## Melanjutkan bacaan

Theodia mengingat halaman terakhir yang Anda lihat dan membuka PDF itu di sana pada waktu berikutnya.

## Mengunduh PDF dari GitHub

Di mode **Pelajar**, tombol **Unduh dari GitHub** muncul di bagian bawah pustaka. Ini terhubung ke repositori PDF komunitas sehingga Anda bisa memasang dokumen PDF yang dikemas dengan cara yang sama seperti memasang Alkitab atau buku.

## Catatan

- PDF disimpan di folder dokumen privat Theodia. PDF tidak disertakan dalam cadangan, jadi jika Anda pindah ke perangkat baru Anda perlu mengimpornya kembali.
