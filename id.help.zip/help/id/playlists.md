---
title: Playlist
level: everyday
categories: playlists
summary: Membuat dan mendengarkan playlist yang dibacakan berisi bagian Alkitab, teks biasa, atau ayat mana pun yang ingin Anda dengar.
---

# Playlist

Sebuah **playlist** adalah daftar trek yang bisa dibacakan Theodia untuk Anda. Setiap trek berupa sebuah bagian Alkitab atau catatan teks biasa singkat. Playlist berguna untuk mendengarkan tanpa tangan selama perjalanan, berjalan, waktu renungan, atau latihan menghafal.

Playlist muncul di aplikasi setelah setidaknya satu playlist dibuat atau diisi.

## Di mana menemukan Playlist

Ketika playlist tersedia, Anda bisa menjangkaunya dengan dua cara:

- **Layar beranda:** Di bagian **Plugin & Lainnya**, ketuk **Playlist**.
- **Menu utama:** Buka menunya (☰) dan ketuk **Playlist**.

Jika belum ada playlist, ubin Playlist dan butir menunya disembunyikan.

## Apa saja isi sebuah playlist

Setiap playlist memiliki:

- Sebuah **nama** — misalnya, "Ayat Pagi" atau "Hafal Mazmur 23".
- Sebuah **kategori** opsional — berguna untuk mengelompokkan playlist menurut keperluan.
- Daftar **trek** — butir-butir untuk dibacakan.

Setiap trek berisi:

- **Konten** — sebuah referensi bagian Alkitab atau teks biasa.
- Sebuah **label** — ditampilkan di layar saat trek berputar.
- Sebuah **suara** opsional — pilih suara berbeda untuk trek ini jika Anda mau.

## Membuat sebuah playlist

1. Buka layar **Playlist**.
2. Ketuk **Buat playlist** (atau tombol **+**).
3. Beri playlist itu sebuah nama.
4. (Opsional) Pilih atau buat sebuah kategori.
5. Mulailah menambahkan trek.

### Menambahkan trek dari sebuah bagian Alkitab

1. Ketuk **Tambah trek**.
2. Pilih **Bagian Alkitab** sebagai jenis kontennya.
3. Masukkan sebuah referensi, seperti `John 3:16` atau `Psalm 23:1-6`.
4. Tambahkan sebuah label jika Anda mau, atau biarkan kosong untuk memakai referensinya.
5. Simpan treknya.

### Menambahkan trek teks biasa

1. Ketuk **Tambah trek**.
2. Pilih **Teks biasa**.
3. Ketik teks yang Anda ingin dibacakan Theodia.
4. Tambahkan sebuah label.
5. Simpan treknya.

### Menambahkan trek secara batch

Jika Anda memiliki daftar referensi atau baris teks, gunakan **Tambah batch**:

1. Buka sebuah playlist.
2. Ketuk menunya dan pilih **Tambah batch**.
3. Tempelkan satu referensi atau baris teks per baris.
4. Nyalakan **Deteksi referensi Alkitab** jika sebagian besar barisnya berupa referensi ayat.
5. Ketuk **Tambah**. Setiap baris menjadi sebuah trek.

## Mendengarkan sebuah playlist

1. Buka playlist yang ingin Anda dengar.
2. Ketuk tombol **Putar** di bagian atas atau di samping sebuah trek.
3. Theodia membacakan setiap trek secara berurutan.

Saat sebuah playlist berputar, sebuah bilah kontrol muncul dengan kontrol-kontrol ini:

- **Putar / Jeda**
- **Trek berikutnya**
- **Trek sebelumnya**
- **Berhenti**

Anda juga bisa menetapkan:

- **Kecepatan** — seberapa cepat suara membaca.
- **Ulang** — ulangi seluruh playlist, ulangi satu trek, atau putar sekali.
- **Acak** — putar trek-trerek dalam urutan acak.
- **Abaikan tanda kurung** — lewati teks di dalam tanda kurung.
- **Jeda antartrek** — tambahkan keheningan singkat antartrek.
- **Pengatur waktu tidur** — hentikan pemutaran setelah waktu yang ditetapkan.

## Menyunting sebuah playlist

Untuk mengubah sebuah playlist, jeda dulu pemutarannya jika sedang berputar.

Anda bisa:

- **Mengganti nama** playlistnya.
- **Mengurutkan ulang trek** — seret trek-trerek ke urutan baru.
- **Menyunting sebuah trek** — ganti referensinya, teksnya, labelnya, atau suaranya.
- **Menghapus sebuah trek** — keluarkan dari playlistnya.
- **Menghapus seluruh playlist** — ini tidak bisa dibatalkan.

## Mengekspor dan mengimpor playlist

Playlist diekspor sebagai berkas JSON yang menyertakan semua trek, kategori, dan setelan. Anda bisa membagikan berkasnya ke perangkat lain, menyimpannya sebagai cadangan, atau menyuntingnya di komputer.

- **Ekspor semua playlist** — membuat berkas `playlists-YYYY-MM-DD.json`.
- **Ekspor sebuah kategori** — membuat berkas JSON yang hanya berisi playlist dalam satu kategori.
- **Impor playlist** — memulihkan playlist dari berkas cadangan JSON.

## Cara cepat membangun sebuah playlist

Anda juga bisa membuat playlist penuh sebagai JSON dan mengimpornya. Berikut contohnya:

```json
{
  "playlists": [
    {
      "name": "Morning Verses",
      "category": "Devotional",
      "tracks": [
        {
          "info": "John 3:16",
          "contentSource": "passage",
          "content": "For God so loved the world...",
          "rawContent": "John 3:16"
        },
        {
          "info": "Psalm 23",
          "contentSource": "passage",
          "content": "The Lord is my shepherd...",
          "rawContent": "Psalm 23:1-6"
        }
      ]
    }
  ]
}
```

Simpan berkasnya, lalu gunakan **Impor playlist** untuk memuatnya ke Theodia.

## Tips

- Playlist bekerja paling baik dengan set ayat yang pendek dan fokus.
- Gunakan kategori untuk memisahkan playlist renungan dari playlist penghafalan.
- Tetapkan pengatur waktu tidur jika Anda mendengarkan sambil tertidur.
- Jika sebuah trek memakai suara yang salah, periksa bahwa bahasa suaranya cocok dengan bahasa teksnya.
- Theodia membaca teks biasa persis seperti yang tertulis; periksa ejaannya demi hasil terbaik.
