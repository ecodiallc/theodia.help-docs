---
title: Sekilas Doa
level: beginner
categories: prayer
summary: Pengenalan singkat tab Doa dan bagian-bagian utamanya.
---

# Sekilas Doa

Tab **Doa** adalah ruang khusus untuk doa. Tab ini menyatukan daftar-daftar, sesi terbimbing, sebuah jurnal, sebuah pengatur waktu, jadwal bacaan leksioner, dan doa-doa baku klasik.

## Bagian-bagian utama

- **Daftar Doa** — mencatat orang, situasi, dan topik yang Anda doakan.
- **Jurnal** — menuliskan refleksi, jawaban, dan pemikiran dari waktu ke waktu.
- **Buat Doa** — minta Theophilus menulis sebuah doa dari sebuah permintaan atau entri jurnal.
- **Pengakuan Iman & Doa Baku** — doa-doa dan pengakuan iman klasik dari tradisi Kristen.
- **Leksioner** — jadwal bacaan Kitab Suci untuk doa harian atau musiman.
- **Doa Terbimbing** — sesi doa terbimbing audio dengan teks-ke-suara.
- **Pengatur Waktu** — sesi doa berwaktu dengan bel opsional.
