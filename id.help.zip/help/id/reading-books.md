---
title: Membaca Buku Bawaan
level: beginner
categories: [content, read]
summary: Cara membaca klasik Kristen yang datang bersama aplikasi.
---

# Membaca Buku Bawaan

Theodia hadir dengan pustaka kecil berisi buku-buku Kristen. Ini adalah karya-karya klasik yang bisa Anda baca di perangkat Anda.

## Cara membuka pustaka

Ketuk tab **Buku** di bagian bawah layar. Anda melihat daftar buku-buku di pustaka Anda.

## Cara membaca sebuah buku

1. Ketuk judul bukunya.
2. Buku terbuka pada pasal pertama.
3. Gunakan tombol **Sebelumnya** dan **Berikutnya** di bagian atas untuk berpindah antarpasal.

## Cara melompat ke sebuah pasal

Ketuk nama pasal di bagian atas layar. Daftar pasal muncul. Pilih sebuah pasal untuk melompat ke sana.

## Cara mengganti ukuran huruf

Buka **Pengaturan** → **Tampilan** dan pilih ukuran huruf. Ukuran teks berubah di seluruh aplikasi, termasuk di buku.

## Cara menambah penanda halaman di sebuah buku

Ketuk ikon **bintang** di kanan atas. Pasal saat ini tersimpan. Ketuk tab **Penanda** untuk melihat halaman-halaman yang Anda simpan.

## Cara mendengarkan sebuah buku

Ketuk ikon **Pengeras suara** di kanan atas. Aplikasi membacakan pasalnya dengan suara. Ketuk lagi untuk berhenti.

## Buku apa saja yang tersedia?

Pustaka memiliki karya klasik seperti:

- Pilgrim's Progress
- The Imitation of Christ
- Practice of the Presence of God
- The Hymn Book

Daftar buku bisa bertambah dari waktu ke waktu. Pembaruan aplikasi bisa menambah lebih banyak lagi.

## Tips

- Buku-buku tersimpan di perangkat Anda. Tidak perlu internet.
- Buku-buku tidak tersinkron ke awan.
