---
title: Mencari Sumber Daya di GitHub
level: everyday
categories: resources
summary: Cari semua repositori GitHub yang diketahui aplikasi sekaligus, lalu pasang yang Anda temukan.
---

# Mencari Sumber Daya di GitHub

Theodia menyimpan daftar repositori GitHub yang menerbitkan sumber daya — Alkitab, komentar, buku, renungan, playlist, paket doa, dan lainnya. **Cari Repositori GitHub** menelusuri semuanya sekaligus, sehingga Anda tidak perlu membuka setiap tab dan menelusuri satu per satu.

> Bagian GitHub di Pengaturan hanya tersedia di **mode Pelajar**. Untuk menyalakannya, pergi ke **Pengaturan → Mode Pengguna → Pelajar**.

## Cara mencari

1. Buka **Pengaturan**.
2. Ketuk **Cari Repositori GitHub**.
3. Ketik sebuah kata di kotak pencarian. Aplikasi mencari kata itu dalam **nama** dan **deskripsi** setiap paket di setiap repositori.

Beberapa hal yang perlu diketahui tentang pencarian:

- **Setiap kata harus cocok.** Mencari `morning evening` hanya menemukan paket yang nama atau deskripsinya memuat *kedua* kata itu.
- **Huruf besar-kecil tidak berpengaruh.** `Morning` dan `morning` menemukan paket yang sama.
- **Cocok terbaik tampil lebih dulu.** Paket yang *namanya diawali* dengan kata pencarian Anda ditampilkan sebelum paket yang hanya menyebutkannya di deskripsi.

## Penyaringan

Ketuk bilah penyaring di atas hasil untuk mempersempit daftar lebih lanjut. Ada dua penyaring, dan keduanya bekerja bersama:

- **Pembuat** — hanya paket dari pembuat itu.
- **Tradisi** — hanya paket untuk tradisi itu.

Ketuk sebuah penyaring lagi untuk menghapusnya, atau ketuk **Bersihkan penyaring** untuk mengatur ulang keduanya.

## Memasang dari sebuah hasil

Setiap hasil menampilkan nama paket, jenis sumber dayanya, pembuatnya, dan repositori asalnya. Di kanan baris ada satu tombol:

- **Pasang** — paket itu belum ada di perangkat Anda.
- **Perbarui** — versi yang lebih baru tersedia. Aplikasi meminta Anda mengonfirmasi lebih dulu, karena memperbarui menghapus salinan lama bersama catatan, sorotan, atau penanda apa pun yang menunjuk kepadanya.
- **Buka** — paket itu sudah terpasang; mengetuknya membawa Anda ke layar tempat Anda memakainya.

Ketuk **Segarkan** di bagian atas untuk mengambil daftar terbaru dari GitHub dengan langsung. Aplikasi memuat ulang daftar sendiri sekali sehari, jadi penyegaran manual hanya diperlukan saat Anda tahu ada sesuatu yang baru diterbitkan.

## Mencari tanpa koneksi

Aplikasi menyimpan salinan daftar di perangkat Anda, sehingga pencarian tetap bekerja bahkan saat Anda luring. Jika aplikasi tidak bisa menghubungi GitHub untuk menyegarkan daftar, sebuah spanduk di bagian atas memberi tahu Anda bahwa Anda sedang melihat hasil tersimpan (cache).

## Jika pencarian tidak menemukan apa-apa

- Coba kata tunggal yang lebih pendek.
- Periksa bahwa tidak ada penyaring **Pembuat** atau **Tradisi** yang masih aktif — tombol **Bersihkan penyaring** muncul setiap kali ada yang aktif.
- Beberapa repositori menerbitkan paketnya dalam bahasa yang berbeda dari nama paketnya, jadi mencari dengan kata terjemahan mungkin tidak menemukannya.
