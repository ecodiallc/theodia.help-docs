---
title: Mode Pelajar
level: advanced
categories: [layout, read, study]
summary: Mode studi paling mendalam di Theodia, membuka komentar, leksikon, referensi silang, alat AI, dan Menu Peluncur.
---

# Mode Pelajar

> **Mode:** Mode Pelajar hanya tersedia ketika mode pengguna Anda disetel ke **Pelajar**. Ganti mode di **Pengaturan** → **Mode Pengguna Aplikasi**.

Mode Pelajar membuka semua alat belajar di Theodia. Mode ini dibangun di atas Mode Studi, sehingga Anda tetap mendapatkan menu ayat, Alkitab paralel, penanda halaman, sorotan, dan catatan — ditambah alat-alat tingkat lanjut berikut ini.

## Cara membuka Mode Pelajar

Mode Pelajar bukan layar terpisah. Mode ini adalah kumpulan alat tambahan yang muncul di dalam pembaca dan navigasi yang sudah ada ketika mode pengguna Anda disetel ke Pelajar.

1. Buka **Pengaturan**.
2. Ketuk **Mode Pengguna Aplikasi**.
3. Pilih **Pelajar**.

Perubahan langsung berlaku. Menu dan tombol yang semula tersembunyi kini muncul.

## Alat pembaca tambahan

Saat Anda membuka sebuah pasal dalam [Mode Studi](theodia://help/study-mode), Mode Pelajar menambahkan alat-alat ini ke menu ayat:

- **Komentar AI** (◈) — minta asisten AI menulis catatan studi untuk ayat ini. (Tidak tersedia di semua wilayah.)
- **Info Kata** (?) — buka entri leksikon untuk kata asli dalam bahasa Ibrani atau Yunani di balik ayat. Lihat panduan [Komentar dan Leksikon](theodia://help/commentaries-and-lexicons).
- **Kamus** (📖) — cari kata-kata Alkitab umum di sumber daya kamus yang telah Anda pasang. Lihat panduan [Kamus Alkitab](theodia://help/dictionary).

Alat-alat ini membutuhkan sumber daya yang dipasang (komentar, leksikon, berkas kamus). Jika sebuah alat berwarna abu-abu atau menampilkan "tidak ditemukan", buka **Pengaturan** → **Kelola Sumber Daya** dan tambahkan sumber daya yang dibutuhkannya.

## Navigasi tambahan

### Tab bilah alat tambahan

Bilah alat bawah mendapatkan satu tab tambahan:

- 💻 **AI** — membuka asisten AI (hanya jika Anda menyalakan AI di Pengaturan). Tab ini berada di sebelah kanan Catatan.

### Item menu utama tambahan

Menu utama menyertakan entri **Asisten AI** dengan syarat yang sama.

## Menu Peluncur

Mode Pelajar mengaktifkan **Menu Peluncur**, cara cepat untuk melompat ke ayat terakhir, menjalankan perintah, dan mengganti tata letak Alkitab tanpa meninggalkan layar Anda. Lihat panduan [Menu Peluncur](theodia://help/launcher-menu) untuk cara menggunakannya.

## Kapan menggunakan Mode Pelajar

- Anda ingin asisten AI, komentar, atau pencarian bahasa asli saat membaca.
- Anda ingin Menu Peluncur untuk navigasi ayat cepat dan obrolan AI.
- Anda sedang mempelajari sebuah bagian secara mendalam dan membutuhkan setiap alat hanya satu ketukan jauhnya.

## Beralih ke mode yang lebih ringan

Jika Anda menginginkan pembaca yang lebih sederhana tanpa alat tingkat lanjut, beralihlah ke mode **Standar** di **Pengaturan** → **Mode Pengguna Aplikasi**. Mode Standar mempertahankan penanda, sorotan, catatan, dan Mode Studi tetapi menyembunyikan AI, komentar, leksikon, dan Menu Peluncur.

Jika Anda menginginkan pengalaman membaca paling bersih, buka sebuah pasal dalam [Mode Fokus](theodia://help/focus-mode).

Penanda, sorotan, dan catatan Anda tidak pernah dihapus saat Anda mengganti mode; semuanya hanya disembunyikan sampai Anda kembali ke mode yang mendukungnya.

## Bantuan dan pertanyaan

Jika sebuah alat hilang atau menampilkan kesalahan, lihat panduan [Masalah Umum](theodia://help/common-problems). Jika Anda baru mengenal Theodia, panduan [Membaca Pasal Pertama Anda](theodia://help/first-read) menuntun Anda melalui dasar-dasarnya langkah demi langkah.
