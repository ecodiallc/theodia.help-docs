---
title: Mencari di Alkitab
level: everyday
categories: [study, read]
summary: Cara menemukan ayat berdasarkan kata, frasa, atau referensi.
---

# Mencari di Alkitab

Bilah pencarian membantu Anda menemukan ayat dengan cepat. Anda bisa mencari berdasarkan sebuah kata, sebuah frasa, atau referensi Alkitab.

## Cara memulai pencarian

1. Ketuk tab **Pencarian** di bagian bawah layar.
2. Ketik apa yang ingin Anda temukan.
3. Ketuk **Cari** di papan ketik.

Hasilnya muncul sebagai daftar ayat. Setiap hasil menampilkan kitab, pasal, dan ayat, ditambah teks ayatnya.

## Mencari dengan kombinasi kata

Saat Anda mengetik lebih dari satu kata, seperti `love joy`, aplikasi menemukan ayat yang memuat **kedua** kata itu. Ini adalah pencarian **AND** — semua kata harus muncul dalam ayat. Pencarian **tidak** menggunakan logika **OR** (ayat dengan salah satu kata saja).

Untuk mencari ayat yang memuat salah satu kata, Anda harus menggunakan kata kunci `OR` secara eksplisit: `love OR joy`.

## Mencari berdasarkan kata

Ketik satu kata, seperti `love` atau `mercy`. Aplikasi menampilkan setiap ayat dalam Alkitab yang memuat kata itu.

## Mencari berdasarkan frasa

Ketik dua atau tiga kata dalam tanda kutip, seperti `"do not be afraid"`. Aplikasi menampilkan ayat-ayat yang memuat frasa persis itu.

## Menyaring hasil

Setelah pencarian, hasilnya disaring ke terjemahan Alkitab yang telah Anda pasang. Untuk mempersempit lebih lanjut, buka tab **Alkitab** dan lihat pada terjemahan tertentu — pencarian dijalankan terhadap terjemahan yang Anda miliki.

## Tips untuk pencarian yang lebih baik

- Gunakan kata pendek. Pencarian `love` menemukan lebih banyak ayat daripada pencarian `loving`.
- Tanda kutip di sekeliling sebuah frasa membuat pencarian menjadi persis.
- Aplikasi hanya mencari terjemahan Alkitab yang telah Anda pasang.
- Untuk melompat ke ayat tertentu berdasarkan referensi (misalnya, `John 3:16`), gunakan kotak **Perintah** di layar beranda alih-alih tab Pencarian.

## Riwayat pencarian

Aplikasi mengingat pencarian terbaru Anda. Saat Anda membuka tab **Pencarian**, daftar menampilkan pencarian terbaru Anda di bagian atas. Ketuk salah satu untuk menjalankannya lagi. Untuk menghapus daftar, ketuk **Bersihkan Semua** di bagian atas pencarian terbaru.

## Mencari di PDF

Tab Pencarian juga bisa mencari di dalam dokumen PDF Anda:

1. Ketuk tab **Pencarian**, lalu ketuk mode **PDF** di bagian atas.
2. Pilih PDF mana yang akan dicari. Ketuk sebuah PDF untuk memasukkan atau mengeluarkannya; gunakan **Semua** atau **Bersihkan** di atas daftar untuk memasukkan semuanya atau mulai dari awal. Hanya PDF yang teksnya dapat dicari dan sudah terpasang yang bisa dipilih.
3. Ketik apa yang ingin Anda temukan dan ketuk **Cari**.

Setiap hasil menampilkan judul PDF, nomor halaman, dan cuplikan teks yang cocok. Ketuk sebuah hasil untuk membuka PDF itu pada halaman tersebut.

Untuk mencari di dalam satu PDF saat membacanya, gunakan tombol **Cari** di pembaca PDF sebagai gantinya — lihat [PDF](theodia://help/pdfs).
