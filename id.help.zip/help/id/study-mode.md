---
title: Mode Studi
level: everyday
categories: [layout, read]
summary: Pembaca Alkitab lengkap di Theodia, dipenuhi alat belajar seperti komentar, referensi silang, leksikon, dan catatan.
---

# Mode Studi

> **Mode:** Mode Studi tersedia di mode **Standar** dan **Pelajar**. Mode Pembaca membuka pasal dalam Mode Fokus sebagai gantinya. Anda bisa mengganti mode di **Pengaturan** → **Mode Pengguna Aplikasi**.

Mode Studi adalah pembaca Alkitab utama di Theodia. Mode ini memiliki semua alat belajar terpasang: komentar, referensi silang, pencarian kata, terjemahan paralel, catatan, dan lainnya.

Mode Fokus adalah pembaca yang lebih sederhana tanpa alat belajar. Lihat panduan [Mode Fokus](theodia://help/focus-mode) jika Anda hanya menginginkan teks bersih. Panduan ini untuk Mode Studi.

## Cara membuka Mode Studi

Ada beberapa cara membuka sebuah pasal dalam Mode Studi:

- Ketuk tab **Alkitab** di bagian bawah layar. Pilih terjemahan, kitab, dan pasal.
- Ketuk sebuah ayat di hasil **Pencarian**.
- Ketuk sebuah penanda dari tab **Penanda**.
- Dari Mode Fokus, ketuk tombol 📖 di bagian atas layar untuk beralih ke Mode Studi.

## Membaca pasal

Pasal terbuka dengan ayat-ayat tersusun berurutan. Di bagian atas layar terdapat tombol-tombol untuk tindakan paling umum. Di bagian bawah layar ada bilah status.

- **Geser ke kiri** untuk pindah ke pasal berikutnya.
- **Geser ke kanan** untuk pindah ke pasal sebelumnya.
- **Ketuk sebuah ayat** untuk membuka menu ayat dengan alat belajar (lihat di bawah).
- **Ketuk angka Strong dalam sebuah ayat** (misalnya, G1234 atau H1234) untuk membuka pencarian leksikon cepat bagi kata itu.

Jika Anda mengaktifkan terjemahan paralel, salinan kedua pasal muncul di bawah yang utama, dalam terjemahan yang Anda pilih. Lihat **Membaca dua terjemahan sekaligus** di bawah.

## Menu ayat

Saat Anda mengetuk sebuah ayat, sebuah menu terbuka dengan judul "Kitab Pasal:Ayat". Alat yang Anda lihat tergantung mode pengguna Anda.

### Alat di mode Standar dan Pelajar

- **Penanda halaman** (★) — simpan ayat agar mudah ditemukan lagi. Ketuk lagi untuk menghapus penanda. Ketukan pertama menambahkannya. Lihat panduan [Menandai Ayat](theodia://help/bookmarks).
- **Sorotan** (□) — beri warna pada ayat agar menonjol. Ketuk untuk membuka pemilih warna. Ketuk warna yang sama lagi untuk menghapus sorotan. Lihat panduan [Menyorot Ayat](theodia://help/highlights).
- **Bacakan** (🔊) — minta ayat dibacakan menggunakan suara teks-ke-suara perangkat Anda. Ini tidak ditampilkan untuk Alkitab interlinear. Lihat panduan [Membaca Tegak](theodia://help/tts) untuk cara menggunakannya dan cara memilih suara.
- **Salin** (⎘) — letakkan teks ayat di papan klip Anda agar bisa ditempel di mana saja.
- **Bandingkan** (⇄) — buka panel yang menampilkan ayat yang sama di semua terjemahan yang telah Anda pasang. Ketuk sebuah terjemahan di panel untuk membaca ayat itu dalam terjemahan tersebut. Lihat panduan [Membandingkan Terjemahan](theodia://help/compare-translations).
- **Referensi Silang** (↗) — buka daftar ayat terkait dari basis data referensi silang. Lihat panduan [Referensi Silang](theodia://help/cross-references).
- **Tambah/Edit Catatan Alkitab** (✎) — tulis catatan pribadi Anda yang terlampir pada ayat. Lihat panduan [Menulis Catatan](theodia://help/notes).

### Alat hanya di mode Pelajar

- **Komentar AI** (◈) — minta asisten AI menulis catatan studi untuk ayat ini. (Tidak tersedia di semua wilayah.)
- **Info Kata** (?) — buka entri leksikon untuk kata asli dalam bahasa Ibrani atau Yunani di balik ayat. Lihat panduan [Komentar dan Leksikon](theodia://help/commentaries-and-lexicons).
- **Kamus** (📖) — cari kata-kata Alkitab umum di sumber daya kamus yang telah Anda pasang. Lihat panduan [Kamus Alkitab](theodia://help/dictionary).

Beberapa alat membutuhkan sumber daya tambahan untuk dipasang. Jika sebuah alat berwarna abu-abu atau menampilkan "tidak ditemukan", buka **Pengaturan** → **Kelola Sumber Daya** dan tambahkan sumber daya yang dibutuhkannya.

## Tombol bagian atas layar

Di atas teks pasal ada deretan ikon. Ini adalah tindakan cepat:

- **Versi Alkitab** — ketuk nama terjemahan (misalnya, "KJV") untuk beralih ke terjemahan lain.
- **Kitab** — ketuk nama kitab untuk melompat ke kitab lain.
- **Pasal** — ketuk nomor pasal untuk melompat ke pasal lain.
- **Buka di AI** (🤖) — kirim pasal saat ini ke asisten AI beserta pertanyaan Anda. (Hanya mode Pelajar.)
- **Mode Fokus** (📖) — beralih ke Mode Fokus untuk membaca bersih.
- **Alkitab Paralel** (🔵 / ⚪) — ketuk untuk menyalakan atau mematikan terjemahan paralel. Saat aktif, pasal yang sama ditampilkan dalam terjemahan paralel pilihan Anda di bawah teks utama. Saat nonaktif, hanya terjemahan utama yang ditampilkan. Lihat **Membaca beberapa terjemahan sekaligus** di bawah.
- **Dengarkan** — minta seluruh pasal dibacakan. Lihat panduan [Membaca Tegak](theodia://help/tts).
- **Lainnya** — buka tindakan pasal tambahan (catatan Alkitab pasal, komentar pasal, bagikan, dan sebagainya).

## Membaca beberapa terjemahan sekaligus

Anda bisa menampilkan hingga empat terjemahan tambahan bersama terjemahan utama Anda. Ini disebut **tampilan paralel**.

1. Buka **Pengaturan**.
2. Nyalakan **Alkitab Paralel**.
3. Ketuk **Tambah Alkitab Paralel** dan pilih sebuah terjemahan.
4. Ulangi untuk menambahkan lebih banyak. Anda bisa memiliki hingga empat terjemahan paralel.

Saat tampilan paralel aktif, setiap ayat di pasal menampilkan terjemahan utama Anda lebih dulu, diikuti ayat yang sama di setiap terjemahan paralel. Ini memudahkan membandingkan bagaimana penerjemah yang berbeda menangani ayat yang sulit tanpa meninggalkan pasal itu.

Anda bisa menyimpan setelan paralel Anda saat ini sebagai **preset**. Ketuk tombol simpan di sebelah terjemahan pilihan Anda, beri nama, dan preset menjadi opsi pergantian cepat. Ketuk preset mana pun nanti untuk langsung memuat kombinasi itu. Ketuk lama sebuah preset untuk menghapusnya.

Anda juga bisa membandingkan satu ayat saja setiap saat dengan alat **Bandingkan** (⇄) di menu ayat. Itu membuka panel yang menampilkan ayat di semua terjemahan yang dipasang.

## Subjudul

Beberapa terjemahan memiliki judul bagian tertanam (misalnya, "Khotbah di Bukit"). Jika terjemahan Anda memilikinya, Anda bisa menampilkan atau menyembunyikannya dengan setelan **Tampilkan Subjudul** di **Pengaturan**. Subjudul muncul sebagai judul kecil berwarna abu-abu di antara ayat-ayat.

## Catatan pasal

Catatan pasal adalah satu catatan yang terlampir pada seluruh pasal, bukan pada satu ayat. Catatan ini berguna untuk satu pemikiran besar tentang pasal itu.

Cara membuka catatan pasal:

1. Ketuk tombol **Lainnya** di bagian atas layar.
2. Ketuk **Catatan Pasal**.
3. Tulis catatan Anda. Ketuk **Simpan**.

Catatan pasal tersimpan bersama pasalnya. Catatan muncul setiap kali Anda membuka pasal itu.

## Sorotan pencarian

Jika Anda datang ke pasal ini dari sebuah pencarian, kata-kata pencarian Anda disorot berwarna kuning di teks ayat. Ini memudahkan melihat mengapa sebuah ayat cocok.

Anda juga bisa menjalankan kembali pencarian pada pasal yang sedang Anda baca. Buka tab **Pencarian** dan masukkan sebuah kata. Hasilnya memungkinkan Anda mengetuk langsung kembali ke pasal dengan kecocokan tersorot.

Alkitab interlinear (MIB — Marvel Interlinear Bible — dan OHGB) selalu terbuka dalam Mode Studi karena membutuhkan tata letak tingkat kata.

## Beralih ke Mode Fokus untuk satu pasal

Dari pasal mana pun dalam Mode Studi, ketuk tombol 📖 di bagian atas. Pasal yang sama terbuka dalam Mode Fokus dengan semua menu tersembunyi. Ketuk tombol 📖 di bilah bawah untuk kembali ke Mode Studi.

## Kapan menggunakan Mode Studi

Mode Studi adalah pilihan yang tepat saat Anda ingin:

- **Membaca dan belajar pada saat yang sama.** Semua alat hanya satu ketukan jauhnya.
- **Mencari arti kata yang tidak Anda kenal.** Ketuk angka Strong dalam ayat untuk entri leksikon cepat.
- **Membandingkan terjemahan.** Gunakan alat Bandingkan di menu ayat atau nyalakan tampilan paralel.
- **Melihat bagaimana sebuah ayat terhubung dengan bagian Alkitab lainnya.** Gunakan Referensi Silang.
- **Membuat catatan saat membaca.** Menu ayat memiliki opsi cepat "Tambah catatan".

Untuk membaca panjang tanpa gangguan, beralihlah ke Mode Fokus.

## Beralih ke Mode Fokus

Dari pasal mana pun dalam Mode Studi, ketuk tombol 📖 di bagian atas. Pasal yang sama terbuka dalam [Mode Fokus](theodia://help/focus-mode) dengan menu dan alat belajar tersembunyi. Ketuk tombol 📖 di bilah bawah untuk kembali ke Mode Studi. Untuk deskripsi lengkap apa yang dilakukan Mode Fokus, lihat panduan [Mode Fokus](theodia://help/focus-mode).

## Bantuan dan pertanyaan

Jika sebuah alat hilang atau menampilkan kesalahan, lihat panduan [Masalah Umum](theodia://help/common-problems). Jika Anda baru mengenal Theodia, panduan [Membaca Pasal Pertama Anda](theodia://help/first-read) menuntun Anda melalui dasar-dasarnya langkah demi langkah.
