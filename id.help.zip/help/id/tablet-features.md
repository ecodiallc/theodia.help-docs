---
title: Fitur Tablet
level: everyday
categories: [layout, tablet]
summary: Bagaimana tata letak Theodia beradaptasi dengan tablet dan layar yang lebih besar, dengan tampilan terbagi, panel samping, dan mode membaca dua panel.
---

# 📱 Fitur Tablet

Theodia dirancang untuk memanfaatkan layar yang lebih besar pada tablet. Di tablet (atau perangkat mana pun yang lebarnya lebih dari sekitar 700 piksel), aplikasi otomatis beralih ke tata letak dua kolom di banyak tempat.

> **Mode:** Fitur-fitur yang dijelaskan di sini hanya muncul jika mode pengguna Anda saat ini mendukungnya. Misalnya, panel samping komentar dan obrolan AI hanya tersedia di mode Pelajar. Tampilan terbagi penanda, sorotan, dan catatan membutuhkan mode Standar atau Pelajar. Mode Fokus hanya menampilkan bacaan bersih satu kolom. Anda bisa mengganti mode di **Pengaturan** → **Mode Pengguna Aplikasi**.

## Menu ayat di Pembaca

Saat Anda mengetuk sebuah nomor ayat (atau menekan lama teks ayat), **menu ayat** muncul sebagai **kartu di tengah** di atas latar gelap.

- Tombol **Salin** dan **Bagikan** selalu terlihat di bagian atas menu.
- **Penanda halaman** dan **Sorotan** ditampilkan dengan keadaannya saat ini.
- **Komentar**, **Kamus**, dan **Bandingkan** terbuka dari menu. Di tablet, alat-alat ini bisa muncul di panel samping atau kartu lebar setelah dipilih.
- Ketuk latar belakangnya atau panah penutup untuk menutup menu.

## Panel Komentar Ayat

Alat **Komentar** membuka **panel samping khusus** di tablet:

- Teks komentar muncul di samping teks Alkitab.
- Anda bisa menggulir komentar secara terpisah dari Alkitab.
- Ketuk tanda **X** atau geser untuk menutup.
- Sebuah **ikon buku** di bagian atas panel memungkinkan Anda mengganti sumber komentar.
- Sebuah **ikon pasal** memungkinkan Anda melihat komentar level pasal.

Di ponsel, komentar terbuka sebagai jendela layar penuh.

## Komentar Pasal

**Komentar Pasal** diakses dari tombol **Lainnya** di bagian atas layar, bukan dari menu ayat. Di tablet, ini terbuka sebagai panel samping persis seperti Komentar Ayat, sehingga Anda bisa membaca komentar dan teks Alkitab bersamaan.

## Tab Bandingkan

Tab **Bandingkan** (di menu ayat) terbuka sebagai **panel samping** di tablet. Tab menampilkan ayat terpilih di setiap versi paralel yang telah Anda aktifkan. Anda bisa mengetuk versi mana pun untuk melompat ke bagian itu di pembaca.

## Popup Kamus / Strong's

Alat **Kamus** (menu ayat → Kamus) terbuka sebagai kartu lebar di tablet. Kartu menampilkan kata Yunani atau Ibraninya, transliterasinya, definisinya, dan angka Strong. Ketuk tombol **Konkordansi** untuk melihat setiap kemunculan kata itu dalam Alkitab.

## Ketuk sebuah kata untuk membuka Leksikonnya

Di panel samping **Info Kata** di tablet, setiap kartu kata yang memiliki angka Strong bisa diketuk. Ketuk kartunya untuk membuka panel **Leksikon** bagi kata itu secara langsung. Panel Leksikon menggantikan panel Info Kata sehingga Anda bisa terus belajar tanpa menutup pembaca.

Di ponsel, kartu Info Kata tidak bisa diketuk karena layarnya terlalu kecil untuk dua panel.

## Alkitab paralel berdampingan

Di Pengaturan, ketuk **Alkitab Paralel** dan pilih hingga tiga versi. Di tablet, versi-versi itu muncul sebagai **panel vertikal** berdampingan:

- Setiap panel menggulir secara terpisah.
- Anda bisa mengetuk sebuah nomor ayat untuk membuka panel samping berisi alat-alat.
- Tab **Bandingkan** menampilkan semua ayat terpilih di satu tempat.
- Ketuk tanda **X** pada panel mana pun untuk menutupnya dan kembali ke tampilan satu kolom.
- Ketuk ikon **Alkitab Paralel** (🔵 / ⚪) di bilah ikon atas untuk menyalakan atau mematikan tampilan paralel tanpa membuka Pengaturan.

Di ponsel, versi paralel ditampilkan satu demi satu (vertikal), bukan berdampingan. Ikon pergantian yang sama juga bekerja di ponsel.

## Tampilan terbagi Penanda dan Sorotan

Di tablet, tab **Penanda** dan **Sorotan** memakai tata letak master-detail:

- **Sisi kiri** — daftar penanda atau sorotan.
- **Sisi kanan** — mengetuk sebuah butir membuka panel pratinjau berisi teks ayat atau bagiannya.

Anda bisa menelusuri butir-butir tersimpan dan melihat pratinjaunya tanpa meninggalkan tab. Di ponsel, mengetuk sebuah butir menavigasi ke layar pembaca.

## Tampilan terbagi Catatan

Tab **Catatan** di tablet menampilkan daftar catatan Anda di kiri dan catatan terpilih di kanan. Mengetuk sebuah catatan membukanya di panel samping sehingga Anda bisa menelusuri beberapa catatan berturut-turut tanpa meninggalkan daftar. Membuat atau menyunting catatan juga memakai panel samping.

## Tampilan terbagi Pencarian

Di tablet, tab **Pencarian** menampilkan formulir pencarian di kiri dan hasilnya di kanan segera setelah Anda menjalankan pencarian. Anda bisa menyempurnakan kueri dan menyaksikan hasilnya diperbarui tanpa berganti layar. Di ponsel, hasil pencarian terbuka di layar terpisah.

## Bilah samping kategori Pengaturan

Layar **Pengaturan** di tablet menampilkan daftar kategori di kiri (AI, Tampilan, Cadangan, Alkitab, dan seterusnya). Ketuk sebuah kategori untuk melompat langsung ke setelannya di kanan. Hanya kategori terpilih yang terbuka, sehingga Anda tidak pernah perlu menggulir seluruh daftar setelan.

## Navigasi Alkitab di tablet

Layar **Daftar Alkitab**, **Kitab-Kitab Alkitab**, dan **Pasal-Pasal Alkitab** tetap satu kolom di tablet, tetapi memakai target sentuh yang lebih besar, kisi yang lebih lebar, dan lapisan yang lebih lega agar isinya lebih mudah dibaca dan diketuk. Layar-layar ini tidak memakai tata letak terbagi karena setiap langkah membutuhkan lebar penuh untuk menampilkan daftar atau kisinya dengan jelas.

## Lanskap dan potret

Memutar tablet menyesuaikan tata letak secara otomatis. Dalam **lanskap**, panel samping punya banyak ruang. Dalam **potret**, panel menjadi lebih sempit tetapi tetap berada di samping teks.

## Obrolan AI ayat terpilih

Obrolan **AI** terbuka di panel samping menu ayat. Panel menampilkan antarmuka percakapan tempat Anda bisa bertanya tentang ayat terpilih. Jawaban AI muncul di panel, dan Anda bisa melanjutkan percakapan tanpa meninggalkan pembaca.

## Bilah samping percakapan di layar AI

Di tab **AI** di tablet, daftar percakapan selalu terlihat sebagai bilah samping kiri yang menetap. Anda bisa berpindah antarobrolan tanpa membuka menu. Tombol **Obrolan Baru** juga selalu terlihat. Di ponsel, daftar percakapan berupa laci munculan.

## Apa yang tetap sama

Tidak setiap layar terbagi menjadi dua panel. Layar-layar berikut tetap satu kolom di tablet:

- **Daftar Alkitab** — daftar versi Alkitab (lebar penuh)
- **Kitab-Kitab Alkitab** — kisi kitab dan bagiannya (lebar penuh)
- **Pasal-Pasal Alkitab** — kisi pasal (lebar penuh)
- **PDF** — pustaka PDF memakai kisi kartu yang lebih lebar (lebar penuh)
- **Pengaturan** — halaman-halaman setelan individual (lebar penuh)
- **Bantuan** — artikel bantuan (lebar penuh)

## Ringkasan

Di tablet, Anda mendapatkan:

- **Alkitab paralel** dalam panel vertikal berdampingan
- **Komentar** dalam panel samping yang menetap
- **Bandingkan** dan **Kamus** dalam kartu lebar
- **Leksikon** dari satu ketukan pada kartu Info Kata mana pun
- **Penanda, Sorotan, Catatan, Renungan, Buku, Pengaturan** dalam tampilan terbagi master-detail
- **Pencarian** dengan hasil sebaris di samping formulir pencariannya
- **Lanskap** dan **potret** keduanya didukung dengan perubahan tata letak otomatis

Di ponsel, semuanya memakai navigasi menyorot-ke-dalam satu kolom tradisional. Aplikasi mendeteksi lebar layar saat diluncurkan dan memilih tata letak yang tepat secara otomatis.
