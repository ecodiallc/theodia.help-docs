---
title: Mengganti Tema dan Huruf
level: everyday
categories: settings
summary: Cara mengubah tampilan aplikasi.
---

# Mengganti Tema dan Huruf

Theodia memungkinkan Anda mengubah tampilan aplikasi. Anda bisa memilih sebuah tema (terang atau gelap) dan ukuran huruf.

## Cara membuka setelan tampilan

1. Buka **Pengaturan**.
2. Ketuk **Tampilan**.

## Cara mengganti tema

Di bagian **Tampilan**, Anda melihat dua tombol tema:

- **Bawaan** — latar terang dengan teks gelap. Cocok untuk siang hari.
- **Gelap** — latar gelap dengan teks terang. Cocok untuk malam hari dan menghemat baterai.

Ketuk sebuah tema untuk menerapkannya. Perubahannya seketika.

## Cara mengganti ukuran huruf

Di bagian **Tampilan**, ketuk salah satu tombol ukuran: **---**, **--**, **-**, **Normal**, **+**, **++**, **+++**. Teks menjadi lebih kecil atau lebih besar di seluruh aplikasi. Pilih ukuran yang paling mudah Anda baca.

## Tips

- Tema gelap menghemat baterai di ponsel dengan layar OLED.
- Jika teksnya terlalu kecil untuk dibaca, perbesar ukuran huruf di aplikasi, bukan di perangkat. Setelan aplikasi lebih halus.
- Untuk membaca panjang, coba tema gelap dengan huruf yang lebih besar.
- [Aktifkan tema gurun](theodia://unlock-desert)
