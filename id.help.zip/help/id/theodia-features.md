---
title: Fitur Theodia
level: beginner
categories: welcome
summary: Gambaran singkat tentang apa yang membuat Theodia istimewa dan bagaimana aplikasi membantu Anda mempelajari Alkitab.
---

# Fitur Theodia

Theodia dirancang sebagai pendamping studi Alkitab yang lengkap. Inilah yang membuatnya menonjol.

## Utamakan Luring (Offline First)

Semuanya bekerja tanpa internet. Alkitab, komentar, leksikon, buku, dan renungan tersimpan di perangkat Anda. Anda bisa membaca, mencari, dan belajar di mana saja — di pesawat, di daerah terpencil, atau di tempat mana pun tanpa sinyal.

## Berfokus pada Privasi

Data Anda tetap bersama Anda. Catatan, sorotan, penanda halaman, dan riwayat bacaan tersimpan secara lokal di perangkat Anda. Tidak perlu akun, dan tidak ada yang dikirim ke server kecuali Anda memilih menggunakan asisten AI opsional.

## Dukungan Tablet

Theodia dirancang untuk ponsel dan tablet. Di layar yang lebih besar, Anda mendapat lebih banyak ruang untuk membaca, tampilan Alkitab paralel, dan tata letak yang memanfaatkan ruang ekstra itu.

## Sumber Daya yang Dapat Dipasang

Anda tidak terbatas pada apa yang disertakan aplikasi. Anda bisa menambahkan lebih banyak versi Alkitab, komentar, leksikon, buku, dan renungan. Sumber daya tersedia dari halaman GitHub proyek dan dapat dipasang langsung ke dalam aplikasi.

## Asisten AI

Asisten AI opsional membantu Anda memahami ayat, menjelaskan konteks, dan menjawab pertanyaan. Asisten hanya aktif jika Anda menyalakannya. Secara bawaan, asisten terhubung ke model jarak jauh yang Anda sediakan melalui endpoint dan kunci API yang Anda konfigurasi. Saat pertama kali menggunakan AI, aplikasi meminta izin Anda dan menunjukkan dengan tepat apa yang dikirim.

## Membaca Alkitab Paralel

Baca hingga empat versi Alkitab sekaligus. Saat Anda membuka sebuah pasal, terjemahan utama Anda muncul lebih dulu, dan setiap ayat diikuti ayat yang sama dalam terjemahan paralel pilihan Anda. Bandingkan rumusan kata, pelajari perbedaannya, dan dapatkan gambaran teks yang lebih utuh. Simpan kombinasi favorit Anda sebagai preset dan ganti dengan cepat.

## Pencarian Teks Penuh

Cari di semua versi Alkitab. Cari kata, frasa, atau kecocokan sebagian. Anda juga bisa membatasi pencarian pada rentang buku tertentu.

## Referensi Silang

Ketuk referensi ayat untuk langsung melompat ke bagian tersebut. Referensi silang sudah tertanam dan berlaku di seluruh Alkitab.

## Leksikon dan Angka Strong

Ketuk angka Strong untuk melihat definisi asli dalam bahasa Yunani atau Ibrani. Entri leksikon disertakan untuk studi kata yang lebih mendalam.

## Penanda Halaman dan Sorotan

Simpan ayat dengan penanda halaman dan tandai dengan warna. Semuanya tersimpan lokal dan bertahan antar sesi.

## Catatan

Tulis pemikiran Anda di samping ayat mana pun. Catatan terkait dengan ayat dan mudah ditemukan nanti.

## Renungan Harian

Mulai hari Anda dengan renungan singkat. Aplikasi ini menyertakan renungan yang terbuka ke bacaan hari ini secara otomatis.

## Buku Kristen

Baca literatur Kristen klasik di dalam aplikasi. Buku-buku diformat agar mudah dibaca dan dilengkapi daftar isi untuk navigasi cepat.

## Membaca PDF

Impor dokumen PDF milik Anda dan bacakan secara luring, tersusun dalam kategori. Pembaca mendukung pencarian, daftar isi, penanda halaman, zoom, dan membaca tegak. Anda juga bisa memasang koleksi PDF terpaket dari repositori komunitas.

## Banyak Bahasa

Theodia mendukung banyak bahasa untuk antarmuka aplikasi maupun konten Alkitab. Ganti bahasa di pengaturan untuk belajar dalam bahasa pilihan Anda.

## Mode Gelap dan Tema

Pilih mode terang atau gelap, atau pilih tema yang sesuai selera Anda. Kenyamanan membaca itu penting, terutama saat cahaya redup.

## Pencadangan Data

Cadangkan catatan, penanda halaman, dan sorotan Anda. Jaga keamanan data Anda dan pindahkan ke perangkat baru bila diperlukan.

## Tanpa Iklan, Tanpa Gangguan

Theodia dibangun untuk fokus. Tidak ada iklan, tidak ada jendela munculan, dan tidak ada interupsi. Hanya teks dan alat belajar Anda.
