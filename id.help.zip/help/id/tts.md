---
title: Membaca Tegak (Teks-ke-Suara)
level: everyday
categories: tts
summary: Minta Theodia membacakan Alkitab atau renungan dengan suara. Cara memakainya, cara memilih suara, dan yang perlu dilakukan saat tidak bersuara.
---

# Membaca Tegak (Teks-ke-Suara)

> **Mode:** Teks-ke-suara tersedia di mode **Standar** dan **Pelajar**. Mode Fokus hanya untuk membaca yang bersih tanpa gangguan. Anda bisa mengganti mode di **Pengaturan** → **Mode Pengguna Aplikasi**.

Theodia bisa membacakan teks dengan suara menggunakan suara teks-ke-suara (TTS) perangkat Anda. Anda bisa mendengarkan satu ayat, satu pasal utuh, atau sebuah renungan. Ini berguna untuk membaca tanpa tangan, mendengarkan saat berjalan atau di perjalanan, membaca sambil mengikuti audio, atau sekadar memberi mata Anda istirahat.

## Di mana tombol dengarkan berada

Anda akan menemukan tombol dengarkan di tiga tempat.

### 1. Di menu ayat (satu ayat)

Ini cara tercepat untuk mendengarkan satu ayat dalam satu waktu. Buka sebuah pasal di [Mode Studi](theodia://help/study-mode), ketuk sebuah ayat untuk membuka menu ayat, lalu ketuk **Bacakan** (🔊). Pembacaan dimulai dari ayat itu. Bilah kontrol kecil muncul di bagian bawah layar berisi putar, jeda, mundur, maju cepat, dan pemilih suara.

Opsi Bacakan tidak ditampilkan untuk Alkitab interlinear (MIB — Marvel Interlinear Bible — dan OHGB), karena keduanya menampilkan kata-kata dalam tata letak berbeda yang tidak terbaca secara alami.

### 2. Di bagian atas sebuah pasal (pasal utuh)

Saat Anda membaca sebuah pasal, perhatikan baris ikon di bagian atas layar. Ketuk **Dengarkan** (🔊) untuk mulai membacakan seluruh pasal dari awal. Tombol itu berubah menjadi tombol berhenti (⏹) selama audio diputar. Ketuk lagi untuk berhenti. Bilah kontrol yang sama muncul di bagian bawah.

Anda bisa melompat ke ayat yang berbeda, dan tombol Dengarkan di sana akan mulai dari ayat itu.

### 3. Di sebuah renungan

Buka hari renungan mana pun, lalu ketuk tombol **Dengarkan** (🔊) di bagian atas bacaannya. Seluruh teks renungan dibacakan dengan suara, kalimat demi kalimat. Bilah kontrol di bagian bawah memberi Anda putar, jeda, mundur, dan kontrol suara.

## Memakai bilah kontrol

Selama audio diputar, sebuah bilah kecil tetap terlihat di bagian bawah layar. Bilah itu memiliki enam kontrol:

- ⏪ **Mundur** — kembali satu ayat (atau satu kalimat di renungan)
- ⏸ **Jeda / ▶ Lanjut** — jeda tanpa kehilangan posisi Anda. Ketuk lagi untuk melanjutkan dari tempat yang sama.
- ⏩ **Maju cepat** — lompat ke ayat berikutnya (atau kalimat berikutnya di renungan)
- 🎙 **Suara** — buka pemilih suara tanpa meninggalkan pasal (lihat di bawah)
- ⚙ **Opsi** — buka panel opsi lanjutan (lihat di bawah)
- **Berhenti** — ketuk tombol 🔊 di bagian atas layar, atau ⏹ yang menggantikannya selama audio diputar, untuk berhenti dan menutup bilahnya.

Bilah kontrol tertutup ketika pasal selesai atau ketika Anda mengetuk berhenti.

### Opsi lanjutan

Ketuk ⚙ untuk membuka opsi pemutaran tambahan. Setelan-setelan ini hanya berlaku untuk pasal saat ini dan diatur ulang saat Anda berganti pasal atau berhenti mendengarkan.

- ⏮ **Kembali ke awal** — lompat ke ayat pertama dari rentang yang Anda tetapkan.
- **Awal** — ketik nomor ayat untuk menetapkan di mana pembacaan dimulai.
- **Akhir** — ketik nomor ayat untuk menetapkan di mana pembacaan berhenti.
- **Semua** — atur ulang rentangnya ke pasal penuh.
- **()** — alihkan apakah teks dalam tanda kurung dibacakan dengan suara.
- 🔁 **Ulang** — otomatis memulai ulang dari awal rentang ketika bagian akhir tercapai, dengan jeda singkat di antaranya. Jika Anda menyalakannya tanpa menetapkan ayat awal atau akhir, seluruh pasal diulang.

### Di layar doa

Pengakuan iman dan doa baku, doa yang dibuat otomatis, dan rutinitas doa memiliki set opsi lanjutan sendiri. Ketuk ⚙ di bilah kontrol untuk membukanya:

- **Kecepatan** — ketuk lajunya (misalnya `1x`) untuk memilih kecepatan baca dari 0.1x sampai 1.5x. Pilihan Anda diingat dan dipakai saat berikutnya Anda membacakan sesuatu.
- **()** — alihkan apakah teks dalam tanda kurung dibacakan dengan suara.
- 🔁 **Ulang** — otomatis memulai ulang doa dari awal ketika selesai, dengan jeda singkat di antaranya. Ini berguna untuk menghafal sebuah pengakuan iman atau doa baku.

Mengubah kecepatan langsung berlaku, tanpa kehilangan posisi Anda. Menyalakan atau mematikan opsi tanda kurung memulai ulang doa dari awal agar perubahannya terdengar dari awal.

## Cara mengganti suara

Anda bisa memilih suara mana yang dipakai Theodia untuk membaca. Ini berguna jika Anda menginginkan aksen berbeda, bahasa berbeda, atau suara yang lebih cepat atau lebih lambat dari bawaan perangkat.

1. Buka **Pengaturan**.
2. Temukan bagian **Pidato**.
3. Ketuk **Pilih Suara**.
4. Daftar suara muncul. Baris pertama, **Bawaan Sistem**, memakai suara yang diutamakan perangkat Anda. Pilih baris lain mana pun untuk menjadikannya bawaan baru.
5. Pilihan Anda tersimpan dan dipakai saat berikutnya Anda mengetuk **Dengarkan** atau **Bacakan**.

Anda juga bisa mengetuk ikon 🎙 di bilah kontrol dengarkan untuk membuka pemilih yang sama tanpa meninggalkan pasal.

Ketersediaan suara sepenuhnya bergantung pada perangkat Anda. iOS dan Android masing-masing membundel sekumpulan suara bawaan. Anda bisa memasang lebih banyak suara dari setelan **Aksesibilitas** atau **Bahasa & Masukan** perangkat Anda. Theodia bisa memakai suara mana pun yang terpasang di perangkat Anda.

## Suara favorit

Jika perangkat Anda memiliki banyak suara, menggulir seluruh daftar setiap kali bisa lambat. Anda bisa membuat daftar pendek **suara favorit** dan pemilih suara hanya akan menampilkan suara-suara itu.

1. Buka **Pengaturan**.
2. Temukan bagian **Pidato**.
3. Ketuk **Suara Favorit** (baris pertama di bagian atas bagian itu).
4. Ketuk **Atur Suara Favorit** untuk membuka layar favorit.
5. Ketuk tombol putar di sebelah sebuah suara untuk mendengar pratinjaunya. Ketuk bintangnya untuk menambahkannya ke favorit. Anda bisa memfavoritkan sebanyak suara yang Anda suka.
6. Kembali. Pemilih suara di seluruh Theodia kini hanya menampilkan suara favorit Anda.

Jika Anda menghapus semua favorit, pemilihnya kembali menampilkan setiap suara. Suara favorit ikut disertakan saat Anda mencadangkan dan memulihkan setelan Theodia.

## Menetapkan suara berbeda per Alkitab

Anda bisa memberi setiap terjemahan Alkitab suaranya sendiri. Ini berguna saat Anda berganti-ganti terjemahan yang terbaca sangat berbeda — misalnya, suara yang lebih formal untuk King James Version dan suara yang lebih percakapan untuk terjemahan modern seperti NIV atau NLT. Ini juga membantu jika Anda mendengarkan Alkitab dalam bahasa-bahasa berbeda dan ingin masing-masing dibacakan dengan aksen yang tepat.

1. Buka **Pengaturan**.
2. Temukan bagian **Pidato**.
3. Cari **Suara Alkitab**.
4. Ketuk Alkitab mana pun dalam daftar.
5. Pilih suara yang Anda inginkan untuk terjemahan itu. Baris pertama, **Bawaan Sistem**, memakai suara TTS utama Anda untuk Alkitab itu.
6. Ulangi untuk Alkitab lain.

Kepalanya menampilkan berapa banyak terjemahan Alkitab yang memiliki suara khusus. **Pilih Suara**, **Suara Komentar**, **Suara Catatan Alkitab**, dan **Suara Renungan** juga menampilkan hitungan ketika suara telah ditetapkan.

Saat berikutnya Anda mendengarkan sebuah pasal dari Alkitab itu, Theodia akan memakai suara yang Anda pilih. Semua Alkitab lain terus memakai suara bawaan utama kecuali Anda mengubahnya juga.

## Melanjutkan pidato di latar belakang

Secara bawaan, Theodia menghentikan pidato ketika Anda meninggalkan layar pembaca, berpindah ke aplikasi lain, atau mengunci ponsel Anda. Ini mencegah audio yang tak terduga saat Anda tidak lagi aktif membaca.

Untuk membiarkan pidato terus berputar di latar belakang:

1. Buka **Pengaturan**.
2. Temukan bagian **Pidato**.
3. Nyalakan **Lanjutkan pidato di latar belakang**.

Saat ini menyala, Anda bisa berganti tab, membuka aplikasi lain, atau mengunci layar dan pasal atau renungannya akan terus dibacakan. Bilah kontrolnya tetap aktif sehingga Anda bisa menjeda atau melompat dari area notifikasi (jika perangkat Anda mendukung).

Mematikan sakelar ini **saat** pidato sedang berputar akan langsung menghentikannya.

## Yang perlu dilakukan jika tidak bekerja

Teks-ke-suara bergantung pada perangkat Anda. Theodia mengirim teks ke sistem operasi, dan sistem operasi membacakannya dengan suara menggunakan sebuah suara. Jika tidak bekerja, coba langkah-langkah ini secara berurutan.

### Theodia berkata TTS tidak tersedia

Beberapa perangkat sama sekali tidak memiliki TTS. Buka **Pengaturan** dan cari bagian **TTS**. Jika bagiannya tidak ada, perangkat Anda tidak mendukung TTS di build ini.

### Daftar suaranya kosong

Pemilih suara bisa menampilkan "tidak ada suara ditemukan". Ini biasanya berarti perangkat belum selesai memuat suara-suarnya.

1. Buka **Pengaturan → Pidato → Pilih Suara**.
2. Jika daftarnya kosong, cari tombol **Uji ulang** tepat di bawah menu tarik-turun. Ketuk itu. Theodia menanyakan ulang suara-suara ke perangkat.
3. Jika masih kosong, periksa setelan sistem perangkat Anda. Di iOS, pergi ke **Pengaturan → Aksesibilitas → Konten Bicara → Suara** dan unduh sebuah suara untuk bahasa Anda. Di Android, pergi ke **Pengaturan → Bahasa & Masukan → Keluaran Teks-ke-Suara** dan ketuk **Pasang data suara**.
4. Tutup dan buka lagi Theodia agar ia mengambil suara barunya.

Jika Anda telah menetapkan suara favorit dan daftarnya kosong, pastikan setidaknya salah satu favorit Anda cocok dengan sebuah suara yang terpasang di perangkat ini.

### Mengetuk Bacakan tetapi tidak terjadi apa-apa

- Periksa bahwa perangkat tidak sedang dalam mode senyap. Sebagian besar perangkat tidak akan memutar audio TTS saat mode senyap.
- Pastikan volume perangkat sudah tinggi.
- Coba tombol **Uji ulang** di **Pengaturan → Pidato**.
- Buka **Pengaturan** dan lihat bagian **Sistem** di bagian bawah. Baris **TTS** seharusnya tertulis **Tersedia**. Jika tertulis **Tidak tersedia**, TTS dimatikan di level sistem operasi. Nyalakan lagi di sana, lalu buka kembali Theodia.

### Audio berputar tetapi bahasanya salah

Theodia mengirim teks dalam bahasa konten saat ini dan meminta perangkat untuk suara yang Anda pilih. Jika suara terpilih untuk bahasa yang berbeda, perangkat mungkin tetap membaca teksnya, tetapi akan terdengar aneh.

1. Buka **Pengaturan → Pidato → Pilih Suara**.
2. Pilih **Bawaan Sistem** agar perangkat memilih yang tepat, atau pilih sebuah suara yang bahasanya cocok dengan teks yang sedang Anda baca.

Theodia saat ini tidak membacakan Alkitab interlinear Yunani atau Ibrani dengan suara. Tombol Bacakan dan Dengarkan disembunyikan pada terjemahan-terjemahan itu.

### Audio berputar tetapi berhenti terlalu dini

Jika sebuah ayat hilang atau tidak terbaca, pasal melompat ke yang berikutnya. Jika bilahnya menutup sendiri setelah beberapa ayat, ketuk tombol **Dengarkan** (🔊) di bagian atas layar untuk memulai ulang.

### Pidato sedang berputar tetapi saya tidak tahu di mana mulainya

Jika Anda menyalakan **Lanjutkan pidato di latar belakang** dan kemudian mendengar audio tetapi tidak bisa menemukan layar yang memulainya, Anda bisa menghentikannya dari mana saja di aplikasi.

1. Buka **Pengaturan**.
2. Temukan bagian **Pidato**.
3. Ketuk tombol merah **Hentikan Pidato** di bagian bawah bagian itu.

Ini langsung menghentikan teks-ke-suara mana pun yang sedang berjalan di Theodia. Anda juga bisa membuka pemilih aplikasi di perangkat Anda dan menggeser Theodia pergi untuk memaksa menghentikan audionya.

### Terbaca terlalu cepat atau terlalu lambat

Theodia tidak mengatur kecepatan baca. Kecepatannya ditetapkan oleh suara yang dipilih. Untuk mengubahnya:

- Di iOS: **Pengaturan → Aksesibilitas → Konten Bicara → Laju Bicara**.
- Di Android: **Pengaturan → Bahasa & Masukan → Keluaran Teks-ke-Suara → Laju Pidato**.

## Tips

- Bilah kontrol tetap terlihat saat Anda berpindah antarpasal, sehingga Anda bisa menjeda, melompat, atau mengganti suara tanpa kehilangan posisi Anda.
- Theodia membaca nomor ayat sebagai jeda kecil. Anda bisa menghentikan bilahnya, menggeser ke ayat yang berbeda, lalu mengetuk putar untuk melanjutkan dari sana.
- Untuk sesi mendengarkan yang panjang, nyalakan **Jangan Ganggu** agar notifikasi tidak menyela audionya.
- Tombol 🔊 memakai volume perangkat Anda saat ini. Jika Anda memasang headphone, volumenya beralih ke level headphone.

## Membacakan sebuah PDF

Theodia juga bisa membacakan halaman-halaman PDF dengan suara. Buka sebuah PDF dan ketuk tombol **Dengarkan** (pengeras suara) di bilah alatnya. Bilah kontrol muncul berisi putar/jeda, mundur, maju cepat, berhenti, bilah kemajuan, dan pemilih kecepatan serta suara. Ketika sebuah halaman selesai, pembacaan berlanjut ke halaman berikutnya secara otomatis.

Pembacaan PDF memakai teks yang dapat dicari yang terpasang untuk PDF itu serta suara dan kecepatan yang sama dengan pembacaan Alkitab.

## Panduan terkait

- Panduan [Mode Studi](theodia://help/study-mode) membahas menu ayat dan tombol-tombol bagian atas layar lebih detail.
- Panduan [Mode Fokus](theodia://help/focus-mode) adalah tampilan baca yang lebih bersih dan juga mendukung TTS melalui tombol 🔊 di bilah bawah.
- Panduan [Masalah Umum](theodia://help/common-problems) memuat perbaikan untuk masalah audio, suara, dan bahasa lainnya.
- Panduan [Renungan Harian](theodia://help/daily-devotionals) membahas pembacaan renungan dan letak tombol dengarkan di layar itu.
- Panduan [PDF](theodia://help/pdfs) membahas pembaca PDF dan tombol dengarkannya.
