---
title: Selamat Datang di Theodia
level: beginner
categories: welcome
summary: Tur singkat tentang aplikasi dan apa yang bisa dilakukannya untuk Anda.
---

# Selamat Datang di Theodia

Theodia adalah aplikasi studi Alkitab. Aplikasi ini berjalan di ponsel atau tablet Anda, bahkan saat Anda tidak punya internet. Semua yang Anda baca, cari, dan pelajari tersimpan di perangkat Anda.

## Apa yang bisa Anda lakukan

Theodia memiliki tiga mode pengguna. Setiap mode menampilkan fitur yang berbeda.

- **Pembaca (Reader)** — membaca Alkitab dalam tampilan bersih tanpa gangguan.
- **Standar (Standard)** — semuanya di Pembaca, ditambah penanda halaman, sorotan, catatan, teks-ke-suara, pencarian, dan renungan harian.
- **Pelajar (Scholar)** — semuanya di Standar, ditambah komentar, leksikon, Kamus Alkitab, asisten AI, dan lainnya.

Anda bisa mengganti mode kapan saja di **Pengaturan** → **Mode Pengguna Aplikasi**.

### Fitur yang tersedia untuk Anda

Mode apa pun yang Anda pilih, Anda selalu bisa:

- **Membaca Alkitab.** Pilih dari banyak terjemahan. Ganti kapan saja.
- **Mencari di Alkitab.** Cari sebuah kata atau frasa. Aplikasi menampilkan setiap ayat yang cocok.
- **Membaca buku dan renungan.** Aplikasi ini dilengkapi karya klasik Kristen dan renungan harian.

Tergantung mode Anda, Anda mungkin juga bisa:

- **Mendengarkan.** Minta ayat dibacakan dengan fitur baca-tegak. (Standar dan Pelajar.)
- **Membuat catatan.** Tulis pemikiran Anda di samping sebuah ayat. (Standar dan Pelajar.)
- **Menyorot.** Tandai ayat favorit Anda dengan warna. (Standar dan Pelajar.)
- **Menandai.** Simpan ayat agar mudah ditemukan lagi. (Standar dan Pelajar.)
- **Bertanya kepada asisten AI.** Dapatkan bantuan memahami sebuah ayat. (Hanya Pelajar.)

## Di mana memulai

1. Buka tab **Alkitab** di bagian bawah layar.
2. Pilih sebuah terjemahan.
3. Ketuk buku apa pun untuk mulai membaca.

Jika Anda ingin belajar lebih banyak, panduan bantuan lainnya tersedia untuk Anda. Pilih topik dari daftar di beranda bantuan.

## Beberapa hal yang perlu diketahui

- Anda tidak perlu membuat akun.
- Catatan, sorotan, dan penanda Anda tetap di perangkat Anda.
- Anda bisa mencadangkannya. Lihat panduan [Mencadangkan Data Anda](theodia://help/backups) untuk caranya.

## Ingin sumber daya lebih banyak?

Aplikasi ini dilengkapi beberapa versi Alkitab yang tersedia bebas. Untuk Alkitab, komentar, leksikon, buku, dan renungan tambahan, lihat panduan [Mendapatkan Sumber Daya Tambahan dari GitHub](theodia://help/getting-core-files). Panduan itu menunjukkan cara menemukan dan menambahkan lebih banyak sumber daya dari halaman GitHub proyek.

Selamat datang. Kami harap Theodia membantu Anda membaca dan belajar.
