---
title: Apa Itu Sumber Daya?
level: beginner
categories: resources
summary: Gambaran umum tentang berbagai jenis berkas yang digunakan Theodia — Alkitab, komentar, buku, dan lainnya.
---

# Apa Itu Sumber Daya?

Di Theodia, "sumber daya" adalah berkas apa pun yang menambah bahan bacaan atau bahan belajar ke dalam aplikasi. Aplikasinya sendiri hanyalah pembaca dan buku catatan. Alkitab, komentar, buku, dan bahan lain yang Anda pelajari semuanya adalah berkas terpisah yang Anda muat masuk.

Panduan ini menjelaskan jenis-jenis sumber daya dan kegunaan masing-masing.

## Mengapa ini penting?

Saat pertama kali membuka Theodia, aplikasi sudah memiliki beberapa bahan untuk dibaca. Seiring Anda menjelajah, Anda akan melihat tombol untuk memasang lebih banyak. Mengetahui apa itu masing-masing jenis sumber daya akan membantu Anda memutuskan apa yang perlu ditambahkan.

## Jenis-jenis sumber daya

Theodia mengenali berkas berdasarkan ekstensinya. Setiap ekstensi adalah jenis sumber daya yang berbeda.

### `.bible` — terjemahan Alkitab

Terjemahan Alkitab adalah salinan lengkap Alkitab dalam versi tertentu, seperti King James Version. Theodia dilengkapi beberapa terjemahan dan memungkinkan Anda menambahkan lebih banyak.

Lihat panduan [Memasang Terjemahan Alkitab](theodia://help/installing-bibles) untuk detailnya.

### `.commentary` — komentar

Komentar adalah buku catatan studi yang ditulis oleh ahli Alkitab. Untuk suatu ayat, komentar memberi tahu Anda latar belakangnya, maknanya, dan bagaimana ayat itu berhubungan dengan bagian Alkitab lainnya.

Lihat panduan [Komentar dan Leksikon](theodia://help/commentaries-and-lexicons) untuk detailnya.

### `.lexicon` — leksikon

Leksikon adalah kamus kata-kata Alkitab. Leksikon memberi tahu Anda kata asli dalam bahasa Ibrani atau Yunani, artinya, dan bagaimana kata itu digunakan dalam Alkitab.

Lihat panduan [Komentar dan Leksikon](theodia://help/commentaries-and-lexicons) untuk detailnya.

### `.book` — buku Kristen

Buku adalah karya Kristen yang lebih panjang, seperti karya klasik dari sejarah gereja. Membaca buku di aplikasi bekerja mirip dengan membaca Alkitab. Theodia dilengkapi perpustakaan kecil karya klasik Kristen yang tersedia bebas.

Lihat panduan [Membaca Buku Bawaan](theodia://help/reading-books) untuk detailnya.

### `.devotional` — renungan

Renungan adalah bacaan harian singkat. Setiap entri biasanya berisi sebuah ayat, renungan singkat, dan doa atau pertanyaan untuk dipikirkan. Banyak renungan dirancang untuk dibaca satu entri per hari selama setahun.

Lihat panduan [Renungan Harian](theodia://help/daily-devotionals) untuk detailnya.

### `.sqlite` — basis data referensi

Basis data referensi adalah berkas pencarian besar yang digunakan aplikasi untuk memberi Anda informasi tambahan saat membaca. Ada dua jenis:

- **Referensi silang** — daftar ayat-ayat yang terhubung dengan ayat yang sedang Anda baca.
- **Morfologi** — informasi tentang kata-kata asli dalam bahasa Ibrani atau Yunani pada ayat tersebut.

Anda tidak membukanya secara langsung. Berkas ini bekerja di latar belakang dan menambahkan fitur ke pembaca Alkitab. Lihat panduan [Referensi Silang](theodia://help/cross-references) untuk detailnya.

### `.data` — data kata

Berkas data kata menyimpan informasi tambahan tentang kata-kata asli Alkitab. Berkas ini digunakan oleh leksikon dan alat belajar. Seperti basis data referensi, Anda tidak membukanya secara langsung. Aplikasi menggunakannya di latar belakang.

## Cara menambahkan sumber daya

Layar **Kelola Sumber Daya** di aplikasi adalah cara mudah menambahkan sumber daya.

1. Buka **Pengaturan**.
2. Ketuk **Kelola Sumber Daya**.
3. Ketuk **Pasang dari GitHub**.
4. Di jendela unduhan, pilih tab — **Alkitab**, **Komentar**, **Buku**, **Renungan**, atau **Inti** — lalu pilih yang Anda inginkan dan ketuk **Pasang yang Dipilih**.
5. Atau ketuk **Pasang Berkas Lokal** untuk mengimpor berkas yang sudah Anda unduh.

Untuk panduan langkah demi langkah mendapatkan berkas langsung dari GitHub, lihat panduan [Mendapatkan Sumber Daya Tambahan dari GitHub](theodia://help/getting-core-files).

## Cara menghapus sumber daya

1. Buka **Pengaturan**.
2. Ketuk **Kelola Sumber Daya**.
3. Temukan sumber daya yang ingin dihapus.
4. Ketuk ikon tempat sampah di sebelahnya.
5. Konfirmasi bahwa Anda ingin menghapusnya.

Menghapus sumber daya tidak menghapus catatan, sorotan, atau penanda halaman Anda. Semua itu tetap aman.

## Di mana sumber daya tersimpan di perangkat Anda

Sumber daya tersimpan di perangkat Anda, bukan di awan. Setelah sumber daya dipasang, Anda tidak perlu internet untuk membacanya. Anda bisa mencadangkan perangkat Anda, tetapi sumber daya itu sendiri tidak dicadangkan ke awan oleh Theodia. Jika Anda menghapus dan memasang ulang aplikasi, Anda perlu menambahkan kembali semua sumber daya yang pernah Anda pasang.

## Bantuan dan pertanyaan

Jika Anda mengalami kesulitan, lihat panduan [Ke Mana Harus Bertanya](theodia://help/getting-more-help). Tim dan komunitas siap membantu.
