---
title: Basi dell'IA
level: advanced
categories: ai
summary: Come usare l'assistente IA per capire i versetti.
---

# Basi dell'IA

> **Modalità:** l'assistente IA richiede la modalità **Studioso**. Puoi cambiare modalità in **Impostazioni** → **Modalità utente app**.

Theodia ha un assistente IA. Può aiutarti a capire un versetto, rispondere a una domanda o parlare di un argomento biblico.

## Come attivare l'IA

L'IA è disattivata per impostazione predefinita. Per attivarla:

1. Apri **Impostazioni**.
2. Tocca **Assistente IA**.
3. Tocca l'interruttore per attivarla.

## Come aprire l'IA

Tocca la scheda **IA** in basso. Si apre una finestra di chat.

## Come fare una domanda

Tocca il campo in basso. Digita la tua domanda. Tocca **Invia**.

Alcune domande che puoi fare:

- "Cosa significa Giovanni 3:16?"
- "Parlami della lettera ai Romani."
- "Qual è il frutto dello Spirito?"
- "Confronta il Discorso della montagna in Matteo e Luca."

## Come chiedere di un versetto specifico

1. Apri un capitolo.
2. Tocca un versetto per aprire il menu.
3. Tocca **Commento IA**.

Il versetto viene inviato all'IA. Il pannello IA si apre con il versetto già inserito. Puoi aggiungere una domanda, come "Cosa significa?" o "Come posso applicarlo?"

## Cose importanti da sapere

- L'IA è uno strumento, non una persona. Può sbagliare.
- Controlla sempre le risposte dell'IA confrontandole con la Bibbia.
- L'IA può richiedere internet. Non funziona offline.
- Quando usi l'IA, le tue domande, il contesto del versetto e la chiave API vengono inviati all'endpoint che scegli. La prima volta l'app chiede il tuo permesso e mostra esattamente cosa viene inviato. Puoi modificare o revocare quel permesso in seguito in **Impostazioni → Assistente IA → Condivisione dati IA remota**.
- In alcune regioni, come la build del App Store cinese, l'assistente IA non è disponibile. In quella build solo le funzionalità bibliche offline sono disponibili.

## Come gestire le conversazioni

La schermata IA conserva un elenco delle conversazioni passate. Dall'elenco puoi riaprire una conversazione vecchia, iniziarne una nuova o eliminarne una che non ti serve più.

## Approfondisci con l'IA

Questa pagina copre le basi. L'IA di Theodia può fare molto di più della semplice chat. Ecco dove andare dopo:

- **[Funzionalità IA](theodia://help/ai-features)** — Scopri tutto ciò che Teofilo può fare: studio di un versetto in greco e in ebraico, catene di riferimenti incrociati, schemi di sermone, generazione di preghiere, morfologia delle lingue originali, ricerche nei dizionari e navigazione a mani libere nell'app. Questa guida ti mostra come trasformare l'IA da chatbot in un vero compagno di studio.
- **[Scrivere prompt IA migliori](theodia://help/ai-prompts)** — Impara l'arte di fare domande che ottengono risposte ricche e accurate. Pochi accorgimenti nel modo in cui formulai la richiesta possono sbloccare risposte molto più approfondite.
- **[Scegliere un modello IA](theodia://help/choosing-a-model)** — Non tutti i modelli IA sono uguali. Scopri quali supportano gli strumenti integrati di Theodia (come aprire versetti e cercare nella Scrittura) e quali trasformano l'IA in un vero assistente di studio biblico a mani libere.
- **[GitHub Models](theodia://help/github-models)** — Il provider gratuito consigliato per Theodia. Ottieni una chiave API gratuita con un account GitHub e inizia a fare domande con un generoso limite giornaliero. Nessuna carta di credito, nessun abbonamento.
- **[Chiavi API e costi](theodia://help/ai-keys-and-costs)** — Capisci come funzionano i prezzi delle API tra i diversi provider e come mantenere i costi vicini allo zero.
