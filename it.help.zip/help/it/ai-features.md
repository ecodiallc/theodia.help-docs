---
title: Funzionalità IA
level: advanced
categories: ai
summary: Scopri tutto ciò che l'IA di Theodia può fare, dallo studio versetto per versetto alla preparazione di sermoni, all'esplorazione delle lingue originali e alla navigazione a mani libere.
---

# Funzionalità IA

> **Modalità:** l'assistente IA richiede la modalità **Studioso**. Puoi cambiare modalità in **Impostazioni** → **Modalità utente app**.

L'assistente IA di Theodia, Teofilo, non è solo un chatbot. È un compagno di studio che può leggere la Bibbia insieme a te, consultare commentari, cercare nella Scrittura, gestire le tue note e persino navigare nell'app, tutto a voce o per iscritto.

Prima che Teofilo invii dati a un endpoint IA per la prima volta, l'app mostra una richiesta di consenso che spiega cosa viene inviato e chiede il tuo permesso. Puoi modificare o revocare quel permesso in qualsiasi momento in **Impostazioni → Assistente IA → Condivisione dati IA remota**.

## Commento IA sul versetto: studia un versetto in profondità

Il **Commento IA sul versetto** è il cuore dell'esperienza IA di Theodia. Mentre leggi un capitolo, tocca il numero di un versetto (oppure tienilo premuto) e scegli **Commento IA**. Si apre un pannello di chat con quel versetto già caricato. L'IA sa esattamente cosa stai leggendo ed è pronta ad esplorarlo con te.

### Avvii rapidi

Non sai cosa chiedere? Il pannello mostra otto pulsanti istantanei:

- **Spiega questo versetto** — Ottieni una spiegazione chiara e ragionata del significato e della portata.
- **Lingua originale** — Vedi le parole greche o ebraiche, le traslitterazioni e le definizioni lessicali dietro il testo inglese.
- **Contesto storico** — Scopri la cultura, la politica e gli eventi intorno al versetto.
- **Contesto testuale** — Vedi come il versetto si inserisce nel paragrafo, nel capitolo e nel libro circostanti.
- **Temi principali** — Scopri le grandi idee che questo versetto contribuisce alla teologia biblica.
- **Applica alla mia vita** — Ricevi applicazioni pratiche e personali su cui agire oggi.
- **Genera una preghiera** — Trasforma il versetto in una preghiera modellata sul suo linguaggio e le sue verità.
- **Genera uno schema di sermone** — Ottieno uno schema a tre punti con introduzione e conclusione, pronto da predicare.

Tocca un pulsante qualsiasi e l'IA inizia subito. Puoi poi fare domande di approfondimento, chiedere chiarimenti o indirizzare la conversazione in una nuova direzione.

### Conversazione naturale

L'IA ricorda gli ultimi messaggi della chat, quindi puoi scavare più a fondo in modo naturale:

- "Puoi dirlo più semplicemente?"
- "Cosa dice il greco originale qui?"
- "Mostrami i riferimenti incrociati collegati a questo."
- "Confronta questo versetto in tre traduzioni diverse."
- "Come sarebbe questo in un ambiente di lavoro moderno?"
- "Dammi tre applicazioni in più per un genitore."

La conversazione resta ancorata al versetto, quindi ogni risposta è radicata nel testo che stai leggendo.

### Tocca qualsiasi riferimento biblico

Quando l'IA cita un altro versetto, per esempio "Questo rispecchia Romani 8:28", il riferimento appare come un **link toccabile**. Toccalo e l'app salta a quel passaggio nel lettore biblico. Puoi esplorare la catena di riferimenti senza mai lasciare la conversazione.

## Cosa può fare l'IA oltre al commento sul versetto

Teofilo ha accesso all'intero contenuto di Theodia: Bibbie, commentari, lessici, dizionari, libri, devozionali, le tue note, i segnalibri e le evidenziazioni. Ecco cosa significa in pratica.

### Leggere e navigare nella Scrittura

- **Leggere qualsiasi versetto o capitolo** — "Leggi Giovanni 3:16 in WEB" oppure "Leggi il Salmo 23 ad alta voce."
- **Aprire passaggi nel lettore** — "Portami a Genesi 1" oppure "Apri Romani 8:28."
- **Confrontare versioni** — "Mostrami Giovanni 3:16 in tutte le mie Bibbie."
- **Cercare nella Bibbia** — "Trova versetti sul perdono" oppure "Cerca 'pace che supera ogni intelletto.'"
- **Ottenere riferimenti incrociati** — "Quali altri versetti si collegano a Isaia 53:5?"
- **Leggere i titoli di sezione** — "Quali sono i sottotitoli in Matteo 5?"

### Esplorare le lingue originali

- **Ricerche lessicali** — "Cosa significa la parola greca 'agape' in Giovanni 3:16?" oppure "Consulta Strong G26."
- **Morfologia** — "Analizza i verbi greci in Romani 8:28" oppure "Cosa significa il codice morfologico V-PAI-3S?"
- **Informazione parola** — L'IA vede la stessa analisi parola per parola che vedi tu: traslitterazione, glossa, grammatica e numeri di Strong.

### Leggere commentari e libri di studio

- **Commento al versetto** — "Cosa dice Matthew Henry su Efesini 2:8?"
- **Commento al capitolo** — "Dammi la panoramica del capitolo di Romani 8."
- **Commento al libro** — "Riassumi il commentario a livello di libro su Apocalisse."
- **Libri di studio** — "Leggimi un capitolo da Hymn Lyrics English" oppure "Cerca nei miei libri la parola 'pazienza'."
- **Devozionali** — "Leggi il devozionale di oggi" oppure "Trova un devozionale sull'ansia."

### Cercare nei dizionari

- "Chi era Melchisedec?"
- "Cosa dice il dizionario biblico su Gàlgala?"
- "Consulta 'propiziazione' in Easton's."

### Gestire la tua vita di studio

L'IA può agire sui tuoi dati personali, sempre salvati in locale sul tuo dispositivo:

- **Segnalibri** — "Salva questo versetto nella mia cartella Preparazione sermone" oppure "Elenca i miei segnalibri."
- **Evideniazioni** — "Evidenzia Giovanni 3:16 in giallo" oppure "Mostrami tutte le mie evidenziazioni."
- **Note** — "Crea una nota biblica su questo versetto" oppure "Leggi le mie note per Genesi 1."
- **Note di studio** — "Salva questa conversazione come nota di studio" oppure "Crea un nuovo quaderno di studio chiamato Romani Study."
- **Cartelle** — "Crea una cartella chiamata Devozione del mattino" oppure "Sposta il mio segnalibro di Giovanni 3:16 nella cartella Preghiera."

### Cambiare le impostazioni dell'app

- "Passa alla modalità scura."
- "Rendi BSB la mia Bibbia predefinita."
- "Attiva Bibbie parallele con NET."
- "Aumenta la dimensione del carattere."

### Leggere ad alta voce

- "Leggi il Salmo 23 ad alta voce" — L'IA può avviare la sintesi vocale per qualsiasi passaggio, libro o nota.
- "Smetti di leggere" — Metti in pausa la sintesi vocale in qualsiasi momento.

## Salva le tue conversazioni

Ogni chat di commento IA può essere salvata. Tocca il menu nel pannello della chat e scegli:

- **Salva come nota biblica** — Aggiunge l'intera conversazione alla nota del versetto nel lettore biblico.
- **Salva come nota di studio** — Conserva la conversazione nel tuo libro Note di studio per consultarla più tardi.

In questo modo una rapida esplorazione con l'IA diventa materiale di studio permanente, che puoi rivedere, modificare o usare per costruire sermoni.

## La scheda IA completa

Oltre al pannello di commento sul versetto, Theodia ha una scheda **IA** dedicata nella navigazione in basso. È una chat libera in cui puoi chiedere qualsiasi cosa, senza un versetto preselezionato. È utile per:

- Studi tematici su tutta la Bibbia
- Ricerca e stesura di sermoni
- Confronto di temi teologici tra libri
- Devozioni quotidiane e spunti di preghiera
- Curiosità bibliche e piani di lettura
- Aiuto sull'app — "Come funzionano le Bibbie parallele?"

Le conversazioni vengono salvate automaticamente. Puoi tornare alle chat passate, iniziarne di nuove ed eliminare quelle vecchie.

## Idee per iniziare

Ecco alcuni modi entusiasmanti di usare l'IA. Scegline uno e provalo oggi.

**Crescita personale**

- "Spiega Filippesi 4:6-7 e dammi una preghiera per quando mi sento ansioso."
- "Cosa dice la Bibbia sul riposo? Trovami cinque versetti e spiegali."

**Famiglia e genitorialità**

- "Come deve guidare Efesini 6:4 la genitorialità moderna? Dammi tre regole pratiche."
- "Trova versetti sull'educare i figli e leggili ad alta voce."

**Preparazione di sermoni e insegnamento**

- "Traccia uno schema per un sermone di 25 minuti su Romani 8:28, con introduzione, tre punti e conclusione."
- "Cosa dicono i miei commentari sull'armatura di Dio in Efesini 6?"
- "Confronta il Discorso della montagna in Matteo con la versione di Luca. Quali sono le differenze?"

**Studio della lingua originale**

- "Mostrami la morfologia di ogni parola in Giovanni 1:1."
- "Qual è la differenza tra 'agape' e 'philia' nel Nuovo Testamento?"

**Profondità devozionale**

- "Leggi il devozionale di oggi e collegalo a un versetto dei Salmi."
- "Dammi uno schema devozionale di sette giorni sul frutto dello Spirito."

**Catene di riferimenti incrociati**

- "Parti da Isaia 53:5 e segui il tema delle 'ferite' e della 'guarigione' attraverso il Nuovo Testamento."
- "Dove compare il concetto di 'alleanza' dalla Genesi agli Ebrei?"

**Memoria e ripasso**

- "Interroga sull'ordine dei libri della Bibbia."
- "Crea una nota di studio che riassuma il punto principale di ogni capitolo di Romani."

## Alcune note importanti

- L'IA è uno **strumento**, non un sostituto della Bibbia o della guida pastorale. Confronta sempre le sue risposte con la Scrittura stessa.
- Quando usi l'IA, le tue domande viaggiano su internet verso i server del provider. La maggior parte dei provider non usa i tuoi dati per l'addestramento, ma il testo lascia il tuo dispositivo.
- L'IA può sbagliare. Usa come autorità finale i commentari, i lessici e il testo biblico stesso.

## Riepilogo

L'IA di Theodia è pensata per rendere lo studio della Bibbia più veloce, più profondo e più personale. Se vuoi una spiegazione di una frase difficile in una riga, uno schema di sermone completo, uno studio di una parola greca o una catena di riferimenti che attraversa tutta la Bibbia, Teofilo è pronto ad aiutarti. Tocca un versetto, fai una domanda e vedi dove ti porta la conversazione.
