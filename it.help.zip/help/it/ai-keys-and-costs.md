---
title: Chiavi API e costi
level: advanced
categories: ai
summary: Perché serve una chiave API, come ottenerla e quanto costa usare un modello IA remoto.
---

# Chiavi API e costi

> **Modalità:** l'assistente IA richiede la modalità **Studioso**. Puoi cambiare modalità in **Impostazioni** → **Modalità utente app**.

L'assistente IA si connette a modelli IA remoti. Se vuoi usarne uno, hai bisogno di una chiave API. Questa pagina spiega perché, come ottenerla e quanto costa in genere.

## Perché serve una chiave API

Un modello IA remoto risiede su un server in internet. La chiave API è come una password che dice al server: "Questa persona ha il permesso di fare domande." Senza di essa, il server non risponde.

L'app non fornisce una chiave integrata. Devi creare un tuo account con un provider e incollare la tua chiave nell'app.

## Come ottenere una chiave API

1. Apri **Impostazioni** in Theodia.
2. Tocca **Assistente IA**.
3. Scegli **Modello remoto**.
4. Scegli un provider dall'elenco, oppure **Personalizzato** e inserisci un URL base.
5. Tocca il link alla pagina delle chiavi del provider. Crea un account se non ne hai uno.
6. Genera una nuova chiave API sul sito del provider.
7. Copia la chiave e incollala in Theodia.
8. Tocca **Verifica connessione** per assicurarti che funzioni.

## Provider supportati

Theodia può connettersi a qualsiasi provider che usi un'API compatibile con OpenAI. Ecco quelli con link preimpostati nell'app:

- **GitHub Models** — github.com/marketplace/models (livello gratuito giornaliero, consigliato)
- **OpenAI** — platform.openai.com
- **OpenRouter** — openrouter.ai
- **Anthropic** — console.anthropic.com
- **Groq** — console.groq.com
- **Mistral** — console.mistral.ai
- **Together AI** — api.together.xyz

Puoi anche usare un URL base **Personalizzato** se gestisci un tuo server o usi un altro servizio.

## Quanto costa?

La maggior parte dei provider addebita per **token**. Un token è approssimativamente una parola o una parte di parola. Paghi per i token che invii (la tua domanda) più quelli che l'IA ti restituisce (la risposta).

### Prezzi indicativi

I prezzi cambiano, ma ecco un'idea approssimativa a metà 2026:

- **Modelli piccoli e veloci** (come gli endpoint economici di classe GPT-3.5) costano una frazione di centesimo per mille token.
- **Modelli di fascia media** (come GPT-4o o Claude Sonnet) costano in genere pochi centesimi per mille token.
- **Modelli di ragionamento avanzati** (come GPT-4.5 o Claude Opus) possono costare da dieci a venti centesimi per mille token.

Una tipica domanda biblica in Theodia può usare da poche centinaia a un paio di migliaia di token in totale. Quindi la maggior parte delle domande costa da **meno di un centesimo a pochi centesimi**.

### Consigli per contenere i costi

- Inizia con un modello economico. La maggior parte delle domande bibliche non ha bisogno del modello più costoso.
- Usa Groq o OpenRouter se vuoi provare modelli diversi e confrontare i prezzi.
- Tieni d'occhio la dashboard di utilizzo sul sito del provider.

## GitHub Models

[GitHub Models](https://github.com/marketplace/models) offre un livello gratuito senza abbonamento. Ti basta un account GitHub gratuito e un personal access token con permesso di leggere i modelli.

**Come configurarlo:**

1. Vai su [github.com/settings/tokens](https://github.com/settings/tokens) e crea un **Personal access token (classic)**.
2. Assegna lo scope `models:read` (oppure seleziona semplicemente il permesso models).
3. In Theodia scegli **GitHub Models** come provider e incolla il tuo token.

**Modelli del livello gratuito:**

- `openai/gpt-4.1-nano` — **15 richieste al minuto, 150 richieste al giorno**
- `openai/gpt-4.1-mini` — **15 richieste al minuto, 150 richieste al giorno**
- `openai/gpt-4.1` — **10 richieste al minuto, 50 richieste al giorno**
- `openai/gpt-4o` — **10 richieste al minuto, 50 richieste al giorno**

Questi limiti si resettano ogni giorno e sono più che sufficienti per lo studio biblico quotidiano.

Per una guida passo passo completa con screenshot, vedi la guida dedicata [GitHub Models](theodia://help/github-models).

## Nota sulla privacy

Quando usi un modello IA remoto, l'app mostra prima una richiesta di consenso che spiega cosa viene inviato: i tuoi messaggi, il contesto del versetto o capitolo, le chiamate agli strumenti e i loro risultati, il nome del modello configurato e la tua chiave API nell'intestazione della richiesta. La richiesta va direttamente all'endpoint che hai configurato, non attraverso Theodia. La maggior parte dei provider non usa i tuoi dati per addestrare i propri modelli, ma il testo lascia il tuo dispositivo. Puoi modificare o revocare il permesso in qualsiasi momento in **Impostazioni → Assistente IA → Condivisione dati IA remota**.

## Riepilogo

- Serve una chiave API per usare l'assistente IA.
- Crea un account con un provider, genera una chiave e incollala in Theodia.
- La maggior parte delle domande costa pochi centesimi o meno.
