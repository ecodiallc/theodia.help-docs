---
title: Scrivere prompt IA migliori
level: advanced
categories: ai
summary: Come rivolgerti all'assistente IA per ottenere risposte utili.
---

# Scrivere prompt IA migliori

> **Modalità:** l'assistente IA richiede la modalità **Studioso**. Puoi cambiare modalità in **Impostazioni** → **Modalità utente app**.

Un "prompt" è la domanda o l'istruzione che dai all'IA. Prompt migliori danno risposte migliori. Questa guida ti mostra come.

## Sii specifico

Scarso: "Parlami dell'amore."
Migliore: "In 1 Corinzi 13, che tipo di amore descrive Paolo e in che modo differisce dall'amore romantico?"

Più dettagli dai, più utile è la risposta.

## Dai contesto

Scarso: "Cosa significa questo versetto?"
Migliore: "Sto leggendo Romani 8 con un piccolo gruppo. Cosa significa 'nessuna condanna' in questo capitolo, e come si collega al resto del capitolo?"

Il contesto aiuta l'IA a adattare la risposta alla tua situazione.

## Chiedi una cosa alla volta

Scarso: "Parlami di preghiera, fede e guarigione."
Migliore: "Parlami prima della preghiera. Poi ti chiederò della fede."

Chiedere una cosa alla volta mantiene le risposte focalizzate.

## Chiedi all'IA di assumere un ruolo

Puoi chiedere all'IA di rispondere con una certa voce. Per esempio:

- "Rispondi come se stessi insegnando a un nuovo credente."
- "Rispondi come uno studioso della Bibbia."
- "Rispondi per un bambino di 10 anni."

L'IA adatta la risposta al ruolo.

## Usa domande di approfondimento

Se la prima risposta non è del tutto giusta, fai una domanda di approfondimento:

- "Puoi dirlo più semplicemente?"
- "Puoi darmi un esempio?"
- "Cosa dice il greco originale?"
- "Dove altro nella Bibbia viene citato questo?"

Una buona conversazione è un andirivieni. L'IA ricorda gli ultimi messaggi.

## Controlla le risposte dell'IA

L'IA può commettere errori. È uno strumento, non un maestro.

- Confronta la risposta dell'IA con i versetti che ti indica.
- Usa i commentari e i lessici nell'app per un'opinione secondaria.
- Se la risposta riguarda una dottrina, chiedi a un pastore o a un amico di fiducia.

## Pattern di prompt comuni

Ecco alcuni che funzionano bene:

- "Spiegami questo versetto come se fossi un nuovo credente."
- "Qual è il punto principale di questo capitolo in una frase?"
- "Elenca tre applicazioni per la mia vita quotidiana tratte da questo passaggio."
- "Quali domande dovrei fare su questo versetto prima di predicarlo?"
