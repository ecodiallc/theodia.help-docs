---
title: Modalità utente app
level: beginner
categories: [user-mode]
summary: Scegli tra le modalità Lettura, Standard e Studioso per controllare quali funzionalità sono disponibili nell'app.
---

# Modalità utente app

Theodia offre tre modalità utente che controllano quali funzionalità vedi. Scegli quella che corrisponde al modo in cui vuoi usare l'app.

## Lettore

La modalità più semplice. La modalità Lettura è per la lettura biblica senza distrazioni.

- Leggi qualsiasi traduzione della Bibbia
- Usa la modalità Messa a fuoco per una lettura pulita a schermo intero
- Naviga tra libri e capitoli
- Nessuno strumento di studio, nessuna IA, nessun segnalibro, nessuna evidenziazione

La modalità Lettura è ideale se vuoi che Theodia sia una Bibbia digitale pulita, senza fronzoli.

## Standard

La modalità Standard aggiunge funzionalità quotidiane per lo studio biblico personale.

Tutto ciò che c'è in Lettore, più:

- Segnalibri, evidenziazioni e note
- Sintesi vocale
- Lettore in modalità Studio con menu del versetto
- Bibbie parallele
- Comando rapido
- Ricerca nella Bibbia
- Devozionali quotidiani e libri integrati

La modalità Standard è la scelta giusta per la maggior parte degli utenti che vogliono leggere, annotare e cercare nella Bibbia senza strumenti avanzati di studio.

## Studioso

La modalità più completa. La modalità Studioso sblocca ogni strumento di Theodia per lo studio biblico approfondito.

Tutto ciò che c'è in Standard, più:

- Commentari e lessici
- Riferimenti incrociati
- Dizionario biblico
- Informazione parola (ricerche Strong)
- Assistente IA e commento IA
- Menu rapido

La modalità Studioso è pensata per pastori, studenti di teologia e chiunque voglia strumenti sulle lingue originali e aiuti di studio con l'IA.

## Come cambiare modalità

1. Apri **Impostazioni**.
2. Tocca **Modalità utente app**.
3. Scegli **Lettore**, **Standard** o **Studioso**.

La modifica ha effetto immediato. I menu e i pulsanti non disponibili nella tua modalità attuale vengono nascosti.

## Come scegliere una modalità

- **Lettore** — Vuoi solo leggere la Bibbia, nient'altro.
- **Standard** — Vuoi segnalibri, evidenziazioni, note, ricerca e devozionali.
- **Studioso** — Vuoi ogni strumento di studio, inclusi IA, commentari e lessici.

Puoi cambiare modalità in qualsiasi momento. I tuoi segnalibri, le evidenziazioni e le note non vengono mai eliminati quando cambi modalità; vengono solo nascosti finché non torni a una modalità che li supporta.
