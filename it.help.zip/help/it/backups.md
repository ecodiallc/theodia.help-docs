---
title: Backup dei dati
level: everyday
categories: settings
summary: Come salvare e ripristinare note, evidenziazioni, segnalibri e segreti.
---

# Backup dei dati

Le tue note, evidenziazioni, segnalibri e impostazioni sono salvate sul tuo dispositivo. Se perdi il telefono, ne compri uno nuovo o disinstalli l'app, quei dati possono andare persi. Questa guida ti mostra come farne un backup.

## Come aprire le impostazioni di backup

1. Apri **Impostazioni**.
2. Tocca **Backup app**.

## Come creare un backup dell'app

1. Apri **Impostazioni**.
2. Tocca **Backup app**.
3. Tocca **Crea backup app**.
4. Scegli una cartella sul tuo dispositivo per salvare il file. Puoi anche scegliere un'unità cloud.
5. L'app crea un unico file con tutti i tuoi dati. Il file termina in `.zip`.

## Quanto spesso fare un backup

Fai un backup:

- Dopo aver scritto molte note.
- Prima di aggiornare il sistema operativo del dispositivo.
- Prima di disinstallare l'app o cambiare telefono.

Una buona abitudine è un backup al mese. Alcuni lo fanno ogni settimana.

## Come ripristinare da un backup dell'app

1. Apri **Impostazioni**.
2. Tocca **Backup app**.
3. Tocca **Ripristina da backup app**.
4. Scegli il file di backup `.zip`.
5. Per ogni tipo di dato (note, evidenziazioni, segnalibri, ecc.), scegli se tenere quello presente sul dispositivo, sostituirlo con il backup o saltarlo.
6. Tocca **Ripristina**.

L'app sostituisce i tuoi dati con quelli nel backup. Questo include:

- Note
- Evidenziazioni
- Segnalibri
- Cartelle dei segnalibri
- Impostazioni (tema, dimensione carattere, lingua)

## Backup dei segreti

Il tuo **Backup app** **non** include segreti sensibili come la chiave API IA o il token GitHub. Per eseguirne un backup separato, usa **Backup segreti**.

### Salvare un backup dei segreti

1. Apri **Impostazioni**.
2. Tocca **Backup app**.
3. In **Backup segreti**, tocca **Salva backup segreti**.
4. Inserisci una password robusta e confermala.
5. L'app crittografa i tuoi segreti e condivide il file crittografato. Salvalo in un posto sicuro.

### Ripristinare un backup dei segreti

1. Apri **Impostazioni**.
2. Tocca **Backup app**.
3. In **Backup segreti**, tocca **Ripristina backup segreti**.
4. Scegli il file di backup dei segreti crittografato.
5. Inserisci la stessa password usata quando lo hai salvato.
6. I tuoi segreti sono ripristinati.

> **Importante:** se dimentichi la password, i segreti non possono essere recuperati. Non esiste alcun ripristino.

## Cose da sapere

- Un ripristino **sostituisce** le categorie che hai scelto. Tutto ciò che hai aggiunto dopo il backup andrà perso per quelle categorie.
- Un backup dell'app è un unico file `.zip`. Tienilo in un posto sicuro.
- Puoi copiare il file, spostarlo o conservarlo in qualsiasi servizio cloud.
- I backup dell'app non includono le traduzioni bibliche vere e proprie. Quelle possono essere scaricate di nuovo da **Impostazioni** → **Gestisci risorse**.
- I backup dei segreti sono crittografati con la tua password. Scegli una password che ricorderai.

## Suggerimento

Se hai più di un dispositivo, puoi copiare il file di backup su ciascuno e ripristinarlo. I tuoi dati saranno gli stessi su entrambi.
