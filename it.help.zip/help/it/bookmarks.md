---
title: Salvare i versetti nei segnalibri
level: everyday
categories: [annotate, read]
summary: Come salvare i versetti per trovarli facilmente in seguito.
---

# Salvare i versetti nei segnalibri

> **Modalità:** i segnalibri sono disponibili nelle modalità **Standard** e **Studioso**. La modalità Messa a fuoco è solo per una lettura pulita e senza distrazioni. Puoi cambiare modalità in **Impostazioni** → **Modalità utente app**.

Un segnalibro salva un versetto o un capitolo di un libro per poterlo trovare di nuovo. I segnalibri sono come i segnapagina in un libro.

## Come salvare un versetto nei segnalibri

1. Apri il versetto.
2. Tocca il versetto per aprire il menu.
3. Tocca **Segnalibro** nel menu. Un'icona a stella indica che il versetto è salvato.

Un segno di spunta sull'icona significa che il versetto è ora nei segnalibri.

## Come salvare un capitolo di un libro

Quando leggi un libro (non la Bibbia), puoi salvare l'intero capitolo:

1. Apri il capitolo.
2. Tocca l'icona **Segnalibro** in alto sullo schermo.

## Come vedere i tuoi segnalibri

Tocca la scheda **Segnalibri** in basso. Vedi un elenco di tutti i versetti e i capitoli di libri che hai salvato.

## Come rimuovere un segnalibro

- **Un versetto:** apri il versetto. Tocca il versetto, poi tocca di nuovo l'icona **Segnalibro**. Il segno di spunta scompare.
- **Dall'elenco:** nella scheda **Segnalibri**, tieni premuto un segnalibro. Appare un piccolo menu. Tocca **Elimina**. (Puoi anche toccare il piccolo pulsante × sulla riga.)

## Organizza con le cartelle

Puoi mettere i segnalibri nelle cartelle. Per esempio, potresti avere una cartella "Preparazione sermone" e un'altra "Incoraggiamento."

Per creare una cartella:

1. Apri la scheda **Segnalibri**.
2. Tocca **Gestisci cartelle** in alto.
3. Tocca **Crea cartella** in alto all'elenco delle cartelle.
4. Digita un nome e tocca **Salva**.

Non puoi creare due cartelle con lo stesso nome. Se un nome esiste già, appare un errore all'interno della casella di creazione cartella, così puoi cambiarlo e riprovare.

Per mettere un segnalibro in una cartella:

1. Nella scheda **Segnalibri**, tieni premuto un segnalibro.
2. Tocca **Sposta in cartella**.
3. Scegli la cartella, poi tocca **Fatto**.

## Importare segnalibri

Puoi portare i segnalibri in Theodia da altre app e file.

Vai su **Impostazioni** → **Segnalibri** → **Importa segnalibri**. Scegli **Importa da file** oppure incolla dagli appunti. L'app rileva automaticamente il formato.

### Formati supportati

**Esportazione JSON nativa** — Il formato usato dalla funzione di esportazione di Theodia. Conserva cartelle e date di creazione.

**HTML segnalibri Netscape** — Il formato usato da Chrome, Firefox e Safari quando esporti i segnalibri. Le cartelle vengono conservate.

**CSV** — Un foglio di calcolo con colonne. L'app cerca le colonne `url` e `folder` (oppure `href` / `category`). Esempio:

```csv
url,folder
/bible/KJV/John/3,Favorites
/bible/KJV/Genesis/1,Sermon Prep
```

**Testo semplice** — Ogni riga è un riferimento biblico, un URL dell'app o un'istruzione di cartella. Esempio:

```
folder: Favorites
John 3:16
Genesis 1:1
folder: Sermon Prep
Matthew 5:1
```

- Le righe che iniziano con `folder: <nome>` impostano la cartella attiva per tutti i segnalibri successivi.
- I riferimenti biblici come `John 3:16` vengono convertiti in segnalibri nella tua Bibbia predefinita.
- Gli URL dell'app come `/bible/KJV/John/3#v3_16` o `/book/MyBook/1` vengono importati direttamente.
- Le righe che iniziano con `#` o `//` sono considerate commenti e ignorate.

### Suggerimenti per l'importazione

- I segnalibri duplicati vengono saltati automaticamente.
- Gli URL esterni (come i link di BibleGateway) vengono convertiti in segnalibri dell'app quando possibile.
- Se una cartella del file di importazione esiste già, i segnalibri vengono messi nella cartella esistente.

## Suggerimenti

- Puoi salvare lo stesso versetto in più traduzioni. Appariranno tutti nell'elenco.
- I segnalibri restano sul tuo dispositivo. Non si sincronizzano con il cloud.
- Vedi la guida [Backup dei dati](theodia://help/backups) per tenerli al sicuro.
