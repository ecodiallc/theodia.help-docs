---
title: Scegliere un modello IA
level: advanced
categories: ai
summary: Come scegliere un modello che funzioni bene con gli strumenti integrati di Theodia.
---

# Scegliere un modello IA

> **Modalità:** l'assistente IA richiede la modalità **Studioso**. Puoi cambiare modalità in **Impostazioni** → **Modalità utente app**.

Non tutti i modelli IA funzionano allo stesso modo in Theodia. La migliore esperienza si ottiene con un modello che supporta il **tool calling** — la capacità dell'IA di usare le funzionalità integrate di Theodia, come cercare versetti biblici, fare ricerche, leggere commentari e navigare nell'app.

## Cos'è il tool calling?

Quando fai una domanda all'IA di Theodia, l'IA può fare più che parlare. Può anche **agire**. Per esempio:

- Dici: "Mostrami Giovanni 3:16 in ESV." L'IA chiama uno strumento per aprire quel versetto nel lettore.
- Dici: "Cosa dicono i miei commentari su Romani 8:28?" L'IA chiama uno strumento per recuperare il contenuto del commentario.
- Dici: "Salva questo versetto come segnalibro." L'IA chiama uno strumento per creare un segnalibro.

I modelli che non supportano il tool calling possono solo darti risposte di testo. Non possono cercare, navigare o modificare nulla nell'app.

## Quali modelli supportano i tool?

### Modelli remoti

La maggior parte dei modelli remoti moderni dei principali provider supporta il tool calling compatibile con OpenAI. In generale:

- I **modelli grandi** (come GPT-4o, Claude Sonnet/Opus, Gemini Pro) gestiscono i tool in modo affidabile e possono concatenare più chiamate in una sola conversazione. I nomi dei provider e gli ID modello sono mostrati nell'app per comodità; il servizio effettivo a cui ti connetti è quello il cui endpoint e chiave configuri.
- I **modelli più piccoli o economici** possono supportare i tool ma essere meno affidabili. Potrebbero ignorare una chiamata o formattarla in modo errato.
- I **modelli molto vecchi o specializzati** spesso non supportano affatto i tool.

Se non sei sicuro, prova il modello in Theodia. Chiedigli "Mostrami Genesi 1:1" oppure "Cerca nella Bibbia versetti sull'amore." Se il versetto si apre o appaiono i risultati della ricerca, il tool calling funziona.

## Modelli consigliati per Theodia

Queste sono buone scelte che bilanciano costo, qualità e supporto dei tool:

- **OpenAI GPT-4o** — ottimo supporto dei tool, veloce, gestisce bene domande complesse in più passaggi.
- **Anthropic Claude Sonnet / Opus** — uso dei tool molto affidabile, ottimo per passaggi lunghi e studio dettagliato.
- **Groq** (vari modelli) — inferenza veloce, spesso gratuita o molto economica, il supporto dei tool varia a seconda del modello.
- **OpenRouter** — ti permette di provare molti modelli con un solo account. Cerca modelli che elencano "function calling" o "tools" tra le loro capacità.
- **[GitHub Models](theodia://help/github-models)** — il provider gratuito consigliato. Accesso a modelli OpenAI, Anthropic e altri tramite il tuo account GitHub, con un generoso livello gratuito giornaliero. Usa gli stessi ID modello in stile `openai/gpt-4o`.

## Modelli da evitare

- I **modelli di sola completamento testuale** (come GPT-3 base o LLaMA grezzo senza instruction tuning) di solito non supportano i tool.
- I **modelli solo immagine o visione** focalizzati sulle immagini piuttosto che sul testo potrebbero non avere il supporto dei tool.
- I **modelli estremamente piccoli** sotto il miliardo di parametri difficilmente usano i tool correttamente, anche se l'API dice che li supportano.

## Come verificare il supporto dei tool

Theodia controlla automaticamente il supporto dei tool. Dopo aver configurato un modello in **Impostazioni → Assistente IA**, tocca **Verifica connessione**. Una volta che la connessione riesce, l'app invia una seconda richiesta con una definizione di tool di esempio. Vedi uno di due risultati:

- **✓ Tool supportati** — Il modello accetta le chiamate ai tool e può usare le funzionalità integrate di Theodia.
- **✗ Tool non supportati** — Il modello rifiuta la richiesta di tool. Risponderà solo con testo e non potrà aprire versetti, cercare o gestire segnalibri per te.

Se vedi "Tool non supportati", il modello può comunque funzionare come assistente chat di testo semplice, ma non avrai l'esperienza integrata e a mani libere.

Puoi anche verificare manualmente chiedendo all'IA di fare qualcosa:

- "Mostrami Matteo 5:3 in KJV." — Dovrebbe aprire il versetto nel lettore.
- "Cosa dice il lessico sulla parola 'agape' in Giovanni 3:16?" — Dovrebbe restituire i dati del lessico.
- "Cerca nella Bibbia versetti sul perdono." — Dovrebbe restituire i risultati della ricerca.
- "Salva Marco 12:30 nei segnalibri." — Dovrebbe creare un segnalibro.

Se l'IA ti dà una descrizione di testo invece di fare davvero l'azione, il modello fatica a usare i tool anche se l'app ha segnalato il supporto.

## Cosa succede se il mio modello non supporta i tool?

Puoi usarlo comunque. L'IA risponderà con testo e potrai cercare versetti, fare ricerche e navigare nell'app manualmente. Ma perderai l'esperienza integrata e a mani libere che rende Theodia potente.

## Riepilogo

- Scegli un modello con supporto per **tool calling / function calling** per la migliore esperienza con Theodia.
- I **modelli remoti grandi** gestiscono i tool in modo più affidabile.
- Verifica qualsiasi modello con comandi semplici come "Mostrami Genesi 1:1" per confermare il supporto dei tool.
