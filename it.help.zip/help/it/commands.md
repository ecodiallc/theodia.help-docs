---
title: Comandi rapidi
level: everyday
categories: [layout, study]
summary: Il campo Comando rapido ti permette di saltare a qualsiasi funzione digitando un breve comando. Impara i formati supportati e alcuni esempi.
---

# Comandi rapidi

Il campo **Comando rapido** ti permette di saltare a quasi ogni parte di Theodia digitando una breve istruzione. Puoi usarlo dalla scheda **Casa** o dal **Menu rapido** (l'icona **▼** nell'intestazione).

## Come funziona

1. Tocca il campo Comando.
2. Digita un comando.
3. Tocca il tasto invio sulla tastiera.

L'app legge il comando e ti porta direttamente alla schermata giusta.

## Nessun prefisso slash

I comandi **non** usano il prefisso `/`. Vengono digitati come testo semplice:

```
john 3:16
search love
backup
```

Se digiti `/settings`, lo slash iniziale lo rende irriconoscibile.

## Riferimenti biblici

Digita qualsiasi riferimento biblico per aprirlo nel lettore.

```
psalms 23
john 3:16
matthew 5:1
1 cor 15:10
```

I nomi dei libri possono essere scritti per intero o abbreviati. Nelle lingue dell'interfaccia diverse dall'inglese puoi anche digitare i nomi dei libri nella lingua attiva.

## Ricerca

```
search abraham
search love
search faith not works
```

## Segnalibri, confronta, commento, riferimenti incrociati e informazione parola

```
bookmark john 3:16
compare genesis 1:1
commentary john 1
aicommentary eph 2:8
xref 1 cor 15:10
word info john 1:1
```

Questi comandi aprono lo strumento indicato per il passaggio dato.

## Lessico

Digita un numero di Strong per aprire la voce lessicale.

```
g1161
h7225
```

## Devozionali

```
devotional
devotional smith
devotional daily
```

Senza nome, apre l'elenco dei devozionali.

## Scorciatoie di navigazione

```
notes
highlights
bookmarks
flashcards
playlist
theoscript
resources
read john 3:16
```

Questi saltano direttamente alla schermata indicata o aprono un passaggio nel lettore.

## Cambio traduzione

Digita l'abbreviazione di una traduzione per passare a essa.

```
kjv
web
trlit
ohgb
```

Su una schermata di lettura, la traduzione si cambia sul posto. In qualsiasi altro punto, apre la traduzione al tuo passaggio più recente.

## Verbi dei comandi localizzati

I verbi dei comandi pubblici possono essere digitati nella lingua attiva dell'interfaccia **oppure** in inglese. L'inglese funziona sempre come fallback. I comandi nascosti (scorciatoie delle impostazioni, comandi di installazione, Easter egg) mantengono solo la sintassi inglese.

## Aiuto

Digita `help` o `commands` nel campo Comando per aprire in qualsiasi momento il riferimento comandi integrato.
