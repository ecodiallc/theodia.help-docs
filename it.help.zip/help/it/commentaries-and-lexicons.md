---
title: Commentari e lessici
level: everyday
categories: study
summary: Come consultare i significati delle parole e leggere le note di studio.
---

# Commentari e lessici

> **Modalità:** commentari e lessici richiedono la modalità **Studioso**. Puoi cambiare modalità in **Impostazioni** → **Modalità utente app**.

Theodia include due strumenti di studio: **commentari** e **lessici**. Ti aiutano a capire la Bibbia più a fondo.

## Cos'è un commentario?

Un commentario è un libro di note di studio scritto da uno studioso della Bibbia. Per un dato versetto, un commentario spiega lo sfondo, il significato e come il versetto si inserisce nel resto della Bibbia.

## Cos'è un lessico?

Un lessico è un dizionario di parole bibliche. Ti dice la parola originale in ebraico o greco, cosa significa e come viene usata nella Bibbia.

## Come aprire un commentario

1. Apri un capitolo.
2. Tocca un versetto.
3. Tocca **Commento**.

Si apre un pannello. Mostra le note di uno studioso della Bibbia su quel versetto.

## Come aprire un lessico

1. Apri un capitolo in una Bibbia che include i numeri di Strong.
2. Tocca un numero di Strong nel versetto (per esempio, G1234 o H1234).
3. Si apre un pannello che mostra la parola originale in ebraico o greco, il suo significato e altri versetti che usano la parola.

I numeri di Strong appaiono in un colore diverso nel testo del versetto, così si distinguono dalle parole normali.

## Scegliere un commentario diverso

Il commentario si sceglie da un menu a discesa in cima al pannello del commentario stesso. Apri il pannello, poi tocca il menu a discesa per vedere i commentari installati. Scegline un altro.

## Scegliere un lessico diverso

Il lessico si sceglie da un menu a discesa in cima al pannello del lessico. Apri il pannello, poi tocca il menu a discesa per vedere i lessici installati. Scegline un altro.

## Risorse integrate

Theodia include un set di commentari e lessici integrati. Sono inclusi nell'app e funzionano offline. Commentari e lessici aggiuntivi non possono essere installati o scaricati separatamente.

## Quando usarli

- I **commentari** sono utili quando un versetto è difficile da capire. Le note ti danno contesto.
- I **lessici** sono utili per gli studi di parole. Ti dicono il significato esatto di una parola nella lingua originale.

## Suggerimento

Se un versetto ha una nota che vuoi conservare, fai uno screenshot o copia il testo in una nota. (Vedi la guida [Scrivere note](theodia://help/notes).)

## Dizionario biblico in linguaggio semplice

Per le definizioni in inglese di parole e concetti biblici (alleanza, espiazione, farisei, ecc.), Theodia include anche uno strumento Dizionario biblico. Aprilo dal menu del versetto toccando **Dizionario** (📖). È diverso dal lessico: i lessici spiegano le parole originali in ebraico e greco, mentre il dizionario spiega la parola inglese in linguaggio semplice. Vedi la guida [Dizionario biblico](theodia://help/dictionary) per sapere come usarlo.
