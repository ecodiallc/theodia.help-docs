---
title: Problemi comuni
level: everyday
categories: trouble
summary: Soluzioni rapide per i problemi più frequenti.
---

# Problemi comuni

Questa guida copre i problemi più comuni. Se il tuo problema non è elencato qui, vedi la guida [Dove chiedere aiuto](theodia://help/getting-more-help).

## L'app è lenta

1. Chiudi le altre app in esecuzione in background.
2. Riavvia l'app.
3. Riavvia il dispositivo.

## Non trovo una traduzione biblica

1. Apri **Impostazioni** → **Gestisci risorse** per vedere cosa è installato.
2. Se la traduzione non c'è, tocca **Installa da GitHub**.
3. Nella finestra di download, tocca la scheda **Bibbie** (o **Bibbie globali**) e seleziona la traduzione che vuoi.
4. Tocca **Installa selezionati** e attendi il completamento del download.
5. Per scaricare una nuova traduzione serve internet.

## Note o segnalibri scomparsi

1. Controlla di essere nella scheda giusta. Le note sono nella scheda **Note Bibliche**. I segnalibri sono nella scheda **Segnalibri**.
2. Se hai recentemente ripristinato un backup, il backup potrebbe aver sostituito i tuoi dati. Controlla la data del backup.
3. Se hai disinstallato e reinstallato l'app, i dati sono andati persi. La prossima volta, fai prima un backup.

## La ricerca non trova versetti

1. Assicurati di aver scritto correttamente la parola.
2. Prova con una parola più breve. "Amore" trova più versetti di "amando."
3. Assicurati di avere installata la traduzione biblica giusta. La ricerca funziona solo nelle traduzioni che possiedi.

## La lettura ad alta voce non funziona

1. Assicurati che il volume del dispositivo sia alto.
2. Assicurati che l'app abbia il permesso di usare l'altoparlante.
3. Prova un'altra traduzione. Alcune traduzioni funzionano meglio con la lettura ad alta voce di altre.
4. Per una checklist passo passo, vedi la guida [Leggere ad alta voce](theodia://help/tts).

## L'app si chiude continuamente

1. Riavvia l'app.
2. Riavvia il dispositivo.
3. Se il problema persiste, segnalalo. Vedi la guida [Dove chiedere aiuto](theodia://help/getting-more-help).

## Voglio disinstallare l'app

Puoi disinstallare Theodia come qualsiasi altra app. Prima, però, fai un backup dei tuoi dati. Dopo la disinstallazione, i dati sul dispositivo saranno persi.

## Sei ancora bloccato?

Vedi la guida [Dove chiedere aiuto](theodia://help/getting-more-help). Lì trovi link per segnalare un problema e per chiedere aiuto alla comunità.

Puoi anche cercare tra le guide di aiuto dalla schermata principale **Aiuto e guide**. Digita una parola come `notifiche`, `ricerca` o `segnalibri` per trovare la guida corrispondente.
