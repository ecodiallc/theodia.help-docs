---
title: Confrontare le traduzioni
level: everyday
categories: [read, study]
summary: Come vedere lo stesso versetto in tutte le traduzioni installate.
---

# Confrontare le traduzioni

> **Modalità:** lo strumento Confronta è disponibile nelle modalità **Standard** e **Studioso**. La modalità Messa a fuoco è solo per una lettura pulita e senza distrazioni. Puoi cambiare modalità in **Impostazioni** → **Modalità utente app**.

Lo strumento **Confronta** mostra un singolo versetto in ogni traduzione biblica che hai installato, tutto in un unico pannello. È utile quando vuoi vedere come diversi traduttori affrontano un versetto difficile, oppure quando stai scegliendo una traduzione e vuoi leggere lo stesso versetto in ciascuna.

## Come aprire Confronta

1. Apri un capitolo in qualsiasi traduzione.
2. Tocca un versetto per aprire il menu del versetto.
3. Tocca **Confronta** (⇄).

Si apre un pannello. La barra del titolo mostra il riferimento (per esempio, "Giovanni 3:16 — Confronta"). Il pannello elenca lo stesso versetto in ogni traduzione installata. La tua traduzione attuale è elencata per prima; le altre sono in ordine alfabetico.

## Aspetto del pannello

Il pannello è una **lista verticale**, non una colonna affiancata. Ogni riga è una traduzione:

- Il **nome della traduzione** (per esempio, "KJV") è in cima alla riga. È toccabile.
- Il **testo del versetto** è sotto il nome.

Scorri il pannello per vedere tutte le traduzioni. Ogni traduzione installata sul dispositivo compare qui. Se una traduzione non ha quel libro o versetto, viene omessa.

## Come leggere il versetto in un'altra traduzione

Tocca il nome della traduzione nella riga. Il pannello Confronta si chiude e si apre lo stesso capitolo con il versetto scelto in quella traduzione. È il modo più veloce per passare dal confronto alla lettura di una traduzione specifica.

## Come chiudere Confronta

- **Su telefono:** tocca la X in alto a destra del pannello.
- **Su tablet:** tocca la X nell'intestazione del pannello, oppure tocca fuori dal pannello.

Torni alla vista del capitolo nella tua traduzione originale.

## Quando usare Confronta

- **Scegliere una traduzione.** Apri un versetto che conosci bene nella tua traduzione attuale, poi usa Confronta per vederlo in altre. Le differenze saltano all'occhio.
- **Versetti difficili.** Un versetto confuso in una traduzione spesso è più chiaro in un'altra.
- **Studi di parole.** Guarda come diversi traduttori trattano una parola o una frase chiave.

Per un confronto d'insieme di un intero capitolo in più tradizioni contemporaneamente, usa invece la **vista parallela**. Vedi la guida [Modalità Studio](theodia://help/study-mode) per sapere come attivarla.
