---
title: Creare risorse personalizzate
level: advanced
categories: resources
summary: Come creare Bibbie, commentari, libri, devozionali e lessici personalizzati e importarli in Theodia.
---

# Creare risorse personalizzate

Theodia supporta risorse personalizzate nel formato Unique Bible App. Ogni risorsa è un file SQLite con una struttura di tabelle specifica. Puoi creare questi file su un computer e importarli nell'app.

## Tipi di file e tabelle richieste

### Bibbie (`.bible`)

Un file Bible è un database SQLite con almeno una di queste tabelle:

- **`Verses`** — colonne: `Book` (intero, 1-66), `Chapter` (intero), `Verse` (intero), `Scripture` (testo)
- **`Bible`** — colonne: `Book` (intero), `Chapter` (intero), `Verse` (intero), `Scripture` (testo)

Puoi anche includere una tabella **`Details`** con colonne di metadati come `Description`, `Abbreviation` e `Version`.

Esempio SQL:

```sql
-- Main text table
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- Optional metadata table
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### Commentari (`.commentary`)

I commentari sono di tre tipi: **libro**, **capitolo** e **versetto**. Il tipo è determinato dalla **prima lettera del nome del file**.

#### Commentari per libro — il nome del file inizia per `b`

Un commentario per libro copre un intero libro della Bibbia in un'unica voce. La tabella `Commentary` ha bisogno delle colonne `Book` e `Scripture` (o `Content`). Non servono colonne `Chapter` o `Verse`.

- **`Commentary`** — colonne: `Book` (intero), `Scripture` (testo) o `Content` (testo)

Esempio SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

Esempio di nome file: `bMyCommentary.commentary`

#### Commentari per capitolo — il nome del file inizia per `c`

Un commentario per capitolo copre ogni capitolo di un libro biblico.

- **`Commentary`** — colonne: `Book` (intero), `Chapter` (intero), `Scripture` (testo) o `Content` (testo)

Esempio SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

Esempio di nome file: `cMyCommentary.commentary`

#### Commentari per versetto — il nome del file inizia per `v`

Un commentario per versetto copre i singoli versetti. La tabella `Commentary` ha bisogno delle colonne `Book`, `Chapter`, `Verse` e `Scripture` (o `Content`).

- **`Commentary`** — colonne: `Book` (intero), `Chapter` (intero), `Verse` (intero), `Scripture` (testo) o `Content` (testo)

Esempio SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

Esempio di nome file: `vMyCommentary.commentary`

### Libri (`.book`)

Un file libro è un database SQLite con una tabella `Reference`.

- **`Reference`** — colonne: `id` (intero), `Chapter` (testo), `Content` (testo)

Ogni riga è un capitolo. La colonna `Chapter` è il titolo del capitolo. La colonna `Content` è il corpo del capitolo, che può includere HTML (`<b>`, `<i>`, `<br>`, ecc.).

Esempio SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

Puoi anche creare libri da file Markdown. L'app può importare file `.md` in cui `#` è il titolo del libro e `##` indica i capitoli. Il Markdown viene convertito automaticamente in HTML.

### Devozionali (`.devotional`)

Un file devozionale è un database SQLite con una tabella `devotional`.

- **`devotional`** — colonne: `month` (intero, 1-12), `day` (intero, 1-31), `devotion` (testo)

Ogni riga è la lettura di un giorno. L'app cerca la voce in base al mese e al giorno attuali.

Esempio SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### Lessici (`.lexicon`)

Un file lessico è un database SQLite con una tabella `Lexicon`.

- **`Lexicon`** — colonne: `Topic` (testo, il numero di Strong), `Definition` (testo, la voce lessicale)

La colonna `Topic` contiene il numero di Strong (per esempio, `G1161` o `H7225`). La colonna `Definition` contiene il testo completo della voce, che può includere HTML.

Esempio SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

I lessici alimentano lo strumento Informazione parola. Quando tocchi una parola in una Bibbia interlineare, l'app cerca il numero di Strong nei lessici installati.

## Come creare un file sul computer

1. Installa un editor SQLite (DB Browser for SQLite, SQLiteStudio o lo strumento da riga di comando `sqlite3`).
2. Crea un nuovo file di database.
3. Crea la tabella richiesta e inserisci i tuoi dati.
4. Salva il file con l'estensione corretta (`.bible`, `.commentary`, `.book`, `.devotional` o `.lexicon`).

## Come importare in Theodia

1. Trasferisci il file sul tuo dispositivo (AirDrop, email, cloud storage o USB).
2. Apri **Theodia**.
3. Vai su **Impostazioni** → **Gestisci risorse**.
4. Tocca **Importa da file**.
5. Seleziona il tuo file.

L'app valida il file (controlla che ci sia la tabella richiesta), lo copia nella cartella dei dati dell'app e lo attiva automaticamente. Se il file non è valido, vedi un messaggio di errore che spiega cosa c'è che non va.

## Limitazioni

- Non puoi sovrascrivere le risorse integrate. Se provi a importare un file con lo stesso nome di una Bibbia, un commentario o un libro integrato, l'importazione fallisce.
- I file Bible devono avere una tabella `Verses` o `Bible`. Se nessuna delle due esiste, l'importazione fallisce.
- I file di commentario devono avere una tabella `Commentary`.
  - I commentari per libro hanno bisogno delle colonne `Book` e `Scripture` (o `Content`).
  - I commentari per capitolo hanno bisogno delle colonne `Book`, `Chapter` e `Scripture` (o `Content`).
  - I commentari per versetto hanno bisogno delle colonne `Book`, `Chapter`, `Verse` e `Scripture` (o `Content`).
- I file libro devono avere una tabella `Reference`.
- I file lessico devono avere una tabella `Lexicon`.
- I file devozionali devono avere una tabella `devotional`.

## Suggerimenti

- Mantieni le dimensioni dei file ragionevoli. File SQLite molto grandi possono causare problemi di memoria su dispositivi vecchi.
- Testa il file prima sul computer. Aprilo in un browser SQLite ed esegui `SELECT * FROM` la tabella richiesta per verificare che i dati siano corretti.
- Per le Bibbie, assicurati che la colonna `Book` usi numeri (1 = Genesi, 66 = Apocalisse).
- Per i commentari, puoi usare `Scripture` o `Content` come colonna del testo del commentario.
- Per i libri, l'HTML nella colonna `Content` viene visualizzato durante la lettura. Tienilo semplice: `<b>`, `<i>`, `<br>` e `<hr>` sono sicuri.

## Dove trovare risorse esistenti

Theodia può leggere le risorse del progetto [Unique Bible App](https://github.com/eliranwong/UniqueBible). Lì sono disponibili molte Bibbie, commentari, libri e altre risorse nel formato SQLite corretto. Vedi la guida [Ottenere risorse extra](theodia://help/getting-core-files) per sapere come trovarle e aggiungerle.
