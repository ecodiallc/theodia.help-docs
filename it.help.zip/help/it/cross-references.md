---
title: Riferimenti incrociati
level: everyday
categories: study
summary: Come trovare i versetti collegati a quello che stai leggendo.
---

# Riferimenti incrociati

> **Modalità:** i riferimenti incrociati sono disponibili nelle modalità **Standard** e **Studioso**. La modalità Messa a fuoco è solo per una lettura pulita e senza distrazioni. Puoi cambiare modalità in **Impostazioni** → **Modalità utente app**.

Un "riferimento incrociato" è un altro versetto che parla della stessa cosa del versetto che stai leggendo. Il pannello dei riferimenti incrociati ti mostra quali versetti della Bibbia si collegano tra loro.

## Come aprire i riferimenti incrociati

1. Apri un capitolo.
2. Tocca un versetto per aprire il menu del versetto.
3. Tocca **Riferimenti incrociati**.

Si apre un pannello. Mostra un elenco di altri versetti collegati a quello che hai toccato.

## Come leggere l'elenco

Ogni riga è un versetto collegato. Vedi:

- Il libro, il capitolo e il versetto.
- Un breve anticipo del testo del versetto.
- Un punteggio che indica quanto forte è il collegamento.

## Come saltare a un versetto collegato

Tocca qualsiasi riga. L'app apre quel versetto per te. Quando hai finito, tocca il pulsante indietro per tornare.

## Cosa significa il punteggio

Il punteggio ti dice quanto i versetti sono collegati. Un punteggio alto significa un collegamento forte e diretto. Un punteggio basso significa un collegamento più lento.

## Usa i riferimenti incrociati per studiare

I riferimenti incrociati sono utili per:

- **Studi di parole.** Vedi come la Bibbia usa una parola in posti diversi.
- **Studi tematici.** Segui un tema, come "amore" o "alleanza", attraverso la Scrittura.
- **Preparazione di sermoni.** Trova rapidamente versetti di supporto.

## Suggerimento

I riferimenti incrociati funzionano meglio con una traduzione parola-per-parola come WEB.
