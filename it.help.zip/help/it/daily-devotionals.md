---
title: Devozionali quotidiani
level: everyday
categories: [content, read]
summary: Come leggere una breve meditazione ogni giorno.
---

# Devozionali quotidiani

Un devozionale è una breve lettura per un giorno. Spesso contiene un versetto, una breve riflessione e una domanda su cui meditare. Theodia include una piccola libreria di devozionali.

## Come aprire un devozionale

1. Tocca la scheda **Devozionali** in basso sullo schermo.
2. Vedi un elenco dei devozionali installati sul tuo dispositivo.
3. Tocca uno per aprirlo.

## Come leggere un devozionale

1. Apri il devozionale.
2. Scorri per leggere.
3. Usa i pulsanti in alto per:
   - Toccare la **data** per saltare a un giorno diverso.
   - Toccare la **stella** per salvare il giorno nei segnalibri.
   - Toccare l'**altoparlante** per leggerlo ad alta voce (se il dispositivo lo supporta). Vedi la guida [Leggere ad alta voce](theodia://help/tts) per scegliere una voce.
   - Toccare **Precedente** o **Successivo** per passare al giorno prima o dopo.

## Come salvare un versetto da un devozionale

1. Apri il devozionale.
2. Tocca un versetto.
3. Tocca **Segnalibro** o **Evidenzia**.

Il versetto viene salvato nei tuoi Segnalibri o Evidenziazioni.

## Come scrivere una nota su un devozionale

1. Apri il devozionale.
2. Tocca un versetto.
3. Tocca **Nota**. Scrivi la tua riflessione o preghiera. Tocca **Salva**.

La nota appare nella tua scheda Note Bibliche.

## Suggerimenti

- I devozionali non hanno bisogno di internet. Funzionano offline.
- Se vuoi altri devozionali, vedi la guida [Ottenere risorse extra da GitHub](theodia://help/getting-core-files).
