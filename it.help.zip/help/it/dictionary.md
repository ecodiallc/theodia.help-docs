---
title: Dizionario biblico
level: everyday
categories: study
summary: Consulta parole e concetti biblici nelle risorse dizionario installate. Aprilo dal menu del versetto o da una voce di lessico, poi tocca una parola per vederla in ogni dizionario.
---

# Dizionario biblico

> **Modalità:** il Dizionario biblico richiede la modalità **Studioso**. Puoi cambiare modalità in **Impostazioni** → **Modalità utente app**.

Lo strumento Dizionario biblico cerca una parola o frase in ogni risorsa dizionario che hai installato. È utile quando vuoi una definizione in linguaggio semplice di una parola biblica, una descrizione di una persona o un luogo, oppure un breve articolo su un concetto teologico.

Il Dizionario biblico è diverso dallo strumento **Informazione parola**, che cerca la parola originale ebraica o greca dietro un versetto. Il dizionario legge la parola **inglese** che tocchi e ti mostra cosa dicono i dizionari installati su di essa. Per le note di traduzione parola per parola, vedi la guida [Commentari e lessici](theodia://help/commentaries-and-lexicons).

## Come aprire il Dizionario

Ci sono due modi per aprire il dizionario.

### Dal menu del versetto

1. Apri un capitolo in [Modalità Studio](theodia://help/study-mode).
2. Tocca un versetto per aprire il menu del versetto.
3. Tocca **Dizionario** (📖).

Si apre un pannello intitolato con il riferimento del versetto (per esempio, "Giovanni 3:16"). Il testo del versetto è in cima, con ogni parola toccabile. Sotto il versetto c'è una striscia di chip che mostra ogni dizionario installato. Sotto c'è la definizione, vuota finché non tocchi una parola.

### Da una voce di lessico

Quando leggi una voce di lessico nel pannello Informazione parola, alcune voci contengono link blu ad articoli del dizionario correlati. Tocca uno di questi link. Il lessico si chiude e il dizionario si apre su quell'articolo. È il modo più veloce per passare da una parola greca o ebraica a una spiegazione semplice di cosa significa.

## Come funziona la vista del versetto

Quando apri il dizionario dal menu di un versetto, il versetto compare in cima al pannello come una lista di parole toccabili. Parole comuni in inglese come "the," "and," "of," "to" e "a" non sono toccabili. Tutte le altre lo sono. Ogni parola toccabile è colorata e in grassetto, così si distingue dal resto del versetto.

Tocca una parola nel versetto. Theodia cerca in ogni dizionario installato una corrispondenza esatta con quella parola. La striscia di chip in basso si aggiorna per mostrare quali dizionari hanno una voce: i dizionari che non hanno una voce per quella parola sono attenuati. Il primo dizionario con una voce viene selezionato automaticamente e la sua definizione appare sotto la striscia di chip.

La parola che hai toccato viene evidenziata nel testo del versetto in cima al pannello, così sai sempre cosa stai consultando.

## Cambiare dizionario

Ogni dizionario installato è mostrato come un piccolo chip sotto il versetto. Dopo aver toccato una parola:

- Il chip a **colore pieno** indica che quel dizionario ha una voce per la parola che hai toccato. Toccalo per passare alla definizione di quel dizionario.
- Il chip **attenuato** indica che quel dizionario non ha una voce per quella parola. È mostrato in grigio così puoi vedere a colpo d'occhio quali dizionari coprono la parola, e il chip non è toccabile.

Il dizionario selezionato è evidenziato. Tocca un altro chip a colore pieno per leggere la stessa parola in quel dizionario. La definizione sotto si aggiorna immediatamente.

Se la parola esiste in un solo dizionario installato, solo quel chip è a colore pieno e gli altri sono attenuati.

## Cosa mostra il pannello

Il pannello del dizionario ha tre parti, dall'alto verso il basso:

- **Il versetto** — il versetto da cui hai aperto il dizionario. Le parole sono toccabili, e l'ultima parola toccata è evidenziata.
- **La striscia di chip** — ogni dizionario installato. Colore pieno significa "ha una voce per la parola toccata." Attenuato significa "non ha una voce per quella parola."
- **La definizione** — l'articolo del dizionario selezionato. Testo semplice, formattato con paragrafi e titoli. I link interni ad altre voci del dizionario sono toccabili; toccandone uno si apre quella voce nel dizionario.

## Cosa succede se non viene trovata alcuna voce

Se tocchi una parola che nessuno dei dizionari installati copre, il pannello mostra un breve messaggio "nessuna voce trovata" invece di una definizione. Questo è comune per parole molto generiche come "year" o "come" che non sono parole di teologia biblica, anche se appaiono spesso nella Bibbia. Prova una parola più specifica, oppure usa lo strumento Informazione parola del lessico, che lavora sul testo greco ed ebraico sottostante.

## Cosa succede se nessun dizionario è installato

Il dizionario ha bisogno di almeno un file di risorsa dizionario per essere utile. Theodia ne include uno. Se lo hai rimosso o stai usando un'installazione personalizzata senza dizionari, la vista del versetto compare comunque e le parole sono toccabili, ma la striscia di chip è vuota e ogni ricerca restituisce "nessuna voce trovata."

Dizionari aggiuntivi non possono essere installati separatamente.

## Suggerimenti

- Il dizionario cerca **corrispondenze esatte di parole**. Toccare "love" trova voci intitolate "love" ma non "loved" o "loving." Per cercare una forma correlata, usa lo strumento Informazione parola del lessico sulla parola greca o ebraica.
- La striscia di chip è la stessa su telefono e tablet. Su tablet il dizionario si apre come pannello laterale accanto al capitolo; su telefono si apre come modal a schermo intero. Entrambi hanno lo stesso layout a tre parti.
- Toccare una parola in un versetto diverso apre un nuovo versetto nel pannello. La selezione precedente viene cancellata. Tocca una parola nel nuovo versetto per iniziare una nuova ricerca.
- Alcune voci del dizionario rimandano alla stessa parola in un altro dizionario. Tocca quei link interni per seguire il percorso attraverso tutti i dizionari installati.

## Differenze tra Dizionario e Informazione parola

Entrambi gli strumenti si aprono dal menu del versetto, ma fanno cose diverse:

- **Dizionario** (📖) legge la parola inglese che tocchi e la cerca nei dizionari inglesi installati. È lo strumento giusto per definizioni in linguaggio semplice di parole o concetti di teologia biblica come "covenant," "atonement" o "Pharisee."
- **Informazione parola** (?) legge la parola greca o ebraica originale dietro il versetto e la cerca nei lessici installati. È lo strumento giusto per studi seri sulle parole, per trovare ogni luogo in cui una parola greca viene usata e per leggere le definizioni nelle lingue originali.

In caso di dubbio, inizia con il dizionario. Se vuoi scavare nella lingua originale, passa a Informazione parola. Vedi la guida [Commentari e lessici](theodia://help/commentaries-and-lexicons) per la guida completa su Informazione parola.

## Guide correlate

- La guida [Modalità Studio](theodia://help/study-mode) spiega in dettaglio il menu del versetto e dove si trova lo strumento Dizionario (📖) accanto a Segnalibro, Evidenzia, Leggi, Confronta, Riferimenti incrociati, Commento IA, Informazione parola e Note.
- La guida [Commentari e lessici](theodia://help/commentaries-and-lexicons) copre Informazione parola e i lessici delle lingue originali.
- La guida [Cosa sono le risorse?](theodia://help/what-are-resources) spiega i diversi tipi di file che Theodia usa, inclusi i file dizionario.
- La guida [Problemi comuni](theodia://help/common-problems) contiene soluzioni per risultati vuoti e altri problemi del dizionario.
