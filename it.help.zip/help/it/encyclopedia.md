---
title: Enciclopedia
level: everyday
categories: study
summary: Come cercare voci di enciclopedia e sfogliare le opere di consultazione.
---

# Enciclopedia

Theodia include un'**Enciclopedia** integrata per cercare articoli, persone, luoghi e argomenti biblici. L'app include *Kitto's Illustrated Commentary* (KIT) già pronta all'uso, e puoi scaricare altre enciclopedie dal repository.

## Cos'è un'enciclopedia in Theodia?

Un'enciclopedia è un'opera di consultazione composta da brevi voci. Ogni voce tratta una persona, un luogo, un evento o un argomento biblico. A differenza di un commentario, che spiega un versetto specifico, una voce di enciclopedia spiega l'argomento in sé.

## Come aprire l'Enciclopedia

1. Tocca **Enciclopedie** nella barra degli strumenti in basso.
2. Scegli un'enciclopedia dalla riga di abbreviazioni in alto.
3. Scrivi un argomento, una persona o un luogo nella casella di ricerca.

La ricerca richiede almeno **3 caratteri** prima di mostrare risultati e suggerimenti.

## Leggere una voce

- Sul **telefono**, tocca un risultato per aprire la voce in una nuova schermata.
- Sul **tablet**, la voce si apre nel pannello di destra mentre l'elenco resta a sinistra.

## Scegliere le enciclopedie

Tocca un chip con l'abbreviazione (come **KIT**) per passare a quell'enciclopedia. Per cercare in più enciclopedie contemporaneamente, usa la scheda **Cerca** e seleziona la modalità **Enciclopedia**.

## Ottenere più enciclopedie

1. Apri **Impostazioni**.
2. Tocca **Gestisci risorse**.
3. Tocca **Scarica da GitHub**.
4. Seleziona la scheda **Enciclopedie**.
5. Tocca il pulsante di download accanto all'enciclopedia che vuoi.

Le enciclopedie vengono scaricate dal repository GitHub di Theodia e installate automaticamente. Le enciclopedie installate appaiono nella schermata Enciclopedia e in Cerca.

Puoi anche installare un'enciclopedia da un file locale: in **Gestisci risorse**, tocca **Importa da file** e scegli un file `.encyclopedia`. Il file viene copiato nella cartella delle enciclopedie dell'app e aggiunto all'indice di ricerca condiviso.

## Tieni premuto per il titolo completo

Nella schermata Cerca, i chip delle enciclopedie mostrano abbreviazioni brevi. Tieni premuto un chip per vedere il nome completo dell'enciclopedia.

## Quando usare l'Enciclopedia

- Cercare una persona, un luogo o un argomento prima o durante la lettura di un passaggio.
- Ottenere informazioni di base su una parola o un concetto biblico che si ripete in molti versetti.
- Leggere insieme a un commentario per uno studio più approfondito.
