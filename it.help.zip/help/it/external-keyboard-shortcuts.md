---
title: Scorciatoie da Tastiera Esterna
level: everyday
categories: [tablet, settings]
summary: Elenco completo delle scorciatoie da tastiera per iPad con tastiera esterna collegata.
---

# ⌨️ Scorciatoie da Tastiera Esterna

Se usi Theodia su iPad con una tastiera esterna (Magic Keyboard, tastiera Bluetooth o tastiera USB), puoi navigare nell'app senza toccare lo schermo.

> **Modalità:** alcune scorciatoie funzionano solo quando la funzione corrispondente è disponibile nella tua modalità utente attuale. Ad esempio, `Cmd + Option + 6` (Segnalibri) e `Cmd + Option + 7` (Punti salienti) non fanno nulla in modalità Lettura. Cambia modalità in **Impostazioni** → **Modalità utente app**.

Le scorciatoie funzionano su **iPad**.

## Scorciatoie globali (da qualsiasi schermata)

| Scorciatoia        | Azione                                          |
| ------------------ | ----------------------------------------------- |
| `Cmd + /`          | Mostra questa guida alle scorciatoie da tastiera |
| `Cmd + .`          | Chiudi modale / pannello (alternativa a Esc)    |
| `Cmd + Option + 1` | Vai alla scheda Casa                             |
| `Cmd + Option + 2` | Vai alla scheda Bibbie                           |
| `Cmd + Option + 3` | Vai alla scheda Libri                            |
| `Cmd + Option + 4` | Vai alla scheda Devozionali                      |
| `Cmd + Option + 5` | Vai alla scheda Cerca                            |
| `Cmd + Option + 6` | Vai alla scheda Segnalibri (Standard e Studioso) |
| `Cmd + Option + 7` | Vai alla scheda Punti salienti (Standard e Studioso) |
| `Cmd + Option + 8` | Vai alla scheda Note Bibliche (Standard e Studioso) |
| `Cmd + Option + 9` | Vai alla scheda IA (solo Studioso, se abilitata) |
| `Cmd + Option + 0` | Vai alla scheda Aiuto                            |
| `Cmd + Option + I` | Vai alla scheda Informazioni                     |
| `Cmd + [`          | Torna indietro                                   |
| `Cmd + F`          | Apri Cerca                                       |
| `Cmd + K`          | Apri Menu rapido (Studioso)                      |
| `Cmd + ,`          | Apri Impostazioni                                |
| `Cmd + Shift + M`  | Apri menu principale                            |
| `Cmd + Shift + T`  | Cambia tema (predefinito / scuro)               |
| `Cmd + Shift + U`  | Apri selettore modalità utente                   |
| `Escape`           | Chiudi modale / pannello                         |

## Scorciatoie del lettore biblico

Funzionano sia nella **Bibbia di Studio** che nella **Bibbia Focus**.

| Scorciatoia        | Azione                                                       |
| ------------------ | ------------------------------------------------------------ |
| `← Freccia sinistra` | Capitolo precedente                                          |
| `→ Freccia destra`   | Capitolo successivo                                          |
| `Cmd + R`          | Passa da Studio a Bibbia Focus (Standard e Studioso)      |
| `Cmd + Option + V` | Apri selettore versione                                      |
| `Cmd + Option + B` | Apri selettore libro                                         |
| `Cmd + Option + C` | Apri selettore capitolo                                      |
| `Cmd + T`          | Attiva/disattiva sintesi vocale (ferma se in riproduzione/pausa, avvia se inattiva) |
| `Cmd + Option + T` | Riproduci / Pausa sintesi vocale                           |

## Solo Bibbia di Studio

| Scorciatoia        | Azione                                                                 |
| ------------------ | ---------------------------------------------------------------------- |
| `↑ Freccia su`     | Seleziona versetto precedente                                          |
| `↓ Freccia giù`    | Seleziona versetto successivo                                          |
| `Cmd + ↑`          | Seleziona primo versetto                                               |
| `Cmd + ↓`          | Seleziona ultimo versetto                                              |
| `Cmd + ←`          | Salta al capitolo 1                                                    |
| `Cmd + →`          | Salta all'ultimo capitolo                                              |
| `Cmd + 0`–`9`      | Salto diretto al versetto (digita cifre, es. `Cmd + 1` `Cmd + 6` per il versetto 16) |
| `Cmd + P`          | Attiva/disattiva Bibbie parallele (Standard e Studioso)                 |
| `Cmd + B`          | Aggiungi segnalibro al versetto selezionato (Standard e Studioso)       |
| `Cmd + H`          | Evidenzia versetto selezionato (Standard e Studioso)                    |
| `Cmd + N`          | Aggiungi nota al versetto selezionato (Standard e Studioso)             |
| `Cmd + C`          | Confronta traduzioni del versetto selezionato (Standard e Studioso)     |
| `Cmd + X`          | Apri riferimenti incrociati del versetto selezionato (Standard e Studioso) |
| `Cmd + I`          | Apri informazione parola (Studioso)                                     |
| `Cmd + D`          | Apri dizionario per il versetto selezionato (Studioso)                 |
| `Cmd + A`          | Apri pannello IA per il versetto selezionato (Studioso)                 |
| `Cmd + Option + S` | Attiva/disattiva titoli di sezione                                      |
| `Cmd + Option + W` | Chiudi tutti i pannelli di studio aperti                                |
| `Cmd + Option + M` | Apri menu azioni versetto                                              |

## Solo Bibbia Focus

| Scorciatoia        | Azione              |
| ------------------ | ------------------- |
| `↑ Freccia su`     | Scorri su           |
| `↓ Freccia giù`    | Scorri giù          |
| `Cmd + ↑`          | Vai in cima         |
| `Cmd + ↓`          | Vai in fondo        |
| `Cmd + =`          | Aumenta zoom        |
| `Cmd + -`          | Riduci zoom         |

## Cerca

| Scorciatoia        | Azione                           |
| ------------------ | -------------------------------- |
| `Return`           | Esegui ricerca                   |
| `Cmd + Return`     | Cancella ricerca e focalizza input |
| `Cmd + ↑`          | Scorri risultati su              |
| `Cmd + ↓`          | Scorri risultati giù             |
| `Cmd + Option + A` | Seleziona tutti gli elementi dell'ambito |
| `Cmd + Option + C` | Deseleziona tutti gli elementi dell'ambito |
| `Cmd + Option + B` | Modalità ricerca Bibbia          |
| `Cmd + Option + O` | Modalità ricerca Libro           |
| `Cmd + Option + D` | Modalità ricerca Dizionario (Studioso) |
| `Cmd + Option + X` | Modalità ricerca Lessico (Studioso) |

## Risultati di ricerca

| Scorciatoia  | Azione                       |
| --------- | ----------------------------- |
| `Cmd + S` | Apri foglio salva tutto       |
| `Cmd + ↑` | Scorri risultati su           |
| `Cmd + ↓` | Scorri risultati giù          |

## Lettore di libri

| Scorciatoia        | Azione                   |
| ------------------ | ------------------------ |
| `← Freccia sinistra` | Capitolo precedente     |
| `→ Freccia destra`   | Capitolo successivo     |
| `Cmd + ↑`          | Capitolo precedente      |
| `Cmd + ↓`          | Capitolo successivo      |
| `↑ Freccia su`     | Scorri su                |
| `↓ Freccia giù`    | Scorri giù               |
| `Cmd + B`          | Aggiungi segnalibro al capitolo corrente |
| `Cmd + J`          | Apri selettore capitolo  |
| `Cmd + L`          | Apri selettore voce      |
| `Cmd + T`          | Attiva/disattiva sintesi vocale |
| `Cmd + Option + T` | Riproduci / Pausa sintesi vocale |

## Lettore devozionale

| Scorciatoia        | Azione              |
| ------------------ | ------------------- |
| `← Freccia sinistra` | Giorno precedente |
| `→ Freccia destra`   | Giorno successivo |
| `↑ Freccia su`     | Scorri su           |
| `↓ Freccia giù`    | Scorri giù          |
| `Cmd + ↑`          | Scorri su (grande)  |
| `Cmd + ↓`          | Scorri giù (grande) |
| `Cmd + D`          | Apri selettore data |
| `Cmd + T`          | Attiva/disattiva sintesi vocale |
| `Cmd + Option + T` | Riproduci / Pausa sintesi vocale |

## Chat IA

| Scorciatoia        | Azione                     |
| ------------------ | -------------------------- |
| `Cmd + Return`     | Invia messaggio            |
| `Cmd + N`          | Nuova chat                 |
| `Cmd + D`          | Attiva/disattiva cassetto conversazioni |
| `Cmd + Option + C` | Cancella chat corrente     |
| `Cmd + S`          | Apri menu salva            |
| `Escape`           | Chiudi cassetto / menu       |

## Segnalibri

| Scorciatoia                      | Azione                              |
| ----------------------------- | ----------------------------------- |
| `↑ Freccia su` / `↓ Freccia giù` | Seleziona segnalibro               |
| `Return`                      | Apri segnalibro (tablet: seleziona) |
| `Cmd + R`                     | Leggi segnalibro nel contesto        |
| `Cmd + M`                     | Sposta segnalibro selezionato nelle cartelle |
| `Cmd + N`                     | Gestisci cartelle                    |
| `Escape`                      | Chiudi pannello dettagli / selettore cartella |

Nel selettore **Sposta in cartella**, `↑ Freccia su` / `↓ Freccia giù` muovono la selezione, `Return` attiva o disattiva la cartella selezionata o l'azione evidenziata, e `Escape` chiude il selettore. La riga **+ Crea cartella** è in cima all'elenco.

## Note Bibliche

| Scorciatoia                      | Azione                |
| ----------------------------- | --------------------- |
| `↑ Freccia su` / `↓ Freccia giù` | Seleziona nota       |
| `Return`                      | Apri nota             |
| `Cmd + Return`                | Focalizza input filtro |
| `Escape`                      | Chiudi dettaglio / editor |

## Punti salienti

| Scorciatoia                      | Azione             |
| ----------------------------- | ------------------ |
| `↑ Freccia su` / `↓ Freccia giù` | Seleziona punto saliente |
| `Return`                      | Apri punto saliente |
| `Cmd + Return`                | Focalizza input filtro |
| `Escape`                      | Chiudi pannello dettagli |

## Elenco Bibbie

| Scorciatoia                                 | Azione                            |
| ---------------------------------------- | --------------------------------- |
| `Tab` / `→ Freccia destra` / `↓ Freccia giù` | Bibbia successiva              |
| `← Freccia sinistra` / `↑ Freccia su`    | Bibbia precedente                 |
| `Return`                                 | Apri Bibbia focalizzata           |
| `Cmd + Shift + S`                        | Attiva/disattiva preferito per la Bibbia focalizzata |
| `Escape`                                 | Torna indietro                    |

## Schermata Libri biblici

| Scorciatoia                | Azione                     |
| ----------------------- | -------------------------- |
| `Tab` / `→ Freccia destra` | Libro successivo          |
| `← Freccia sinistra`      | Libro precedente           |
| `↓ Freccia giù`           | Libro sotto nella griglia  |
| `↑ Freccia su`            | Libro sopra nella griglia  |
| `Cmd + ↓`                 | Sezione successiva (AT / NT) |
| `Cmd + ↑`                 | Sezione precedente (AT / NT) |
| `Return`                  | Apri libro focalizzato       |
| `Escape`                  | Torna indietro               |

## Elenco libri

| Scorciatoia                                 | Azione            |
| ---------------------------------------- | ----------------- |
| `Tab` / `→ Freccia destra` / `↓ Freccia giù` | Libro successivo |
| `← Freccia sinistra` / `↑ Freccia su`    | Libro precedente  |
| `Return`                                 | Apri libro focalizzato |
| `Escape`                                 | Torna indietro    |

## Schermata Capitoli biblici

| Scorciatoia                                 | Azione               |
| ---------------------------------------- | -------------------- |
| `Tab` / `→ Freccia destra` / `↓ Freccia giù` | Capitolo successivo |
| `← Freccia sinistra` / `↑ Freccia su`    | Capitolo precedente  |
| `Return`                                 | Apri capitolo focalizzato |
| `Escape`                                 | Torna indietro       |

## Schermata Capitoli dei libri

| Scorciatoia               | Azione                    |
| ---------------------- | ------------------------- |
| `Tab` / `↓ Freccia giù` | Capitolo successivo       |
| `↑ Freccia su`          | Capitolo precedente       |
| `Return`                | Apri capitolo focalizzato |
| `Cmd + Return`          | Focalizza input ricerca/filtro |
| `Escape`                | Torna indietro            |

## Elenco devozionali

| Scorciatoia                                 | Azione                  |
| ---------------------------------------- | ----------------------- |
| `Tab` / `→ Freccia destra` / `↓ Freccia giù` | Devozionale successivo |
| `← Freccia sinistra` / `↑ Freccia su`    | Devozionale precedente |
| `Return`                                 | Apri devozionale focalizzato |
| `Escape`                                 | Torna indietro          |

## Menu principale (quando aperto)

| Scorciatoia        | Azione                  |
| -------------- | ----------------------- |
| `↑ Freccia su`   | Voce menu precedente    |
| `↓ Freccia giù`  | Voce menu successiva    |
| `Return`         | Seleziona voce evidenziata |
| `Escape`         | Chiudi menu             |

## Impostazioni

| Scorciatoia | Azione                    |
| -------- | ------------------------- |
| `Escape` | Chiudi modale / selettore aperto |

## Modali editor

| Scorciatoia  | Azione         |
| --------- | -------------- |
| `Cmd + S` | Salva          |
| `Escape`  | Annulla / chiudi |

## Protezione durante la digitazione

Quando sei focalizzato in un campo di testo (casella di ricerca, editor note, input IA), le scorciatoie che non usano `Cmd` (come le frecce e `Spazio`) sono bloccate per evitare di attivare accidentalmente la navigazione. Le scorciatoie che usano `Cmd` (es. `Cmd + S`, `Cmd + B`) funzionano anche durante la digitazione.
