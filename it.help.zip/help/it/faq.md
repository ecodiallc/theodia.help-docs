---
title: Domande Frequenti
level: everyday
categories: faq
summary: Risposte alle domande più comuni sull'uso di Theodia.
---

# Domande Frequenti

## Theodia costa qualcosa?

Theodia è un acquisto una tantum. Non c'è abbonamento, pubblicità, acquisti in-app o richieste di donazioni. Tutte le risorse aggiuntive disponibili nel catalogo sono gratuite dopo l'acquisto dell'app.

## Ho bisogno di una connessione internet?

No. Una volta installata l'app e i suoi file dati, tutto funziona offline. Puoi leggere, cercare, evidenziare, prendere appunti e usare la maggior parte degli strumenti di studio senza segnale.

L'unica funzione che richiede internet è il download di nuove risorse.

## Dove sono memorizzati i miei dati?

Tutti i tuoi segnalibri, evidenziazioni, note e impostazioni sono salvati sul tuo dispositivo. Non vengono caricati su nessun server.

Puoi farne un backup manualmente. Vedi la guida [Backup dei tuoi dati](theodia://help/backups) per sapere come fare.

## Posso ascoltare la Bibbia ad alta voce?

Sì. Apri un capitolo qualsiasi, tocca il menu e scegli l'opzione di lettura ad alta voce. Sul tuo dispositivo deve essere installata una voce di sintesi vocale. Vedi la guida [Lettura ad Alta Voce](theodia://help/tts) per maggiori informazioni.

## Come cerco un versetto?

Puoi scrivere un riferimento come `Giovanni 3:16` nel Comando rapido nella schermata principale, oppure usare la scheda **Cerca** per cercare per parola o frase.

## Come segnalo un bug o suggerisco una funzione?

Tocca **Segnala un problema** nella schermata Informazioni, [segnalalo su GitHub](https://github.com/ecodiallc/theodia.app/issues/new), o visita la pagina [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions).

## Quali dispositivi sono supportati?

Theodia funziona su iPhone, iPad e telefoni e tablet Android. Funziona meglio su dispositivi con almeno 2 GB di spazio libero per i file dati principali.

## Posso usare una tastiera esterna?

Sì. Theodia supporta tastiere Bluetooth e USB su iPad. Navigazione, ricerca e molte funzioni di lettura hanno scorciatoie da tastiera. Vedi la guida [Scorciatoie da Tastiera Esterna](theodia://help/external-keyboard-shortcuts) per l'elenco completo.

## Quali lingue sono supportate?

L'interfaccia dell'app è disponibile in inglese, arabo, cinese (semplificato e tradizionale), ceco, danese, olandese, filippino, francese, tedesco, greco, ebraico, hindi, indonesiano, italiano, giapponese, coreano, polacco, portoghese (Brasile), rumeno, russo, spagnolo, svedese, thai, turco, ucraino e vietnamita.

La lingua del testo biblico dipende dalle traduzioni che hai installato.

## Come cambio la lingua?

Vai in **Impostazioni** e cerca l'opzione lingua.

## La mia domanda non è qui. Dove posso trovare altro aiuto?

Sfoglia il resto delle guide di aiuto per argomento, o fai una domanda nella [community di GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions).

Suggerimento: nella schermata principale **Aiuto e guide**, usa la casella di ricerca per scrivere un argomento come `notifiche` o `ricerca` e trovare la guida corrispondente.
