---
title: La tua Prima Lettura
level: beginner
categories: [start, read]
summary: Una guida passo passo per aprire e leggere un capitolo.
---

# La tua Prima Lettura

Questa guida ti accompagna nell'apertura di un capitolo per la prima volta.

## Passo 1: apri la scheda Bibbie

Guarda in fondo allo schermo. Vedi una riga di schede. Tocca quella che dice **Bibbie**.

## Passo 2: scegli un libro

Vedi un elenco di libri biblici. La Genesi è il primo. Giovanni è verso la metà. L'Apocalisse è l'ultimo.

Tocca il nome del libro che vuoi.

## Passo 3: scegli un capitolo

Vedi i numeri da 1 fino al numero di capitoli del libro. Tocca il capitolo che vuoi.

Il capitolo si apre. I versetti sono sullo schermo.

## Passo 4: muoviti

- Scorri a **sinistra** per andare al capitolo successivo.
- Scorri a **destra** per tornare indietro.

## Passo 5: interagisci con un versetto

Cosa puoi fare con un versetto dipende dalla tua modalità utente.

### Modalità Lettura

La modalità Lettura è pulita e senza distrazioni.

- Tocca un versetto per evidenziarlo brevemente.
- Non ci sono strumenti di studio, segnalibri o menu.
- Se vuoi più funzioni, passa a **Standard** o **Studioso** in **Impostazioni**.

### Modalità Standard

La modalità Standard aggiunge funzioni quotidiane per lo studio personale della Bibbia.

Tocca un versetto per aprire un menu con queste opzioni:

- **Segnalibro** per il versetto.
- **Evidenzia** con un colore.
- **Aggiungi nota** al versetto.
- **Copia** il testo del versetto.
- **Confronta** il versetto in un'altra traduzione.
- **Cerca riferimenti incrociati** per il versetto.

### Modalità Studioso

La modalità Studioso sblocca ogni strumento per lo studio approfondito della Bibbia.

Tocca un versetto per aprire un menu con tutto quello della modalità Standard, più:

- **Commentario** sul versetto.
- **Informazione parola** e ricerche nelle lingue originali.
- **Dizionario** definizioni.
- **Assistente IA** per uno studio più approfondito.

Puoi cambiare modalità in qualsiasi momento in **Impostazioni**.

## Hai bisogno di aiuto con uno strumento specifico?

Ogni strumento ha la sua guida. Tocca **Aiuto** nella schermata principale per vederle tutte. La guida [Modalità Studio](theodia://help/study-mode) è un buon punto di partenza: spiega ogni strumento nel menu del versetto.

Se stai ancora imparando dove si trovano le cose, vedi la guida [Layout e Navigazione dell'App](theodia://help/navigating-the-app). Spiega la schermata principale, il menu principale e la barra degli strumenti in basso.

## Vuoi più risorse?

L'app include già diverse versioni bibliche disponibili gratuitamente. Se vuoi aggiungerne altre, o aggiungere commentari, libri o devozionali, vedi la guida [Ottenere Risorse Extra da GitHub](theodia://help/getting-core-files). Ti mostra dove trovarle e come aggiungerle.
