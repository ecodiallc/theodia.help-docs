---
title: Messa a fuoco
level: beginner
categories: [layout, read]
summary: Un modo pulito e senza distrazioni per leggere lunghi passaggi.
---

# Messa a fuoco

> **Modalità:** la modalità Messa a fuoco è il lettore in modalità **Lettura**. È disponibile anche nelle modalità **Standard** e **Studioso** come alternativa alla modalità Studio. Puoi cambiare modalità in **Impostazioni** → **Modalità utente app**.

La modalità Messa a fuoco ti permette di leggere un capitolo biblico senza pulsanti o menu che intralciano. È ideale per lunghe sessioni di lettura.

## Come attivarla

1. Apri un capitolo qualsiasi.
2. Nella riga di icone in alto, tocca il pulsante 📖. Si apre lo stesso capitolo in modalità Messa a fuoco.
3. Menu e pulsanti si nascondono. Resta solo il testo biblico.

In modalità **Lettura**, i capitoli si aprono automaticamente in modalità Messa a fuoco. Il pulsante 📖 è nascosto perché non c'è una modalità Studio a cui passare.

## Cosa puoi fare in modalità Messa a fuoco

- **Scorri** per leggere.
- **Scorri** a sinistra o a destra per passare al capitolo successivo o precedente.
- **Tocca il pulsante 📖** nella barra in basso per tornare alla modalità Studio. (Nascosto in modalità Lettura.)
- **Tocca il pulsante 🔊** nella barra in basso per ascoltare il capitolo ad alta voce. Appare una mini barra di controllo con riproduci, pausa, riavvolgi, avanti veloce e selettore voce. (Nascosto in modalità Lettura: la sintesi vocale richiede Standard o Studioso.)

## Quando usare la modalità Messa a fuoco

- Leggere un intero libro, un capitolo alla volta.
- Leggere un lungo passaggio per un momento devozionale o di silenzio.
- Leggere ad alta voce seguendo il testo senza distrazioni.

## Passare alla modalità Studio

La modalità Messa a fuoco nasconde ogni strumento di studio, ma sono a un tocco di distanza. Tocca il pulsante 📖 in alto per aprire lo stesso capitolo in [modalità Studio](theodia://help/study-mode). La modalità Studio è il lettore completo, con commentari, riferimenti incrociati, ricerche lessicali e note. Per sapere cosa può fare la modalità Studio, vedi la guida [Modalità Studio](theodia://help/study-mode).

In modalità **Lettura**, il pulsante 📖 è nascosto perché la modalità Studio non è disponibile.
