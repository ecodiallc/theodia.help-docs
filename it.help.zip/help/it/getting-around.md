---
title: Spostarsi Velocemente
level: beginner
categories: layout
summary: Ogni modo rapido per saltare a un versetto, un capitolo o una schermata in Theodia.
---

# Spostarsi Velocemente

Questa guida è un prontuario per la navigazione. Copre ogni modo veloce per spostarti da dove sei a dove vuoi andare.

## Salta direttamente a un versetto

Il modo più veloce per aprire un versetto è il **Comando rapido** nella schermata principale.

- Scrivi `Giovanni 3:16` e tocca Vai.
- Scrivi `Salmi 23` e tocca Vai.
- Scrivi `Genesi 1` e tocca Vai.

L'app apre il capitolo esatto (e scorre al versetto, se ne hai indicato uno).

## Scorri tra i capitoli

Quando stai leggendo un capitolo:

- **Scorri a sinistra** → capitolo successivo.
- **Scorri a destra** → capitolo precedente.

Funziona anche tra i libri. Dopo Esodo 40, scorrere a sinistra porta a Levitico 1.

## Usa la barra in alto

Mentre leggi, in alto vedi la **versione**, il **libro** e il **capitolo** attuali.

- Tocca il nome della versione per cambiare Bibbia.
- Tocca il nome del libro per scegliere un altro libro.
- Tocca il numero del capitolo per scegliere un altro capitolo.

## Salta da un segnalibro

Se hai salvato un versetto:

1. Apri la scheda **Segnalibri**.
2. Tocca una voce qualsiasi.
3. Vai direttamente a quel versetto.

## Salta dalla ricerca

1. Apri la scheda **Cerca**.
2. Scrivi una parola o una frase.
3. Tocca un risultato qualsiasi.
4. L'app apre il capitolo con le parole cercate evidenziate in giallo.

## Cambia layout di lettura

Il lettore biblico ha due layout:

- **Modalità Studio** — mostra il capitolo con tutti gli strumenti di studio a un tocco.
- **Modalità Messa a fuoco** — nasconde ogni strumento e menu, lasciando solo il testo.

Per cambiare: tocca il pulsante **📖** in alto mentre leggi. Toccalo di nuovo per tornare indietro. (La modalità Lettura resta sempre in Messa a fuoco.)

## Usa le schede in basso

La riga di icone in fondo allo schermo è sempre visibile. Tocca una scheda qualsiasi per passare a quella sezione. Le schede esatte dipendono dalla tua modalità utente:

**Tutte le modalità:**

- **Casa** — torna alla schermata principale.
- **Bibbie** — elenco delle traduzioni.
- **Cerca** — ricerca nella Bibbia.
- **Impostazioni** — preferenze e risorse.

**Standard e Studioso vedono anche:**

- **Segnalibri** — versetti salvati.
- **Punti salienti** — versetti marcati a colori.
- **Note Bibliche** — note private.

**Studioso vede anche:**

- **IA** — l'assistente IA (se attivato nelle Impostazioni).

### Ricordare dove eri rimasto

Ogni scheda conserva la propria cronologia di navigazione. Quando torni a una scheda, torni al punto **dove eri rimasto**, non alla schermata iniziale di quella sezione.

- Apri la scheda **Bibbie**, scegli una traduzione, apri un capitolo, poi passa a **Cerca**. Più tardi tocchi di nuovo **Bibbie** e torni esattamente a quel capitolo.
- Apri la scheda **Segnalibri**, tocca un versetto salvato, poi passa a **Impostazioni**. Toccando di nuovo **Segnalibri** torni all'elenco dei segnalibri.

Questo vale per ogni scheda. Ognuna ricorda il tuo posto finché non navighi esplicitamente verso un'altra schermata dentro quella scheda.

### Cosa resetta una scheda

Una scheda torna alla sua schermata principale solo quando:

- Sei già su quella scheda e tocchi di nuovo la stessa icona. È un modo rapido per resettarla.
- L'app viene chiusa forzatamente e riaperta.

### Schede in basso vs menu principale

- **Schede in basso** — ogni scheda ricorda la propria pila. Toccare una scheda ti riporta dove eri rimasto.
- **Menu principale** — toccare una voce naviga a quella schermata. È un elenco a discesa, non un overlay.

Esempio:

- Stai leggendo Giovanni 3. Tocca la scheda **Segnalibri**, poi di nuovo **Bibbie**. Torni a Giovanni 3.
- Stai leggendo Giovanni 3. Apri il menu e tocca **Note**. Esamini le note, poi tocchi la scheda **Bibbie** per tornare a Giovanni 3.

## Suggerimenti

- La schermata principale ricorda quali sezioni sono espanse o compresse.
- Se una scheda manca, controlla la tua **modalità utente** in **Impostazioni** → **Modalità utente app**. La modalità Lettura nasconde segnalibri, punti salienti, note e IA. La modalità Standard nasconde l'IA. Potresti anche dover abilitare una funzione in **Impostazioni** o installare una risorsa.
