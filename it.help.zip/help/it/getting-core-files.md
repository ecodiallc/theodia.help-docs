---
title: Ottenere Risorse Extra
level: everyday
categories: resources
summary: Come aggiungere Bibbie, commentari, libri e altre risorse a Theodia.
---

# Ottenere Risorse Extra

Theodia include già alcune risorse integrate, ma puoi aggiungerne altre. Il modo più semplice è attraverso la schermata **Gestisci risorse** dentro l'app.

## Cosa puoi aggiungere

- **Bibbie** — più traduzioni in diverse lingue
- **Commentari** — note di studio che spiegano i versetti
- **Libri** — classici cristiani e opere di consultazione
- **Devozionali** — letture devozionali giornaliere
- **File principali** — file dati più grandi come morfologia, riferimenti incrociati e la Marvel Interlinear Bible (MIB)

## Come aggiungere risorse dall'interno dell'app

1. Apri **Impostazioni**.
2. Tocca **Gestisci risorse**.
3. Scegli una scheda: **Core**, **Bibbie**, **Commentari**, **Libri** o **Devozionali**.
4. Sfoglia l'elenco. Tocca una risorsa per saperne di più.
5. Tocca la casella di spunta per selezionare ciò che vuoi.
6. Tocca **Scarica** in basso. I file vengono scaricati e installati automaticamente.

Una volta installata, la risorsa appare nell'app subito. Non è necessario riavviare.

## File principali

La scheda **Core** contiene file dati grandi che alimentano gli strumenti di studio più approfonditi. Tra questi:

- Dati di morfologia (forme delle parole nelle lingue originali)
- Database di riferimenti incrociati
- La Marvel Interlinear Bible (MIB)

I file principali servono solo una volta. Restano sul dispositivo e funzionano offline.

## Bibbie globali

La scheda **Bibbie globali** contiene traduzioni bibliche da una raccolta più ampia. Se non trovi una traduzione nella scheda principale **Bibbie**, controlla qui.

## Gestire le risorse installate

Nella schermata principale di **Gestisci risorse** (non nella scheda di download), puoi:

- **Abilitare o disabilitare** una risorsa senza eliminarla. Le risorse disabilitate restano sul dispositivo ma sono nascoste dai menu.
- **Eliminare** una risorsa per liberare spazio. Puoi scaricarla di nuovo più tardi.

## Aggiungere i tuoi file

Se hai un file di risorsa proveniente da altri canali — un amico, un altro progetto o un sito web — puoi importarlo direttamente:

1. In **Gestisci risorse**, tocca **Importa da file**.
2. Scegli il file dal tuo dispositivo.
3. L'app legge il file e lo aggiunge alla tua libreria.

L'app accetta questi tipi di file:

- `.bible` — traduzioni bibliche
- `.commentary` — commentari
- `.lexicon` — lessici
- `.book` — libri
- `.devotional` — devozionali

## Collegare un repository GitHub personalizzato

Se qualcuno mantiene un repository GitHub con risorse compatibili con Theodia, puoi aggiungerlo come fonte personalizzata:

1. Vai in **Impostazioni → Repository GitHub**.
2. Tocca **Aggiungi repository**.
3. Inserisci l'URL GitHub (ad esempio, `https://github.com/username/repo-name`).
4. Scegli quali tipi di risorsa contiene il repository (Bibbie, commentari o libri).
5. Salva.
6. Torna a **Gestisci risorse**. Appare una nuova scheda con le risorse di quel repository.

Se il repository è privato, dovrai aggiungere un **Personal Access Token** in **Impostazioni → Repository GitHub** per permettere all'app di leggerlo.

## Nota sulle dimensioni dei file

I file di risorsa possono essere grandi. Le Bibbie sono di solito piccole (qualche megabyte). Commentari e file principali possono essere molto più grandi (centinaia di megabyte). Quando possibile, scarica via Wi-Fi.

## Riepilogo

- Usa **Impostazioni → Gestisci risorse** per sfogliare e installare risorse.
- I file principali sbloccano strumenti di studio più profondi come morfologia e riferimenti incrociati.
- Importa file locali se ne hai di tuoi.
- Aggiungi repository GitHub personalizzati se vuoi risorse da un'altra fonte.
