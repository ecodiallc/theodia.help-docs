---
title: Dove Fare Domande
level: everyday
categories: trouble
summary: Come ottenere aiuto dal team e dalla community di Theodia, e come trovare gli argomenti di aiuto dentro l'app.
---

# Dove Fare Domande

Se sei bloccato, ci sono diversi posti dove chiedere aiuto.

## Trovare un argomento di aiuto

Se cerchi informazioni su una funzione specifica, prova uno di questi percorsi:

- **Sfoglia per categoria.** Apri **Aiuto e guide** e tocca una categoria come **Impostazioni e personalizzazione** o **Risoluzione problemi**. Ogni scheda elenca le guide correlate.
- **Cerca per parola chiave.** Nella schermata principale di **Aiuto e guide**, scrivi una parola nella casella di ricerca in alto. Ad esempio, scrivendo `notifiche` appare la guida [Notifiche e promemoria](theodia://help/notifications); scrivendo `ricerca` appare la guida [Cercare nella Bibbia](theodia://help/search-the-bible).
- **Controlla prima le Impostazioni.** Molte funzioni si configurano in **Impostazioni**. Se vuoi impostare promemoria, apri **Impostazioni** → **Notifiche**. La schermata delle impostazioni ha anche un collegamento **Aiuto** per ogni sezione.

## Dentro l'app

Apri la schermata **Informazioni**. Vedi due pulsanti:

- **Segnala un problema** — apre un modulo per inviare al team una domanda, un'idea o una segnalazione di bug.
- **Discussioni / Feedback** — apre la bacheca della community.

## La pagina GitHub

Puoi vedere l'elenco dei problemi noti e le modifiche recenti su [GitHub](https://github.com/ecodiallc/theodia.app).

## Discussioni della community

Altre persone che usano Theodia fanno domande e condividono suggerimenti nella [bacheca delle discussioni della community](https://github.com/ecodiallc/theodia.app/discussions). Puoi leggere le conversazioni passate e iniziarne una nuova.

## Prima di chiedere

Alcune informazioni ci aiutano a risponderti più velocemente:

- **Qual è il tuo dispositivo?** (es. iPhone 13, Pixel 7)
- **Quale versione dell'app?** (Apri **Informazioni** per vederla.)
- **Cosa hai fatto?** Una breve descrizione dei passaggi.
- **Cosa è successo?** Cosa hai visto sullo schermo.
- **Cosa ti aspettavi che succedesse?** Questa è spesso la parte più utile.

## Cosa aspettarti

- Per le segnalazioni di bug, il team di solito risponde entro qualche giorno.
- Per le idee, il team le legge tutte. Non possiamo promettere quando un'idea verrà aggiunta.
- Per le domande alla community, altri utenti spesso rispondono più velocemente del team.

## Nota sulla privacy

Quando invii una domanda, non includere informazioni private. Il team può vedere ciò che invii.
