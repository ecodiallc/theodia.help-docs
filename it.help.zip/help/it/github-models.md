---
title: GitHub Models
categories: ai
level: advanced
summary: Configura GitHub Models, un modo gratuito per iniziare a esplorare l'IA in Theodia senza un abbonamento API esistente.
---

# GitHub Models

> **Modalità:** l'assistente IA richiede la modalità **Studioso**. Puoi cambiare modalità in **Impostazioni** → **Modalità utente app**.

Se non hai già un servizio IA a pagamento, **GitHub Models** è il modo più semplice per iniziare a esplorare l'IA di Theodia. È gratuito per iniziare, e ti serve solo un account GitHub gratuito.

## Cos'è GitHub Models?

GitHub Models è un servizio di GitHub che ti permette di eseguire modelli IA moderni tramite API. Supporta lo stesso formato di OpenAI, quindi funziona perfettamente con Theodia.

## Perché scegliere GitHub Models?

- **Nessuna carta di credito richiesta** — Basta un account GitHub.
- **Modelli di alta qualità** — Hai accesso a GPT-4o, GPT-4.1 e altri modelli affidabili che supportano gli strumenti di Theodia.
- **Configurazione semplice** — Un token, un URL e hai finito.

## Passo 1: crea un account GitHub

Se hai già un account GitHub, passa al Passo 2.

1. Vai su [github.com](https://github.com).
2. Tocca **Sign up** e segui le istruzioni per creare un account gratuito.
3. Verifica il tuo indirizzo email quando GitHub invia la conferma.

## Passo 2: crea un Personal Access Token

Questo token è la tua chiave API. Dice a GitHub chi sei quando Theodia invia le domande.

1. Vai su [github.com/settings/tokens](https://github.com/settings/tokens).
2. Tocca **Generate new token** e scegli **Generate new token (classic)**.
3. Dai al token un nome come **Theodia AI**.
4. Sotto **Select scopes**, spunta la casella **`models:read`**.
   - È l'unico permesso di cui Theodia ha bisogno.
5. Scorri fino in fondo e tocca **Generate token**.
6. **Copia il token immediatamente.** GitHub lo mostra solo una volta. Incollalo in un posto sicuro (come le note del telefono) finché non lo aggiungi a Theodia.

## Passo 3: scegli un modello

GitHub Models offre diversi modelli. Per Theodia, queste sono le migliori opzioni:

| Modello               | Limite giornaliero gratuito | Ideale per                                      |
| --------------------- | --------------------------- | ----------------------------------------------- |
| `openai/gpt-4.1-nano` | 150 richieste / giorno     | Domande veloci e spiegazioni semplici dei versetti |
| `openai/gpt-4.1-mini` | 150 richieste / giorno     | Studio generale con buon supporto degli strumenti |
| `openai/gpt-4.1`      | 50 richieste / giorno      | Studio approfondito e domande complesse          |
| `openai/gpt-4o`       | 50 richieste / giorno      | Versatile, supporto strumenti eccellente       |

Inizia con **`openai/gpt-4.1-mini`** — è veloce, affidabile e offre un limite giornaliero più alto.

## Passo 4: configura Theodia

1. Apri **Theodia**.
2. Vai in **Impostazioni** → **Assistente IA**.
3. Assicurati che sia selezionato **Modello remoto**.
4. Tocca il menu a discesa **Fornitore** e scegli **GitHub Models**.
   - Se GitHub Models non è nell'elenco, tocca **Personalizzato** e inserisci manualmente l'URL di base: `https://models.github.ai`
5. Incolla il tuo GitHub Personal Access Token nel campo **Chiave API**.
6. Inserisci l'ID del modello scelto nel campo **Modello** (ad esempio: `openai/gpt-4.1-mini`).
7. Tocca **Test connessione**.
8. Attendi che il controllo finisca. Dovresti vedere:
   - **✓ Connessione riuscita**
   - **✓ Strumenti supportati**

Se vedi **✗ Strumenti non supportati**, prova un altro ID modello dalla tabella sopra.

## Passo 5: inizia a chattare

1. Tocca la scheda **IA** in fondo allo schermo.
2. Scrivi una domanda e tocca **Invia**.
3. Oppure, mentre leggi un capitolo biblico, tocca il numero di un versetto e scegli **Commento IA** per avviare una chat specifica per quel versetto.

## Risoluzione problemi

### "Connessione fallita" o "HTTP 401"

- Assicurati di aver copiato l'**intero** token. È una stringa lunga che inizia con `ghp_`.
- I token scadono se non usati a lungo. Torna su GitHub e generane uno nuovo.
- Controlla di aver selezionato **models:read** quando hai creato il token.

### "Strumenti non supportati"

- Alcuni modelli su GitHub Models non accettano chiamate agli strumenti. Prova invece **`openai/gpt-4o`** o **`openai/gpt-4.1-mini`**.
- Assicurati che l'ID modello sia scritto esattamente come mostrato, incluso il prefisso `openai/`.

### Errori di limite di richieste

- Se raggiungi il limite giornaliero, passa a un modello con limite più alto (come `openai/gpt-4.1-nano` a 150 richieste al giorno).
- I limiti si azzerano ogni 24 ore.

## Riepilogo

- GitHub Models è il **modo consigliato per iniziare a esplorare l'IA** in Theodia.
- Ti serve un **account GitHub gratuito** e un **Personal Access Token** con `models:read`.
- Il modello migliore per iniziare è **`openai/gpt-4.1-mini`**.
- Inserisci il token e il modello in **Impostazioni → Assistente IA**, tocca **Test connessione** e inizia a chattare.
