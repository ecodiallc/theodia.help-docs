---
title: Evidenziazione dei Versetti
level: everyday
categories: [annotate, read]
summary: Come marcare i versetti a colori e ritrovarli in seguito.
---

# Evidenziazione dei Versetti

> **Modalità:** le evidenziazioni sono disponibili nelle modalità **Standard** e **Studioso**. La modalità Messa a fuoco è solo per lettura pulita e senza distrazioni. Puoi cambiare modalità in **Impostazioni** → **Modalità utente app**.

L'evidenziazione marca un versetto con un colore. Funziona come un evidenziatore giallo su carta. Il versetto resta evidenziato la prossima volta che lo apri.

## Come evidenziare un versetto

1. Apri il versetto.
2. Tocca il versetto per aprire il menu.
3. Tocca l'icona **Evidenzia**.
4. Scegli un colore.

Il versetto è ora evidenziato con quel colore.

## Come cambiare colore di evidenziazione

1. Apri il versetto.
2. Tocca il versetto, poi tocca l'icona **Evidenzia**.
3. Scegli un nuovo colore.

## Come rimuovere un'evidenziazione

1. Apri il versetto.
2. Tocca il versetto, poi tocca **Evidenzia** nel menu.
3. Tocca **Rimuovi evidenziazione** in fondo al selettore colori.

## Un modo comune di usare i colori

Molti lettori usano un piccolo set di colori per scopi specifici:

- **Giallo** per i preferiti in generale.
- **Verde** per i versetti su Dio.
- **Blu** per i versetti sulla preghiera.
- **Rosa** per i versetti di conforto.
- **Arancione** per i versetti di ammonimento o correzione.
- **Viola** per i versetti sulla profezia o la fine dei tempi.

Scegli un sistema che funzioni per te.

## Come vedere tutte le tue evidenziazioni

Tocca la scheda **Punti salienti** in basso. Vedi l'elenco di ogni versetto che hai evidenziato, dal più recente. In alto c'è una riga di chip colorati: tocca un colore per mostrare solo le evidenziazioni di quel colore, oppure tocca **Tutto** per cancellare il filtro.

## Importare evidenziazioni

Puoi portare evidenziazioni da altre app e file in Theodia.

Vai in **Impostazioni** → **Segnalibri** → **Importa punti salienti**. Scegli **Importa da file** o incolla dagli appunti. L'app rileva automaticamente il formato.

### Formati supportati

**Esportazione JSON nativa** — Il formato usato dalla funzione di esportazione di Theodia:

```json
{
  "/bible/KJV/John/3#v3_16": "yellow",
  "/bible/KJV/Genesis/1#v1_1": "green"
}
```

**CSV** — Un foglio di calcolo con colonne `url` e `color`. Esempio:

```csv
url,color
/bible/KJV/John/3#v3_16,yellow
/bible/KJV/Genesis/1#v1_1,green
```

**Testo semplice** — Ogni riga è un riferimento biblico o un URL, opzionalmente seguito da un nome colore. Esempio:

```
John 3:16 yellow
Genesis 1:1 green
Matthew 5:1
```

- Colori disponibili: `yellow`, `green`, `blue`, `pink`, `orange`, `purple`.
- Se non indichi un colore, l'evidenziazione predefinita è gialla.
- Le righe che iniziano con `#` o `//` sono considerate commenti e ignorate.

## Suggerimenti

- Le evidenziazioni restano sul tuo dispositivo. Non si sincronizzano nel cloud.
- Puoi evidenziare un versetto in una traduzione e vederlo nelle tue altre traduzioni dello stesso versetto.
- Vedi la guida [Backup dei tuoi dati](theodia://help/backups) per tenerle al sicuro.
