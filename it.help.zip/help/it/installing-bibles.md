---
title: Installare Traduzioni Bibliche
level: beginner
categories: start
summary: Come aggiungere una traduzione biblica alla tua libreria.
---

# Installare Traduzioni Bibliche

Theodia include già alcune traduzioni bibliche pronte da leggere. Puoi aggiungerne altre in qualsiasi momento. Una "traduzione" è una versione diversa del testo biblico, come la King James Version.

## Come aggiungere una traduzione

La scheda Bibbie mostra l'elenco delle traduzioni già installate. Per aggiungerne altre, apri il gestore risorse:

1. Apri **Impostazioni**.
2. Tocca **Gestisci risorse**.
3. Tocca **Installa da GitHub**.
4. Nella modale di download, tocca la scheda **Bibbie**.
5. Tocca la casella di spunta accanto a ogni traduzione che vuoi.
6. Tocca **Installa selezionati** in basso.
7. Attendi che il download finisca.

La traduzione è ora nella tua libreria. Per vederla, apri la scheda **Bibbie**.

## Come passare da una traduzione all'altra

1. Apri il capitolo che vuoi leggere.
2. Tocca il nome della traduzione in alto allo schermo.
3. Scegli quella che preferisci dall'elenco.

L'app memorizza la tua scelta per la prossima volta.

## Come rimuovere una traduzione

1. Apri **Impostazioni**.
2. Tocca **Gestisci risorse**.
3. Trova la traduzione che vuoi rimuovere.
4. Tocca la **X** accanto ad essa.
5. Conferma di volerla rimuovere.

Rimuovere una traduzione non cancella le tue note, evidenziazioni o segnalibri. Quelli restano al sicuro.

## Quanto spazio occupano le traduzioni?

La maggior parte delle traduzioni occupa tra 2 e 10 MB. Sono memorizzate sul tuo dispositivo, non nel cloud. Puoi tenerne quante vuoi, finché il dispositivo ha spazio.

## Cosa fare se una traduzione non è nell'app?

Alcune traduzioni non sono nell'elenco integrato. Puoi comunque aggiungerle.

1. Apri l'app e vai in **Impostazioni** → **Gestisci risorse**.
2. Tocca **Installa da GitHub**.
3. Nella modale di download, guarda la scheda **Bibbie** e la scheda **Bibbie globali**. Se trovi la tua traduzione, selezionala e tocca **Installa selezionati**.
4. Se non la trovi, tocca **Importa da file** per importare un file `.bible`. Ottieni il file dalla pagina GitHub del progetto. Vedi la guida [Ottenere Risorse Extra da GitHub](theodia://help/getting-core-files) per istruzioni passo passo.
