---
title: Aggiungere i File Principali
level: beginner
categories: start
summary: Come scaricare i file dati grandi che l'app necessita per studiare la Bibbia in profondità.
---

# Aggiungere i File Principali

Theodia include già una Bibbia e alcuni piccoli extra pronti all'uso. Per sfruttare al meglio l'app, devi anche scaricare i **file principali**. Sono file dati grandi che aggiungono strumenti di studio come commentari, ricerche sulle parole e note grammaticali. Senza di essi l'app funziona, ma le funzioni di studio sono limitate.

## Perché servono i file principali

I file principali aggiungono:

- **Ricerca parole.** Tocca una parola in un versetto qualsiasi per vedere l'ebraico o il greco originale e il significato.
- **Commentario.** Commento IA su ogni versetto.
- **Grammatica.** Informazioni su ogni parola nella lingua originale.
- **Bibbia interlineare.** Leggi il testo nella lingua originale con l'inglese sotto ogni parola.

Puoi leggere la Bibbia senza questi file, ma la maggior parte degli strumenti di studio ne ha bisogno.

## Come installare i file principali

**[Installa file principali](theodia://manage/core)**

1. Apri **Impostazioni**.
2. Tocca **Gestisci risorse**.
3. Si apre la scheda **Core**. Vedi l'elenco dei file principali. Ognuno ha un nome, una dimensione e una casella di spunta.
4. Tocca ogni file che vuoi installare. Una spunta mostra che è selezionato.
5. Tocca **Installa selezionati**.
6. Attendi che i file vengano scaricati e installati. Sono grandi, quindi su una connessione lenta potrebbero servire alcuni minuti.

I file si scaricano sul tuo dispositivo. Serve farlo solo una volta. L'app li userà da quel momento in poi, anche offline.

## Suggerimenti

- Usa il Wi-Fi. I file sono grandi.
- Collega il telefono o il tablet. I download grandi usano batteria.
- Se un download fallisce, tocca di nuovo il file per riprovare.
- Puoi installarli tutti o solo quelli che ti servono.

## Cosa fare se un file manca dall'elenco?

L'app prende l'elenco dalla pagina GitHub del progetto. Se l'elenco è vuoto, controlla la connessione internet e riprova. Se è ancora vuoto, vedi la guida [Dove Fare Domande](theodia://help/getting-more-help).

Per modi più avanzati di aggiungere risorse, vedi la guida [Ottenere Risorse Extra da GitHub](theodia://help/getting-core-files).
