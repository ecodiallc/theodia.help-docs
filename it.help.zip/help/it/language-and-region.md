---
title: Lingua e Regione dell'App
level: everyday
categories: settings
summary: Come cambiare la lingua dell'app.
---

# Lingua e Regione dell'App

Theodia è disponibile in molte lingue. L'app può cambiare la lingua di menu e pulsanti. I contenuti di aiuto sono disponibili anche in molte di queste lingue e sono integrati nell'app. Puoi anche scaricare o aggiornare il pacchetto di aiuto di una lingua — apri **Impostazioni** → **Aiuto** oppure **Gestisci risorse** → **Installa da GitHub** → **Documenti di aiuto**.

## Come aprire le impostazioni lingua

1. Apri **Impostazioni**.
2. Tocca **Lingua**.

## Come cambiare la lingua dell'app

1. Nell'elenco **Lingua**, tocca la lingua che vuoi.
2. L'app applica subito la nuova lingua.

Le opzioni che vedi dipendono dalle lingue supportate dall'app.

## Come viene scelta la lingua al primo avvio

Quando installi Theodia per la prima volta, l'app sceglie una lingua in base alle impostazioni del tuo dispositivo. Puoi cambiarla in qualsiasi momento.

## Cosa viene tradotto

- Menu, pulsanti ed etichette.
- Schermate delle impostazioni.
- Messaggi di errore.
- Strumenti di ricerca e studio.

## Cosa è solo in inglese

- Alcuni contenuti di libri e devozionali.

## Traduzioni bibliche e lingua dell'app

La lingua dell'app e la lingua della traduzione biblica sono due cose diverse. Puoi avere l'app in spagnolo e la Bibbia in inglese, o viceversa.

Per cambiare la traduzione biblica, vedi la guida [Installare Traduzioni Bibliche](theodia://help/installing-bibles).

## Suggerimenti

- Se un pulsante o un'etichetta è vuoto, all'app manca quella traduzione. Di solito c'è la versione inglese come fallback.
- Se vuoi aiutare a tradurre l'app, vedi la guida [Dove Fare Domande](theodia://help/getting-more-help).
