---
title: Menu Rapido
level: everyday
categories: layout
summary: Un modo veloce per saltare ai versetti recenti, eseguire comandi e cambiare layout biblico senza lasciare la schermata attuale.
---

# Menu Rapido

> **Modalità:** il Menu rapido richiede la modalità **Studioso**. Puoi cambiare modalità in **Impostazioni** → **Modalità utente app**.

Il Menu rapido è un pannello di accesso rapido che puoi aprire quasi ovunque nell'app. Tiene insieme i tuoi versetti recenti, i comandi e le configurazioni bibliche salvate.

## Come aprirlo

Tocca l'**icona di espansione (⌄)** nell'angolo in alto a destra dell'intestazione della schermata principale. Un pannello scende dall'alto.

## Cosa c'è dentro

### 1. Casella comando

In cima al pannello c'è una casella di testo con un'icona di tastiera. Scrivi un comando e tocca **Vai** sulla tastiera. L'app legge il comando e ti porta direttamente lì.

Esempi:

- `Giovanni 3:16` — apre quel versetto.
- `cerca amore` — cerca "amore" nella Bibbia.
- `segnalibro salmi 23` — salva il versetto come segnalibro.
- `kjv` — passa alla traduzione KJV.

Per l'elenco completo dei comandi, vedi la guida [Comandi](theodia://help/commands).

### 2. Insiemi paralleli

Se hai salvato preimpostazioni di Bibbie parallele, appaiono qui come elenco comprimibile. Tocca una per caricare immediatamente quella configurazione parallela.

Per creare una preimpostazione parallela:

1. Apri **Impostazioni** → **Bibbia parallela**.
2. Aggiungi traduzioni e tocca **Salva preimpostazione**.
3. Dai un nome. Apparirà nel Menu rapido.

Tieni premuto un insieme parallelo nel Menu rapido per eliminarlo.

### 3. Collezioni bibliche

Le Collezioni bibliche sono scorciatoie che cambiano traduzione e vista parallela contemporaneamente. Se ne hai create, appaiono qui come elenco comprimibile.

Tieni premuta una collezione per eliminarla.

### 4. Icone funzionalità

Sotto la casella comando puoi vedere una riga di pulsanti rotondi con emoji. Sono scorciatoie a un tocco per le funzioni principali dell'app.

Le icone disponibili includono:

- **Informazioni**, **Bibbie**, **Note Bibliche**, **Segnalibri**, **Libri**
- **Devozionali**, **Flashcard**, **Aiuto**, **Punti salienti**
- **Playlist**, **Plugin**, **Cerca**, **Impostazioni**, **Theoscript**

Per scegliere quali icone mostrare e in che ordine:

1. Apri **Impostazioni** → **Menu rapido**.
2. Tocca **Icone menu rapido**.
3. Usa gli interruttori per mostrare o nascondere ogni icona.
4. Usa le frecce su/giù per riordinare quelle abilitate.

L'ordine nelle impostazioni è l'ordine in cui appaiono nel Menu rapido.

### 5. Versetti recenti

L'app ricorda gli ultimi capitoli e versetti che hai aperto. Appaiono come elenco in fondo al pannello. Tocca una voce per tornare direttamente lì.

- **Tocca** per aprire.
- **Scorri a sinistra** o **tieni premuto** per rimuovere dall'elenco.
- Tocca **Cancella tutto** per rimuovere tutte le voci in una volta.

## Quando usare il Menu rapido

Usalo quando vuoi:

- Tornare a un versetto che hai appena letto.
- Scrivere un comando senza andare alla schermata principale.
- Cambiare traduzione o configurazione parallela con un tocco.
- Aprire una funzione principale da qualsiasi schermata dell'app.
- Controllare qualcosa rapidamente senza passare per i menu.

## Suggerimenti

- Il Menu rapido è disponibile su quasi ogni schermata, quindi puoi aprirlo anche mentre leggi un capitolo.
- La casella comando supporta gli stessi comandi della casella Comando rapido nella schermata principale.
- Le icone funzionalità e il loro ordine sono salvati localmente sul dispositivo. Sopravvivono ai riavvii dell'app.
- I versetti recenti sono salvati localmente sul dispositivo. Sopravvivono ai riavvii dell'app.
