---
title: Muoversi tra Libri, Capitoli e Versetti
level: everyday
categories: [layout, read]
summary: Come muoversi nella Bibbia e saltare dove vuoi andare.
---

# Muoversi tra Libri, Capitoli e Versetti

Questa guida ti mostra tutti i modi per muoverti nella Bibbia.

## Il modo facile: scorrere

- Scorri a **sinistra** su un capitolo per andare al capitolo successivo.
- Scorri a **destra** per tornare indietro.
- Funziona anche per il libro successivo. Dopo l'ultimo capitolo dell'Esodo, lo scorrimento a sinistra porta al primo capitolo del Levitico.

## Il modo con il menu

- Tocca il nome della traduzione in alto per passare a un'altra Bibbia.
- Tocca il nome del libro in alto per scegliere un altro libro.
- Tocca il numero del capitolo per scegliere un altro capitolo.

## Il modo veloce: scrivere

- Nella schermata principale, in cima c'è una casella. Scrivi un riferimento, come `Giovanni 3:16` o `salmi 23`, e tocca il tasto **Vai** sulla tastiera.
- L'app apre il versetto.

## Il modo con i segnalibri

Se hai salvato un versetto, apri la scheda **Segnalibri**. Tocca una voce qualsiasi per saltare lì.

## Il modo con la ricerca

Tocca la scheda **Cerca**. Scrivi una parola. L'app ti mostra ogni versetto che la contiene. Tocca un risultato per aprirlo.

## Il modo con la cronologia

L'app ricorda i capitoli che hai aperto. Per trovarli di nuovo, guarda nella scheda **Segnalibri** (per i versetti salvati) o scorri l'elenco dei libri nella scheda **Bibbie** per trovare un libro letto di recente.

## Suggerimenti

- La scheda Bibbie mostra i libri in ordine, dalla Genesi all'Apocalisse.
- Per Salmi, Proverbi e altri libri lunghi, tocca il libro e usa l'elenco dei capitoli per saltare avanti velocemente.
