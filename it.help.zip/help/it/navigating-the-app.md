---
title: Layout e Navigazione dell'App
level: beginner
categories: layout
summary: Un tour della schermata principale, del menu principale e della barra degli strumenti in basso: dove si trova tutto.
---

# Layout e Navigazione dell'App

Theodia ha tre aree principali tra cui muoverti: la **schermata principale**, il **menu principale** e la **barra degli strumenti in basso**. Questa guida le spiega tutte in modo da sapere sempre dove andare.

## Mappa veloce

- La **schermata principale** è la pagina che vedi quando apri l'app. Ha una casella di ricerca, grandi pulsanti per ogni sezione e un elenco delle Bibbie, dei libri e dei devozionali installati.
- La **barra degli strumenti in basso** (anche chiamata tab bar) è la riga di icone in fondo allo schermo. Tocca una qualsiasi per saltare direttamente a quella sezione.
- Il **menu principale** è l'icona con tre linee (☰) nell'angolo in alto a destra della schermata principale. Toccalo per aprire l'elenco di tutte le schermate dell'app, incluse quelle che non hanno una scheda propria.

## La schermata principale

Quando apri Theodia, atterri sulla schermata principale. È divisa in quattro parti, dall'alto verso il basso.

### L'intestazione

In cima c'è una barra colorata. A sinistra ci sono l'icona dell'app e il nome "Theodia". A destra c'è il pulsante del menu principale (☰). Quando sei dentro un libro o un capitolo, a sinistra compare invece un pulsante indietro (←). Tocca il menu principale per aprire il menu (vedi sotto).

### Il Comando rapido

Appena sotto l'intestazione c'è una casella di testo simile a una ricerca, con etichetta **Comando rapido**. Scrivi una breve istruzione e tocca il tasto Vai sulla tastiera. L'app legge l'istruzione e ti porta alla schermata giusta. Esempi:

- `salmi 23` — apre il Salmo 23
- `giovanni 3:16` — apre Giovanni 3:16
- `cerca amore` — cerca "amore" nella Bibbia
- `segnalibro giovanni 3:16` — salva Giovanni 3:16 come segnalibro
- `commentario romani 8:28` — apre il commentario per quel versetto
- `xref` (seguito da un riferimento) — apre i riferimenti incrociati per quel versetto
- `aiuto` — apre l'elenco dei comandi con esempi

Se l'app non capisce ciò che hai scritto, mostra un piccolo avviso con un suggerimento. Vedi la guida **Problemi comuni** se i comandi non funzionano.

### La griglia di pulsanti

Sotto il Comando rapido c'è una griglia di grandi pulsanti, due per riga. Ogni pulsante ti porta a una parte diversa dell'app. I pulsanti sono:

- 📖 **Bibbie** — il tuo elenco di traduzioni bibliche
- 🔍 **Cerca** — cerca una parola o una frase nella Bibbia
- 📚 **Libri** — la tua libreria di classici cristiani
- 📅 **Devozionali** — devozionali giornalieri
- 🔖 **Segnalibri** — i tuoi versetti e capitoli salvati
- 🖍 **Punti salienti** — i tuoi versetti marcati a colori
- 📝 **Note Bibliche** — le tue note private sui versetti
- ⚙️ **Impostazioni** — lingua, tema, risorse e altro
- ❓ **Aiuto** — il sistema di aiuto (questa pagina)
- ℹ️ **Informazioni** — versione dell'app e crediti

### Gli elenchi di risorse

Sotto la griglia ci sono sezioni espandibili: **Bibbie**, **Libri** e **Devozionali**. Ogni sezione mostra gli elementi che hai installato. Tocca l'intestazione di una sezione per espanderla o comprimerla. Tocca un elemento qualsiasi per aprirlo.

La sezione Bibbie è il modo più veloce per saltare in una traduzione specifica: nessun menu, basta toccare.

## La barra degli strumenti in basso

La barra degli strumenti in basso (tab bar) è la riga di icone in fondo allo schermo. È visibile quasi ovunque nell'app, così puoi sempre saltare a un'altra sezione. Le schede che vedi dipendono dalla tua modalità utente.

**Tutte le modalità vedono:**

- 🏠 **Casa** — apre la schermata principale
- 📖 **Bibbie** — apre l'elenco delle traduzioni bibliche
- 📚 **Libri** — apre la tua libreria di libri
- 🔍 **Cerca** — apre la ricerca biblica
- ⚙️ **Impostazioni** — apre le impostazioni

**Standard e Studioso vedono anche:**

- 🔖 **Segnalibri** — apre i tuoi versetti salvati
- 🖍 **Punti salienti** — apre i tuoi versetti marcati a colori
- 📝 **Note** — apre le tue note private

**Studioso vede anche:**

- 💻 **IA** — apre l'assistente IA (se lo hai attivato nelle Impostazioni)

La scheda attuale è evidenziata. Tocca un'altra scheda per passare.

### Come si comporta la barra

Ogni scheda nella barra ha la propria **pila** di schermate. Quando tocchi una scheda, torni al punto **dove eri rimasto** nella pila di quella scheda, non alla schermata iniziale. Ad esempio:

- Tocca **Bibbie** → vedi l'elenco delle traduzioni.
- Tocca una traduzione → vedi l'elenco dei libri.
- Tocca un libro → vedi l'elenco dei capitoli.
- Tocca un capitolo → stai leggendo il capitolo.
- Passa a **Segnalibri** per controllare qualcosa.
- Tocca di nuovo **Bibbie** → torni al capitolo che stavi leggendo.

Ogni scheda ricorda il tuo posto. L'app conserva la tua cronologia di navigazione dentro ogni scheda, quindi passare da una scheda all'altra non fa perdere il progresso.

### Cosa resetta una scheda

Una scheda torna alla sua schermata principale solo quando:

- Sei già su quella scheda e tocchi di nuovo la stessa icona. È un modo rapido per tornare all'inizio.
- L'app viene chiusa forzatamente e riaperta.

### Schede in basso vs menu principale

- **Schede in basso** — ogni scheda ricorda la propria pila. Toccare una scheda ti riporta dove eri rimasto.
- **Menu principale** — toccare una voce naviga a quella schermata usando lo stesso sistema delle schede. Non si apre come overlay.

Usa le schede per cambiare attività. Usa il menu principale quando vuoi un elenco completo di tutte le schermate dell'app.

### Quando usare la barra degli strumenti

Usa la barra quando vuoi cambiare ciò che stai facendo:

- Stai leggendo un capitolo e vuoi cercare qualcos'altro → tocca **Cerca**.
- Stai cercando e vuoi controllare i tuoi segnalibri → tocca **Segnalibri**.
- Sei in qualsiasi schermata e vuoi tornare a casa → tocca **Casa**.

## Il menu principale

Il menu principale è il pulsante con tre linee sovrapposte (☰) nell'angolo in alto a destra della schermata principale. Toccalo e un pannello scorre dentro dal lato destro. Il pannello mostra ogni schermata supportata dalla tua modalità attuale:

- 🏠 **Casa**
- 📖 **Bibbie**
- 📚 **Libri**
- 🙏 **Devozionali**
- 🔍 **Cerca**
- 🔖 **Segnalibri** (Standard e Studioso)
- 🖍 **Punti salienti** (Standard e Studioso)
- 📝 **Note Bibliche** (Standard e Studioso)
- 💻 **Assistente IA** (solo Studioso, e solo se l'IA è attivata)
- ⚙️ **Impostazioni**
- ❓ **Aiuto**
- ℹ️ **Informazioni**

La voce che corrisponde alla schermata in cui ti trovi è evidenziata e ha un piccolo punto accanto. Tocca una voce qualsiasi per andare direttamente lì. Tocca fuori dal pannello, la X in alto o il pulsante indietro del dispositivo per chiuderlo senza cambiare schermata.

### Come differisce il menu principale

Il menu principale è un pannello a discesa, non un livello di navigazione separato. Quando tocchi una voce, l'app naviga a quella schermata nello stesso modo in cui avresti usato la scheda in basso o la griglia di pulsanti. La pila della tua scheda attuale viene preservata, quindi puoi tornare al punto in cui eri toccando di nuovo la scheda originale.

Ad esempio:

- Stai leggendo Giovanni 3. Tocchi la scheda **Segnalibri**. Vai ai tuoi segnalibri. Quando tocchi di nuovo **Bibbie**, torni a Giovanni 3 — esattamente dove eri rimasto.
- Stai leggendo Giovanni 3. Apri il menu principale e tocchi **Note Bibliche**. Si aprono le tue note. Per tornare a Giovanni 3, tocca la scheda **Bibbie** e torni automaticamente al capitolo.

Le schede cambiano il contesto e ricordano il tuo posto. Il menu principale è semplicemente un altro modo per raggiungere le stesse schermate.

### Quando usare il menu principale

Usa il menu principale quando:

- Vuoi aprire **Punti salienti**, **Note**, **Devozionali**, **Aiuto** o **Informazioni** — schermate che non hanno una propria scheda nella barra.
- Sei in profondità in un capitolo o in una ricerca e vuoi controllare qualcosa rapidamente senza perdere il posto.
- Vuoi aprire **Impostazioni** senza lasciare la schermata in cui ti trovi.

## Modalità Studioso

Se la tua modalità utente è **Studioso**, il layout guadagna schede extra, voci di menu e strumenti di lettura nascosti nelle modalità Lettura e Standard. Vedi la guida [Modalità Studioso](theodia://help/scholar-mode) per una panoramica completa di ogni funzione.

## Come si combinano le tre aree

- **Passare a una sezione principale diversa** (Bibbie, Cerca, Segnalibri, ecc.) → Barra degli strumenti in basso
- **Saltare a un versetto specifico o a un comando** → Comando rapido nella schermata principale
- **Sfogliare tutte le schermate disponibili** → Griglia di pulsanti nella schermata principale
- **Controllare Note, Punti salienti o Aiuto senza lasciare il posto** → Menu principale
- **Aprire Impostazioni da ovunque** → Menu principale o barra degli strumenti

Le userai tutte. Nessuna è "il modo giusto". Scegli la più comoda per quello che stai facendo.

### Barra vs menu principale: esempio rapido

Immagina di leggere Romani 8 e di voler evidenziare un versetto che ti piace.

**Con la barra degli strumenti:**

1. Tocca il versetto per aprire il menu del versetto.
2. Tocca **Evidenzia** e scegli un colore.
3. Fatto. Non hai mai lasciato il capitolo.

**Con il menu principale (se vuoi rivedere le tue evidenziazioni):**

1. Tocca ☰ per aprire il menu.
2. Tocca **Punti salienti**. Si apre l'elenco delle tue evidenziazioni.
3. Esaminale, poi tocca la scheda **Bibbie** per tornare a Romani 8.

**Con la barra degli strumenti (se vuoi cambiare attività):**

1. Tocca **Casa** o **Segnalibri** nella barra.
2. Lasci Romani 8 e vai alla nuova schermata.
3. Per tornare a Romani 8, tocca di nuovo **Bibbie** — torni automaticamente al capitolo.

## Suggerimenti

- La schermata principale ricorda quali sezioni sono espanse o compresse. Devi impostarlo solo una volta.
- Se non vedi una scheda che ti aspetti, controlla due cose:

1. **La tua modalità utente** — la modalità Lettura nasconde segnalibri, punti salienti, note e IA. La modalità Standard nasconde l'IA. Cambia modalità in **Impostazioni** → **Modalità utente app**.
2. **Impostazioni funzioni** — alcune schede devono essere attivate in **Impostazioni** (ad esempio, l'assistente IA).
