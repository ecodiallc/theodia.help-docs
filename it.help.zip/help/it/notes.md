---
title: Scrivere Note
level: everyday
categories: [annotate, read]
summary: Come scrivere i tuoi pensieri accanto a un versetto.
---

# Scrivere Note

> **Modalità:** le note sono disponibili nelle modalità **Standard** e **Studioso**. La modalità Messa a fuoco è solo per lettura pulita e senza distrazioni. Puoi cambiare modalità in **Impostazioni** → **Modalità utente app**.

Le note sono il posto dove scrivi i tuoi pensieri, preghiere o idee di studio accanto a un versetto. Ogni nota è legata a un versetto specifico.

## Come aggiungere una nota

1. Apri il versetto.
2. Tocca il versetto per aprire il menu.
3. Tocca **Nota** nel menu. Ha un'icona a matita.
4. Scrivi la tua nota.
5. Tocca **Salva**.

La nota è ora salvata con il versetto.

## Come leggere una nota

1. Apri il versetto.
2. Cerca il segno di matita accanto al versetto. Significa che c'è una nota.
3. Tocca il versetto. La nota appare sotto.

## Come modificare una nota

1. Apri il versetto con la nota.
2. Tocca il versetto.
3. Tocca **Nota** nel menu.
4. Apporta le tue modifiche.
5. Tocca **Salva**.

## Come eliminare una nota

1. Apri il versetto con la nota.
2. Tocca il versetto.
3. Tocca **Nota** nel menu.
4. Tocca **Elimina**.

## Come vedere tutte le tue note

Tocca la scheda **Note Bibliche** in basso. Vedi l'elenco di ogni nota che hai scritto, ordinato per data.

## Cerca nelle tue note

Nella scheda **Note Bibliche**, tocca la casella **Cerca**. Scrivi una parola. L'app trova ogni nota che la contiene.

## Suggerimenti

- Le note sono ideali per sermoni, devozioni e domande di studio.
- Le note sono private. Restano sul tuo dispositivo.
- Vedi la guida [Backup dei tuoi dati](theodia://help/backups) per tenerle al sicuro.
