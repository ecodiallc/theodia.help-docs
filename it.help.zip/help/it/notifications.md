---
title: Notifiche e Promemoria
level: everyday
categories: [settings]
summary: Come attivare, personalizzare e gestire promemoria offline per preghiera, devozionali, piani di lettura biblica e altro.
---

# Notifiche e Promemoria

Theodia può ricordarti di pregare, leggere devozionali, seguire piani di lettura biblica, ripassare flashcard e altre attività — anche quando l'app è offline. Tutti i promemoria sono programmati sul tuo dispositivo; non servono connessione internet né server push.

## Come attivare o disattivare i promemoria

1. Apri **Impostazioni**.
2. Tocca **Notifiche**.
3. Attiva o disattiva **Abilita promemoria**.

La prima volta che attivi i promemoria, l'app chiede il permesso di inviare notifiche. Tocca **Consenti** così i promemoria possono apparire.

Se hai negato il permesso in precedenza, iOS o Android potrebbero bloccare la richiesta. In tal caso, apri l'app **Impostazioni** del dispositivo, trova **Theodia** e abilita le notifiche lì.

## Tipi di promemoria

La schermata delle notifiche è divisa in canali. Ogni canale è una famiglia di promemoria che puoi attivare o disattivare indipendentemente:

- **Promemoria di preghiera** — promemoria generali di preghiera.
- **Promemoria routine** — promemoria legati a una routine di preghiera specifica.
- **Versetto / devozionale del giorno** — promemoria del versetto o devozionale giornaliero.
- **Promemoria piano di lettura biblica** — promemoria per un piano di lettura attivo.
- **Promemoria Theoscript** — promemoria per eseguire un Theoscript.
- **Promemoria approfondimenti IA** — promemoria generati dall'IA.
- **Promemoria ripasso flashcard** — inviti a ripassare le flashcard.
- **Promemoria abitudine di lettura** — inviti giornalieri alla lettura.
- **Promemoria liturgici e stagionali** — promemoria legati al calendario liturgico.
- **I miei promemoria** — promemoria creati da segnalibri, punti salienti, playlist, capitoli biblici o libri.
- **Promemoria personalizzati** — promemoria completamente personalizzati creati da te.

Tocca un canale qualsiasi per vedere i suoi promemoria, cambiare l'ora, scegliere i giorni in cui attivarlo o disattivarlo.

## Promemoria personalizzati

I promemoria personalizzati sono quelli che costruisci da zero.

1. In **Impostazioni** → **Notifiche**, tocca **Promemoria personalizzati**.
2. Tocca il pulsante **+**.
3. Inserisci un **Titolo** e un **Messaggio**.
4. Scegli un'**Ora**.
5. Seleziona i **Giorni** in cui vuoi che si ripeta.
6. Scegli cosa apre il promemoria quando viene toccato (opzionale).
7. Tocca **Salva**.

Puoi modificare o eliminare un promemoria personalizzato in qualsiasi momento toccandolo nell'elenco.

## Cosa succede quando tocchi un promemoria

La maggior parte dei promemoria apre una schermata specifica dell'app. Ad esempio, un promemoria di routine di preghiera apre quella routine; un promemoria di piano di lettura biblica apre la lettura successiva.

Se un promemoria non ha una schermata collegata, apre l'app sulla schermata principale.

## Ore di quiete

Le ore di quiete silenziano i suoni delle notifiche, lasciando comunque apparire i promemoria visivi.

1. In **Impostazioni** → **Notifiche**, tocca **Ore di quiete**.
2. Imposta un'ora di **Inizio** e una di **Fine**.

I promemoria programmati durante le ore di quiete appariranno sullo schermo senza suono.

## Promemoria in arrivo e cronologia

- **Prossimi promemoria** mostra tutto ciò che è programmato per scattare.
- **Cronologia notifiche** mostra i promemoria consegnati di recente, programmati e annullati.

Usa questi elenchi per confermare che un promemoria sia impostato correttamente o per capire perché uno non è apparso.

## Se i promemoria non appaiono

- Assicurati che **Abilita promemoria** sia attivo.
- Controlla che le notifiche siano consentite nelle impostazioni di sistema del dispositivo.
- Assicurati che il canale del promemoria sia abilitato e che almeno un giorno sia selezionato.
- Se hai impostato le ore di quiete, il promemoria potrebbe essere silenzioso.
- Alcuni produttori Android mettono le app in sospensione. Aggiungi Theodia all'elenco consentito se il tuo dispositivo offre impostazioni di ottimizzazione batteria.
- Se un promemoria è collegato a un contenuto che hai rimosso (ad esempio, un piano di lettura biblica o una routine eliminata), il promemoria potrebbe non scattare finché non selezioni di nuovo un target valido.

## Suoni delle notifiche

Puoi scegliere il suono riprodotto dai promemoria che supportano i suoni. Tocca **Suono** dentro un promemoria o un canale per scegliere tra le opzioni disponibili. I suoni sono inclusi nell'app, quindi funzionano offline.

Usa il pulsante **Anteprima suono** per ascoltare il suono selezionato prima di salvare.

## Badge

Alcuni promemoria possono aggiungere un badge all'icona dell'app. Tocca **Azzera badge** nella schermata delle notifiche per resettarlo.
