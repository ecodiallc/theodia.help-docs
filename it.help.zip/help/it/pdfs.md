---
title: PDF
level: everyday
categories: [read, resources]
summary: Importa, organizza e leggi documenti PDF in Theodia.
---

# PDF

> **Modalità:** i PDF sono disponibili nelle modalità **Standard** e **Studioso**. La modalità Messa a fuoco è solo per una lettura pulita e senza distrazioni. Puoi cambiare modalità in **Impostazioni** → **Modalità utente app**.

Theodia può archiviare e leggere file PDF. I PDF importati restano sul tuo dispositivo, quindi funzionano anche offline.

## Apri la libreria PDF

Tocca la scheda **PDF** in fondo allo schermo, oppure tocca la tile **PDF** nella schermata principale.

## Importa un PDF

1. Apri la scheda **PDF**.
2. Tocca il pulsante **+** in basso a destra.
3. Scegli un PDF dal tuo dispositivo.
4. (Facoltativo) Digita o scegli una categoria per organizzarlo.

## Organizza i PDF

Tieni premuta qualsiasi carta PDF per aprire un menu con queste opzioni:

- **Rinomina** — cambia il titolo mostrato nella libreria.
- **Cambia categoria** — sposta il PDF in una categoria.
- **Elimina** — rimuove il PDF da Theodia. Elimina anche la posizione di lettura salvata.

Le categorie sono testo libero. Digita un nuovo nome o scegline uno esistente quando importi o cambi una categoria.

## Leggi un PDF

Tocca una carta PDF per aprirla. Il lettore mostra:

- Il titolo del documento in una barra in alto.
- Una riga di pulsanti di pagina: **Prima pagina**, **Precedente**, la pagina corrente ("3 / 120"), **Successiva** e **Ultima pagina**.
- Una barra degli strumenti con gli strumenti del documento: **Sommario**, **Riduci zoom**, **Aumenta zoom**, **Reimposta zoom**, **Segnalibro**, **Cerca**, **Leggi** e **Vista testo**.

Alcuni strumenti sono disattivati quando non possono essere usati — per esempio, **Cerca** e **Leggi** sono disattivati finché il testo ricercabile del PDF non è installato.

### Sfoglia le pagine

- Tocca la **freccia sinistra** o **destra** per andare indietro o avanti di una pagina.
- Tocca **Prima pagina** o **Ultima pagina** per saltare a una delle due estremità del documento.
- Tocca il numero di pagina (per esempio "3 / 120") per aprire una griglia di pagine, poi tocca la pagina che vuoi. La griglia si apre vicino alla pagina in cui ti trovi.
- Usa i **tasti freccia sinistra e destra** di una tastiera esterna.

### Zoom

- Tocca **Aumenta zoom** (+) o **Riduci zoom** (−) per cambiare la dimensione della pagina.
- Tocca **Reimposta zoom** per riportare la pagina alla dimensione normale.
- Se aumenti lo zoom, cambi pagina e poi riduci lo zoom, Theodia ti riporta alla pagina che stavi leggendo.

## Cerca dentro un PDF

1. Apri il PDF e tocca il pulsante **Cerca** (lente d'ingrandimento) nella barra degli strumenti.
2. Digita ciò che stai cercando. I risultati appaiono mentre digiti, con il numero di pagina e un estratto del testo circostante.
3. Tocca un risultato per saltare a quella pagina.

La ricerca richiede che il testo ricercabile del PDF sia installato. Se non è ancora installato, il pulsante Cerca è disattivato. I PDF installati dal repository GitHub della community includono il testo ricercabile; i PDF che importi tu non lo hanno finché non viene aggiunto.

## Sommario

Se il PDF ha un indice incorporato, il pulsante **Sommario** nella barra degli strumenti lo mostra come struttura. Tocca il titolo di una sezione per saltare a quella pagina. Le sezioni possono essere espanse e compresse. Se il PDF non ha un indice, il pulsante è disattivato.

## Segnalibri in un PDF

1. Apri il PDF e tocca il pulsante **Segnalibro** nella barra degli strumenti.
2. Tocca **Aggiungi segnalibro** per salvare la pagina corrente. Il nome inizia come numero di pagina — digita un nome se preferisci — poi tocca **Salva**.
3. Tocca qualsiasi segnalibro nell'elenco per saltare alla sua pagina.
4. Tocca la **×** accanto a un segnalibro per eliminarlo.

I segnalibri dei PDF sono separati dai segnalibri della Bibbia. Ogni PDF conserva il proprio elenco.

## Leggi un PDF ad alta voce

Se il testo ricercabile del PDF è installato, Theodia può leggere ad alta voce la pagina corrente:

1. Apri il PDF e tocca il pulsante **Leggi** (altoparlante) nella barra degli strumenti.
2. Appare una barra di controllo con **Riproduci/Pausa**, **Riavvolgi**, **Avanti veloce**, **Ferma**, una barra di avanzamento che puoi toccare per saltare dentro la pagina, la velocità di lettura e la voce.
3. Quando la pagina finisce, la lettura continua automaticamente nella pagina successiva.

La voce e la velocità sono le stesse usate per la lettura della Bibbia — vedi [Leggere ad alta voce](theodia://help/tts) per come cambiarle.

## Copia, condividi o salva il testo della pagina

Tocca il pulsante **Vista testo** nella barra degli strumenti per vedere la pagina corrente come testo semplice. Da lì puoi:

- **Copia** — copia il testo della pagina negli appunti.
- **Condividi** — condividi il testo della pagina tramite qualsiasi app del tuo dispositivo.
- **Aggiungi alle note** — apre un editor di note con il testo della pagina, una citazione e un link a questa pagina già compilati per te.

## Riprendi la lettura

Theodia ricorda l'ultima pagina che hai visualizzato e la prossima volta apre il PDF da lì.

## Scarica PDF da GitHub

In modalità **Studioso**, in fondo alla libreria appare un pulsante **Scarica da GitHub**. Si collega al repository GitHub della community dei PDF, così puoi installare documenti PDF confezionati nello stesso modo in cui installi Bibbie o libri.

## Note

- I PDF sono archiviati nella cartella documenti privata di Theodia. Non sono inclusi nei backup, quindi se passi a un nuovo dispositivo dovrai importarli di nuovo.
