---
title: Playlist
level: everyday
categories: playlists
summary: Crea e ascolta playlist vocali di passaggi biblici, testo semplice o qualsiasi versetto che desideri sentire.
---

# Playlist

Una **playlist** è un elenco di brani che Theodia può leggerti ad alta voce. Ogni brano è un passaggio biblico o una breve nota in testo semplice. Le playlist sono utili per ascoltare senza usare le mani mentre viaggi, cammini, fai un momento di devozione o eserciti la memoria.

Le playlist appaiono nell'app non appena ne viene creata o popolata almeno una.

## Dove trovare le Playlist

Quando le playlist sono disponibili, puoi raggiungerle in due modi:

- **Schermata principale:** nella sezione **Plugin e altro**, tocca **Playlist**.
- **Menu principale:** apri il menu (☰) e tocca **Playlist**.

Se non esiste ancora nessuna playlist, la tile e la voce di menu Playlist sono nascoste.

## Cosa contiene una playlist

Ogni playlist ha:

- Un **nome** — ad esempio "Versetti del mattino" o "Memorizza il Salmo 23".
- Una **categoria** opzionale — utile per raggruppare le playlist per scopo.
- Un elenco di **brani** — gli elementi da leggere ad alta voce.

Ogni brano contiene:

- **Contenuto** — un riferimento biblico o un testo semplice.
- Un'**etichetta** — mostrata sullo schermo mentre il brano viene riprodotto.
- Una **voce** opzionale — scegli una voce diversa per questo brano, se vuoi.

## Creare una playlist

1. Apri la schermata **Playlist**.
2. Tocca **Crea playlist** (o il pulsante **+**).
3. Dai un nome alla playlist.
4. (Opzionale) Scegli o crea una categoria.
5. Inizia ad aggiungere brani.

### Aggiungere un brano da un passaggio biblico

1. Tocca **Aggiungi traccia**.
2. Scegli **Passaggio biblico** come tipo di contenuto.
3. Inserisci un riferimento, come `Giovanni 3:16` o `Salmo 23:1-6`.
4. Aggiungi un'etichetta, se vuoi, oppure lascia vuoto per usare il riferimento.
5. Salva il brano.

### Aggiungere un brano in testo semplice

1. Tocca **Aggiungi traccia**.
2. Scegli **Testo semplice**.
3. Scrivi il testo che vuoi che Theodia legga.
4. Aggiungi un'etichetta.
5. Salva il brano.

### Aggiunta batch di brani

Se hai un elenco di riferimenti o righe di testo, usa **Aggiunta batch**:

1. Apri una playlist.
2. Tocca il menu e scegli **Aggiunta batch**.
3. Incolla un riferimento o una riga di testo per riga.
4. Attiva **Rileva riferimenti biblici** se la maggior parte delle righe sono riferimenti a versetti.
5. Tocca **Aggiungi**. Ogni riga diventa un brano.

## Ascoltare una playlist

1. Apri la playlist che vuoi ascoltare.
2. Tocca il pulsante **Riproduci** in alto o accanto a un brano.
3. Theodia legge ogni brano in ordine.

Mentre una playlist è in riproduzione, appare una barra di controllo con questi comandi:

- **Riproduci / Pausa**
- **Traccia successiva**
- **Traccia precedente**
- **Ferma**

Puoi anche impostare:

- **Velocità** — la velocità con cui la voce legge.
- **Ripeti** — ripeti l'intera playlist, ripeti un brano o riproduci una volta sola.
- **Casuale** — riproduci i brani in ordine casuale.
- **Ignora parentesi** — salta il testo tra parentesi.
- **Pausa tra i brani** — aggiungi un breve silenzio tra i brani.
- **Timer di spegnimento** — interrompi la riproduzione dopo un tempo prefissato.

## Modificare una playlist

Per modificare una playlist, prima metti in pausa la riproduzione, se è attiva.

Puoi:

- **Rinominare** la playlist.
- **Riordinare i brani** — trascina i brani in un nuovo ordine.
- **Modificare un brano** — cambiarne riferimento, testo, etichetta o voce.
- **Eliminare un brano** — rimuoverlo dalla playlist.
- **Eliminare l'intera playlist** — questa azione non può essere annullata.

## Esportare e importare playlist

Le playlist vengono esportate come file JSON che includono tutti i brani, le categorie e le impostazioni. Puoi condividere il file con un altro dispositivo, conservarlo come backup o modificarlo su un computer.

- **Esporta tutte le playlist** — crea un file `playlists-AAAA-MM-GG.json`.
- **Esporta una categoria** — crea un file JSON contenente solo le playlist di una categoria.
- **Importa playlist** — ripristina le playlist da un file di backup JSON.

## Modi rapidi per creare una playlist

Puoi anche creare una playlist completa come JSON e importarla. Ecco un esempio:

```json
{
  "playlists": [
    {
      "name": "Versetti del mattino",
      "category": "Devozionale",
      "tracks": [
        {
          "info": "Giovanni 3:16",
          "contentSource": "passage",
          "content": "Perché Dio ha tanto amato il mondo...",
          "rawContent": "Giovanni 3:16"
        },
        {
          "info": "Salmo 23",
          "contentSource": "passage",
          "content": "Il Signore è il mio pastore...",
          "rawContent": "Salmo 23:1-6"
        }
      ]
    }
  ]
}
```

Salva il file, poi usa **Importa playlist** per caricarlo in Theodia.

## Suggerimenti

- Le playlist funzionano meglio con insiemi brevi e mirati di versetti.
- Usa le categorie per separare le playlist devozionali da quelle di memorizzazione.
- Imposta un timer di spegnimento se ascolti mentre ti addormenti.
- Se un brano usa la voce sbagliata, verifica che la lingua della voce corrisponda a quella del testo.
- Theodia legge il testo semplice esattamente come è scritto; controlla l'ortografia per i migliori risultati.
