---
title: Sviluppo plugin
categories: plugins
level: advanced
summary: Cosa contiene un pacchetto plugin Theodia e come scrivere un manifesto di plugin.
---

# Sviluppo plugin

Un plugin Theodia è un pacchetto autonomo che aggiunge superfici UI, contenuti o gestione di eventi all'app. I plugin sono creati al di fuori dell'app principale e installati dagli utenti attraverso Impostazioni → Plugin.

## Struttura del pacchetto plugin

Un pacchetto plugin è un archivio ZIP con estensione `.plugin.zip`. All'interno, i file si trovano al livello superiore — non dentro una cartella annidata.

Un pacchetto tipico contiene:

```
my-plugin.plugin.zip
├── plugin.json       (obbligatorio)
├── data.sqlite       (opzionale, per plugin contenuto/ui)
├── template.html     (opzionale)
├── style.css         (opzionale)
└── logo.png          (opzionale)
```

File obbligatori:

- `plugin.json` — il manifesto del plugin (vedi sotto).

File opzionali:

- Un database SQLite per i plugin che memorizzano contenuti o dati UI.
- Risorse HTML, Markdown, immagini o JSON referenziate dal manifesto.

Tutti i riferimenti alle risorse in `plugin.json` devono usare nomi di file esatti e flat, senza percorsi. Ad esempio, usa `template.html` invece di `templates/template.html`.

## Nozioni di base sul manifesto

Un `plugin.json` minimale si presenta così:

```json
{
  "id": "org.example.myplugin",
  "name": "Example Plugin",
  "version": "0.1.0",
  "type": "ui",
  "description": "A short description of what the plugin does.",
  "extensions": [
    {
      "surface": "bible-verse-menu",
      "config": {
        "label": "Example",
        "icon": "🔌",
        "screenType": "template",
        "templateFile": "template.html"
      }
    }
  ]
}
```

### Campi comuni del manifesto

| Campo           | Obbligatorio                      | Descrizione                                                                   |
| --------------- | --------------------------------- | ----------------------------------------------------------------------------- |
| `id`            | Sì                                | Identificatore in stile dominio inverso, ad esempio `org.example.myplugin`.   |
| `name`          | Sì                                | Nome visualizzato agli utenti.                                                |
| `version`       | Sì                                | Versione semver del plugin.                                                   |
| `type`          | Sì                                | `ui`, `content` o `composite`.                                                |
| `description`   | No                                | Breve riepilogo di cosa fa il plugin.                                         |
| `minAppVersion` | No                                | Versione minima dell'app Theodia richiesta.                                   |
| `apiVersion`    | No                                | Versione dell'API plugin presa di mira.                                       |
| `extensions`    | Obbligatorio per `ui` e `composite` | Array di dichiarazioni di superficie (vedi sotto).                            |

### Superfici

Ogni voce `extensions` dichiara dove appare il plugin e cosa fa:

```json
{
  "surface": "home-screen",
  "config": {
    "title": "My Plugin",
    "icon": "📝",
    "screenType": "list",
    "dbTable": "Articles",
    "titleColumn": "Title"
  }
}
```

Superfici supportate:

- `bottom-toolbar` — voce nella scheda Plugin in basso.
- `home-screen` — tile nella schermata principale.
- `hamburger-menu` — voce nel menu principale.
- `bible-verse-menu` — azione su pressione lunga di un versetto nel lettore biblico.
- `bible-chapter-toolbar` — azione nella barra degli strumenti del capitolo nel lettore biblico.
- `book-chapter-toolbar` — azione nella barra degli strumenti del lettore di libri.
- `ai-verse-action` — azione IA su un versetto (richiede che l'IA sia abilitata).
- `ai-chapter-action` — azione IA su un capitolo (richiede che l'IA sia abilitata).
- `event` — gestore di eventi del ciclo di vita dell'app.

### Tipi di schermata

Il campo `screenType` nella configurazione di una superficie indica all'app come renderizzare la schermata del plugin:

- `list` — elenco scorrevole di righe del database.
- `data-list` — elenco con aggiunta/modifica/eliminazione.
- `detail` — contenuto di una singola riga o passaggio.
- `markdown` — file Markdown statico renderizzato come HTML.
- `html` — file HTML statico renderizzato con `react-native-render-html`.
- `template` — file HTML con sostituzione dei segnaposto `{{key}}`.
- `flashcard` — interfaccia a carta con due colonne del database.

## Distribuzione

Una volta impacchettato come file `.plugin.zip`, un plugin può essere:

- Importato direttamente da un file dall'utente.
- Servito da un repository catalogo.

## Suggerimenti

- Mantieni `plugin.json` JSON valido. L'app rifiuta i manifesti non validi durante l'installazione.
- Usa nomi di file esatti per tutte le risorse referenziate.
- Gli ID plugin dovrebbero seguire lo stile dominio inverso per evitare collisioni.
- Verifica i contenuti del plugin offline, poiché gli utenti potrebbero non avere una connessione di rete.
