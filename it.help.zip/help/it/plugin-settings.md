---
title: Abilitare e configurare plugin
level: advanced
categories: plugins
summary: Come attivare, disattivare e importare plugin.
---

# Abilitare e configurare plugin

Una volta installato un plugin, puoi attivarlo, disattivarlo o rimuoverlo. Questa guida ti mostra come fare.

## Come aprire le impostazioni plugin

1. Apri **Impostazioni**.
2. Tocca **Plugin**.
3. Tocca **Gestisci plugin**.

## Come attivare o disattivare un plugin

Nell'elenco **Plugin installati**, trova il plugin che vuoi. Tocca l'interruttore sulla destra.

- **On** — il plugin è attivo.
- **Spento** — il plugin è in pausa.

Alcuni plugin hanno anche un interruttore on/off nella riga **Plugin** della schermata principale.

## Come rimuovere un plugin

1. Trova il plugin nell'elenco **Plugin installati**.
2. Tocca **Disinstalla**.
3. Conferma.

## Come installare un nuovo plugin

1. Apri le impostazioni plugin (vedi sopra).
2. Tocca **Importa da file**.
3. Scegli il file del plugin dal tuo dispositivo.

Il plugin appare nell'elenco **Plugin installati**. Attivalo per iniziare a usarlo.

## Suggerimenti

- Alcuni plugin richiedono internet per funzionare. Potrebbero non funzionare offline.
- Alcuni plugin richiedono un account o una chiave. La pagina del plugin spiegherà come procedere.
- Se un plugin causa problemi, disattivalo. Puoi continuare a usare il resto dell'app.
- Rimuovere un plugin non elimina le tue note, evidenziazioni o segnalibri. Questi restano al sicuro.
