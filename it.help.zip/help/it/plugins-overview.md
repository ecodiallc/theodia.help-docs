---
title: Cosa sono i plugin?
level: advanced
categories: plugins
summary: Una guida semplice sui plugin e su cosa possono aggiungere.
---

# Cosa sono i plugin?

Un plugin è una piccola estensione per Theodia. I plugin aggiungono nuove funzionalità, nuove risorse o nuovi strumenti. Sono creati da persone della community di Theodia.

## Cosa può fare un plugin?

I plugin possono fare molte cose. Alcuni esempi:

- Aggiungere una nuova traduzione biblica.
- Aggiungere un nuovo commentario o lessico.
- Aggiungere un pulsante alla barra degli strumenti in basso.
- Aggiungere una tile alla schermata principale.
- Aggiungere una voce al menu principale.
- Aggiungere uno strumento di studio personalizzato.

## Come trovare i plugin installati

I plugin possono apparire in tre posti:

- **Barra degli strumenti in basso** — una scheda **Plugin** in fondo allo schermo.
- **Schermata principale** — una griglia plugin nella schermata Home.
- **Menu principale** — una voce **Plugin** nel menu principale.

Dove appare un plugin dipende da ciò che il suo autore ha dichiarato nel manifesto. Tocca qualsiasi icona di plugin per aprirlo.

## Formati dei file plugin

Theodia supporta due formati di file plugin:

- **`.plugin.zip`** — un archivio ZIP contenente `plugin.json`, il database del plugin e le eventuali risorse. Questo è il formato consigliato. Il nome del file è del tipo `org.example.myplugin.plugin.zip`.
- **Risorse legacy a file singolo** — file `.bible`, `.commentary`, `.lexicon`, `.book`, `.sqlite` o `.db` più vecchi che incorporano il manifesto dentro il database. Funzionano ancora, ma hanno meno funzionalità.

## Come installare un nuovo plugin

Theodia non ha un negozio di plugin dentro l'app. Per installare un plugin:

1. Trova un file plugin sul tuo dispositivo.
2. Apri **Impostazioni** → **Plugin** → **Gestisci plugin**.
3. Tocca **Importa da file**.
4. Scegli il file del plugin.

Il plugin appare nell'elenco **Plugin installati**. Attivalo per iniziare a usarlo.

## Come attivare o disattivare un plugin

In **Impostazioni** → **Plugin** → **Gestisci plugin**, trova il plugin nell'elenco **Plugin installati**. Tocca l'interruttore sulla destra.

- **On** — il plugin è attivo.
- **Spento** — il plugin è in pausa.

Disattivare un plugin ne nasconde le funzionalità. Non elimina il plugin.

## Come rimuovere un plugin

1. Apri **Impostazioni** → **Plugin** → **Gestisci plugin**.
2. Trova il plugin nell'elenco **Plugin installati**.
3. Tocca **Disinstalla**.
4. Conferma.

## Cosa c'è dentro un file `.plugin.zip`?

Un file `.plugin.zip` è un archivio ZIP. Deve contenere:

- `plugin.json` — il manifesto del plugin.
- Il database del plugin, nominato esattamente come dichiarato nel manifesto.

Può anche contenere:

- Risorse HTML o Markdown referenziate dal manifesto.

Il manifesto dichiara `id`, `name`, `version` e cosa fornisce:

- `type`: `content`, `ui` o `composite`.
- `content`: un database SQLite e uno schema per contenuto biblico, commentario, lessico, libro o devozionale.
- `extensions`: superfici come `bottom-toolbar`, `home-screen`, `hamburger-menu`, azioni sui versetti, pulsanti nella barra degli strumenti del capitolo o gestori di eventi.

## Una parola di cautela

I plugin sono creati da altre persone, non dal team di Theodia. Leggi la descrizione del plugin prima di installarlo. Alcuni plugin potrebbero richiedere internet o raccogliere dati.

## Sviluppo plugin

Se vuoi creare o modificare plugin all'interno del repository sorgente di Theodia, consulta la guida [Sviluppo plugin](theodia://help/plugin-development). Spiega come impacchettare i plugin con `npm run package-plugins` e reimportarli per modificarli con `npm run import-plugin-dev`.

## Dove posso ottenere aiuto per un plugin?

Ogni plugin ha la propria pagina in **Gestisci plugin**. Guarda lì per prima cosa. Se hai ancora domande, consulta la guida [Dove fare domande](theodia://help/getting-more-help).
