---
title: Obiettivi di preghiera
level: everyday
categories: [prayer]
summary: Tieni traccia delle abitudini e degli obiettivi personali di preghiera.
---

# Obiettivi di preghiera

> **Modalità:** gli Obiettivi di preghiera sono disponibili in modalità **Standard** e **Studioso**. La modalità Messa a fuoco nasconde gli strumenti extra per una lettura senza distrazioni. Puoi cambiare modalità in **Impostazioni** → **Modalità utente app**.

Gli Obiettivi di preghiera ti permettono di tenere traccia delle abitudini che ti interessano: leggere una preghiera fissa ogni mattina, completare tre routine di preghiera al giorno, scrivere nel diario prima di dormire, passare dieci minuti in silenzio, o qualsiasi altra regola tu scelga. Theodia registra già la tua attività di preghiera, quindi un obiettivo osserva semplicemente quell'attività e ti dice come stai andando.

## Cosa misura un obiettivo

Quando crei un obiettivo, scegli cosa contare:

- **Routine** — completa una qualsiasi routine, una routine specifica, o una routine che contiene un tipo di passaggio come silenzio o lectio divina.
- **Voci di diario** — scrivi nel tuo diario di preghiera.
- **Minuti del timer** — trascorri tempo nel timer di preghiera.
- **Preghiere fisse** — leggi una preghiera fissa o un credo.
- **Sessioni guidate** — completa una preghiera audio-guidata.
- **Check-in manuale** — tocchi tu stesso **Segna come fatto** quando hai pregato.

Puoi anche impostare un obiettivo numerico e una programmazione: giornaliera, settimanale, mensile, giorni specifici della settimana, o una sola volta.

## Creare un obiettivo

1. Vai alla scheda **Preghiera**.
2. Tocca **Obiettivi** (o il pulsante **+** se vedi già la riga Obiettivi).
3. Tocca il pulsante fluttuante **+** per aprire il costruttore di obiettivi.
4. Scegli un modello per iniziare rapidamente, oppure **Inizia da zero**.
5. Compila i dettagli: nome, icona, colore, obiettivo, programmazione e ora del promemoria.
6. Tocca **Salva obiettivo**.

Il primo obiettivo che crei viene fissato automaticamente nella schermata principale di Preghiera.

## Fissare un obiettivo nella schermata principale

Gli obiettivi fissati appaiono nella scheda **Obiettivo attivo** in cima alla scheda Preghiera e nella riga **Obiettivi di preghiera** sotto Statistiche. Per fissare o rimuovere un obiettivo:

1. Apri l'elenco degli obiettivi.
2. Trova l'obiettivo che vuoi.
3. Tocca l'obiettivo, poi tocca **Fissa in home**. Tocca di nuovo per **Rimuovi dalla home**.

Puoi fissare fino a due obiettivi. Solo gli obiettivi attivi possono essere fissati.

## Segnare un obiettivo come completato

Se un obiettivo è impostato su **Check-in manuale**, Theodia non può sapere automaticamente quando hai pregato. Devi segnarlo tu stesso:

1. Apri la schermata dei dettagli dell'obiettivo.
2. Tocca **Segna completato oggi**.
3. Opzionalmente aggiungi una breve nota, poi tocca **Segna come fatto** di nuovo.

Puoi anche aprire il menu a scomparsa della scheda Obiettivo attivo e toccare **Segna come fatto**.

## Leggere i tuoi progressi

Tocca qualsiasi obiettivo per aprire la schermata dei dettagli. Vedrai:

- **Progresso di oggi** — quanto sei vicino all'obiettivo in questo momento.
- **Serie** — serie attuale e serie più lunga.
- **Tasso di successo** — percentuale dei giorni programmati completati.
- **Mini calendario** — i giorni verdi sono completati, il giorno contornato è oggi.
- **Cronologia recente** — ultime due settimane di progressi.

### Azioni sull'obiettivo

Dalla schermata dei dettagli puoi:

- **Fissa** o **rimuovi** dalla home.
- **Metti in pausa** per interrompere il tracciamento per un po' (le serie si bloccano).
- **Riprendi** per ricominciare a tracciare.
- **Modifica** per cambiare obiettivo, programmazione, promemoria o stile.
- **Elimina** per rimuovere l'obiettivo e la sua cronologia.

## Approfondimenti

La schermata **Approfondimenti** mostra le tendenze tra tutti i tuoi obiettivi:

- Obiettivi raggiunti oggi, questa settimana e questo mese.
- Serie più lunga attuale.
- Tassi di completamento settimanale e mensile.
- Tempo medio di preghiera (dagli obiettivi timer).
- Obiettivo più consistente.
- Distribuzione dei tipi di obiettivo.

Apri Approfondimenti dal menu a scomparsa nell'elenco Obiettivi di preghiera.

## Scorciatoie da tastiera

Se usi una tastiera esterna:

- **Escape** — torna indietro.
- **Cmd + S** (iOS) o **Ctrl + S** (Android) — salva un obiettivo nel costruttore.
- **Cmd + E** (iOS) o **Ctrl + E** (Android) — copia un riepilogo negli appunti dalla schermata dettaglio o approfondimenti.

## Promemoria e giorni di grazia

Un obiettivo può ricordarti i giorni selezionati a un'ora scelta. I promemoria usano le notifiche locali del dispositivo e rispettano l'impostazione principale delle notifiche in **Impostazioni** → **Notifiche**.

I **giorni di grazia** proteggono una serie quando salti un giorno. Se imposti 1 o 2 giorni di grazia, la serie non si interrompe finché non salti quel numero di giorni programmati consecutivi.

## Suggerimenti

- Inizia con un solo obiettivo. È più facile costruire un'abitudine quando ti concentri.
- Usa i modelli per gli schemi comuni, poi personalizza obiettivo o programmazione.
- Metti in pausa un obiettivo quando viaggi o sei malato invece di eliminarlo: le serie si bloccano e riprendono al tuo ritorno.
- Gli obiettivi con check-in manuale funzionano per qualsiasi cosa Theodia non misuri automaticamente, come pregare per una persona o una famiglia specifica.
- Controlla Approfondimenti una volta a settimana per vedere quali obiettivi sono più facili e quali hanno bisogno di attenzione.
