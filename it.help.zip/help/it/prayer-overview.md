---
title: Panoramica della preghiera
level: beginner
categories: prayer
summary: Una rapida introduzione alla scheda Preghiera e alle sue sezioni principali.
---

# Panoramica della preghiera

La scheda **Preghiera** è uno spazio dedicato alla preghiera. Raccoglie liste, sessioni guidate, un diario, un timer, programmi di lettura lezionaria e preghiere fisse classiche.

## Le sezioni principali

- **Lista di preghiera** — tieni traccia di persone, situazioni e argomenti per cui preghi.
- **Diario** — annota riflessioni, risposte e pensieri nel tempo.
- **Genera preghiera** — chiedi a Teofilo di scrivere una preghiera da una richiesta o una voce di diario.
- **Credi e preghiere fisse** — preghiere classiche e credi della tradizione cristiana.
- **Lezionario** — programmi di lettura della Scrittura per la preghiera quotidiana o stagionale.
- **Preghiera guidata** — sessioni di preghiera audio-guidate con sintesi vocale.
- **Timer** — sessioni di preghiera a tempo con campane opzionali.
