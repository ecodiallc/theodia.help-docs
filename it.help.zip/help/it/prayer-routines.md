---
title: Routine
level: everyday
categories: [prayer]
summary: Costruisci un'abitudine quotidiana creando e completando routine di preghiera, lettura biblica, lettura devozionale, segnalibri, evidenziazioni e altro.
---

# Routine

Una **routine** è un elenco ordinato di passaggi. Pensala come una playlist per la tua vita spirituale: può includere preghiera, un passaggio biblico, un devozionale, una preghiera fissa come il Padre Nostro, silenzio, riflessione, le tue richieste di preghiera, segnalibri, evidenziazioni, inni e flashcard.

Le routine vivono nella propria scheda **Routine**. Quando la funzionalità Routine è abilitata, la scheda Routine è visibile in fondo all'app.

## Perché le routine sono importanti

- **Abitudini:** una routine trasforma momenti sparsi in una sessione coesa.
- **Flessibilità:** puoi creare routine per la preghiera del mattino, la lettura biblica serale, l'adorazione in famiglia, il diario di gratitudine, il ripasso di memorizzazione, o qualsiasi stagione.
- **Tutto in un unico posto:** preghiera, Scrittura, segnalibri, evidenziazioni e strumenti di studio possono fluire insieme in una sola routine.

## Avviare una routine

1. Tocca la scheda **Routine**.
2. Tocca la routine che vuoi eseguire.
3. Tocca **Avvia** per aprire l'esecutore della routine e procedere attraverso ogni passaggio.

## Costruire una routine

1. Nell'elenco **Routine**, tocca il pulsante **+**.
2. Dai un nome alla routine e una descrizione opzionale.
3. Tocca **Aggiungi passaggio** e scegli un tipo di passaggio:
   - **Passaggio** — leggi un passaggio biblico.
   - **Preghiera fissa** — un credo, preghiera o liturgia dalla libreria.
   - **Richieste di preghiera** — prega per le tue richieste attive.
   - **Silenzio / Riflessione / Preghiera libera** — spazio a tempo o aperto.
   - **Sessione guidata** — una sessione di preghiera con voce.
   - **Inno** — leggi o canta un inno.
   - **Flashcard** — ripassa le schede di memoria.
   - **Devozionale** — leggi una voce devozionale.
   - **Revisione segnalibri** — rivisita i segnalibri salvati.
   - **Revisione evidenziazioni** — rivedi i versetti evidenziati.
4. Riordina i passaggi toccando le frecce su/giù su ogni passaggio. Imposta una durata o un'etichetta, se vuoi.
5. Tocca **Salva**.

## Fissare una routine

Le routine fissate appaiono in cima all'elenco Routine.

1. Apri l'elenco **Routine**.
2. Tieni premuta una routine.
3. Tocca **Fissa in home**.

## Aggiungere qualcosa a una routine

Quasi tutto nell'app può diventare un passaggio di routine:

- **Lettore biblico:** tocca un versetto, poi il pulsante **+** e scegli una routine.
- **Segnalibri:** tieni premuto un segnalibro biblico, oppure tocca il pulsante **+**, e scegli una routine.
- **Preghiere fisse:** tocca il pulsante **+** su qualsiasi riga di preghiera fissa.
- **Richieste di preghiera:** tocca il pulsante **+** su una riga di richiesta.
- **Evidenziazioni:** scegli un passaggio di revisione evidenziazioni per rivisitare i versetti marcati.

Puoi inserire l'elemento all'inizio, alla fine, o dopo un passaggio specifico.

## Completare una routine

L'esecutore della routine ti guida attraverso ogni passaggio. Alcuni passaggi avanzano automaticamente; altri aspettano che tu tocchi **Successivo**. Alla fine vedi una schermata di celebrazione con opzioni per aggiungere la routine a una playlist o iniziarne un'altra.

Una spunta verde appare sulla scheda della routine per il resto della giornata per indicare che è stata completata.

## Eliminare o modificare una routine

- **Modifica:** apri l'elenco routine, tocca una routine, poi tocca **Modifica**.
- **Elimina:** tieni premuta una routine e tocca **Elimina**. Le routine integrate non possono essere eliminate, ma puoi nasconderle rimuovendole dalla home.

## Nota sulla privacy

Le routine e i loro dati restano sul tuo dispositivo. Statistiche e badge sono opzionali; per disabilitarli, vai a **Impostazioni** → **Preghiera** e disattiva le opzioni di tracciamento.
