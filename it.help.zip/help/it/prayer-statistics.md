---
title: Statistiche e serie di preghiera
level: everyday
categories: prayer
summary: Come funzionano le serie di preghiera e come disattivare statistiche e badge.
---

# Statistiche e serie di preghiera

La schermata **Statistiche** nella scheda Preghiera traccia la tua attività di preghiera e le serie quando **Statistiche preghiera** è abilitata in **Impostazioni** → **Preghiera**. È progettata per incoraggiare un'abitudine quotidiana di preghiera senza essere invadente.

## Cosa conta come attività

Le seguenti azioni vengono registrate come attività di preghiera:

- **Routine** di preghiera completate
- **Sessioni guidate** completate
- **Sessioni timer** completate
- Richieste di preghiera **pregate**
- **Preghiere fisse** lette
- Voci **lezionarie** lette
- **Voci di diario** aggiunte

Tutte queste appaiono nel riepilogo delle tue attività.

## Solo le routine estendono la serie

La tua **serie di preghiera** è il numero di giorni consecutivi in cui hai completato almeno una routine di preghiera.

- Completare una routine estende la serie.
- Altre attività di preghiera vengono tracciate, ma non estendono la serie da sole.
- Se salti un giorno, la serie si azzera.
- Completare più routine in un giorno conta comunque come un solo giorno di serie.

> **Suggerimento:** se vuoi costruire o mantenere una serie, fai delle routine il centro del tuo tempo quotidiano di preghiera.

## Cosa mostra la schermata Statistiche

- **Serie attuale** — giorni consecutivi con una routine completata.
- **Serie più lunga** — la tua serie migliore di sempre.
- **Riepilogo attività** — totali per questa settimana, questo mese e sempre.
- **Calendario** — vista mese per mese dei giorni con attività di preghiera.

## Badge

Quando **Mostra badge di preghiera** è abilitato, puoi ottenere achievement nascosti per traguardi di preghiera. I badge sono una funzionalità leggera a sorpresa, non un obbligo.

I badge richiedono che le Statistiche preghiera siano abilitate. Se le statistiche sono disattivate, anche i badge vengono nascosti.

## Come disabilitare statistiche e badge

Puoi disattivare queste funzionalità in qualsiasi momento:

1. Apri **Impostazioni** → **Preghiera**.
2. Disattiva **Abilita statistiche preghiera**.
3. Disattiva **Mostra badge di preghiera**.

Quando le statistiche sono disabilitate:

- Le serie non vengono più contate.
- La sezione Statistiche scompare dalla scheda Preghiera.
- I badge vengono nascosti.
- I dati di preghiera esistenti restano sul dispositivo; nulla viene eliminato.

Per riabilitare le statistiche in seguito, basta riattivare l'interruttore.
