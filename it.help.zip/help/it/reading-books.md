---
title: Lettura dei libri integrati
level: beginner
categories: [content, read]
summary: Come leggere i classici cristiani inclusi nell'app.
---

# Lettura dei libri integrati

Theodia include una piccola libreria di libri cristiani. Sono classici che puoi leggere sul tuo dispositivo.

## Come aprire la libreria

Tocca la scheda **Libri** in fondo allo schermo. Vedi un elenco dei libri nella tua libreria.

## Come leggere un libro

1. Tocca il titolo del libro.
2. Il libro si apre al primo capitolo.
3. Usa i pulsanti **Precedente** e **Successivo** in alto per spostarti tra i capitoli.

## Come saltare a un capitolo

Tocca il nome del capitolo in cima allo schermo. Appare un elenco di capitoli. Scegli un capitolo per andarci.

## Come cambiare la dimensione del carattere

Apri **Impostazioni** → **Aspetto** e scegli una dimensione del carattere. La dimensione del testo cambia in tutta l'app, inclusi i libri.

## Come aggiungere un segnalibro in un libro

Tocca l'icona **stella** in alto a destra. Il capitolo corrente viene salvato. Tocca la scheda **Segnalibri** per vedere le pagine salvate.

## Come ascoltare un libro

Tocca l'icona **Altoparlante** in alto a destra. L'app legge il capitolo ad alta voce. Tocca di nuovo per fermare.

## Quali libri sono disponibili?

La libreria include classici come:

- Il progresso del pellegrino
- L'imitazione di Cristo
- La pratica della presenza di Dio
- Il libro degli inni

L'elenco dei libri può crescere nel tempo. Gli aggiornamenti dell'app possono aggiungerne altri.

## Suggerimenti

- I libri sono memorizzati sul tuo dispositivo. Non serve internet.
- I libri non si sincronizzano nel cloud.
