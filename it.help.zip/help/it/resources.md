---
title: Trovare risorse su GitHub
level: everyday
categories: resources
summary: Cerca in tutti i repository GitHub conosciuti dall'app in una volta, poi installa ciò che trovi.
---

# Trovare risorse su GitHub

Theodia tiene un elenco di repository GitHub che pubblicano risorse — Bibbie, commentari, libri, devozionali, playlist, pacchetti di preghiera e altro. **Cerca repository GitHub** le cerca tutte in una volta, così non devi aprire ogni scheda e sfogliarle separatamente.

> La sezione GitHub delle Impostazioni è disponibile solo in **modalità Studioso**. Per attivarla, vai in **Impostazioni → Modalità utente → Studioso**.

## Come cercare

1. Apri **Impostazioni**.
2. Tocca **Cerca repository GitHub**.
3. Digita una parola nella casella di ricerca. L'app cerca quella parola nel **nome** e nella **descrizione** di ogni risorsa in ogni repository.

Alcune cose da sapere sulla ricerca:

- **Ogni parola deve corrispondere.** Cercando `morning evening` trovi solo le risorse il cui nome o la cui descrizione contiene *entrambe* le parole.
- **Le maiuscole non contano.** `Morning` e `morning` trovano le stesse risorse.
- **La corrispondenza migliore viene prima.** Una risorsa il cui nome *inizia* con la tua ricerca viene mostrata prima di una che la menziona solo nella descrizione.

## Filtri

Tocca la barra dei filtri sopra i risultati per restringere ulteriormente l'elenco. Ci sono due filtri e funzionano insieme:

- **Autore** — solo risorse di quell'autore.
- **Tradizione** — solo risorse di quella tradizione.

Tocca di nuovo un filtro per azzerarlo, oppure tocca **Cancella filtri** per azzerare entrambi.

## Installare da un risultato

Ogni risultato mostra il nome della risorsa, che tipo di risorsa è, chi l'ha creata e da quale repository proviene. A destra della riga c'è un solo pulsante:

- **Installa** — la risorsa non è ancora sul tuo dispositivo.
- **Aggiorna** — è disponibile una versione più recente. L'app chiede prima di confermare, perché l'aggiornamento rimuove la vecchia copia insieme a eventuali note, evidenziazioni o segnalibri che puntano ad essa.
- **Apri** — la risorsa è già installata; toccarla ti porta alla schermata in cui la usi.

Tocca **Aggiorna elenco** in alto per scaricare subito da GitHub l'elenco più recente. L'app aggiorna l'elenco da sola una volta al giorno, quindi un aggiornamento manuale serve solo quando sai che è stato pubblicato qualcosa di nuovo.

## Cercare senza connessione

L'app conserva una copia dell'elenco sul tuo dispositivo, quindi la ricerca funziona anche quando sei offline. Se l'app non riesce a raggiungere GitHub per aggiornare l'elenco, un banner in alto ti avvisa che stai vedendo i risultati memorizzati nella cache.

## Se una ricerca non trova nulla

- Prova una parola singola più corta.
- Controlla che nessun filtro **Autore** o **Tradizione** sia ancora attivo — il pulsante **Cancella filtri** appare ogni volta che lo è.
- Alcuni repository pubblicano le loro risorse in una lingua diversa da quella del nome della risorsa, quindi cercando una parola tradotta potresti non trovarle.
