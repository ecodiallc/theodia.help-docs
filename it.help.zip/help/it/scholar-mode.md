---
title: Modalità Studioso
level: advanced
categories: [layout, read, study]
summary: La modalità di studio più approfondita di Theodia, che sblocca commentari, lessici, riferimenti incrociati, strumenti IA e il Menu rapido.
---

# Modalità Studioso

> **Modalità:** la modalità Studioso è disponibile solo quando la modalità utente è impostata su **Studioso**. Cambia modalità in **Impostazioni** → **Modalità utente app**.

La modalità Studioso sblocca ogni strumento di studio in Theodia. Si basa sulla Modalità studio, quindi ottieni comunque il menu dei versetti, Bibbie parallele, segnalibri, evidenziazioni e note — più gli strumenti avanzati elencati sotto.

## Come aprire la modalità Studioso

La modalità Studioso non è una schermata separata. È un insieme di strumenti extra che appaiono dentro il lettore e la navigazione esistenti quando la modalità utente è impostata su Studioso.

1. Apri **Impostazioni**.
2. Tocca **Modalità utente app**.
3. Scegli **Studioso**.

La modifica ha effetto immediato. I menu e i pulsanti precedentemente nascosti ora appaiono.

## Strumenti extra nel lettore

Quando apri un capitolo in [Modalità studio](theodia://help/study-mode), la modalità Studioso aggiunge questi strumenti al menu dei versetti:

- **Commento IA** (◈) — chiedi all'assistente IA di scrivere una nota di studio per questo versetto. (Non disponibile in tutte le regioni.)
- **Info parola** (?) — apri una voce di lessico per la parola ebraica o greca originale dietro il versetto. Vedi la guida [Commentari e lessici](theodia://help/commentaries-and-lexicons).
- **Dizionario** (📖) — cerca parole bibliche generali nelle risorse dizionario che hai installato. Vedi la guida [Dizionario biblico](theodia://help/dictionary).

Questi strumenti richiedono risorse installate (commentari, lessici, file dizionario). Se uno strumento è disattivato o mostra "non trovato", apri **Impostazioni** → **Gestisci risorse** e aggiungi la risorsa necessaria.

## Navigazione extra

### Scheda aggiuntiva nella barra degli strumenti

La barra degli strumenti in basso guadagna una scheda extra:

- 💻 **IA** — apre l'assistente IA (solo se hai attivato l'IA nelle Impostazioni). Questa scheda si trova a destra di Note.

### Voci extra nel menu principale

Il menu principale include una voce **Assistente IA** nelle stesse condizioni.

## Il Menu rapido

La modalità Studioso abilita il **Menu rapido**, un modo veloce per saltare ai versetti recenti, eseguire comandi e cambiare layout biblici senza lasciare la schermata corrente. Vedi la guida [Menu rapido](theodia://help/launcher-menu) per sapere come usarlo.

## Quando usare la modalità Studioso

- Vuoi l'assistente IA, i commentari o le ricerche sulle lingue originali mentre leggi.
- Vuoi il Menu rapido per una navigazione rapida dei versetti e la chat IA.
- Stai studiando un passaggio in profondità e hai bisogno di ogni strumento a portata di tap.

## Passare a una modalità più leggera

Se vuoi un lettore più semplice senza strumenti avanzati, passa a **Standard** in **Impostazioni** → **Modalità utente app**. La modalità Standard mantiene segnalibri, evidenziazioni, note e Modalità studio, ma nasconde IA, commentari, lessici e Menu rapido.

Se vuoi l'esperienza di lettura più pulita possibile, apri un capitolo in [Messa a fuoco](theodia://help/focus-mode).

I tuoi segnalibri, evidenziazioni e note non vengono mai eliminati quando cambi modalità; vengono semplicemente nascosti finché non torni a una modalità che li supporta.

## Aiuto e domande

Se uno strumento manca o mostra un errore, consulta la guida [Problemi comuni](theodia://help/common-problems). Se sei nuovo su Theodia, la guida [Leggere il tuo primo capitolo](theodia://help/first-read) ti guida passo dopo passo alle basi.
