---
title: Ricerca nella Bibbia
level: everyday
categories: [study, read]
summary: Come trovare versetti per parola, frase o riferimento.
---

# Ricerca nella Bibbia

La barra di ricerca ti aiuta a trovare i versetti velocemente. Puoi cercare per parola, frase o riferimento biblico.

## Come avviare una ricerca

1. Tocca la scheda **Cerca** in fondo allo schermo.
2. Scrivi ciò che vuoi trovare.
3. Tocca **Cerca** sulla tastiera.

I risultati appaiono come elenco di versetti. Ogni risultato mostra libro, capitolo e versetto, più il testo del versetto.

## Cercare combinazioni di parole

Quando scrivi più di una parola, come `amore gioia`, l'app trova versetti che contengono **entrambe** le parole. È una ricerca **AND** — tutte le parole devono apparire nel versetto. Non usa la logica **OR** (versetti con una sola parola qualsiasi).

Per cercare versetti che contengono una parola o l'altra, devi usare la parola chiave `OR` esplicitamente: `amore OR gioia`.

## Cercare per parola

Scrivi una sola parola, come `amore` o `misericordia`. L'app mostra ogni versetto della Bibbia che contiene quella parola.

## Cercare per frase

Scrivi due o tre parole tra virgolette, come `"non temere"`. L'app mostra i versetti che contengono esattamente quella frase.

## Filtrare i risultati

Dopo una ricerca, i risultati sono filtrati per le traduzioni bibliche installate. Per restringere ulteriormente, apri la scheda **Bibbia** e guarda una traduzione specifica: le ricerche vengono eseguite sulle traduzioni che hai.

## Suggerimenti per ricerche migliori

- Usa parole brevi. La ricerca di `amore` trova più versetti di `amando`.
- Le virgolette attorno a una frase rendono la ricerca esatta.
- L'app cerca solo nelle traduzioni bibliche che hai installato.
- Per saltare a un versetto specifico per riferimento (ad esempio `Giovanni 3:16`), usa la casella **Comando rapido** nella schermata principale invece della scheda Cerca.

## Cronologia ricerche

L'app ricorda le tue ricerche più recenti. Quando apri la scheda **Cerca**, l'elenco mostra in alto le ricerche recenti. Tocca una per eseguirla di nuovo. Per cancellare l'elenco, tocca **Cancella tutto** in cima alle ricerche recenti.
