---
title: Modalità Studio
level: everyday
categories: [layout, read]
summary: Il lettore biblico completo di Theodia, con strumenti di studio come commenti, riferimenti incrociati, lessici e note.
---

# Modalità Studio

> **Modalità:** la modalità Studio è disponibile in modalità **Standard** e **Studioso**. La modalità Lettura apre i capitoli in Messa a fuoco. Puoi cambiare modalità in **Impostazioni** → **Modalità utente app**.

La Modalità Studio è il lettore biblico principale di Theodia. Ha tutti gli strumenti di studio integrati: commenti, riferimenti incrociati, ricerche di parole, traduzioni parallele, note e altro.

Messa a fuoco è un lettore più semplice senza strumenti di studio. Vedi la guida [Messa a fuoco](theodia://help/focus-mode) se vuoi solo testo pulito. Questa guida è per la modalità Studio.

## Come aprire la Modalità Studio

Ci sono diversi modi per aprire un capitolo in modalità Studio:

- Tocca la scheda **Bibbia** in fondo allo schermo. Scegli una traduzione, un libro e un capitolo.
- Tocca un versetto nei risultati di **Cerca**.
- Tocca un segnalibro dalla scheda **Segnalibri**.
- Dalla Messa a fuoco, tocca il pulsante 📖 in cima allo schermo per passare alla modalità Studio.

## Leggere il capitolo

Il capitolo si apre con i versetti elencati in ordine. In cima allo schermo ci sono pulsanti per le azioni più comuni. In fondo allo schermo c'è una barra di stato.

- **Scorri a sinistra** per andare al capitolo successivo.
- **Scorri a destra** per andare al capitolo precedente.
- **Tocca un versetto** per aprire il menu dei versetti con gli strumenti di studio (vedi sotto).
- **Tocca un numero di Strong in un versetto** (ad esempio G1234 o H1234) per aprire una rapida ricerca lessicale per quella parola.

Se hai attivata una traduzione parallela, una seconda copia del capitolo appare sotto quella principale, nella traduzione scelta. Vedi **Leggere due traduzioni contemporaneamente** più sotto.

## Il menu dei versetti

Quando tocchi un versetto, si apre un menu con il titolo "Libro Capitolo:Versetto". Gli strumenti che vedi dipendono dalla tua modalità utente.

### Strumenti in modalità Standard e Studioso

- **Segnalibro** (★) — salva il versetto per trovarlo di nuovo. Tocca di nuovo per rimuovere il segnalibro. Il primo tocco lo aggiunge. Vedi la guida [Segnalibri](theodia://help/bookmarks).
- **Evidenzia** (□) — colora il versetto per farlo risaltare. Tocca per aprire il selettore colore. Tocca lo stesso colore di nuovo per rimuovere l'evidenziazione. Vedi la guida [Evidenziazioni](theodia://help/highlights).
- **Leggi** (🔊) — fa leggere il versetto ad alta voce con la voce di sintesi vocale del dispositivo. Non viene mostrato per le Bibbie interlineari. Vedi la guida [Lettura ad alta voce](theodia://help/tts) per sapere come usarlo e come scegliere una voce.
- **Copia** (⎘) — copia il testo del versetto negli appunti per incollarlo ovunque.
- **Confronta** (⇄) — apre un pannello che mostra lo stesso versetto in ogni traduzione installata. Tocca una traduzione nel pannello per leggere il versetto in quella traduzione. Vedi la guida [Confrontare traduzioni](theodia://help/compare-translations).
- **Riferimenti incrociati** (↗) — apre un elenco di versetti correlati dal database dei riferimenti incrociati. Vedi la guida [Riferimenti incrociati](theodia://help/cross-references).
- **Aggiungi/Modifica nota biblica** (✎) — scrivi una tua nota privata legata al versetto. Vedi la guida [Scrivere note](theodia://help/notes).

### Strumenti solo in modalità Studioso

- **Commento IA** (◈) — chiedi all'assistente IA di scrivere una nota di studio per questo versetto. (Non disponibile in tutte le regioni.)
- **Info parola** (?) — apri una voce di lessico per la parola ebraica o greca originale dietro il versetto. Vedi la guida [Commentari e lessici](theodia://help/commentaries-and-lexicons).
- **Dizionario** (📖) — cerca parole bibliche generali nelle risorse dizionario che hai installato. Vedi la guida [Dizionario biblico](theodia://help/dictionary).

Alcuni strumenti richiedono risorse extra installate. Se uno strumento è disattivato o mostra "non trovato", apri **Impostazioni** → **Gestisci risorse** e aggiungi la risorsa necessaria.

## Pulsanti in cima allo schermo

Sopra il testo del capitolo c'è una riga di icone. Queste sono le azioni rapide:

- **Versione biblica** — tocca il nome della traduzione (ad esempio "KJV") per passare a una traduzione diversa.
- **Libro** — tocca il nome del libro per saltare a un altro libro.
- **Capitolo** — tocca il numero del capitolo per saltare a un altro capitolo.
- **Apri in IA** (🤖) — invia il capitolo corrente all'assistente IA con la tua domanda. (Solo modalità Studioso.)
- **Messa a fuoco** (📖) — passa alla Messa a fuoco per una lettura pulita.
- **Bibbie parallele** (🔵 / ⚪) — tocca per attivare o disattivare le traduzioni parallele. Quando abilitate, lo stesso capitolo viene mostrato nelle traduzioni parallele scelte sotto il testo principale. Quando disabilitate, viene mostrata solo la traduzione principale. Vedi **Leggere più traduzioni contemporaneamente** più sotto.
- **Leggi** — fa leggere l'intero capitolo ad alta voce. Vedi la guida [Lettura ad alta voce](theodia://help/tts).
- **Altro** — apre azioni extra sul capitolo (nota biblica del capitolo, commento al capitolo, condividi e così via).

## Leggere più traduzioni contemporaneamente

Puoi mostrare fino a quattro traduzioni extra accanto a quella principale. Questa è la **vista parallela**.

1. Apri **Impostazioni**.
2. Attiva **Bibbia parallela**.
3. Tocca **Aggiungi Bibbia parallela** e scegli una traduzione.
4. Ripeti per aggiungerne altre. Puoi avere fino a quattro traduzioni parallele.

Quando la vista parallela è attiva, ogni versetto del capitolo mostra la traduzione principale per primo, seguita dallo stesso versetto in ogni traduzione parallela. Questo rende facile confrontare come diversi traduttori gestiscono un versetto difficile senza lasciare il capitolo.

Puoi salvare la tua configurazione parallela corrente come **preimpostazione**. Tocca il pulsante salva accanto alle traduzioni selezionate, dagli un nome, e diventa un'opzione di cambio rapido. Tocca una preimpostazione in seguito per caricare istantaneamente quella combinazione. Tieni premuta una preimpostazione per eliminarla.

Puoi anche confrontare un solo versetto alla volta con lo strumento **Confronta** (⇄) nel menu dei versetti. Quello apre un pannello che mostra il versetto in ogni traduzione installata.

## Sottotitoli

Alcune traduzioni hanno titoli di sezione integrati (ad esempio "Il sermone sulla montagna"). Se la tua traduzione li ha, puoi mostrarli o nasconderli con l'impostazione **Mostra titoli delle sezioni** in **Impostazioni**. I sottotitoli appaiono come piccoli titoli grigi tra i versetti.

## La nota al capitolo

Una nota al capitolo è una singola nota allegata all'intero capitolo, non a un singolo versetto. È utile per un pensiero generale sul capitolo.

Per aprire la nota al capitolo:

1. Tocca il pulsante **Altro** in cima allo schermo.
2. Tocca **Nota capitolo**.
3. Scrivi la tua nota. Tocca **Salva**.

La nota al capitolo viene salvata con il capitolo. Appare ogni volta che apri quel capitolo.

## Evidenziazioni di ricerca

Se arrivi al capitolo da una ricerca, le parole cercate sono evidenziate in giallo nel testo del versetto. Questo rende facile capire perché un versetto corrispondeva.

Puoi anche rieseguire una ricerca su un capitolo che stai leggendo. Apri la scheda **Cerca** e inserisci una parola. I risultati ti permettono di tornare direttamente al capitolo con le corrispondenze evidenziate.

Le Bibbie interlineari (MIB — Marvel Interlinear Bible — e OHGB) si aprono sempre in modalità Studio perché hanno bisogno del layout a livello di parola.

## Passare alla Messa a fuoco per un singolo capitolo

Da qualsiasi capitolo in modalità Studio, tocca il pulsante 📖 in cima. Lo stesso capitolo si apre in Messa a fuoco con tutti i menu nascosti. Tocca il pulsante 📖 nella barra in basso per tornare alla modalità Studio.

## Quando usare la Modalità Studio

La Modalità Studio è la scelta giusta quando vuoi:

- **Leggere e studiare contemporaneamente.** Tutti gli strumenti sono a un tap di distanza.
- **Cercare una parola che non conosci.** Tocca un numero di Strong nel versetto per una rapida voce lessicale.
- **Confrontare traduzioni.** Usa lo strumento Confronta nel menu dei versetti o attiva la vista parallela.
- **Vedere come un versetto si collega al resto della Bibbia.** Usa Riferimenti incrociati.
- **Prendere note mentre leggi.** Il menu dei versetti ha un'opzione rapida "Aggiungi nota".

Per lunghe letture senza distrazioni, passa alla Messa a fuoco.

## Passare alla Messa a fuoco

Da qualsiasi capitolo in modalità Studio, tocca il pulsante 📖 in cima. Lo stesso capitolo si apre in [Messa a fuoco](theodia://help/focus-mode) con menu e strumenti di studio nascosti. Tocca il pulsante 📖 nella barra in basso per tornare alla modalità Studio. Per una descrizione completa di ciò che fa la Messa a fuoco, vedi la guida [Messa a fuoco](theodia://help/focus-mode).

## Aiuto e domande

Se uno strumento manca o mostra un errore, consulta la guida [Problemi comuni](theodia://help/common-problems). Se sei nuovo su Theodia, la guida [Leggere il tuo primo capitolo](theodia://help/first-read) ti guida passo dopo passo alle basi.
