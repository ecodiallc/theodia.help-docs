---
title: Funzionalità tablet
level: everyday
categories: [layout, tablet]
summary: Come il layout di Theodia si adatta a tablet e schermi più grandi, con viste divise, pannelli laterali e modalità di lettura a due riquadri.
---

# 📱 Funzionalità tablet

Theodia è progettato per sfruttare gli schermi più grandi dei tablet. Su un tablet (o su qualsiasi dispositivo più largo di circa 700 pixel), l'app passa automaticamente a un layout a due colonne in molti punti.

> **Modalità:** le funzionalità descritte qui appaiono solo se la tua modalità utente attuale le supporta. Ad esempio, i pannelli laterali dei commenti e la chat IA sono disponibili solo in modalità Studioso. Le viste divise di segnalibri, evidenziazioni e note richiedono la modalità Standard o Studioso. La modalità Messa a fuoco mostra solo lettura pulita a colonna singola. Puoi cambiare modalità in **Impostazioni** → **Modalità utente app**.

## Menu dei versetti nel lettore

Quando tocchi un numero di versetto (o tieni premuto il testo del versetto), il **menu dei versetti** appare come una **scheda centrata** sopra uno sfondo scuro.

- I pulsanti **Copia** e **Condividi** sono sempre visibili in cima al menu.
- **Segnalibri** ed **Evidenziazioni** sono mostrati con il loro stato attuale.
- **Commento**, **Dizionario** e **Confronta** si aprono dal menu. Su tablet questi strumenti possono apparire in un pannello laterale o in una scheda larga una volta selezionati.
- Tocca lo sfondo o la freccia di chiusura per chiudere il menu.

## Pannello Commento al versetto

Lo strumento **Commento** apre un **pannello laterale** dedicato su tablet:

- Il testo del commento appare accanto al testo biblico.
- Puoi scorrere il commento indipendentemente dalla Bibbia.
- Tocca la **X** o scorri via per chiudere.
- Un'**icona libro** in cima al pannello ti permette di cambiare fonte del commentario.
- Un'**icona capitolo** ti permette di visualizzare il commento a livello di capitolo.

Su telefono, il commento si apre come modale a schermo intero.

## Commento al capitolo

Il **Commento al capitolo** si accede dal pulsante **Altro** in cima allo schermo, non dal menu dei versetti. Su tablet si apre come pannello laterale proprio come il Commento al versetto, così puoi leggere il commento e il testo biblico insieme.

## Scheda Confronta

La scheda **Confronta** (nel menu dei versetti) si apre come **pannello laterale** su tablet. Mostra il versetto selezionato in ogni versione parallela abilitata. Puoi toccare qualsiasi versione per saltare a quel passaggio nel lettore.

## Pop-up Dizionario / Strong

Lo strumento **Dizionario** (menu dei versetti → Dizionario) si apre come una scheda larga su tablet. Mostra la parola greca o ebraica, la sua traslitterazione, la definizione e il numero di Strong. Tocca il pulsante **Concordanza** per vedere ogni occorrenza di quella parola nella Bibbia.

## Tocca una parola per aprire il suo lessico

Nel pannello **Info parola** su tablet, ogni carta di parola che ha un numero di Strong è tappabile. Tocca la carta per aprire direttamente il pannello **Lessico** per quella parola. Il pannello Lessico sostituisce il pannello Info parola, così puoi continuare a studiare senza chiudere il lettore.

Su telefono, le carte Info parola non sono tappabili perché lo schermo è troppo piccolo per due pannelli.

## Bibbie parallele affiancate

Nelle Impostazioni, tocca **Bibbie parallele** e scegli fino a tre versioni. Su tablet, le versioni appaiono come **riquadri verticali** uno accanto all'altro:

- Ogni riquadro scorre indipendentemente.
- Puoi toccare un numero di versetto per aprire un pannello laterale con gli strumenti.
- La scheda **Confronta** mostra tutti i versetti selezionati in un unico posto.
- Tocca la **X** su un riquadro per chiuderlo e tornare alla vista a colonna singola.
- Tocca l'icona **Bibbie parallele** (🔵 / ⚪) nella barra delle icone in alto per attivare o disattivare la vista parallela senza aprire le Impostazioni.

Su telefono, le versioni parallele sono mostrate una sotto l'altra (verticalmente) invece che affiancate. La stessa icona di attivazione funziona anche sui telefoni.

## Vista divisa per Segnalibri ed Evidenziazioni

Su tablet, le schede **Segnalibri** ed **Evidenziazioni** usano un layout master-detail:

- **Lato sinistro** — l'elenco dei segnalibri o delle evidenziazioni.
- **Lato destro** — toccando un elemento si apre un riquadro di anteprima con il testo del versetto o del passaggio.

Puoi scorrere gli elementi salvati e previsualizzarli senza lasciare la scheda. Su telefono, toccando un elemento si naviga alla schermata del lettore.

## Vista divisa per Note

La scheda **Note** su tablet mostra l'elenco delle note a sinistra e la nota selezionata a destra. Toccando una nota si apre un pannello laterale, così puoi scorrere diverse note di seguito senza lasciare l'elenco. Anche la creazione o la modifica di una nota usa un pannello laterale.

## Vista divisa per Ricerca

Su tablet, la scheda **Cerca** mostra il modulo di ricerca a sinistra e i risultati a destra non appena esegui una ricerca. Puoi affinare la query e vedere i risultati aggiornarsi senza cambiare schermata. Su telefono, i risultati della ricerca si aprono su una schermata separata.

## Barra laterale delle categorie delle Impostazioni

La schermata **Impostazioni** su tablet mostra l'elenco delle categorie a sinistra (IA, Aspetto, Backup, Bibbie, ecc.). Tocca una categoria per saltare direttamente alle sue impostazioni a destra. Solo la categoria selezionata è espansa, quindi non devi mai scorrere l'intera lista delle impostazioni.

## Navigazione biblica su tablet

Le schermate **Elenco Bibbie**, **Libri biblici** e **Capitoli biblici** restano a colonna singola su tablet, ma usano target tattili più grandi, griglie più larghe e padding più generoso, così i contenuti sono più facili da leggere e toccare. Non usano un layout diviso perché ogni passaggio ha bisogno della larghezza piena per mostrare chiaramente il suo elenco o la sua griglia.

## Orizzontale e verticale

La rotazione del tablet adatta automaticamente il layout. In **orizzontale**, i pannelli laterali hanno molto spazio. In **verticale**, i pannelli diventano più stretti ma restano accanto al testo.

## Chat IA sul versetto selezionato

La chat **IA** si apre nel pannello laterale del menu dei versetti. Mostra un'interfaccia di conversazione dove puoi fare domande sul versetto selezionato. La risposta dell'IA appare nel pannello, e puoi continuare la conversazione senza lasciare il lettore.

## Barra laterale delle conversazioni nella schermata IA

Nella scheda **IA** su tablet, l'elenco delle conversazioni è sempre visibile come barra laterale persistente a sinistra. Puoi passare da una chat all'altra senza aprire un menu. Il pulsante **Nuova chat** è sempre visibile. Su telefono, l'elenco delle conversazioni è un cassetto a comparsa.

## Cosa resta uguale

Non tutte le schermate si dividono in due riquadri. Le seguenti schermate restano a colonna singola su tablet:

- **Elenco Bibbie** — elenco delle versioni bibliche (larghezza piena)
- **Libri biblici** — griglia dei libri e sezioni (larghezza piena)
- **Capitoli biblici** — griglia dei capitoli (larghezza piena)
- **Impostazioni** — pagine delle singole impostazioni (larghezza piena)
- **Aiuto** — articoli di aiuto (larghezza piena)

## Riepilogo

Su tablet ottieni:

- **Bibbie parallele** in riquadri verticali affiancati
- **Commento** in pannelli laterali persistenti
- **Confronta** e **Dizionario** in schede larghe
- **Lessico** dal tocco su qualsiasi carta Info parola
- **Segnalibri, Evidenziazioni, Note, Devozionali, Libri, Impostazioni** in viste master-detail
- **Ricerca** con risultati in linea accanto al modulo di ricerca
- **Orizzontale** e **verticale** entrambi supportati con adattamenti automatici del layout

Su telefono, tutto usa la tradizionale navigazione a colonna singola con drill-down. L'app rileva la larghezza dello schermo all'avvio e sceglie il layout giusto automaticamente.
