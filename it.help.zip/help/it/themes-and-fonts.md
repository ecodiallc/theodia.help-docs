---
title: Cambiare tema e carattere
level: everyday
categories: settings
summary: Come cambiare l'aspetto dell'app.
---

# Cambiare tema e carattere

Theodia ti permette di cambiare l'aspetto dell'app. Puoi scegliere un tema (chiaro o scuro) e una dimensione del carattere.

## Come aprire le impostazioni di Aspetto

1. Apri **Impostazioni**.
2. Tocca **Aspetto**.

## Come cambiare tema

Nella sezione **Aspetto** vedi due pulsanti del tema:

- **Predefinito** — sfondo chiaro con testo scuro. Buono per il giorno.
- **Scuro** — sfondo scuro con testo chiaro. Buono per la notte e risparmia batteria.

Tocca un tema per applicarlo. La modifica è istantanea.

## Come cambiare la dimensione del carattere

Nella sezione **Aspetto**, tocca uno dei pulsanti delle dimensioni: **---**, **--**, **-**, **Normale**, **+**, **++**, **+++**. Il testo diventa più piccolo o più grande in tutta l'app. Scegli la dimensione più comoda da leggere.

## Suggerimenti

- Il tema scuro risparmia batteria sui telefoni con schermo OLED.
- Se il testo è troppo piccolo da leggere, aumenta la dimensione del carattere nell'app, non nel dispositivo. L'impostazione dell'app è più precisa.
- Per lunghe letture, prova il tema scuro e un carattere più grande.
- [Attiva il tema deserto](theodia://unlock-desert)
