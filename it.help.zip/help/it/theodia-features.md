---
title: Funzionalità di Theodia
level: beginner
categories: welcome
summary: Una rapida panoramica di ciò che rende speciale Theodia e di come ti aiuta a studiare la Bibbia.
---

# Funzionalità di Theodia

Theodia è costruito per essere un compagno completo di studio biblico. Ecco cosa lo distingue.

## Offline First

Tutto funziona senza internet. Bibbie, commentari, lessici, libri e devozionali sono memorizzati sul tuo dispositivo. Puoi leggere, cercare e studiare ovunque — in aereo, in una zona remota, o in qualsiasi posto senza segnale.

## Orientato alla privacy

I tuoi dati restano con te. Note, evidenziazioni, segnalibri e cronologia di lettura sono memorizzati localmente sul dispositivo. Non serve un account, e nulla viene inviato a un server a meno che tu non scelga di usare l'opzionale assistente IA.

## Supporto tablet

Theodia è progettato sia per telefoni che per tablet. Su schermi più grandi hai più spazio per leggere, viste parallele della Bibbia e un layout che sfrutta lo spazio extra.

## Risorse installabili

Non sei limitato a ciò che viene fornito con l'app. Puoi aggiungere altre versioni bibliche, commentari, lessici, libri e devozionali. Le risorse sono disponibili dalla pagina GitHub del progetto e possono essere installate direttamente nell'app.

## Assistente IA

L'opzionale assistente IA ti aiuta a capire i versetti, spiegare il contesto e rispondere alle domande. È attivo solo se lo accendi. Per default si connette a un modello remoto che fornisci tu tramite endpoint e chiave API. La prima volta che usi l'IA, l'app chiede il tuo permesso e mostra esattamente cosa viene inviato.

## Lettura parallela della Bibbia

Leggi fino a quattro versioni bibliche contemporaneamente. Quando apri un capitolo, la tua traduzione principale appare per prima, e ogni versetto è seguito dallo stesso versetto nelle traduzioni parallele scelte. Confronta le formulazioni, studia le differenze e ottieni un quadro più completo del testo. Salva le tue combinazioni preferite come preimpostazioni e passa da una all'altra rapidamente.

## Ricerca full-text

Cerca in qualsiasi versione biblica. Cerca parole, frasi o corrispondenze parziali. Puoi anche limitare la ricerca a un intervallo di libri.

## Riferimenti incrociati

Tocca un riferimento biblico per saltare direttamente a quel passaggio. I riferimenti incrociati sono integrati e funzionano in tutta la Bibbia.

## Lessico e numeri di Strong

Tocca un numero di Strong per vedere la definizione originale in greco o ebraico. Le voci di lessico sono incluse per uno studio più approfondito delle parole.

## Segnalibri ed evidenziazioni

Salva i versetti con i segnalibri e marcali con i colori. Tutto è memorizzato localmente e persiste tra le sessioni.

## Note

Scrivi i tuoi pensieri accanto a qualsiasi versetto. Le note sono legate al versetto e facili da trovare in seguito.

## Devozionale quotidiano

Inizia la giornata con una breve lettura devozionale. L'app include devozionali che si aprono automaticamente alla voce di oggi.

## Libri cristiani

Leggi classici della letteratura cristiana dentro l'app. I libri sono formattati per una lettura agevole e includono un sommario per una rapida navigazione.

## Più lingue

Theodia supporta molte lingue sia per l'interfaccia dell'app che per i contenuti biblici. Cambia lingua nelle impostazioni per studiare nella lingua che preferisci.

## Modalità scura e temi

Scegli tra modalità chiara o scura, o seleziona un tema che preferisci. Il comfort di lettura conta, soprattutto con poca luce.

## Backup dei dati

Fai il backup delle tue note, segnalibri ed evidenziazioni. Tieni i tuoi dati al sicuro e trasferiscili su un nuovo dispositivo quando serve.

## Niente pubblicità, niente distrazioni

Theodia è costruito per la concentrazione. Non ci sono pubblicità, pop-up o interruzioni. Solo il testo e i tuoi strumenti di studio.
