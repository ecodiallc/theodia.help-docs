---
title: Theoscript
level: everyday
categories: theoscript
summary: Automatizza lettura biblica, sintesi vocale, segnalibri e altro con semplici comandi Theoscript.
---

# Theoscript

I **Theoscript** sono piccoli script che automatizzano cose dentro Theodia. Uno script può leggere un passaggio ad alta voce, aprire un capitolo, impostare un segnalibro, mostrare un messaggio, eseguire un altro comando e altro ancora. Sono un modo rapido per creare scorciatoie personali o piccoli aiuti devozionali senza uscire dall'app.

## Dove vivono i Theoscript

Apri **Theoscript** dalla schermata principale o dal menu principale. La schermata appare solo quando esiste almeno un Theoscript.

La libreria mostra:

- **Script** — ogni script che hai creato o importato.
- **Categorie** — cartelle opzionali che raggruppano script correlati.

Tocca uno script per eseguirlo. Tieni premuto uno script per modificarlo, duplicarlo o eliminarlo.

## Creare un nuovo script

1. Vai su **Theoscript**.
2. Tocca **+ Aggiungi script**.
3. Dai un nome allo script.
4. Scrivi i comandi nel campo **Contenuto script**.
5. Tocca **Salva**.

Ogni comando va su una riga propria. Indentare le righe dentro un blocco con due spazi.

## Comandi comuni

| Comando                | Cosa fa                                  | Esempio                                       |
| ---------------------- | ---------------------------------------- | --------------------------------------------- |
| `speak`                | Legge testo o un passaggio ad alta voce  | `speak "Buongiorno"` oppure `speak John 3:16` |
| `open`, `read`, `show` | Apre un passaggio nel lettore            | `open Psalm 23`                               |
| `bookmark`             | Salva il passaggio corrente nei segnalibri | `bookmark`                                    |
| `highlight`            | Evidenzia il versetto corrente           | `highlight yellow`                            |
| `message`              | Mostra un messaggio popup                | `message "Lettura terminata"`                 |
| `set`                  | Cambia un'impostazione o un valore       | `set theme dark`                              |
| `return`               | Interrompe lo script in anticipo         | `return`                                      |
| `with playlist`        | Aggiunge brani a una playlist            | `with playlist "Morning" track John 3:16 end` |
| `start playlist`       | Riproduce una playlist                   | `start playlist "Morning"`                    |
| `with note`            | Crea una nota                            | `with note "John 3:16" "My thoughts" end`     |

## Controllo di flusso

Usa `if` per eseguire comandi solo quando una condizione è vera:

```text
if chapter == 1 {
  message "Inizia un nuovo libro!"
}
```

Usa `repeat` per ripetere un blocco di comandi:

```text
repeat 3 {
  speak "Pace a te"
}
```

Usa `for` per ciclare su un elenco:

```text
for $ref in ["John 3:16", "Psalm 23:1", "Romans 8:28"] {
  open $ref
  speak $ref
}
```

Usa `function` e `call` per riutilizzare blocchi di codice:

```text
function greet $name {
  message "Ciao, " + $name
}
call greet "friend"
```

## Variabili

Memorizza un valore in una variabile con `let`:

```text
let $name = "Teofilo"
message "Benvenuto, " + $name
```

Le stringhe letterali a destra dell'uguale devono essere racchiuse tra virgolette singole o doppie. Questo evita di confondere un valore letterale con un comando o un nome di variabile. Numeri, variabili ed espressioni di comando non hanno bisogno di virgolette:

```text
let $count = 42
let $text = $last.passageText
let $words = count words in $text
let $greeting = "Ciao, " + $name
```

Le variabili sono utili dentro cicli, funzioni e definizioni di playlist.

## Script di esempio

### Saluto e un versetto

```text
speak "Buongiorno. Ecco il tuo versetto per oggi."
open John 3:16
speak John 3:16
```

### Tre versetti preferiti nei segnalibri

```text
open John 3:16
bookmark
open Psalm 23:1
bookmark
open Romans 8:28
bookmark
message "Preferiti salvati."
```

### Costruire una playlist parlata

```text
with playlist "Commute" {
  track John 3:16
  track Psalm 23
  track Romans 8:28
}
start playlist "Commute"
```

### Messaggio condizionale

```text
open Genesis 1:1
if book == "Genesis" {
  message "In principio..."
}
```

## Organizzare gli script

Tocca **Gestisci categorie** per creare categorie. Quando modifichi uno script, scegli la categoria in cui metterlo. Le categorie aiutano a tenere separati script personali, di esempio e vocali.

## Esportare e importare

Tocca il menu nella libreria Theoscript per:

- **Esporta Theoscript** — salva tutti gli script in un file.
- **Esporta questa categoria** — salva solo la categoria selezionata.
- **Importa Theoscript** — carica un file precedentemente esportato.

I file esportati sono testo semplice e possono essere condivisi con altri utenti di Theodia.

## Eseguire script dai Comandi

I Theoscript possono anche essere eseguiti per nome dal **Menu rapido** o chiedendoli con i Comandi. Per esempio, dire o scrivere `run My Morning Script` troverà ed eseguirà lo script chiamato _My Morning Script_, se esiste.

## Risoluzione dei problemi

- **Non succede nulla quando tocco Esegui.** Verifica che il contenuto dello script non sia vuoto e che ogni comando sia scritto correttamente.
- **Speak non legge nulla.** Assicurati che un passaggio sia aperto, oppure passa del testo tra virgolette direttamente a `speak`.
- **Un comando è evidenziato con un errore.** I Theoscript mostrano errori quando un comando è sconosciuto o un riferimento non è valido. Modifica lo script e riprova.
