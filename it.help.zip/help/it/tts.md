---
title: Lettura ad alta voce (sintesi vocale)
level: everyday
categories: tts
summary: Fai leggere a Theodia la Bibbia o un devozionale ad alta voce. Come usarlo, come scegliere una voce e cosa fare quando tace.
---

# Lettura ad alta voce (sintesi vocale)

> **Modalità:** la sintesi vocale è disponibile in modalità **Standard** e **Studioso**. La modalità Messa a fuoco è solo per lettura pulita senza distrazioni. Puoi cambiare modalità in **Impostazioni** → **Modalità utente app**.

Theodia può leggere il testo ad alta voce usando la voce di sintesi vocale (TTS) del tuo dispositivo. Puoi ascoltare un singolo versetto, un intero capitolo o un devozionale. È utile per lettura hands-free, ascoltare mentre cammini o viaggi, leggere insieme all'audio, o semplicemente dare riposo agli occhi.

## Dove si trova il pulsante di ascolto

Troverai un pulsante di ascolto in tre posti.

### 1. Nel menu dei versetti (singolo versetto)

Questo è il modo più veloce per ascoltare un versetto alla volta. Apri un capitolo in [Modalità studio](theodia://help/study-mode), tocca un versetto per aprire il menu dei versetti, poi tocca **Leggi** (🔊). La lettura inizia da quel versetto. Appare una piccola barra di controllo in fondo allo schermo con riproduci, pausa, riavvolgi, avanti veloce e un selettore vocale.

L'opzione Leggi non viene mostrata per le Bibbie interlineari (MIB — Marvel Interlinear Bible — e OHGB), poiché mostrano le parole in un layout diverso che non si legge naturalmente.

### 2. In cima a un capitolo (intero capitolo)

Quando leggi un capitolo, guarda la riga di icone in cima allo schermo. Tocca **Leggi** (🔊) per iniziare a leggere l'intero capitolo dall'inizio. Il pulsante diventa un pulsante di stop (⏹) mentre l'audio è in riproduzione. Toccalo di nuovo per fermare. Appare la stessa barra di controllo in fondo.

Puoi saltare a un versetto diverso, e il pulsante Leggi lì inizierà da quel versetto.

### 3. In un devozionale

Apri qualsiasi giorno del devozionale, poi tocca il pulsante **Leggi** (🔊) in cima alla lettura. L'intero testo devozionale viene letto ad alta voce, frase per frase. Una barra di controllo in fondo ti dà riproduci, pausa, riavvolgi e controlli vocali.

## Usare la barra di controllo

Mentre l'audio è in riproduzione, una piccola barra rimane visibile in fondo allo schermo. Ha sei controlli:

- ⏪ **Indietro** — torna indietro di un versetto (o di una frase in un devozionale)
- ⏸ **Pausa / ▶ Riprendi** — metti in pausa senza perdere il punto. Tocca di nuovo per continuare dallo stesso punto.
- ⏩ **Avanti veloce** — salta al versetto successivo (o alla frase successiva in un devozionale)
- 🎙 **Voce** — apre il selettore vocale senza lasciare il capitolo (vedi sotto)
- ⚙ **Opzioni** — apre il pannello delle opzioni estese (vedi sotto)
- **Stop** — tocca il pulsante 🔊 in cima allo schermo, oppure il ⏹ che lo sostituisce mentre l'audio è attivo, per fermare e chiudere la barra.

La barra di controllo si chiude quando il capitolo finisce o quando tocchi stop.

### Opzioni estese

Tocca ⚙ per espandere opzioni di riproduzione extra. Queste impostazioni durano solo per il capitolo corrente e si resettano quando cambi capitolo o fermi l'ascolto.

- ⏮ **Torna all'inizio** — salta al primo versetto dell'intervallo impostato.
- **Inizio** — scrivi un numero di versetto per impostare dove inizia la lettura.
- **Fine** — scrivi un numero di versetto per impostare dove finisce la lettura.
- **Tutto** — resetta l'intervallo all'intero capitolo.
- **()** — attiva o disattiva se il testo tra parentesi debba essere letto ad alta voce.
- 🔁 **Ripeti** — riavvia automaticamente dall'inizio dell'intervallo quando si arriva alla fine, con una breve pausa in mezzo. Se lo attivi senza impostare un versetto di inizio o fine, l'intero capitolo si ripete.

## Come cambiare la voce

Puoi scegliere quale voce usa Theodia per leggere. È utile se vuoi un accento diverso, una lingua diversa, o una voce più veloce o più lenta rispetto al default del dispositivo.

1. Apri **Impostazioni**.
2. Trova la sezione **Sintesi vocale**.
3. Tocca **Seleziona voce**.
4. Appare un elenco di voci. La prima riga, **Predefinita di sistema**, usa la voce preferita dal dispositivo. Scegli qualsiasi altra riga per impostarla come nuovo default.
5. La tua scelta viene salvata e usata la prossima volta che tocchi **Leggi**.

Puoi anche toccare l'icona 🎙 nella barra di ascolto per aprire lo stesso selettore senza lasciare il capitolo.

La disponibilità delle voci dipende interamente dal tuo dispositivo. iOS e Android includono ciascuno un insieme di voci integrate. Puoi installare altre voci dalle impostazioni del dispositivo in **Accessibilità** o **Lingua e input**. Theodia può usare qualsiasi voce installata sul dispositivo.

## Voci preferite

Se il tuo dispositivo ha molte voci, scorrere l'elenco completo ogni volta può essere lento. Puoi creare una lista corta di **voci preferite** e i selettori vocali mostreranno solo quelle.

1. Apri **Impostazioni**.
2. Trova la sezione **Sintesi vocale**.
3. Tocca **Voci preferite** (la prima riga in cima alla sezione).
4. Tocca **Imposta voci preferite** per aprire la schermata dei preferiti.
5. Tocca il pulsante play accanto a una voce per ascoltarla in anteprima. Tocca la stella per aggiungerla ai preferiti. Puoi mettere tra i preferiti tutte le voci che vuoi.
6. Torna indietro. I selettori vocali in Theodia mostrano ora solo le tue voci preferite.

Se rimuovi tutti i preferiti, i selettori tornano a mostrare tutte le voci. Le voci preferite sono incluse quando fai il backup e ripristini le impostazioni di Theodia.

## Impostare una voce diversa per ogni Bibbia

Puoi assegnare una voce propria a ogni traduzione biblica. È utile quando passi tra traduzioni che si leggono molto diversamente — ad esempio una voce più formale per la King James Version e una più conversazionale per una traduzione moderna come NIV o NLT. Aiuta anche se ascolti Bibbie in lingue diverse e vuoi che ciascuna sia parlata con il giusto accento.

1. Apri **Impostazioni**.
2. Trova la sezione **Sintesi vocale**.
3. Cerca **Voci della Bibbia**.
4. Tocca qualsiasi Bibbia nell'elenco.
5. Scegli la voce che vuoi per quella traduzione. La prima riga, **Predefinita di sistema**, usa la tua voce TTS principale per quella Bibbia.
6. Ripeti per ogni altra Bibbia.

L'intestazione mostra quante traduzioni bibliche hanno una voce personalizzata. **Seleziona voce**, **Voce di commento**, **Voce delle note della Bibbia** e **Voce devozionale** mostrano anche un conteggio quando è impostata una voce.

La prossima volta che ascolterai un capitolo da quella Bibbia, Theodia userà la voce scelta. Tutte le altre Bibbie continueranno a usare la voce principale di default, a meno che non le cambi anche loro.

## Continuare la lettura in background

Per default, Theodia ferma la lettura quando esci dalla schermata del lettore, passi a un'altra app o blocchi il telefono. Questo evita audio inaspettato quando non stai più leggendo attivamente.

Per far continuare la lettura in background:

1. Apri **Impostazioni**.
2. Trova la sezione **Sintesi vocale**.
3. Attiva **Continua la lettura in background**.

Quando è attiva, puoi cambiare scheda, aprire un'altra app o bloccare lo schermo e il capitolo o devozionale continueranno a leggere. La barra di controllo resta attiva così puoi mettere in pausa o saltare dall'area di notifica (se il dispositivo lo supporta).

Disattivare questo interruttore mentre la lettura è già in corso la fermerà immediatamente.

## Cosa fare se non funziona

La sintesi vocale dipende dal tuo dispositivo. Theodia invia il testo al sistema operativo, e il sistema operativo lo legge ad alta voce usando una voce. Se non funziona, prova questi passaggi in ordine.

### Theodia dice che il TTS non è disponibile

Alcuni dispositivi e la build web non hanno affatto il TTS. Apri **Impostazioni** e cerca la sezione **TTS**. Se la sezione non c'è, il tuo dispositivo non supporta il TTS in questa build.

### L'elenco delle voci è vuoto

Il selettore vocale potrebbe mostrare "nessuna voce trovata". Di solito significa che il dispositivo non ha ancora finito di caricare le voci.

1. Apri **Impostazioni → Sintesi vocale → Seleziona voce**.
2. Se l'elenco è vuoto, cerca un pulsante **Verifica** appena sotto il menu a discesa. Toccalo. Theodia interroga di nuovo il dispositivo per le voci.
3. Se è ancora vuoto, controlla le impostazioni di sistema del dispositivo. Su iOS, vai in **Impostazioni → Accessibilità → Contenuto parlato → Voci** e scarica una voce per la tua lingua. Su Android, vai in **Impostazioni → Lingua e input → Output sintesi vocale** e tocca **Installa dati voce**.
4. Chiudi e riapri Theodia così rileva la nuova voce.

Se hai impostato voci preferite e l'elenco è vuoto, assicurati che almeno una delle tue preferite corrisponda a una voce installata su questo dispositivo.

### Tocco Leggi ma non succede nulla

- Controlla che il dispositivo non sia in modalità silenziosa. La maggior parte dei dispositivi non riproduce audio TTS in modalità silenziosa.
- Assicurati che il volume del dispositivo sia alto.
- Prova il pulsante **Verifica** in **Impostazioni → Sintesi vocale**.
- Apri **Impostazioni** e guarda la sezione **Sistema** in fondo. La riga **TTS** dovrebbe dire **Disponibile**. Se dice **Non disponibile**, il TTS è disattivato a livello di sistema operativo. Riabilitalo lì, poi riapri Theodia.

### L'audio parte ma è nella lingua sbagliata

Theodia invia il testo nella lingua del contenuto attuale e chiede al dispositivo la voce selezionata. Se la voce selezionata è per una lingua diversa, il dispositivo potrebbe comunque leggere il testo, ma suonerà strano.

1. Apri **Impostazioni → Sintesi vocale → Seleziona voce**.
2. Scegli **Predefinita di sistema** per lasciare che il dispositivo scelga quella giusta, oppure scegli una voce la cui lingua corrisponda al testo che stai leggendo.

Theodia non legge attualmente ad alta voce le Bibbie interlineari greche o ebraiche. I pulsanti Leggi sono nascosti su quelle traduzioni.

### L'audio parte ma si interrompe presto

Se un versetto manca o non è leggibile, il capitolo salta al successivo. Se la barra si chiude da sola dopo pochi versetti, tocca di nuovo il pulsante **Leggi** (🔊) in cima allo schermo per ricominciare.

### La lettura è in riproduzione ma non so da dove è partita

Se hai attivato **Continua la lettura in background** e in seguito senti audio ma non trovi la schermata che l'ha avviata, puoi fermarlo da qualsiasi punto dell'app.

1. Apri **Impostazioni**.
2. Trova la sezione **Sintesi vocale**.
3. Tocca il pulsante rosso **Ferma lettura** in fondo alla sezione.

Questo ferma immediatamente qualsiasi sintesi vocale in esecuzione in Theodia. Puoi anche aprire il selettore app del dispositivo e chiudere Theodia per forzare l'arresto dell'audio.

### Legge troppo velocemente o troppo lentamente

Theodia non controlla la velocità di lettura. La velocità è impostata dalla voce scelta. Per cambiarla:

- Su iOS: **Impostazioni → Accessibilità → Contenuto parlato → Velocità di parlato**.
- Su Android: **Impostazioni → Lingua e input → Output sintesi vocale → Velocità di parlato**.

## Suggerimenti

- La barra di controllo rimane visibile mentre navighi tra i capitoli, così puoi mettere in pausa, saltare o cambiare voce senza perdere il punto.
- Theodia legge i numeri dei versetti come piccole pause. Puoi fermare la barra, scorrere a un versetto diverso, poi toccare play per continuare da lì.
- Per lunghe sessioni di ascolto, attiva **Non disturbare** così le notifiche non interrompono l'audio.
- Il pulsante 🔊 usa il volume attuale del dispositivo. Se inserisci le cuffie, il volume passa a quello delle cuffie.

## Guide correlate

- La guida [Modalità studio](theodia://help/study-mode) copre in modo più dettagliato il menu dei versetti e i pulsanti in cima allo schermo.
- La guida [Messa a fuoco](theodia://help/focus-mode) è una vista di lettura più pulita che supporta comunque il TTS tramite il pulsante 🔊 nella barra in basso.
- La guida [Problemi comuni](theodia://help/common-problems) contiene soluzioni per altri problemi audio, vocali e di lingua.
- La guida [Devozionali quotidiani](theodia://help/daily-devotionals) copre la lettura devozionale e dove si trova il pulsante Leggi in quella schermata.
