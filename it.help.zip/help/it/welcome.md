---
title: Benvenuto in Theodia
level: beginner
categories: welcome
summary: Un breve tour dell'app e di cosa può fare per te.
---

# Benvenuto in Theodia

Theodia è un'app di studio biblico. Funziona sul tuo telefono o tablet, anche senza internet. Tutto ciò che leggi, cerchi e studi è salvato sul tuo dispositivo.

## Cosa puoi fare

Theodia ha tre modalità utente. Ogni modalità mostra un insieme diverso di funzionalità.

- **Lettura** — leggi la Bibbia in una vista pulita e senza distrazioni.
- **Standard** — tutto della modalità Lettura, più segnalibri, evidenziazioni, note, sintesi vocale, ricerca e devozionali quotidiani.
- **Studioso** — tutto della modalità Standard, più commentari, lessici, il Dizionario biblico, l'assistente IA e altro.

Puoi cambiare modalità in qualsiasi momento in **Impostazioni** → **Modalità utente app**.

### Funzionalità sempre disponibili

Indipendentemente dalla modalità scelta, puoi sempre:

- **Leggere la Bibbia.** Scegli tra molte traduzioni. Passa dall'una all'altra in qualsiasi momento.
- **Cercare nella Bibbia.** Cerca una parola o una frase. L'app ti mostra ogni versetto che corrisponde.
- **Leggere libri e devozionali.** L'app include classici cristiani e un devozionale quotidiano.

A seconda della tua modalità, potresti anche poter:

- **Ascoltare.** Fai leggere i versetti ad alta voce con la funzione di lettura ad alta voce. (Standard e Studioso.)
- **Prendere note.** Scrivi i tuoi pensieri accanto a un versetto. (Standard e Studioso.)
- **Evidenzia.** Marchia i tuoi versetti preferiti a colori. (Standard e Studioso.)
- **Aggiungere segnalibri.** Salva i versetti per trovarli rapidamente. (Standard e Studioso.)
- **Chiedere all'assistente IA.** Ottieni aiuto per capire un versetto. (Solo Studioso.)

## Da dove iniziare

1. Apri la scheda **Bibbia** in fondo allo schermo.
2. Scegli una traduzione.
3. Tocca qualsiasi libro per iniziare a leggere.

Se vuoi saperne di più, il resto delle guide di aiuto è qui per te. Scegli un argomento dall'elenco nella pagina principale dell'aiuto.

## Alcune cose da sapere

- Non serve un account.
- Le tue note, evidenziazioni e segnalibri restano sul dispositivo.
- Puoi farne il backup. Vedi la guida [Backup dei tuoi dati](theodia://help/backups) per sapere come.

## Vuoi più risorse?

L'app include diverse versioni bibliche liberamente disponibili. Per Bibbie, commentari, lessici, libri e devozionali extra, vedi la guida [Ottenere risorse extra da GitHub](theodia://help/getting-core-files). Ti mostra come trovare e aggiungere altre risorse dalla pagina GitHub del progetto.

Benvenuto. Speriamo che Theodia ti aiuti a leggere e studiare.
