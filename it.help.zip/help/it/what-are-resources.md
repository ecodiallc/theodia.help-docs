---
title: Cosa sono le risorse?
level: beginner
categories: resources
summary: Una panoramica dei diversi tipi di file che Theodia usa: Bibbie, commentari, libri e altro.
---

# Cosa sono le risorse?

In Theodia, una "risorsa" è qualsiasi file che aggiunge materiale di lettura o studio all'app. L'app in sé è solo un lettore e un quaderno. Le Bibbie, i commentari, i libri e gli altri materiali che studi sono tutti file separati che carichi dentro.

Questa guida spiega i diversi tipi di risorse e a cosa serve ciascuno.

## Perché è importante?

Quando apri Theodia per la prima volta, ha già alcune cose da leggere. Mentre esplori, vedrai pulsanti per installarne altre. Sapere che tipo di risorsa è ciascuna ti aiuta a decidere cosa aggiungere.

## I diversi tipi di risorse

Theodia riconosce i file dalla loro estensione. Ogni estensione è un tipo diverso di risorsa.

### `.bible` — una traduzione biblica

Una traduzione biblica è una copia completa della Bibbia in una versione particolare, come la King James Version. Theodia include alcune traduzioni e ti permette di aggiungerne altre.

Vedi la guida [Installare traduzioni bibliche](theodia://help/installing-bibles) per i dettagli.

### `.commentary` — un commentario

Un commentario è un libro di note di studio scritto da uno studioso biblico. Per un dato versetto, un commentario ti dice lo sfondo, il significato e come il versetto si inserisce nel resto della Bibbia.

Vedi la guida [Commentari e lessici](theodia://help/commentaries-and-lexicons) per i dettagli.

### `.lexicon` — un lessico

Un lessico è un dizionario di parole bibliche. Ti dice la parola originale ebraica o greca, cosa significa e come è usata nella Bibbia.

Vedi la guida [Commentari e lessici](theodia://help/commentaries-and-lexicons) per i dettagli.

### `.book` — un libro cristiano

Un libro è un'opera cristiana più lunga, come un classico della storia della chiesa. Leggere libri nell'app funziona in modo simile alla lettura biblica. Theodia include una piccola libreria di classici cristiani liberamente disponibili.

Vedi la guida [Lettura dei libri integrati](theodia://help/reading-books) per i dettagli.

### `.devotional` — un devozionale

Un devozionale è una breve lettura quotidiana. Ogni voce di solito ha un versetto, una breve riflessione e una preghiera o una domanda su cui meditare. Molti devozionali sono pensati per essere letti una voce al giorno per un anno.

Vedi la guida [Devozionali quotidiani](theodia://help/daily-devotionals) per i dettagli.

### `.sqlite` — un database di riferimento

Un database di riferimento è un grande file di consultazione che l'app usa per darti informazioni extra mentre leggi. Ci sono due tipi:

- **Riferimenti incrociati** — elenchi di versetti che si collegano al versetto che stai leggendo.
- **Morfologia** — informazioni sulle parole ebraiche o greche originali nel versetto.

Non li apri direttamente. Lavorano in background e aggiungono funzionalità al lettore biblico. Vedi la guida [Riferimenti incrociati](theodia://help/cross-references) per i dettagli.

### `.data` — dati sulle parole

Un file di dati sulle parole contiene informazioni extra sulle parole originali della Bibbia. È usato dal lessico e dagli strumenti di studio. Come i database di riferimento, non lo apri direttamente. L'app lo usa in background.

## Come aggiungere una risorsa

La schermata **Gestisci risorse** dell'app è il modo più semplice per aggiungere una risorsa.

1. Apri **Impostazioni**.
2. Tocca **Gestisci risorse**.
3. Tocca **Installa da GitHub**.
4. Nel modale di download, scegli una scheda — **Bibbie**, **Commentari**, **Libri**, **Devozionali** o **Nucleo** — poi seleziona ciò che vuoi e tocca **Installa selezionate**.
5. Oppure tocca **Installa file locale** per importare un file che hai già scaricato.

Per una guida passo passo su come ottenere file direttamente da GitHub, vedi la guida [Ottenere risorse extra da GitHub](theodia://help/getting-core-files).

## Come rimuovere una risorsa

1. Apri **Impostazioni**.
2. Tocca **Gestisci risorse**.
3. Trova la risorsa che vuoi rimuovere.
4. Tocca l'icona del cestino accanto ad essa.
5. Conferma di volerla rimuovere.

Rimuovere una risorsa non elimina le tue note, evidenziazioni o segnalibri. Questi restano al sicuro.

## Dove vivono le risorse sul dispositivo

Le risorse sono memorizzate sul dispositivo, non nel cloud. Una volta installata una risorsa, non serve internet per leggerla. Puoi fare il backup del dispositivo, ma le risorse in sé non sono salvate nel cloud da Theodia. Se disinstalli e reinstalli l'app, dovrai aggiungere di nuovo le risorse che avevi installato.

## Aiuto e domande

Se hai problemi, consulta la guida [Dove fare domande](theodia://help/getting-more-help). Il team e la community possono aiutarti.
