---
title: 自分のリソースを作る
level: advanced
categories: resources
summary: 独自の聖書、注解、書籍、デボーショナル、レキシコンを作り、Theodia に読み込む方法です。
---

# 自分のリソースを作る

Theodia は、Unique Bible App 形式のカスタムリソースに対応しています。各リソースは、決まったテーブル構造を持つ SQLite ファイルです。これらのファイルはコンピュータで作り、アプリに読み込めます。

## ファイルの種類と必要なテーブル

### 聖書（`.bible`）

聖書ファイルは、次のテーブルのうち少なくとも 1 つを持つ SQLite データベースです：

- **`Verses`** — 列：`Book`（整数、1〜66）、`Chapter`（整数）、`Verse`（整数）、`Scripture`（テキスト）
- **`Bible`** — 列：`Book`（整数）、`Chapter`（整数）、`Verse`（整数）、`Scripture`（テキスト）

`Description`、`Abbreviation`、`Version` などのメタデータ列を持つ **`Details`** テーブルも含められます。

SQL の例：

```sql
-- Main text table
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- Optional metadata table
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### 注解（`.commentary`）

注解には 3 種類あります：**書籍**、**章**、**節**。種類はファイル名の**最初の文字**で決まります。

#### 書籍注解 —— ファイル名が `b` で始まる

書籍注解は、聖書の書籍全体を 1 つの項目で扱います。`Commentary` テーブルには `Book` と `Scripture`（または `Content`）の列が必要です。`Chapter` や `Verse` の列は不要です。

- **`Commentary`** — 列：`Book`（整数）、`Scripture`（テキスト）または `Content`（テキスト）

SQL の例：

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

ファイル名の例：`bMyCommentary.commentary`

#### 章注解 —— ファイル名が `c` で始まる

章注解は、聖書の書籍の各章を扱います。

- **`Commentary`** — 列：`Book`（整数）、`Chapter`（整数）、`Scripture`（テキスト）または `Content`（テキスト）

SQL の例：

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

ファイル名の例：`cMyCommentary.commentary`

#### 節注解 —— ファイル名が `v` で始まる

節注解は、個々の聖句を扱います。`Commentary` テーブルには `Book`、`Chapter`、`Verse`、`Scripture`（または `Content`）の列が必要です。

- **`Commentary`** — 列：`Book`（整数）、`Chapter`（整数）、`Verse`（整数）、`Scripture`（テキスト）または `Content`（テキスト）

SQL の例：

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

ファイル名の例：`vMyCommentary.commentary`

### 書籍（`.book`）

書籍ファイルは、`Reference` テーブルを持つ SQLite データベースです。

- **`Reference`** — 列：`id`（整数）、`Chapter`（テキスト）、`Content`（テキスト）

各行が 1 つの章です。`Chapter` 列は章のタイトル、`Content` 列は章の本文で、HTML（`<b>`、`<i>`、`<br>` など）を含められます。

SQL の例：

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

Markdown ファイルから書籍を作ることもできます。アプリは `#` を書籍のタイトル、`##` を章の印とする `.md` ファイルを読み込めます。Markdown は自動的に HTML に変換されます。

### デボーショナル（`.devotional`）

デボーショナルファイルは、`devotional` テーブルを持つ SQLite データベースです。

- **`devotional`** — 列：`month`（整数、1〜12）、`day`（整数、1〜31）、`devotion`（テキスト）

各行が 1 日の読書です。アプリは今日の月と日で項目を引き当てます。

SQL の例：

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### レキシコン（`.lexicon`）

レキシコンファイルは、`Lexicon` テーブルを持つ SQLite データベースです。

- **`Lexicon`** — 列：`Topic`（テキスト、ストロング番号）、`Definition`（テキスト、レキシコンの項目）

`Topic` 列はストロング番号（たとえば `G1161` や `H7225`）を、`Definition` 列は項目の全文を持ちます。HTML を含められます。

SQL の例：

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

レキシコンは単語情報ツールの力源です。行間対照聖書で単語をタップすると、アプリはインストール済みのレキシコンからストロング番号を引き当てます。

## コンピュータでファイルを作る

1. SQLite エディタをインストールします（DB Browser for SQLite、SQLiteStudio、`sqlite3` コマンドラインツールなど）。
2. 新しいデータベースファイルを作ります。
3. 必要なテーブルを作り、データを挿入します。
4. 正しい拡張子（`.bible`、`.commentary`、`.book`、`.devotional`、`.lexicon`）で保存します。

## Theodia への読み込み

1. ファイルを端末へ転送します（AirDrop、メール、クラウドストレージ、USB）。
2. **Theodia** を開きます。
3. **設定** → **リソースの管理**へ進みます。
4. **ファイルから読み込む**をタップします。
5. ファイルを選びます。

アプリはファイルを検証し（必要なテーブルの有無を確認）、アプリのデータフォルダへコピーして、自動的に有効にします。ファイルが無効なときは、何が悪いかを説明するエラーメッセージが表示されます。

## 制限

- 内蔵リソースを上書きすることはできません。内蔵の聖書、注解、書籍と同じ名前のファイルを読み込もうとすると、読み込みは失敗します。
- 聖書ファイルには `Verses` か `Bible` のテーブルが必要です。どちらもなければ、読み込みは失敗します。
- 注解ファイルには `Commentary` テーブルが必要です。
  - 書籍注解には `Book` と `Scripture`（または `Content`）の列が必要です。
  - 章注解には `Book`、`Chapter`、`Scripture`（または `Content`）の列が必要です。
  - 節注解には `Book`、`Chapter`、`Verse`、`Scripture`（または `Content`）の列が必要です。
- 書籍ファイルには `Reference` テーブルが必要です。
- レキシコンファイルには `Lexicon` テーブルが必要です。
- デボーショナルファイルには `devotional` テーブルが必要です。

## ヒント

- ファイルサイズは適度に保ちます。非常に大きな SQLite ファイルは、古い端末でメモリの問題を起こすことがあります。
- まずコンピュータでファイルを試します。SQLite ブラウザで開き、必要なテーブルに `SELECT * FROM` を実行して、データが正しく見えるか確かめます。
- 聖書では、`Book` 列が番号を使っているか確認します（1 = 創世記、66 = 黙示録）。
- 注解では、注解のテキスト列として `Scripture` と `Content` のどちらでも使えます。
- 書籍では、`Content` 列の HTML は読書中に表示されます。シンプルに保ちましょう。`<b>`、`<i>`、`<br>`、`<hr>` は安全です。

## 既存リソースの入手先

Theodia は [Unique Bible App](https://github.com/eliranwong/UniqueBible) プロジェクトのリソースを読めます。正しい SQLite 形式の聖書、注解、書籍などのリソースがたくさんあります。見つけ方と追加方法は[追加リソースの入手](theodia://help/getting-core-files)ガイドを見てください。
