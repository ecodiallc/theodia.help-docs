---
title: 명령
level: everyday
categories: [layout, study]
summary: 명령 입력으로 짧은 명령을 입력해 거의 모든 기능으로 건너뜁니다. 지원 형식과 예를 알아봅니다.
---

# 명령

**명령** 입력으로 짧은 지시를 입력해 Theodia의 거의 모든 부분으로 건너뛸 수 있습니다. 홈 탭이나 **런처 메뉴**(머리말의 **▼** 아이콘)에서 쓸 수 있습니다.

## 작동 방식

1. 명령 상자를 누릅니다.
2. 명령을 입력합니다.
3. 키보드의 이동 키를 누릅니다.

앱이 명령을 읽고 바로 알맞은 화면으로 데려갑니다.

## 슬래시 접두어 없음

명령에는 **`/` 접두어를 쓰지 않습니다.** 일반 텍스트로 입력합니다:

```
john 3:16
search love
backup
```

`/settings`처럼 입력하면 맨 앞의 `/` 때문에 알아볼 수 없게 됩니다.

## 성경 참조

성경 참조를 입력하면 읽기 화면에서 열립니다.

```
psalms 23
john 3:16
matthew 5:1
1 cor 15:10
```

책 이름은 전체 이름이나 약어로 일치시킬 수 있습니다. 영어가 아닌 UI 언어에서는 현재 언어로 책 이름을 입력할 수도 있습니다.

## 검색

```
search abraham
search love
search faith not works
```

## 책갈피, 비교, 주석, 관계 참조, 단어 정보

```
bookmark john 3:16
compare genesis 1:1
commentary john 1
aicommentary eph 2:8
xref 1 cor 15:10
word info john 1:1
```

이 명령들은 주어진 구간에 대해 이름 붙은 도구를 엽니다.

## 원어 사전

스트롱 번호를 입력하면 원어 사전 항목이 열립니다.

```
g1161
h7225
```

## 묵상

```
devotional
devotional smith
devotional daily
```

이름 없이 쓰면 묵상 목록을 엽니다.

## 이동 단축

```
notes
highlights
bookmarks
flashcards
playlist
theoscript
resources
read john 3:16
```

이것들은 이름 붙은 화면으로 바로 건너뛰거나 읽기 화면에서 구간을 엽니다.

## 번역 전환

번역 약어를 입력하면 그것으로 바꿉니다.

```
kjv
web
trlit
ohgb
```

읽기 화면에서는 번역이 그 자리에서 바뀝니다. 그 밖의 곳에서는 가장 최근 구간으로 그 번역을 엽니다.

## 현지화된 명령 동사

공개 명령 동사는 현재 UI 언어로도, 영어로도 입력할 수 있습니다. 영어는 언제나 예비로 작동합니다. 숨은 명령(설정 단축, 설치 명령, 이스터 에그)은 영어 문법만 유지합니다.

## 도움말

명령 상자에 `help`나 `commands`를 입력하면 언제든 앱 안의 명령 참고자료가 열립니다.
