---
title: 자기 자료 만들기
level: advanced
categories: resources
summary: 사용자 지정 성경, 주석, 책, 묵상, 원어 사전을 만들어 Theodia로 가져오는 방법입니다.
---

# 자기 자료 만들기

Theodia는 Unique Bible App 형식의 사용자 지정 자료를 지원합니다. 각 자료는 특정 표 구조를 가진 SQLite 파일입니다. 이 파일들은 컴퓨터에서 만들어 앱으로 가져올 수 있습니다.

## 파일 형식과 필요한 표

### 성경 (`.bible`)

성경 파일은 이 표 중 최소 하나가 있는 SQLite 데이터베이스입니다:

- **`Verses`** — 열: `Book` (정수, 1-66), `Chapter` (정수), `Verse` (정수), `Scripture` (텍스트)
- **`Bible`** — 열: `Book` (정수), `Chapter` (정수), `Verse` (정수), `Scripture` (텍스트)

`Description`, `Abbreviation`, `Version` 같은 메타데이터 열이 있는 **`Details`** 표를 포함할 수도 있습니다.

SQL 예:

```sql
-- Main text table
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- Optional metadata table
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### 주석 (`.commentary`)

주석은 세 종류가 있습니다: **책**, **장**, **절**. 종류는 **파일 이름의 첫 글자**로 정해집니다.

#### 책 주석 — 파일 이름이 `b`로 시작

책 주석은 성경 책 전체를 하나의 항목으로 다룹니다. `Commentary` 표에는 `Book`과 `Scripture`(또는 `Content`) 열이 필요합니다. `Chapter`나 `Verse` 열은 필요 없습니다.

- **`Commentary`** — 열: `Book` (정수), `Scripture` (텍스트) 또는 `Content` (텍스트)

SQL 예:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

파일 이름 예: `bMyCommentary.commentary`

#### 장 주석 — 파일 이름이 `c`로 시작

장 주석은 성경 책의 각 장을 다룹니다.

- **`Commentary`** — 열: `Book` (정수), `Chapter` (정수), `Scripture` (텍스트) 또는 `Content` (텍스트)

SQL 예:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

파일 이름 예: `cMyCommentary.commentary`

#### 절 주석 — 파일 이름이 `v`로 시작

절 주석은 개별 구절을 다룹니다. `Commentary` 표에는 `Book`, `Chapter`, `Verse`, `Scripture`(또는 `Content`) 열이 필요합니다.

- **`Commentary`** — 열: `Book` (정수), `Chapter` (정수), `Verse` (정수), `Scripture` (텍스트) 또는 `Content` (텍스트)

SQL 예:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

파일 이름 예: `vMyCommentary.commentary`

### 책 (`.book`)

책 파일은 `Reference` 표가 있는 SQLite 데이터베이스입니다.

- **`Reference`** — 열: `id` (정수), `Chapter` (텍스트), `Content` (텍스트)

각 줄이 한 장입니다. `Chapter` 열은 장 제목이고, `Content` 열은 장 본문으로 HTML(`<b>`, `<i>`, `<br>` 등)을 포함할 수 있습니다.

SQL 예:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

Markdown 파일로도 책을 만들 수 있습니다. 앱은 `#`이 책 제목이고 `##`이 장을 표시하는 `.md` 파일을 가져올 수 있습니다. Markdown은 자동으로 HTML로 바뀝니다.

### 묵상 (`.devotional`)

묵상 파일은 `devotional` 표가 있는 SQLite 데이터베이스입니다.

- **`devotional`** — 열: `month` (정수, 1-12), `day` (정수, 1-31), `devotion` (텍스트)

각 줄이 하루의 읽기입니다. 앱은 오늘의 월과 일로 항목을 찾습니다.

SQL 예:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### 원어 사전 (`.lexicon`)

원어 사전 파일은 `Lexicon` 표가 있는 SQLite 데이터베이스입니다.

- **`Lexicon`** — 열: `Topic` (텍스트, 스트롱 번호), `Definition` (텍스트, 원어 사전 항목)

`Topic` 열은 스트롱 번호(예: `G1161` 또는 `H7225`)를 담습니다. `Definition` 열은 전체 항목 본문을 담으며 HTML을 포함할 수 있습니다.

SQL 예:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

원어 사전은 단어 정보 도구를 움직입니다. 행간 성경에서 단어를 누르면 앱은 설치한 원어 사전에서 스트롱 번호를 찾습니다.

## 컴퓨터에서 파일 만들기

1. SQLite 편집기를 설치합니다(DB Browser for SQLite, SQLiteStudio, 또는 `sqlite3` 명령줄 도구).
2. 새 데이터베이스 파일을 만듭니다.
3. 필요한 표를 만들고 데이터를 넣습니다.
4. 올바른 확장자로 파일을 저장합니다(`.bible`, `.commentary`, `.book`, `.devotional`, 또는 `.lexicon`).

## Theodia로 가져오기

1. 파일을 기기로 옮깁니다(AirDrop, 이메일, 클라우드 저장소, 또는 USB).
2. **Theodia**를 엽니다.
3. **설정** → **자료 관리**로 가세요.
4. **파일에서 가져오기**를 누릅니다.
5. 파일을 선택합니다.

앱은 파일을 검사하고(필요한 표가 있는지 확인) 앱의 데이터 폴더로 복사해 자동으로 켭니다. 파일이 잘못됐으면 무엇이 잘못됐는지 설명하는 오류 메시지가 보입니다.

## 한계

- 내장 자료를 덮어쓸 수 없습니다. 내장 성경, 주석, 책과 같은 이름의 파일을 가져오려 하면 가져오기가 실패합니다.
- 성경 파일에는 `Verses`나 `Bible` 표가 필요합니다. 어느 것도 없으면 가져오기가 실패합니다.
- 주석 파일에는 `Commentary` 표가 필요합니다.
  - 책 주석에는 `Book`과 `Scripture`(또는 `Content`) 열이 필요합니다.
  - 장 주석에는 `Book`, `Chapter`, `Scripture`(또는 `Content`) 열이 필요합니다.
  - 절 주석에는 `Book`, `Chapter`, `Verse`, `Scripture`(또는 `Content`) 열이 필요합니다.
- 책 파일에는 `Reference` 표가 필요합니다.
- 원어 사전 파일에는 `Lexicon` 표가 필요합니다.
- 묵상 파일에는 `devotional` 표가 필요합니다.

## 도움말

- 파일 크기를 적당히 유지하세요. 아주 큰 SQLite 파일은 오래된 기기에서 메모리 문제를 일으킬 수 있습니다.
- 컴퓨터에서 먼저 파일을 시험하세요. SQLite 브라우저에서 열고 필요한 표에 `SELECT * FROM`을 실행해 데이터가 옳게 보이는지 확인합니다.
- 성경은 `Book` 열이 숫자를 쓰는지 확인하세요(1 = 창세기, 66 = 요한계시록).
- 주석은 주석 본문 열로 `Scripture`나 `Content` 어느 것이든 쓸 수 있습니다.
- 책은 `Content` 열의 HTML이 읽을 때 그려집니다. 간단히 두세요: `<b>`, `<i>`, `<br>`, `<hr>`은 안전합니다.

## 기존 자료를 찾는 곳

Theodia는 [Unique Bible App](https://github.com/eliranwong/UniqueBible) 프로젝트에서 자료를 읽을 수 있습니다. 많은 성경, 주석, 책, 기타 자료가 올바른 SQLite 형식으로 거기 있습니다. 찾고 추가하는 방법은 [추가 자료 받기](theodia://help/getting-core-files) 가이드를 보세요.
