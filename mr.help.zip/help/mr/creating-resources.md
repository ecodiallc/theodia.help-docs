---
title: स्वतःची संसाधने तयार करणे
level: advanced
categories: resources
summary: सानुकूल बायबल, टीका, पुस्तके, devotionals आणि लेक्सिकॉन कसे तयार करायचे आणि Theodia मध्ये कसे आयात करायचे.
---
# स्वतःची संसाधने तयार करणे

Theodia Unique Bible App स्वरूपातील सानुकूल संसाधने समर्थित करते. प्रत्येक संसाधन विशिष्ट टेबल संरचनेसह SQLite फाइल असते. तुम्ही हे फाइल्स संगणकावर तयार करून अ‍ॅपमध्ये आयात करू शकता.

## फाइल प्रकार आणि आवश्यक टेबल्स

### बायबल (`.bible`)

बायबल फाइल किमान यापैकी एक टेबल असलेला SQLite डेटाबेस आहे:

- **`Verses`** — स्तंभ: `Book` (पूर्णांक, 1-66), `Chapter` (पूर्णांक), `Verse` (पूर्णांक), `Scripture` (पाठ)
- **`Bible`** — स्तंभ: `Book` (पूर्णांक), `Chapter` (पूर्णांक), `Verse` (पूर्णांक), `Scripture` (पाठ)

तुम्ही `Description`, `Abbreviation` आणि `Version` सारखे मेटाडेटा स्तंभ असलेला **`Details`** टेबल देखील समाविष्ट करू शकता.

उदाहरण SQL:

```sql
-- मुख्य पाठ टेबल
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- पर्यायी मेटाडेटा टेबल
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### टीका (`.commentary`)

टीका तीन प्रकारात येतात: **पुस्तक**, **अध्याय** आणि **वचन**. प्रकार **फाइलनामच्या पहिल्या अक्षरातून** ठरतो.

#### पुस्तक टीका — फाइलनाम `b` ने सुरू होतो

पुस्तक टीका संपूर्ण बायबल पुस्तक एका प्रवेशात कव्हर करते.

- **`Commentary`** — स्तंभ: `Book` (पूर्णांक), `Scripture` (पाठ) किंवा `Content` (पाठ)

उदाहरण SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

फाइलनाम उदाहरण: `bMyCommentary.commentary`

#### अध्याय टीका — फाइलनाम `c` ने सुरू होतो

अध्याय टीका बायबल पुस्तकाचा प्रत्येक अध्याय कव्हर करते.

- **`Commentary`** — स्तंभ: `Book` (पूर्णांक), `Chapter` (पूर्णांक), `Scripture` (पाठ) किंवा `Content` (पाठ)

उदाहरण SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

फाइलनाम उदाहरण: `cMyCommentary.commentary`

#### वचन टीका — फाइलनाम `v` ने सुरू होतो

वचन टीका व्यक्तिगत वचने कव्हर करते.

- **`Commentary`** — स्तंभ: `Book` (पूर्णांक), `Chapter` (पूर्णांक), `Verse` (पूर्णांक), `Scripture` (पाठ) किंवा `Content` (पाठ)

उदाहरण SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

फाइलनाम उदाहरण: `vMyCommentary.commentary`

### पुस्तके (`.book`)

पुस्तक फाइल ही `Reference` टेबल असलेला SQLite डेटाबेस आहे.

- **`Reference`** — स्तंभ: `id` (पूर्णांक), `Chapter` (पाठ), `Content` (पाठ)

प्रत्येक ओळ एक अध्याय असतो. `Chapter` स्तंभ अध्याय शीर्षक आहे. `Content` मुख्य भाग आहे, ज्यात HTML (`<b>`, `<i>`, `<br>`, इ.) समाविष्ट असू शकते.

उदाहरण SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

तुम्ही Markdown फाइल्समधून पुस्तके देखील तयार करू शकता. अ‍ॅप `.md` फाइल्स आयात करतो, ज्यात `#` पुस्तक शीर्षक आणि `##` अध्याय असतात. Markdown स्वयंचलित HTML मध्ये बदलतो.

### Devotionals (`.devotional`)

Devotional फाइल ही `devotional` टेबल असलेला SQLite डेटाबेस आहे.

- **`devotional`** — स्तंभ: `month` (पूर्णांक, 1-12), `day` (पूर्णांक, 1-31), `devotion` (पाठ)

प्रत्येक ओळ एका दिवसाचे वाचन असते. अ‍ॅप आजच्या महिन्या आणि दिवसानुसार प्रवेश शोधतो.

उदाहरण SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### लेक्सिकॉन (`.lexicon`)

लेक्सिकॉन फाइल ही `Lexicon` टेबल असलेला SQLite डेटाबेस आहे.

- **`Lexicon`** — स्तंभ: `Topic` (पाठ, Strong's संख्या), `Definition` (पाठ, लेक्सिकॉन प्रवेश)

`Topic` स्तंभ Strong's संख्या ठेवतो (उदा. `G1161` किंवा `H7225`). `Definition` स्तंभ पूर्ण प्रवेश पाठ ठेवतो, ज्यात HTML असू शकते.

उदाहरण SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

लेक्सिकॉन शब्द माहिती साधनाला शक्ती देतात. जेव्हा तुम्ही इंटरलिनियर बायबलमध्ये शब्द टॅप करता, तेव्हा अ‍ॅप इन्स्टॉल केलेल्या लेक्सिकॉनमध्ये Strong's संख्या शोधतो.

## संगणकावर फाइल तयार करणे

1. SQLite संपादक इन्स्टॉल करा (DB Browser for SQLite, SQLiteStudio, किंवा `sqlite3` कमांड-लाइन साधन).
2. नवीन डेटाबेस फाइल तयार करा.
3. आवश्यक टेबल तयार करा आणि तुमचा डेटा टाका.
4. फाइल योग्य extension (.bible, .commentary, .book, .devotional किंवा .lexicon) सह साठवा.

## Theodia मध्ये आयात करणे

1. फाइल तुमच्या डिव्हाइसवर हलवा (AirDrop, ईमेल, क्लाउड स्टोरेज किंवा USB).
2. **Theodia** उघडा.
3. **सेटिंग्स** → **संसाधने व्यवस्थापित करा** येथे जा.
4. **फाइलमधून आयात करा** वर टॅप करा.
5. तुमची फाइल निवडा.

अ‍ॅप फाइल वैध ठरवतो (आवश्यक टेबल तपासतो), ती अ‍ॅपच्या डेटा फोल्डरमध्ये कॉपी करतो, आणि ती स्वयंचलित सक्षम करतो. जर फाइल अवैध असेल, तर त्रुटी संदेश दिसतो.

## मर्यादा

- तुम्ही निर्मित संसाधने ओव्हरराइट करू शकत नाही.
- बायबल फाइल्सला `Verses` किंवा `Bible` टेबल आवश्यक.
- टीका फाइल्सला `Commentary` टेबल आवश्यक.
  - पुस्तक टीकांना `Book` आणि `Scripture` (किंवा `Content`) स्तंभ आवश्यक.
  - अध्याय टीकांना `Book`, `Chapter` आणि `Scripture` (किंवा `Content`) स्तंभ आवश्यक.
  - वचन टीकांना `Book`, `Chapter`, `Verse` आणि `Scripture` (किंवा `Content`) स्तंभ आवश्यक.
- पुस्तक फाइल्सला `Reference` टेबल आवश्यक.
- लेक्सिकॉन फाइल्सला `Lexicon` टेबल आवश्यक.
- Devotional फाइल्सला `devotional` टेबल आवश्यक.

## टिपा

- फाइल आकार वाजवी ठेवा.
- आधी तुमची फाइल संगणकावर चाचणी करा.
- बायबलसाठी, `Book` स्तंभ संख्या वापरतो याची खात्री करा (1 = उत्पत्ति, 66 = प्रकटीकरण).
- टीकांसाठी, तुम्ही `Scripture` किंवा `Content` वाचा चटा.
- पुस्तकांसाठी, `Content` स्तंभात HTML पाठ वाचताना रेंडर होते. ते साधे ठेवा: `<b>`, `<i>`, `<br>` आणि `<hr>` सुरक्षित आहेत.

## असलेली संसाधने कुठे शोधावीत

Theodia [Unique Bible App](https://github.com/eliranwong/UniqueBible) प्रकल्पातील संसाधने वाचू शकते. तेथे अनेक बायबल, टीका, पुस्तके आणि इतर संसाधने योग्य SQLite स्वरूपात उपलब्ध आहेत. ती कसे शोधावी आणि जोडावी यासाठी [अतिरिक्त संसाधने मिळवणे](theodia://help/getting-core-files) मार्गदर्शक पाहा.
