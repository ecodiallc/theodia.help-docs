---
title: PDFs
level: everyday
categories: [read, resources]
summary: Theodia मध्ये PDF दस्तऐवज आयात, व्यवस्थापित आणि वाचा.
---

# PDFs

> **मोड:** PDFs **मानक** आणि **विद्वान** मोडमध्ये उपलब्ध आहेत. फोकस मोड केवळ स्वच्छ, विना विघ्न वाचनासाठी आहे. मोड बदलण्यासाठी **सेटिंग्ज** → **अॅप वापरकर्ता मोड** येथे जा.

Theodia PDF फाइली जतन करू आणि वाचू शकतो. आयात केलेल्या PDFs तुमच्या डिव्हाइसवर राहतात, म्हणून त्या ऑफलाइन काम करतात.

## PDF लायब्ररी उघडा

स्क्रीनच्या तळाशी **PDFs** टॅबवर टॅप करा, किंवा होम स्क्रीनवर **PDFs** टाइलवर टॅप करा.

## PDF आयात करा

1. **PDFs** टॅब उघडा.
2. तळाशी-उजव्या बाजूला **+** बटन टॅप करा.
3. तुमच्या डिव्हाइसमधून एक PDF निवडा.
4. (पर्यायी) तो व्यवस्थापित करण्यासाठी एक category टाइप करा अथवा निवडा.

## PDF व्यवस्थापित करा

कोणत्याही PDF कार्डवर long-press करा त्यात हे पर्याय असलेले मेनू उघडेल:

- **Rename** — लायब्ररीत दिसणारे शीर्षक बदला.
- **Change category** — PDF ला एका category मध्ये हलवा.
- **Delete** — PDF Theodia मधून हटवा. यामुळे त्याची जतन केलेली वाचन स्थितीही हटते.

Categories free-form text आहेत. आयात करताना किंवा category बदलताना नवे नाव टाइप करा किंवा एक विद्यमान निवडा.

## PDF वाचा

PDF कार्डवर टॅप करून तो उघडा. Reader मध्ये दिसते:

- वरच्या बारमध्ये document चे शीर्षक.
- page बटणांची एक रांग: **First page**, **Previous**, सध्याचा page ("3 / 120"), **Next**, आणि **Last page**.
- document च्या tools सह एक toolbar: **Contents**, **Zoom out**, **Zoom in**, **Reset zoom**, **Bookmark**, **Search**, **Listen**, आणि **Text view**.

काही tools dimmed असतात जेव्हा ते वापरता येऊ शकत नाहीत — उदाहरणार्थ, जोपर्यंत PDF चे searchable text इंस्टॉल झाले नाही तोपर्यंत **Search** आणि **Listen** dimmed राहतात.

### Pages बदला

- एक page मागे किंवा पुढे जाण्यासाठी **बायाँ** अथवा **दायाँ chevron** टॅप करा.
- document च्या शेवटापर्यंत जाण्यासाठी **First page** किंवा **Last page** टॅप करा.
- Page number टॅप करा (उदा. "3 / 120") त्यामुळे pages ची grid उघडेल, मग ज्या page वर जायचे ते निवडा. Grid तुमच्या सध्याच्या page च्या जवळ उघडते.
- external keyboard वर **Left** आणि **Right arrow keys** वापरा.

### Zoom

- page चा आकार बदलण्यासाठी **Zoom in** (+) अथवा **Zoom out** (−) टॅप करा.
- page ला सामान्य आकारात परत आणण्यासाठी **Reset zoom** टॅप करा.
- जर तुम्ही zoom in केले, page बदलले, आणि नंतर zoom out केले, तर Theodia तुम्हाला ज्या page वर तुम्ही वाचत होता तिथे परत आणते.

## PDF मध्ये शोध

1. PDF उघडा आणि toolbar मधील **Search** (magnifying glass) बटन टॅप करा.
2. तुम्ही शोधत असलेला मजकूर टाइप करा. टाइप करताना results दिसतात, page number आणि आसपासच्या text चा snippet सह.
3. त्या page वर जाण्यासाठी कोणताही result टॅप करा.

शोधासाठी PDF चे searchable text इंस्टॉल असणे आवश्यक आहे. जर ते अद्याप इंस्टॉल झाले नसेल तर **Search** बटन dimmed राहते. Community GitHub repository मधून इंस्टॉल केलेल्या PDFs मध्ये searchable text असते; तुम्ही स्वतः आयात केलेल्या PDFs मध्ये ते जोडल्यासारखे नसते जोपर्यंत जोडले जात नाही.

## Contents

जर PDF मध्ये built-in table of contents असेल, तर toolbar चे **Contents** बटन ते outline म्हणून दाखवते. त्या page वर जाण्यासाठी section चे शीर्षक टॅप करा. Sections expand आणि collapse करता येतात. जर PDF मध्ये table of contents नसेल, तर बटन dimmed राहते.

## PDF मधील bookmarks

1. PDF उघडा आणि toolbar मधील **Bookmark** बटन टॅप करा.
2. सध्याचा page जतन करण्यासाठी **Bookmark page** टॅप करा. नाव सुरुवातीला page number असते — तुम्हाला आवडेल तर तुमचे नाव टाइप करा — नंतर **Save** टॅप करा.
3. त्याच्या page वर जाण्यासाठी यादीतील कोणताही bookmark टॅप करा.
4. bookmark हटवण्यासाठी त्याच्याशेजारी **×** टॅप करा.

PDF bookmarks तुमच्या बायबल bookmarks पासून वेगळे असतात. प्रत्येक PDF ची स्वतःची यादी असते.

## PDF जोरात वाचा

जर PDF चे searchable text इंस्टॉल असेल, तर Theodia सध्याचा page जोरात वाचू शकतो:

1. PDF उघडा आणि toolbar मधील **Listen** (speaker) बटन टॅप करा.
2. एक control bar दिसते ज्यामध्ये **Play/Pause**, **Rewind**, **Fast forward**, **Stop**, page च्या आत skip करण्यासाठी टॅप करता येणारा progress bar, वाचन गती, आणि voice असतात.
3. page पूर्ण झाल्यावर वाचन आपोआप पुढील page वर चालू राहते.

Voice आणि गती बायबल वाचनासाठी वापरलेली जी असतात तीच आहेत — ते बदलण्याची पद्धत [जोरात वाचा (TTS)](theodia://help/tts) गाइडमध्ये पहा.

## page चा मजकूर copy, share, किंवा save करा

सध्याचा page plain text म्हणून पाहण्यासाठी toolbar चे **Text view** बटन टॅप करा. तिथून तुम्ही:

- **Copy** — page चा मजकूर clipboard वर copy करा.
- **Share** — page चा मजकूर तुमच्या डिव्हाइसवरील कोणत्याही अॅपमधून share करा.
- **Add to study notes** — note editor उघडतो, ज्यामध्ये page चा मजकूर, एक citation, आणि या page वर परत येण्याचा लिंक तुमच्यासाठी आधीपासून भरलेला असतो.

## वाचन जारी ठेवा

Theodia तुम्ही शेवटी कोणता page पाहिला तो लक्षात ठेवतो आणि पुढील वेळी PDF तिथूनच उघडतो.

## GitHub मधून PDFs डाउनलोड करा

**विद्वान** मोडमध्ये, लायब्ररीच्या तळाशी एक **Download from GitHub** बटन दिसते. हे community PDF repository शी जोडते, ज्यामुळे तुम्ही packaged PDF दस्तऐवज Bibles किंवा books इंस्टॉल करता तसे इंस्टॉल करू शकता.

## नोट्स

- PDF फाइली Theodia च्या private documents folder मध्ये जतन होतात. त्या backups मध्ये समाविष्ट नसतात, म्हणून नवीन डिव्हाइसवर स्थलांतर केल्यास त्या पुन्हा आयात कराव्या लागतील.
