---
title: प्रार्थना अवलोकन
level: beginner
categories: prayer
summary: Prayer टॅब आणि त्याच्या मुख्य विभागांचा त्वरित परिचय.
---

# प्रार्थना अवलोकन

**Prayer** टॅब प्रार्थनेसाठी समर्पित जागा आहे. ते यादी, मार्गदर्शित सत्रे, journal, timer, lectionary reading schedules, आणि शास्त्रीय fixed prayers यांना एकत्र आणते.

## मुख्य विभाग

- **Prayer List** — ज्यांच्यासाठी तुम्ही प्रार्थना करत आहात ते लोक, परिस्थिती आणि विषय लक्षात ठेवा.
- **Journal** — वेळोवेळी चिंतन, उत्तरे आणि विचार लिहून ठेवा.
- **Generate Prayer** — Theophilus ला request किंवा journal entry मधून प्रार्थना लिहिण्याची विनंती करा.
- **Creeds & Fixed Prayers** — ख्रिश्चन परंपरेतील शास्त्रीय प्रार्थना आणि creeds.
- **Lectionary** — दैनिक किंवा मौसमी प्रार्थनेसाठी scripture reading schedules.
- **Guided Prayer** — text-to-speech सह audio-guided prayer sessions.
- **Timer** — ऐच्छिक घंट्यांसह timed prayer sessions.
