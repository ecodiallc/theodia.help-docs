---
title: AI-basisprincipes
level: advanced
categories: ai
summary: Hoe u de AI-helper gebruikt om verzen te begrijpen.
---

# AI-basisprincipes

> **Modus:** De AI-assistent vereist de modus **Geleerde**. U kunt van modus wisselen in **Instellingen** → **App-gebruikersmodus**.

Theodia heeft een AI-assistent. Die kan u helpen een vers te begrijpen, een vraag beantwoorden of een Bijbelonderwerp doornemen.

## De AI aanzetten

De AI staat standaard uit. Om die aan te zetten:

1. Open **Instellingen**.
2. Tik op **AI-assistent**.
3. Tik op de schakelaar om die aan te zetten.

## De AI openen

Tik onderaan het scherm op het tabblad **AI**. Er opent een chatvenster.

## Een vraag stellen

Tik op het vak onderaan. Typ uw vraag. Tik op **Versturen**.

Een paar dingen die u kunt vragen:

- "Wat betekent Johannes 3:16?"
- "Vertel me over het boek Romeinen."
- "Wat is de vrucht van de Geest?"
- "Vergelijk de bergrede in Matteüs en Lucas."

## Naar een specifiek vers vragen

1. Open een hoofdstuk.
2. Tik op een vers om het versmenu te openen.
3. Tik op **AI-commentaar**.

Het vers wordt naar de AI gestuurd. Het AI-paneel opent met het vers al ingevuld. U kunt een vraag toevoegen, zoals "Wat betekent dit?" of "Hoe kan ik dit toepassen?"

## Belangrijke dingen om te weten

- De AI is een hulpmiddel, geen persoon. Ze kan fouten maken.
- Controleer de antwoorden van de AI altijd aan de Bijbel zelf.
- De AI heeft het internet nodig. Ze werkt niet offline.
- Wanneer u de AI gebruikt, worden uw vragen, de verscontext en uw API-sleutel naar het door u gekozen eindpunt gestuurd. De eerste keer vraagt de app om uw toestemming en toont precies wat er wordt gestuurd. U kunt die toestemming later veranderen of intrekken in **Instellingen → AI-assistent → Gegevensdeling met externe AI**.
- Sommige regio's, zoals de App Store-build voor het vasteland van China, bieden de AI-assistent niet aan. In die build zijn alleen offline Bijbelfuncties beschikbaar.

## Gesprekken beheren

Het AI-scherm bewaart een lijst met vroegere gesprekken. Vanuit de lijst kunt u een oud gesprek openen, een nieuw beginnen of een gesprek verwijderen dat u niet meer nodig heeft.

## Dieper met AI

Deze pagina behandelt de basis. De AI van Theodia kan veel meer dan chatten. Dit is waar u verder kunt gaan:

- **[AI-functies](theodia://help/ai-features)** — Ontdek alles wat Theophilus kan: versstudie met één tik in het Grieks en Hebreeuws, kruisverwijsketens, preekcontouren, gebedsgeneratie, brontaalmorfologie, woordenboeknaslag en navigatie zonder handen. Dit is de gids die toont hoe u de AI van een chatbot tot een volwaardige studiepartner maakt.
- **[Betere AI-prompts schrijven](theodia://help/ai-prompts)** — Leer de kunst van het stellen van vragen die rijke, nauwkeurige antwoorden opleveren. Een paar aanpassingen aan hoe u uw verzoek formuleert, kunnen aanzienlijk diepere antwoorden van de AI ontgrendelen.
- **[Een AI-model kiezen](theodia://help/choosing-a-model)** — Niet alle AI-modellen zijn gelijk. Ontdek welke modellen de ingebouwde hulpmiddelen van Theodia ondersteunen (zoals verzen openen en Schrift doorzoeken) en welke de AI tot een echte Bijbelstudie-assistent zonder handen maken.
- **[GitHub Models](theodia://help/github-models)** — De aanbevolen gratis aanbieder voor Theodia. Ontvang een gratis API-sleutel met een GitHub-account en begin met vragen stellen op een royale dagelijkse laag. Geen creditcard, geen abonnement.
- **[API-sleutels en kosten](theodia://help/ai-keys-and-costs)** — Begrijp hoe API-prijzen tussen aanbieders werken en hoe u de kosten dicht bij nul houdt.
