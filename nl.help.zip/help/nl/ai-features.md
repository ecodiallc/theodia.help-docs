---
title: AI-functies
categories: ai
level: advanced
summary: Ontdek alles wat de AI van Theodia kan — van vers-voor-vers studie tot preekvoorbereiding, brontaalverkenning en navigatie zonder handen.
---

# AI-functies

> **Modus:** De AI-assistent vereist de modus **Geleerde**. U kunt van modus wisselen in **Instellingen** → **App-gebruikersmodus**.

De AI-assistent van Theodia, Theophilus, is niet zomaar een chatbot. Ze is een studiepartner die de Bijbel naast u kan lezen, commentaren kan opzoeken, de Schrift kan doorzoeken, uw notities kan beheren en zelfs door de app kan navigeren — allemaal met stem of tekst.

Voordat Theophilus voor de eerste keer gegevens naar een AI-eindpunt stuurt, toont de app een toestemmingsvraag die uitlegt wat er wordt gestuurd en om uw toestemming vraagt. U kunt die toestemming op elk moment veranderen of intrekken in **Instellingen → AI-assistent → Gegevensdeling met externe AI**.

## AI-verschat: één vers diep bestuderen

De **AI-verschat** is het hart van de AI-ervaring in Theodia. Terwijl u een willekeurig hoofdstuk leest, tikt u op een versnummer (of houdt de vertaaltekst lang ingedrukt) en kiest **AI-commentaar**. Er opent een chatpaneel met dat vers al geladen. De AI weet precies wat u leest en is klaar om het samen met u te verkennen.

### Starters met één tik

Weet u niet wat u moet vragen? Het paneel toont acht directe starters:

- **Leg dit vers uit** — Ontvang een heldere, doordachte uiteenzetting van betekenis en betekenisvolheid.
- **Brontaal** — Zie de Griekse of Hebreeuwse woorden, transliteraties en lexicondefinities achter de Engelse tekst.
- **Historische context** — Leer over de cultuur, politiek en gebeurtenissen rond het vers.
- **Tekstuele context** — Zie hoe het vers in de alinea, het hoofdstuk en het boek eromheen past.
- **Belangrijkste thema's** — Ontdek de grote ideeën die dit vers aan de Bijbeltheologie bijdraagt.
- **Toepassen op mijn leven** — Ontvang praktische, persoonlijke toepassingen waar u vandaag iets mee kunt.
- **Een gebed genereren** — Maak van het vers een gebed naar zijn taal en waarheden.
- **Een preekcontour genereren** — Ontvang een contour met drie punten, inleiding en conclusie, klaar om te preken.

Tik op een starter en de AI begint onmiddellijk. U kunt doorvragen met eigen vragen, om verduidelijking vragen of het gesprek een nieuwe richting sturen.

### Doorvragen als een echt gesprek

De AI onthoudt de laatste paar berichten in de chat, dus u kunt natuurlijk dieper graven:

- "Kunt u dat eenvoudiger zeggen?"
- "Wat zegt het oorspronkelijke Grieks hier?"
- "Toon me kruisverwijzingen die hierbij horen."
- "Vergelijk dit vers in drie verschillende vertalingen."
- "Hoe zou dit er op een moderne werkplek uitzien?"
- "Geef me nog drie toepassingen voor een ouder."

Het gesprek blijft aan het vers gekoppeld, dus elk antwoord is geworteld in de tekst die u leest.

### Tik op een willekeurige Bijbelverwijzing

Noemt de AI een ander vers — bijvoorbeeld "Dit weerspiegelt Romeinen 8:28" — dan verschijnt de verwijzing als een **tikbare link**. Tik erop en de app springt naar dat gedeelte in de Bijbellezer. U kunt de keten van verwijzingen verkennen zonder het gesprek te verlaten.

## Wat de AI verder kan dan verschat

Theophilus heeft toegang tot de volledige inhoud van Theodia — Bijbels, commentaren, lexicons, woordenboeken, boeken, stichtelijke lezingen, uw notities, bladwijzers en markeringen. Dit betekent dat in de praktijk.

### Schrift lezen en navigeren

- **Elk vers of hoofdstuk lezen** — "Lees Johannes 3:16 in de WEB" of "Lees Psalm 23 voor."
- **Gedeelten in de lezer openen** — "Breng me naar Genesis 1" of "Open Romeinen 8:28."
- **Versies vergelijken** — "Toon me Johannes 3:16 in al mijn Bijbels."
- **De Bijbel doorzoeken** — "Vind verzen over vergeving" of "Zoek 'vrede die alle begrip te boven gaat.'"
- **Kruisverwijzingen ophalen** — "Welke andere verzen horen bij Jesaja 53:5?"
- **Sectiekoppen lezen** — "Wat zijn de tussentitels in Matteüs 5?"

### Brontalen verkennen

- **Lexiconnaslag** — "Wat betekent het Griekse woord 'agape' in Johannes 3:16?" of "Zoek Strong's G26 op."
- **Morfologie** — "Ontleed de Griekse werkwoorden in Romeinen 8:28" of "Wat betekent morfologiecode V-PAI-3S?"
- **Woordinfo** — De AI kan dezelfde woord-voor-woord-uitsplitsing zien die u in de app ziet — transliteratie, vertaling, grammatica en Strong's-nummers.

### Commentaren en studieboeken lezen

- **Verscommentaar** — "Wat zegt Matthew Henry over Efeziërs 2:8?"
- **Hoofdstukcommentaar** — "Geef me de hoofdstukoverzichten voor Romeinen 8."
- **Boekcommentaar** — "Vat het commentaar op boekniveau over Openbaring samen."
- **Studieboeken** — "Lees me een hoofdstuk uit Hymn Lyrics English" of "Zoek in mijn boeken naar 'geduld.'"
- **Stichtelijke lezingen** — "Lees de stichtelijke lezing van vandaag" of "Vind een stichtelijke lezing over angst."

### Woordenboeken doorzoeken

- "Wie was Melchizedek?"
- "Wat zegt het Bijbelwoordenboek over Gilgal?"
- "Zoek 'propitiation' op in Easton's."

### Uw studieleven beheren

De AI kan op uw persoonlijke gegevens handelen — altijd lokaal op uw apparaat opgeslagen:

- **Bladwijzers** — "Voorzie dit vers in mijn map Preekvoorbereiding van een bladwijzer" of "Toon mijn bladwijzers."
- **Markeringen** — "Markeer Johannes 3:16 in geel" of "Toon al mijn markeringen."
- **Notities** — "Maak een Bijbelnoot bij dit vers" of "Lees mijn notities bij Genesis 1."
- **Studienotities** — "Sla dit gesprek op als studienotitie" of "Maak een nieuw studienotitieboek genaamd Romeinen-studie."
- **Mappen** — "Maak een map genaamd Ochtendstichting" of "Verplaats mijn bladwijzer van Johannes 3:16 naar de map Gebed."

### App-instellingen veranderen

- "Wissel naar de donkere modus."
- "Maak de BSB mijn standaardbijbel."
- "Zet parallelle Bijbels aan met de NET."
- "Vergroot de tekstgrootte."

## Voorlezen

- "Lees Psalm 23 voor" — De AI kan tekst-naar-spraak activeren voor elk gedeelte, boek of notitie.
- "Stop met lezen" — Pauzeer TTS op elk moment.

## Uw gesprekken opslaan

Elk AI-verschat kan worden opgeslagen. Tik op het menu in het chatpaneel en kies:

- **Opslaan als Bijbelnoot** — Voegt het volledige gesprek toe aan de versnoot in de Bijbellezer.
- **Opslaan als studienotitie** — Bewaart het gesprek in uw studienotitieboek voor later gebruik.

Zo wordt een snelle AI-verkenning permanent studiemateriaal dat u opnieuw kunt bekijken, bewerken of gebruiken voor preken.

## Het volledige AI-tabblad

Naast het verschatpaneel heeft Theodia een speciaal tabblad **AI** in de onderste navigatie. Dit is een vrijvormige chat waarin u alles kunt vragen — geen vers vooraf gekozen. Gebruik het voor:

- Themastudies door de hele Bijbel
- Preekonderzoek en uitlijnen
- Vergelijken van theologische thema's tussen boeken
- Dagelijkse stichting en gebedsprompts
- Bijbeltrivia en leesplannen
- App-hulp — "Hoe werken parallelle Bijbels?"

Uw gesprekken worden automatisch opgeslagen. U kunt terugkeren naar oude chats, nieuwe beginnen en oude gesprekken verwijderen.

## Ideeën om te beginnen

Hier zijn een paar spannende manieren om de AI te gebruiken. Kies er een en probeer die vandaag.

**Persoonlijke groei**

- "Leg Filippenzen 4:6–7 uit en geef me een gebed voor wanneer ik angstig ben."
- "Wat zegt de Bijbel over rust? Vind vijf verzen en leg elk uit."

**Gezin en opvoeding**

- "Hoe zou Efeziërs 6:4 het moderne ouderschap moeten leiden? Geef me drie praktische regels."
- "Vind verzen over kinderen opvoeden en lees ze aan me voor."

**Preek- en lesvoorbereiding**

- "Stel een preek van 25 minuten over Romeinen 8:28 op met inleiding, drie punten en conclusie."
- "Wat zeggen mijn commentaren over de 'wapenrusting van God' in Efeziërs 6?"
- "Vergelijk de bergrede in Matteüs met de versie van Lucas. Wat zijn de verschillen?"

**Brontaalstudie**

- "Toon me de morfologie van elk woord in Johannes 1:1."
- "Wat is het verschil tussen 'agape' en 'philia' in het Nieuwe Testament?"

**Stichtelijke diepgang**

- "Lees de stichtelijke lezing van vandaag en verbind die met een vers in de Psalmen."
- "Geef me een zeven dagen durende stichtelijke contour over de vrucht van de Geest."

**Kruisverwijsketens**

- "Begin bij Jesaja 53:5 en volg het thema 'wonden' en 'genezing' door het Nieuwe Testament."
- "Waar verschijnt het begrip 'verbond' van Genesis tot Hebreeën?"

**Geheugen en herhaling**

- "Toets me over de boeken van de Bijbel op volgorde."
- "Maak een studienotitie die het hoofdpunt van elk hoofdstuk in Romeinen samenvat."

## Een paar belangrijke opmerkingen

- De AI is een **hulpmiddel**, geen vervanging voor de Bijbel of pastorale begeleiding. Vergelijk haar antwoorden altijd met de Schrift zelf.
- Wanneer u de AI gebruikt, reizen uw vragen over het internet naar de servers van de aanbieder. De meeste aanbieders trainen niet op uw gegevens, maar de tekst verlaat wel uw apparaat.
- De AI kan fouten maken. Gebruik commentaren, lexicons en de Bijbeltekst zelf als uw uiteindelijke autoriteit.

## Samenvatting

De AI van Theodia is ontworpen om Bijbelstudie sneller, dieper en persoonlijker te maken. Of u nu een uitleg in één zin van een verwarrend vers wilt, een volledige preekcontour, een Griekse woordstudie of een kruisverwijsketen die de hele Bijbel bestrijkt, Theophilus is klaar om te helpen. Tik op een vers, stel een vraag en kijk waar het gesprek leidt.
