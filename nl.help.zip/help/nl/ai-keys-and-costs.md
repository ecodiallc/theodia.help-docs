---
title: API-sleutels en kosten
level: advanced
categories: ai
summary: Waarom u een API-sleutel nodig heeft, hoe u er een krijgt en wat het gebruik van een extern AI-model gewoonlijk kost.
---

# API-sleutels en kosten

> **Modus:** De AI-assistent vereist de modus **Geleerde**. U kunt van modus wisselen in **Instellingen** → **App-gebruikersmodus**.

De AI-assistent verbindt met externe AI-modellen. Wilt u er een gebruiken, dan heeft u een API-sleutel nodig. Deze pagina legt uit waarom, hoe u er een krijgt en wat die gewoonlijk kost.

## Waarom u een API-sleutel nodig heeft

Een extern AI-model woont op een server op het internet. De API-sleutel is als een wachtwoord dat de server vertelt: "Deze persoon mag vragen stellen." Zonder die key antwoordt de server niet.

De app levert geen ingebouwde sleutel. U moet uw eigen account bij een aanbieder maken en uw sleutel in de app plakken.

## Hoe u een API-sleutel krijgt

1. Open **Instellingen** in Theodia.
2. Tik op **AI-assistent**.
3. Kies **Extern model**.
4. Kies een aanbieder uit de lijst, of kies **Aangepast** en voer een basis-URL in.
5. Tik op de link naar de sleutelpagina van de aanbieder. Maak een account als u er geen heeft.
6. Genereer een nieuwe API-sleutel op de site van de aanbieder.
7. Kopieer de sleutel en plak haar in Theodia.
8. Tik op **Verbinding testen** om te controleren dat het werkt.

## Ondersteunde aanbieders

Theodia kan verbinden met elke aanbieder die een OpenAI-compatibele API gebruikt. Dit zijn degen met vooraf ingestelde links in de app:

- **GitHub Models** — github.com/marketplace/models (gratis dagelijkse laag, aanbevolen)
- **OpenAI** — platform.openai.com
- **OpenRouter** — openrouter.ai
- **Anthropic** — console.anthropic.com
- **Groq** — console.groq.com
- **Mistral** — console.mistral.ai
- **Together AI** — api.together.xyz

U kunt ook een **Aangepaste** basis-URL gebruiken als u uw eigen server draait of een andere dienst gebruikt.

## Wat kost het?

De meeste aanbieders rekenen per **token**. Een token is ongeveer een woord of een deel van een woord. U betaalt voor de tokens die u stuurt (uw vraag) plus de tokens die de AI terugstuurt (het antwoord).

### Typische prijzen

Prijzen veranderen, maar dit is een ruw beeld per midden 2026:

- **Kleine snelle modellen** (zoals goedkopere eindpunten in de GPT-3.5-klasse) kosten een fractie van een cent per duizend tokens.
- **Modellen uit het middensegment** (zoals GPT-4o of Claude Sonnet) kosten meestal enkele centen per duizend tokens.
- **Grote redeneermodellen** (zoals GPT-4.5 of Claude Opus) kunnen tien tot twintig cent per duizend tokens kosten.

Een typische Bijbelvraag in Theodia kan in totaal enkele honderden tot een paar duizend tokens gebruiken. Dat betekent dat de meeste vragen ergens van **onder een cent tot enkele centen** kosten.

### Tips om de kosten laag te houden

- Begin met een goedkoper model. De meeste Bijbelvragen hebben het duurste model niet nodig.
- Gebruik Groq of OpenRouter als u verschillende modellen wilt proberen en prijzen wilt vergelijken.
- Houd uw verbruiksdashboard op de site van de aanbieder in de gaten.

## GitHub Models

[GitHub Models](https://github.com/marketplace/models) biedt een gratis laag zonder abonnement. Alles wat u nodig heeft is een gratis GitHub-account en een personal access token met toestemming om modellen te lezen.

**Hoe in te stellen:**

1. Ga naar [github.com/settings/tokens](https://github.com/settings/tokens) en maak een **Personal access token (classic)**.
2. Geef hem het `models:read`-bereik (of selecteer gewoon de models-toestemming).
3. Kies in Theodia **GitHub Models** als aanbieder en plak uw token.

**Gratis-laag-modellen:**

- `openai/gpt-4.1-nano` — **15 verzoeken per minuut, 150 verzoeken per dag**
- `openai/gpt-4.1-mini` — **15 verzoeken per minuut, 150 verzoeken per dag**
- `openai/gpt-4.1` — **10 verzoeken per minuut, 50 verzoeken per dag**
- `openai/gpt-4o` — **10 verzoeken per minuut, 50 verzoeken per dag**

Deze limieten resetten dagelijks en zijn ruim voldoende voor gewone Bijbelstudie.

Zie voor een volledige stapsgewijze rondleiding met schermafbeeldingen de speciale gids [GitHub Models](theodia://help/github-models).

## Privacy-opmerking

Wanneer u een extern AI-model gebruikt, toont de app eerst een toestemmingsvraag die uitlegt wat er wordt gestuurd: uw berichten, de vers- of hoofdstukcontext, hulpmiddelaanroepen en resultaten, de naam van het ingestelde model en uw API-sleutel in de aanvraagheader. Het verzoek gaat rechtstreeks naar het door u ingestelde eindpunt, niet via Theodia. De meeste aanbieders gebruiken uw gegevens niet om hun modellen te trainen, maar de tekst verlaat wel uw apparaat. U kunt de toestemming op elk moment veranderen of intrekken in **Instellingen → AI-assistent → Gegevensdeling met externe AI**.

## Samenvatting

- U heeft een API-sleutel nodig om de AI-assistent te gebruiken.
- Maak een account bij een aanbieder, genereer een sleutel en plak haar in Theodia.
- De meeste vragen kosten enkele centen of minder.
