---
title: Betere AI-prompts schrijven
level: advanced
categories: ai
summary: Hoe u de AI-assistent vraagt op een manier die goede antwoorden oplevert.
---

# Betere AI-prompts schrijven

> **Modus:** De AI-assistent vereist de modus **Geleerde**. U kunt van modus wisselen in **Instellingen** → **App-gebruikersmodus**.

Een "prompt" is de vraag of instructie die u de AI geeft. Bessere prompts leveren betere antwoorden op. Deze gids toont u hoe.

## Wees specifiek

Slecht: "Vertel me over liefde."
Beter: "In 1 Korintiërs 13, wat voor soort liefde beschrijft Paulus, en hoe verschilt die van romantische liefde?"

Hoe meer detail u geeft, hoe nuttiger het antwoord.

## Geef context

Slecht: "Wat betekent dit vers?"
Beter: "Ik lees Romeinen 8 met een kleine groep. Wat betekent 'geen veroordeling' in dit hoofdstuk, en hoe hangt dat samen met de rest van het hoofdstuk?"

Context helpt de AI haar antwoord op uw situatie af te stemmen.

## Vraag één ding tegelijk

Slecht: "Vertel me over gebed, geloof en genezing."
Beter: "Vertel me eerst over gebed. Daarna vraag ik over geloof."

Eén ding tegelijk vragen houdt antwoorden gericht.

## Vraag de AI een rol aan te nemen

U kunt de AI vragen in een bepaalde toon te antwoorden. Bijvoorbeeld:

- "Antwoord alsof u een nieuwe christen onderricht."
- "Antwoord als een Bijbelgeleerde."
- "Antwoord voor een kind van 10."

De AI stemt haar antwoord af op de rol.

## Gebruik vervolgvragen

Is het eerste antwoord niet helemaal goed, stel dan een vervolgvraag:

- "Kunt u dat eenvoudiger zeggen?"
- "Kunt u me een voorbeeld geven?"
- "Wat zegt het oorspronkelijke Grieks?"
- "Waar komt dit verder in de Bijbel voor?"

Een goed gesprek is een heen-en-weer. De AI onthoudt de laatste paar berichten.

## Controleer de antwoorden van de AI

De AI kan fouten maken. Ze is een hulpmiddel, geen leraar.

- Vergelijk het antwoord van de AI met de verzen waarnaar ze u wijst.
- Gebruik de commentaren en lexicons in de app voor een tweede mening.
- Gaat het antwoord over leerstellingen, vraag dan een pastor of een vertrouwde vriend.

## Veelvoorkomende promptpatronen

Hier zijn er een paar die goed werken:

- "Leg dit vers aan me uit alsof ik een nieuwe christen ben."
- "Wat is het hoofdpunt van dit hoofdstuk in één zin?"
- "Som drie toepassingen voor mijn dagelijkse leven uit dit gedeelte op."
- "Welke vragen zou ik over dit vers moeten stellen voordat ik het preek?"
