---
title: App-gebruikersmodus
level: beginner
categories: [user-mode]
summary: Kies tussen de modi Lezer, Standaard en Geleerde om te bepalen welke functies in de app beschikbaar zijn.
---

# App-gebruikersmodus

Theodia biedt drie gebruikersmodi die bepalen welke functies u ziet. Kies degene die past bij hoe u de app wilt gebruiken.

## Lezer

De eenvoudigste modus. Lezermodus is voor Bijbellezen zonder afleiding.

- Elke Bijbelvertaling lezen
- De Focusmodus gebruiken voor rustig, schermvullend lezen
- Door boeken en hoofdstukken navigeren
- Geen studiehulpmiddelen, geen AI, geen bladwijzers, geen markeringen

Lezermodus is ideaal als u wilt dat Theodia aanvoelt als een zuivere digitale Bijbel zonder extra's.

## Standaard

Standaardmodus voegt functies voor alledag toe voor persoonlijke Bijbelstudie.

Alles uit Lezer, plus:

- Bladwijzers, markeringen en notities
- Tekst-naar-spraak
- De Studiemodus-lezer met versmenu
- Parallelle Bijbels
- Opdrachtinvoer
- De Bijbel doorzoeken
- Dagelijkse stichtelijke lezingen en ingebouwde boeken

Standaardmodus is de juiste keuze voor de meeste gebruikers die de Bijbel willen lezen, markeren en doorzoeken zonder geavanceerde studiehulpmiddelen.

## Geleerde

De volledige modus. Geleerdemodus ontgrendelt elk hulpmiddel in Theodia voor diepe Bijbelstudie.

Alles uit Standaard, plus:

- Commentaren en lexicons
- Kruisverwijzingen
- Bijbelwoordenboek
- Woordinfo (Strong's-naslag)
- AI-assistent en AI-commentaar
- Launcher-menu

Geleerdemodus is ontworpen voor pastors, seminariedocenten en iedereen die brontaalhulpmiddelen en AI-ondersteunde studie-hulpmiddelen wilt.

## Van modus wisselen

1. Open **Instellingen**.
2. Tik op **App-gebruikersmodus**.
3. Kies **Lezer**, **Standaard** of **Geleerde**.

De wijziging werkt onmiddellijk door. Menu's en knoppen waar u in uw huidige modus geen toegang toe heeft, worden verborgen.

## Een modus kiezen

- **Lezer** — U wilt alleen de Bijbel lezen, niets anders.
- **Standaard** — U wilt bladwijzers, markeringen, notities, zoeken en stichtelijke lezingen.
- **Geleerde** — U wilt elk studiehulpmiddel, inclusief AI, commentaren en lexicons.

U kunt op elk moment van modus wisselen. Uw bladwijzers, markeringen en notities worden nooit verwijderd wanneer u van modus wisselt; ze worden gewoon verborgen totdat u terugkeert naar een modus die ze ondersteunt.
