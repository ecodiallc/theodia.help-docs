---
title: Back-up van uw gegevens
level: everyday
categories: settings
summary: Hoe u uw notities, markeringen, bladwijzers en geheimen opslaat en herstelt.
---

# Back-up van uw gegevens

Uw notities, markeringen, bladwijzers en instellingen worden op uw apparaat opgeslagen. Verliest u uw telefoon, krijgt u een nieuwe of verwijdert u de app, dan kunnen die gegevens verloren gaan. Deze gids toont u hoe u er een back-up van maakt.

## De back-upinstellingen openen

1. Open **Instellingen**.
2. Tik op **App-back-up**.

## Een app-back-up maken

1. Open **Instellingen**.
2. Tik op **App-back-up**.
3. Tik op **App-back-up maken**.
4. Kies een map op uw apparaat om het bestand op te slaan. U kunt ook een cloudschijf kiezen.
5. De app maakt één bestand met al uw gegevens. Het bestand eindigt op `.zip`.

## Hoe vaak een back-up maken

Maak een back-up:

- Nadat u veel notities heeft geschreven.
- Voordat u het besturingssysteem van uw apparaat bijwerkt.
- Voordat u de app verwijdert of van telefoon wisselt.

Een goede gewoonte is één back-up per maand. Sommige mensen back-uppen elke week.

## Vanuit een app-back-up herstellen

1. Open **Instellingen**.
2. Tik op **App-back-up**.
3. Tik op **Herstellen vanuit app-back-up**.
4. Kies het `.zip`-back-upbestand.
5. Kies voor elk gegevenstype (notities, markeringen, bladwijzers enz.) of u wat op het apparaat staat behoudt, het vervangt door de back-up of overslaat.
6. Tik op **Herstellen**.

De app vervangt uw gegevens door de gegevens in de back-up. Dit omvat:

- Notities
- Markeringen
- Bladwijzers
- Bladwijzermappen
- Instellingen (thema, tekstgrootte, taal)

## Geheimen-back-up

Uw **App-back-up** omvat **geen** gevoelige geheimen zoals uw AI-API-sleutel of GitHub-token. Om die apart te back-uppen, gebruikt u **Geheimen-back-up**.

### Een geheimen-back-up opslaan

1. Open **Instellingen**.
2. Tik op **App-back-up**.
3. Tik onder **Geheimen-back-up** op **Geheimen-back-up opslaan**.
4. Voer een sterk wachtwoord in en bevestig het.
5. De app versleutelt uw geheimen en deelt het versleutelde bestand. Bewaar het op een veilige plaats.

### Een geheimen-back-up herstellen

1. Open **Instellingen**.
2. Tik op **App-back-up**.
3. Tik onder **Geheimen-back-up** op **Geheimen-back-up herstellen**.
4. Kies het versleutelde geheimen-back-upbestand.
5. Voer hetzelfde wachtwoord in dat u gebruikte bij het opslaan.
6. Uw geheimen zijn hersteld.

> **Belangrijk:** Vergeet u het wachtwoord, dan kunnen de geheimen niet worden teruggehaald. Er is geen reset.

## Dingen om te weten

- Een herstel **vervangt** de categorieën die u koos. Alles wat u na de back-up toevoegde, gaat voor die categorieën verloren.
- Een app-back-up is één `.zip`-bestand. Bewaar het op een veilige plaats.
- U kunt het bestand kopiëren, verplaatsen of in een cloudservice opslaan.
- App-back-ups omvatten niet de Bijbelvertalingen zelf. Die kunnen opnieuw worden gedownload via **Instellingen** → **Bronnen beheren**.
- Geheimen-back-ups worden met uw wachtwoord versleuteld. Kies een wachtwoord dat u zult onthouden.

## Tip

Heeft u meer dan één apparaat, dan kunt u het back-upbestand naar elk apparaat kopiëren en het daar herstellen. Uw gegevens zijn dan op beide hetzelfde.
