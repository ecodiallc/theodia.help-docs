---
title: Verzen van bladwijzers voorzien
level: everyday
categories: [annotate, read]
summary: Hoe u verzen opslaat zodat u ze terugvindt.
---

# Verzen van bladwijzers voorzien

> **Modus:** Bladwijzers zijn beschikbaar in de modi **Standaard** en **Geleerde**. De Focusmodus is alleen voor rustig lezen zonder afleiding. U kunt van modus wisselen in **Instellingen** → **App-gebruikersmodus**.

Een bladwijzer slaat een vers of een boekhoofdstuk op zodat u het terugvindt. Bladwijzers zijn als leeslinten in een boek.

## Een vers van een bladwijzer voorzien

1. Open het vers.
2. Tik op het vers om het menu te openen.
3. Tik in het menu op **Bladwijzer**. Een sterretje markeert het vers als opgeslagen.

Een vinkje op het pictogram betekent dat het vers nu een bladwijzer heeft.

## Een boekhoofdstuk van een bladwijzer voorzien

Tijdens het lezen van een boek (geen Bijbel) kunt u het hele hoofdstuk voorzien van een bladwijzer:

1. Open het hoofdstuk.
2. Tik op het pictogram **Bladwijzer** bovenaan het scherm.

## Uw bladwijzers bekijken

Tik onderaan op het tabblad **Bladwijzers**. U ziet een lijst met elk vers en boekhoofdstuk dat u heeft opgeslagen.

## Een bladwijzer verwijderen

- **Eén vers:** Open het vers. Tik op het vers, tik daarna opnieuw op het pictogram **Bladwijzer**. Het vinkje verdwijnt.
- **Vanuit de lijst:** Houd in het tabblad **Bladwijzers** een bladwijzer lang ingedrukt. Er verschijnt een klein menu. Tik op **Verwijderen**. (U kunt ook op het kleine knopje × op de regel tikken.)

## Organiseren met mappen

U kunt bladwijzers in mappen plaatsen. Zo kunt u bijvoorbeeld een map "Preekvoorbereiding" hebben en een andere "Bemoediging".

Een map maken:

1. Open het tabblad **Bladwijzers**.
2. Tik bovenaan op **Mappen beheren**.
3. Tik bovenaan de mappenlijst op **+ Map maken**.
4. Typ een naam en tik op **Opslaan**.

U kunt geen twee mappen met dezelfde naam maken. Bestaat een naam al, dan verschijnt er een foutmelding in het vak voor het maken van de map, zodat u hem kunt aanpassen en opnieuw proberen.

Een bladwijzer in een map plaatsen:

1. Houd in het tabblad **Bladwijzers** een bladwijzer lang ingedrukt.
2. Tik op **Opslaan in map**.
3. Kies de map en tik op **Gereed**.

## Bladwijzers importeren

U kunt bladwijzers uit andere apps en bestanden in Theodia brengen.

Ga naar **Instellingen** → **Bladwijzers** → **Bladwijzers importeren**. Kies **Importeren uit bestand** of plak vanaf het klembord. De app herkent het formaat automatisch.

### Ondersteunde formaten

**Eigen JSON-export** — Het formaat van Theodia's eigen exportfunctie. Dit behoudt mappen en aanmaakdata.

**Netscape-bladwijzer-HTML** — Het formaat dat Chrome, Firefox en Safari gebruiken bij het exporteren van bladwijzers. Mappen blijven behouden.

**CSV** — Een spreadsheet met kolommen. De app zoekt naar de kolommen `url` en `folder` (of `href` / `category`). Voorbeeld:

```csv
url,folder
/bible/KJV/John/3,Favorites
/bible/KJV/Genesis/1,Sermon Prep
```

**Platte tekst** — Elke regel is een Bijbelverwijzing, een app-URL of een mapopdracht. Voorbeeld:

```
folder: Favorites
John 3:16
Genesis 1:1
folder: Sermon Prep
Matthew 5:1
```

- Regels die beginnen met `folder: <naam>` stellen de actieve map in voor alle daaropvolgende bladwijzers.
- Bijbelverwijzingen zoals `John 3:16` worden omgezet naar bladwijzers in uw standaardbijbel.
- App-URL's zoals `/bible/KJV/John/3#v3_16` of `/book/MyBook/1` worden direct geïmporteerd.
- Regels die beginnen met `#` of `//` worden als commentaar behandeld en overgeslagen.

### Tips voor het importeren

- Dubbele bladwijzers worden automatisch overgeslagen.
- Externe URL's (zoals BibleGateway-links) worden waar mogelijk omgezet naar app-bladwijzers.
- Bestaat een map uit het importbestand al, dan worden bladwijzers in de bestaande map geplaatst.

## Tips

- U kunt hetzelfde vers in vele vertalingen van een bladwijzer voorzien. Ze verschijnen allemaal in de lijst.
- Bladwijzers blijven op uw apparaat. Ze synchroniseren niet met de cloud.
- Zie de gids [Back-up van uw gegevens](theodia://help/backups) om ze veilig te houden.

## Bladwijzers in PDF's

PDF's hebben hun eigen bladwijzers, apart van uw Bijbelbladwijzers. Tik tijdens het lezen van een PDF op de knop **Bladwijzer** in de werkbalk van de lezer om de huidige pagina op te slaan, geef hem een naam en spring er later naartoe. Elke PDF heeft zijn eigen lijst — zie [PDF's](theodia://help/pdfs).
