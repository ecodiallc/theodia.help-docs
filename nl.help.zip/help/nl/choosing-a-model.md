---
title: Een AI-model kiezen
level: advanced
categories: ai
summary: Hoe u een model kiest dat goed samenwerkt met de ingebouwde hulpmiddelen en mogelijkheden van Theodia.
---

# Een AI-model kiezen

> **Modus:** De AI-assistent vereist de modus **Geleerde**. U kunt van modus wisselen in **Instellingen** → **App-gebruikersmodus**.

Niet elk AI-model werkt op dezelfde manier in Theodia. De beste ervaring komt van een model dat **tool calling** ondersteunt — het vermogen van de AI om de ingebouwde functies van Theodia te gebruiken, zoals Bijbelverzen opzoeken, zoeken, commentaren lezen en door de app navigeren.

## Wat is tool calling?

Wanneer u de AI van Theodia een vraag stelt, kan de AI meer dan alleen praten. Ze kan ook **handelen**. Bijvoorbeeld:

- U zegt: "Toon me Johannes 3:16 in de ESV." De AI roept een hulpmiddel aan om dat vers in de lezer te openen.
- U zegt: "Wat zeggen mijn commentaren over Romeinen 8:28?" De AI roept een hulpmiddel aan om commentaarinhoud op te halen.
- U zegt: "Sla dit vers op als bladwijzer." De AI roept een hulpmiddel aan om een bladwijzer te maken.

Modellen die geen tool calling ondersteunen, kunnen u alleen tekstantwoorden geven. Ze kunnen niets opzoeken, navigeren of iets in de app veranderen.

## Welke modellen ondersteunen hulpmiddelen?

### Externe modellen

De meeste moderne externe modellen van grote aanbieders ondersteunen OpenAI-compatibele tool calling. In het algemeen:

- **Grote modellen** (zoals GPT-4o, Claude Sonnet/Opus, Gemini Pro) behandelen hulpmiddelen betrouwbaar en kunnen meerdere hulpmiddelaanroepen in één gesprek aaneenschakelen. Aanbiedernamen en model-ID's worden voor het gemak in de app getoond; de werkelijke service waarmee u verbindt, is die met het door u ingestelde eindpunt en de door u ingestelde sleutel.
- **Kleinere of goedkopere modellen** ondersteunen mogelijk hulpmiddelen maar kunnen minder betrouwbaar zijn. Ze kunnen een hulpmiddelaanroep negeren of verkeerd opmaken.
- **Zeer oude of gespecialiseerde modellen** ondersteunen vaak helemaal geen hulpmiddelen.

Bij twijfel, test het model in Theodia. Vraag "Toon me Genesis 1:1" of "Zoek de Bijbel door naar verzen over liefde." Opent het vers of verschijnen zoekresultaten, dan werkt tool calling.

## Aanbevolen modellen voor Theodia

Dit zijn goede keuzes die kosten, kwaliteit en hulpmiddelondersteuning in balans brengen:

- **OpenAI GPT-4o** — uitstekende hulpmiddelondersteuning, snel, behandelt complexe meerstapsvragen goed.
- **Anthropic Claude Sonnet / Opus** — zeer betrouwbaar hulpmiddelgebruik, geweldig voor lange gedeelten en gedetailleerde studie.
- **Groq** (verschillende modellen) — snelle inferentie, vaak gratis of zeer goedkoop, hulpmiddelondersteuning verschilt per model.
- **OpenRouter** — laat u vele modellen proberen vanuit één account. Zoek naar modellen die "function calling" of "tools" in hun mogelijkheden vermelden.
- **[GitHub Models](theodia://help/github-models)** — de aanbevolen gratis aanbieder. Toegang tot OpenAI, Anthropic en andere modellen via uw GitHub-account met een royale dagelijkse gratis laag. Gebruikt dezelfde `openai/gpt-4o`-stijl model-ID's.

## Modellen om te vermijden

- **Zuivere tekstvoltooiingsmodellen** (zoals GPT-3-basis of ruwe LLaMA zonder instructieafstemming) ondersteunen meestal geen hulpmiddelen.
- **Alleen-afbeelding- of visiemodellen** gericht op beelden in plaats van tekst, missen mogelijk hulpmiddelondersteuning.
- **Zeer kleine modellen** onder de 1 miljard parameters gebruiken hulpmiddelen waarschijnlijk niet correct, zelfs niet als de API beweert dat ze die ondersteunen.

## Hoe u hulpmiddelondersteuning test

Theodia controleert automatisch op hulpmiddelondersteuning. Nadat u een model in **Instellingen → AI-assistent** heeft ingesteld, tikt u op **Verbinding testen**. Zodra de verbinding slaagt, stuurt de app een tweede verzoek met een voorbeeldhulpmiddeldefinitie. U ziet een van twee resultaten:

- **✓ Hulpmiddelen ondersteund** — Het model accepteert hulpmiddelaanroepen en kan de ingebouwde functies van Theodia gebruiken.
- **✗ Hulpmiddelen niet ondersteund** — Het model weigert het hulpmiddelverzoek. Het antwoordt alleen in tekst en kan geen verzen openen, zoeken of bladwijzers voor u beheren.

Ziet u "Hulpmiddelen niet ondersteund", dan kan het model nog steeds werken als een gewone tekstchat-assistent, maar u krijgt de geïntegreerde, handvrije ervaring niet.

U kunt ook handmatig verifiëren door de AI iets te laten doen:

- "Toon me Matteüs 5:3 in de KJV." — Zou het vers in de lezer moeten openen.
- "Wat zegt het lexicon over het woord 'agape' in Johannes 3:16?" — Zou lexicongegevens moeten teruggeven.
- "Zoek de Bijbel door naar verzen over vergeving." — Zou zoekresultaten moeten teruggeven.
- "Voorzie Marcus 12:30 van een bladwijzer." — Zou een bladwijzer moeten maken.

Geeft de AI u een tekstbeschrijving in plaats van het ding werkelijk te doen, dan worstelt het model met zijn hulpmiddelen, ook al rapporteerde de app ondersteuning.

## Wat als mijn model geen hulpmiddelen ondersteunt?

U kunt het nog steeds gebruiken. De AI antwoordt in tekst, en u kunt zelf handmatig verzen opzoeken, zoeken en door de app navigeren. Maar u mist de handvrije, geïntegreerde ervaring die Theodia krachtig maakt.

## Samenvatting

- Kies een model met **tool calling / function calling**-ondersteuning voor de beste Theodia-ervaring.
- **Grote externe modellen** behandelen hulpmiddelen het meest betrouwbaar.
- Test elk model met eenvoudige opdrachten zoals "Toon me Genesis 1:1" om hulpmiddelondersteuning te verifiëren.
