---
title: Een Bijbelvertaling kiezen
level: beginner
categories: [read, study]
summary: Een eenvoudige gids voor het kiezen van de vertaling die het beste bij u past.
---

# Een Bijbelvertaling kiezen

Een Bijbel"vertaling" is de poging van iemand om de Bijbel in woorden te zetten die u kunt lezen. Verschillende vertalingen klinken verschillend. Sommige zijn woord-voor-woord. Sommige zijn gedachte-voor-gedachte. Er is geen verkeerde keuze. Kies degene die voor u het prettigst leest.

## Twee hoofdstijlen

**Woord-voor-woordvertalingen** proberen dezelfde woorden aan te houden als de oorspronkelijke talen (Hebreeuws en Grieks). Ze kunnen moeilijker te lezen zijn maar voelen dichter bij de bron. Voorbeelden: KJV, WEB.

**Gedachte-voor-gedachtevertalingen** proberen de betekenis van het origineel in woorden te zetten die mensen vandaag gebruiken. Ze zijn gemakkelijker te lezen. Voorbeelden: BSB, UST.

## Enkele populaire vertalingen

- **KJV (King James Version).** Oud-Engelse stijl. Geliefd bij veel lezers.
- **WEB (World English Bible).** Woord-voor-woord. Modern Engels in het publieke domein.
- **BSB (Berean Standard Bible).** Gedachte-voor-gedachte. Gemakkelijk te lezen.
- **UST (unfoldingWord Simplified Text).** Gedachte-voor-gedachte. Gebruikt eenvoudig, helder Engels.

## Hoe u er een uitprobeert

U kunt zoveel vertalingen installeren als u wilt. Lees hetzelfde vers in twee of drie. Kijk welke u het meeste helpt.

## Hoe u vergelijkt

Open een hoofdstuk en tik bovenaan op de vertalingsnaam om te wisselen. De functie **Vergelijken** (zie de gids [Vertalingen vergelijken](theodia://help/compare-translations)) toont twee vertalingen naast elkaar.
