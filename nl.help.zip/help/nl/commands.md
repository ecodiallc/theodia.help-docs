---
title: Opdrachten
level: everyday
categories: [layout, study]
summary: Met de Opdracht-invoer springt u met een korte opdracht naar bijna elke functie. Leer de ondersteunde formaten en voorbeelden.
---

# Opdrachten

Met de **Opdracht**-invoer springt u door een korte instructie te typen naar bijna elk deel van Theodia. U kunt die gebruiken vanaf het tabblad Beginscherm of vanuit het **Launcher-menu** (het pictogram **▼** in de kop).

## Hoe het werkt

1. Tik op het Opdrachtvak.
2. Typ een opdracht.
3. Tik op de ga-toets van uw toetsenbord.

De app leest de opdracht en brengt u meteen naar het juiste scherm.

## Geen slash-voorvoegsel

Opdrachten gebruiken **geen** `/`-voorvoegsel. Ze worden als platte tekst ingevoerd:

```
john 3:16
search love
backup
```

Typt u `/settings`, dan maakt het voorafgaande `/` de opdracht onherkenbaar.

## Bijbelverwijzingen

Typ een willekeurige Bijbelverwijzing om die in de lezer te openen.

```
psalms 23
john 3:16
matthew 5:1
1 cor 15:10
```

Boeknamen kunnen op volledige naam of afkorting worden gematcht. In niet-Engelse interfacetalen kunt u boeknamen ook in de actieve taal typen.

## Zoeken

```
search abraham
search love
search faith not works
```

## Bladwijzers, vergelijken, commentaar, kruisverwijzingen en woordinfo

```
bookmark john 3:16
compare genesis 1:1
commentary john 1
aicommentary eph 2:8
xref 1 cor 15:10
word info john 1:1
```

Deze opdrachten openen het genoemde hulpmiddel bij het opgegeven gedeelte.

## Lexicon

Typ een Strong's-nummer om het lexiconitem te openen.

```
g1161
h7225
```

## Stichtelijke lezingen

```
devotional
devotional smith
devotional daily
```

Zonder naam opent dit de lijst met stichtelijke lezingen.

## Navigatieshortcuts

```
notes
highlights
bookmarks
flashcards
playlist
theoscript
resources
read john 3:16
```

Deze springen direct naar het genoemde scherm of openen een gedeelte in de lezer.

## Vertaling wisselen

Typ een vertalingafkorting om ernaar te wisselen.

```
kjv
web
trlit
ohgb
```

Op een lezersscherm wisselt de vertaling ter plaatse. Elders opent hij de vertaling bij uw meest recente gedeelte.

## Gelokaliseerde opdrachtwerkwoorden

De publieke opdrachtwerkwoorden kunnen in de actieve interfacetaal **of** in het Engels worden getypt. Het Engels werkt altijd als terugval. Verborgen opdrachten (instellingenshortcuts, installatieopdrachten, paaseieren) behouden alleen de Engelse syntaxis.

## Hulp

Typ `help` of `commands` in het Opdrachtvak om op elk moment de opdrachtnaslag in de app te openen.
