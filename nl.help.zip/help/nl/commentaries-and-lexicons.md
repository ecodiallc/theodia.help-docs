---
title: Commentaren en lexicons
level: everyday
categories: study
summary: Hoe u woordbetekenissen opzoekt en studienotities leest.
---

# Commentaren en lexicons

> **Modus:** Commentaren en lexicons vereisen de modus **Geleerde**. U kunt van modus wisselen in **Instellingen** → **App-gebruikersmodus**.

Theodia bevat twee studiehulpmiddelen: **commentaren** en **lexicons**. Ze helpen u de Bijbel dieper te begrijpen.

## Wat is een commentaar?

Een commentaar is een boek met studienotities, geschreven door een Bijbelgeleerde. Voor een bepaald vers vertelt een commentaar u de achtergrond, de betekenis en hoe het vers in de rest van de Bijbel past.

## Wat is een lexicon?

Een lexicon is een woordenboek van Bijbelwoorden. Het vertelt u het oorspronkelijke Hebreeuwse of Griekse woord, wat het betekent en hoe het in de Bijbel wordt gebruikt.

## Een commentaar openen

1. Open een hoofdstuk.
2. Tik op een vers.
3. Tik op **Commentaar**.

Er opent een paneel. Het toont notities van een Bijbelgeleerde bij dat vers.

## Een lexicon openen

1. Open een hoofdstuk in een Bijbel die Strong's-nummers bevat.
2. Tik op een Strong's-nummer in het vers (bijvoorbeeld G1234 of H1234).
3. Er opent een paneel met het oorspronkelijke Hebreeuwse of Griekse woord, zijn betekenis en andere verzen die het woord gebruiken.

Strong's-nummers hebben een andere kleur in de vertaaltekst, zodat ze opvallen tussen de gewone woorden.

## Een ander commentaar kiezen

Het commentaar wordt gekozen uit een vervolgkeuzemenu bovenaan het commentaarpaneel zelf. Open het paneel en tik op het vervolgkeuzemenu om de commentaren te zien die u heeft geïnstalleerd. Kies een ander.

## Een ander lexicon kiezen

Het lexicon wordt gekozen uit een vervolgkeuzemenu bovenaan het lexiconpaneel. Open het paneel en tik op het vervolgkeuzemenu om de lexicons te zien die u heeft geïnstalleerd. Kies een ander.

## Ingebouwde bronnen

Theodia wordt geleverd met een ingebouwde set commentaren en lexicons. Deze zitten bij de app en werken offline. Extra commentaren en lexicons kunnen niet apart worden geïnstalleerd of gedownload.

## Wanneer deze gebruiken

- **Commentaren** zijn goed wanneer een vers moeilijk te begrijpen is. De notities geven u de achtergrond.
- **Lexicons** zijn goed voor woordstudies. Ze vertellen u de exacte betekenis van een woord in de brontaal.

## Tip

Heeft een vers een notitie die u wilt bewaren, maak dan een schermafbeelding of kopieer de tekst in een notitie. (Zie de gids [Notities schrijven](theodia://help/notes).)

## Bijbelwoordenboek in gewone taal

Voor Engelse definities van Bijbelwoorden en -begrippen (verbond, verzoening, Farizeeën enzovoort) bevat Theodia ook een hulpmiddel Bijbelwoordenboek. Open het vanuit het versmenu door op **Woordenboek** (📖) te tikken. Het is anders dan het lexicon: lexicons leggen de oorspronkelijke Hebreeuwse en Griekse woorden uit, terwijl het woordenboek het Engelse woord in gewone taal uitlegt. Zie de gids [Bijbelwoordenboek](theodia://help/dictionary) voor gebruik.
