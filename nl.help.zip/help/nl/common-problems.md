---
title: Veelvoorkomende problemen
level: everyday
categories: trouble
summary: Snelle oplossingen voor problemen waar u op kunt stuiten.
---

# Veelvoorkomende problemen

Deze gids behandelt de problemen waar mensen het vaakst op stuiten. Staat uw probleem er niet bij, zie dan de gids [Waar u vragen kunt stellen](theodia://help/getting-more-help).

## De app is traag

1. Sluit andere apps die op de achtergrond draaien.
2. Herstart de app.
3. Herstart uw apparaat.

## Ik kan geen Bijbelvertaling vinden

1. Open **Instellingen** → **Bronnen beheren** om te zien wat er geïnstalleerd is.
2. Staat de vertaling er niet, tik dan op **Installeren vanaf GitHub**.
3. Tik in het downloadvenster op het tabblad **Bijbels** (of **Wereldbijbels**) en selecteer de vertaling die u wilt.
4. Tik op **Geselecteerde installeren** en wacht tot het downloaden klaar is.
5. U heeft internet nodig om een nieuwe vertaling te downloaden.

## Mijn notities of bladwijzers zijn weg

1. Controleer of u naar het juiste tabblad kijkt. Notities zitten in het tabblad **Notities**. Bladwijzers zitten in het tabblad **Bladwijzers**.
2. Heeft u recentelijk een back-up hersteld, dan heeft de back-up mogelijk uw gegevens vervangen. Controleer de datum van de back-up.
3. Heeft u de app verwijderd en opnieuw geïnstalleerd, dan waren uw gegevens verloren. Maak de volgende keer eerst een back-up.

## Het zoeken vindt geen verzen

1. Zorg dat u het woord goed hebt gespeld.
2. Probeer een korter woord. "Love" vindt meer verzen dan "loving."
3. Zorg dat u de juiste Bijbelvertaling heeft geïnstalleerd. Zoeken werkt alleen in de vertalingen die u heeft.

## Voorlezen werkt niet

1. Zorg dat het volume van uw apparaat omhoog staat.
2. Zorg dat de app de luidspreker mag gebruiken.
3. Probeer een andere vertaling. Sommige vertalingen werken beter met voorlezen dan andere.
4. Zie voor een stapsgewijze checklist de gids [Voorlezen](theodia://help/tts).

## De app crasht steeds

1. Herstart de app.
2. Herstart uw apparaat.
3. Blijft het probleem zich voordoen, meld het dan. Zie de gids [Waar u vragen kunt stellen](theodia://help/getting-more-help).

## Ik wil de app verwijderen

U kunt Theodia verwijderen zoals elke andere app. Doe eerst een back-up van uw gegevens. Na het verwijderen zijn de gegevens op het apparaat weg.

## Toch vastgelopen?

Zie de gids [Waar u vragen kunt stellen](theodia://help/getting-more-help). Daar vindt u links om een probleem te melden en om de gemeenschap te vragen.

U kunt de hulpgidsen ook doorzoeken vanaf het hoofdscherm **Hulp & Gidsen**. Typ een woord zoals `notifications`, `search` of `bookmarks` om de bijpassende gids te vinden.
