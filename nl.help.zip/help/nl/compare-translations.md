---
title: Vertalingen vergelijken
level: everyday
categories: [read, study]
summary: Hoe u hetzelfde vers in elke geïnstalleerde vertaling bekijkt.
---

# Vertalingen vergelijken

> **Modus:** Het hulpmiddel Vergelijken is beschikbaar in de modi **Standaard** en **Geleerde**. De Focusmodus is alleen voor rustig lezen zonder afleiding. U kunt van modus wisselen in **Instellingen** → **App-gebruikersmodus**.

Het hulpmiddel **Vergelijken** toont één vers in elke Bijbelvertaling die u heeft geïnstalleerd, allemaal in één paneel. Het is handig wanneer u wilt zien hoe verschillende vertalers een moeilijk vers aanpakken, of wanneer u een vertaling uitkiest en hetzelfde vers in elke vertaling wilt bekijken.

## Vergelijken openen

1. Open een hoofdstuk in een willekeurige vertaling.
2. Tik op een vers om het versmenu te openen.
3. Tik op **Vergelijken** (⇄).

Er opent een paneel. De titelbalk toont de verwijzing (bijvoorbeeld "Johannes 3:16 — Vergelijken"). Het paneel toont hetzelfde vers in elke geïnstalleerde vertaling. Uw huidige vertaling staat bovenaan; de rest is alfabetisch gesorteerd.

## Hoe het paneel eruitziet

Het paneel is een **verticale lijst**, geen kolommen naast elkaar. Elke regel is één vertaling:

- De **naam van de vertaling** (bijvoorbeeld "KJV") staat bovenaan de regel. Die is tikbaar.
- De **vertaaltekst** staat onder de naam.

Scroll door het paneel om alle vertalingen te zien. Elke vertaling die op uw apparaat geïnstalleerd is, verschijnt hier. Heeft een vertaling dat boek of vers niet, dan ontbreekt hij.

## Het vers in een andere vertaling lezen

Tik op de naam van de vertaling in de regel. Het paneel Vergelijken sluit en hetzelfde hoofdstuk opent met het gekozen vers in die vertaling. Dit is de snelste manier om van een vergelijking meteen een specifieke vertaling in te lezen.

## Vergelijken sluiten

- **Op een telefoon:** tik op de X rechtsboven in het paneel.
- **Op een tablet:** tik op de X in de kop van het paneel, of tik buiten het paneel.

U bent terug in de hoofdstukweergave in uw oorspronkelijke vertaling.

## Wanneer Vergelijken gebruiken

- **Een vertaling kiezen.** Open een vers dat u goed kent in uw huidige vertaling en gebruik Vergelijken om het in andere vertalingen te zien. De verschillen vallen op.
- **Moeilijke verzen.** Een vers dat in één vertaling verwarrend is, is in een andere vaak duidelijker.
- **Woordstudies.** Bekijk hoe verschillende vertalers een sleutelwoord of zin aanpakken.

Gebruik voor een vergelijking in één oogopslag van een heel hoofdstuk in meerdere vertalingen tegelijk in plaats daarvan de **parallelle weergave**. Zie de gids [Studiemodus](theodia://help/study-mode) voor het inschakelen.
