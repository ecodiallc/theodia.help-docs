---
title: Uw eigen bronnen maken
level: advanced
categories: resources
summary: Hoe u aangepaste Bijbels, commentaren, boeken, stichtelijke lezingen en lexicons maakt en in Theodia importeert.
---

# Uw eigen bronnen maken

Theodia ondersteunt aangepaste bronnen in het Unique Bible App-formaat. Elke bron is een SQLite-bestand met een specifieke tabelstructuur. U kunt deze bestanden op een computer maken en in de app importeren.

## Bestandstypen en vereiste tabellen

### Bijbels (`.bible`)

Een Bijbelbestand is een SQLite-database met ten minste één van deze tabellen:

- **`Verses`** — kolommen: `Book` (geheel getal, 1-66), `Chapter` (geheel getal), `Verse` (geheel getal), `Scripture` (tekst)
- **`Bible`** — kolommen: `Book` (geheel getal), `Chapter` (geheel getal), `Verse` (geheel getal), `Scripture` (tekst)

U kunt ook een **`Details`**-tabel opnemen met metagegevenskolommen zoals `Description`, `Abbreviation` en `Version`.

Voorbeeld-SQL:

```sql
-- Main text table
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- Optional metadata table
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### Commentaren (`.commentary`)

Commentaren bestaan in drie soorten: **boek**, **hoofdstuk** en **vers**. Het type wordt bepaald door de **eerste letter van de bestandsnaam**.

#### Boekcommentaren — bestandsnaam begint met `b`

Een boekcommentaar behandelt een heel Bijbelboek in één item. De tabel `Commentary` heeft de kolommen `Book` en `Scripture` (of `Content`) nodig. De kolommen `Chapter` of `Verse` zijn niet nodig.

- **`Commentary`** — kolommen: `Book` (geheel getal), `Scripture` (tekst) of `Content` (tekst)

Voorbeeld-SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

Voorbeeld bestandsnaam: `bMyCommentary.commentary`

#### Hoofdstukcommentaren — bestandsnaam begint met `c`

Een hoofdstukcommentaar behandelt elk hoofdstuk van een Bijbelboek.

- **`Commentary`** — kolommen: `Book` (geheel getal), `Chapter` (geheel getal), `Scripture` (tekst) of `Content` (tekst)

Voorbeeld-SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

Voorbeeld bestandsnaam: `cMyCommentary.commentary`

#### Verscommentaren — bestandsnaam begint met `v`

Een verscommentaar behandelt afzonderlijke verzen. De tabel `Commentary` heeft de kolommen `Book`, `Chapter`, `Verse` en `Scripture` (of `Content`) nodig.

- **`Commentary`** — kolommen: `Book` (geheel getal), `Chapter` (geheel getal), `Verse` (geheel getal), `Scripture` (tekst) of `Content` (tekst)

Voorbeeld-SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

Voorbeeld bestandsnaam: `vMyCommentary.commentary`

### Boeken (`.book`)

Een boekbestand is een SQLite-database met een tabel `Reference`.

- **`Reference`** — kolommen: `id` (geheel getal), `Chapter` (tekst), `Content` (tekst)

Elke rij is één hoofdstuk. De kolom `Chapter` is de hoofdstuktitel. De kolom `Content` is de hoofdtekst van het hoofdstuk, die HTML kan bevatten (`<b>`, `<i>`, `<br>` enz.).

Voorbeeld-SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

U kunt ook boeken maken vanuit Markdown-bestanden. De app kan `.md`-bestanden importeren waarin `#` de boektitel is en `##` hoofdstukken markeert. De Markdown wordt automatisch naar HTML omgezet.

### Stichtelijke lezingen (`.devotional`)

Een bestand met stichtelijke lezingen is een SQLite-database met een tabel `devotional`.

- **`devotional`** — kolommen: `month` (geheel getal, 1-12), `day` (geheel getal, 1-31), `devotion` (tekst)

Elke rij is de lezing van één dag. De app zoekt het item op via de maand en dag van vandaag.

Voorbeeld-SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### Lexicons (`.lexicon`)

Een lexiconbestand is een SQLite-database met een tabel `Lexicon`.

- **`Lexicon`** — kolommen: `Topic` (tekst, het Strong's-nummer), `Definition` (tekst, het lexiconitem)

De kolom `Topic` bevat het Strong's-nummer (bijvoorbeeld `G1161` of `H7225`). De kolom `Definition` bevat de volledige itemtekst, die HTML kan bevatten.

Voorbeeld-SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

Lexicons drijven het gereedschap Woordinfo aan. Wanneer u in een interlineaire Bijbel op een woord tikt, zoekt de app het Strong's-nummer op in de geïnstalleerde lexicons.

## Een bestand op uw computer maken

1. Installeer een SQLite-editor (DB Browser for SQLite, SQLiteStudio of het commandoregelgereedschap `sqlite3`).
2. Maak een nieuw databasebestand.
3. Maak de vereiste tabel en voeg uw gegevens in.
4. Sla het bestand op met de juiste extensie (`.bible`, `.commentary`, `.book`, `.devotional` of `.lexicon`).

## Importeren in Theodia

1. Zet het bestand over naar uw apparaat (AirDrop, e-mail, cloudopslag of USB).
2. Open **Theodia**.
3. Ga naar **Instellingen** → **Bronnen beheren**.
4. Tik op **Importeren uit bestand**.
5. Selecteer uw bestand.

De app valideert het bestand (controleert op de vereiste tabel), kopieert het naar de gegevensmap van de app en activeert het automatisch. Is het bestand ongeldig, dan ziet u een foutmelding die uitlegt wat er mis is.

## Beperkingen

- U kunt ingebouwde bronnen niet overschrijven. Probeert u een bestand te importeren met dezelfde naam als een ingebouwde Bijbel, een commentaar of een boek, dan mislukt de import.
- Bijbelbestanden hebben een tabel `Verses` of `Bible` nodig. Bestaat geen van beide, dan mislukt de import.
- Commentaarbestanden hebben een tabel `Commentary` nodig.
  - Boekcommentaren hebben de kolommen `Book` en `Scripture` (of `Content`) nodig.
  - Hoofdstukcommentaren hebben de kolommen `Book`, `Chapter` en `Scripture` (of `Content`) nodig.
  - Verscommentaren hebben de kolommen `Book`, `Chapter`, `Verse` en `Scripture` (of `Content`) nodig.
- Boekbestanden hebben een tabel `Reference` nodig.
- Lexiconbestanden hebben een tabel `Lexicon` nodig.
- Bestanden met stichtelijke lezingen hebben een tabel `devotional` nodig.

## Tips

- Houd de bestandsgrootte redelijk. Zeer grote SQLite-bestanden kunnen geheugenproblemen veroorzaken op oudere apparaten.
- Test uw bestand eerst op een computer. Open het in een SQLite-browser en voer `SELECT * FROM` uit op de vereiste tabel om te controleren dat de gegevens er goed uitzien.
- Zorg bij Bijbels dat de kolom `Book` getallen gebruikt (1 = Genesis, 66 = Openbaring).
- Bij commentaren kunt u `Scripture` of `Content` als tekstkolom gebruiken.
- Bij boeken wordt HTML in de kolom `Content` weergegeven tijdens het lezen. Houd het eenvoudig: `<b>`, `<i>`, `<br>` en `<hr>` zijn veilig.

## Waar u bestaande bronnen vindt

Theodia kan bronnen uit het project [Unique Bible App](https://github.com/eliranwong/UniqueBible) lezen. Veel Bijbels, commentaren, boeken en andere bronnen zijn daar beschikbaar in het juiste SQLite-formaat. Zie de gids [Extra bronnen ophalen](theodia://help/getting-core-files) voor hoe u ze vindt en toevoegt.
