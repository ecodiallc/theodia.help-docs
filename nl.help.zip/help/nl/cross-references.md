---
title: Kruisverwijzingen
level: everyday
categories: study
summary: Hoe u verzen vindt die aansluiten bij het vers dat u aan het lezen bent.
---

# Kruisverwijzingen

> **Modus:** Kruisverwijzingen zijn beschikbaar in de modi **Standaard** en **Geleerde**. De Focusmodus is alleen voor rustig lezen zonder afleiding. U kunt van modus wisselen in **Instellingen** → **App-gebruikersmodus**.

Een "kruisverwijzing" is een ander vers dat over hetzelfde onderwerp gaat als het vers dat u aan het lezen bent. Het paneel Kruisverwijzingen toont u welke verzen in de Bijbel met elkaar verbonden zijn.

## De kruisverwijzingen openen

1. Open een hoofdstuk.
2. Tik op een vers om het versmenu te openen.
3. Tik op **Kruisverwijzingen**.

Er opent een paneel. Het toont een lijst met andere verzen die aansluiten bij het vers waarop u tikte.

## De lijst lezen

Elke regel is één verbonden vers. U ziet:

- Het boek, het hoofdstuk en het vers.
- Een korte voorproef van de vertaaltekst.
- Een score die aangeeft hoe sterk de verbinding is.

## Naar een verbonden vers springen

Tik op een willekeurige regel. De app opent dat vers voor u. Bent u klaar, tik dan op de terugknop om terug te keren.

## Wat de score betekent

De score vertelt u hoe nauw de verzen verbonden zijn. Een hoge score betekent een sterke, directe verbinding. Een lage score betekent een lossere.

## Kruisverwijzingen voor studie gebruiken

Kruisverwijzingen zijn nuttig voor:

- **Woordstudies.** Zie hoe de Bijbel een woord op verschillende plaatsen gebruikt.
- **Themastudies.** Volg een thema, zoals "liefde" of "verbond", door de Schrift heen.
- **Preekvoorbereiding.** Vind snel ondersteunende verzen.

## Tip

Kruisverwijzingen werken het best met een woord-voor-woordvertaling zoals WEB.
