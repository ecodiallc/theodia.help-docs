---
title: Dagelijkse stichtelijke lezingen
level: everyday
categories: [content, read]
summary: Hoe u elke dag een korte stichtelijke lezing leest.
---

# Dagelijkse stichtelijke lezingen

Een stichtelijke lezing is een korte lezing voor één dag. Die heeft vaak een vers, een korte gedachte en een vraag om over na te denken. Theodia wordt geleverd met een kleine bibliotheek van stichtelijke lezingen.

## Een stichtelijke lezing openen

1. Tik onderaan het scherm op het tabblad **Stichtelijke lezingen**.
2. U ziet een lijst met de stichtelijke lezingen die op uw apparaat geïnstalleerd zijn.
3. Tik op een lezing om haar te openen.

## Een stichtelijke lezing lezen

1. Open de stichtelijke lezing.
2. Scroll om te lezen.
3. Gebruik de knoppen bovenaan om:
   - Op de **datum** te tikken om naar een andere dag te springen.
   - Op de **ster** te tikken om de dag van een bladwijzer te voorzien.
   - Op de **luidspreker** te tikken om haar voor te lezen (als uw apparaat dat ondersteunt). Zie de gids [Voorlezen](theodia://help/tts) voor het kiezen van een stem.
   - Op **Vorige** of **Volgende** te tikken om naar de dag ervoor of erna te gaan.

## Een vers uit een stichtelijke lezing opslaan

1. Open de stichtelijke lezing.
2. Tik op een vers.
3. Tik op **Bladwijzer** of **Markeren**.

Het vers wordt opgeslagen in uw Bladwijzers of Markeringen.

## Een notitie bij een stichtelijke lezing schrijven

1. Open de stichtelijke lezing.
2. Tik op een vers.
3. Tik op **Notitie**. Typ uw beschouwing of gebed. Tik op **Opslaan**.

De notitie verschijnt in uw tabblad Notities.

## Tips

- Stichtelijke lezingen hebben het internet niet nodig. Ze werken offline.
- Wilt u meer stichtelijke lezingen, zie dan de gids [Extra bronnen van GitHub](theodia://help/getting-core-files).
