---
title: Bijbelwoordenboek
level: everyday
categories: study
summary: Zoek Bijbelwoorden en -begrippen op in geïnstalleerde woordenboekbronnen. Open het vanuit het versmenu of een lexiconitem, en tik op elk woord om hetzelfde woord in elk woordenboek te zien.
---

# Bijbelwoordenboek

> **Modus:** Het Bijbelwoordenboek vereist de modus **Geleerde**. U kunt van modus wisselen in **Instellingen** → **App-gebruikersmodus**.

Het hulpmiddel Bijbelwoordenboek zoekt een woord of zin op in elke woordenboekbron die u heeft geïnstalleerd. Het is handig wanneer u een definitie in gewone taal van een Bijbelwoord wilt, een beschrijving van een persoon of plaats, of een kort artikel over een theologisch begrip.

Het Bijbelwoordenboek is anders dan het hulpmiddel **Woordinfo**, dat het oorspronkelijke Hebreeuwse of Griekse woord achter een vers opzoekt. Het woordenboek leest het **Engelse** woord waarop u tikt en toont wat uw geïnstalleerde woordenboeken erover zeggen. Voor woord-voor-woord Bijbelvertaalnotities, zie de gids [Commentaren en lexicons](theodia://help/commentaries-and-lexicons).

## Het woordenboek openen

Er zijn twee manieren om het woordenboek te openen.

### Vanuit het versmenu

1. Open een hoofdstuk in de [Studiemodus](theodia://help/study-mode).
2. Tik op een vers om het versmenu te openen.
3. Tik op **Woordenboek** (📖).

Er opent een paneel getiteld met de versverwijzing (bijvoorbeeld "Johannes 3:16"). De vertaaltekst staat bovenaan, met elk woord tikbaar. Onder het vers zit een strook met chips die elke geïnstalleerde woordenboek toont. Daaronder zit de definitie, die leeg is totdat u op een woord tikt.

### Vanuit een lexiconitem

Wanneer u een lexiconitem in het Woordinfo-paneel leest, bevatten sommige items blauwe links naar verwante woordenboekartikelen. Tik op een van die links. Het lexicon sluit en het woordenboek opent op dat artikel. Dit is de snelste manier om van een Grieks of Hebreeuws woord naar een uitleg in gewone taal te springen.

## Hoe de versweergave werkt

Wanneer u het woordenboek vanuit een versmenu opent, verschijnt het vers bovenaan het paneel als een lijst tikbare woorden. Gewone Engelse woorden zoals "the", "and", "of", "to" en "a" zijn niet tikbaar. Elk ander woord wel. Elk tikbaar woord is gekleurd en vet, zodat het opvalt tussen de rest van het vers.

Tik op een willekeurig woord in het vers. Theodia doorzoekt elke geïnstalleerde woordenboek op een exacte overeenkomst met dat woord. De chipstrook onderaan werkt bij om te tonen welke woordenboeken een item hebben: woordenboeken zonder item voor dat woord worden gedimd. De eerste woordenboek met een item wordt automatisch geselecteerd, en haar definitie verschijnt onder de chipstrook.

Het woord waarop u tikte is in de vertaaltekst bovenaan het paneel gemarkeerd, zodat u altijd weet wat u opzoekt.

## Tussen woordenboeken wisselen

Elke geïnstalleerde woordenboek wordt als een kleine chip onder het vers getoond. Na het tikken op een woord:

- **Effen gekleurde** chip — deze woordenboek heeft een item voor het woord waarop u tikte. Tik erop om naar de definitie van die woordenboek te wisselen.
- **Gedimde** chip — deze woordenboek heeft geen item voor dat woord. Ze wordt grijs getoond zodat u in één oogopslag ziet welke woordenboeken het woord dekken, en de chip is niet tikbaar.

De geselecteerde woordenboek is gemarkeerd. Tik op een andere effen chip om hetzelfde woord in die woordenboek te lezen. De definitie hieronder werkt meteen bij.

Bestaat het woord in slechts een van uw geïnstalleerde woordenboeken, dan is alleen die chip effen en zijn de anderen gedimd.

## Wat het paneel toont

Het woordenboekpaneel heeft drie delen, van boven naar beneden:

- **Het vers** — het vers waarvanuit u het woordenboek opende. Woorden zijn tikbaar, en het woord dat u het laatst tikte is gemarkeerd.
- **De chipstrook** — elke geïnstalleerde woordenboek. Effen betekent "heeft een item voor het getikte woord." Gedimd betekent "geen item voor dat woord."
- **De definitie** — het artikel uit de geselecteerde woordenboek. Platte tekst, opgemaakt met alinea's en koppen. Interne links naar andere woordenboekitems zijn tikbaar; erop tikken opent dat item in het woordenboek.

## Wat er gebeurt als er geen item wordt gevonden

Tikt u op een woord dat geen van uw geïnstalleerde woordenboeken dekt, dan toont het paneel een kort bericht "geen items gevonden" in plaats van een definitie. Dit komt vaak voor bij heel gewone woorden zoals "year" of "come" die geen echte Bijbel-theologiewoorden zijn, zelfs al verschijnen ze overal in de Bijbel. Probeer een specifieker woord, of gebruik in plaats daarvan het hulpmiddel Woordinfo van het lexicon, dat op de onderliggende Griekse en Hebreeuwse tekst werkt.

## Wat er gebeurt als er geen woordenboek is geïnstalleerd

Het woordenboek heeft ten minste één woordenboekbronbestand nodig om nuttig te zijn. Theodia wordt er met een geleverd. Heeft u die verwijderd of draait u een eigen installatie zonder woordenboeken, dan verschijnt de versweergave nog steeds en zijn woorden nog steeds tikbaar, maar de chipstrook is leeg en elke zoekopdracht geeft "geen items gevonden."

Extra woordenboeken kunnen niet apart worden geïnstalleerd.

## Tips

- Het woordenboek zoekt op **exacte woordovereenkomsten**. Tikken op "love" vindt items getiteld "love" maar niet "loved" of "loving." Om een verwante vorm op te zoeken, gebruik het hulpmiddel Woordinfo van het lexicon op het Griekse of Hebreeuwse woord.
- De chipstrook is hetzelfde op telefoons en tablets. Op een tablet opent het woordenboek als een zijpaneel naast het hoofdstuk; op een telefoon opent het als een schermvullend venster. Beide hebben dezelfde driedelige indeling.
- Tikken op een woord in een ander vers opent een nieuw vers in het paneel. Uw vorige selectie wordt gewist. Tik op een woord in het nieuwe vers om een nieuwe opzoekactie te starten.
- Sommige woordenboekitems verwijzen naar hetzelfde woord in een andere woordenboek. Tik op die interne links om het spoor door al uw geïnstalleerde woordenboeken te volgen.

## Verschillen tussen Woordenboek en Woordinfo

Beide hulpmiddelen openen vanuit het versmenu, maar ze doen verschillende dingen:

- **Woordenboek** (📖) leest het Engelse woord waarop u tikt en vindt het in uw geïnstalleerde Engelse woordenboeken. Het is het juiste hulpmiddel voor definities in gewone taal van Bijbel-theologiewoorden zoals "covenant", "atonement" of "Pharisee."
- **Woordinfo** (?) leest het oorspronkelijke Griekse of Hebreeuwse woord achter het vers en vindt het in uw geïnstalleerde lexicons. Het is het juiste hulpmiddel voor serieuze woordstudies, het vinden van elke plaats waar een Grieks woord wordt gebruikt, en het lezen van de definities in de brontaal.

Bij twijfel, begin met het woordenboek. Wilt u in de brontaal graven, wissel dan naar Woordinfo. Zie de gids [Commentaren en lexicons](theodia://help/commentaries-and-lexicons) voor de volledige Woordinfo-rondleiding.

## Verwante gidsen

- De gids [Studiemodus](theodia://help/study-mode) legt het versmenu in detail uit en waar het hulpmiddel Woordenboek (📖) naast Bladwijzer, Markeren, Voorlezen, Vergelijken, Kruisverwijzingen, AI-commentaar, Woordinfo en Notities zit.
- De gids [Commentaren en lexicons](theodia://help/commentaries-and-lexicons) behandelt Woordinfo en de brontaal-lexicons.
- De gids [Wat zijn bronnen?](theodia://help/what-are-resources) legt de verschillende soorten bestanden uit die Theodia gebruikt, waaronder de woordenboekbronnen.
- De gids [Veelvoorkomende problemen](theodia://help/common-problems) heeft oplossingen voor lege resultaten en andere woordenboekproblemen.
