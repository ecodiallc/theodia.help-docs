---
title: Encyclopedie
level: everyday
categories: study
summary: Hoe u encyclopedieartikelen opzoekt en naslagwerken doorbladert.
---

# Encyclopedie

Theodia bevat een ingebouwde **Encyclopedie** voor het opzoeken van Bijbelgerelateerde artikelen, personen, plaatsen en onderwerpen. De app wordt geleverd met _Kitto's Illustrated Commentary_ (KIT) ingebouwd, en u kunt extra encyclopedieën uit de repository downloaden.

## Wat is een encyclopedie in Theodia?

Een encyclopedie is een naslagwerk van korte artikelen. Elk artikel behandelt een persoon, plaats, gebeurtenis of Bijbelonderwerp. Anders dan een commentaar, dat een specifiek vers uitlegt, legt een encyclopedieartikel het onderwerp zelf uit.

## De Encyclopedie openen

1. Tik in de onderste werkbalk op **Encyclopedie**.
2. Kies een encyclopedie uit de rij afkortingen bovenaan.
3. Typ een onderwerp, persoon of plaats in het zoekvak.

Zoeken vereist ten minste **3 tekens** voordat resultaten en autocomplete-suggesties verschijnen.

## Een artikel lezen

- Op een **telefoon** tikt u op een willekeurig resultaat om het artikel op een nieuw scherm te openen.
- Op een **tablet** opent het artikel in het paneel rechts terwijl de lijst links blijft.

## Encyclopedieën kiezen

Tik op een afkortingschip (zoals **KIT**) om naar die encyclopedie te wisselen. Om in meer dan één encyclopedie tegelijk te zoeken, gebruikt u het tabblad **Zoeken** en kiest **Encyclopedie** als zoekmodus.

## Meer encyclopedieën ophalen

1. Open **Instellingen**.
2. Tik op **Bronnen beheren**.
3. Tik op **Installeren vanaf GitHub**.
4. Selecteer het tabblad **Encyclopedieën**.
5. Tik op de downloadknop naast de encyclopedie die u wilt.

Encyclopedieën worden gedownload uit de GitHub-repository van Theodia's encyclopedieën en automatisch geïnstalleerd. Geïnstalleerde encyclopedieën verschijnen in het Encyclopedie-scherm en in Zoeken.

U kunt ook een encyclopedie vanuit een lokaal bestand installeren: tik in **Bronnen beheren** op **Lokaal bestand importeren** en kies een `.encyclopedia`-bestand. Het bestand wordt naar de encyclopediemap van de app gekopieerd en aan de gedeelde opzoekindex toegevoegd.

## Lang indrukken voor de volledige titel

Op het Zoekscherm tonen de encyclopediechips korte afkortingen. Houd een chip lang ingedrukt om de volledige encyclopedienaam te zien.

## Wanneer de Encyclopedie gebruiken

- Zoek een persoon, plaats of onderwerp op voorafgaand aan of tijdens het lezen van een gedeelte.
- Krijg achtergrond over een Bijbelwoord of begrip dat over vele verzen loopt.
- Lees naast een commentaar voor diepere studie.
