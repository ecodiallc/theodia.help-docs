---
title: Sneltoetsen extern toetsenbord
level: everyday
categories: [tablet, settings]
summary: Volledige naslag voor toetsenbordsneltoetsen op iPad met een extern toetsenbord aangesloten.
---

# ⌨️ Sneltoetsen extern toetsenbord

Gebruikt u Theodia op iPad met een extern toetsenbord (Magic Keyboard, Bluetooth-toetsenbord of USB-toetsenbord), dan kunt u door de app navigeren zonder het scherm aan te raken.

> **Modus:** Sommige sneltoetsen werken alleen wanneer de bijbehorende functie beschikbaar is in uw huidige gebruikersmodus. Zo doen `Cmd + Option + 6` (Bladwijzers) en `Cmd + Option + 7` (Markeringen) niets in de modus Lezer. Wissel van modus in **Instellingen** → **App-gebruikersmodus**.

Sneltoetsen werken op **iPad**.

## Algemene sneltoetsen (overal)

| Sneltoets          | Actie                                          |
| ------------------ | ---------------------------------------------- |
| `Cmd + /`          | Deze hulp bij toetsenbordsneltoetsen tonen     |
| `Cmd + .`          | Modal/paneel sluiten (alternatief voor Escape) |
| `Cmd + Option + 1` | Naar het tabblad Beginscherm                   |
| `Cmd + Option + 2` | Naar het tabblad Bijbels                       |
| `Cmd + Option + 3` | Naar het tabblad Boeken                        |
| `Cmd + Option + 4` | Naar het tabblad Stichtelijke lezingen         |
| `Cmd + Option + 5` | Naar het tabblad Zoeken                        |
| `Cmd + Option + 6` | Naar het tabblad Bladwijzers (Standaard en Geleerde) |
| `Cmd + Option + 7` | Naar het tabblad Markeringen (Standaard en Geleerde) |
| `Cmd + Option + 8` | Naar het tabblad Notities (Standaard en Geleerde) |
| `Cmd + Option + 9` | Naar het tabblad AI (alleen Geleerde, indien ingeschakeld) |
| `Cmd + Option + 0` | Naar het tabblad Hulp                          |
| `Cmd + Option + I` | Naar het tabblad Over                          |
| `Cmd + [`          | Terug                                          |
| `Cmd + F`          | Zoeken openen                                  |
| `Cmd + K`          | Launcher-menu openen (Geleerde)                |
| `Cmd + ,`          | Instellingen openen                            |
| `Cmd + Shift + M`  | Hoofdmenu openen                               |
| `Cmd + Shift + T`  | Thema wisselen (standaard/donker)              |
| `Cmd + Shift + U`  | Kiezer voor gebruikersmodus openen             |
| `Escape`           | Modal sluiten / paneel dichtklappen            |

## Sneltoetsen Bijbellezer

Deze werken in zowel de **Studielezer** als de **Focuslezer**.

| Sneltoets          | Actie                                                       |
| ------------------ | ------------------------------------------------------------ |
| `← Pijl links`     | Vorig hoofdstuk                                              |
| `→ Pijl rechts`    | Volgend hoofdstuk                                            |
| `Cmd + R`          | Wisselen tussen Studielezer en Focuslezer (Standaard en Geleerde) |
| `Cmd + Option + V` | Vertalingskiezer openen                                      |
| `Cmd + Option + B` | Boekkiezer openen                                            |
| `Cmd + Option + C` | Hoofdstukkiezer openen                                       |
| `Cmd + T`          | Voorlezen aan/uit (stoppen tijdens afspelen/gepauzeerd, starten in rust) |
| `Cmd + Option + T` | Voorlezen afspelen/pauzeren                                  |

## Alleen Studielezer

| Sneltoets          | Actie                                                                 |
| ------------------ | ---------------------------------------------------------------------- |
| `↑ Pijl omhoog`    | Vorig vers selecteren                                                  |
| `↓ Pijl omlaag`    | Volgend vers selecteren                                                |
| `Cmd + ↑`          | Eerste vers selecteren                                                 |
| `Cmd + ↓`          | Laatste vers selecteren                                                |
| `Cmd + ←`          | Naar hoofdstuk 1 springen                                              |
| `Cmd + →`          | Naar het laatste hoofdstuk springen                                    |
| `Cmd + 0`–`9`      | Rechtstreeks naar vers springen (cijfers typen, bijv. `Cmd + 1` `Cmd + 6` voor vers 16) |
| `Cmd + P`          | Parallelle Bijbels aan/uit (Standaard en Geleerde)                     |
| `Cmd + B`          | Geselecteerd vers van bladwijzer voorzien (Standaard en Geleerde)      |
| `Cmd + H`          | Geselecteerd vers markeren (Standaard en Geleerde)                     |
| `Cmd + N`          | Notitie toevoegen bij geselecteerd vers (Standaard en Geleerde)        |
| `Cmd + C`          | Vertalingen van geselecteerd vers vergelijken (Standaard en Geleerde)  |
| `Cmd + X`          | Kruisverwijzingen openen voor geselecteerd vers (Standaard en Geleerde) |
| `Cmd + I`          | Woordinfo openen (Geleerde)                                            |
| `Cmd + D`          | Woordenboek openen voor geselecteerd vers (Geleerde)                   |
| `Cmd + A`          | AI-paneel openen voor geselecteerd vers (Geleerde)                     |
| `Cmd + Option + S` | Tussentitels aan/uit                                                   |
| `Cmd + Option + W` | Alle open studiepanelen sluiten                                        |
| `Cmd + Option + M` | Menu met versacties openen                                             |

## Alleen Focuslezer

| Sneltoets       | Actie           |
| --------------- | --------------- |
| `↑ Pijl omhoog` | Omhoog scrollen |
| `↓ Pijl omlaag` | Omlaag scrollen |
| `Cmd + ↑`       | Naar boven scrollen |
| `Cmd + ↓`       | Naar beneden scrollen |
| `Cmd + =`       | Inzoomen        |
| `Cmd + -`       | Uitzoomen       |

## Zoeken

| Sneltoets          | Actie                            |
| ------------------ | -------------------------------- |
| `Return`           | Zoekopdracht uitvoeren           |
| `Cmd + Return`     | Zoekopdracht wissen en invoerveld focus geven |
| `Cmd + ↑`          | Resultaten omhoog scrollen       |
| `Cmd + ↓`          | Resultaten omlaag scrollen       |
| `Cmd + Option + A` | Alle bereikitems selecteren      |
| `Cmd + Option + C` | Alle bereikitems deselecteren    |
| `Cmd + Option + B` | Modus Bijbel zoeken              |
| `Cmd + Option + O` | Modus Boeken zoeken              |
| `Cmd + Option + D` | Modus Woordenboek zoeken (Geleerde) |
| `Cmd + Option + X` | Modus Lexicon zoeken (Geleerde)  |

## Zoekresultaten

| Sneltoets | Actie              |
| --------- | ------------------ |
| `Cmd + S` | Alles-opslaan-blad openen |
| `Cmd + ↑` | Resultaten omhoog scrollen |
| `Cmd + ↓` | Resultaten omlaag scrollen |

## Boekenlezer

| Sneltoets          | Actie                    |
| ------------------ | ------------------------ |
| `← Pijl links`     | Vorig hoofdstuk          |
| `→ Pijl rechts`    | Volgend hoofdstuk        |
| `Cmd + ↑`          | Vorig hoofdstuk          |
| `Cmd + ↓`          | Volgend hoofdstuk        |
| `↑ Pijl omhoog`    | Omhoog scrollen          |
| `↓ Pijl omlaag`    | Omlaag scrollen          |
| `Cmd + B`          | Huidige hoofdstuk van bladwijzer voorzien |
| `Cmd + J`          | Hoofdstukkiezer openen   |
| `Cmd + L`          | Stemkiezer openen        |
| `Cmd + T`          | Voorlezen aan/uit        |
| `Cmd + Option + T` | Voorlezen afspelen/pauzeren |

## Lezer stichtelijke lezingen

| Sneltoets          | Actie               |
| ------------------ | ------------------- |
| `← Pijl links`     | Vorige dag          |
| `→ Pijl rechts`    | Volgende dag        |
| `↑ Pijl omhoog`    | Omhoog scrollen     |
| `↓ Pijl omlaag`    | Omlaag scrollen     |
| `Cmd + ↑`          | Omhoog scrollen (groot) |
| `Cmd + ↓`          | Omlaag scrollen (groot) |
| `Cmd + D`          | Datumskiezer openen  |
| `Cmd + T`          | Voorlezen aan/uit   |
| `Cmd + Option + T` | Voorlezen afspelen/pauzeren |

## AI-chat

| Sneltoets          | Actie                      |
| ------------------ | -------------------------- |
| `Cmd + Return`     | Bericht versturen          |
| `Cmd + N`          | Nieuwe chat                |
| `Cmd + D`          | Gesprekslade aan/uit       |
| `Cmd + Option + C` | Huidige chat wissen        |
| `Cmd + S`          | Opslaanmenu openen         |
| `Escape`           | Lade/menu sluiten          |

## Bladwijzers

| Sneltoets                     | Actie                              |
| ----------------------------- | ---------------------------------- |
| `↑ Pijl omhoog` / `↓ Pijl omlaag` | Bladwijzer selecteren          |
| `Return`                      | Bladwijzer openen (tablet: selecteren) |
| `Cmd + R`                     | Bladwijzer in context lezen        |
| `Cmd + M`                     | Geselecteerde bladwijzer naar mappen verplaatsen |
| `Cmd + N`                     | Mappen beheren                     |
| `Escape`                      | Detailpaneel/mapkiezer sluiten     |

In de kiezer **Opslaan in map** verplaatst `↑ Pijl omhoog` / `↓ Pijl omlaag` de selectie, wisselt `Return` de geselecteerde map of activeert de gemarkeerde actie, en sluit `Escape` de kiezer. De rij **+ Map maken** staat bovenaan de lijst.

## Bijbelnotities

| Sneltoets                     | Actie                 |
| ----------------------------- | --------------------- |
| `↑ Pijl omhoog` / `↓ Pijl omlaag` | Notitie selecteren |
| `Return`                      | Notitie openen        |
| `Cmd + Return`                | Filterinvoer focus geven |
| `Escape`                      | Detail/editor sluiten |

## Markeringen

| Sneltoets                     | Actie              |
| ----------------------------- | ------------------ |
| `↑ Pijl omhoog` / `↓ Pijl omlaag` | Markering selecteren |
| `Return`                      | Markering openen   |
| `Cmd + Return`                | Filterinvoer focus geven |
| `Escape`                      | Detailpaneel sluiten |

## Bijbellijst

| Sneltoets                                | Actie                             |
| ---------------------------------------- | --------------------------------- |
| `Tab` / `→ Pijl rechts` / `↓ Pijl omlaag` | Volgende Bijbel                  |
| `← Pijl links` / `↑ Pijl omhoog`         | Vorige Bijbel                     |
| `Return`                                 | Gerichte Bijbel openen            |
| `Cmd + Shift + S`                        | Favoriet wisselen voor gerichte Bijbel |
| `Escape`                                 | Terug                             |

## Scherm Bijbelboeken

| Sneltoets               | Actie                      |
| ----------------------- | -------------------------- |
| `Tab` / `→ Pijl rechts` | Volgende boek              |
| `← Pijl links`          | Vorige boek                |
| `↓ Pijl omlaag`         | Boek eronder in het raster |
| `↑ Pijl omhoog`         | Boek erboven in het raster |
| `Cmd + ↓`               | Volgende sectie (OT / NT)  |
| `Cmd + ↑`               | Vorige sectie (OT / NT)    |
| `Return`                | Gericht boek openen        |
| `Escape`                | Terug                      |

## Boekenlijst

| Sneltoets                                | Actie             |
| ---------------------------------------- | ----------------- |
| `Tab` / `→ Pijl rechts` / `↓ Pijl omlaag` | Volgende boek    |
| `← Pijl links` / `↑ Pijl omhoog`         | Vorige boek       |
| `Return`                                 | Gericht boek openen |
| `Escape`                                 | Terug             |

## Scherm Bijbelhoofdstukken

| Sneltoets                                | Actie                |
| ---------------------------------------- | -------------------- |
| `Tab` / `→ Pijl rechts` / `↓ Pijl omlaag` | Volgende hoofdstuk  |
| `← Pijl links` / `↑ Pijl omhoog`         | Vorige hoofdstuk     |
| `Return`                                 | Gericht hoofdstuk openen |
| `Escape`                                 | Terug                |

## Scherm boekhoofdstukken

| Sneltoets              | Actie                     |
| ---------------------- | ------------------------- |
| `Tab` / `↓ Pijl omlaag` | Volgende hoofdstuk       |
| `↑ Pijl omhoog`        | Vorige hoofdstuk          |
| `Return`               | Gericht hoofdstuk openen  |
| `Cmd + Return`         | Zoek-/filterinvoer focus geven |
| `Escape`               | Terug                     |

## Lijst stichtelijke lezingen

| Sneltoets                                | Actie                   |
| ---------------------------------------- | ----------------------- |
| `Tab` / `→ Pijl rechts` / `↓ Pijl omlaag` | Volgende stichtelijke lezing |
| `← Pijl links` / `↑ Pijl omhoog`         | Vorige stichtelijke lezing |
| `Return`                                 | Gerichte lezing openen  |
| `Escape`                                 | Terug                   |

## Grafieken

Op de schermen Statistieken, Doelen en Concordantie.

| Sneltoets       | Actie                                  |
| --------------- | -------------------------------------- |
| `← Pijl links`  | Vorige categorie in een grafiek selecteren |
| `→ Pijl rechts` | Volgende categorie in een grafiek selecteren |

Het onderschrift onder de grafiek volgt de selectie, en de nieuwe waarde wordt uitgesproken.

## Hoofdmenu (wanneer geopend)

| Sneltoets      | Actie                   |
| -------------- | ----------------------- |
| `↑ Pijl omhoog` | Vorig menu-item        |
| `↓ Pijl omlaag` | Volgend menu-item      |
| `Return`       | Gemarkeerd item selecteren |
| `Escape`       | Menu sluiten            |

## Instellingen

| Sneltoets | Actie                     |
| --------- | ------------------------- |
| `Escape`  | Open modal/kiezer sluiten |

## Editor-modals

| Sneltoets | Actie          |
| --------- | -------------- |
| `Cmd + S` | Opslaan        |
| `Escape`  | Annuleren/sluiten |

## Typbeveiliging

Bent u bezig in een tekstveld (zoekvak, notitieeditor, AI-invoer), dan worden sneltoetsen zonder Cmd, zoals de pijltjestoetsen en `Spatie`, onderdrukt zodat ze niet per ongeluk navigatie activeren. Sneltoetsen met de `Cmd`-toets (bijv. `Cmd + S`, `Cmd + B`) blijven tijdens het typen werken.
