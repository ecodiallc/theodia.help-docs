---
title: Veelgestelde vragen
level: everyday
categories: faq
summary: Antwoorden op de meest gestelde vragen over het gebruik van Theodia.
---

# Veelgestelde vragen

## Kost Theodia iets?

Theodia is een eenmalige aankoop. Er is geen abonnement, geen advertenties, geen in-app-aankopen en geen verzoek om donaties. Alle extra bronnen in de catalogus zijn gratis te downloaden nadat u de app heeft gekocht.

## Heb ik een internetverbinding nodig?

Nee. Zodra de app en haar gegevensbestanden zijn geïnstalleerd, werkt alles offline. U kunt lezen, zoeken, markeren, notities maken en de meeste studiehulpmiddelen gebruiken zonder signaal.

De enige functie die internet nodig heeft, is het downloaden van nieuwe bronnen.

## Waar worden mijn gegevens opgeslagen?

Al uw bladwijzers, markeringen, notities en instellingen worden op uw apparaat opgeslagen. Ze worden niet naar een server geüpload.

U kunt er handmatig een back-up van maken. Zie de gids [Back-up van uw gegevens](theodia://help/backups) voor instructies.

## Kan ik naar de Bijbel luisteren?

Ja. Open een willekeurig hoofdstuk, tik op het menu en kies de voorleesoptie. Uw apparaat moet een tekst-naar-spraakstem geïnstalleerd hebben. Zie de gids [Voorlezen](theodia://help/tts) voor meer.

## Hoe zoek ik naar een vers?

U kunt een verwijzing zoals `John 3:16` in de Opdracht op het beginscherm typen, of het tabblad **Zoeken** gebruiken om op woord of zin te zoeken.

## Hoe meld ik een bug of stel ik een functie voor?

Tik op het Over-scherm op **Suggestie/probleem indienen**, [meld het op GitHub](https://github.com/ecodiallc/theodia.app/issues/new), of bezoek de pagina [GitHub-discussies](https://github.com/ecodiallc/theodia.app/discussions).

## Welke apparaten worden ondersteund?

Theodia draait op iPhone, iPad en Android-telefoons en -tablets. Het werkt het best op apparaten met ten minste 2 GB vrije opslagruimte voor de kerngegevensbestanden.

## Kan ik een extern toetsenbord gebruiken?

Ja. Theodia ondersteunt Bluetooth- en USB-toetsenborden op iPad. Navigatie, zoeken en veel leesfuncties hebben toetsenbordsneltoetsen. Zie de gids [Externe toetsenbordsneltoetsen](theodia://help/external-keyboard-shortcuts) voor de volledige lijst.

## Welke talen worden ondersteund?

De app-interface is beschikbaar in het Engels, Arabisch, Chinees (vereenvoudigd en traditioneel), Tsjechisch, Deens, Nederlands, Filipijns, Frans, Duits, Grieks, Hebreeuws, Hindi, Indonesisch, Italiaans, Japans, Koreaans, Pools, Portugees (Brazilië), Roemeens, Russisch, Spaans, Swahili, Zweeds, Thai, Turks, Oekraïens en Vietnamees.

De taal van de Bijbeltekst hangt af van welke vertalingen u heeft geïnstalleerd.

## Hoe verander ik de taal?

Ga naar **Instellingen** en zoek de taaloptie.

## Mijn vraag staat hier niet. Waar krijg ik meer hulp?

Blader door de rest van de hulpgidsen per onderwerp, of stel een vraag in de [GitHub-discussies](https://github.com/ecodiallc/theodia.app/discussions)-gemeenschap.

Tip: op het hoofdscherm **Hulp & Gidsen** gebruikt u het zoekvak om een onderwerp zoals `notifications` of `search` te typen en de bijpassende gids te vinden.
