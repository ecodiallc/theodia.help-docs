---
title: Uw eerste hoofdstuk lezen
level: beginner
categories: [start, read]
summary: Een stapsgewijze uitleg over het openen en lezen van een hoofdstuk.
---

# Uw eerste hoofdstuk lezen

Deze gids loopt met u mee bij het openen van een hoofdstuk voor de allereerste keer.

## Stap 1: Open het Bijbel-tabblad

Kijk onderaan het scherm. U ziet een rij tabbladen. Tik op degene met **Bijbel**.

## Stap 2: Kies een boek

U ziet een lijst met Bijbelboeken. Genesis staat als eerste. Johannes staat ongeveer in het midden. Openbaring staat als laatste.

Tik op de naam van het boek dat u wilt.

## Stap 3: Kies een hoofdstuk

U ziet de nummers 1 tot en met het aantal hoofdstukken van het boek. Tik op het hoofdstuk dat u wilt.

Het hoofdstuk opent. De verzen staan op het scherm.

## Stap 4: Beweeg rond

- Veeg **naar links** om naar het volgende hoofdstuk te gaan.
- Veeg **naar rechts** om terug te gaan.

## Stap 5: Werk met een vers

Wat u met een vers kunt doen, hangt af van uw gebruikersmodus.

### Lezermodus

Lezermodus is rustig en zonder afleiding.

- Tik op een vers om het kort te laten oplichten.
- Er zijn geen studiehulpmiddelen, bladwijzers of menu's.
- Wilt u meer functies, schakel dan in **Instellingen** over naar **Standaard** of **Geleerde**.

### Standaardmodus

Standaardmodus voegt functies voor alledag toe voor persoonlijke Bijbelstudie.

Tik op een vers om een menu te openen met deze opties:

- **Bladwijzer** het vers.
- **Markeer** het in een kleur.
- **Voeg een notitie** toe.
- **Kopieer** de vertaaltekst.
- **Vergelijk** het vers in een andere vertaling.
- **Zoek kruisverwijzingen** op voor het vers.

### Geleerdemodus

Geleerdemodus ontgrendelt elk hulpmiddel voor diepe Bijbelstudie.

Tik op een vers om een menu te openen met alles uit Standaard, plus:

- **Commentaar** op het vers.
- **Woordinfo** en naslag in de brontaal.
- **Woordenboek**-definities.
- **AI-assistent** voor diepere studie.

U kunt op elk moment van modus wisselen in **Instellingen**.

## Hulp nodig bij een specifiek hulpmiddel?

Elk hulpmiddel heeft een eigen gids. Tik op **Hulp** op de beginspagina om ze allemaal te zien. De gids [Studiemodus](theodia://help/study-mode) is een goede start — hij loopt elk hulpmiddel in het versmenu langs.

Bent u nog aan het ontdekken waar alles staat, zie dan de gids [App-indeling en navigatie](theodia://help/navigating-the-app). Die legt het beginscherm, het hoofdmenu en de onderste werkbalk uit.

## Meer bronnen gewenst?

De app bevat enkele vrij beschikbare Bijbelvertalingen. Wilt u er meer toevoegen, of commentaren, boeken of stichtelijke lezingen, zie dan de gids [Extra bronnen van GitHub](theodia://help/getting-core-files). Daar leest u waar u ze vindt en hoe u ze toevoegt.
