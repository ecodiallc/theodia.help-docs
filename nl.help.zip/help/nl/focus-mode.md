---
title: Focusmodus
level: beginner
categories: [layout, read]
summary: Een rustige manier om lange gedeelten te lezen, zonder afleiding.
---

# Focusmodus

> **Modus:** De Focusmodus is de lezer in de **Lezer**-modus. Hij is ook beschikbaar in de modi **Standaard** en **Geleerde** als alternatief voor de Studiemodus. U kunt van modus wisselen in **Instellingen** → **App-gebruikersmodus**.

De Focusmodus is een manier om een Bijbelhoofdstuk te lezen zonder knoppen of menu's in de weg. Die is goed voor lange leessessies.

## Inschakelen

1. Open een willekeurig hoofdstuk.
2. Tik in de rij pictogrammen bovenaan het scherm op de knop 📖. Hij opent hetzelfde hoofdstuk in de Focusmodus.
3. De menu's en knoppen verdwijnen. Alleen de Bijbeltekst blijft over.

In de **Lezer**-modus openen hoofdstukken automatisch in de Focusmodus. De knop 📖 is verborgen omdat er geen Studiemodus is om naar te wisselen.

## Wat u in de Focusmodus kunt doen

- **Scrollen** om te lezen.
- **Vegen** om naar het volgende of vorige hoofdstuk te gaan.
- **Op de knop 📖 tikken** in de onderbalk om terug te wisselen naar de Studiemodus. (Verborgen in de Lezer-modus.)
- **Op de knop 🔊 tikken** in de onderbalk om het hoofdstuk voor te lezen. Er verschijnt een mini-bedieningsbalk met afspelen, pauzeren, terugspoelen, doorspoelen en een stemkiezer. (Verborgen in de Lezer-modus — voorlezen vereist Standaard of Geleerde.)

## Goede toepassingen van de Focusmodus

- Een heel boek doorlezen, hoofdstuk voor hoofdstuk.
- Een lang gedeelte lezen voor stichtelijke lezing of stille tijd.
- Hardop lezen en meelezen zonder afleiding.

## Naar de Studiemodus wisselen

De Focusmodus verbergt elk studiehulpmiddel, maar ze zijn nog steeds op één tik afstand. Tik op de knop 📖 bovenaan het scherm om hetzelfde hoofdstuk in de [Studiemodus](theodia://help/study-mode) te openen. De Studiemodus is de volledige lezer, met commentaar, kruisverwijzingen, lexiconnaslag en notities. Zie de gids [Studiemodus](theodia://help/study-mode) om te zien wat de Studiemodus kan.

In de **Lezer**-modus is de knop 📖 verborgen omdat de Studiemodus niet beschikbaar is.
