---
title: Snel door de app navigeren
level: beginner
categories: layout
summary: Elke snelle manier om naar een vers, hoofdstuk of scherm in Theodia te springen.
---

# Snel door de app navigeren

Deze gids is een spiekbriefje voor navigatie. Het behandelt elke snelle manier om van waar u bent naar waar u wilt zijn te gaan.

## Direct naar een vers springen

De snelste manier om een vers te openen is de **Opdracht** op het beginscherm.

- Typ `John 3:16` en tik op Ga.
- Typ `Psalms 23` en tik op Ga.
- Typ `Genesis 1` en tik op Ga.

De app opent precies dat hoofdstuk (en scrollt naar het vers als u er een opgaf).

## Vegen tussen hoofdstukken

Wanneer u een hoofdstuk leest:

- **Veeg naar links** → volgende hoofdstuk.
- **Veeg naar rechts** → vorige hoofdstuk.

Dit werkt ook over boeken heen. Na Exodus 40 brengt veegen naar links u naar Leviticus 1.

## Gebruik de bovenbalk

Tijdens het lezen toont de bovenkant van het scherm de huidige **vertaling**, het **boek** en het **hoofdstuk**.

- Tik op de naam van de vertaling om van Bijbel te wisselen.
- Tik op de naam van het boek om een ander boek te kiezen.
- Tik op het hoofdstuknummer om een ander hoofdstuk te kiezen.

## Springen vanaf een bladwijzer

Heeft u een vers opgeslagen:

1. Open het tabblad **Bladwijzers**.
2. Tik op een willekeurig item.
3. U gaat meteen naar dat vers.

## Springen vanuit zoeken

1. Open het tabblad **Zoeken**.
2. Typ een woord of zin.
3. Tik op een willekeurig resultaat.
4. De app opent het hoofdstuk met uw zoekwoorden geel gemarkeerd.

## Leesweergaven wisselen

De Bijbellezer heeft twee weergaven:

- **Studiemodus** — toont het hoofdstuk met alle studiehulpmiddelen op één tik afstand.
- **Focusmodus** — verbergt elk hulpmiddel en menu, zodat alleen de tekst overblijft.

Wisselen: tik tijdens het lezen op de knop **📖** bovenaan het scherm. Tik nogmaals om terug te wisselen. (Lezermodus blijft altijd in de Focusmodus.)

## Gebruik de onderste tabbladen

De rij pictogrammen onderaan het scherm is altijd zichtbaar. Tik op een tabblad om naar dat deel te gaan. Welke tabbladen er zijn, hangt af van uw gebruikersmodus:

**Alle modi:**

- **Beginscherm** — terug naar het beginscherm.
- **Bijbels** — lijst van vertalingen.
- **Zoeken** — zoek in de Bijbel, boeken, woordenboeken, lexicons en PDF's.
- **Instellingen** — voorkeuren en bronnen.

**Standaard en Geleerde zien ook:**

- **Bladwijzers** — opgeslagen verzen.
- **Markeringen** — verzen in kleur gemarkeerd.
- **Notities** — uw privénotities.
- **PDF's** — uw geïmporteerde PDF-documenten.

**Geleerde ziet ook:**

- **AI** — de AI-assistent (als ingeschakeld in Instellingen).

### Onthouden waar u was gebleven

Elk tabblad bewaart zijn eigen navigatiegeschiedenis. Wanneer u terugkeert naar een tabblad, gaat u naar **waar u was gebleven**, niet naar het startscherm van dat deel.

- U opent het tabblad **Bijbels**, kiest een vertaling, opent een hoofdstuk en wisselt dan naar **Zoeken**. Later tikt u weer op **Bijbels** en u zit weer bij datzelfde hoofdstuk.
- U opent het tabblad **Bladwijzers**, tikt op een gebladwijzerd vers en wisselt dan naar **Instellingen**. Nogmaals op **Bladwijzers** tikken brengt u terug naar de bladwijzerlijst.

Dit geldt voor elk tabblad. Elk tabblad onthoudt uw plek totdat u zelf naar een ander scherm binnen dat tabblad navigeert.

### Wat een tabblad reset

Een tabblad keert alleen terug naar zijn startscherm als:

- U al op dat tabblad bent en opnieuw op hetzelfde tabbladpictogram tikt. Dit is een snelle manier om het terug te zetten naar het begin.
- De app geforceerd wordt afgesloten en opnieuw wordt geopend.

### Onderste tabbladen versus het hoofdmenu

- **Onderste tabbladen** — elk tabblad onthoudt zijn eigen stapel. Op een tabblad tikken brengt u terug naar waar u was gebleven.
- **Hoofdmenu** — tikken op een item navigeert naar dat scherm. Het is een vervolgkeuzelijst, geen overlay.

Voorbeeld:

- U leest Johannes 3. Tik op het tabblad **Bladwijzers**, tik daarna weer op **Bijbels**. U keert terug naar Johannes 3.
- U leest Johannes 3. Open het menu en tik op **Notities**. Bekijk uw notities en tik daarna op het tabblad **Bijbels** om terug te keren naar Johannes 3.

## Tips

- Het beginscherm onthoudt welke delen zijn uitgeklapt of ingeklapt.
- Ontbreekt een tabblad, controleer dan uw **gebruikersmodus** in **Instellingen** → **App-gebruikersmodus**. Lezermodus verbergt bladwijzers, markeringen, notities en AI. Standaard verbergt AI. Mogelijk moet u ook een functie inschakelen in **Instellingen** of een bron installeren.
