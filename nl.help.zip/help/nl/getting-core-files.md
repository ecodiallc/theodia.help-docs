---
title: Extra bronnen ophalen
level: everyday
categories: resources
summary: Hoe u Bijbels, commentaren, boeken en andere bronnen aan Theodia toevoegt.
---

# Extra bronnen ophalen

Theodia wordt met enkele ingebouwde bronnen geleverd, maar u kunt er meer toevoegen. De gemakkelijkste manier is via het scherm **Bronnen beheren** in de app.

## Wat u kunt toevoegen

- **Bijbels** — meer vertalingen in verschillende talen
- **Commentaren** — studienotities die verzen uitleggen
- **Boeken** — christelijke klassiekers en naslagwerken
- **Stichtelijke lezingen** — dagelijkse stichtelijke lezingen
- **Kernbestanden** — grotere gegevensbestanden zoals morfologie, kruisverwijzingen en de Marvel Interlinear Bible (MIB)

## Bronnen vanuit de app toevoegen

1. Open **Instellingen**.
2. Tik op **Bronnen beheren**.
3. Kies een tabblad: **Kern**, **Bijbels**, **Commentaren**, **Boeken** of **Stichtelijke lezingen**.
4. Blader door de lijst. Tik op een bron om er meer over te lezen.
5. Tik op het selectievakje om te kiezen wat u wilt.
6. Tik onderaan op **Downloaden**. De bestanden worden automatisch gedownload en geïnstalleerd.

Eenmaal geïnstalleerd verschijnt de bron meteen in de app. U hoeft niet te herstarten.

## Kernbestanden

Het tabblad **Kern** heeft grote gegevensbestanden die diepere studiefuncties aandrijven. Daaronder vallen:

- Morfologiegegevens (woordvormen in de brontaal)
- Kruisverwijsdatabases
- De Marvel Interlinear Bible (MIB)

U hoeft kernbestanden maar één keer te downloaden. Ze blijven op uw apparaat en werken offline.

## Wereldbijbels

Het tabblad **Wereldbijbels** heeft Bijbelvertalingen uit een bredere collectie. Ziet u een vertaling die u wilt niet in het hoofdtabblad **Bijbels**, kijk dan hier.

## Geïnstalleerde bronnen beheren

Op het hoofdscherm **Bronnen beheren** (niet het downloadtabblad) kunt u:

- Een bron **inschakelen of uitschakelen** zonder haar te verwijderen. Uitgeschakelde bronnen blijven op uw apparaat maar worden in menu's verborgen.
- Een bron **verwijderen** om ruimte vrij te maken. U kunt haar later opnieuw downloaden.

## Eigen bestanden toevoegen

Heeft u een bronbestand van ergens anders — een vriend, een ander project of een website — dan kunt u het direct importeren:

1. Tik in **Bronnen beheren** op **Lokaal bestand importeren**.
2. Kies het bestand van uw apparaat.
3. De app leest het bestand en voegt het aan uw bibliotheek toe.

De app accepteert deze bestandstypen:

- `.bible` — Bijbelvertalingen
- `.commentary` — commentaren
- `.lexicon` — lexicons
- `.book` — boeken
- `.devotional` — stichtelijke lezingen

## Een eigen GitHub-repository koppelen

Onderhoudt iemand een GitHub-repository met Theodia-compatibele bronnen, dan kunt u die als eigen bron toevoegen:

1. Ga naar **Instellingen → GitHub-repositories**.
2. Tik op **Repository toevoegen**.
3. Voer de GitHub-URL in (bijvoorbeeld `https://github.com/username/repo-name`).
4. Kies welke soorten bronnen de repository bevat (Bijbels, commentaren of boeken).
5. Sla hem op.
6. Keer terug naar **Bronnen beheren**. Er verschijnt een nieuw tabblad met de bronnen uit die repository.

Is de repository privé, dan moet u in **Instellingen → GitHub-repositories** een **Personal Access Token** toevoegen zodat de app haar kan lezen.

## Een kanttekening bij bestandsgroottes

Bronbestanden kunnen groot zijn. Bijbels zijn meestal klein (een paar megabyte). Commentaren en kernbestanden kunnen veel groter zijn (honderden megabytes). Download waar mogelijk via Wi-Fi.

## Samenvatting

- Gebruik **Instellingen → Bronnen beheren** om bronnen te bekijken en te installeren.
- Kernbestanden ontgrendelen diepere studiehulpmiddelen zoals morfologie en kruisverwijzingen.
- Importeer lokale bestanden als u eigen bestanden heeft.
- Voeg eigen GitHub-repositories toe als u bronnen uit een andere bron wilt.
