---
title: Waar u vragen kunt stellen
level: everyday
categories: trouble
summary: Hoe u hulp krijgt van het Theodia-team en de gemeenschap, en hoe u hulponderwerpen in de app vindt.
---

# Waar u vragen kunt stellen

Bent u vastgelopen, dan zijn er een paar plaatsen om hulp te vragen.

## Een hulponderwerp vinden

Zoekt u informatie over een specifieke functie, probeer dan een van deze paden:

- **Bladeren per categorie.** Open **Hulp & Gidsen** en tik op een categorie zoals **Instellingen en aanpassing** of **Problemen oplossen**. Elke kaart toont verwante gidsen.
- **Zoeken op sleutelwoord.** Op het hoofdscherm **Hulp & Gidsen** typt u een woord in het zoekvak bovenaan. Zo toont het typen van `notifications` de gids [Meldingen en herinneringen](theodia://help/notifications); het typen van `search` toont de gids [De Bijbel doorzoeken](theodia://help/search-the-bible).
- **Eerst Instellingen nakijken.** Veel functies worden in **Instellingen** ingesteld. Wilt u herinneringen instellen, open dan **Instellingen** → **Meldingen**. Het instellingenscherm heeft voor elke sectie ook een **Hulp**-link.

## In de app

Open het scherm **Over**. U ziet twee knoppen:

- **Suggestie/probleem indienen** — opent een formulier om het team een vraag, een idee of een bugrapport te sturen.
- **Discussie / Feedback** — opent het gemeenschapsdiscussiebord.

## De GitHub-pagina

U kunt de lijst met bekende problemen en recente wijzigingen zien op [GitHub](https://github.com/ecodiallc/theodia.app).

## Gemeenschapsdiscussie

Andere gebruikers van Theodia stellen vragen en delen tips op het [gemeenschapsdiscussiebord](https://github.com/ecodiallc/theodia.app/discussions). U kunt oude gesprekken lezen en een nieuw gesprek starten.

## Voordat u vraagt

Een paar dingen helpen ons sneller te antwoorden:

- **Wat is uw apparaat?** (bijv. iPhone 13, Pixel 7)
- **Welke versie van de app?** (Open **Over** om het te zien.)
- **Wat deed u?** Een korte beschrijving van de stappen.
- **Wat gebeurde er?** Wat u op het scherm zag.
- **Wat verwachtte u dat er zou gebeuren?** Dit is vaak het nuttigste deel.

## Wat u kunt verwachten

- Voor bugrapporten antwoordt het team meestal binnen enkele dagen.
- Voor ideeën leest het team ze allemaal. We kunnen niet beloven wanneer een idee wordt toegevoegd.
- Voor gemeenschapsvragen antwoorden andere gebruikers vaak sneller dan het team.

## Een kanttekening over privacy

Stuurt u een vraag in, geef dan geen privégegevens door. Het team kan zien wat u stuurt.
