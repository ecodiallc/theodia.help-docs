---
title: GitHub Models
categories: ai
level: advanced
summary: Stel GitHub Models in — een gratis manier om AI in Theodia te verkennen zonder een bestaand API-abonnement.
---

# GitHub Models

> **Modus:** De AI-assistent vereist de modus **Geleerde**. U kunt van modus wisselen in **Instellingen** → **App-gebruikersmodus**.

Betaalt u nog niet voor een AI-dienst, dan is **GitHub Models** de gemakkelijkste manier om de AI van Theodia te verkennen. Het biedt een gratis manier om te beginnen, en alles wat u nodig heeft is een gratis GitHub-account.

## Wat is GitHub Models?

GitHub Models is een dienst van GitHub die u moderne AI-modellen via een API laat draaien. Ze ondersteunt hetzelfde formaat als OpenAI, dus ze werkt naadloos met Theodia.

## Waarom GitHub Models kiezen?

- **Geen creditcard nodig** — Gewoon een GitHub-account.
- **Modellen van hoge kwaliteit** — U krijgt toegang tot GPT-4o, GPT-4.1 en andere betrouwbare modellen die de hulpmiddelen van Theodia ondersteunen.
- **Eenvoudige installatie** — Één token, één URL, en u bent klaar.

## Stap 1: Maak een GitHub-account

Heeft u al een GitHub-account, sla dan over naar Stap 2.

1. Ga naar [github.com](https://github.com).
2. Tik op **Sign up** en volg de instructies om een gratis account te maken.
3. Verifieer uw e-mailadres wanneer GitHub de bevestiging stuurt.

## Stap 2: Maak een Personal Access Token

Dit token is uw API-sleutel. Het vertelt GitHub wie u bent wanneer Theodia vragen stuurt.

1. Ga naar [github.com/settings/tokens](https://github.com/settings/tokens).
2. Tik op **Generate new token** en kies **Generate new token (classic)**.
3. Geef het token een naam zoals **Theodia AI**.
4. Onder **Select scopes**, vink het vakje voor **`models:read`** aan.
   - Dit is de enige toestemming die Theodia nodig heeft.
5. Scroll naar beneden en tik op **Generate token**.
6. **Kopieer het token onmiddellijk.** GitHub toont het maar één keer. Plak het ergens veilig (zoals de notities-app van uw telefoon) totdat u het aan Theodia toevoegt.

## Stap 3: Kies een model

GitHub Models biedt verschillende modellen. Voor Theodia zijn dit de beste opties:

| Model                 | Dagelijkse gratis limiet | Beste voor                                     |
| --------------------- | ------------------------ | ---------------------------------------------- |
| `openai/gpt-4.1-nano` | 150 verzoeken / dag      | Snelle vragen en eenvoudige versuitleg         |
| `openai/gpt-4.1-mini` | 150 verzoeken / dag      | Algemene studie met goede hulpmiddelondersteuning |
| `openai/gpt-4.1`      | 50 verzoeken / dag       | Diepere studie en complexe meerstapsvragen     |
| `openai/gpt-4o`       | 50 verzoeken / dag       | Veelzijdig, uitstekende hulpmiddelondersteuning |

Begin met **`openai/gpt-4.1-mini`** — hij is snel, betrouwbaar en biedt een hogere dagelijkse verzoekenlimiet.

## Stap 4: Stel Theodia in

1. Open **Theodia**.
2. Ga naar **Instellingen** → **AI-assistent**.
3. Zorg dat **Extern model** is geselecteerd.
4. Tik op het vervolgkeuzemenu **Aanbieder** en kies **GitHub Models**.
   - Staat GitHub Models niet in de lijst, tik dan op **Aangepast** en voer de basis-URL handmatig in: `https://models.github.ai`
5. Plak uw GitHub Personal Access Token in het veld **API-sleutel**.
6. Voer uw gekozen model-ID in het veld **Model** in (bijvoorbeeld: `openai/gpt-4.1-mini`).
7. Tik op **Verbinding testen**.
8. Wacht tot de controle klaar is. U zou moeten zien:
   - **✓ Verbinding geslaagd**
   - **✓ Hulpmiddelen ondersteund**

Ziet u **✗ Hulpmiddelen niet ondersteund**, probeer dan een andere model-ID uit de tabel hierboven.

## Stap 5: Begin met chatten

1. Tik onderaan het scherm op het tabblad **AI**.
2. Typ een vraag en tik op **Versturen**.
3. Of tik tijdens het lezen van een willekeurig Bijbelhoofdstuk op een versnummer en kies **AI-commentaar** om een versspecifieke chat te starten.

## Problemen oplossen

### "Verbinding mislukt" of "HTTP 401"

- Zorg dat u het **volledige** token hebt gekopieerd. Het is een lange tekenreeks die begint met `ghp_`.
- Tokens verlopen als ze lang ongebruikt blijven. Ga terug naar GitHub en genereer een nieuw token.
- Controleer dat u **models:read** heeft geselecteerd bij het maken van het token.

### "Hulpmiddelen niet ondersteund"

- Sommige modellen op GitHub Models accepteren geen hulpmiddelaanroepen. Probeer in plaats daarvan **`openai/gpt-4o`** of **`openai/gpt-4.1-mini`**.
- Zorg dat de model-ID precies zo gespeld is als getoond, inclusief het voorvoegsel `openai/`.

### Fouten door snelheidslimiet

- Haalt u de dagelijkse limiet, wissel dan naar een model met een hogere toewijzing (zoals `openai/gpt-4.1-nano` met 150 verzoeken per dag).
- Limieten resetten elke 24 uur.

## Samenvatting

- GitHub Models is de **aanbevolen manier om AI te verkennen** in Theodia.
- U heeft een **gratis GitHub-account** en een **Personal Access Token** met `models:read` nodig.
- Het beste startermodel is **`openai/gpt-4.1-mini`**.
- Voer het token en model in bij **Instellingen → AI-assistent**, tik op **Verbinding testen** en begin met chatten.
