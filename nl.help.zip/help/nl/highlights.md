---
title: Verzen markeren
level: everyday
categories: [annotate, read]
summary: Hoe u verzen in kleur markeert en ze later terugvindt.
---

# Verzen markeren

> **Modus:** Markeringen zijn beschikbaar in de modi **Standaard** en **Geleerde**. De Focusmodus is alleen voor rustig lezen zonder afleiding. U kunt van modus wisselen in **Instellingen** → **App-gebruikersmodus**.

Markeren geeft een vers een kleur. Het werkt als een gele markeerstift op papier. Het vers blijft gemarkeerd wanneer u het de volgende keer opent.

## Een vers markeren

1. Open het vers.
2. Tik op het vers om het menu te openen.
3. Tik op het pictogram **Markeren**.
4. Kies een kleur.

Het vers is nu in die kleur gemarkeerd.

## De markeerkleur veranderen

1. Open het vers.
2. Tik op het vers en tik daarna op het pictogram **Markeren**.
3. Kies een nieuwe kleur.

## Een markering verwijderen

1. Open het vers.
2. Tik op het vers en tik daarna in het menu op **Markeren**.
3. Tik onderaan de kleurenkiezer op **Markering verwijderen**.

## Een gangbare manier om kleuren te gebruiken

Veel lezers gebruiken een klein aantal kleuren voor een klein aantal doelen:

- **Geel** voor algemene favorieten.
- **Groen** voor verzen over God.
- **Blauw** voor verzen over gebed.
- **Roze** voor verzen over vertroosting.
- **Oranje** voor verzen over waarschuwing of terechtwijzing.
- **Paars** voor verzen over profetie of de laatste tijden.

Kies een systeem dat bij u past.

## Al uw markeringen bekijken

Tik onderaan op het tabblad **Markeringen**. U ziet een lijst met elk gemarkeerd vers, nieuwste eerst. Bovenaan zit een rij kleurvlakjes — tik op een kleur om alleen markeringen van die kleur te tonen, of tik op **Alle** om het filter te wissen.

## Markeringen importeren

U kunt markeringen uit andere apps en bestanden in Theodia brengen.

Ga naar **Instellingen** → **Bladwijzers** → **Markeringen importeren**. Kies **Importeren uit bestand** of plak vanaf het klembord. De app herkent het formaat automatisch.

### Ondersteunde formaten

**Eigen JSON-export** — Het formaat van Theodia's eigen exportfunctie:

```json
{
  "/bible/KJV/John/3#v3_16": "yellow",
  "/bible/KJV/Genesis/1#v1_1": "green"
}
```

**CSV** — Een spreadsheet met de kolommen `url` en `color`. Voorbeeld:

```csv
url,color
/bible/KJV/John/3#v3_16,yellow
/bible/KJV/Genesis/1#v1_1,green
```

**Platte tekst** — Elke regel is een Bijbelverwijzing of URL, optioneel gevolgd door een kleurnaam. Voorbeeld:

```
John 3:16 yellow
Genesis 1:1 green
Matthew 5:1
```

- Beschikbare kleuren: `yellow`, `green`, `blue`, `pink`, `orange`, `purple`.
- Wordt geen kleur opgegeven, dan wordt de markering standaard geel.
- Regels die beginnen met `#` of `//` worden als commentaar behandeld en overgeslagen.

## Tips

- Markeringen blijven op uw apparaat. Ze synchroniseren niet met de cloud.
- U kunt een vers in één vertaling markeren en het laten verschijnen in uw andere vertalingen van hetzelfde vers.
- Zie de gids [Back-up van uw gegevens](theodia://help/backups) om ze veilig te houden.
