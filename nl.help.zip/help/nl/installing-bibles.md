---
title: Bijbelvertalingen installeren
level: beginner
categories: start
summary: Hoe u een Bijbelvertaling aan uw bibliotheek toevoegt.
---

# Bijbelvertalingen installeren

Theodia wordt met een paar Bijbelvertalingen geleverd die klaar zijn om te lezen. U kunt er op elk moment meer toevoegen. Een "vertaling" is een andere versie van de Bijbeltekst, zoals de King James Version.

## Een vertaling toevoegen

Het tabblad Bijbel toont een lijst met vertalingen die al geïnstalleerd zijn. Om er meer toe te voegen, opent u de bronnenbeheerder:

1. Open **Instellingen**.
2. Tik op **Bronnen beheren**.
3. Tik op **Installeren vanaf GitHub**.
4. Tik in het downloadvenster op het tabblad **Bijbels**.
5. Tik op het selectievakje naast elke vertaling die u wilt.
6. Tik onderaan op **Geselecteerde installeren**.
7. Wacht tot het downloaden klaar is.

De vertaling zit nu in uw bibliotheek. Om haar te zien, opent u het tabblad **Bijbel**.

## Tussen vertalingen wisselen

1. Open een hoofdstuk dat u wilt lezen.
2. Tik bovenaan het scherm op de naam van de vertaling.
3. Kies uit de lijst degene die u wilt.

De app bewaart uw keuze voor de volgende keer.

## Een vertaling verwijderen

1. Open **Instellingen**.
2. Tik op **Bronnen beheren**.
3. Zoek de vertaling die u wilt verwijderen.
4. Tik op de **X** ernaast.
5. Bevestig dat u haar wilt verwijderen.

Een vertaling verwijderen wist uw notities, markeringen of bladwijzers niet. Die blijven behouden.

## Hoeveel ruimte gebruiken vertalingen?

De meeste vertalingen zijn tussen 2 en 10 MB. Ze worden op uw apparaat opgeslagen, niet in de cloud. U kunt er zoveel bewaren als u wilt, zolang uw apparaat maar ruimte heeft.

## Wat als een vertaling niet in de app zit?

Sommige vertalingen staan niet in de lijst in de app. U kunt ze alsnog toevoegen.

1. Open de app en ga naar **Instellingen** → **Bronnen beheren**.
2. Tik op **Installeren vanaf GitHub**.
3. Kijk in het downloadvenster op het tabblad **Bijbels** en het tabblad **Wereldbijbels**. Staat uw vertaling er, selecteer haar dan en tik op **Geselecteerde installeren**.
4. Staat hij er niet, tik dan op **Lokaal bestand importeren** om een `.bible`-bestand te importeren. Dat bestand haalt u van de GitHub-pagina van het project. Zie de gids [Extra bronnen van GitHub](theodia://help/getting-core-files) voor stapsgewijze hulp.
