---
title: De kernbestanden toevoegen
level: beginner
categories: start
summary: Hoe u de grote gegevensbestanden downloadt die de app nodig heeft om de Bijbel diep te bestuderen.
---

# De kernbestanden toevoegen

Theodia wordt geleverd met een Bijbel en een paar kleine extra's die klaar zijn om te gebruiken. Om het meeste uit de app te halen, moet u ook de **kernbestanden** downloaden. Dit zijn grote gegevensbestanden die studiehulpmiddelen toevoegen zoals commentaar, woordnaslag en grammatica-aantekeningen. Zonder hen werkt de app, maar de studiefuncties zijn beperkt.

## Waarom u de kernbestanden nodig heeft

De kernbestanden voegen toe:

- **Woordnaslag.** Tik op een woord in elk vers om het oorspronkelijke Hebreeuws of Grieks te zien en wat het betekent.
- **Commentaar.** AI-commentaar bij elk vers.
- **Grammatica.** Informatie over elk woord in de brontaal.
- **Interlineaire Bijbel.** Lees de brontaaltekst met Engels onder elk woord.

U kunt de Bijbel zonder hen lezen, maar de meeste studiehulpmiddelen hebben hen nodig.

## De kernbestanden installeren

**[Kernbestanden installeren](theodia://manage/core)**

1. Open **Instellingen**.
2. Tik op **Bronnen beheren**.
3. Het tabblad **Kern** opent. U ziet een lijst met de kernbestanden. Elk heeft een naam, een grootte en een selectievakje.
4. Tik op elk bestand dat u wilt installeren. Een vinkje toont dat het is gekozen.
5. Tik op **Geselecteerde installeren**.
6. Wacht tot de bestanden zijn gedownload en geïnstalleerd. Ze zijn groot, dus dit kan op een trage verbinding enkele minuten duren.

De bestanden worden naar uw apparaat gedownload. U hoeft dit maar één keer te doen. De app gebruikt de bestanden vanaf dan, zelfs offline.

## Tips

- Gebruik Wi-Fi. De bestanden zijn groot.
- Sluit uw telefoon of tablet aan. Grote downloads kosten batterij.
- Mislukt een download, tik dan opnieuw op het bestand om te herproberen.
- U kunt ze allemaal installeren of alleen degen die u nodig heeft.

## Wat als een bestand in de lijst ontbreekt?

De app haalt de lijst van de GitHub-pagina van het project. Is de lijst leeg, controleer dan uw internetverbinding en probeer het opnieuw. Is hij nog steeds leeg, zie dan de gids [Waar u vragen kunt stellen](theodia://help/getting-more-help).

Zie voor geavanceerdere manieren om bronnen toe te voegen de gids [Extra bronnen van GitHub](theodia://help/getting-core-files).
