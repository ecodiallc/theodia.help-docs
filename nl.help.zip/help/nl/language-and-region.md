---
title: Apptaal en regio
level: everyday
categories: settings
summary: Hoe u de taal van de app veranderd.
---

# Apptaal en regio

Theodia is beschikbaar in vele talen. De app kan de taal van menu's en knoppen veranderen. Hulpinhoud is ook in veel van deze talen beschikbaar en zit in de app ingebouwd. U kunt het hulppakket van een taal ook downloaden of bijwerken — open **Instellingen** → **Hulp** of **Bronnen beheren** → **Installeren vanaf GitHub** → **Hulpdocumenten**.

## De taalinstellingen openen

1. Open **Instellingen**.
2. Tik op **Taal**.

## De apptaal veranderen

1. Tik in de lijst **Taal** op de taal die u wilt.
2. De app past de nieuwe taal meteen toe.

Welke keuzes u ziet, hangt af van de talen die de app ondersteunt.

## Hoe de taal bij de eerste installatie wordt gekozen

Wanneer u Theodia voor het eerst installeert, kiest de app een taal op basis van de instellingen van uw apparaat. U kunt die op elk moment veranderen.

## Wat wordt vertaald

- Menu's, knoppen en labels.
- Instellingenschermen.
- Foutmeldingen.
- Zoek- en studiehulpmiddelen.

## Wat alleen in het Engels is

- Sommige boek- en stichtelijke-lezinginhoud.

## Bijbelvertalingen en apptaal

De apptaal en de taal van de Bijbelvertaling zijn verschillende dingen. U kunt de app in het Spaans hebben en de Bijbel in het Engels, of andersom.

Om de Bijbelvertaling te veranderen, zie de gids [Bijbelvertalingen installeren](theodia://help/installing-bibles).

## Tips

- Is een knop of label leeg, dan ontbreekt er een vertaling. Meestal staat de Engelse versie er als terugval.
- Wilt u helpen de app te vertalen, zie dan de gids [Waar u vragen kunt stellen](theodia://help/getting-more-help).
