---
title: Het Launcher-menu
level: everyday
categories: layout
summary: Een snelle manier om naar recente verzen te springen, opdrachten uit te voeren en Bijbelindelingen te wisselen zonder uw huidige scherm te verlaten.
---

# Het Launcher-menu

> **Modus:** Het Launcher-menu vereist de modus **Geleerde**. U kunt van modus wisselen in **Instellingen** → **App-gebruikersmodus**.

Het Launcher-menu is een sneltoegangspaneel dat u vanuit bijna overal in de app kunt openen. Het houdt uw recente verzen, opdrachten en opgeslagen Bijbelindelingen op één plaats.

## Openen

Tik op het **uitklappictogram (⌄)** in de rechterbovenhoek van de kop van het beginscherm. Er schuift een paneel van boven binnen.

## Wat erin zit

### 1. Opdrachtvak

Bovenaan het paneel zit een tekstvak met een toetsenbordpictogram. Typ een opdracht en tik op **Go** op uw toetsenbord. De app leest de opdracht en brengt u meteen erheen.

Voorbeelden:

- `John 3:16` — opent dat vers.
- `search love` — doorzoekt de Bijbel op "love".
- `bookmark psalms 23` — voorziet het vers van een bladwijzer.
- `kjv` — wisselt naar de KJV-vertaling.

Voor de volledige lijst met opdrachten, zie de gids [Opdrachten](theodia://help/commands).

### 2. Parallelle sets

Heeft u parallelle Bijbelpresets opgeslagen, dan verschijnen ze hier als een inklapbare lijst. Tik op een preset om die parallelle instelling meteen te laden.

Een parallelle preset maken:

1. Open **Instellingen** → **Parallelle Bijbel**.
2. Voeg vertalingen toe en tik op **Preset opslaan**.
3. Geef het een naam. Het verschijnt in het Launcher-menu.

Houd in het Launcher-menu een parallelle set lang ingedrukt om hem te verwijderen.

### 3. Bijbelcollecties

Bijbelcollecties zijn shortcuts van één tik die tegelijk uw vertaling en parallelle weergave wisselen. Heeft u er gemaakt, dan verschijnen ze hier als een inklapbare lijst.

Houd een collectie lang ingedrukt om haar te verwijderen.

### 4. Functiepictogrammen

Onder het opdrachtvak ziet u mogelijk een rij ronde emoji-knoppen. Dit zijn shortcuts van één tik naar de belangrijkste functies van de app.

Beschikbare pictogrammen zijn onder andere:

- **Over**, **Bijbels**, **Bijbelnotities**, **Bladwijzers**, **Boeken**
- **Stichtelijke lezingen**, **Flashcards**, **Hulp**, **Markeringen**
- **Afspeellijsten**, **Plug-ins**, **Zoeken**, **Instellingen**, **Theoscript**

Om te kiezen welke pictogrammen verschijnen en in welke volgorde:

1. Open **Instellingen** → **Launcher-menu**.
2. Tik op **Launcher-menu-pictogrammen**.
3. Gebruik de schakelaars om elk pictogram te tonen of te verbergen.
4. Gebruik de pijlen omhoog/omlaag om de pictogrammen die u heeft ingeschakeld te herschikken.

De volgorde in de instellingen is de volgorde waarin ze in het Launcher-menu verschijnen.

### 5. Recente verzen

De app onthoudt de laatste hoofdstukken en verzen die u opende. Ze verschijnen als een lijst onderaan het paneel. Tik op een item om er meteen naar terug te springen.

- **Tik** om te openen.
- **Veeg naar links** of **houd lang ingedrukt** om uit de lijst te verwijderen.
- Tik op **Alles wissen** om elk item tegelijk te verwijderen.

## Wanneer het Launcher-menu gebruiken

Gebruik het wanneer u wilt:

- Terugspringen naar een vers dat u net las.
- Een opdracht typen zonder naar het beginscherm te gaan.
- Vertaling of parallelle instelling wisselen met één tik.
- Een grote functie openen van overal in de app.
- Snel iets nakijken zonder door menu's te navigeren.

## Tips

- Het Launcher-menu is op bijna elk scherm beschikbaar, zodat u het kunt openen tijdens het lezen van een hoofdstuk.
- Het opdrachtvak ondersteunt dezelfde opdrachten als het opdrachtvak op het beginscherm.
- Functiepictogrammen en hun volgorde worden lokaal op uw apparaat opgeslagen. Ze overleven een herstart van de app.
- Recente verzen worden lokaal op uw apparaat opgeslagen. Ze overleven een herstart van de app.
