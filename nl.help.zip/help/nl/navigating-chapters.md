---
title: Navigeren tussen boeken, hoofdstukken en verzen
level: everyday
categories: [layout, read]
summary: Hoe u door de Bijbel beweegt en naar waar u wilt gaan springt.
---

# Navigeren tussen boeken, hoofdstukken en verzen

Deze gids toont u alle manieren om door de Bijbel te bewegen.

## De gemakkelijke manier: vegen

- Veeg **naar links** over een hoofdstuk om naar het volgende hoofdstuk te gaan.
- Veeg **naar rechts** om terug te gaan.
- Dit werkt ook voor het volgende boek. Na het laatste hoofdstuk van bijvoorbeeld Exodus brengt de veeg u naar het eerste hoofdstuk van Leviticus.

## De menu-manier

- Tik bovenaan op de naam van de vertaling om naar een andere Bijbel te wisselen.
- Tik bovenaan op de naam van het boek om een ander boek te kiezen.
- Tik op het hoofdstuknummer om een ander hoofdstuk te kiezen.

## De snelle manier: typen

- Op de beginspagina staat bovenaan een vak. Typ een verwijzing, zoals `John 3:16` of `psalms 23`, en tik op de **Go**-toets op het toetsenbord.
- De app opent het vers.

## De bladwijzer-manier

Heeft u een vers opgeslagen, open dan het tabblad **Bladwijzers**. Tik op een willekeurig item om ernaartoe te springen.

## De zoek-manier

Tik op het tabblad **Zoeken**. Typ een woord. De app toont elk vers waarin het voorkomt. Tik op een willekeurig resultaat om het te openen.

## De geschiedenis-manier

De app onthoudt hoofdstukken die u heeft geopend. Om ze terug te vinden, kijk in het tabblad **Bladwijzers** (voor verzen die u heeft opgeslagen) of scroll door de boekenlijst in het tabblad **Bijbel** om een boek te vinden dat u onlangs las.

## Tips

- Het tabblad Bijbel toont de boeken in volgorde van Genesis tot Openbaring.
- Voor Psalmen, Spreuken en andere lange boeken: tik op het boek en gebruik de hoofdstuklijst om ver vooruit te springen.
