---
title: App-indeling en navigatie
level: beginner
categories: layout
summary: Een rondleiding langs het beginscherm, het hoofdmenu en de onderste werkbalk — waar alles te vinden is.
---

# App-indeling en navigatie

Theodia heeft drie hoofdgebieden waar u tussen kunt bewegen: het **beginscherm**, het **hoofdmenu** en de **onderste werkbalk**. Deze gids loopt ze elk langs, zodat u altijd weet waar u heen moet.

## Een korte kaart

- Het **beginscherm** is de pagina die u ziet wanneer u de app voor het eerst opent. Het heeft een zoekvak, grote knoppen voor elk deel van de app en een lijst met uw geïnstalleerde Bijbels, boeken en stichtelijke lezingen.
- De **onderste werkbalk** (ook de tabbladbalk genoemd) is de rij pictogrammen onderaan het scherm. Tik op een van hen om meteen naar dat deel van de app te springen.
- Het **hoofdmenu** is het pictogram met drie strepen (☰) in de rechterbovenhoek van het beginscherm. Tik erop om een lijst met elk scherm in de app te openen, ook degen zonder eigen tabblad.

## Het beginscherm

Wanneer u Theodia voor het eerst opent, landt u op het beginscherm. Het is van boven naar beneden in vier delen verdeeld.

### De kop

Helemaal bovenaan zit een gekleurde balk. Links staat het app-pictogram en de naam "Theodia". Rechts zit de knop van het hoofdmenu (☰). Zit u in een boek of hoofdstuk, dan toont de linkerkant in plaats daarvan een terugknop (←). Tik op het hoofdmenu om het menu te openen (zie hieronder).

### De Opdracht

Net onder de kop zit een tekstvak in zoekstijl met het label **Opdracht**. Typ een korte instructie en tik op de ga-toets van uw toetsenbord. De app leest de instructie en brengt u naar het juiste scherm. Voorbeelden:

- `psalms 23` — opent Psalm 23
- `john 3:16` — opent Johannes 3:16
- `search love` — doorzoekt de Bijbel op "love"
- `bookmark john 3:16` — slaat Johannes 3:16 op als bladwijzer
- `commentary romans 8:28` — opent het commentaar bij dat vers
- `xref` (gevolgd door een verwijzing) — opent de kruisverwijzingen bij dat vers
- `help` — opent de lijst met opdrachten en voorbeelden

Begrijpt de app niet wat u typte, dan toont hij een kleine waarschuwing met een hint. Zie de gids **Veelvoorkomende problemen** als opdrachten niet werken.

### Het knopraster

Onder de Opdracht zit een raster met grote knoppen, twee per rij. Elke knop brengt u naar een ander deel van de app. De knoppen zijn:

- 📖 **Bijbels** — uw lijst met Bijbelvertalingen
- 🔍 **Zoeken** — zoek de Bijbel door op een woord of zin
- 📚 **Boeken** — uw bibliotheek met christelijke klassiekers
- 📅 **Stichtelijke lezingen** — dagelijkse stichtelijke lezingen
- 🔖 **Bladwijzers** — uw opgeslagen verzen en hoofdstukken
- 🖍 **Markeringen** — uw verzen in kleur gemarkeerd
- 📝 **Notities** — uw privénotities bij verzen
- ⚙️ **Instellingen** — taal, thema, bronnen en meer
- ❓ **Hulp** — het hulpsysteem (deze pagina)
- ℹ️ **Over** — app-versie en credits

### De bronnenlijsten

Onder het knopraster zitten uitklapbare secties: **Bijbels**, **Boeken** en **Stichtelijke lezingen**. Elke sectie toont de items die u heeft geïnstalleerd. Tik op een sectiekop om die uit of in te klappen. Tik op een item in een sectie om het te openen.

De sectie Bijbels is de snelste manier om in een specifieke vertaling te springen — geen menu's, gewoon tikken.

## De onderste werkbalk

De onderste werkbalk (tabbladbalk) is de rij pictogrammen onderaan het scherm. Die blijft bijna overal in de app zichtbaar, zodat u altijd naar een ander deel kunt springen. Welke tabbladen u ziet, hangt af van uw gebruikersmodus.

**Alle modi zien:**

- 🏠 **Beginscherm** — opent het beginscherm
- 📖 **Bijbels** — opent uw lijst met Bijbelvertalingen
- 📚 **Boeken** — opent uw boekenbibliotheek
- 🔍 **Zoeken** — opent Bijbelzoeken
- ⚙️ **Instellingen** — opent de instellingen

**Standaard- en Geleerdemodus zien ook:**

- 🔖 **Bladwijzers** — opent uw opgeslagen verzen
- 🖍 **Markeringen** — opent uw verzen in kleur gemarkeerd
- 📝 **Notities** — opent uw privénotities

**Geleerdemodus ziet ook:**

- 💻 **AI** — opent de AI-assistent (als u die in Instellingen heeft aangezet)

Het huidige tabblad is gemarkeerd. Tik op een ander tabblad om te wisselen.

### Hoe de werkbalk zich gedraagt

Elk tabblad in de werkbalk heeft zijn eigen **stapel** van schermen. Wanneer u op een tabblad tikt, gaat u terug naar **waar u was gebleven** in de stapel van dat tabblad, niet naar het startscherm. Bijvoorbeeld:

- Tik op **Bijbels** → u ziet de lijst met Bijbelvertalingen.
- Tik op een vertaling → u ziet de lijst met boeken.
- Tik op een boek → u ziet de lijst met hoofdstukken.
- Tik op een hoofdstuk → u leest het hoofdstuk.
- Wissel naar **Bladwijzers** om iets na te kijken.
- Tik weer op **Bijbels** → u keert terug naar het hoofdstuk dat u aan het lezen was.

Elk tabblad onthoudt uw plek. De app bewaart uw navigatiegeschiedenis binnen elk tabblad, dus wisselen tussen tabbladen kost geen voortgang.

### Wat een tabblad reset

Een tabblad keert alleen terug naar zijn startscherm als:

- U al op dat tabblad bent en opnieuw op hetzelfde tabbladpictogram tikt. Dit is een snelle manier om terug naar het begin te gaan.
- De app geforceerd wordt afgesloten en opnieuw wordt geopend.

### Onderste tabbladen versus het hoofdmenu

- **Onderste tabbladen** — elk tabblad onthoudt zijn eigen stapel. Op een tabblad tikken brengt u terug naar waar u was gebleven.
- **Hoofdmenu** — tikken op een item navigeert naar dat scherm via hetzelfde tabbladsysteem. Het opent niet als overlay.

Gebruik de tabbladen om van taak te wisselen. Gebruik het hoofdmenu wanneer u een volledige lijst met elk scherm in de app wilt.

### Wanneer de werkbalk gebruiken

Gebruik de werkbalk wanneer u wilt wisselen van bezigheid:

- U leest een hoofdstuk en wilt iets anders zoeken → tik op **Zoeken**.
- U zoekt en wilt uw bladwijzers nakijken → tik op **Bladwijzers**.
- U bent ergens in de app en wilt naar huis → tik op **Beginscherm**.

## Het hoofdmenu

Het hoofdmenu is de knop met drie gestapelde strepen (☰) in de rechterbovenhoek van het beginscherm. Tik erop en er schuift een paneel vanaf de rechterkant binnen. Het paneel toont elk scherm dat uw huidige modus ondersteunt:

- 🏠 **Beginscherm**
- 📖 **Bijbels**
- 📚 **Boeken**
- 🙏 **Stichtelijke lezingen**
- 🔍 **Zoeken**
- 🔖 **Bladwijzers** (Standaard en Geleerde)
- 🖍 **Markeringen** (Standaard en Geleerde)
- 📝 **Notities** (Standaard en Geleerde)
- 💻 **AI-assistent** (alleen Geleerde, en alleen als AI is aangezet)
- ⚙️ **Instellingen**
- ❓ **Hulp**
- ℹ️ **Over**

Het item dat bij het scherm waar u nu bent hoort, is gemarkeerd en heeft er een klein puntje naast. Tik op een item om er meteen heen te gaan. Tik buiten het paneel, op de X bovenaan of op de terugknop van uw apparaat om het te sluiten zonder van scherm te wisselen.

### Hoe het hoofdmenu anders is

Het hoofdmenu is een vervolgkeuzepaneel, geen aparte navigatielaag. Wanneer u op een item tikt, navigeert de app naar dat scherm op dezelfde manier alsof u het onderste tabblad of het knopraster had gebruikt. De stapel van uw huidige tabblad blijft behouden, zodat u door opnieuw op het oorspronkelijke tabblad te tikken kunt terugkeren naar waar u was.

Bijvoorbeeld:

- U leest Johannes 3. U tikt op het tabblad **Bladwijzers**. U gaat naar uw bladwijzers. Tikt u weer op **Bijbels**, dan keert u terug naar Johannes 3 — precies waar u was gebleven.
- U leest Johannes 3. U opent het hoofdmenu en tikt op **Notities**. Uw notities openen. Om terug naar Johannes 3 te gaan, tikt u op het tabblad **Bijbels** en u keert automatisch naar het hoofdstuk terug.

De tabbladen wisselen uw context en onthouden uw plek. Het hoofdmenu is gewoon een andere manier om dezelfde schermen te bereiken.

### Wanneer het hoofdmenu gebruiken

Gebruik het hoofdmenu wanneer:

- U **Markeringen**, **Notities**, **Stichtelijke lezingen**, **Hulp** of **Over** wilt openen — schermen zonder eigen werkbalktabblad.
- U diep in een hoofdstuk of zoekopdracht zit en snel iets wilt nakijken zonder uw plek te verliezen.
- U **Instellingen** wilt openen zonder het scherm waar u bent te verlaten.

## Geleerdemodus

Staat uw gebruikersmodus op **Geleerde**, dan krijgt de indeling extra tabbladen, menu-items en lezerhulpmiddelen die Lezer en Standaard verbergen. Zie de gids [Geleerdemodus](theodia://help/scholar-mode) voor een volledige rondleiding langs elke functie.

## Hoe de drie gebieden samenhoren

- **Naar een ander hoofdgedeelte wisselen** (Bijbels, Zoeken, Bladwijzers enz.) → Onderste werkbalk
- **Naar een specifiek vers of commando springen** → Opdracht op het beginscherm
- **Alle beschikbare schermen bekijken** → Knopraster op het beginscherm
- **Notities, Markeringen of Hulp nakijken zonder uw plek te verlaten** → hoofdmenu
- **Instellingen van overal openen** → hoofdmenu of werkbalk

U zult alle drie gebruiken. Geen enkele is "de juiste manier." Kies wat u het gemakkelijkst vindt voor wat u doet.

### Werkbalk versus hoofdmenu: een snel voorbeeld

Stel dat u Romeinen 8 leest en een vers dat u mooi vindt wilt markeren.

**Met de werkbalk:**

1. Tik op het vers om het versmenu te openen.
2. Tik op **Markeren** en kies een kleur.
3. Gereed. U heeft het hoofdstuk nooit verlaten.

**Met het hoofdmenu (als u uw markeringen wilt nalezen):**

1. Tik op ☰ om het menu te openen.
2. Tik op **Markeringen**. Uw markeringenlijst opent.
3. Lees ze na en tik daarna op het tabblad **Bijbels** om terug te keren naar Romeinen 8.

**Met de werkbalk (als u van taak wilt wisselen):**

1. Tik op **Beginscherm** of **Bladwijzers** in de werkbalk.
2. U verlaat Romeinen 8 en gaat naar het nieuwe scherm.
3. Om terug naar Romeinen 8 te gaan, tikt u weer op **Bijbels** — u keert automatisch naar het hoofdstuk terug.

## Tips

- Het beginscherm onthoudt welke secties zijn uitgeklapt of ingeklapt. U hoeft het maar één keer in te stellen.
- Ziet u een tabblad dat u verwachtte niet, controleer dan twee dingen:

1. **Uw gebruikersmodus** — Lezermodus verbergt bladwijzers, markeringen, notities en AI. Standaard verbergt AI. Wissel van modus in **Instellingen** → **App-gebruikersmodus**.
2. **Functie-instellingen** — sommige tabbladen moeten in **Instellingen** worden aangezet (bijvoorbeeld de AI-assistent).
