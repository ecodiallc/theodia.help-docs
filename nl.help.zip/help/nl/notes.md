---
title: Notities schrijven
level: everyday
categories: [annotate, read]
summary: Hoe u uw eigen gedachten bij een vers schrijft.
---

# Notities schrijven

> **Modus:** Notities zijn beschikbaar in de modi **Standaard** en **Geleerde**. De Focusmodus is alleen voor rustig lezen zonder afleiding. U kunt van modus wisselen in **Instellingen** → **App-gebruikersmodus**.

Notities zijn de plek waar u uw eigen gedachten, gebeden of studie-ideeën bij een vers schrijft. Elke notitie is gekoppeld aan een specifiek vers.

## Een notitie toevoegen

1. Open het vers.
2. Tik op het vers om het menu te openen.
3. Tik in het menu op **Notitie**. Die heeft een potloodpictogram.
4. Typ uw notitie.
5. Tik op **Opslaan**.

De notitie is nu bij het vers opgeslagen.

## Een notitie lezen

1. Open het vers.
2. Let op het potloodteken naast het vers. Dat betekent dat er een notitie is.
3. Tik op het vers. De notitie verschijnt eronder.

## Een notitie bewerken

1. Open het vers met de notitie.
2. Tik op het vers.
3. Tik in het menu op **Notitie**.
4. Breng uw wijzigingen aan.
5. Tik op **Opslaan**.

## Een notitie verwijderen

1. Open het vers met de notitie.
2. Tik op het vers.
3. Tik in het menu op **Notitie**.
4. Tik op **Verwijderen**.

## Al uw notities bekijken

Tik onderaan op het tabblad **Notities**. U ziet een lijst met elke notitie die u heeft geschreven, op datum gesorteerd.

## Uw notities doorzoeken

Tik in het tabblad **Notities** op het **Zoek**vak. Typ een woord. De app vindt elke notitie met dat woord.

## Tips

- Notities zijn ideaal voor preken, stichtelijke lezingen en studiedevragen.
- Notities zijn privé. Ze blijven op uw apparaat.
- Zie de gids [Back-up van uw gegevens](theodia://help/backups) om ze veilig te houden.
