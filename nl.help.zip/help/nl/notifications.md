---
title: Meldingen en herinneringen
level: everyday
categories: [settings]
summary: Hoe u offline herinneringen voor gebed, stichtelijke lezingen, Bijbelplannen en meer inschakelt, aanpast en beheert.
---

# Meldingen en herinneringen

Theodia kan u herinneren aan gebed, stichtelijke lezingen, Bijbelplannen, flashcards en andere activiteiten — zelfs wanneer de app offline is. Alle herinneringen worden op uw apparaat ingepland; er is geen internetverbinding of pushmeldingsserver nodig.

## Herinneringen aan- of uitzetten

1. Open **Instellingen**.
2. Tik op **Meldingen**.
3. Zet **Herinneringen inschakelen** aan of uit.

De eerste keer dat u herinneringen inschakelt, vraagt de app om toestemming om meldingen te sturen. Tik op **Toestaan** zodat de herinneringen kunnen verschijnen.

Heeft u eerder toestemming geweigerd, dan kan iOS of Android het verzoek blokkeren. Ga in dat geval naar de app **Instellingen** van uw apparaat, zoek **Theodia** en zet daar de meldingen aan.

## Soorten herinneringen

Het meldingenscherm is verdeeld in kanalen. Elk kanaal is een familie herinneringen die u onafhankelijk aan of uit kunt zetten:

- **Gebedsherinneringen** — algemene gebedsherinneringen.
- **Gebedsritme** — herinneringen gekoppeld aan een specifiek gebedsritme.
- **Stichtelijke lezing** — de dagelijkse vers- of stichtelijke-lezingherinnering.
- **Bijbelplanherinneringen** — herinneringen voor een actief Bijbelplan.
- **Theoscript-herinneringen** — herinneringen om een Theoscript uit te voeren.
- **AI-inzichtherinneringen** — door AI gegenereerde herinneringen.
- **Flashcard-herhalingsherinneringen** — herinneringen om flashcards te herhalen.
- **Leesgewoonteherinneringen** — dagelijkse herinneringen voor leesgewoonten.
- **Liturgische en seizoensgebonden herinneringen** — herinneringen gekoppeld aan de kerkkalender.
- **Mijn herinneringen** — herinneringen die u maakte vanuit bladwijzers, markeringen, afspeellijsten, Bijbelhoofdstukken of boeken.
- **Eigen herinneringen** — volledig eigen herinneringen die u zelf maakt.

Tik op een kanaal om zijn herinneringen te zien, de tijd te veranderen, te kiezen op welke dagen het afgaat, of het uit te zetten.

## Eigen herinneringen

Eigen herinneringen zijn herinneringen die u vanaf nul opbouwt.

1. Tik in **Instellingen** → **Meldingen** op **Eigen herinneringen**.
2. Tik op de knop **+**.
3. Voer een **Titel** en **Bericht** in.
4. Kies een **Tijd**.
5. Kies de **Dagen** waarop hij moet herhalen.
6. Kies wat de herinnering opent wanneer erop wordt getikt (optioneel).
7. Tik op **Opslaan**.

U kunt een eigen herinnering op elk moment bewerken of verwijderen door er in de lijst op te tikken.

## Wat er gebeurt wanneer u op een herinnering tikt

De meeste herinneringen openen een specifiek scherm in de app. Zo opent een gebedsritme-herinnering dat ritme; een Bijbelplanherinnering opent de volgende lezing.

Heeft een herinnering geen gekoppeld scherm, dan opent ze de app op het beginscherm.

## Stille uren

Stille uren dempen het geluid van meldingen maar laten visuele herinneringen verschijnen.

1. Tik in **Instellingen** → **Meldingen** op **Stille uren**.
2. Stel een **Start**- en **Eind**tijd in.

Herinneringen die tijdens de stille uren ingepland zijn, verschijnen op het scherm zonder geluid.

## Aankomende herinneringen en geschiedenis

- **Aankomende herinneringen** toont alles wat de volgende keer zal afgaan.
- **Meldingsgeschiedenis** toont onlangs afgeleverde, ingeplande en geannuleerde herinneringen.

Gebruik deze lijsten om te bevestigen dat een herinnering goed is ingesteld of om te zien waarom een herinnering niet verscheen.

## Als herinneringen niet verschijnen

- Zorg dat **Herinneringen inschakelen** aanstaat.
- Controleer dat meldingen zijn toegestaan in de systeeminstellingen van uw apparaat.
- Zorg dat het kanaal van de herinnering is ingeschakeld en er ten minste één dag is gekozen.
- Heeft u stille uren ingesteld, dan kan de herinnering stil zijn.
- Sommige Android-fabrikanten laten apps slapen. Voeg Theodia toe aan de toegestane lijst als uw apparaat batterij-optimalisatie-instellingen heeft.
- Is een herinnering gekoppeld aan inhoud die u verwijderde (bijvoorbeeld een verwijderd Bijbelplan of ritme), dan gaat die mogelijk niet af totdat u een geldig doel opnieuw kiest.

## Meldingsgeluiden

U kunt het geluid kiezen dat herinneringen die geluiden ondersteunen afspelen. Tik in een herinnering of kanaal op **Geluid** om uit de beschikbare opties te kiezen. Geluiden zitten bij de app, dus ze werken offline.

Gebruik de knop **Geluid beluisteren** om het gekozen geluid te horen voordat u opslaat.

## Badges

Sommige herinneringen kunnen een badge op het app-pictogram toevoegen. Tik op het meldingenscherm op **Badge wissen** om haar te resetten.
