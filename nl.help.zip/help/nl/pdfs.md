---
title: PDF's
level: everyday
categories: [read, resources]
summary: PDF-documenten importeren, organiseren en lezen in Theodia.
---

# PDF's

> **Modus:** PDF's zijn beschikbaar in de modi **Standaard** en **Geleerde**. Focusmodus is uitsluitend voor schoon, afleidingsvrij lezen. U kunt van modus wisselen in **Instellingen** → **App-gebruikersmodus**.

Theodia kan PDF-bestanden opslaan en lezen. Geïmporteerde PDF's blijven op uw apparaat, dus ze werken offline.

## De PDF-bibliotheek openen

Tik onderaan het scherm op het tabblad **PDF's** of tik op het tegel **PDF's** op het beginscherm.

## Een PDF importeren

1. Open het tabblad **PDF's**.
2. Tik op de knop **+** rechtsonder.
3. Kies een PDF van uw apparaat.
4. (Optioneel) Typ of kies een categorie om de PDF te organiseren.

## PDF's organiseren

Houd een PDF-kaart lang ingedrukt om een menu te openen met deze opties:

- **Hernoemen** — de titel veranderen die in de bibliotheek wordt getoond.
- **Categorie veranderen** — de PDF naar een categorie verplaatsen.
- **Verwijderen** — de PDF uit Theodia verwijderen. Dit verwijdert ook de opgeslagen leespositie.

Categorieën zijn vrije tekst. Typ een nieuwe naam of kies een bestaande wanneer u importeert of een categorie verandert.

## Een PDF lezen

Tik op een PDF-kaart om haar te openen. De lezer toont:

- De documenttitel in een balk bovenaan.
- Een rij paginaknoppen: **Eerste pagina**, **Vorige**, de huidige pagina ("3 / 120"), **Volgende** en **Laatste pagina**.
- Een werkbalk met de gereedschappen van het document: **Inhoud**, **Uitzoomen**, **Inzoomen**, **Zoom herstellen**, **Bladwijzer**, **Zoeken**, **Luisteren** en **Tekstweergave**.

Sommige gereedschappen zijn gedimd wanneer ze niet kunnen worden gebruikt — zo zijn **Zoeken** en **Luisteren** gedimd totdat de doorzoekbare tekst van de PDF is geïnstalleerd.

### Bladzijden omslaan

- Tik op het **linker-** of **rechterpijltje** om één pagina terug of vooruit te gaan.
- Tik op **Eerste pagina** of **Laatste pagina** om naar een van beide uiteinden van het document te springen.
- Tik op het paginanummer (bijvoorbeeld "3 / 120") om een raster van pagina's te openen en tik op de pagina die u wilt. Het raster opent bij de pagina waar u bent.
- Gebruik de **pijltjestoetsen Links** en **Rechts** op een extern toetsenbord.

### Zoomen

- Tik op **Inzoomen** (+) of **Uitzoomen** (−) om het paginaformaat te veranderen.
- Tik op **Zoom herstellen** om de pagina naar de normale grootte terug te brengen.
- Zoomt u in, slaat u de pagina om en zoomt u daarna uit, dan brengt Theodia u terug naar de pagina die u las.

## Binnen een PDF zoeken

1. Open de PDF en tik op de knop **Zoeken** (vergrootglas) in de werkbalk.
2. Typ wat u zoekt. Resultaten verschijnen terwijl u typt, met het paginanummer en een fragment van de omringende tekst.
3. Tik op een resultaat om naar die pagina te springen.

Zoeken vereist dat de doorzoekbare tekst van de PDF is geïnstalleerd. Is die nog niet geïnstalleerd, dan is de knop Zoeken gedimd. Van GitHub geïnstalleerde PDF's bevatten doorzoekbare tekst; PDF's die u zelf importeert hebben die nog niet totdat ze is toegevoegd.

## Inhoud

Heeft de PDF een ingebouwde inhoudsopgave, dan toont de knop **Inhoud** in de werkbalk haar als een overzicht. Tik op een sectietitel om naar die pagina te springen. Secties kunnen worden uitgeklapt en ingeklapt. Heeft de PDF geen inhoudsopgave, dan is de knop gedimd.

## Bladwijzers in een PDF

1. Open de PDF en tik op de knop **Bladwijzer** in de werkbalk.
2. Tik op **Pagina van bladwijzer voorzien** om de huidige pagina op te slaan. De naam begint als het paginanummer — typ desgewenst een naam — en tik dan op **Opslaan**.
3. Tik op een willekeurige bladwijzer in de lijst om naar haar pagina te springen.
4. Tik op de **×** naast een bladwijzer om haar te verwijderen.

PDF-bladwijzers staan apart van uw Bijbelbladwijzers. Elke PDF houdt haar eigen lijst bij.

## Een PDF voorlezen

Is de doorzoekbare tekst van de PDF geïnstalleerd, dan kan Theodia de huidige pagina voorlezen:

1. Open de PDF en tik op de knop **Luisteren** (luidspreker) in de werkbalk.
2. Er verschijnt een bedieningsbalk met **Afspelen/Pauzeren**, **Terugspoelen**, **Vooruitspoelen**, **Stoppen**, een voortgangsbalk waarop u kunt tikken om binnen de pagina te springen, de leessnelheid en de stem.
3. Is de pagina afgelopen, dan gaat het voorlezen automatisch verder op de volgende pagina.

De stem en snelheid zijn dezelfde als bij het Bijbellezen — zie [Voorlezen](theodia://help/tts) voor hoe u ze veranderd.

## Paginatekst kopiëren, delen of opslaan

Tik op de knop **Tekstweergave** in de werkbalk om de huidige pagina als platte tekst te zien. Van daaruit kunt u:

- **Kopiëren** — de paginatekst naar het klembord kopiëren.
- **Delen** — de paginatekst via een willekeurige app op uw apparaat delen.
- **Toevoegen aan studienotities** — opent een notitieeditor met de paginatekst, een bronvermelding en een link terug naar deze pagina, alvast voor u ingevuld.

## Het lezen hervatten

Theodia onthoudt de laatste pagina die u bekeek en opent de PDF de volgende keer daar.

## PDF's van GitHub downloaden

In de modus **Geleerde** verschijnt onderaan de bibliotheek een knop **Downloaden van GitHub**. Deze verbindt met de gemeenschaps-PDF-repository zodat u verpakte PDF-documenten kunt installeren op dezelfde manier als Bijbels of boeken.

## Opmerkingen

- PDF's worden opgeslagen in de privémap Documenten van Theodia. Ze zijn niet in back-ups opgenomen, dus verhuist u naar een nieuw apparaat, dan moet u ze opnieuw importeren.
