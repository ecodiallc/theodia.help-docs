---
title: Afspeellijsten
level: everyday
categories: playlists
summary: Gesproken afspeellijsten maken en beluisteren met Bijbelgedeelten, platte tekst of elk vers dat u wilt horen.
---

# Afspeellijsten

Een **afspeellijst** is een lijst met nummers die Theodia voor u kan voorlezen. Elk nummer is ofwel een Bijbelgedeelte of een korte notitie in platte tekst. Afspeellijsten zijn handig voor luisteren zonder handen tijdens een woon-werkverkeer, een wandeling, stichtelijke tijd of memoreren.

Afspeellijsten verschijnen in de app zodra ten minste één afspeellijst is gemaakt of gevuld.

## Waar u Afspeellijsten vindt

Zijn afspeellijsten beschikbaar, dan bereikt u ze op twee manieren:

- **Beginscherm:** Tik in de sectie **Plug-ins & meer** op **Afspeellijsten**.
- **Hoofdmenu:** Open het menu (☰) en tik op **Afspeellijsten**.

Bestaan er nog geen afspeellijsten, dan zijn het tegel Afspeellijsten en het menu-item verborgen.

## Wat een afspeellijst bevat

Elke afspeellijst heeft:

- Een **naam** — bijvoorbeeld "Ochtendverzen" of "Memoreer Psalm 23".
- Een optionele **categorie** — handig om afspeellijsten per doel te groeperen.
- Een lijst met **nummers** — de items die worden voorgelezen.

Elk nummer bevat:

- **Inhoud** — ofwel een Bijbelgedeelteverwijzing of platte tekst.
- Een **label** — getoond op het scherm terwijl het nummer speelt.
- Een optionele **stem** — kies desgewenst een andere stem voor dit nummer.

## Een afspeellijst maken

1. Open het scherm **Afspeellijsten**.
2. Tik op **Afspeellijst maken** (of de knop **+**).
3. Geef de afspeellijst een naam.
4. (Optioneel) Kies of maak een categorie.
5. Begin met het toevoegen van nummers.

### Een nummer toevoegen vanuit een Bijbelgedeelte

1. Tik op **Nummer toevoegen**.
2. Kies **Bijbelgedeelte** als inhoudstype.
3. Voer een verwijzing in, zoals `John 3:16` of `Psalm 23:1-6`.
4. Voeg desgewenst een label toe, of laat het leeg om de verwijzing te gebruiken.
5. Sla het nummer op.

### Een nummer in platte tekst toevoegen

1. Tik op **Nummer toevoegen**.
2. Kies **Platte tekst**.
3. Typ de tekst die Theodia moet lezen.
4. Voeg een label toe.
5. Sla het nummer op.

### Nummers in bulk toevoegen

Heeft u een lijst met verwijzingen of tekstregels, gebruik dan **Bulk toevoegen**:

1. Open een afspeellijst.
2. Tik op het menu en kies **Bulk toevoegen**.
3. Plak één verwijzing of tekstregel per regel.
4. Zet **Bijbelverwijzingen detecteren** aan als de meeste regels versverwijzingen zijn.
5. Tik op **Toevoegen**. Elke regel wordt een nummer.

## Naar een afspeellijst luisteren

1. Open de afspeellijst die u wilt horen.
2. Tik bovenaan op de knop **Afspelen** of naast een nummer.
3. Theodia leest elk nummer op volgorde voor.

Tijdens het afspelen verschijnt een bedieningsbalk met deze bedieningselementen:

- **Afspelen / Pauzeren**
- **Volgend nummer**
- **Vorig nummer**
- **Stoppen**

U kunt ook instellen:

- **Snelheid** — hoe snel de stem leest.
- **Herhalen** — de hele afspeellijst herhalen, één nummer herhalen of een keer afspelen.
- **Willekeurig** — nummers in willekeurige volgorde afspelen.
- **Haakjes negeren** — tekst tussen haakjes overslaan.
- **Pauze tussen nummers** — een korte stilte tussen nummers toevoegen.
- **Slaaptimer** — het afspelen na een ingestelde tijd stoppen.

## Een afspeellijst bewerken

Om een afspeellijst te veranderen, pauzeer eerst het afspelen als het momenteel speelt.

U kunt:

- De afspeellijst **hernoemen**.
- **Nummers herordenen** — sleep nummers naar een nieuwe volgorde.
- **Een nummer bewerken** — de verwijzing, tekst, het label of de stem veranderen.
- **Een nummer verwijderen** — het uit de afspeellijst halen.
- **De hele afspeellijst verwijderen** — dit kan niet ongedaan worden gemaakt.

## Afspeellijsten exporteren en importeren

Afspeellijsten worden geëxporteerd als JSON-bestanden die alle nummers, categorieën en instellingen bevatten. U kunt het bestand met een ander apparaat delen, het als back-up bewaren of het op een computer bewerken.

- **Alle afspeellijsten exporteren** — maakt een bestand `playlists-JJJJ-MM-DD.json`.
- **Een categorie exporteren** — maakt een JSON-bestand met alleen de afspeellijsten in één categorie.
- **Afspeellijsten importeren** — herstelt afspeellijsten vanuit een JSON-back-upbestand.

## Snelle manieren om een afspeellijst te bouwen

U kunt ook een volledige afspeellijst als JSON maken en die importeren. Hier is een voorbeeld:

```json
{
  "playlists": [
    {
      "name": "Morning Verses",
      "category": "Devotional",
      "tracks": [
        {
          "info": "John 3:16",
          "contentSource": "passage",
          "content": "For God so loved the world...",
          "rawContent": "John 3:16"
        },
        {
          "info": "Psalm 23",
          "contentSource": "passage",
          "content": "The Lord is my shepherd...",
          "rawContent": "Psalm 23:1-6"
        }
      ]
    }
  ]
}
```

Sla het bestand op en gebruik **Afspeellijsten importeren** om het in Theodia te laden.

## Tips

- Afspeellijsten werken het best met korte, gerichte sets verzen.
- Gebruik categorieën om stichtelijke afspeellijsten te scheiden van memoreerlijsten.
- Stel een slaaptimer in als u luistert terwijl u in slaap valt.
- Gebruikt een nummer de verkeerde stem, controleer dan dat de taal van de stem overeenkomt met de taal van de tekst.
- Theodia leest platte tekst precies zoals geschreven; controleer de spelling voor het beste resultaat.
