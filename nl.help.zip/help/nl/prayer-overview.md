---
title: Overzicht van gebed
level: beginner
categories: prayer
summary: Een korte kennismaking met het tabblad Gebed en zijn hoofdafdelingen.
---

# Overzicht van gebed

Het tabblad **Gebed** is een eigen ruimte voor gebed. Het brengt lijsten, begeleide sessies, een dagboek, een timer, lectionarium-leesschema's en klassieke vaste gebeden samen.

## De hoofdafdelingen

- **Gebedslijst** — mensen, situaties en onderwerpen bijhouden waarvoor u bidt.
- **Dagboek** — over tijd beschouwingen, antwoorden en gedachten opschrijven.
- **Gebed genereren** — Theophilus vragen een gebed te schrijven vanuit een verzoek of dagboekitem.
- **Geloofsbelijdenissen & vaste gebeden** — klassieke gebeden en belijdenissen uit de christelijke traditie.
- **Lectionarium** — Schriftleesschema's voor dagelijks of seizoensgebonden gebed.
- **Begeleid gebed** — audiobegeleide gebedssessies met tekst-naar-spraak.
- **Timer** — gebedssessies met tijdsaanduiding en optionele bel.
