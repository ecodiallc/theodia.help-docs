---
title: Ingebouwde boeken lezen
level: beginner
categories: [content, read]
summary: Hoe u de christelijke klassiekers leest die bij de app horen.
---

# Ingebouwde boeken lezen

Theodia wordt geleverd met een kleine bibliotheek van christelijke boeken. Dit zijn klassiekers die u op uw apparaat kunt lezen.

## De bibliotheek openen

Tik onderaan het scherm op het tabblad **Boeken**. U ziet een lijst met de boeken in uw bibliotheek.

## Een boek lezen

1. Tik op de titel van het boek.
2. Het boek opent bij het eerste hoofdstuk.
3. Gebruik de knoppen **Vorige** en **Volgende** bovenaan om tussen hoofdstukken te bewegen.

## Naar een hoofdstuk springen

Tik op de hoofdstuknaam bovenaan het scherm. Er verschijnt een lijst met hoofdstukken. Kies een hoofdstuk om ernaartoe te springen.

## De tekstgrootte veranderen

Open **Instellingen** → **Weergave** en kies een tekstgrootte. De tekstgrootte verandert in de hele app, ook in boeken.

## Een bladwijzer in een boek maken

Tik op het pictogram **ster** rechtsboven. Het huidige hoofdstuk wordt opgeslagen. Tik op het tabblad **Bladwijzers** om uw opgeslagen pagina's te zien.

## Naar een boek luisteren

Tik op het pictogram **Luidspreker** rechtsboven. De app leest het hoofdstuk voor. Tik nogmaals om te stoppen.

## Welke boeken zijn beschikbaar?

De bibliotheek heeft klassiekers zoals:

- Pilgrim's Progress
- The Imitation of Christ
- Practice of the Presence of God
- The Hymn Book

De boekenlijst kan in de loop van de tijd groeien. Updates van de app kunnen er meer toevoegen.

## Tips

- Boeken worden op uw apparaat opgeslagen. Er is geen internet nodig.
- Boeken synchroniseren niet met de cloud.
