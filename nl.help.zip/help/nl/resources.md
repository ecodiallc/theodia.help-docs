---
title: Bronnen op GitHub vinden
level: everyday
categories: resources
summary: Doorzoek alle GitHub-repositories die de app kent tegelijk, en installeer wat u vindt.
---

# Bronnen op GitHub vinden

Theodia houdt een lijst bij met GitHub-repositories die bronnen publiceren — Bijbels, commentaren, boeken, stichtelijke lezingen, afspeellijsten, gebedspakketten en meer. **GitHub-repositories doorzoeken** doorzoekt ze allemaal tegelijk, zodat u niet elk tabblad apart hoeft te openen en door te bladeren.

> De GitHub-sectie van Instellingen is alleen beschikbaar in de **Geleerdemodus**. Om die aan te zetten, ga naar **Instellingen → Gebruikersmodus → Geleerde**.

## Zoeken

1. Open **Instellingen**.
2. Tik op **GitHub-repositories doorzoeken**.
3. Typ een woord in het zoekvak. De app zoekt dat woord in de **naam** en de **beschrijving** van elk pakket in elke repository.

Een paar dingen om over het zoeken te weten:

- **Elk woord moet overeenkomen.** Zoeken op `morning evening` vindt alleen pakketten waarvan de naam of beschrijving *beide* woorden bevat.
- **Hoofdletters doen er niet toe.** `Morning` en `morning` vinden dezelfde pakketten.
- **De beste overeenkomst komt eerst.** Een pakket waarvan de naam *begint* met uw zoekwoord wordt getoond vóór een pakket dat het alleen in de beschrijving noemt.

## Filteren

Tik op de filterbalk boven de resultaten om de lijst verder in te perken. Er zijn twee filters, en ze werken samen:

- **Auteur** — alleen pakketten van die auteur.
- **Traditie** — alleen pakketten voor die traditie.

Tik opnieuw op een filter om hem te wissen, of tik op **Filters wissen** om beide te resetten.

## Installeren vanuit een resultaat

Elk resultaat toont de naam van het pakket, wat voor bron het is, wie het maakte en uit welke repository het komt. Rechts op de regel zit één knop:

- **Installeren** — het pakket staat nog niet op uw apparaat.
- **Bijwerken** — er is een nieuwere versie beschikbaar. De app vraagt u eerst om bevestiging, omdat bijwerken de oude kopie verwijdert, samen met alle notities, markeringen of bladwijzers die erbij horen.
- **Openen** — het pakket is al geïnstalleerd; erop tikken brengt u naar het scherm waar u het gebruikt.

Tik bovenaan op **Vernieuwen** om meteen de nieuwste lijst van GitHub op te halen. De app vernieuwt de lijst eenmaal per dag vanzelf, dus handmatig vernieuwen is alleen nodig wanneer u weet dat er iets nieuws is gepubliceerd.

## Zoeken zonder verbinding

De app bewaart een kopie van de lijst op uw apparaat, dus zoeken werkt zelfs offline. Kan de app GitHub niet bereiken om de lijst te vernieuwen, dan vertelt een banner bovenaan dat u de gecachte resultaten ziet.

## Als een zoekopdracht niets vindt

- Probeer een korter, enkel woord.
- Controleer dat er nog geen filter **Auteur** of **Traditie** actief is — de knop **Filters wissen** verschijnt zodra dat zo is.
- Sommige repositories publiceren hun pakketten in een andere taal dan de pakketnaam, dus zoeken op een vertaald woord vindt ze mogelijk niet.
