---
title: Geleerdemodus
level: advanced
categories: [layout, read, study]
summary: De diepste studiemodus in Theodia, die commentaren, lexicons, kruisverwijzingen, AI-hulpmiddelen en het Launcher-menu ontgrendelt.
---

# Geleerdemodus

> **Modus:** De Geleerdemodus is alleen beschikbaar wanneer uw gebruikersmodus op **Geleerde** staat. Wissel van modus in **Instellingen** → **App-gebruikersmodus**.

De Geleerdemodus ontgrendelt elk studiehulpmiddel in Theodia. Ze is gebouwd bovenop de Studiemodus, dus u krijgt nog steeds het versmenu, parallelle Bijbels, bladwijzers, markeringen en notities — plus de geavanceerde hulpmiddelen hieronder.

## De Geleerdemodus openen

De Geleerdemodus is geen apart scherm. Ze is een set extra hulpmiddelen die in de bestaande lezer en navigatie verschijnen wanneer uw gebruikersmodus op Geleerde staat.

1. Open **Instellingen**.
2. Tik op **App-gebruikersmodus**.
3. Kies **Geleerde**.

De wijziging werkt onmiddellijk door. Menu's en knoppen die verborgen waren, verschijnen nu.

## Extra lezerhulpmiddelen

Wanneer u een hoofdstuk in de [Studiemodus](theodia://help/study-mode) opent, voegt de Geleerdemodus deze hulpmiddelen aan het versmenu toe:

- **AI-commentaar** (◈) — vraag de AI-assistent een studienotitie voor dit vers te schrijven. (Niet in alle regio's beschikbaar.)
- **Woordinfo** (?) — opent een lexiconitem voor het oorspronkelijke Hebreeuwse of Griekse woord achter het vers. Zie de gids [Commentaren en lexicons](theodia://help/commentaries-and-lexicons).
- **Woordenboek** (📖) — zoek algemene Bijbelwoorden op in de geïnstalleerde woordenboekbronnen. Zie de gids [Bijbelwoordenboek](theodia://help/dictionary).

Deze hulpmiddelen hebben geïnstalleerde bronnen nodig (commentaren, lexicons, woordenboekbestanden). Is een hulpmiddel grijs of verschijnt "niet gevonden", open dan **Instellingen** → **Bronnen beheren** en voeg de benodigde bron toe.

## Extra navigatie

### Extra werkbalktabblad

De onderste werkbalk krijgt één extra tabblad:

- 💻 **AI** — opent de AI-assistent (alleen als u AI in Instellingen heeft aangezet). Dit tabblad zit rechts van Notities.

### Extra hoofdmenu-items

Het hoofdmenu omvat onder dezelfde voorwaarden een item **AI-assistent**.

## Het Launcher-menu

De Geleerdemodus schakelt het **Launcher-menu** in, een snelle manier om naar recente verzen te springen, opdrachten uit te voeren en Bijbelindelingen te wisselen zonder uw huidige scherm te verlaten. Zie de gids [Launcher-menu](theodia://help/launcher-menu) voor gebruik.

## Wanneer de Geleerdemodus gebruiken

- U wilt de AI-assistent, commentaren of brontaalnaslag tijdens het lezen.
- U wilt het Launcher-menu voor snelle versnavigatie en AI-chat.
- U bestudeert een gedeelte diepgaand en heeft elk hulpmiddel op één tik afstand nodig.

## Naar een lichtere modus wisselen

Wilt u een eenvoudiger lezer zonder de geavanceerde hulpmiddelen, wissel dan in **Instellingen** → **App-gebruikersmodus** naar de modus **Standaard**. Standaardmodus houdt bladwijzers, markeringen, notities en de Studiemodus vast, maar verbergt AI, commentaren, lexicons en het Launcher-menu.

Wilt u de meest zuivere leeservaring, open dan een hoofdstuk in de [Focusmodus](theodia://help/focus-mode).

Uw bladwijzers, markeringen en notities worden nooit verwijderd wanneer u van modus wisselt; ze worden gewoon verborgen totdat u terugkeert naar een modus die ze ondersteunt.

## Hulp en vragen

Ontbreekt een hulpmiddel of verschijnt er een foutmelding, zie dan de gids [Veelvoorkomende problemen](theodia://help/common-problems). Bent u nieuw met Theodia, dan loopt de gids [Uw eerste hoofdstuk lezen](theodia://help/first-read) stap voor stap met u mee.
