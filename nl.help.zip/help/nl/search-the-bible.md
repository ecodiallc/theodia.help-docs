---
title: De Bijbel doorzoeken
level: everyday
categories: [study, read]
summary: Hoe u verzen vindt op woord, zin of verwijzing.
---

# De Bijbel doorzoeken

De zoekbalk helpt u snel verzen te vinden. U kunt zoeken op een woord, een zin of een Bijbelverwijzing.

## Een zoekopdracht starten

1. Tik onderaan het scherm op het tabblad **Zoeken**.
2. Typ wat u wilt vinden.
3. Tik op het toetsenbord op **Zoeken**.

De resultaten verschijnen als een lijst met verzen. Elk resultaat toont het boek, het hoofdstuk en het vers, plus de vertaaltekst.

## Zoeken op woordcombinaties

Wanneer u meer dan één woord typt, zoals `love joy`, vindt de app verzen die **beide** woorden bevatten. Dit is een **EN**-zoekopdracht — alle woorden moeten in het vers voorkomen. Hij gebruikt **geen** **OF**-logica (verzen met een van de woorden).

Om te zoeken naar verzen met één van de woorden, moet u het sleutelwoord `OR` expliciet gebruiken: `love OR joy`.

## Zoeken op woord

Typ één woord, zoals `love` of `mercy`. De app toont elk vers in de Bijbel dat dat woord bevat.

## Zoeken op zin

Typ twee of drie woorden tussen aanhalingstekens, zoals `"do not be afraid"`. De app toont verzen met precies die zin.

## De resultaten filteren

Na een zoekopdracht worden de resultaten gefilterd op de Bijbelvertalingen die u heeft geïnstalleerd. Om verder in te perken, opent u het tabblad **Bijbel** en bekijkt u een specifieke vertaling — zoekopdrachten lopen over de vertalingen die u heeft.

## Tips voor betere zoekopdrachten

- Gebruik korte woorden. Zoeken op `love` vindt meer verzen dan zoeken op `loving`.
- Aanhalingstekens rond een zin maken de zoekopdracht exact.
- De app doorzoekt alleen de Bijbelvertalingen die u heeft geïnstalleerd.
- Om via een verwijzing naar een specifiek vers te springen (bijvoorbeeld `John 3:16`), gebruikt u het **Opdracht**-vak op het beginscherm in plaats van het tabblad Zoeken.

## Zoekgeschiedenis

De app onthoudt uw meest recente zoekopdrachten. Wanneer u het tabblad **Zoeken** opent, toont de lijst bovenaan uw recente zoekopdrachten. Tik op een zoekopdracht om hem opnieuw uit te voeren. Om de lijst te wissen, tikt u bovenaan de recente zoekopdrachten op **Alles wissen**.

## PDF's doorzoeken

Het tabblad Zoeken kan ook in uw PDF-documenten zoeken:

1. Tik op het tabblad **Zoeken** en tik daarna bovenaan op de modus **PDF's**.
2. Kies welke PDF's doorzocht worden. Tik op een PDF om die op te nemen of uit te sluiten; gebruik **Alle** of **Wissen** boven de lijst om alles op te nemen of opnieuw te beginnen. Alleen PDF's waarvan de doorzoekbare tekst is geïnstalleerd, kunnen gekozen worden.
3. Typ wat u wilt vinden en tik op **Zoeken**.

Elk resultaat toont de titel van de PDF, het paginanummer en een fragment van de gevonden tekst. Tik op een resultaat om die PDF op die pagina te openen.

Om binnen één PDF te zoeken terwijl u die leest, gebruikt u de knop **Zoeken** in de PDF-lezer — zie [PDF's](theodia://help/pdfs).
