---
title: Studiemodus
level: everyday
categories: [layout, read]
summary: De volledige Bijbellezer in Theodia, vol studiehulpmiddelen zoals commentaar, kruisverwijzingen, lexicon en notities.
---

# Studiemodus

> **Modus:** De Studiemodus is beschikbaar in de modi **Standaard** en **Geleerde**. De Lezermodus opent hoofdstukken in plaats daarvan in de Focusmodus. U kunt van modus wisselen in **Instellingen** → **App-gebruikersmodus**.

De Studiemodus is de hoofdlezer van Theodia. Alle studiehulpmiddelen zitten erin ingebouwd: commentaar, kruisverwijzingen, woordnaslag, parallelle vertalingen, notities en meer.

De Focusmodus is een eenvoudiger lezer zonder studiehulpmiddelen. Zie de gids [Focusmodus](theodia://help/focus-mode) als u alleen zuivere tekst wilt. Deze gids gaat over de Studiemodus.

## De Studiemodus openen

Er zijn verschillende manieren om een hoofdstuk in de Studiemodus te openen:

- Tik onderaan het scherm op het tabblad **Bijbel**. Kies een vertaling, een boek en een hoofdstuk.
- Tik op een vers in de **Zoek**resultaten.
- Tik op een bladwijzer in het tabblad **Bladwijzers**.
- Tik vanuit de Focusmodus op de knop 📖 bovenaan het scherm om naar de Studiemodus te wisselen.

## Het hoofdstuk lezen

Het hoofdstuk opent met de verzen op volgorde. Bovenaan het scherm staan knoppen voor de meest gebruikte handelingen. Onderaan het scherm zit een statusbalk.

- **Veeg naar links** om naar het volgende hoofdstuk te gaan.
- **Veeg naar rechts** om naar het vorige hoofdstuk te gaan.
- **Tik op een vers** om het versmenu met studiehulpmiddelen te openen (zie hieronder).
- **Tik op een Strong's-nummer in een vers** (bijvoorbeeld G1234 of H1234) om snel dat woord in het lexicon op te zoeken.

Als u een parallelle vertaling heeft ingeschakeld, verschijnt onder de hoofdweergave een tweede kopie van het hoofdstuk, in de door u gekozen vertaling. Zie hieronder **Meerdere vertalingen tegelijk lezen**.

## Het versmenu

Wanneer u op een vers tikt, opent een menu met de titel "Boek Hoofdstuk:Vers". Welke hulpmiddelen u ziet, hangt af van uw gebruikersmodus.

### Hulpmiddelen in Standaard- en Geleerdemodus

- **Bladwijzer** (★) — sla het vers op zodat u het terugvindt. Tik nogmaals om de bladwijzer te verwijderen. De eerste tik voegt het toe. Zie de gids [Verzen van bladwijzers voorzien](theodia://help/bookmarks).
- **Markeren** (□) — geef het vers een kleur zodat het opvalt. Tik erop om een kleurenkiezer te openen. Tik op dezelfde kleur om de markering te verwijderen. Zie de gids [Verzen markeren](theodia://help/highlights).
- **Voorlezen** (🔊) — laat het vers voorlezen met de voorleesstem van uw apparaat. Dit wordt niet getoond bij interlineaire Bijbels. Zie de gids [Voorlezen](theodia://help/tts) voor gebruik en het kiezen van een stem.
- **Kopiëren** (⎘) — zet de vertaaltekst op uw klembord zodat u hem overal kunt plakken.
- **Vergelijken** (⇄) — opent een paneel dat hetzelfde vers in elke geïnstalleerde vertaling toont. Tik in het paneel op een vertaling om het vers daarin te lezen. Zie de gids [Vertalingen vergelijken](theodia://help/compare-translations).
- **Kruisverwijzingen** (↗) — opent een lijst met verwante verzen uit de kruisverwijsdatabase. Zie de gids [Kruisverwijzingen](theodia://help/cross-references).
- **Bijbelnoot toevoegen/bewerken** (✎) — schrijf uw eigen privénotitie, gekoppeld aan het vers. Zie de gids [Notities schrijven](theodia://help/notes).

### Alleen in de Geleerdemodus

- **AI-commentaar** (◈) — vraag de AI-assistent een studienotitie voor dit vers te schrijven. (Niet in alle regio's beschikbaar.)
- **Woordinfo** (?) — opent een lexiconitem voor het oorspronkelijke Hebreeuwse of Griekse woord achter het vers. Zie de gids [Commentaren en lexicons](theodia://help/commentaries-and-lexicons).
- **Woordenboek** (📖) — zoek algemene Bijbelwoorden op in de geïnstalleerde woordenboekbronnen. Zie de gids [Bijbelwoordenboek](theodia://help/dictionary).

Sommige hulpmiddelen hebben extra bronnen nodig. Is een hulpmiddel grijs of verschijnt "niet gevonden", open dan **Instellingen** → **Bronnen beheren** en voeg de benodigde bron toe.

## Knoppen bovenaan het scherm

Boven de hoofdstuktekst staat een rij pictogrammen. Dit zijn de snelle acties:

- **Bijbelvertaling** — tik op de naam van de vertaling (bijvoorbeeld "KJV") om naar een andere vertaling te wisselen.
- **Boek** — tik op de naam van het boek om naar een ander boek te springen.
- **Hoofdstuk** — tik op het hoofdstuknummer om naar een ander hoofdstuk te springen.
- **Openen in AI** (🤖) — stuur het huidige hoofdstuk met uw vraag naar de AI-assistent. (Alleen Geleerdemodus.)
- **Focusmodus** (📖) — wissel naar de Focusmodus voor rustig lezen.
- **Parallelle Bijbels** (🔵 / ⚪) — tik om parallelle vertalingen aan of uit te zetten. Ingeschakeld wordt hetzelfde hoofdstuk in uw gekozen parallelle vertalingen onder de hoofdtekst getoond. Uitgeschakeld wordt alleen de hoofdvertaling getoond. Zie hieronder **Meerdere vertalingen tegelijk lezen**.
- **Luisteren** — laat het hele hoofdstuk voorlezen. Zie de gids [Voorlezen](theodia://help/tts).
- **Meer** — open extra hoofdstukacties (bijbelnoot bij het hoofdstuk, commentaar bij het hoofdstuk, delen en meer).

## Meerdere vertalingen tegelijk lezen

U kunt tot vier extra vertalingen naast uw hoofdvertaling tonen. Dit heet de **parallelle weergave**.

1. Open **Instellingen**.
2. Zet **Parallelle Bijbel** aan.
3. Tik op **Parallelle Bijbel toevoegen** en kies een vertaling.
4. Herhaal om er meer toe te voegen. U kunt tot vier parallelle vertalingen hebben.

In de parallelle weergave toont elk vers eerst uw hoofdvertaling, gevolgd door hetzelfde vers in elke parallelle vertaling. Zo vergelijkt u makkelijk hoe verschillende vertalers een moeilijk vertaalde vers aanpakken, zonder het hoofdstuk te verlaten.

U kunt uw huidige parallelle instelling als **preset** opslaan. Tik op de opslagknop naast uw gekozen vertalingen, geef het een naam en het wordt een snelle wisseloptie. Tik later op een preset om die combinatie direct te laden. Houd een preset lang ingedrukt om hem te verwijderen.

U kunt ook één vers tegelijk vergelijken met het hulpmiddel **Vergelijken** (⇄) in het versmenu. Dat opent een paneel dat het vers in elke geïnstalleerde vertaling toont.

## Tussentitels

Sommige vertalingen hebben sectiekopjes ingebouwd (bijvoorbeeld "De bergrede"). Heeft uw vertaling die, dan kunt u ze tonen of verbergen met de instelling **Tussentitels tonen** in **Instellingen**. Tussentitels verschijnen als kleine grijze titels tussen de verzen.

## De hoofdstuknoot

Een hoofdstuknoot is één notitie die aan het hele hoofdstuk hangt, niet aan één vers. Die is handig voor één grote gedachte over het hoofdstuk.

De hoofdstuknoot openen:

1. Tik op de knop **Meer** bovenaan het scherm.
2. Tik op **Hoofdstuknoot**.
3. Schrijf uw notitie. Tik op **Opslaan**.

De hoofdstuknoot wordt bij het hoofdstuk opgeslagen. Hij verschijnt telkens wanneer u dat hoofdstuk opent.

## Zoekmarkeringen

Bent u vanuit een zoekopdracht bij het hoofdstuk gekomen, dan zijn uw zoekwoorden in de vertaaltekst geel gemarkeerd. Zo ziet u meteen waarom een vers overeenkwam.

U kunt ook opnieuw zoeken binnen een hoofdstuk dat u aan het lezen bent. Open het tabblad **Zoeken** en voer een woord in. Vanuit de resultaten tikt u direct terug het hoofdstuk in, met de treffers gemarkeerd.

Interlineaire Bijbels (MIB — Marvel Interlinear Bible — en OHGB) openen altijd in de Studiemodus, omdat ze de woord-voor-woord-indeling nodig hebben.

## Naar de Focusmodus voor één hoofdstuk

Tik vanuit elk hoofdstuk in de Studiemodus op de knop 📖 bovenaan. Hetzelfde hoofdstuk opent in de Focusmodus met alle menu's verborgen. Tik op de knop 📖 in de onderbalk om terug te wisselen naar de Studiemodus.

## Wanneer de Studiemodus gebruiken

De Studiemodus is de juiste keuze wanneer u wilt:

- **Lezen en bestuderen tegelijk.** Alle hulpmiddelen zijn op één tik afstand.
- **Een woord opzoeken dat u niet kent.** Tik op een Strong's-nummer in het vers voor een snel lexiconitem.
- **Vertalingen vergelijken.** Gebruik het hulpmiddel Vergelijken in het versmenu of zet de parallelle weergave aan.
- **Zien hoe een vers met de rest van de Bijbel samenhangt.** Gebruik Kruisverwijzingen.
- **Notities maken tijdens het lezen.** Het versmenu heeft een snelle optie "Notitie toevoegen".

Voor lang, rustig lezen zonder afleiding wisselt u naar de Focusmodus.

## Naar de Focusmodus wisselen

Tik vanuit elk hoofdstuk in de Studiemodus op de knop 📖 bovenaan. Hetzelfde hoofdstuk opent in de [Focusmodus](theodia://help/focus-mode) met de menu's en studiehulpmiddelen verborgen. Tik op de knop 📖 in de onderbalk om terug te wisselen naar de Studiemodus. Voor een volledige beschrijving van wat de Focusmodus doet, zie de gids [Focusmodus](theodia://help/focus-mode).

## Hulp en vragen

Ontbreekt een hulpmiddel of verschijnt er een foutmelding, zie dan de gids [Veelvoorkomende problemen](theodia://help/common-problems). Bent u nieuw met Theodia, dan loopt de gids [Uw eerste hoofdstuk lezen](theodia://help/first-read) stap voor stap met u mee.
