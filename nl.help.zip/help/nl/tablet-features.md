---
title: Tabletfuncties
level: everyday
categories: [layout, tablet]
summary: Hoe de indeling van Theodia zich aanpast aan tablets en grotere schermen, met gesplitste weergaven, zijpanelen en tweekoloms-leesmodi.
---

# 📱 Tabletfuncties

Theodia is ontworpen om grotere schermen op tablets te benutten. Op een tablet (of elk apparaat breder dan ongeveer 700 pixels) schakelt de app op veel plaatsen automatisch naar een tweekolomsindeling.

> **Modus:** De hier beschreven functies verschijnen alleen als uw huidige gebruikersmodus ze ondersteunt. Zo zijn commentaarzijpanelen en AI-chat alleen beschikbaar in de Geleerdemodus. Gesplitste weergaven van bladwijzers, markeringen en notities vereisen Standaard of Geleerde. De Focusmodus toont alleen rustige lezing in één kolom. U kunt van modus wisselen in **Instellingen** → **App-gebruikersmodus**.

## Versmenu van de lezer

Wanneer u op een versnummer tikt (of de vertaaltekst lang ingedrukt houdt), verschijnt het **versmenu** als een **gecentreerde kaart** over een donkere achtergrond.

- De knoppen **Kopiëren** en **Delen** zijn altijd bovenaan het menu zichtbaar.
- **Bladwijzers** en **Markeringen** worden met hun huidige staat getoond.
- **Commentaar**, **Woordenboek** en **Vergelijken** openen vanuit het menu. Op een tablet verschijnen deze hulpmiddelen na selectie in een zijpaneel of brede kaart.
- Tik op de achtergrond of de sluitpijl om het menu te sluiten.

## Paneel Verscommentaar

Het hulpmiddel **Commentaar** opent op een tablet een **speciaal zijpaneel**:

- De commentaartekst verschijnt naast de Bijbeltekst.
- U kunt door het commentaar scrollen onafhankelijk van de Bijbel.
- Tik op de **X** of veeg weg om te sluiten.
- Een **boekpictogram** bovenaan het paneel laat u van commentaarbron wisselen.
- Een **hoofdstukpictogram** laat u commentaar op hoofdstukniveau bekijken.

Op een telefoon opent het commentaar als een schermvullend venster.

## Hoofdstukcommentaar

**Hoofdstukcommentaar** wordt geopend via de knop **Meer** bovenaan het scherm, niet via het versmenu. Op een tablet opent het net zoals het Verscommentaar als een zijpaneel, zodat u het commentaar en de Bijbeltekst samen kunt lezen.

## Tabblad Vergelijken

Het tabblad **Vergelijken** (in het versmenu) opent op een tablet als een **zijpaneel**. Het toont het gekozen vers in elke parallelle versie die u heeft ingeschakeld. U kunt op een willekeurige versie tikken om naar dat gedeelte in de lezer te springen.

## Woordenboek / Strong's-pop-up

Het hulpmiddel **Woordenboek** (versmenu → Woordenboek) opent op een tablet als een brede kaart. Het toont het Griekse of Hebreeuwse woord, zijn transliteratie, definitie en Strong's-nummer. Tik op de knop **Concordantie** om elke plaats van dat woord in de Bijbel te zien.

## Tik op een woord om zijn lexicon te openen

In het zijpaneel **Woordinfo** op een tablet is elke woordkaart met een Strong's-nummer tikbaar. Tik op de kaart om het paneel **Lexicon** voor dat woord direct te openen. Het lexiconpaneel vervangt het Woordinfo-paneel zodat u kunt blijven studeren zonder de lezer te sluiten.

Op een telefoon zijn Woordinfo-kaarten niet tikbaar, want het scherm is te klein voor twee panelen.

## Parallelle Bijbels naast elkaar

Tik in Instellingen op **Parallelle Bijbels** en kies tot drie versies. Op een tablet verschijnen de versies als **verticale vlakken** naast elkaar:

- Elk vlak scrollt onafhankelijk.
- U kunt op een versnummer tikken om een zijpaneel met hulpmiddelen te openen.
- Het tabblad **Vergelijken** toont alle gekozen verzen op één plaats.
- Tik op de **X** op een willekeurig vlak om het te sluiten en terug te keren naar de weergave met één kolom.
- Tik op het pictogram **Parallelle Bijbels** (🔵 / ⚪) in de bovenste pictogrambalk om de parallelle weergave aan of uit te zetten zonder Instellingen te openen.

Op een telefoon worden parallelle versies één voor één (verticaal) getoond in plaats van naast elkaar. Hetzelfde wisselpictogram werkt ook op telefoons.

## Gesplitste weergave Bladwijzers en Markeringen

Op een tablet gebruiken de tabbladen **Bladwijzers** en **Markeringen** een master-detailindeling:

- **Linkerkant** — de lijst met bladwijzers of markeringen.
- **Rechterkant** — tikken op een item opent een voorbeeldpaneel met de vertaaltekst of het gedeelte.

U kunt door uw opgeslagen items bladeren en ze bekijken zonder het tabblad te verlaten. Op een telefoon brengt tikken op een item u naar het lezersscherm.

## Gesplitste weergave Notities

Het tabblad **Notities** op een tablet toont uw notitielijst links en de geselecteerde notitie rechts. Tikken op een notitie opent haar in een zijpaneel, zodat u meerdere notities na elkaar kunt nalezen zonder de lijst te verlaten. Een notitie maken of bewerken gebruikt ook een zijpaneel.

## Gesplitste weergave Zoeken

Op een tablet toont het tabblad **Zoeken** het zoekformulier links en de resultaten rechts zodra u een zoekopdracht uitvoert. U kunt uw zoekopdracht verfijnen en de resultaten bijwerken zien zonder van scherm te wisselen. Op een telefoon openen zoekresultaten op een apart scherm.

## Zijbalk met instellingencategorieën

Het scherm **Instellingen** op een tablet toont links een categorielijst (AI, Weergave, Back-up, Bijbels enz.). Tik op een categorie om direct naar haar instellingen rechts te springen. Alleen de gekozen categorie is uitgeklapt, zodat u nooit door de hele instellingenlijst hoeft te scrollen.

## Bijbelnavigatie op tablets

De schermen **Bijbellijst**, **Bijbelboeken** en **Bijbelhoofdstukken** blijven op tablets in één kolom, maar gebruiken grotere aanraakdoelen, bredere rasters en ruimere padding zodat de inhoud gemakkelijker te lezen en te tikken is. Ze gebruiken geen gesplitste indeling, omdat elke stap de volle breedte nodig heeft om zijn lijst of raster duidelijk te tonen.

## Liggend en staand

De tablet draaien past de indeling automatisch aan. In **liggende** stand hebben zijpanelen veel ruimte. In **staande** stand worden panelen smaller maar blijven ze naast de tekst.

## AI-chat bij geselecteerd vers

De **AI**-chat opent in het zijpaneel van het versmenu. Het toont een gespreksinterface waar u vragen over het geselecteerde vers kunt stellen. Het AI-antwoord verschijnt in het paneel, en u kunt het gesprek voortzetten zonder de lezer te verlaten.

## Gesprekszijbalk in het AI-scherm

In het tabblad **AI** op een tablet is de gesprekslijst altijd zichtbaar als blijvende linkse zijbalk. U kunt tussen gesprekken wisselen zonder een menu te openen. Ook de knop **Nieuw gesprek** is altijd zichtbaar. Op een telefoon is de gesprekslijst een pop-uplade.

## Wat hetzelfde blijft

Niet elk scherm splitst zich in twee vlakken. De volgende schermen blijven op tablets in één kolom:

- **Bijbellijst** — lijst met Bijbelversies (volle breedte)
- **Bijbelboeken** — boekraster en secties (volle breedte)
- **Bijbelhoofdstukken** — hoofdstukraster (volle breedte)
- **PDF's** — de PDF-bibliotheek gebruikt een breder kaartraster (volle breedte)
- **Instellingen** — individuele instellingenpagina's (volle breedte)
- **Hulp** — hulpartikelen (volle breedte)

## Samenvatting

Op een tablet krijgt u:

- **Parallelle Bijbels** in verticale vlakken naast elkaar
- **Commentaar** in blijvende zijpanelen
- **Vergelijken** en **Woordenboek** in brede kaarten
- **Lexicon** vanuit een tik op elke Woordinfo-kaart
- **Bladwijzers, Markeringen, Notities, Stichtelijke lezingen, Boeken, Instellingen** in master-detail gesplitste weergaven
- **Zoeken** met resultaten naast het zoekformulier
- **Liggende** en **staande** stand beide ondersteund met automatische indelingswijzigingen

Op een telefoon gebruikt alles de traditionele éénkoloms-drilldown-navigatie. De app detecteert de schermbreedte bij het opstarten en kiest automatisch de juiste indeling.
