---
title: Thema's en lettertypen veranderen
level: everyday
categories: settings
summary: Hoe u het uiterlijk van de app veranderd.
---

# Thema's en lettertypen veranderen

Theodia laat u veranderen hoe de app eruitziet. U kunt een thema (licht of donker) en een tekstgrootte kiezen.

## De weergave-instellingen openen

1. Open **Instellingen**.
2. Tik op **Weergave**.

## Het thema veranderen

In de sectie **Weergave** ziet u twee themaknoppen:

- **Standaard** — een lichte achtergrond met donkere tekst. Goed voor overdag.
- **Donker** — een donkere achtergrond met lichte tekst. Goed voor 's nachts en spaart de batterij.

Tik op een thema om het toe te passen. De wijziging is onmiddellijk.

## De tekstgrootte veranderen

Tik in de sectie **Weergave** op een van de grootteknoppen: **---**, **--**, **-**, **Normaal**, **+**, **++**, **+++**. De tekst wordt in de hele app kleiner of groter. Kies de grootte die u het gemakkelijkst leest.

## Tips

- Het donkere thema spaart de batterij op telefoons met OLED-schermen.
- Is de tekst te klein om te lezen, vergroot dan de tekstgrootte in de app, niet op het apparaat. De instelling van de app is fijner.
- Probeer voor lang lezen het donkere thema en een groter lettertype.
- [Het woestijnthema activeren](theodia://unlock-desert)
