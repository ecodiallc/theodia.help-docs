---
title: Theodia-functies
level: beginner
categories: welcome
summary: Een kort overzicht van wat Theodia bijzonder maakt en hoe het u helpt de Bijbel te bestuderen.
---

# Theodia-functies

Theodia is gebouwd als een complete metgezel voor Bijbelstudie. Dit is wat haar onderscheidt.

## Offline eerst

Alles werkt zonder internet. Bijbels, commentaren, lexicons, boeken en stichtelijke lezingen worden op uw apparaat opgeslagen. U kunt overal lezen, zoeken en studeren — in een vliegtuig, in een afgelegen gebied of op elke plek zonder signaal.

## Privacygericht

Uw gegevens blijven bij u. Notities, markeringen, bladwijzers en leesgeschiedenis worden lokaal op uw apparaat opgeslagen. Er is geen account nodig en er wordt niets naar een server gestuurd tenzij u er zelf voor kiest de optionele AI-assistent te gebruiken.

## Tabletondersteuning

Theodia is ontworpen voor zowel telefoons als tablets. Op een groter scherm krijgt u meer ruimte om te lezen, parallelle Bijbelweergaven en een indeling die de extra ruimte benut.

## Installeerbare bronnen

U bent niet beperkt tot wat met de app meekomt. U kunt meer Bijbelvertalingen, commentaren, lexicons, boeken en stichtelijke lezingen toevoegen. Bronnen zijn beschikbaar op de GitHub-pagina van het project en kunnen rechtstreeks in de app worden geïnstalleerd.

## AI-assistent

De optionele AI-assistent helpt u verzen te begrijpen, context uit te leggen en vragen te beantwoorden. Ze is alleen actief als u haar aanzet. Standaard verbindt ze met een extern model dat u aanlevert via een eindpunt en API-sleutel die u instelt. Gebruikt u de AI voor de eerste keer, dan vraagt de app om uw toestemming en toont precies wat er wordt gestuurd.

## Parallel Bijbellezen

Lees tot vier Bijbelvertalingen tegelijk. Opent u een hoofdstuk, dan verschijnt uw hoofdvertaling eerst, en op elk vers volgt hetzelfde vers in uw gekozen parallelle vertalingen. Vergelijk formuleringen, bestudeer verschillen en krijg een voller beeld van de tekst. Sla uw favoriete combinaties op als presets en wissel er snel tussen.

## Zoeken in volledige tekst

Zoek door elke Bijbelvertaling. Zoek naar woorden, zinsdelen of gedeeltelijke overeenkomsten. U kunt de zoekopdracht ook beperken tot een reeks boeken.

## Kruisverwijzingen

Tik op een versverwijzing om rechtstreeks naar dat gedeelte te springen. Kruisverwijzingen zijn ingebouwd en werken door de hele Bijbel.

## Lexicon en Strong's-nummers

Tik op een Strong's-nummer om de oorspronkelijke Griekse of Hebreeuwse definitie te zien. Lexiconitems zijn inbegrepen voor diepere woordstudie.

## Bladwijzers en markeringen

Bewaar verzen met bladwijzers en markeer ze met kleuren. Alles wordt lokaal opgeslagen en blijft tussen sessies bestaan.

## Notities

Schrijf uw eigen gedachten naast elk vers. Notities zijn aan het vers gekoppeld en gemakkelijk later terug te vinden.

## Dagelijkse stichtelijke lezing

Begin uw dag met een korte stichtelijke lezing. De app bevat lezingen die automatisch naar het item van vandaag openen.

## Christelijke boeken

Lees klassieke christelijke literatuur in de app. Boeken zijn opgemaakt voor gemakkelijk lezen en bevatten een inhoudsopgave voor snelle navigatie.

## PDF's lezen

Importeer uw eigen PDF-documenten en lees ze offline, georganiseerd in categorieën. De lezer ondersteunt zoeken, een inhoudsopgave, bladwijzers, zoomen en voorlezen. U kunt ook verpakte PDF-verzamelingen uit de gemeenschapsrepository installeren.

## Meerdere talen

Theodia ondersteunt veel talen, zowel voor de app-interface als voor Bijbelinhoud. Wissel van taal in de instellingen om in uw voorkeurstaal te studeren.

## Donkere modus en thema's

Kies tussen lichte of donkere modus, of kies een thema dat bij uw voorkeur past. Leescomfort telt, vooral bij weinig licht.

## Gegevensback-up

Maak back-ups van uw notities, bladwijzers en markeringen. Houd uw gegevens veilig en verplaats ze naar een nieuw apparaat wanneer nodig.

## Geen advertenties, geen afleiding

Theodia is gebouwd voor focus. Er zijn geen advertenties, geen pop-ups en geen onderbrekingen. Gewoon de tekst en uw studiegereedschappen.
