---
title: Voorlezen (tekst-naar-spraak)
level: everyday
categories: tts
summary: Laat Theodia de Bijbel of een stichtelijke lezing voorlezen. Hoe het werkt, hoe u een stem kiest en wat te doen bij stilte.
---

# Voorlezen (tekst-naar-spraak)

> **Modus:** Tekst-naar-spraak is beschikbaar in de modi **Standaard** en **Geleerde**. De Focusmodus is alleen voor rustig lezen zonder afleiding. U kunt van modus wisselen in **Instellingen** → **App-gebruikersmodus**.

Theodia kan tekst voorlezen met de tekst-naar-spraakstem (TTS) van uw apparaat. U kunt naar één vers, een heel hoofdstuk of een stichtelijke lezing luisteren. Dit is handig voor lezen zonder handen, luisteren tijdens het wandelen of onderweg, meelezen met audio, of gewoon uw ogen rust geven.

## Waar de luisterknop zit

U vindt een luisterknop op drie plaatsen.

### 1. In het versmenu (één vers)

Dit is de snelste manier om vers voor vers te luisteren. Open een hoofdstuk in de [Studiemodus](theodia://help/study-mode), tik op een vers om het versmenu te openen en tik op **Voorlezen** (🔊). Het lezen begint bij dat vers. Onderaan het scherm verschijnt een kleine bedieningsbalk met afspelen, pauzeren, terugspoelen, doorspoelen en een stemkiezer.

De optie Voorlezen wordt niet getoond bij interlineaire Bijbels (MIB — Marvel Interlinear Bible — en OHGB), omdat die woorden in een andere indeling tonen die niet natuurlijk leest.

### 2. Bovenaan een hoofdstuk (heel hoofdstuk)

Wanneer u een hoofdstuk leest, kijk dan naar de rij pictogrammen bovenaan het scherm. Tik op **Luisteren** (🔊) om het hele hoofdstuk vanaf het begin voor te lezen. De knop wordt tijdens het afspelen een stopknop (⏹). Tik nogmaals om te stoppen. Dezelfde bedieningsbalk verschijnt onderaan.

U kunt naar een ander vers springen; de luisterknop daar begint dan vanaf dat vers.

### 3. In een stichtelijke lezing

Open een willekeurige dag van een stichtelijke lezing en tik op de knop **Luisteren** (🔊) bovenaan de lezing. De volledige tekst wordt zin voor zin voorgelezen. Een bedieningsbalk onderaan geeft u afspelen, pauzeren, terugspoelen en stembediening.

## De bedieningsbalk gebruiken

Tijdens het afspelen blijft onderaan het scherm een kleine balk zichtbaar. Die heeft zes bedieningen:

- ⏪ **Terugspoelen** — één vers terug (of één zin in een stichtelijke lezing)
- ⏸ **Pauzeren / ▶ Hervatten** — pauzeer zonder uw plek te verliezen. Tik opnieuw om op dezelfde plek verder te gaan.
- ⏩ **Doorspoelen** — spring naar het volgende vers (of de volgende zin in een stichtelijke lezing)
- 🎙 **Stem** — open de stemkiezer zonder het hoofdstuk te verlaten (zie hieronder)
- ⚙ **Opties** — open het uitgebreide optiepaneel (zie hieronder)
- **Stoppen** — tik op de knop 🔊 bovenaan het scherm, of op de ⏹ die hem tijdens het afspelen vervangt, om te stoppen en de balk te sluiten.

De bedieningsbalk sluit wanneer het hoofdstuk eindigt of wanneer u op stop tikt.

### Uitgebreide opties

Tik op ⚙ om extra afspeelopties uit te klappen. Deze instellingen gelden alleen voor het huidige hoofdstuk en worden gereset wanneer u van hoofdstuk wisselt of stopt met luisteren.

- ⏮ **Naar het begin** — spring naar het eerste vers van het bereik dat u instelde.
- **Begin** — typ een versnummer waar het lezen begint.
- **Einde** — typ een versnummer waar het lezen stopt.
- **Alle** — zet het bereik terug op het hele hoofdstuk.
- **()** — schakel in of haakjestekst (tekst tussen haakjes) wordt voorgelezen.
- 🔁 **Herhalen** — herstart automatisch aan het begin van het bereik zodra het einde is bereikt, met een korte pauze ertussen. Zet u dit aan zonder begin- of eindvers, dan herhaalt het hele hoofdstuk zich.

### In gebedsschermen

Belijdenissen en vaste gebeden, gegenereerde gebeden en gebedsritmes hebben hun eigen set uitgebreide opties. Tik op ⚙ in de bedieningsbalk om ze uit te klappen:

- **Snelheid** — tik op de snelheid (bijvoorbeeld `1x`) om een leessnelheid te kiezen van 0,1x tot 1,5x. Uw keuze wordt onthouden en de volgende keer gebruikt wanneer u iets voorleest.
- **()** — schakel in of haakjestekst (tekst tussen haakjes) wordt voorgelezen.
- 🔁 **Herhalen** — herstart het gebed automatisch vanaf het begin zodra het eindigt, met een korte pauze ertussen. Dit is handig om een belijdenis of vast gebed uit het hoofd te leren.

Een snelheidswijziging werkt meteen door, zonder uw plek te verliezen. De haakjesoptie aan- of uitzetten herstart het gebed vanaf het begin, zodat de wijziging vanaf het begin te horen is.

## De stem veranderen

U kunt kiezen welke stem Theodia gebruikt om voor te lezen. Dit is handig als u een ander accent, een andere taal of een snellere of langzamere stem wilt dan de standaard van het apparaat.

1. Open **Instellingen**.
2. Zoek de sectie **Spraak**.
3. Tik op **Stem selecteren**.
4. Er verschijnt een lijst met stemmen. De eerste regel, **Systeemstandaard**, gebruikt de stem die uw apparaat verkiest. Kies een andere regel om die als nieuwe standaard in te stellen.
5. Uw keuze wordt opgeslagen en gebruikt de volgende keer dat u op **Luisteren** of **Voorlezen** tikt.

U kunt ook op het pictogram 🎙 in de luisterbedieningsbalk tikken om dezelfde kiezer te openen zonder het hoofdstuk te verlaten.

De beschikbaarheid van stemmen hangt volledig af van uw apparaat. iOS en Android worden elk met een set ingebouwde stemmen geleverd. U kunt meer stemmen installeren via de instellingen **Toegankelijkheid** of **Taal en invoer** van uw apparaat. Theodia kan elke stem gebruiken die op uw apparaat geïnstalleerd is.

## Favoriete stemmen

Heeft uw apparaat veel stemmen, dan kan het door de volledige lijst scrollen telkens traag zijn. U kunt een korte lijst met **favoriete stemmen** maken en de stemkiezers tonen dan alleen die stemmen.

1. Open **Instellingen**.
2. Zoek de sectie **Spraak**.
3. Tik op **Favoriete stemmen** (de eerste regel bovenaan de sectie).
4. Tik op **Favoriete stemmen instellen** om het favorietenscherm te openen.
5. Tik op de afspeelknop naast een stem om te beluisteren. Tik op de ster om die aan uw favorieten toe te voegen. U kunt zoveel stemmen als u wilt favorieten.
6. Ga terug. De stemkiezers in Theodia tonen nu alleen uw favoriete stemmen.

Verwijdert u alle favorieten, dan tonen de kiezers weer elke stem. Favoriete stemmen worden mee opgeslagen bij het maken van een back-up en het herstel van de instellingen van Theodia.

## Een andere stem per Bijbel instellen

U kunt elke Bijbelvertaling zijn eigen stem geven. Dit is handig wanneer u wisselt tussen vertalingen die heel verschillend lezen — bijvoorbeeld een formelere stem voor de King James Version en een gesprekiger stem voor een moderne vertaling zoals de NIV of NLT. Het helpt ook als u naar Bijbels in verschillende talen luistert en elke in het juiste accent wilt horen.

1. Open **Instellingen**.
2. Zoek de sectie **Spraak**.
3. Zoek **Bijbelstemmen**.
4. Tik op een willekeurige Bijbel in de lijst.
5. Kies de stem die u voor die vertaling wilt. De eerste regel, **Systeemstandaard**, gebruikt uw hoofd-TTS-stem voor die Bijbel.
6. Herhaal voor andere Bijbels.

De kop toont hoeveel Bijbelvertalingen een eigen stem hebben ingesteld. Ook **Stem selecteren**, **Commentaarstem**, **Bijbelnotitiestem** en **Stichtelijke-lezingstem** tonen een aantal wanneer er een stem is ingesteld.

De volgende keer dat u naar een hoofdstuk uit die Bijbel luistert, gebruikt Theodia de door u gekozen stem. Alle andere Bijbels blijven de standaardhoofdstem gebruiken, tenzij u die ook aanpast.

## Spraak op de achtergrond voortzetten

Standaard stopt Theodia de spraak wanneer u het lezersscherm verlaat, naar een andere app wisselt of uw telefoon vergrendelt. Dit voorkomt onverwachte audio wanneer u niet meer actief leest.

Om spraak op de achtergrond te laten doorgaan:

1. Open **Instellingen**.
2. Zoek de sectie **Spraak**.
3. Zet **Spraak op de achtergrond voortzetten** aan.

Als dit aanstaat, kunt u van tabblad wisselen, een andere app openen of het scherm vergrendelen en blijft het hoofdstuk of de stichtelijke lezing voorlezen. De bedieningsbalk blijft actief, zodat u vanuit het meldingsgebied kunt pauzeren of overslaan (als uw apparaat dat ondersteunt).

Deze schakelaar **uit** zetten terwijl de spraak al speelt, stopt die onmiddellijk.

## Wat te doen als het niet werkt

Tekst-naar-spraak hangt af van uw apparaat. Theodia stuurt de tekst naar het besturingssysteem, en het besturingssysteem leest die voor met een stem. Werkt het niet, probeer dan deze stappen op volgorde.

### Theodia zegt dat TTS niet beschikbaar is

Sommige apparaten hebben helemaal geen TTS. Open **Instellingen** en zoek de sectie **TTS**. Is de sectie er niet, dan ondersteunt uw apparaat TTS niet in deze build.

### De stemmenlijst is leeg

De stemkiezer kan "geen stemmen gevonden" tonen. Dit betekent meestal dat het apparaat zijn stemmen nog niet klaar heeft geladen.

1. Open **Instellingen → Spraak → Stem selecteren**.
2. Is de lijst leeg, zoek dan net onder het vervolgkeuzemenu naar een knop **Opnieuw testen**. Tik erop. Theodia vraagt het apparaat opnieuw om stemmen.
3. Is hij nog steeds leeg, controleer dan de systeeminstellingen van uw apparaat. Op iOS: ga naar **Instellingen → Toegankelijkheid → Gesproken inhoud → Stemmen** en download een stem voor uw taal. Op Android: ga naar **Instellingen → Taal en invoer → Tekst-naar-spraak-uitvoer** en tik op **Spraakgegevens installeren**.
4. Sluit Theodia en open het opnieuw zodat het de nieuwe stem oppikt.

Heeft u favoriete stemmen ingesteld en is de lijst leeg, zorg dan dat ten minste een van uw favorieten overeenkomt met een op dit apparaat geïnstalleerde stem.

### Op Voorlezen tikken, maar er gebeurt niets

- Controleer dat het apparaat niet op stil staat. De meeste apparaten spelen geen TTS-audio in de stille modus.
- Zorg dat het volume van het apparaat omhoog staat.
- Probeer de knop **Opnieuw testen** in **Instellingen → Spraak**.
- Open **Instellingen** en bekijk onderaan de sectie **Systeem**. De regel **TTS** zou **Beschikbaar** moeten zeggen. Zegt die **Niet beschikbaar**, dan staat TTS uit op het niveau van het besturingssysteem. Zet het daar weer aan en open Theodia opnieuw.

### Er speelt audio, maar in de verkeerde taal

Theodia stuurt tekst in de taal van de huidige inhoud en vraagt het apparaat om de door u geselecteerde stem. Is de geselecteerde stem voor een andere taal, dan kan het apparaat de tekst nog steeds voorlezen, maar het klinkt vreemd.

1. Open **Instellingen → Spraak → Stem selecteren**.
2. Kies **Systeemstandaard** zodat het apparaat de juiste kiest, of kies een stem waarvan de taal overeenkomt met de tekst die u leest.

Theodia leest Griekse of Hebreeuwse interlineaire Bijbels momenteel niet voor. De knoppen Voorlezen en Luisteren zijn op die vertalingen verborgen.

### Er speelt audio, maar die stopt vroegtijdig

Ontbreekt een vers of is die onleesbaar, dan slaat het hoofdstuk die over. Sluit de balk zichzelf na een paar verzen, tik dan op de knop **Luisteren** (🔊) bovenaan het scherm om opnieuw te beginnen.

### De spraak speelt, maar ik weet niet waar die begon

Heeft u **Spraak op de achtergrond voortzetten** aangezet en hoort u later audio maar vindt u het scherm dat hem startte niet, dan kunt u hem vanuit de hele app stoppen.

1. Open **Instellingen**.
2. Zoek de sectie **Spraak**.
3. Tik onderaan de sectie op de rode knop **Spraak stoppen**.

Dit stopt onmiddellijk elke lopende tekst-naar-spraak in Theodia. U kunt ook de app-wisselaar van uw apparaat openen en Theodia wegveegen om de audio geforceerd te stoppen.

### Het leest te snel of te langzaam

Theodia beheert de leessnelheid niet. De snelheid wordt bepaald door de gekozen stem. Om die te veranderen:

- Op iOS: **Instellingen → Toegankelijkheid → Gesproken inhoud → Spreektempo**.
- Op Android: **Instellingen → Taal en invoer → Tekst-naar-spraak-uitvoer → Spraaksnelheid**.

## Tips

- De bedieningsbalk blijft zichtbaar terwijl u tussen hoofdstukken navigeert, zodat u kunt pauzeren, overslaan of van stem wisselen zonder uw plek te verliezen.
- Theodia leest versnummers als kleine pauzes. U kunt de balk stoppen, naar een ander vers vegen en dan op afspelen tikken om daar verder te gaan.
- Zet voor lange luistersessies **Niet storen** aan zodat meldingen de audio niet onderbreken.
- De knop 🔊 gebruikt het huidige volume van uw apparaat. Sluit u koptelefoon aan, dan wisselt het volume naar het koptelefoonniveau.

## Een PDF voorlezen

Theodia kan ook PDF-pagina's voorlezen. Open een PDF en tik op de knop **Luisteren** (luidspreker) in zijn werkbalk. Er verschijnt een bedieningsbalk met afspelen/pauzeren, terugspoelen, doorspoelen, stoppen, een voortgangsbalk en de snelheids- en stemkiezers. Is een pagina klaar, dan gaat het lezen automatisch verder op de volgende pagina.

PDF-lezing gebruikt de geïnstalleerde doorzoekbare tekst van de PDF en dezelfde stemmen en snelheid als Bijbellezing.

## Verwante gidsen

- De gids [Studiemodus](theodia://help/study-mode) behandelt het versmenu en de knoppen bovenaan het scherm in meer detail.
- De gids [Focusmodus](theodia://help/focus-mode) is een rustiger leesweergave die TTS ook ondersteunt via de knop 🔊 in de onderbalk.
- De gids [Veelvoorkomende problemen](theodia://help/common-problems) heeft oplossingen voor andere audio-, stem- en taalproblemen.
- De gids [Dagelijkse stichtelijke lezingen](theodia://help/daily-devotionals) behandelt het lezen van stichtelijke lezingen en waar de luisterknop op dat scherm zit.
- De gids [PDF's](theodia://help/pdfs) behandelt de PDF-lezer en zijn luisterknop.
