---
title: Welkom bij Theodia
level: beginner
categories: welcome
summary: Een korte rondleiding door de app en wat hij voor u kan doen.
---

# Welkom bij Theodia

Theodia is een app voor Bijbelstudie. Hij draait op uw telefoon of tablet, ook zonder internet. Alles wat u leest, zoekt en bestudeert wordt op uw apparaat opgeslagen.

## Wat u kunt doen

Theodia heeft drie gebruikersmodi. Elke modus toont een andere set functies.

- **Lezer** — lees de Bijbel in een rustige weergave zonder afleiding.
- **Standaard** — alles uit Lezer, plus bladwijzers, markeringen, notities, voorlezen, zoeken en dagelijkse stichtelijke lezingen.
- **Geleerde** — alles uit Standaard, plus commentaren, lexicons, het Bijbelwoordenboek, de AI-assistent en meer.

U kunt op elk moment van modus wisselen in **Instellingen** → **App-gebruikersmodus**.

### Functies die voor u beschikbaar zijn

Welke modus u ook kiest, u kunt altijd:

- **De Bijbel lezen.** Kies uit vele vertalingen. Wissel op elk moment tussen vertalingen.
- **De Bijbel doorzoeken.** Zoek op een woord of zin. De app toont elk vers dat overeenkomt.
- **Boeken en stichtelijke lezingen lezen.** De app bevat christelijke klassiekers en een dagelijkse stichtelijke lezing.

Afhankelijk van uw modus kunt u ook:

- **Luisteren.** Laat verzen voorlezen met de voorleesfunctie. (Standaard en Geleerde.)
- **Notities maken.** Schrijf uw eigen gedachten bij een vers. (Standaard en Geleerde.)
- **Markeren.** Markeer uw favoriete verzen in kleur. (Standaard en Geleerde.)
- **Bladwijzers maken.** Sla verzen op zodat u ze snel terugvindt. (Standaard en Geleerde.)
- **De AI-assistent raadplegen.** Krijg hulp bij het begrijpen van een vers. (Alleen Geleerde.)

## Waar te beginnen

1. Open het tabblad **Bijbel** onder aan het scherm.
2. Kies een vertaling.
3. Tik op een boek om te beginnen met lezen.

Wilt u meer weten? De overige hulpgidsen staan voor u klaar. Kies een onderwerp uit de lijst op de hulppagina.

## Een paar dingen om te weten

- U heeft geen account nodig.
- Uw notities, markeringen en bladwijzers blijven op uw apparaat.
- U kunt er een back-up van maken. Zie de gids [Back-up van uw gegevens](theodia://help/backups) voor instructies.

## Meer bronnen gewenst?

De app bevat enkele vrij beschikbare Bijbelvertalingen. Voor extra Bijbels, commentaren, lexicons, boeken en stichtelijke lezingen, zie de gids [Extra bronnen van GitHub](theodia://help/getting-core-files). Daar leest u hoe u meer bronnen van de GitHub-pagina van het project vindt en toevoegt.

Welkom. We hopen dat Theodia u helpt bij het lezen en bestuderen.
