---
title: Wat zijn bronnen?
level: beginner
categories: resources
summary: Een overzicht van de verschillende soorten bestanden die Theodia gebruikt — Bijbels, commentaren, boeken en meer.
---

# Wat zijn bronnen?

In Theodia is een "bron" elk bestand dat lees- of studiemateriaal aan de app toevoegt. De app zelf is alleen een lezer en een notitieblok. De Bijbels, commentaren, boeken en andere materialen waarmee u studeert, zijn allemaal aparte bestanden die u inlaadt.

Deze gids legt de verschillende soorten bronnen uit en waar elke soort voor dient.

## Waarom is dit belangrijk?

Wanneer u Theodia voor het eerst opent, heeft het al een paar dingen om te lezen. Tijdens het verkennen ziet u knoppen om meer te installeren. Weten wat elke soort bron is, helpt u beslissen wat u toevoegt.

## De verschillende soorten bronnen

Theodia herkent bestanden aan hun extensie. Elke extensie is een andere soort bron.

### `.bible` — een Bijbelvertaling

Een Bijbelvertaling is een volledige kopie van de Bijbel in een bepaalde versie, zoals de King James Version. Theodia wordt met een paar vertalingen geleverd en laat u er meer toevoegen.

Zie de gids [Bijbelvertalingen installeren](theodia://help/installing-bibles) voor details.

### `.commentary` — een commentaar

Een commentaar is een boek met studienotities, geschreven door een Bijbelgeleerde. Voor een bepaald vers vertelt een commentaar u de achtergrond, de betekenis en hoe het vers in de rest van de Bijbel past.

Zie de gids [Commentaren en lexicons](theodia://help/commentaries-and-lexicons) voor details.

### `.lexicon` — een lexicon

Een lexicon is een woordenboek van Bijbelwoorden. Het vertelt u het oorspronkelijke Hebreeuwse of Griekse woord, wat het betekent en hoe het in de Bijbel wordt gebruikt.

Zie de gids [Commentaren en lexicons](theodia://help/commentaries-and-lexicons) voor details.

### `.book` — een christelijk boek

Een boek is een langer christelijk werk, zoals een klassieker uit de kerkgeschiedenis. Boeken lezen in de app werkt ongeveer zoals een Bijbel lezen. Theodia wordt geleverd met een kleine bibliotheek van vrij beschikbare christelijke klassiekers.

Zie de gids [Ingebouwde boeken lezen](theodia://help/reading-books) voor details.

### `.devotional` — een stichtelijke lezing

Een stichtelijke lezing is een korte dagelijkse lezing. Elk item heeft meestal een vers, een korte beschouwing en een gebed of vraag om over na te denken. Veel stichtelijke lezingen zijn ontworpen om een item per dag een jaar lang te lezen.

Zie de gids [Dagelijkse stichtelijke lezingen](theodia://help/daily-devotionals) voor details.

### `.sqlite` — een naslagdatabase

Een naslagdatabase is een groot opzoekbestand dat de app gebruikt om u extra informatie te geven tijdens het lezen. Er zijn twee soorten:

- **Kruisverwijzingen** — lijsten met verzen die aansluiten bij het vers dat u leest.
- **Morfologie** — informatie over de oorspronkelijke Hebreeuwse of Griekse woorden in het vers.

U opent deze niet direct. Ze werken op de achtergrond en voegen functies aan de Bijbellezer toe. Zie de gids [Kruisverwijzingen](theodia://help/cross-references) voor details.

### `.data` — woordgegevens

Een woordgegevensbestand bevat extra informatie over de oorspronkelijke Bijbelwoorden. Het wordt gebruikt door het lexicon en de studiehulpmiddelen. Zoals de naslagdatabases opent u het niet direct. De app gebruikt het op de achtergrond.

## Een bron toevoegen

Het scherm **Bronnen beheren** van de app is de gemakkelijke manier om een bron toe te voegen.

1. Open **Instellingen**.
2. Tik op **Bronnen beheren**.
3. Tik op **Installeren vanaf GitHub**.
4. Kies in het downloadvenster een tabblad — **Bijbels**, **Commentaren**, **Boeken**, **Stichtelijke lezingen** of **Kern** — selecteer dan wat u wilt en tik op **Geselecteerde installeren**.
5. Of tik op **Lokaal bestand importeren** om een bestand te importeren dat u al heeft gedownload.

Zie voor een stapsgewijze rondleiding langs het rechtstreeks ophalen van bestanden van GitHub de gids [Extra bronnen van GitHub](theodia://help/getting-core-files).

## Een bron verwijderen

1. Open **Instellingen**.
2. Tik op **Bronnen beheren**.
3. Zoek de bron die u wilt verwijderen.
4. Tik op het prullenbakpictogram ernaast.
5. Bevestig dat u haar wilt verwijderen.

Een bron verwijderen wist uw notities, markeringen of bladwijzers niet. Die blijven behouden.

## Waar bronnen op uw apparaat wonen

Bronnen worden op uw apparaat opgeslagen, niet in de cloud. Eenmaal geïnstalleerd heeft u het internet niet nodig om ze te lezen. U kunt een back-up van uw apparaat maken, maar de bronnen zelf worden door Theodia niet naar de cloud geback-upt. Verwijdert u de app en installeert haar opnieuw, dan moet u alle geïnstalleerde bronnen opnieuw toevoegen.

## Hulp en vragen

Loopt u tegen iets aan, zie dan de gids [Waar u vragen kunt stellen](theodia://help/getting-more-help). Het team en de gemeenschap helpen u graag.
