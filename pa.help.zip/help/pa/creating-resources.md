---
title: ਤੁਹਾਡੇ ਆਪਣੇ ਸੰਸਾਧਨ ਬਨਾਉਣਾ
level: advanced
categories: resources
summary: Theodia ਲਈ ਕਸਟਮ ਬਾਈਬਲਾਂ, ਟਿੱਪਣੀਆਂ, ਕਿਤਾਬਾਂ, devotional ਅਤੇ lexicon ਕਿਵੇਂ ਬਨਾਉਣੇ ਅਤੇ ਆਇਆਤ ਕਰਨੇ ਹਨ.
---

# ਤੁਹਾਡੇ ਆਪਣੇ ਸੰਸਾਧਨ ਬਨਾਉਣਾ

Theodia Unique Bible App ਫ਼ਾਰਮੈਟ ਵਿੱਚ ਕਸਟਮ ਸੰਸਾਧਨਾਂ ਦਾ ਸਮਰਥਨ ਕਰਦਾ ਹੈ. ਹਰ ਸੰਸਾਧਨ ਇੱਕ ਵਿਸ਼ੇਸ਼ ਟੇਬਲ ਸੰਰਚਨਾ ਵਾਲੀ SQLite ਫ਼ਾਈਲ ਹੁੰਦਾ ਹੈ. ਤੁਸੀਂ ਇਹ ਫ਼ਾਈਲਾਂ ਕੰਪਿਊਟਰ 'ਤੇ ਬਨਾ ਸਕਦੇ ਹੋ ਅਤੇ ਐਪ ਵਿੱਚ ਆਇਆਤ ਕਰ ਸਕਦੇ ਹੋ.

## ਫ਼ਾਈਲ ਪ੍ਰਕਾਰ ਅਤੇ ਜ਼ਰੂਰੀ ਟੇਬਲ

### ਬਾਈਬਲ (`.bible`)

ਬਾਈਬਲ ਫ਼ਾਈਲ ਘੱਟੋ-ਘੱਟ ਇਨ੍ਹਾਂ ਟੇਬਲਾਂ ਵਿੱਚੋਂ ਇੱਕ ਵਾਲੀ SQLite ਡੇਟਾਬੇਸ ਹੈ:

- **`Verses`** — ਕਾਲਮ: `Book` (ਪੂਰਨਾਂਕ, 1-66), `Chapter` (ਪੂਰਨਾਂਕ), `Verse` (ਪੂਰਨਾਂਕ), `Scripture` (ਪਾਠ)
- **`Bible`** — ਕਾਲਮ: `Book` (ਪੂਰਨਾਂਕ), `Chapter` (ਪੂਰਨਾਂਕ), `Verse` (ਪੂਰਨਾਂਕ), `Scripture` (ਪਾਠ)

ਤੁਸੀਂ **`Details`** ਟੇਬਲ ਵੀ ਸ਼ਾਮਿਲ ਕਰ ਸਕਦੇ ਹੋ ਜਿਸ ਵਿੱਚ `Description`, `Abbreviation` ਅਤੇ `Version` ਵਰਗੇ metadata ਕਾਲਮ ਹੋਣ.

ਉਦਾਹਰਨ SQL:

```sql
-- ਮੁੱਖ ਪਾਠ ਟੇਬਲ
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- ਵਿਕਲਪਿਕ metadata ਟੇਬਲ
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### ਟਿੱਪਣੀਆਂ (`.commentary`)

ਟਿੱਪਣੀਆਂ ਤਿੰਨ ਪ੍ਰਕਾਰ ਦੀਆਂ ਹੁੰਦੀਆਂ ਹਨ: **ਕਿਤਾਬ**, **chapter**, ਅਤੇ **verse**. ਪ੍ਰਕਾਰ filename ਦੇ ਪਹਿਲੇ ਅੱਖਰ ਤੋਂ ਨਿਰਧਾਰਤ ਹੁੰਦਾ ਹੈ.

#### ਕਿਤਾਬ ਟਿੱਪਣੀਆਂ — filename `b` ਨਾਲ ਸ਼ੁਰੂ ਹੁੰਦਾ ਹੈ

ਕਿਤਾਬ ਟਿੱਪਣੀ ਬਾਈਬਲ ਦੀ ਇੱਕ ਪੂਰੀ ਕਿਤਾਬ ਨੂੰ ਇੱਕ single entry ਵਿੱਚ ਕਵਰ ਕਰਦੀ ਹੈ. `Commentary` ਟੇਬਲ ਵਿੱਚ `Book` ਅਤੇ `Scripture` (ਜਾਂ `Content`) ਕਾਲਮ ਚਾਹੀਦੇ ਹਨ. `Chapter` ਜਾਂ `Verse` ਕਾਲਮ ਦੀ ਲੋੜ ਨਹੀਂ.

- **`Commentary`** — ਕਾਲਮ: `Book` (ਪੂਰਨਾਂਕ), `Scripture` (text) ਜਾਂ `Content` (text)

ਉਦਾਹਰਨ SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

Filename ਉਦਾਹਰਨ: `bMyCommentary.commentary`

#### Chapter ਟਿੱਪਣੀਆਂ — filename `c` ਨਾਲ ਸ਼ੁਰੂ ਹੁੰਦਾ ਹੈ

chapter ਟਿੱਪਣੀ ਬਾਈਬਲ ਕਿਤਾਬ ਦੇ ਹਰ chapter ਨੂੰ ਕਵਰ ਕਰਦੀ ਹੈ.

- **`Commentary`** — ਕਾਲਮ: `Book` (ਪੂਰਨਾਂਕ), `Chapter` (ਪੂਰਨਾਂਕ), `Scripture` (text) ਜਾਂ `Content` (text)

ਉਦਾਹਰਨ SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

Filename ਉਦਾਹਰਨ: `cMyCommentary.commentary`

#### Verse ਟਿੱਪਣੀਆਂ — filename `v` ਨਾਲ ਸ਼ੁਰੂ ਹੁੰਦਾ ਹੈ

verse ਟਿੱਪਣੀ ਵਿਅਕਤੀਗਤ verses ਨੂੰ ਕਵਰ ਕਰਦੀ ਹੈ. `Commentary` ਟੇਬਲ ਵਿੱਚ `Book`, `Chapter`, `Verse`, ਅਤੇ `Scripture` (ਜਾਂ `Content`) ਕਾਲਮ ਚਾਹੀਦੇ ਹਨ.

- **`Commentary`** — ਕਾਲਮ: `Book` (ਪੂਰਨਾਂਕ), `Chapter` (ਪੂਰਨਾਂਕ), `Verse` (ਪੂਰਨਾਂਕ), `Scripture` (text) ਜਾਂ `Content` (text)

ਉਦਾਹਰਨ SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

Filename ਉਦਾਹਰਨ: `vMyCommentary.commentary`

### ਕਿਤਾਬਾਂ (`.book`)

ਕਿਤਾਬ ਫ਼ਾਈਲ SQLite ਡੇਟਾਬੇਸ ਹੈ ਜਿਸ ਵਿੱਚ `Reference` ਟੇਬਲ ਹੁੰਦੀ ਹੈ.

- **`Reference`** — ਕਾਲਮ: `id` (ਪੂਰਨਾਂਕ), `Chapter` (text), `Content` (text)

ਹਰ row ਇੱਕ chapter ਹੁੰਦੀ ਹੈ. `Chapter` ਕਾਲਮ chapter ਦਾ ਸਿਰਲੇਖ ਹੁੰਦਾ ਹੈ. `Content` ਕਾਲਮ chapter ਦਾ ਮੁੱਖ ਪਾਠ ਹੁੰਦਾ ਹੈ, ਜਿਸ ਵਿੱਚ HTML (`<b>`, `<i>`, `<br>`, ਆਦਿ) ਸ਼ਾਮਿਲ ਹੋ ਸਕਦਾ ਹੈ.

ਉਦਾਹਰਨ SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

ਤੁਸੀਂ Markdown ਫ਼ਾਈਲਾਂ ਤੋਂ ਵੀ ਕਿਤਾਬਾਂ ਬਨਾ ਸਕਦੇ ਹੋ. ਐਪ `.md` ਫ਼ਾਈਲਾਂ ਆਇਆਤ ਕਰ ਸਕਦਾ ਹੈ ਜਿਥੇ `#` ਕਿਤਾਬ ਦਾ ਸਿਰਲੇਖ ਹੈ ਅਤੇ `##` chapters ਨੂੰ ਦਰਸਾਉਂਦਾ ਹੈ. Markdown ਸਵੈਚਾਲਤ ਰੂਪ ਵਿੱਚ HTML ਵਿੱਚ ਪਰਿਵਰਤਿਤ ਹੁੰਦਾ ਹੈ.

### Devotional (`.devotional`)

devotional ਫ਼ਾਈਲ SQLite ਡੇਟਾਬੇਸ ਹੈ ਜਿਸ ਵਿੱਚ `devotional` ਟੇਬਲ ਹੁੰਦੀ ਹੈ.

- **`devotional`** — ਕਾਲਮ: `month` (ਪੂਰਨਾਂਕ, 1-12), `day` (ਪੂਰਨਾਂਕ, 1-31), `devotion` (text)

ਹਰ row ਇੱਕ ਦਿਨ ਦੀ ਪੜ੍ਹਾਈ ਹੁੰਦੀ ਹੈ. ਐਪ ਅੱਜ ਦੇ month ਅਤੇ day ਅਨੁਸਾਰ entry ਲੱਭਦਾ ਹੈ.

ਉਦਾਹਰਨ SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### Lexicon (`.lexicon`)

lexicon ਫ਼ਾਈਲ SQLite ਡੇਟਾਬੇਸ ਹੈ ਜਿਸ ਵਿੱਚ `Lexicon` ਟੇਬਲ ਹੁੰਦੀ ਹੈ.

- **`Lexicon`** — ਕਾਲਮ: `Topic` (text, Strong's number), `Definition` (text, lexicon entry)

`Topic` ਕਾਲਮ Strong's number ਰੱਖਦਾ ਹੈ (ਉਦਾਹਰਨ: `G1161` ਜਾਂ `H7225`). `Definition` ਕਾਲਮ ਪੂਰਾ entry text ਰੱਖਦਾ ਹੈ, ਜਿਸ ਵਿੱਚ HTML ਸ਼ਾਮਿਲ ਹੋ ਸਕਦਾ ਹੈ.

ਉਦਾਹਰਨ SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

Lexicon Word Info ਟੂਲ ਨੂੰ power ਕਰਦੇ ਹਨ. ਜਦੋਂ ਤੁਸੀਂ interlinear Bible ਵਿੱਚ ਇੱਕ word 'ਤੇ tap ਕਰਦੇ ਹੋ, ਐਪ installed lexicon ਵਿੱਚ Strong's number ਲੱਭਦਾ ਹੈ.

## ਕੰਪਿਊਟਰ 'ਤੇ ਫ਼ਾਈਲ ਬਨਾਉਣਾ

1. SQLite editor ਇੰਸਟਾਲ ਕਰੋ (DB Browser for SQLite, SQLiteStudio, ਜਾਂ `sqlite3` command-line tool).
2. ਨਵਾਂ database ਫ਼ਾਈਲ ਬਨਾਓ.
3. ਜ਼ਰੂਰੀ ਟੇਬਲ ਬਨਾਓ ਅਤੇ ਆਪਣਾ data insert ਕਰੋ.
4. ਫ਼ਾਈਲ ਨੂੰ ਸਹੀ extension (`.bible`, `.commentary`, `.book`, `.devotional`, ਜਾਂ `.lexicon`) ਨਾਲ save ਕਰੋ.

## Theodia ਵਿੱਚ ਆਇਆਤ ਕਰਨਾ

1. ਫ਼ਾਈਲ ਆਪਣੇ device 'ਤੇ transfer ਕਰੋ (AirDrop, email, cloud storage, ਜਾਂ USB).
2. **Theodia** ਖੋਲ੍ਹੋ.
3. **ਸੈਟਿੰਗਜ਼** → **ਸੰਸਾਧਨ ਪ੍ਰਬੰਧਨ** 'ਤੇ ਜਾਓ.
4. **ਫ਼ਾਈਲ ਤੋਂ ਆਇਆਤ ਕਰੋ** 'ਤੇ tap ਕਰੋ.
5. ਆਪਣੀ ਫ਼ਾਈਲ select ਕਰੋ.

ਐਪ ਫ਼ਾਈਲ validate ਕਰਦਾ ਹੈ (ਜ਼ਰੂਰੀ ਟੇਬਲ ਦੀ ਜਾਂਚ), ਇਸਨੂੰ app ਦੇ data folder ਵਿੱਚ copy ਕਰਦਾ ਹੈ, ਅਤੇ automatically enable ਕਰ ਦਿੰਦਾ ਹੈ. ਜੇਕਰ ਫ਼ਾਈਲ invalid ਹੈ, ਤਾਂ ਤੁਹਾਨੂੰ error message ਮਿਲਦਾ ਹੈ ਜਿਸ ਵਿੱਚ ਬਤਾਇਆ ਹੁੰਦਾ ਹੈ ਕਿ ਕੀ ਗਲਤ ਹੈ.

## ਸੀਮਾਵਾਂ

- ਤੁਸੀਂ built-in ਸੰਸਾਧਨ overwrite ਨਹੀਂ ਕਰ ਸਕਦੇ. ਜੇਕਰ ਤੁਸੀਂ built-in Bible, commentary, ਜਾਂ ਕਿਤਾਬ ਦੇ ਨਾਮ ਵਾਲੀ ਫ਼ਾਈਲ import ਕਰਨ ਦੀ ਕੋਸ਼ਿਸ਼ ਕਰਦੇ ਹੋ, import fail ਹੁੰਦਾ ਹੈ.
- Bible ਫ਼ਾਈਲ ਵਿੱਚ `Verses` ਜਾਂ `Bible` ਟੇਬਲ ਚਾਹੀਦੀ ਹੈ. ਜੇਕਰ ਕੋਈ ਵੀ ਨਹੀਂ ਹੈ, import fail ਹੁੰਦਾ ਹੈ.
- Commentary ਫ਼ਾਈਲ ਵਿੱਚ `Commentary` ਟੇਬਲ ਚਾਹੀਦੀ ਹੈ.
  - ਕਿਤਾਬ ਟਿੱਪਣੀ ਵਿੱਚ `Book` ਅਤੇ `Scripture` (ਜਾਂ `Content`) ਕਾਲਮ ਚਾਹੀਦੇ ਹਨ.
  - Chapter ਟਿੱਪਣੀ ਵਿੱਚ `Book`, `Chapter`, ਅਤੇ `Scripture` (ਜਾਂ `Content`) ਕਾਲਮ ਚਾਹੀਦੇ ਹਨ.
  - Verse ਟਿੱਪਣੀ ਵਿੱਚ `Book`, `Chapter`, `Verse`, ਅਤੇ `Scripture` (ਜਾਂ `Content`) ਕਾਲਮ ਚਾਹੀਦੇ ਹਨ.
- ਕਿਤਾਬ ਫ਼ਾਈਲ ਵਿੱਚ `Reference` ਟੇਬਲ ਚਾਹੀਦੀ ਹੈ.
- Lexicon ਫ਼ਾਈਲ ਵਿੱਚ `Lexicon` ਟੇਬਲ ਚਾਹੀਦੀ ਹੈ.
- Devotional ਫ਼ਾਈਲ ਵਿੱਚ `devotional` ਟੇਬਲ ਚਾਹੀਦੀ ਹੈ.

## ਟਿਪਸ

- ਫ਼ਾਈਲ ਦਾ ਆਕਾਰ ਵਾਜਬ ਰੱਖੋ. ਬਹੁਤ ਵੱਡੀ SQLite ਫ਼ਾਈਲ ਪੁਰਾਣੇ devices 'ਤੇ memory ਸਮੱਸਿਆਵਾਂ ਪੈਦਾ ਕਰ ਸਕਦੀ ਹੈ.
- ਪਹਿਲਾਂ ਕੰਪਿਊਟਰ 'ਤੇ ਫ਼ਾਈਲ test ਕਰੋ. SQLite browser ਵਿੱਚ ਖੋਲ੍ਹੋ ਅਤੇ `SELECT * FROM` ਜ਼ਰੂਰੀ ਟੇਬਲ run ਕਰਕੇ data ਦੀ ਜਾਂਚ ਕਰੋ.
- ਬਾਈਬਲਾਂ ਲਈ, `Book` ਕਾਲਮ ਵਿੱਚ numbers ਵਰਤੋ (1 = ਉਤਪਤੀ, 66 = ਪ੍ਰਕਾਸ਼ ਦੀ ਪੋਥੀ).
- ਟਿੱਪਣੀਆਂ ਲਈ, ਤੁਸੀਂ `Scripture` ਜਾਂ `Content` ਵਿੱਚੋਂ ਕੋਈ ਵੀ commentary text ਕਾਲਮ ਵਰਤ ਸਕਦੇ ਹੋ.
- ਕਿਤਾਬਾਂ ਲਈ, `Content` ਕਾਲਮ ਵਿੱਚ HTML reading ਸਮੇਂ render ਹੁੰਦਾ ਹੈ. ਇਸਨੂੰ ਸਾਦਾ ਰੱਖੋ: `<b>`, `<i>`, `<br>`, ਅਤੇ `<hr>` safe ਹਨ.

## ਮੌਜੂਦਾ ਸੰਸਾਧਨ ਕਿੱਥੇ ਲੱਭਣੇ ਹਨ

Theodia [Unique Bible App](https://github.com/eliranwong/UniqueBible) ਪ੍ਰੋਜੈਕਟ ਤੋਂ ਸੰਸਾਧਨ ਪੜ੍ਹ ਸਕਦਾ ਹੈ. ਉਥੇ ਕਈ ਬਾਈਬਲਾਂ, ਟਿੱਪਣੀਆਂ, ਕਿਤਾਬਾਂ ਅਤੇ ਹੋਰ ਸੰਸਾਧਨ ਸਹੀ SQLite ਫ਼ਾਰਮੈਟ ਵਿੱਚ ਉਪਲਬਧ ਹਨ. ਇਨ੍ਹਾਂ ਨੂੰ ਲੱਭਣ ਅਤੇ ਜੋੜਨ ਲਈ [Getting Extra Resources from GitHub](theodia://help/getting-core-files) guide ਦੇਖੋ.
