---
title: Core Files ਜੋੜਣੇ
level: beginner
categories: start
summary: ਬਾਈਬਲ ਦੀ depth ਵਿੱਚ study करਨ ਵालੀआਂ large data files download करਨा.
---

# Core Files ਜੋੜਣੇ

Theodia Bible ਅਤੇ small extras ਨਾਲ ready. ਜ਼ਿਆਦਾ benefit ਲਈ **core files** download ਕਰੋ. लਾਰج data files addition tools ਜਿਵੇं commentary, word lookups, grammar. Without, app ਕੰਮ ਕਰਦਾ ਪਰ study features limited.

## ਕਿਉਂ ਚਾਹੀਦੇ

- **Word lookups.** ਕੋਈ ਵੀ word टैਪ ਤਾਂ original Hebrew/Greek ਅਤੇ ਅਰਥ.
- **Commentary.** AI Commentary on each verse.
- **Grammar.** Original language ਦਾ each word info.
- **Interlinear Bible.** English ਹੇਠਾਂ original-language text.

�ਿਨਾਂ ਪੜ੍ਹ ਸਕਦੇ, ਪર study tools ਚਾਹੀਦੇ.

## ਕਿਵੇਂ install ਕਰੋ

**[Install Core Files](theodia://manage/core)**

1. **Settings** खोल.
2. **Manage Resources** टैप.
3. **Core** tab automatically opens. List ਦਿਖ. ਹਰ file name, size, checkbox.
4. जੋ चाहੀਦਾ selects करੋ.
5. **Install Selected** टैप.
6. download हੋਣ तक wait. Large, slow connection minutes.

Files device 'ਤੇ download. ਇੱਕ ਵਾਰ. App offline ਭੀ use.

## ਟਿੱਪਸ

- Wi-Fi वरਤੋ.
- Phone/tablet plug ਕਰੋ.
- Download fail ਤਾਂ file ਫਿਰ टैप.
- सारੇ ਜਾਂ चाहੀਦੇ जrist.

## ਜੇ ਫਾਇਲ list विच missing

List GitHub ਤੋਂ pulls. Empty app → internet check ਫਿਰ try. ਫਿਰ [Where to Ask Questions](theodia://help/getting-more-help). Advanced resources [Getting Extra Resources from GitHub](theodia://help/getting-core-files).
