---
title: ਐਪ ਭਾਸ਼ਾ ਅਤੇ Region
level: everyday
categories: settings
summary: ਐਪ ਦੀ language ਕਿਵੇਂ ਬਦਲਣੀ.
---

# ਐਪ ਭਾਸ਼ਾ ਅਤੇ Region

Theodia ਬਹੁਤ ਭਾਸ਼ਾਵਾਂ ਵਿੱਚ. App menus/buttons language बदल सकਦਾ. Help content भी many languages 'ਤੇ built-in. Help pack download/update: **Settings** → **Help** या **Manage Resources** → **Install from GitHub** → **Help docs**.

## Language settings खोलਣਾ

1. **Settings** खोल.
2. **Language** टैप.

## App language ਬਦਲਣਾ

1. **Language** list 'ते चाहीਦਾ ਟैप.
2. App apply करਦਾ.

 choices supported languages 'ਤੇ depend.

## First install language

First install app device settings ਦੁਆरਾ language চੁਣ. ਬਾਅਦ ਬਦਲ सकਦੇ.

## ਕੀ translate ਹੁੰਦਾ

- Menus, buttons, labels.
- Settings screens.
- Error messages.
- Search and study tools.

## ਕੀ صिर्फ English ਵਿੱਚ

- ਕੁਛ book ਅਤੇ devotional content.

## ਬਾਈਬਲ translations ਔਰ app language

App language ਔਰ Bible translation language अलग. Spanish app + English Bible possible.

Translation ਬਦਲਣ ਲਈ [Installing Bible Translations](theodia://help/installing-bibles) देख.

## ਟਿੱਪਸ

- empty button/label -> translation missing. English fallback.
- Translate app helper -> [Where to Ask Questions](theodia://help/getting-more-help).
