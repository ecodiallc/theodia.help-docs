---
title: Launcher Menu
level: everyday
categories: layout
summary: Recent verses ਨੂੰ jump, commands run, ਔਰ Bible layouts switch ਕਰਨ ਦਾ ਤੇਜ਼ way.
---

# Launcher Menu

> **Mode:** Launcher Menu ਲਈ **Scholar** mode. ਮੋਡ बदलਣ ਲਈ **Settings** → **App User Mode**.

Launcher Menu ਇੱਕ fast-access panel. ਲਗਭਗ anywhere app विच खोल सकਦੇ. Recent verses, commands, saved Bible setups एक जगह.

## ਕਿਵੇਂ खोलਣਾ

Home screen header top-right 'ते **expand icon (⌄)** टैप. Panel top तੋਂ slide.

## अੰਦਰ ਕੀ ਹੈ

### 1. Command Box

Panel top 'ते text box with keyboard icon. Command टਾਈप + **Go**. App reads command ਔर there जांदा.

Examples:
- `John 3:16` — opens verse.
- `search love` — searches Bible.
- `bookmark psalms 23` — bookmarks verse.
- `kjv` — switch to KJV.

Full commands [Commands](theodia://help/commands) guide.

### 2. Parallel Sets

Saved parallel Bible presets panel विच collapsible list. टैप तां instant setup load.

Preset create:
1. **Settings** → **Parallel Bible**.
2. translations add + **Save Preset**.
3. Name.

Long-press deletion.

### 3. Bible Collections

One-tap shortcuts translating + parallel view एक साथ. Long-press delete.

### 4. Feature Icons

Round emoji buttons major features shortcuts. Available: About, Bibles, Bible Notes, Bookmarks, Books, Devotionals, Flashcards, Help, Highlights, Playlists, Plugins, Search, Settings, Theoscript.

Choose/order:
1. **Settings** → **Launcher Menu**.
2. **Launcher Menu Icons** टैप.
3. switches show/hide.
4. up/down arrows reorder.

### 5. Recent Verses

App last opened chapters/verses remembers. Panel bottom list. Tap open; swipe left or long-press remove; **Clear all**.

## ਕਦੋਂ वरਤੋ

- जust read verse तੇ jump.
- Home screen बिना command type.
- Translation/parallel one tap switch.
- Major feature anywhere.
- Menus बिना quick check.

## ਟਿੱਪਸ

- Launcher Menu almost every screen 'ਤੇ, reading दौरान भी खोल सकਦੇ.
- Command box home screen commands same support.
- Icons/order local save.
- Recent verses local save.
