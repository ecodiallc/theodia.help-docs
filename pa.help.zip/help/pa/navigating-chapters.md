---
title: ਕਿਤਾਬਾਂ, ਅਧਿਆਇਆਂ ਅਤੇ ਵਚਨਾਂ ਦੇ ਵਿੱਚ ਨੈਵੀਗੇਟ ਕਰਨਾ
level: everyday
categories: [layout, read]
summary: ਬਾਈਬਲ ਵਿੱਚ ਕਿਵੇਂ ਘੁੰਮਣਾ ਔਰ ਜਾਣਾ ਜਹां जाना है.
---

# ਕਿਤਾਬਾਂ, ਅਧਿਆਇਆਂ ਔਰ ਵਚਨਾਂ ਦੇ ਵਿੱਚ ਨੈਵੀਗੇਟ ਕਰਨਾ

बਾਈਬਲ ਵਿੱਚ move ਕਰਨ ਦੇ ਸਾਰੇ तरीके.

## ਆਸਾਨ तਰीका: स्वाईप

- ਅਧਿਆਇ 'ਤੇ **left swipe** → ਅਗਲਾ ਅਧਿਆਇ.
- **right swipe** → ਵਾਪਸ.
- Books पਾਰ ਵੀ. Exodus ਦੇ ਆਖਰੀ chapter ਤੋਂ ਬाद Leviticus ਦਾ ਪਹਿਲਾ.

## ਮੇਨੂ तरीका

- ਊपर translation name टੈप → दੂसरा Bible.
- ਊपर book name टੈप → दੂसरा book.
- ਊपर chapter number टैप → दੂसरਾ chapter.

## ਤੇਜ਼ तरीका: type ਕਰੋ

Home page top 'ते box. Reference like `John 3:16` ਜਾਂ `psalms 23` टਾਈप + **Go**. App verse खोलਦा.

## ਬੁੱਕमार्क तरीका

**Bookmarks** tab खोल. entry टੈप → jump.

## ਖੋਜ तरीका

**Search** tab, word टਾਈप. हर verse जिसमें है दिख. Tap open.

## ਹिस्āroи तरीका

App recently opened chapters remembers. Book list scroll in **Bible** tab.

## ਟਿੱਪਸ

- Bible tab Genesis ਤੋਂ Revelation order.
- Psalms/Proverbs जैसे long books 'ਤੇ book टੈप + chapter list वरਤ.
