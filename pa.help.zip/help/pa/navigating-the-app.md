---
title: ਐਪ Layout और नैवीगेशन
level: beginner
categories: layout
summary: Home screen, main menu, ਔर bottom toolbar — ਸब ਕुछ ਕਿੱਥੇ.
---

# ਐप Layout और नैवीगेशन

Theodia में three main areas: **home screen**, **main menu**, **bottom toolbar**.

## Quick map

- **Home screen** — search box, big buttons, installed Bibles/books/devotionals lists.
- **Bottom toolbar (tab bar)** — icons row. Tap jump.
- **Main menu** — top-right ☰ on home. opens list of every screen.

## Home screen

Four parts top to bottom:

### Header

Colored bar. Left app icon + "Theodia." Right ☰. inside book/chapter left back arrow.

### Command

Search-style box. Short instruction + Go. Examples:
- `psalms 23` — opens chapter
- `john 3:16`
- `search love`
- `bookmark john 3:16`
- `commentary romans 8:28`
- `xref ...`
- `help`

Don't understand -> alert. Common Problems guide.

### Button grid

Two per row:
📖 Bibles, 🔍 Search, 📚 Books, 📅 Devotionals, 🔖 Bookmarks, 🖍 Highlights, 📝 Notes, ⚙️ Settings, ❓ Help, ℹ️ About.

### Resource lists

Expandable: Bibles, Books, Devotionals. Tap header expand/collapse; tap item open. Bibles fastest.

## Bottom toolbar

Icons row always visible. Tabs mode dependent.

**All modes:** 🏠 Home, 📖 Bibles, 📚 Books, 🔍 Search, ⚙️ Settings.
**Standard/Scholar:** 🔖 Bookmarks, 🖍 Highlights, 📝 Notes.
**Scholar:** 💻 AI (if turned on).

Current tab highlighted.

### Behavior

Each tab own **stack**. Tap tab -> where left off. Example Bibles -> translations -> books -> chapters -> chapter; switch Bookmarks; tap Bibles -> back at chapter. Each tab remembers. Tab resets only if already on tab and tap icon again, or app force-close/reopen.

### Bottom tabs vs main menu

Tabs remember stack; menu items navigate using same tab system (not overlay).

## Main menu

☰ top-right home. Panel right slide lists all mode-supported screens:
🏠 Home, 📖 Bibles, 📚 Books, 🙏 Devotionals, 🔍 Search, 🔖 Bookmarks (Standard/Scholar), 🖍 Highlights, 📝 Notes, 💻 AI Assistant (Scholar if on), ⚙️ Settings, ❓ Help, ℹ️ About.

Current screen highlighted with dot. Tap item open; close tap outside/X/back.

Menu is dropdown not overlay. Tabs switch context remember place; menu another way.

Use menu for Highlights, Notes, Devotionals, Help, About (no tab); deep check without losing place; Settings anywhere.

## Scholar mode

Extra tabs/menu/tools. see Scholar Mode guide.

## How three areas fit

- Switch main section -> bottom toolbar
- Jump verse/command -> Home Command
- Browse all -> button grid
- Notes/Highlights/Help without leaving -> main menu
- Settings anywhere -> menu or toolbar

## Tips

- Home screen remembers expanded/collapsed.
- Missing tab? Check mode and feature settings:
  - User mode Reader hides bookmarks/highlights/notes/AI; Standard hides AI. Settings → App User Mode.
  - Feature settings; Settings.
