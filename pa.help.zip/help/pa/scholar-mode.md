---
title: Scholar Mode
level: advanced
categories: [layout, read, study]
summary: Theodia ਦਾ ਸਭ ਤੋਂ ਗਹਿਰਾ study mode, ਜੋ commentaries, lexicons, cross-references, AI ਟੂਲ, ਅਤੇ Launcher Menu ਅਨਲਾਕ ਕਰਦਾ ਹੈ.
---

# Scholar Mode

> **ਮੋਡ:** Scholar mode ਸਿਰਫ਼ ਤਾਂ ਉਪਲਬਧ ਹੈ ਜਦੋਂ ਤੁਹਾਡਾ user mode **Scholar** ਸੈਟ ਹੋਵੇ. ਮੋਡ ਬਦਲਣ ਲਈ **Settings** → **App User Mode** 'ਤੇ ਜਾਓ.

Scholar mode Theodia ਦੇ ਸਾਰੇ study tools ਅਨਲਾਕ ਕਰਦਾ ਹੈ. ਇਹ Study Mode 'ਤੇ ਬਣਿਆ ਹੈ, ਇਸ ਲਈ ਤੁਹਾਨੂੰ ਫਿਰ ਵੀ verse menu, parallel Bibles, bookmarks, highlights, ਅਤੇ notes ਮਿਲਦੇ ਹਨ — ਨਾਲ ਹੀ ਹੇਠਾਂ ਦਿੱਤੇ ਉੱਨਤ ਟੂਲ.

## Scholar mode ਕਿਵੇਂ ਖੋਲ੍ਹੀਏ

Scholar mode ਇੱਕ ਵੱਖਰੀ ਸਕਰੀਨ ਨਹੀਂ ਹੈ. ਇਹ ਮੌਜੂਦਾ reader ਅਤੇ ਨੈਵੀਗੇਸ਼ਨ ਵਿੱਚ ਆਉਣ ਵਾਲੇ ਟੂਲਾਂ ਦਾ ਇੱਕ ਸੈੱਟ ਹੈ ਜਦੋਂ ਤੁਹਾਡਾ user mode Scholar ਸੈਟ ਹੋਵੇ.

1. **ਸੈਟਿੰਗਜ਼** ਖੋਲ੍ਹੋ.
2. **App User Mode** 'ਤੇ ਟੈਪ ਕਰੋ.
3. **Scholar** ਚੁਣੋ.

ਬਦਲਾਅ ਤੁਰੰਤ ਲਾਗੂ ਹੁੰਦਾ ਹੈ. ਜੋ menus ਅਤੇ ਬਟਨ ਛੁਪੇ ਹੋਏ ਸਨ, ਉਹ ਹੁਣ ਦਿਖਾਈ ਦਿੰਦੇ ਹਨ.

## ਵਾਧੂ reader ਟੂਲ

ਜਦੋਂ ਤੁਸੀਂ [Study Mode](theodia://help/study-mode) ਵਿੱਚ ਕੋਈ ਅਧਿਆਇ ਖੋਲ੍ਹਦੇ ਹੋ, Scholar mode verse menu ਵਿੱਚ ਇਹ ਟੂਲ ਜੋੜਦਾ ਹੈ:

- **AI Commentary** (◈) — AI ਸਹਾਇਕ ਨੂੰ ਇਸ ਵਚਨ ਲਈ ਇੱਕ study note ਲਿਖਣ ਲਈ ਕਹੋ. (ਸਾਰੇ ਖੇਤਰਾਂ ਵਿੱਚ ਉਪਲਬਧ ਨਹੀਂ.)
- **Word Info** (?) — ਵਚਨ ਪਿੱਛੇ ਅਸਲ ਹਿਬਰੂ ਜਾਂ ਗ੍ਰੀਕ ਸ਼ਬਦ ਲਈ ਇੱਕ lexicon entry ਖੋਲ੍ਹੋ. [Commentaries and Lexicons](theodia://help/commentaries-and-lexicons) ਗਾਈਡ ਦੇਖੋ.
- **Dictionary** (📖) — ਤੁਹਾਡੇ ਸਥਾਪਿਤ dictionary resources ਵਿੱਚ ਆਮ Bible words ਲੱਭੋ. [Bible Dictionary](theodia://help/dictionary) ਗਾਈਡ ਦੇਖੋ.

ਇਨ੍ਹਾਂ ਟੂਲਾਂ ਲਈ resources ਸਥਾਪਿਤ ਹੋਣੇ ਜ਼ਰੂਰੀ ਹਨ (commentaries, lexicons, dictionary ਫਾਈਲਾਂ). ਜੇ ਕੋਈ ਟੂਲ ਗ੍ਰੇ ਆਊਟ ਹੋਵੇ ਜਾਂ "not found" ਦਿਖਾਏ, ਤਾਂ **Settings** → **Manage Resources** ਖੋਲ੍ਹੋ ਅਤੇ ਜਿਸ resource ਦੀ ਲੋੜ ਹੋਵੇ ਉਹ ਜੋੜੋ.

## ਵਾਧੂ ਨੈਵੀਗੇਸ਼ਨ

### ਵਾਧੂ ਟੂਲਬਾਰ ਟੈਬ

ਬੌਟਮ ਟੂਲਬਾਰ ਵਿੱਚ ਇੱਕ ਵਾਧੂ ਟੈਬ ਜੁੜਦਾ ਹੈ:

- 💻 **AI** — AI ਸਹਾਇਕ ਖੋਲ੍ਹਦਾ ਹੈ (ਸਿਰਫ਼ ਜੇ ਤੁਸੀਂ settings ਵਿੱਚ AI ਚਾਲੂ ਕੀਤਾ ਹੈ). ਇਹ ਟੈਬ Notes ਦੇ ਸੱਜੇ ਪਾਸੇ ਹੁੰਦੀ ਹੈ.

### ਵਾਧੂ main menu ਆਈਟਮਜ਼

main menu ਵਿੱਚ ਉਹੀ conditions 'ਤੇ **AI Assistant** entry ਸ਼ਾਮਲ ਹੁੰਦਾ ਹੈ.

## Launcher Menu

Scholar mode **Launcher Menu** ਚਾਲੂ ਕਰਦਾ ਹੈ, ਜੋ ਤੁਹਾਡੀ ਮੌਜੂਦਾ ਸਕਰੀਨ ਛੱਡੇ ਬਿਨਾਂ recent verses 'ਤੇ ਜੰਪ ਕਰਨ, commands ਚਲਾਉਣ, ਅਤੇ Bible layouts ਸਵਿਚ ਕਰਨ ਦਾ ਤੇਜ਼ ਤਰੀਕਾ ਹੈ. ਇਸਨੂੰ ਕਿਵੇਂ ਵਰਤਣਾ ਹੈ ਲਈ [Launcher Menu](theodia://help/launcher-menu) ਗਾਈਡ ਦੇਖੋ.

## Scholar mode ਕਦੋਂ ਵਰਤੀਏ

- ਜਦੋਂ ਤੁਸੀਂ ਪੜ੍ਹਦੇ ਸਮੇਂ AI ਸਹਾਇਕ, commentaries, ਜਾਂ original-language lookups ਚਾਹੁੰਦੇ ਹੋ.
- ਜਦੋਂ ਤੁਸੀਂ ਤੇਜ਼ verse navigation ਅਤੇ AI chat ਲਈ Launcher Menu ਚਾਹੁੰਦੇ ਹੋ.
- ਜਦੋਂ ਤੁਸੀਂ ਕਿਸੇ ਪੈਸੇਜ ਦਾ ਗਹਿਰਾਈ ਨਾਲ ਅਧਿਐਨ ਕਰ ਰਹੇ ਹੋ ਅਤੇ ਹਰ tool ਇੱਕ ਟੈਪ ਦੂਰ ਚਾਹੁੰਦੇ ਹੋ.

## ਹਲਕੇ ਮੋਡ 'ਤੇ ਸਵਿਚ ਕਰਨਾ

ਜੇ ਤੁਸੀਂ ਬਿਨਾਂ ਉੱਨਤ ਟੂਲਾਂ ਵਾਲਾ ਸਾਦਾ reader ਚਾਹੁੰਦੇ ਹੋ, ਤਾਂ **Settings** → **App User Mode** ਵਿੱਚ **Standard** mode 'ਤੇ ਸਵਿਚ ਕਰੋ. Standard mode bookmarks, highlights, notes, ਅਤੇ Study Mode ਰੱਖਦਾ ਹੈ ਪਰ AI, commentaries, lexicons, ਅਤੇ Launcher Menu ਨੂੰ ਛੁਪਾਉਂਦਾ ਹੈ.

ਜੇ ਤੁਸੀਂ ਸਭ ਤੋਂ ਸਾਫ਼ ਪੜ੍ਹਾਈ ਅਨੁਭਵ ਚਾਹੁੰਦੇ ਹੋ, ਤਾਂ [Focus Mode](theodia://help/focus-mode) ਵਿੱਚ ਕੋਈ ਅਧਿਆਇ ਖੋਲ੍ਹੋ.

ਮੋਡ ਬਦਲਣ 'ਤੇ ਤੁਹਾਡੇ bookmarks, highlights, ਅਤੇ notes ਕਦੇ ਨਹੀਂ ਮਿਟਦੇ; ਉਹ ਸਿਰਫ਼ ਛੁਪੇ ਰਹਿੰਦੇ ਹਨ ਜਦ ਤੱਕ ਤੁਸੀਂ ਕਿਸੇ ਅਜਿਹੇ mode 'ਤੇ ਵਾਪਸ ਨਾ ਆਓ ਜੋ ਉਨ੍ਹਾਂ ਦਾ ਸਮਰਥਨ ਕਰਦਾ ਹੋਵੇ.

## Help ਅਤੇ ਪ੍ਰਸ਼ਨ

ਜੇ ਕੋਈ ਟੂਲ ਗਾਇਬ ਹੈ ਜਾਂ error ਦਿਖਾਉਂਦਾ ਹੈ, ਤਾਂ [Common Problems](theodia://help/common-problems) ਗਾਈਡ ਦੇਖੋ. ਜੇ ਤੁਸੀਂ Theodia ਵਿੱਚ ਨਵੇਂ ਹੋ, ਤਾਂ [Reading Your First Chapter](theodia://help/first-read) ਗਾਈਡ ਤੁਹਾਨੂੰ ਕਦਮ-ਦਰ-ਕਦਮ ਮੂਲ ਗੱਲਾਂ ਸਿਖਾਉਂਦੀ ਹੈ.
