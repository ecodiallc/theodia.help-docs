---
title: Study Mode
level: everyday
categories: [layout, read]
summary: Theodia ਵਿੱਚ complete Bible reader, commentary, cross-references, lexicon, ਅਤੇ notes ਵਰਗੇ study tools ਨਾਲ.
---

# Study Mode

> **Mode:** Study Mode **ਸਟੈਂਡਰਡ** ਅਤੇ **ਸਕਾਲਰ** ਮੋਡ ਵਿੱਚ ਉਪਲੱਬਧ ਹੈ. Reader mode chapters ਨੂੰ ਫੋਕਸ ਮੋਡ ਵਿੱਚ ਖੋਲ੍ਹਦਾ ਹੈ. ਮੋਡ ਬਦਲਣ ਲਈ **Settings** → **App User Mode**.

Study Mode Theodia ਦਾ main Bible reader ਹੈ. ਇਸ ਵਿੱਚ ਸਾਰੇ study tools built-in ਹਨ: commentary, cross-references, word lookups, parallel translations, notes, ਅਤੇ ਹੋਰ.

Focus Mode ਇੱਕ simpler reader ਹੈ ਜਿਸ ਵਿੱਚ study tools ਨਹੀਂ. ਜੇ ਤੁਸੀਂ ਸਿਰਫ਼ clean text ਚਾਹੁੰਦੇ ਹੋ, [Focus Mode](theodia://help/focus-mode) guide ਵੇਖੋ. ਇਹ guide Study Mode ਲਈ ਹੈ.

## Study Mode ਕਿਵੇਂ ਖੋਲ੍ਹਣਾ ਹੈ

chapter Study Mode ਵਿੱਚ ਖੋਲ੍ਹਣ ਦੇ ਕੁਝ ਤਰੀਕੇ:

- ਸਕ੍ਰੀਨ ਦੇ ਹੇਠਾਂ **Bible** tab 'ਤੇ ਟੈਪ ਕਰੋ. ਇੱਕ translation, ਇੱਕ book, ਅਤੇ ਇੱਕ chapter ਚੁਣੋ.
- **Search** results ਵਿੱਚ ਇੱਕ verse 'ਤੇ ਟੈਪ ਕਰੋ.
- **Bookmarks** tab ਤੋਂ ਇੱਕ bookmark 'ਤੇ ਟੈਪ ਕਰੋ.
- Focus Mode ਤੋਂ, ਸਕ੍ਰੀਨ ਦੇ ਉੱਪਰ 📖 ਬਟਨ 'ਤੇ ਟੈਪ ਕਰੋ Studies Mode switch ਕਰਨ ਲਈ.

## chapter ਪੜ੍ਹਨਾ

chapter verses ਦੀ ਕ੍ਰਮਵਾਰ ਸੂਚੀ ਨਾਲ ਖੁਲ੍ਹਦਾ ਹੈ. ਸਕ੍ਰੀਨ ਊਪਰ ਸਭ common actions ਦੇ ਬਟਨ ਹਨ. ਸਕ੍ਰੀਨ ਨਿਚੇ ਇੱਕ status bar ਹੁੰਦਾ ਹੈ.

- next chapter ਲਈ **swipe left**.
- previous chapter ਲਈ **swipe right**.
- study tools ਵਾਲਾ verse menu ਖੋਲ੍ਹਣ ਲਈ **verse 'ਤੇ ਟੈਪ** ਕਰੋ.
- verse ਵਿਚ ਏਕ Strong's number 'ਤੇ ਟੈਪ ਕਰੋ (ਜਿਵੇਂ G1234 ਜਾਂ H1234) ਇਸ word ਲਈ quick lexicon lookup ਖੋਲ੍ਹਣ ਲਈ.

ਜਬ ਤੁਹਾਡਾ parallel translation ਚਾਲੂ ਹੈ, ਤਾ second copy ਚੈਪਟਰ main ਦੇ ਨিচੇ ਉਸ translation ਵਿਚ ਦਿਖਦਾ ਹੈ ਜੋ ਤੁਸੀਂ ਚੁਨਾ. ਨਿਚੇ **Reading two translations at once** ਵੇਖੋ.

## verse menu

verse 'ਤੇ ਟੈਪ ਕਰਨ 'ਤੇ ਇੱਕ menu ਖੁਲ੍ਹਦਾ ਹੈ ਜਿਸਦਾ title "Book Chapter:Verse" ਹੈ. ਤੁਸੀਂ ਕੌਣਸੇ tools ਦਿਖਦੇ ਹਨ ਯਹ ਤੁਹਾਡੇ user mode 'ਤੇ depend ਕਰਦਾ ਹੈ.

### ਸਟੈਂਡਰਡ ਅਤੇ ਸਕਾਲਰ ਮੋਡ ਦੇ tools

- **Bookmark** (★) — verse save ਕਰੋ ਤਾ ਕਿ ਤੁਸੀਂ ਇਸਨੂੰ ਦੁਬਾਰਾ ਲੱਭ ਸੋ. remove ਕਰਨ ਲਈ ਦੁਬਾਰਾ ਟੈਪ. ਪਹਲੀ ਟੈਪ add ਕਰਦੀ ਹੈ. [Bookmarking Verses](theodia://help/bookmarks) ਵੇਖੋ.
- **Highlight** (□) — verse ਊਚਾ ਕਰੋ ਤਾਂ ਕਿ ਯਹ ਖਡਾ ਦਿਖੇ. color picker ਖੋਲ੍ਹਣ ਲਈ ਟੈਪ. ਉਸੀ color 'ਤੇ ਦੁਬਾਰਾ ਟੈਪ ਕਰਕੇ remove. [Highlighting Verses](theodia://help/highlights) ਵੇਖੋ.
- **Speak** (🔊) — verse ਤੁਹਾਡੇ device's text-to-speech voice ਨਾਲ ਬੁਲੰਦ ਆਵਾਜ਼ ਵਿਚ ਪਡ੍ਹੋ. interlinear Bibles ਲਈ ਨਹੀਂ ਦਿਖਦਾ. [Reading Out Loud](theodia://help/tts) ਵੇਖੋ.
- **Copy** (⎘) — verse text clipboard 'ਤੇ ਪਾਓ ਤਾਂ ਕਿ ਤੁਸੀਂ ਇਸਨੂੰ ਕਿਤੇ ਵੀ paste ਕਰ ਸੋ.
- **Compare** (⇄) — ਇੱਕ panel ਖੋਲ੍ਹਦਾ ਹੈ ਜੋ ਇੱਕੋ verse ਤੁਹਾਡੇ ਸਾਰੇ installed translations ਵਿਚ ਦਿਖਾਉਂਦਾ ਹੈ. [Comparing Translations](theodia://help/compare-translations) ਵੇਖੋ.
- **Cross-References** (↗) — cross-reference database ਤੋਂ related verses ਦੀ ਸੂਚੀ ਖੋਲ੍ਹਦਾ ਹੈ. [Cross-References](theodia://help/cross-references) ਵੇਖੋ.
- **Add/Edit Bible Note** (✎) — verse ਨਾਲ ਤੁਹਾਡਾ private note ਲਿਖੋ. [Writing Notes](theodia://help/notes) ਵੇਖੋ.

### ਸਕਾਲਰ ਮੋਡ ਵਿੱਚ ਹੀ tools

- **AI Commentary** (◈) — AI assistant ਨੂੰ verse ਲਈ study note ਲਿਖਣ ਲਈ ਕਹੋ. (ਸਾਰੇ regions ਵਿੱਚ ਨਹੀਂ.)
- **Word Info** (?) — verse ਦੇ ਤਹਿਤ original Hebrew ਜਾਂ Greek word ਲਈ lexicon entry ਖੋਲ੍ਹੋ. [Commentaries and Lexicons](theodia://help/commentaries-and-lexicons) ਵੇਖੋ.
- **Dictionary** (📖) — installed dictionary resources ਵਿਚ general Bible words ਖੋਜੋ. [Bible Dictionary](theodia://help/dictionary) ਵੇਖੋ.

ਕੁਝ tools ਨੂੰ extra resources installed ਹੋਣ ਦੀ ਲੋੜ ਹੈ. ਜਬ tool greyed out ਹੋਵੇ ਜਾਂ "not found" ਦਿਖਾਵੇ, **Settings** → **Manage Resources** ਖੋਲ੍ਹੋ ਅਤੇ required resource add ਕਰੋ.

## ਸਕ੍ਰੀਨ ਦੇ ਉੱਪਰ ਬਟਨ

chapter text ਦੇ ਊਪਰ ਇੱਕ row icons ਹੈ. ਯਹ quick actions ਹਨ:

- **Bible version** — translation name (ਜਿਵੇਂ "KJV") 'ਤੇ ਟੈਪ ਕਰਕੇ ਦੂਸਰਾ translation ਚੁਣੋ.
- **Book** — book name 'ਤੇ ਟੈਪ ਕਰਕੇ ਦੂਸਰਾ book jump ਕਰੋ.
- **Chapter** — chapter number 'ਤੇ ਟੈਪ ਕਰਕੇ ਦੂਸਰਾ chapter jump ਕਰੋ.
- **Open in AI** (🤖) — current chapter ਨੂੰ ਤੁਹਾਡੇ question ਨਾਲ AI assistant ਨੂੰ ਭੇਜோ. (ਸਕਾਲਰ ਮੋਡ ਹੀ.)
- **Focus Mode** (📖) — clean reading ਲਈ Focus Mode switch ਕਰੋ.
- **Parallel Bibles** (🔵 / ⚪) — parallel translations ਚਾਲੂ/ ਕਰਨ ਲਈ ਟੈਪ. ਜਦ on ਹੈ, ਇੱਕੋ chapter ਤੁਹਾਡੇ chosen parallel translations ਵਿਚ main text ਨਿਚੇ ਦਿਖਦਾ ਹੈ. off ਹੈ ਤਾ ਸਿਰਫ਼ main translation. ਨਿਚੇ **Reading multiple translations at once** ਵੇਖੋ.
- **Listen** — ਪੂਰਾ chapter ਬੁਲੰਦ ਆਵਾਜ਼ ਵਿਚ ਪਡ੍ਹੋ. [Reading Out Loud](theodia://help/tts) ਵੇਖੋ.
- **More** — extra chapter actions ਖੋਲ੍ਹਦਾ ਹੈ (chapter Bible note, chapter commentary, share, ਔਰ ਬੀ).

## ਇੱਕ ਸਾਥ ਕਈ translations ਪੜ੍ਹਨਾ

ਤੁਸੀਂ ਅਪਨੇ main ਦੇ ਸਾਥ up to four extra translations ਦਿਖਾ ਸਕਤੇ ਹੋ. ਇਸਨੂੰ **parallel view** ਕਹਿੰਦੇ ਹਨ.

1. **Settings** ਖੋਲ੍ਹੋ.
2. **Parallel Bible** ਚਾਲੂ ਕਰੋ.
3. **Add Parallel Bible** 'ਤੇ ਟੈਪ ਕਰkę ਇੱਕ translation ਚੁਣੋ.
4. ਔਰ add ਕਰਨ ਲਈ repeat. up to four parallel translations ਹੋ ਸਕਤੇ ਹਨ.

parallel view on ਹੈ ਤਾ ਹਰ verse main translation ਪਹਲੇ ਦਿਖਦਾ ਹੈ, ਫਿਰ ਹਰ parallel translation ਵਿਚ ਇੱਕੋ verse. ਇਸ ਤਰਹ ਤੁਸੀਂ ਤੁਲਨਾ easily ਕਰ ਸਕਤੇ ਹੋ ਬਿਨਾ chapter ਛੋਡੇ.

ਤੁਸੀਂ ਅਪਨਾ current parallel setup **preset** ਦੇ ਰੂਪ ਵਿਚ save ਕਰ ਸਕਤੇ ਹੋ. selected translations ਦੇ ਨਾਲ save ਬਟਨ 'ਤੇ ਟੈਪ ਕਰੋ, ਨਾਮ ਦਿਓ, ਅਤੇ ਯਹ quick-switch option ਬਣ ਜਾਏਗਾ. ਬਾਦ ਮੇ ਕੋਈ ਵੀ preset ਟੈਪ ਕਰਕੇ ਤੁਰੰਤ load ਕਰੋ. preset ਦੇ long-press ਨਾਲ delete ਕਰੋ.

ਤੁਸੀਂ **Compare** (⇄) tool ਨਾਲ ਵੀ ਇੱਕ verse at a time compare ਕਰ ਸਕਤੇ ਹੋ verse menu ਵਿਚ. ਯਹ panel ਤੁਹਾਡੇ ਸਾਰੇ installed translations ਵਿਚ verse ਦਿਖਾਉਂਦਾ ਹੈ.

## Subheadings

ਕੁਝ translations ਵਿਚ section headings ਸ਼ਾਮਿਲ ਹਨ (ਜਿਵੇਂ "The Sermon on the Mount"). ਜੇ ਤੁਹਾਡਾ translation ਉਨ੍ਹਾਂ ਦਾ support ਕਰਦਾ ਹੈ, ਤਾ **Settings** ਵਿਚ **Show Subheadings** ਨਾਲ ਊਚਾ/ਬਦ ਕਰ ਸਕਦੇ ਹੋ. Subheadings verses ਦੇ ਿਚ small grey titles ਦੇ ਰੂਪ ਵਿਚ ਦਿਖਦੇ ਹਨ.

## chapter note

chapter note ਇੱਕ single note ਹੈ ਜੋ whole chapter ਨਾਲ attach ਹੁੰਦਾ ਹੈ, ਇੱਕ single verse ਨਾਲ ਨਹੀਂ. ਯਹ ਇੱਕ ਬੜਾ thought chapter ਲਈ useful ਹੈ.

chapter note ਖੋਲ੍ਹਣ ਲਈ:

1. ਸਕ੍ਰੀਨ ਦੇ ਉੱਪਰ **More** ਬਟਨ 'ਤੇ ਟੈਪ ਕਰੋ.
2. **Chapter Note** 'ਤੇ ਟੈਪ ਕਰੋ.
3. ਆਪਨਾ note ਲਿਖੋ. **Save** 'ਤੇ ਟੈਪ ਕਰੋ.

chapter note chapter ਨਾਲ save ਹੋ ਜਾਦਾ ਹੈ. ਯਹ ਹਰ ਬਾਰ ਇਸ chapter ਖੋਲ੍ਹਣ 'ਤੇ ਦਿਖਦਾ ਹੈ.

## Search highlights

ਜਬ ਤੁਸੀਂ search results ਤੋਂ chapter 'ਤੇ ਆਏ ਹੋ, your search words ਆਇਤ text ਵਿਚ yellow highlight ਹੋ ਜਾਦੇ ਹਨ. ਯਹ ਦਿਖਾਉਂਦਾ ਹੈ ਕਿ verse ਕਿਉਂ match ਕੀਤਾ.

ਤੁਸੀਂ chapter ਜੋ ਤੁਸੀਂ ਪਡ੍ਹ ਰਹੇ ਹੋ ਉਸ 'ਤੇ ਵੀ search re-run ਕਰ ਸਕਤੇ ਹੋ. **Search** tab ਖੋਲ੍ਹੋ ਔਰ ਇੱਕ word ਦਾਖਲ ਕਰੋ. results ਤੁহਾਨੂੰ ਤੁਰੰਤ chapter ਵਿਚ enter ਕਰਨ ਦਿਦੇ ਹਨ matches highlighted ਨਾਲ.

Interlinear Bibles (MIB — Marvel Interlinear Bible — ਅਤੇ OHGB) ਹਮੇਸ਼ਾ Study Mode ਵਿਚ ਖੁਲ੍ਹਦੇ ਹਨ ਕਿਉਂਕਿ ਉਨ੍ਹਾਂ ਨੂੰ word-level layout ਦੀ ਲੋੜ ਹੈ.

## ਇੱਕ chapter ਲਈ Focus Mode switch ਕਰਨਾ

Study Mode ਵਿਚ ਕਿਸੇ chapter ਤੋਂ, ਉੱਪਰ 📖 ਬਟਨ 'ਤੇ ਟੈਪ ਕਰੋ. ਇੱਕੋ chapter Focus Mode ਵਿਚ ਉਨ੍ਹੀ menus hidden ਨਾਲ ਖੁਲ੍ਹਦਾ ਹੈ. bottom bar ਵਿਚ 📖 ਬਟਨ 'ਤੇ ਟੈਪ ਕਰਕੇ Study Mode ਵਾਪਸ switch ਕਰੋ.

## ਕਦੋਂ Study Mode ਵਰਤਣਾ ਹੈ

Study Mode right choice ਹੈ ਜਬ ਤੁਸੀਂ:

- **ਪਡ੍ਹੋ ਔਰ study ਏਕ .** ਸਾਰੇ tools ਇੱਕ tap ਦੂਰ.
- **ਅਜਾਤ word lookup.** lexicon entry ਲਈ verse ਵਿਚ Strong's number 'ਤੇ tap.
- **translations compare.** verse menu's Compare tool ਵਰਤੋ ਜਾ parallel view ਚਾਲੂ ਕਰੋ.
- **connections ਦੇਖੋ.** Cross-References ਵਰਤੋ.
- **notes ਲਿਖੋ.** verse menu quick "Add note" option.

long, distraction-free reading ਲਈ, Focus Mode switch ਕਰੋ.

## Focus Mode switch ਕਰਨਾ

Study Mode ਵਿਚ ਕਿਸੇ chapter ਤੋਂ, ਉੱ 📖 ਬਟਨ 'ਤੇ ਟੈਪ ਕਰੋ. ਇੱਕੋ chapter [Focus Mode](theodia://help/focus-mode) ਵਿਚ menus ਔਰ study tools hidden ਨਾਲ ਖੁਲ੍ਹਦਾ ਹੈ. bottom bar ਵਿਚ 📖 ਬਟਨ 'ਤੇ ਟੈਪ ਕਰਕੇ Study Mode ਵਾਪਸ switch ਕਰੋ. ਵਿਸਤਾਰ ਲਈ [Focus Mode](theodia://help/focus-mode) ਵੇਖੋ.

## ਮਦਦ ਅਤੇ ਪ੍ਰਸ਼ਨ

tool ਮਿਸਿੰਗ ਜਾਂ error ਦਿਖਾਵੇ ਤਾ [Common Problems](theodia://help/common-problems) guide ਵੇਖੋ. ਜੇ ਤੁਸੀਂ Theodia ਨੌਂ ਹੋ, [Reading Your First Chapter](theodia://help/first-read) guide ਬੇਸਿਕ step by step ਸਮਝਾਉਂਦਾ ਹੈ.