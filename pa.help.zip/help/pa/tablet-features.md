---
title: Tablet Features
level: everyday
categories: [layout, tablet]
summary: ਜਿਵੇਂ Theodia ਦਾ layout tablets ਅਤੇ ਬੇ screens ਲਈ adapt ਹੁੰਦਾ ਹੈ — split views, side panels, ਔਰ two-pane reading modes ਨਾਲ.
---

# Tablet Features

Theodia ਬਡੇ screens 'ਤੇ tablets ਲਈ designed ਹੈ. tablet (жਾ ~700 pixels ਤੋਂ ਜਯਾਦਾ wide device) 'ਤੇ, ਐਪ ਬਹੁਤ ਸਾਰੇ places ਵਿੱਚ automatically two-column layout switch ਕਰਦਾ ਹੈ.

> **Modeterminant:** ਯਹ guide ਵਿਚ described ਫੀਚਰ ਸਿਰਫ਼ ਤਦ ਦਿਖਦੇ ਹਨ ਜਬ ਤੁਹਾਡਾ current user mode ਉਨ੍ਹਾਂ ਨੂੰ support ਕਰਦਾ ਹੈ. ਉਦਾਹਰਣ ਲਈ, commentary side panels ਅਤੇ AI chat ਸਿਰਫ਼ ਸਕਾਲਰ mode ਵਿਚ ਹਨ. Bookmarks, highlights, ਅਤੇ notes split views ਨੂੰ ਸਟੈਡਰਡ ਜਾਂ ਸਕਾਲਰ mode ਚਾਹੀਦਾ ਹੈ. Focus Mode ਸਿਰਫ਼ clean, single-column reading ਦਿਖਾਉਂਦਾ ਹੈ. modes ਬਦਲਣ ਲਈ **Settings** → **App User Mode**.

## Reader verse menu

verse number 'ਤੇ tap ਕਰਨ (жਾਂ verse text long-press ਕਰਨ) 'ਤੇ, **verse menu** ਇੱਕ **centered card** ਦੇ ਰੂਪ ਵਿਚ dark backdrop ਊਪਰ ਦਿਖਦਾ ਹੈ.

- **Copy** ਅਤੇ **Share** ਬਟਨ ਹੇਸ਼ਾ menu ਦੇ top 'ਤੇ visible ਹਨ.
- **Bookmarks** ਅਤੇ **Highlights**ਅਪਨਾ current state ਨਾਲ ਦਿਖਦੇ ਹਨ.
- **Commentary**, **Dictionary**, ਅਤੇ **Compare** menu ਤੋਂ ਖੁਲ੍ਹਦੇ ਹਨ. tablet 'ਤੇ ਯਹ tools selected ਹੋਣ 'ਤੇ side panel ਜਾਂ wide card ਵਿਚ ਦਿਖ ਸਕਤੇ ਹਨ.
- menu dismiss ਕਰਨ ਲਈ backdrop ਜਾ close arrow 'ਤੇ tap ਕਰੋ.

## Verse Commentary panel

**Commentary** tool tablet 'ਤੇ **dedicated side panel** ਖੋਲ੍ਹਦਾ ਹੈ:

- commentary text Bible text ਦੇ ਬਿਚ ਦਿਖਦਾ ਹੈ.
- ਤੁਸੀਂ commentary Biology ਤੋਂ independent scroll ਕਰ ਸਕਤੇ ਹੋ.
- close ਕਰਨ ਲਈ **X** ਟੈ ਜਾ swipe away.
- panel ਦੇ top 'ਤੇ **book icon** commentary source ਬਦਲਣ ਦਿੰਦਾ ਹੈ.
- **chapter icon** chapter-level commentary ਦਿਖਾਉਂਦਾ ਹੈ.

phone 'ਤੇ, commentary full-screen modal ਵਿਚ ਖੁਲ੍ਹਦਾ ਹੈ.

## Chapter Commentary

**Chapter Commentary** ਨੂੰ top 'ਤੇ **More** ਬਟਨ ਤੋਂ access ਕਿਯਾ ਜਾਤਾ ਹੈ, verse menu ਤੋਂ ਨਹੀਂ. tablet 'ਤੇ ਯਹ Verse Commentary ਵਾਗ side panel ਖੁਲ੍ਹਦਾ ਹੈ, ਤਾ ਕਿ ਤੁਸੀਂ commentary ਅਤੇ Bible text ਇਕੱਠੇ ਪੜ੍ਹ ਸਕੋ.

## Compare tab

verse menu ਵਿੱਚ **Compare** tab tablet 'ਤੇ **side panel** ਵਿਚ ਖੁਲ੍ਹਦਾ ਹੈ. ਯਹ selected verse ਨੂੰ ਤੁਹਾਡੇ enable ਕੀਤੇ ਸਾਰੇ parallel versions ਵਿਚ ਦਿਖਾਉਂਦਾ ਹੈ. ਤੁਸੀਂ ਕੋਈ ਵੀ version 'ਤੇ tap ਕਰਕੇ reader ਵਿਚ ਉਸ passage 'ਤੇ jump ਕਰ ਸਕਤੇ ਹੋ.

## Dictionary / Strong's popup

verse menu → Dictionary tablet 'ਤੇ ਇੱਕ wide card ਵਿਚ ਖੁਲ੍ਹਦਾ ਹੈ. ਯਹ Greek жਾ Hebrew word, ਇਸਦਾ transliteration, definition, ਅਤੇ Strong's number ਦਿਖਾਉਂਦਾ ਹੈ. **Concordance** ਬਟਨ 'ਤੇ tap ਕਰਕੇ ਉਸ word ਦੇ ਸਾਰੇ occurrences ਬਾਈਬਲ ਵਿਚ ਦੇਖੋ.

## Tap a word to open its Lexicon

tablet 'ਤੇ **Word Info** side panel ਵਿਚ, Strong's number ਵਾਲਾ ਹਰ word card tappable ਹੁੰਦਾ ਹੈ. card 'ਤੇ tap ਕਰਕੇ **Lexicon** panel ਸੀਧਾ ਖੋਲ੍ਹੋ. Lexicon panel Word Info panel replace ਕਰਦਾ ਹੈ ਤਾ ਕਿ ਤੁਸੀਂ reader ਛੋਡੇ ਬਿਨਾ study ਜਾਰੀ ਰੱਖ ਸਕੋ.

phone 'ਤੇ Word Info cards tappable ਨਹੀਂ ਹਨ ਕਿਉਂਕਿ screen two panels ਲਈ ਬਹੁਤ small ਹੈ.

## Parallel Bibles side by side

Settings ਵਿਚ, **Parallel Bibles** 'ਤੇ tap ਕਰੋ ਅਤੇ up to three versions ਚੁਣੋ. tablet 'ਤੇ, versions **vertical panes** ਦੇ ਰੂਪ ਵਿਚ side by side ਦਿਖਦੇ ਹਨ:

- ਹਰ pane independently scroll ਕਰਦਾ ਹੈ.
- verse number 'ਤੇ tap ਕਰਕੇ side panel ਵਿਚ tools ਖੋਲ੍ਹੋ.
- **Compare** tab ਸਾਰੇ selected verses ਇੱਕ ਜਗਹ ਦਿਖਾਉਂਦਾ ਹੈ.
- ਕਿਸੀ pane 'ਤੇ **X** ਟੈ ਕਰਕੇ close ਕਰੋ ਅਤੇ single-column view 'ਤੇ ਵਾਪਸ ਜਾਓ.
- top icon bar ਵਿਚ **Parallel Bibles** icon (🔵 / ⚪) 'ਤੇ ਟੈ ਕਰਕੇ parallel view toggle ਕਰੋ, Settings ਖੋল੍ਹੇ ਬਿਨਾ.

phone 'ਤੇ parallel versions ਇੱਕ ਦੂਜੇ ਦੇ ਨਿਚੇ (vertically) ਦਿਖਦੇ ਹਨ side by side ਨਹੀਂ. same toggle icon phones 'ਤੇ ਭੀ ਾਮ ਕਰਦਾ ਹੈ.

## Bookmarks and Highlights split view

tablet 'ਤੇ, **Bookmarks** ਅਤੇ **Highlights** tabs master-detail layout ਵਰਤਦੇ ਹਨ:

- **Left side** — bookmarks жਾ highlights ਦੀ ਸੂਚੀ.
- **Right side** — ਇੱਕ item 'ਤੇ tap ਕਰਾਨ ਤੋਂ ਬਾਦ preview pane ਵਿਚ verse жਾ passage text ਦਿਖਦਾ ਹੈ.

ਤੁਸੀਂ saved items skim ਅਤੇ preview ਕਰ ਸਕਤੇ ਹੋ tab ਛੋਡੇ ਬਿਨਾ. phone 'ਤੇ, item 'ਤੇ tap ਕਰਾਨ ਤੋਂ navigation reader screen 'ਤੇ ਹੋ ਜਾਤਾ ਹੈ.

## Notes split view

tablet 'ਤੇ **Notes** tab left 'ਤੇ notes list ਅਤੇ right 'ਤੇ selected note ਦਿਖਾਉਂਦਾ ਹੈ. note 'ਤੇ tap ਕਰਨ 'ਤੇ side panel ਵਿਚ ਖੁਲ੍ਹਦਾ ਹੈ ਤਾ ਕਿ ਤੁਸੀਂ ਈ notes back-to-back skim ਕਰ ਸਕੋ list ਛੋਡੇ ਬਿਨਾ. note create жਾ edit ਕਰਨਾ ਭੀ side panel ਵਿਚ ਹੋਂਦਾ ਹੈ.

## Search split view

tablet 'ਤੇ, **Search** tab search form left 'ਤੇ ਅਤੇ search ਚਲਾਉਣ ਤੋਂ ਬਾਦ results right 'ਤੇ ਦਿਖਾਉਂਦਾ ਹੈ. ਤੁਸੀਂ query refine ਕਰ ਸਕਤੇ ਹੋ ਅਤੇ results watch ਕਰ ਸਕਤੇ ਹੋ screen ਬਦਲੇ ਬਿਨਾ. phone 'ਤੇ search results separate screen 'ਤੇ ਖੁਲ੍ਹਦੇ ਹਨ.

## Settings category sidebar

tablet 'ਤੇ, **Settings** screen left 'ਤੇ category list ਦਿਖਾਉਂਦਾ ਹੈ (AI, Appearance, Backup, Bibles, ਆਦਿ). category 'ਤੇ tap ਕਰਕੇ right 'ਤੇ ਉਸਕੀ settings jump ਕਰੋ. ਸਿਰਫ਼ selected category expanded ਹੁੰਦਾ ਹੈ, ਤਾ ਪੂਰਾ settings list scroll ਕਰਨ ਦੀ ਲੋੜ ਨਹੀਂ.

## Bible navigation on tablets

**Bible List**, **Bible Books**, ਅਤੇ **Bible Chapters** screens tablets 'ਤੇ single-column ਹੀ ਰਹਿੰਦੇ ਹਨ, ਪਰ ਵੋ larger touch targets, wider grids, ਅਤੇ more spacious padding ਵਰਤਦੇ ਹਨ ਤਾ ਕਿ content easier read ਅਤੇ tap ਹੋ ਸਕੇ. ਉਨ੍ਹਾਂ ਨੂੰ split-view ਨਹੀਂ ਮਿਲਦਾ ਕਿਉਂਕਿ ਹਰ step ਨੂੰ ਅਪਨਾ full width list жਾਂ grid clearly ਦਿਖਾਉਣ ਲਈ ਚਾਹੀਦਾ ਹੈ.

## Landscape and portrait

tablet ਘੁਮਾਉਣ 'ਤੇ layout automatically adjust ਹੁੰਦਾ ਹੈ. **landscape** ਵਿਚ side panels ਨੂੰ plenty space ਮਿਲਦਾ ஹੈ. **portrait** ਵਿਚ panels narrower ਹੁੰਦੇ ਹਨ ਪਰ ਫਿਰ ਭੀ text ਦੇ ਬਿਚ ਰਹਿੰਦੇ ਹਨ.

## Selected verse AI chat

**AI** chat verse menu side panel ਵਿਚ ਖੁਲ੍ਹਦਾ ਹੈ. ਯਹ ਏਕ conversation interface ਦਿਖਾਉਂਦਾ ਹੈ ਜਿਥੇ ਤੁਸੀਂ selected verse ਬਾਰੇ questions ਪੂਛ ਸਕਤੇ ੋ. AI response panel ਵİc ਦਿਖਦਾ ਹੈ, ਅਤੇ ਤੁਸੀਂ reader ਛੋਡੇ ਬਿਨਾ conversation continue ਕਰ ਸਕਤੇ ਹੋ.

## Conversation sidebar in AI screen

tablet 'ਤੇ **AI** tab ਵਿਚ conversation list ਹਮੇਸ਼ਾ persistent left sidebar ਦੇ ਰੂਪ ਵਿਚ visible ਹੁੰਦਾ ਹੈ. ਤੁਸੀਂ menu ਖੋਲ੍ਹੇ ਬਿਨਾ chats ਬਦਲ ਸਕਤੇ ੋ. **New Chat** ਬਟਨ ਔਰ always visible ਹੁੰਦਾ ਹੈ. phone 'ਤੇ conversation list popup drawer ਹੁੰਦਾ ਹੈ.

## ਜੋ same ਰਹਿੰਦਾ ਹੈ

ਹਰ screen split into two panes ਨਹੀਂ ਹੁੰਦਾ. ਯਹ screens single-column ਹੀ ਰਹਿੰਦੇ ਹਨ tablets 'ਤੇ:

- **Bible List** — Bible versions ਦੀ list (full width)
- **Bible Books** — book grid ਅਤੇ sections (full width)
- **Bible Chapters** — chapter grid (full width)
- **PDFs** — PDF library wider card grid (full width)
- **Settings** — individual settings pages (full width)
- **Help** — help articles (full width)

## Summary

tablet 'ਤੇ ਤੁਸੀਂ ਮਿਲਦੇ ਹੋ:

- **Parallel Bibles** side-by-side vertical panes ਵਿਚ
- **Commentary** persistent side panels ਵਿਚ
- **Compare** ਅਤੇ **Dictionary** wide cards ਵਿਚ
- **Lexicon** Word Info card 'ਤੇ tap ਸੇ
- **Bookmarks, Highlights, Notes, Devotionals, Books, Settings** master-detail split views ਵਿਚ
- **Search** search form ਦੇ ਨਾਲ inline results
- **Landscape** ਅਤੇ **portrait** both supported automatic layout changes ਨਾਲ

phone 'ਤੇ ਸਭ traditional single-column drill-down navigation ਵਰਤਦਾ ਹੈ. ਐਪ screen width launch 'ਤੇ detect ਕਰਦਾ ਹੈ ਅਤੇ right layout automatically ਚੁਣਦਾ ਹੈ.