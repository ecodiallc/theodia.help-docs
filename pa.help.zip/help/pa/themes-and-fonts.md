---
title: ਥੀਮ ਅਤੇ ਫੌਂਟ ਬਦਲਣਾ
level: everyday
categories: settings
summary: ਐਪ ਦਾ look ਕਿਵੇਂ ਬਦਲਣਾ ਹੈ.
---

# ਥੀਮ ਅਤੇ ਫੌਂਟ ਬਦਲਣਾ

Theodia ਤੁਹਾਨੂੰ ਐਪ ਦਾ look ਬਦਲਣ ਦਿੰਦਾ ਹੈ. ਤੁਸੀਂ theme (light ਜਾਂ dark) ਅਤੇ font size ਚੁਣ ਸਕਦੇ ਹੋ.

## Appearance settings ਕਿਵੇਂ ਖੋਲ੍ਹਣੀ ਹੈ

1. **Settings** ਖੋਲ੍ਹੋ.
2. **Appearance** 'ਤੇ ਟੈ ਕਰੋ.

## theme ਕਿਵੇਂ ਬਦਲਣਾ ਹੈ

**Appearance** section ਵਿੱਚ, ਤੁਹਾਨੂੰ two theme buttons ਮਿਲਦੇ ਹਨ:

- **Default** — light background ਨਾਲ dark text. daytime ਲਈ ਚੰਗਾ.
- **Dark** — dark background ਨਾਲ light text. nighttime ਲਈ ਚੰਗਾ ਅਤੇ battery save ਕਰਦਾ ਹੈ.

theme 'ਤੇ tap ਕਰਕੇ apply ਕਰੋ. change instant ਹੁੰਦਾ ਹੈ.

## font size ਕਿਵੇਂ ਬਦਲਣਾ ਹੈ

**Appearance** section ਵਿੱਚ, size buttons ਵਿੱਚੋਂ ਇੱਕ ਚੁਣੋ: **---**, **--**, **-**, **Normal**, **+**, **++**, **+++**. text across ਐਪ smaller ਜਾਂ larger ਹੁੰਦਾ ਹੈ. ਜੋ size ਤੁਹਾਡੇ ਲਈ read ਕਰਨ ਲਈ ਸਬਸੇ easier ਹੈ ਚੁਣੋ.

## ਸੁਝਾਅ

- OLED screens ਵਾਲੇ phones 'ਤੇ dark theme battery save ਕਰਦਾ ਹੈ.
- ਜੇ text ਬਹੁਤ small ਹੈ read ਕਰਨ ਲਈ, ਐਪ ਵਿਚ font size ਬਢਾਓ, device ਵਿਚ ਨਹੀਂ. ਐਪ ਦਾ setting finer ਹੈ.
- long reading ਲਈ dark theme ਅਤੇ larger font try ਕਰੋ.
- [Activate the desert theme](theodia://unlock-desert)