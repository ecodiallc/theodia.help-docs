---
title: Theodia Features
level: beginner
categories: welcome
summary: Theodia ਨੂੰ special ਬਣਾਉਣ ਵਾਲਾ ਕੀ ਹੈ ਅਤੇ ਇਹ ਤੁਹਾਨੂੰ Bible study ਵੱਚ ਕਿਵੇਂ ਮਦਦ ਕਰਦਾ ਹੈ, ਦਾ quick overview.
---

# Theodia Features

Theodia ਇੱਕ complete Bible study companion ਬਣਾਉਣ ਲਈ built ਹੈ. ਯਹ কੀ special ਬਣਾਉਂਦਾ ਹੈ ਉਹ ਹੈ:

## Offline First

ਸਭ ਕੁਛ internet ਤੋਂ ਬਿਨਾ ਕਾਮ ਕਰਦਾ ਹੈ. Bibles, commentaries, lexicons, books, ਅਤੇ devotionals ਤੁਹਾਡੇ device 'ਤੇ store ਹੁੰਦੇ ਹਨ. ਤੁਸੀਂ plane 'ਤੇ, remote area ਵਿਚ, жਾਂ signal ਤੋਂ ਬਿਨਾ anywhere read, search, ਅਤੇ study ਕਰ ਸਕਤੇ ਹੋ.

## Privacy Focused

ਤੁਹਾਡਾ data ਤੁਹਾਡੇ ਨਾਲ ਰਹਿੰਦਾ ਹੈ. Notes, highlights, bookmarks, ਅਤੇ reading history ਤੁਹਾਡੇ device 'ਤੇ locally store ਹੁੰਦੇ ਹਨ. ਕੋਈ account ਦੀ ਲੋੜ ਨਹੀਂ, ਔਰ optional AI assistant use ਕਰਨ ਦੇ ਚੁਣਾਵ ਤੋਂ ਬਿਨਾ ਕੁਝ ਭੀ server 'ਤੇ ਨਹੀਂ ਭੇਜਾ ਜਾਤਾ.

## Tablet Support

Theodia phones ਅਤੇ tablets ਦੋਨੋਂ ਲਈ designed ਹੈ. larger screen 'ਤੇ, ਤੁਹਾਨੂੰ reading ਲਈ more space, parallel Bible views, ਅਤੇ extra room use ਕਰਨ ਵਾਲਾ layout ਮਿਲਦਾ ਹੈ.

## Installable Resources

ਤੁਸੀਂ app ਦੇ ਨਾਲ ਆਉਣ ਵਾਲੇ ਤੋਂ ਜ਼ਿਆਦਾ add ਕਰ ਸਕਦੇ ਹੋ. extra Bible versions, commentaries, lexicons, books, ਅਤੇ devotionals. Resources project's GitHub page 'ਤੇ available ਹਨ ਅਤੇ directly app ਵਿੱਚ install ਕੀਤੇ ਜਾ ਸਕਦੇ ਹਨ.

## AI Assistant

optional AI assistant ਤੁਹਾਨੂੰ verses understand ਕਰਨ, context explain ਕਰਨ, ਅਤੇ questions ਦੇ ਉਤਤਰ ਦੇਣ ਵਿਚ help ਕਰਦਾ ਹੈ. ਯਹ ਸਿਰਫ਼ ਤਦ active ਹੁੰਦਾ ਹੈ ਜਬ ਤੁਸੀਂ ਇਸਨੂੰ ਚਾਲੂ ਕਰਦੇ ਹੋ. default ਤੌਰ 'ਤੇ ਯਹ ਤੁਹਾਡੇ endpoint ਅਤੇ API key ਤੋਂ remote model connect ਕਰਦਾ ਹੈ. ਪਹਿਲੀ ਬਾਰ AI use ਕਰਨ 'ਤੇ, app permission ਮੰਗਦਾ ਹੈ ਅਤੇ exactly ਜੋ ਭੇਜਿਆ ਜਾਤਾ ਹੈ ਦਿਖਾਉਂਦਾ ਹੈ.

## Parallel Bible Reading

ਇੱਕ ਸਾਥ up to four Bible versions ਪੜ੍ਹੋ. chapter ਖੋਲ੍ਹਣ 'ਤੇ, ਤੁਹਾਡਾ main translation ਪਹਿਲੇ ਦਿਖਦਾ ਹੈ, ਅਤੇ ਹਰ verse ਦੇ ਬਾad ਤੁਹਾਡੇ chosen parallel translations ਵਿਚ ਇੱਕੋ verse ਦਿਖਦਾ ਹੈ. wording compare ਕਰੋ, differences study ਕਰੋ, ਅਤੇ text ਦਾ fuller picture ਲਓ. ਆਪਨੇ favorite combinations presets ਦੇ ਰੂਪ ਵਿਚ save ਕਰੋ ਅਤੇ ਉਨ੍ਹਾਂ ਬਿਚ quickly switch ਕਰੋ.

## Full-Text Search

ਕਿਸੇ ਭੀ Bible version ਵਿੱਚ search ਕਰੋ. words, phrases, ਜਾਂ partial matches ਲਭੋ. ਤੁਸੀਂ search ਨੂੰ books ਦੇ ਏਕ range ਤੱ limit ਭੀ ਕਰ ਸਕਦੇ ਹੋ.

## Cross-References

 verse reference 'ਤੇ tap ਕਰਕੇ directly ਉਸ passage 'ਤੇ jump ਕਰੋ. Cross-references built-in ਹਨ ਅਤੇ entire Bible ਵிச work ਕਰਦੇ ਹਨ.

## Lexicon and Strong's Numbers

Strong's number 'ਤੇ tap ਕਰਕੇ original Greek ਜਾਂ Hebrew definition ਦੇਖੋ. deeper word study ਲਈ lexicon entries ਸ਼ਾਮਿਲ ਹਨ.

## Bookmarks and Highlights

verses ਨੂੰ bookmarks ਨਾਲ save ਕਰੋ ਅਤੇ colors ਨਾਲ mark ਕਰੋ. ਸਭ device 'ਤੇ locally store ਹੁੰਦਾ ਹੈ ਅਤੇ sessions ਬਿਚ persist ਰਹਿੰਦਾ ਹੈ.

## Notes

ਕਿਸੇ ਭੀ verse ਦੇ ਨਾਲ ਆਪਣੇ thoughts ਲਿਖੋ. notes verse ਨਾਲ tied ਹੁੰਦੇ ਹਨ ਅਤੇ ਬਾਦ ਵਿਚ easily ਲੱਭੇ ਜਾ ਸਕਤੇ ਹਨ.

## Daily Devotional

ਦਿਨ ਸ਼ੁਰੂ ਕਰੋ ਇੱਕ short devotional reading ਨਾਲ. app ਵਿਚ devotionals ਹਨ ਜੋ today's entry automatically ਖੁল੍ਹਦੇ ਹਨ.

## Christian Books

ਕਿਤਾਬਾਂ classic Christian literature app ਅੰਦਰ ਪੜ੍ਹੋ. books easy reading ਲਈ formatted ਹਨ ਅਤੇ quick navigation ਲਈ table of contents ਸ਼ਾਮਿਲ ਹੈ.

## PDF Reading

ਤੁਹਾਡੇ own PDF documents import ਕਰੋ ਅਤੇ ਉਨ੍ਹਾਂ ਨੂੰ offline read ਕਰੋ, categories ਵਿਚ organized. reader search, table of contents, bookmarks, zoom, ਅਤੇ reading aloud support ਕਰਦਾ ਹੈ. community repository ਤੋਂ packaged PDF collections ਭੀ install ਕਰ ਸਕਦੇ ਹੋ.

## Multiple Languages

Theodia app interface ਅਤੇ Bible content ਦੋਨੋਂ ਲਈ many languages support ਕਰਦਾ ਹੈ. settings ਵਿਚ language switch ਕਰੋ.

## Dark Mode and Themes

light ਜਾਂ dark mode ਚੁਣੋ, ਜਾਂ ਅਪਨੀ preference ਦੇ according theme pick ਕਰੋ. reading comfort important ਹੈ, especially low light ਵਿਚ.

## Data Backup

ਤੁਹਾਡੇ notes, bookmarks, ਅਤੇ highlights backup ਕਰੋ. data safe ਰੱਖੋ ਅਤੇ need ਹੋਣ 'ਤੇ new device 'ਤੇ move ਕਰੋ.

## No Ads, No Distractions

Theodia focus ਲਈ built ਹੈ. ਕੋਈ ads, ਕੋਈ pop-ups, ਕੋਈ interruptions. Just text ਅਤੇ ਤੁਹਾਡੇ study tools.