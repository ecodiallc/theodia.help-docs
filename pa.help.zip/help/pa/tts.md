---
title: ਉੱਚੀ ਆਵਾਜ਼ ਵਿੱਚ ਪੜ੍ਹਾਈ (Text-to-Speech)
level: everyday
categories: tts
summary: Theodia ਨੂੰ Bible ਜਾਂ devotional ਉੱਚੀ ਆਵਾਜ਼ ਵਿਚ ਪਡ੍ਹਾਓ. ਇਸਦਾ use, voice ਚੁਣਨਾ, ਅਤੇ silent ਹੋਣ 'ਤੇ ਕੀ ਕਰਨਾ ਹੈ.
---

# ਉੱਚੀ ਆਵਾਜ਼ ਵਿੱਚ ਪੜ੍ਹਾਈ (Text-to-Speech)

> **Mode:** Text-to-speech **ਸਟੈਂਡਰਡ** ਅਤੇ **ਸਕਾਲਰ** mode ਵਿਚ ਉਪਲਬਧ ਹੈ. Focus Mode ਸਿਰਫ਼ clean, distraction-free reading ਲਈ ਹੈ. mode ਬਦਲਣ ਲਈ **Settings** → **App User Mode**.

Theodia ਤੁਹਾਡੇ device ਦੀ text-to-speech (TTS) voice ਵਰਤ ਕੇ text ਉੱਚੀ ਆਵਾਜ਼ ਵਿਚ ੍ਹਾ ਸਕਦਾ ਹੈ. ਤੁਸੀਂ ਇੱਕ single verse, ਇੱਕ ਪੂਰਾ chapter, ਜਾਂ ਇੱਕ devotional ਸੁਣ ਸਕਤੇ ਹੋ. ਯਹ hands-free reading, walk ਜਾਂ commute ਦੌਰਾਨ ਸੁਣਨ, audio ਸਾਥ readings follow ਕਰਨ, ਜਾਂ eyes ਨੂੰ rest ਦੇਣ ਲਈ useful ਹੈ.

## listen ਬਟਨ ਕിੱഥੇ ਹੈ

ਤੁਸੀਂ three places 'ਤੇ listen ਬਟਨ ਲੱਭੋਂਗੇ.

### 1. verse menu ਵਿੱਚ (single verse)

ਇੱਕ verse ਤੁਰੰਤ ਸੁਣਨ ਦਾ fastest way. [Study Mode](theodia://help/study-mode) ਵਿਚ chapter ਖੋਲ੍ਹੋ, verse 'ਤੇ ਟੈ ਕਰਕੇ verse menu ਖੋਲ੍ਹੋ, ਫਿਰ **Speak** (🔊) 'ਤੇ ਟੈ ਕਰੋ. ਉਸ verse ਤੋਂ reading ਸ਼ੁਰੂ ਹੁੰਦੀ ਹੈ. ਸਕ੍ਰੀਨ ਨਿਚੇ small control bar play, pause, rewind, fast-forward, ਅਤੇ voice picker ਨਾਲ ਦਿਖਦਾ ਹੈ.

Speak option interlinear Bibles (MIB — Marvel Interlinear Bible — ਅਤੇ OHGB) ਲਈ ਨਹੀਂ ਦਿਖਦਾ, ਕਿਉਂਕਿ ਉਨ੍ਹਾਂ ਦਾ layout natural ਤੌਰ 'ਤੇ read ਨਹੀਂ ਹੁੰਦਾ.

### 2. chapter ਦੇ top 'ਤੇ (whole chapter)

chapter read ਕਰਦੇ ਸਮய, ਸਕ੍ਰੀਨ ਦੇ ਉੱ icons ਦੀ row ਵਿਚ **Listen** (🔊) 'ਤੇ tap ਕਰੋ. ਪੂਰਾ chapter ਬਾਦ ਵਿਚ ਸ਼ுਰੂ ਤੋਂ read ਹਏਗਾ. button audio play ਹੋਣ 'ਤੇ stop (⏹) ਬਣ ਜਾਦਾ ਹੈ. ਦੁਬਾਰਾ tap ਕਰਕੇ stop. same control bar ਨਿਚੇ ਦਿਖਦਾ ਹੈ.

ਤੁਸੀਂ different verse 'ਤੇ jump ਕਰ ਸਕਤੇ ੋ, ਅਤੇ ਵਹਾਂ Listen ਬਟਨ ਉਸ verse ਤੋਂ ੁਰੂ ਹੋਏਗਾ.

### 3. devotional ਵਿੱਚ

ਕਿਸੇ devotional day ਖੋਲ੍ਹੋ, ਫਿਰ reading ਦੇ top 'ਤੇ **Listen** (🔊) 'ਤੇ tap ਕਰੋ. full devotional text sentence by sentence ਬੁਲੰਦ ਆਵਾਜ਼ ਵਿਚ read ਹੁੰਦਾ ਹੈ. ਸਕ੍ਰੀਨ ਨਿਚੇ control bar play, pause, rewind, ਅਤੇ voice controls ਦਿੰਦਾ ਹੈ.

## control bar use ਕਰਨਾ

audio play ਹੋਣ 'ਤੇ, ਸਕ੍ਰੀਨ ਨਿਚੇ ਇੱਕ small bar ਹੇਸ਼ਾ visible ਰਹਿੰਦਾ ਹੈ. ਇਸ ਵਿਚ six controls ਹਨ:

- ⏪ **Rewind** — ਇੱਕ verse (ਜਾਂ devotional ਵਿੱਚ ਇੱਕ sentence) back
- ⏸ **Pause / ▶ Resume** — place ਨਾ ਖੋਣਾ ਵਾਲਾ pause. ਦੁਬáਰਾ tap ਕਰਕੇ continue.
- ⏩ **Fast forward** — ਅਗਲਾ verse (ਜਾਂ devotional ਵਿੱਚ ਅਗਲਾ sentence) skip
- 🎙 **Voice** — chapter ਛੋਡੇ ਬਿਨਾ voice picker ਖੋਲ੍ਹੋ (ਨਿਚੇ ਵੇਖੋ)
- ⚙ **Options** — extended options panel ਖੋਲ੍ਹੋ (ਨਿਚੇ ਵੇਖੋ)
- **Stop** — ਸਕ੍ਰੀਨ ਊਪਰ 🔊 ਜੋ audio play ਹੋਣ 'ਤੇ ⏹ ਬਣ ਜਾਤਾ ਹੈ, 'ਤੇ tap ਕਰੋ.

chapter finish ਹੋਣ 'ਤੇ ਜਾਂ stop tap ਕਰਨ 'ਤੇ bar close ਹੁੰਦਾ ਹੈ.

### Extended options

⚙ 'ਤੇ tap ਕਰੋ extra playback options expand ਕਰਨ ਲਈ. ਯਹ settings sirf current chapter ਲਈ last ਹੁੰਦੀਆਂ ਹਨ ਅਤੇ chapter switch ਜਾਂ listening stop ਕਰਨ 'ਤੇ reset ਹੁੰਦੀਆਂ ਹਨ.

- ⏮ **Back to begin** — ਤੁਹਾਡੇ set ਕੀਤੇ range ਦਾ ਪਹਿਲਾ verse jump ਕਰੋ.
- **Begin** — verse number type ਕਰੋ reading ਕਿੱਥੋਂ ਸ਼ੁਰੂ ਹੋਵੇ.
- **End** — verse number type ਕਰੋ reading ਕਿਥੇ ਰੁੱਕੇ.
- **All** — range ਨੂੰ full chapter 'ਤੇ reset ਕਰੋ.
- **()** — parenthetical text (parentheses ਵਿੱਚ text) read aloud ਹੋਵੇ ਜਾਂ ਨਹੀਂ toggle.
- 🔁 **Repeat** — range ਦੇ end 'ਤੇ ਪਹੁੰਚਣ 'ਤੇ automatically begin 'ਤੇ restart, ਛੋਟੇ pause ਨਾਲ. ਜੇ begin/end verse set ਨਾ ਕੀਤਾ ਹੋਵੇ ਅਤੇ repeat on ਕਰਦੇ ੋ, ਪੂਰਾ chapter repeat ਹੁੰਦਾ ਹੈ.

### prayer screens ਵਿੱਚ

Creeds and fixed prayers, generated prayers, ਅਤੇ prayer routines ਅਪਨੇ extended options ਰੱਖਦੇ ਹਨ. control bar ਵਿਚ ⚙ 'ਤੇ tap ਕਰੋ:

- **Speed** — rate (ਜਿਵੇਂ `1x`) 'ਤੇ tap ਕਰਕੇ 0.1x ਤੋਂ 1.5x ਤੱ reading speed ਚੁਣੋ. ਤੁਹਾਡੀ choice ਯਾਦ ਰੱਖੀ ਜਾਂਦੀ ਹੈ ਅਤੇ next time use ਹੁੰਦੀ ਹੈ.
- **()** — parenthetical text read aloud toggle.
- 🔁 **Repeat** — finish ਹੋਣ 'ਤੇ prayer ਨੂੰ beginning ਤੋਂ automatically restart, ਛੋਟੇ pause ਨਾਲ. creed жਾਂ fixed prayer memorize ਕਰਨ ਲਈ useful.

speed change ਤੁਰੰਤ effect ਹੁੰਦਾ ਹੈ, place ਨਾ ਖੋਣਾ. parenthetical option on/off ਕਰਨ 'ਤੇ prayer ਸ਼ੁਰੂ ਤੋਂ restart ਹੁੰਦਾ ਹੈ ਤਾਂ ਕਿ change ਸ਼ੁਰੂ ਤੋਂ ਸੁਣੀ ਜਾ ਸਕੇ.

## voice ਕਿਵੇਂ ਬਦਲਣਾ ਹੈ

ਤੁਸੀਂ ਚੁਣ ਸਕਤੇ ਹੋ Theodia ਕਿਹੜੀ voice use ਕਰੇ. different accent, language, ਜਾਂ device default ਤੋਂ faster/slower voice ਲਈ useful.

1. **Settings** ਖੋਲ੍ਹੋ.
2. **Speech** section ਤੋਂਡ.
3. **Select Voice** 'ਤੇ tap ਕਰੋ.
4. voices ਦੀ list ਦਿਖਦੀ ਹੈ. ਪਹਿਲਾ row, **System Default**, ਤੁਹਾਡੇ device ਦੀ preferred voice use ਕਰਦਾ ਹੈ. ਕੋਈ ਹੋਰ row ਚੁਣੋ new default ਬਣਾਉਣ ਲਈ.
5. choice save ਹੁੰਦਾ ਹੈ ਅਤੇ next time **Listen** жਾਂ **Speak** tap ਕਰਨ 'ਤੇ use ਹੁੰਦਾ ਹੈ.

ਤੁਸੀਂ listening control bar ਵਿਚ 🎙 icon 'ਤੇ tap ਕਰਕੇ ਬਿਨਾ chapter ਛੋਡੇ same picker ਭੀ ਖੋਲ੍ਹ ਸਕਤੇ ੋ.

voice availability ਪੂਰੀ ਤਰਹ ਤੁਹਾਡੇ device 'ਤੇ depend ਕਰਦਾ ਹੈ. iOS ਅਤੇ Android each ਅਪਨਾ set of built-in voices ਲੈ ਕੇ ਆਉਂਦੇ ਹਨ. device ਦੀ **Accessibility** ਜਾਂ **Language & Input** settings ਤੋਂ more voices install ਕਰ ਸਕਦੇ ਹੋ. Theodia ਤੁਹਾਡੇ device 'ਤੇ installed ਕੋਈ ਭੀ voice use ਕਰ ਸਕਦਾ ਹੈ.

## Favorite voices

ਜਬ device ਵਿਚ ਬਹੁਤ voices ਹਨ, full list scroll ਕਰਨਾ slow ਹੋ ਸਕਦਾ ਹੈ. ਤੁਸੀਂ **favorite voices** ਦੀ short list ਬਣਾ ਸਕਦੇ ਹੋ, ਅਤੇ voice pickers ਸਿਰਫ ਵਹੀ ਦਿਖਾਏਂਗੇ.

1. **Settings** ਖੋਲ੍ਹੋ.
2. **Speech** section ਤோਂਡ.
3. **Favorite Voices** 'ਤੇ tap ਕਰੌ (section ਦੇ top 'ਤੇ first row).
4. favorites screen ਖੋਲ੍ਹਣ ਲਈ **Set Favorite Voices** 'ਤੇ tap.
5. voice preview ਕਰਨ ਲਈ play button 'ਤੇ tap. favorite ਬਣਾਉਣ ਲਈ star 'ਤੇ tap. ਤੁਸੀਂ ਜਿਤਨੇ ਚਾਹੋ favorite ਕਰ ਸਕਤੇ ਹੋ.
6. back ਜਾਓ. Theodia ਭਰ ਵਿਚ voice pickers ਸਿਰਫ ਤੁਹਾਡੇ favorite voices ਦਿਖਾਏਂਗੇ.

ਜਬ ਸਭ favorites remove ਕਰ ਦਿਓ, pickers ਦੁਬਾਰਾ ਸਭ voices ਦਿਖਾਉਂਦੇ ਹਨ. favorite voices backup ਅਤੇ restore ਵਿਚ ਸ਼ਾਮਿਲ ਹੁੰਦੇ ਹਨ.

## ਹਰ Bible ਲਈ different voice

ਤੁਸੀਂ ਹਰ Bible translation ਨੂੰ ਅਪনੀ voice ਦੇ ਸਕਦੇ ਹੋ. different ਤਰਹ ਦੇ versions (ਜਿਵੇਂ formal voice KJV ਲਈ, conversational modern translation ਜਿਵੇਂ NIV žਾਂ NLT) ਲਈ useful. different languages ਵਿਚ Bibles ਸੁਣਨ 'ਤੇ ਭੀ each ਨੂੰ right accent ਵਿਚ spoken ਕਰਨ ਲਈ.

1. **Settings** ਖੋਲ੍ਹੋ.
2. **Speech** section ਤோਂਡ.
3. **Bible Voices** ਤோਂਡ.
4. list ਵਿਚ ਕੋਈ Bible 'ਤੇ tap.
5. ਉਸ translation ਲਈ voice ਚੁਣੋ. ਪਹਿਲਾ row, **System Default**, ਤੁਹਾਡੀ main TTS voice ਵਰਤਦਾ ਹੈ.
6. ਦੂਸਰੇ Bibles ਲਈ repeat.

header ਦਿਖਾਉਂਦਾ ਹੈ ਕਿਨੇ Bibles ਚustom voice set ਹਨ. **Select Voice**, **Commentary Voice**, **Bible Notes Voice**, ਅਤੇ **Devotional Voice** ਭੀ ਜਬ voice set ਹੋਵੇ count ਦਿਖਾਉਂਦੇ ਹਨ.

ਅਗਲੀ ਬার ਤੁਸੀਂ ਉਸ Bible ਤੋਂ chapter ਸੁਣੋਗੇ, Theodia ਤੁਹਾਡੀ chosen voice use ਕਰਏਗਾ. ਬਾਕੀ Bibles main default voice use ਕਰਦੇ ਰਹਿੰਦੇ ਹਨ ਜਦ ਤੱਕ ਤੁਸੀਂ ਉਨ੍ਹਾਂ ਨੂੰ ਬਦਲ ਨਾ ਦਿઓ.

## background ਵਿਚ speech continue

default ਤੌਰ 'ਤੇ, Theodia reader screen ਛੋਡਨ, ਦੂਸਰਾ app ਖੋਲ੍ਹਣ, жਾਂ phone lock ਕਰਨ 'ਤੇ speech stop ਕਰਦਾ ਹੈ. ਯਹ prevents unexpected audio ਜਬ ਤੁਸੀਂ actively reading ਨਹੀਂ.

background ਵਿਚ play ਰੱਖਣ ਲਈ:

1. **Settings** ਖੋਲ੍ਹੋ.
2. **Speech** section ਤோਂਡ.
3. **Continue speech in background** ਚਾਲੂ ਕਰੋ.

on ਹੋਣ 'ਤੇ, ਤੁਸੀਂ tabs switch, ਦੂਸਰਾ app ਖੋਲ੍ਹ, ਜਾ screen lock ਕਰ ਸਕਤ ਹੋ ਔਰ chapter ਜਾ devotional read ਕਰਨਾ ਜਾਰੀ ரਹੇਗਾ. control bar active ਰਹੇਗਾ ਤਾ ਕਿ ਤੁਸੀਂ notification area ਤੋਂ pause ਜਾਂ skip ਕਰ ਸਕੋ (device support ਹੋਣ 'ਤੇ).

speech playੋਣ 'ਤੇ toggle **off** ਕਰਨਾ ਤੁਰੰਤ ਇਸਨੂੰ stop ਕਰ ਦਿੰਦਾ ਹੈ.

## ਜਬ ਕਾਮ ਨਹੀਂ ਕਰ ਰਿਹਾ ਹੋ

TTS ਤੁਹਾਡੇ device 'ਤੇ depend ਕਰਦਾ ਹੈ. Theodia text operating system ਨੂੰ ਭੇਜਦਾ ਹੈ, ਅਤੇ operating system installed voice ਨਾਲ ਇਸਨੂੰ ਬੁਲੰਦ ਆਵਾਜ਼ ਵਿਚ ਪਡ੍ਹਦਾ ਹੈ. ਜਬ ਕਾਮ ਨਹੀਂ ਕਰ ਰਿਹਾ, ਯੇ steps ਕਰਮ ਵਿਚ try ਕਰੋ.

### Theodia ਬੋਲਦਾ ਹੈ TTS available ਨহੀਂ

ਕੁਝ devices 'ਤੇ TTS ਨਹੀਂ ਹੁੰਦਾ. **Settings** ਖੋਲ੍ਹੋ ਅਤੇ **TTS** section ਤੋਂਡ. ਜਬ section ਨਹੀਂ ਹੈ, ਤਬ ਤੁਹਾਡੇ device 'ਤੇ ਇਸ build ਵਿਚ TTS support ਨਹੀਂ.

### voice list ਖਾਲੀ ਹੈ

voice picker "no voices found" ਦਿਖਾ ਸਕਦਾ ਹੈ. ਯਹ ਆਮ ਤੌਰ 'ਤੇ ਹੁੰਦਾ ਹੈ ਜਬ device ਨੂੰ voices load ਕਰਨ ਵਿਚ time ਲਗਦਾ ਹੈ.

1. **Settings → Speech → Select Voice** ਖੋਲ੍ਹੋ.
2. ਜਬ list empty ਹੈ, dropdown ਦੇ ਬਿਚਲਾ **Retest** ਬਟਨ ਤੋਂਡ. Theodia voices' ਲਈ device re-query ਕਰਦਾ ਹੈ.
3. ਜਬ ਫਿਰ ਭੀ empty ਹੈ, device's system settings ਚੈਕ ਕਰੋ. iOS 'ਤੇ, **Settings → Accessibility → Spoken Content → Voices** 'ਤੇ ਜਾਓ ਅਤੇ ਤੁਹਾਡੀ language ਲਈ voice download ਕਰੋ. Android 'ਤੇ, **Settings → Language & Input → Text-to-Speech Output** 'ਤੇ ਜਾਓ ਅਤੇ **Install voice data** 'ਤੇ tap.
4. Theodia reopen ਕਰੋ ਤਾਂ ਇਹ new voice pick ਕਰੇ.

ਜਬ ਤੁਸੀਂ favorite voices set ਕੀਤੇ ਹਨ ਅਤੇ list empty ਹੈ, ensure ਕਰੋ at least ਇੱਕ favorite ਤੁਹਾਡੇ device 'ਤੇ installed voice match ਕਰਦਾ ਹੈ.

### Speak tap ਕਰਨ 'ਤੇ ਕੁਝ ਨਹੀਂ ਹੁੰਦਾ

- device silent mode ਵਿਚ ਨਹੀਂ ਹੋਣਾ ਚਾਹੀਦਾ. most devices silent mode ਵਿਚ TTS audio play ਨਹੀਂ ਕਰਦੇ.
- device volume up ਹੋਣਾ ਚਾਹੀਦਾ.
- **Settings → Speech** ਵਿਚ **Retest** ਬਟਨ try ਕਰੋ.
- **Settings** ਖੋਲ੍ਹੋ ਅਤੇ bottom ਵਿਚ **System** section ਤੋਂਡ. **TTS** row ਬੋਲਣਾ ਚਾਹੀਦਾ **Available**. ਜਬ ਯਹ **Unavailable** ਹੈ, TTS operating-system level 'ਤੇ off ਹੈ. ਵਹਾਂ re-enable ਰੋ ਅਤੇ Theodia reopen ਕਰੋ.

### Audio wrong language ਵਿਚ play ਹੁੰਦਾ ਹੈ

Theodia current content ਦੀ language ਵਿਚ text ਭੇਜਦਾ ਹੈ ਅਤੇ ਤੁਹਾਡੀ chosen voice ਮਾਗਦਾ ਹੈ. ਜਬ chosen voice ਕਿਸੀ ਦੂਸਰੀ language ਦੀ ਹੈ, device text read ਕਰ ਸਕਦਾ ਹੈ ਪਰ odd sound ਕਰੇਗਾ.

1. **Settings → Speech → Select Voice** ਖੋਲ੍ਹੋ.
2. voice ਚੁਣੋ ਜੋ text ਦੀ language match ਕਰਦੀ ਹੈ, ਜਾ **System Default** ਚੁਣੋ ਤਾਂ device right one pick ਕਰੇ.

Theodia Greek жਾ Hebrew interlinear Bibles ਨੂੰ aloud ਨਹੀਂ ਪਡ੍ਹਦਾ. Speak ਅਤੇ Listen ਬਟਨ ਉਨ translations 'ਤੇ hidden ਹਨ.

### Audio early stop ਹੁੰਦਾ ਹੈ

ਜਬ ਕੋਈ verse missing ਜਾ unreadable ਹੈ, chapter ਅਗ਼ਲੇ verse 'ਤੇ skip ਕਰਦਾ ਹੈ. ਜਬ bar few verses ਬਾ ਖੁਦ close ਹੁੰਦਾ ਹੈ, top 'ਤੇ **Listen** (🔊) ਦੁਬਾਰਾ tap ਕਰੋ.

### Speech playing ਹੈ ਪਰ ਨਹੀਂ ਪਤਾ ਕਿੱਥੋਂ ਸ਼ੁਰੂ ਹੁਆ

ਜਬ ਤੁਸੀਂ **Continue speech in background** ਚਾਲੂ ਕੀਤਾ ਹੈ ਔਰ ਬਾਦ ਵਿਚ audio ਸੁਣਦੇੋ ਪਰ screen ਨਹੀਂ ਮਿਲਦਾ, ਤੁਸੀਂ app ਦੇ ਕਿਸੀ ਭੀ ਜਗਹ ਤੋਂ ਇਸਨੂੰ stop ਕਰ ਸਕਤੇ ਹੋ.

1. **Settings** ਖੋਲ੍ਹੋ.
2. **Speech** section ਤோਂਡ.
3. section ਦੇ bottom 'ਤੇ red **Stop Speech** ਬਟਨ 'ਤੇ tap.

ਯਹ Theodia ਵਿਚ ਚਲ ਰਿਹਾ ਸਭ TTS ਤੁਰੰਤ stop ਕਰ ਦਿੰਦਾ ਹੈ. device's app switcher ਵਿਚ Theodia away swipe ਕਰਕੇ ਭੀ audio force-stop ਕਰ ਸਕਤੇ ਹੋ.

### ਯਹ ਬਹੁਤ fast ਜਾ slow read ਕਰਦਾ ਹੈ

Theodia reading speed control ਨਹੀਂ ਕਰਦਾ. speed chosen voice ਦਵਾਰਾ set ਹੁੰਦਾ ਹੈ. ਬਦਲਨ ਲਈ:

- iOS: **Settings → Accessibility → Spoken Content → Speaking Rate**.
- Android: **Settings → Language & Input → Text-to-Speech Output → Speech Rate**.

## ਸੁਝਾਅ

- chapter ਬਿਚ navigate ਕਰਦੇ ਸਮਯ control bar visible ਰਹੇਗਾ, ਤਾ ਕਿ pause, skip, ਜਾਂ voice change place ਨਾ ਖੋਲ.
- Theodia verse numbers ਨੂੰ small pauses ਦੇ ਰੂਪ ਵਿਚ read ਕਰਦਾ ਹੈ. bar stop ਕਰੋ, different verse 'ਤੇ swipe ਕਰੋ, ਫਿਰ play tap ਕਰੋ ਤੁਰੰਤ.
- long listen-throughs ਲਈ, notifications interrupt ਨਾ ਕਰੇ ਤਾਂ **Do Not Disturb** ਚਾਲੂ ਕਰੋ.
- 🔊 button device ਦੀ current volume use ਕਰਦਾ ਹੈ. headphones plug ਕਰਨ 'ਤੇ volume headphone level 'ਤੇ switch.

## PDF out loud ਪੜ੍ਹਨਾ

Theodia PDF pages ਬੀ aloud read ਕਰ ਸਕਦਾ ਹੈ. PDF ਖੋਲ੍ਹੋ ਅਤੇ toolbar ਵਿਚ **Listen** (speaker) 'ਤੇ tap ਕਰો. control bar play/pause, rewind, fast forward, stop, progress bar, speed, ਅਤੇ voice pickers ਵਿਚ ਦਿਖਦਾ ਹੈ. page finish ਹੋਣ 'ਤੇ reading ਅਗਲੇ page 'ਤੇ automatically ਜਾਰੀ ਰਹਿੰਦੀ ਹੈ.

PDF reading PDF ਦੇ installed searchable text ਅਤੇ Bible reading ਵਾਲੇ same voices ਅਤੇ speed use ਕਰਦੀ ਹੈ.

## related guides

- [Study Mode](theodia://help/study-mode) guide verse menu ਅਤੇ top-of-screen buttons ਵਿਸਥਾਰ ਵਿਚ cover ਕਰਦਾ ਹੈ.
- [Focus Mode](theodia://help/focus-mode) guide cleaner reading view ਹੈ ਜੋ ਭੀ bottom bar ਵਿਚ 🔊 ਨਾਲ TTS support ਕਰਦਾ ਹੈ.
- [Common Problems](theodia://help/common-problems) guide other audio, voice, ਅਤੇ language issues ਲਈ fixes ਦਿੰਦਾ ਹੈ.
- [Daily Devotionals](theodia://help/daily-devotionals) guide devotional reading ਅਤੇ listen ਬਟਨ ਦੇ location cover ਕਰਦਾ ਹੈ.
- [PDFs](theodia://help/pdfs) guide PDF reader ਅਤੇ ਇਸਦ੾а listen ਬਟਨ cover ਕਰਦਾ ਹੈ.