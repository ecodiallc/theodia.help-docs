---
title: Theodia ਵਿੱਚ Welcome
level: beginner
categories: welcome
summary: ਐਪ ਦਾ short tour ਅਤੇ ਯਹ ਕੀ ਕਰ ਸਕਦੀ ਹੈ.
---

# Theodia ਵਿਚ Welcome

Theodia ਇੱਕ Bible study app ਹੈ. ਇਹ ਤੁਹਾਡੇ phone żਾ tablet 'ਤੇ ਚਲਦੀ ਹੈ, ਭਾਵੇਂ internet ਨਹੀਂ. ਤੁਸੀਂ ਜੋ read, search, ਅਤੇ study ਕਰੋ, ਉਹ ਤੁਹਾਡੇ device 'ਤੇ save ਹੁੰਦਾ ਹੈ.

## ਤੁਸੀਂ ਕੀ ਕਰ ਸਕਦੇ ਹੋ

Theodia ਵਿਚ three user modes ਹਨ. ਹਰ mode ਏਕ different set of features ਦਿਖਾਉਂਦਾ ਹੈ.

- **Reader** — clean, distraction-free view ਵਿਚ Bible ਪਡ੍ਹੋ.
- **Standard** — Reader ਵਿਚ ਸਭ ਜਮਾ, ਪਲੱਸ bookmarks, highlights, notes, text-to-speech, search, ਅਤੇ daily devotionals.
- **Scholar** — Standard ਵਿਚ ਸਭ ਜਮਾ, ਪਲੱਸ commentaries, lexicons, Bible Dictionary, AI assistant, ਅਤੇ ਹੋਰ.

modes ਕਿਸੇ ਭੀ ਸਮਯ **Settings** → **App User Mode** ਵਿਚ  ਸਕਤੇ ਹੋ.

### features available ਤੁਹਾਡੇ ਲਿਏ

ਚਾਹੇ ਤੁਸੀਂ ਕੋਈ mode ਚੁਣਿਆ ਹੋਵੇ, ਤੁਸੀਂ ੇਸ਼ਾ ਕਰ ਸਕਦੇ ਹੋ:

- **Bible ਪਡ੍ਹੋ.** many translations ਵਿਚੋਂ ਚੁਣੋ. ਕਭੀ ਭੀ ਉਨ੍ਹਾਂ ਵі switch ਕਰੋ.
- **Bible search ਕਰੋ.** word ਜਾ phrase ਲਭੋ. app ਤੁਹਾਨੂੰ ਹਰ matching verse ਦਿਖਾਏਗਾ.
- **Books ਅਤੇ devotionals ਪਡ੍ਹੋ.** app Christian classics ਅਤੇ daily devotional ਨਾਲ ਆਉਂਦਾ ਹੈ.

mode ਦੇ according, ਤੁਸੀਂ ਇਹ ਭੀ ਕਰ ਸਕਤੇ ਹੋ:

- **ਸੁਣੋ.** read-aloud feature ਨਾਲ verses ਬੁਲੰਦ ਆਵਾਜ਼ ਵਿਚ суਣੋ. (Standard ਅਤੇ Scholar.)
- **Notes ਲਿਖੋ.** verse ਦੇ ਨਾਲ ਆਨੇ thoughts ਲਿਖੋ. (Standard ਅਤੇ Scholar.)
- **Highlight ਕਰੋ.** favorite verses colors ਨਾਲ mark ਕਰੋ. (Standard ਅਤੇ Scholar.)
- **Bookmark ਕਰੋ.** verses save ਕਰੋ ਤਾ ਤੁਸੀਂ ਉਨ੍ਹਾਂ ਨੂੰ fast ਦੁਬਾਰਾ ਲੱਭ ਸਕੋ. (Standard ਅਤੇ Scholar.)
- **AI assistant ਪੂਛੋ.** verse understand ਕਰਨ ਵਿਚ help ਲਓ. (Sirf Scholar.)

## ਕਿਥੇ ਸ਼ੁਰੂ ਕਰਨਾ ਹੈ

1. ਸਕ੍ਰੀਨ ਦੇ bottom 'ਤੇ **Bible** tab ਖੋਲ੍ਹੋ.
2. ਇੱਕ translation ਚੁਣੋ.
3. ਕਿਸੇ book 'ਤੇ tap ਕਰਕੇ reading ਸ਼ੁਰੂ ਕਰੋ.

ਜੇ ਤੁਸੀਂ more ਜਾਣਨਾ ਚਾਹੁੰਦੇ ੋ, rest of help guides ਤੁਹਾਡੇ ਲਈ ਹਨ. help home page ਦੀ list ਤੋਂ topic ਚੁਣੋ.

## ਕੁਝ ਜਾਣਨ ਵਾਲੀਆਂ ਗੱਲਾਂ

- account ਦੀ ਲੋੜ ਨਹੀਂ.
- ਤੁਹਾਡੇ notes, highlights, ਅਤੇ bookmarks ਤੁਹਾਡੇ device 'ਤੇ ਰਹਿੰਦੇ ਹਨ.
- backup ਕਰ ਸਕਤੇ ਹੋ. [Backing Up Your Data](theodia://help/backups) guide ਵੇਖੋ.

## more resources ਚਾਹੀਦੇ ਹਨ?

app ਵਿਚ freely available Bible versions ਸ਼ਾਮਿਲ ਹਨ. extra Bibles, commentaries, lexicons, books, ਅati devotionals ਲਈ, [Getting Extra Resources from GitHub](theodia://help/getting-core-files) guide ਵੇਖੋ. ਯਹ show ਕਰਦਾ ਹੈ ਕਿ project's GitHub page ਤੋਂ resources ਕਿਵੇਂ find ਅਤੇ add ਕਰਨੇ ਹਨ.

Welcome. ਹਮ ਆਸਾ ਕਰਦੇ ਹਨ Theodia ਤੁਹਾਨੂੰ read ਅਤੇ study ਵਿਚ help ਕਰੇ.