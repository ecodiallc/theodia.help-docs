---
title: Resources ਕਯਾ ਹਨ?
level: beginner
categories: resources
summary: Theodia ਜੋ ਫਾਇਲਾ use ਕਰਦਾ ਹੈ — Bibles, commentaries, books, ਔਰ ਬੀ — ਉਨ ਦੇ ਤਰਹ-ਤਰਹ ਦਾ overview.
---

# Resources ਕਯਾ ਹਨ?

Theodia ਵਿਚ, "resource" ਏਕ ਫਾਇਲ ਹੈ ਜੋ app ਵਿਚ reading жਾ study material add ਕਰਦੀ ਹੈ. app itself ਸਿਰਫ ਏਕ reader ਅਤੇ notebook ਹੈ. ਤੁਸੀਂ ਜੋ Bibles, commentaries, books, ਔਰ ਬੀ materials study ਕਰਦੇ ਹੋ, ਵੋ ਸਾਰੇ separate files ਹਨ ਜਿਨ੍ਹਾਂ ਨੂੰ ਤੁਸੀਂ load ਕਰਦੇ ਹੋ.

ਯਹ guide different kinds of resources ਅਤ ਹਰ ਇੱਕ ਚੀ serve ਕਰਨ ਵਾਲਾ ਬਤਾਉਦਾ ਹੈ.

## ਯਹ ਕਯੋ matter ਕਰਦਾ ਹੈ?

ਜਬ ਤੁਸੀਂ ਪਹਿਲੀ ਬਾਰ Theodia ਖੋਲ੍ਹਦੇ ਹੋ, ਤਬ ਥੋਡਾ read ਕਰਨ ਲਈ already ਹੈ. explore ਕਰਦੇ ਹੋਏ, ਤੁਹਾਨੂੰ more install ਕਰਨ ਲਈ buttons ਮਿਲੇਗੇ. ਹਰ resource kind ਕਯਾ ਹੈ knowing ਤੁਹਾਨੂੰ decide ਕਰਨ ਵਿਚ help ਕਰਦਾ ਹੈ ਕਿ ਕਯਾ add ਕਰਨਾ ਹੈ.

## different kinds of resources

Theodia files ਨੂੰ ਉਨ ਦੇ extension ਨਾਲ recognize ਕਰਦਾ ਹੈ. ਹਰ extension ਏ different resource kind ਹੈ.

### `.bible` — Bible translation

Bible translation ਏਕ particular version ਦੀ ਪੂਰੀ Bible ਹੈ, ਜਿਵੇਂ King James Version. Theodia ਕੁਛ translations ਨਾਲ ਆਉਂਦਾ ਹੈ ਅਤੇ more add ਕਰਨ ਦਿਦਾ ਹੈ.

details ਲਈ [Installing Bible Translations](theodia://help/installing-bibles) guide ਵੇਖੋ.

### `.commentary` — commentary

commentary ਏਕ Bible scholar ਦਵਾਰਾ ਲਖੇ study notes ਦੀ  ਹੈ. given verse ਲਈ, commentary background, meaning, ਅਤੇ verse ਕਿਵੇਂ rest of Bible ਵਿਚ fits ਬਤਾਉਦਾ ਹੈ.

details [Commentaries and Lexicons](theodia://help/commentaries-and-lexicons) guide ਵੇਖੋ.

### `.lexicon` — lexicon

lexicon Bible words ਦਾ ਏਕ dictionary ਹੈ. ਯਹ original Hebrew жਾ Greek word, ਇਸਦਾ meaning, ਅਤੇ Bible ਵਿਚ ਇਸda use ਬਤਾਉਦਾ ਹੈ.

details [Commentaries and Lexicons](theodia://help/commentaries-and-lexicons) guide ਵੇਖੋ.

### `.book` — Christian book

book ਏਕ longer Christian work ਹੈ, church history ਦਾ classic. app ਵਿਚ book ਪਡ੍ਹਨਾ Bible ਪਡ੍ਹਨੇ ਜਿਵੇਂ ਹੀ ਹੈ. Theodia freely available Christian classics ਦੀ ਛੋਟੀ library ਨাল ਆਉਂਦਾ ਹੈ.

details [Reading Built-in Books](theodia://help/reading-books) guide ਵੇਖੋ.

### `.devotional` — devotional

devotional ਏਕ short daily reading ਹੈ. ਹਰ entry ਵਿਚ usually verse, short reflection, ਅਤੇ prayer жਾ thinking question ਹੁੰਦਾ ਹੈ. many devotionals designed ਹੋਂਦੇ ਹਨ ਏਕ entry ਏਕ year ਲਈ daily.

details [Daily Devotionals](theodia://help/daily-devotionals) guide ਵੇਖੋ.

### `.sqlite` — reference database

reference database ਏਕ large lookup file ਹੈ ਜੋ app ਤੁਹਾਨੂੰ extra information ਦਿਦਾ ਹੈ reading ਦੌਰਾਨ. two kinds ਹਨ:

- **Cross-references** — verses ਦੀ list ਜੋ ਤੁਸੀ ਪਡ੍ਹ ਰਹੇ verse ਨਾਲ connect ਹੁੰਦੀਆਂ ਹਨ.
- **Morphology** — verse ਵਿਚ original Hebrew żਾਂ Greek words ਬਾਰੇ information.

ਤੁਸੀਂ ਇਨ੍ਹਾਂ ਨੂੰ directly ਨਹੀਂ ਖੋਲ੍ਹਦੇ. ਯਹ background ਵਿਚ work ਕਰਦੇ ਹਨ ਅਤੇ Bible reader ਵਿਚ features add ਕਰਦੇ ਹਨ. details [Cross-References](theodia://help/cross-references) guide ਵੇਖੋ.

### `.data` — word data

word data file original Bible words ਬਾਰੇ extra information ਰੱਖਦੀ ਹੈ. ਯਹ lexicon ਅਤੇ study tools ਦਵਾਰਾ use ਹੁੰਦੀ ਹੈ. reference databases ਜਿਵੇਂ, ਤੁਸੀਂ ਇਸ ਨੂੰ directly ਨਹੀਂ ਖੂলਦੇ. app background ਵਿਚ use ਕਰਦਾ ਹੈ.

## resource ਕਿਵੇਂ add ਕਰਨਾ ਹੈ

app ਦਾ **Manage Resources** screen easy way ਹੈ resource add ਕਰਨ ਲਈ.

1. **Settings** ਖੋਲ੍ਹੋ.
2. **Manage Resources** 'ਤੇ tap ਕਰੋ.
3. **Install from GitHub** 'ਤੇ tap ਕਰੋ.
4. download modal ਵਿਚ ਏਕ tab ਚੁਣੋ — **Bibles**, **Commentaries**, **Books**, **Devotionals**, ਜਾ **Core** — ਫਿਰ ਚਾਹੀਦਾ ਚੁਣੋ ਅਤੇ **Install Selected** 'ਤੇ tap.
5. ਜਾ downloaded file import ਕਰん லਈ **Install Local File** 'ਤੇ tap.

GitHub ਤੌ directly files ਲੈਣ ਦਾ step-by-step walkthrough [Getting Extra Resources from GitHub](theodia://help/getting-core-files) guide ਵੇਖੋ.

## resource ਕਿਵੇਂ remove ਕਰਨਾ ਹੈ

1. **Settings** ਖੋਲ੍ਹੋ.
2. **Manage Resources** 'ਤੇ tap ਕਰੋ.
3. ਤੂਸੀ ਜ resource remove ਕਰਨਾ ਹੈ ਤੋਂਡ.
4. ਇਸ ਦੇ ਨਾਲ trash can icon 'ਤੇ tap ਕਰੋ.
5. confirm ਕਰੋ ਕਿ ਤੁਸੀਂ ਇਸ ਨੂੰ remove ਕਰਨਾ ਚਾਹੁੰਦੇ ਹੋ.

resource remove ਕਰਨ ਨਾਲ ਤੁਹਾਡੇ notes, highlights, żāṃ bookmarks ਮਿਟਦੇ ਨਹੀਂ. ਵੋ safe ਰਹਿੰਦੇ ਹਨ.

## resources device 'ਤੇ ਕਿੱਥੇ ਰਹਿੰਦੇ ਹਨ

Resources device 'ਤੇ store ਹੁੰਦੇ ਹਨ, cloud ਵਿਚ ਨহੀਂ. ਏਕ ਬਾਰ resource install ਹੋ ਜਾਏ ਤਾ internet ਦੀ ਲੋੜ ਨਹੀਂ read ਕਰਨ ਲਈ. ਤੁਸੀਂ device backup ਕਰ ਸਤੇ ਹੋ, ਪਰ resources themselves Theodia ਦਵਾਰਾ cloud 'ਤੇ backup ਨਹੀਂ ਹੁੰਦੇ. ਜਬ ਤੁਸੀਂ app uninstall ਅਤੇ reinstall ਕਰੋ, ਤਬ ਤੁਸੀਂ installed resources ਦੁбਾਰਾ add ਕਰਨੇ ਪਡੇਂਗੇ.

## ਮਦਹ ਅਤੇ ਪਰਸ਼ਨ

ਜਬ trouble ਹੂ, [Where to Ask Questions](theodia://help/getting-more-help) guide ਵੇਖੋ. team ਅਤੇ community help ਕਰ ਕਤੇ ਹਨ.