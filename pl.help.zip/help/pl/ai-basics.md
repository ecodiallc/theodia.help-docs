---
title: Podstawy AI
level: advanced
categories: ai
summary: Jak używać asystenta AI do zrozumienia wersetów.
---

# Podstawy AI

> **Tryb:** Asystent AI wymaga trybu **Badacz**. Możesz zmienić tryb w **Ustawienia** → **Tryb użytkownika**.

Theodia ma asystenta AI. Może pomóc Ci zrozumieć werset, odpowiedzieć na pytanie lub przeprowadzić rozmowę na temat biblijny.

## Jak włączyć AI

AI jest domyślnie wyłączona. Aby ją włączyć:

1. Otwórz **Ustawienia**.
2. Stuknij **Asystent AI**.
3. Stuknij przełącznik, aby włączyć AI.

## Jak otworzyć AI

Stuknij zakładkę **AI** na dole ekranu. Otworzy się okno czatu.

## Jak zadać pytanie

Stuknij pole na dole. Wpisz pytanie. Stuknij **Wyślij**.

Oto kilka przykładów pytań:

- „Co oznacza Jana 3:16?”
- „Opowiedz mi o Liście do Rzymian.”
- „Co to jest owoc Ducha?”
- „Porównaj Kazanie na Górze w Mateusza i Łukasza.”

## Jak zapytać o konkretny werset

1. Otwórz rozdział.
2. Stuknij werset, aby wyświetlić menu wersetu.
3. Stuknij **Komentarz AI**.

Werset zostanie wysłany do AI. Panel AI otworzy się z wypełnionym wersetem. Możesz dodać pytanie, na przykład „Co to znaczy?” lub „Jak to zastosować?”

## Ważne informacje

- AI to narzędzie, nie człowiek. Może popełniać błędy.
- Zawsze sprawdzaj odpowiedzi AI na podstawie samej Biblii.
- AI może wymagać internetu. Nie działa offline.
- Gdy używasz AI, Twoje pytania, kontekst wersetu i klucz API są wysyłane do wybranego punktu końcowego. Za pierwszym razem aplikacja prosi o zgodę i pokazuje dokładnie, co jest wysyłane. Możesz później zmienić lub wycofać zgodę w **Ustawienia → Asystent AI → Udostępnianie danych zdalnemu AI**.
- W niektórych regionach, takich jak chińska wersja App Store, asystent AI nie jest dostępny. W tej wersji dostępne są tylko funkcje offline Biblii.

## Jak zarządzać rozmowami

Ekran AI przechowuje listę wcześniejszych rozmów. Z listy możesz otworzyć starą rozmowę, rozpocząć nową lub usunąć niepotrzebną.

## Idź głębiej z AI

Ta strona obejmuje podstawy. AI w Theodii potrafi znacznie więcej niż tylko czat. Oto kolejne kroki:

- **[Funkcje AI](theodia://help/ai-features)** — Odkryj wszystko, co potrafi Teofil: jednym stuknięciem studium wersetu po grecku i hebrajsku, łańcuchy odniesień krzyżowych, konspekty kazań, generowanie modlitw, morfologię języków oryginalnych, wyszukiwanie w słownikach i nawigację bez użycia rąk. Ten przewodnik pokazuje, jak zamienić AI z chatbota w pełnego partnera do studiów.
- **[Pisanie lepszych poleceń AI](theodia://help/ai-prompts)** — Naucz się sztuki zadawania pytań, które przynoszą bogate i trafne odpowiedzi. Kilka drobnych zmian w sformułowaniu może znacząco poprawić odpowiedzi AI.
- **[Wybór modelu AI](theodia://help/choosing-a-model)** — Nie wszystkie modele AI są równe. Sprawdź, które modele obsługują wbudowane narzędzia Theodii (takie jak otwieranie wersetów i wyszukiwanie Pisma) i które zamieniają AI w prawdziwego asystenta do studiów biblijnych bez użycia rąk.
- **[GitHub Models](theodia://help/github-models)** — Zalecany darmowy dostawca dla Theodii. Uzyskaj bezpłatny klucz API z kontem GitHub i zacznij zadawać pytania w hojnym dziennym limicie. Bez karty kredytowej, bez subskrypcji.
- **[Klucze API i koszty](theodia://help/ai-keys-and-costs)** — Zrozum, jak działa cennik API w różnych usługach i jak utrzymać koszty blisko zera.
