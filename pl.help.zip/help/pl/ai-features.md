---
title: Funkcje AI
categories: ai
level: advanced
summary: Odkryj wszystko, co potrafi AI w Theodii — od studium wersetu po przygotowanie kazania, badanie języków oryginalnych i nawigację bez użycia rąk.
---

# Funkcje AI

> **Tryb:** Asystent AI wymaga trybu **Badacz**. Możesz zmienić tryb w **Ustawienia** → **Tryb użytkownika**.

Asystent AI w Theodii, Teofil, to nie tylko chatbot. To partner do studiów, który może czytać Biblię razem z Tobą, przeglądać komentarze, przeszukiwać Pismo, zarządzać notatkami, a nawet nawigować po aplikacji — głosem lub tekstem.

Zanim Teofil po raz pierwszy wyśle dane do punktu końcowego AI, aplikacja wyświetli prośbę o zgodę wyjaśniającą, co jest wysyłane. Możesz zmienić lub wycofać zgodę w dowolnym momencie w **Ustawienia → Asystent AI → Udostępnianie danych zdalnemu AI**.

## Czat AI przy wersie: głębokie studium jednego wersetu

**Czat AI przy wersie** to serce doświadczenia AI w Theodii. Podczas czytania dowolnego rozdziału stuknij numer wersetu (lub przytrzymaj tekst wersetu) i wybierz **Komentarz AI**. Otworzy się panel czatu z załadowanym wersetem. AI wie dokładnie, co czytasz i jest gotowa to z Tobą zbadać.

### Szybkie tematy jednym stuknięciem

Nie wiesz, co zapytać? Panel oferuje osiem gotowych tematów:

- **Wyjaśnij ten werset** — uzyskaj jasny, przemyślany opis znaczenia i znaczenia wersetu.
- **Język oryginalny** — zobacz greckie lub hebrajskie słowa, transliteracje i definicje leksykalne stojące za tekstem.
- **Kontekst historyczny** — poznaj kulturę, politykę i wydarzenia otaczające werset.
- **Kontekst tekstowy** — zobacz, jak werset pasuje do akapitu, rozdziału i księgi wokół niego.
- **Główne tematy** — odkryj wielkie idee, które ten werset wnosi do teologii biblijnej.
- **Zastosuj w moim życiu** — uzyskaj praktyczne, osobiste zastosowania, które możesz wdrożyć dziś.
- **Ułóż modlitwę** — zamień werset w modlitwę wzorowaną na jego języku i prawdach.
- **Utwórz konspekt kazania** — uzyskaj trzy punkty z wstępem i zakończeniem, gotowe do głoszenia.

Stuknij dowolny temat, a AI natychmiast zacznie. Możesz kontynuować własnymi pytaniami, prosić o wyjaśnienie lub skierować rozmowę w nowym kierunku.

### Kontynuuj jak w prawdziwej rozmowie

AI pamięta ostatnie kilka wiadomości w czacie, więc możesz naturalnie pójść głębiej:

- „Możesz to powiedzieć prościej?”
- „Co mówi oryginalny tekst grecki?”
- „Pokaż odniesienia krzyżowe związane z tym wersetem.”
- „Porównaj ten werset w trzech różnych przekładach.”
- „Jak to wygląda we współczesnym miejscu pracy?”
- „Daj mi trzy dodatkowe zastosowania dla rodzica.”

Rozmowa pozostaje przypisana do wersetu, więc każda odpowiedź opiera się na tekście, który czytasz.

### Stuknij dowolne odniesienie biblijne

Gdy AI wspomni inny werset — na przykład „To odzwierciedla Rzymian 8:28” — odniesienie pojawi się jako **klikalny link**. Stuknij je, a aplikacja przejdzie do tego fragmentu w czytniku Biblii. Możesz badać łańcuch odniesień bez opuszczania rozmowy.

## Co AI potrafi poza czatem przy wersie

Teofil ma dostęp do całej zawartości Theodii — Biblii, komentarzy, leksykonów, słowników, ksiąg, rozważań, Twoich notatek, zakładek i podświetleń. Oto co to oznacza w praktyce.

### Czytanie i nawigacja po Piśmie

- **Czytaj dowolny werset lub rozdział** — „Przeczytaj Jana 3:16 w WEB” lub „Przeczytaj Psalm 23 na głos.”
- **Otwieraj fragmenty w czytniku** — „Przejdź do Rodzaju 1” lub „Otwórz Rzymian 8:28.”
- **Porównuj wersje** — „Pokaż mi Jana 3:16 we wszystkich moich Bibliach.”
- **Przeszukuj Biblię** — „Znajdź wersety o przebaczeniu” lub „Wyszukaj «pokój który przewyższa rozum».”
- **Uzyskaj odniesienia krzyżowe** — „Jakie inne wersety odnoszą się do Izajasza 53:5?”
- **Czytaj nagłówki sekcji** — „Jakie są podtytuły w Mateusza 5?”

### Badanie języków oryginalnych

- **Wyszukiwanie w leksykonie** — „Co oznacza greckie słowo «agape» w Jana 3:16?” lub „Sprawdź Stronga G26.”
- **Morfologia** — „Odmień greckie czasowniki w Rzymian 8:28” lub „Co oznacza kod morfologiczny V-PAI-3S?”
- **Informacje o słowie** — AI widzi tę samą analizę słowo po słowie co Ty w aplikacji: transliterację, glossę, gramatykę i numery Stronga.

### Czytanie komentarzy i ksiąg studialnych

- **Komentarz do wersetu** — „Co Matthew Henry mówi o Efezjan 2:8?”
- **Komentarz do rozdziału** — „Daj mi przegląd rozdziału Rzymian 8.”
- **Komentarz do księgi** — „Podsumuj komentarz na poziomie księgi do Apokalipsy.”
- **Księgi studialne** — „Przeczytaj mi rozdział z Hymn Lyrics English” lub „Przeszukaj moje księgi pod kątem «cierpliwości».”
- **Rozważania** — „Przeczytaj dzisiejsze rozważanie” lub „Znajdź rozważanie o niepokoju.”

### Wyszukiwanie w słownikach

- „Kim był Melchizedek?”
- „Co mówi słownik biblijny o Gilgal?”
- „Sprawdź «zadośćuczynienie» w Eastona.”

### Zarządzanie życiem studialnym

AI może działać na Twoich osobistych danych — zawsze przechowywanych lokalnie na urządzeniu:

- **Zakładki** — „Dodaj ten werset do folderu Przygotowanie kazania” lub „Wyświetl moje zakładki.”
- **Podświetlenia** — „Podświetl Jana 3:16 na żółto” lub „Pokaż wszystkie moje podświetlenia.”
- **Notatki** — „Utwórz notatkę biblijną do tego wersetu” lub „Przeczytaj moje notatki do Rodzaju 1.”
- **Notatki ze studiów** — „Zapisz tę rozmowę jako notatkę ze studiów” lub „Utwórz nową księgę notatek ze studiów o nazwie Studium Rzymian.”
- **Foldery** — „Utwórz folder Poranna dewocja” lub „Przenieś moją zakładkę Jana 3:16 do folderu Modlitwa.”

### Zmiana ustawień aplikacji

- „Przełącz na tryb ciemny.”
- „Ustaw BSB jako moją domyślną Biblię.”
- „Włącz Biblię równoległą z NET.”
- „Zwiększ rozmiar czcionki.”

### Czytanie na głos

- „Przeczytaj Psalm 23 na głos” — AI może uruchomić syntezator mowy dla dowolnego fragmentu, księgi lub notatki.
- „Zatrzymaj czytanie” — wstrzymaj TTS w dowolnym momencie.

## Zapisywanie rozmów

Każdy czat AI przy wersie można zapisać. Stuknij menu w panelu czatu i wybierz:

- **Zapisz jako notatka biblijna** — dołącza całą rozmowę do notatki wersetu w czytniku Biblii.
- **Zapisz jako notatka ze studiów** — przechowuje rozmowę w księdze notatek ze studiów do późniejszego wykorzystania.

To zamienia szybką eksplorację AI w trwały materiał studialny, który można później przeglądać, edytować lub wykorzystywać do kazań.

## Pełna zakładka AI

Oprócz panelu czatu przy wersie Theodia ma dedykowaną zakładkę **AI** w dolnym pasku nawigacji. To czat dowolny, w którym możesz zapytać o cokolwiek — bez uprzedniego wyboru wersetu. Użyj go do:

- Studiów tematycznych w całej Biblii
- Badań i konspektów kazań
- Porównywania tematów teologicznych między księgami
- Codziennej dewocji i podpowiedzi modlitewnych
- Biblijnej ciekawostki i planów czytania
- Pomocy w aplikacji — „Jak działa Biblia równoległa?”

Twoje rozmowy są zapisywane automatycznie. Możesz wracać do wcześniejszych czatów, zaczynać nowe i usuwać stare wątki.

## Pomysły na początek

Oto kilka ekscytujących sposobów na użycie AI. Wybierz jeden i wypróbuj go dziś.

**Rozwój osobisty**

- „Wyjaśnij Filipian 4:6–7 i ułóż modlitwę na czas niepokoju.”
- „Co Biblia mówi o odpoczynku? Znajdź mi pięć wersetów i wyjaśnij każdy.”

**Rodzina i rodzicielstwo**

- „Jak Efezjan 6:4 powinien kształtować współczesne rodzicielstwo? Daj mi trzy praktyczne zasady.”
- „Znajdź wersety o wychowywaniu dzieci i przeczytaj je na głos.”

**Przygotowanie kazania i nauczania**

- „Narysuj konspekt 25-minutowego kazania na podstawie Rzymian 8:28 z wstępem, trzema punktami i zakończeniem.”
- „Co mówią moje komentarze o «zbroi Bożej» w Efezjan 6?”
- „Porównaj Kazanie na Górze w Mateusza z wersją Łukasza. Jakie są różnice?”

**Studium języków oryginalnych**

- „Pokaż morfologię każdego słowa w Jana 1:1.”
- „Jaka jest różnica między «agape» a «philia» w Nowym Testamencie?”

**Głębia dewocyjna**

- „Przeczytaj dzisiejsze rozważanie i połącz je z wersetem z Psalmów.”
- „Daj mi siedmiodniowy plan dewocyjny na temat owocu Ducha.”

**Łańcuchy odniesień krzyżowych**

- „Zacznij od Izajasza 53:5 i prześledź motyw «ran» i «uzdrowienia» przez Nowy Testament.”
- „Gdzie pojawia się pojęcie «przymierza» od Rodzaju do Hebrajczyków?”

**Pamięć i powtórki**

- „Sprawdzij mnie z kolejności ksiąg Biblii.”
- „Utwórz notatkę ze studiów podsumowującą główną myśl każdego rozdziału Rzymian.”

## Kilka ważnych uwag

- AI to **narzędzie**, nie zamiennik Biblii czy drogi duchownego. Zawsze porównuj jej odpowiedzi z samym Pismem.
- Gdy używasz AI, Twoje pytania podróżują przez internet na serwery dostawcy. Większość dostawców nie uczy się na Twoich danych, ale tekst opuszcza Twoje urządzenie.
- AI może popełniać błędy. Za ostateczną autorytet przyjmuj komentarze, leksykony i sam tekst Biblii.

## Podsumowanie

AI w Theodii ma na celu uczynić studium Biblii szybszym, głębszym i bardziej osobistym. Niezależnie od tego, czy chcesz jednozdaniowego wyjaśnienia niezrozumiałego wersetu, pełnego konspektu kazania, greckiego studium słowa czy łańcucha odniesień krzyżowych obejmującego całą Biblię — Teofil jest gotowy pomóc. Stuknij werset, zadaj pytanie i zobacz, dokąd zaprowadzi Cię rozmowa.
