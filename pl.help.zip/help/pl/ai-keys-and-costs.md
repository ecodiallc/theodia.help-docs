---
title: Klucze API i koszty
level: advanced
categories: ai
summary: Dlaczego potrzebujesz klucza API, jak go uzyskać i ile zazwyczaj kosztuje korzystanie ze zdalnego modelu AI.
---

# Klucze API i koszty

> **Tryb:** Asystent AI wymaga trybu **Badacz**. Możesz zmienić tryb w **Ustawienia** → **Tryb użytkownika**.

Asystent AI łączy się ze zdalnymi modelami AI. Jeśli chcesz z nich korzystać, potrzebujesz klucza API. Ta strona wyjaśnia dlaczego, jak go uzyskać i ile to zazwyczaj kosztuje.

## Dlaczego potrzebujesz klucza API

Zdalny model AI działa na serwerze w internecie. Klucz API jest jak hasło, które mówi serwerowi: „Ta osoba może zadawać pytania.” Bez niego serwer nie odpowie.

Aplikacja nie dostarcza wbudowanego klucza. Musisz utworzyć własne konto u dostawcy i wkleić klucz do aplikacji.

## Jak uzyskać klucz API

1. Otwórz **Ustawienia** w Theodii.
2. Stuknij **Asystent AI**.
3. Wybierz **Model zdalny**.
4. Wybierz dostawcę z listy lub wybierz **Niestandardowy** i wpisz adres URL.
5. Stuknij link do strony klucza dostawcy. Utwórz konto, jeśli go nie masz.
6. Wygeneruj nowy klucz API na stronie dostawcy.
7. Skopiuj klucz i wklej go do Theodii.
8. Stuknij **Sprawdź połączenie**, aby upewnić się, że działa.

## Obsługiwani dostawcy

Theodia może łączyć się z dowolnym dostawcą używającym API zgodnego z OpenAI. Oto ci, dla których aplikacja ma gotowe linki:

- **GitHub Models** — github.com/marketplace/models (darmowy limit dzienny, zalecane)
- **OpenAI** — platform.openai.com
- **OpenRouter** — openrouter.ai
- **Anthropic** — console.anthropic.com
- **Groq** — console.groq.com
- **Mistral** — console.mistral.ai
- **Together AI** — api.together.xyz

Możesz też użyć **Niestandardowego** adresu URL, jeśli uruchamiasz własny serwer lub korzystasz z innej usługi.

## Ile to kosztuje?

Większość dostawców nalicza opłaty za **token**. Token to mniej więcej słowo lub jego część. Płacisz za tokeny, które wysyłasz (Twoje pytanie), oraz za tokeny, które zwraca AI (odpowiedź).

### Przykładowe ceny

Ceny się zmieniają, ale oto przybliżone wartości na połowę 2026 roku:

- **Małe, szybkie modele** (takie jak tańsze endpointy z klasy GPT-3.5) kosztują ułamek centa za tysiąc tokenów.
- **Modele średniej klasy** (takie jak GPT-4o lub Claude Sonnet) zazwyczaj kosztują kilka centów za tysiąc tokenów.
- **Duże modele rozumujące** (takie jak GPT-4.5 lub Claude Opus) mogą kosztować od dziesięciu do dwudziestu centów za tysiąc tokenów.

Typowe pytanie biblijne w Theodii może użyć od kilkuset do kilku tysięcy tokenów łącznie. Oznacza to, że większość pytań kosztuje od **mniej niż centa do kilku centów**.

### Wskazówki, aby obniżyć koszty

- Zacznij od tańszego modelu. Większość pytań biblijnych nie wymaga najdroższego modelu.
- Użyj Groq lub OpenRouter, jeśli chcesz testować różne modele i porównywać ceny.
- Śledź panel zużycia na stronie dostawcy.

## GitHub Models

[GitHub Models](https://github.com/marketplace/models) oferuje darmowy poziom bez subskrypcji. Wystarczy bezpłatne konto GitHub i osobisty token dostępu z uprawnieniem do odczytu modeli.

**Jak to skonfigurować:**

1. Wejdź na [github.com/settings/tokens](https://github.com/settings/tokens) i utwórz **Personal access token (classic)**.
2. Nadaj mu zakres `models:read` (lub po prostu wybierz uprawnienie do modeli).
3. W Theodii wybierz **GitHub Models** jako dostawcę i wklej swój token.

**Modele w darmowym poziomie:**

- `openai/gpt-4.1-nano` — **15 zapytań na minutę, 150 zapytań dziennie**
- `openai/gpt-4.1-mini` — **15 zapytań na minutę, 150 zapytań dziennie**
- `openai/gpt-4.1` — **10 zapytań na minutę, 50 zapytań dziennie**
- `openai/gpt-4o` — **10 zapytań na minutę, 50 zapytań dziennie**

Te limity resetują się codziennie i wystarczają na regularne studium Biblii.

Aby uzyskać pełny przewodnik krok po kroku ze zrzutami ekranu, zobacz dedykowany przewodnik [GitHub Models](theodia://help/github-models).

## Uwaga o prywatności

Gdy używasz zdalnego modelu AI, aplikacja najpierw wyświetla prośbę o zgodę wyjaśniającą, co jest wysyłane: Twoje wiadomości, kontekst wersetu lub rozdziału, wywołania narzędzi i ich wyniki, skonfigurowaną nazwę modelu oraz Twój klucz API w nagłówku żądania. Żądanie trafia bezpośrednio do skonfigurowanego przez Ciebie punktu końcowego, nie przez serwery Theodii. Większość dostawców nie używa Twoich danych do trenowania modeli, ale tekst opuszcza Twoje urządzenie. Możesz w dowolnym momencie zmienić lub wycofać zgodę w **Ustawienia → Asystent AI → Udostępnianie danych zdalnemu AI**.

## Podsumowanie

- Aby korzystać z asystenta AI, potrzebujesz klucza API.
- Utwórz konto u dostawcy, wygeneruj klucz i wklej go do Theodii.
- Większość pytań kosztuje kilka centów lub mniej.
