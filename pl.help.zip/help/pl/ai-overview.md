---
title: Asystent AI
level: advanced
category: ai
summary: Jak używać asystenta AI do zrozumienia wersetów.
---

# Asystent AI

Theodia ma asystenta AI. Może pomóc Ci zrozumieć werset, odpowiedzieć na pytanie lub przeprowadzić rozmowę na temat biblijny.

## Jak włączyć AI

AI jest domyślnie wyłączona. Aby ją włączyć:

1. Otwórz **Ustawienia**.
2. Stuknij **Asystent AI**.
3. Stuknij przełącznik, aby włączyć AI.

Może być konieczne skonfigurowanie konta lub klucza. Aplikacja Cię przeprowadzi przez to.

## Jak otworzyć AI

Stuknij zakładkę **AI** na dole ekranu. Otworzy się okno czatu.

## Jak zadać pytanie

Stuknij pole na dole. Wpisz pytanie. Stuknij **Wyślij**.

Oto kilka przykładów pytań:

- „Co oznacza Jana 3:16?”
- „Opowiedz mi o Liście do Rzymian.”
- „Co to jest owoc Ducha?”
- „Porównaj Kazanie na Górze w Mateusza i Łukasza.”

## Jak zapytać o konkretny werset

1. Otwórz rozdział.
2. Stuknij werset, aby wyświetlić menu wersetu.
3. Stuknij **Komentarz AI**.

Werset zostanie wysłany do AI. Panel AI otworzy się z wypełnionym wersetem. Możesz dodać pytanie, na przykład „Co to znaczy?” lub „Jak to zastosować?”

## Ważne informacje

- AI to narzędzie, nie człowiek. Może popełniać błędy.
- Zawsze sprawdzaj odpowiedzi AI na podstawie samej Biblii.
- AI może wymagać internetu. Nie działa offline.
- Gdy używasz AI, Twoje pytania, kontekst wersetu i klucz API są wysyłane do wybranego punktu końcowego. Za pierwszym razem aplikacja prosi o zgodę i pokazuje dokładnie, co jest wysyłane. Możesz później zmienić lub wycofać zgodę w **Ustawienia → Asystent AI → Udostępnianie danych zdalnemu AI**.
- W niektórych regionach, takich jak chińska wersja App Store, asystent AI nie jest dostępny. W tej wersji dostępne są tylko funkcje offline Biblii.

## Jak zarządzać rozmowami

Ekran AI przechowuje listę wcześniejszych rozmów. Z listy możesz otworzyć starą rozmowę, rozpocząć nową lub usunąć niepotrzebną.

Aby uzyskać bardziej zaawansowane wskazówki, zobacz przewodnik [Pisanie lepszych poleceń AI](theodia://help/ai-prompts).
