---
title: Pisanie lepszych poleceń AI
level: advanced
categories: ai
summary: Jak zadawać pytania asystentowi AI, aby otrzymywać dobre odpowiedzi.
---

# Pisanie lepszych poleceń AI

> **Tryb:** Asystent AI wymaga trybu **Badacz**. Możesz zmienić tryb w **Ustawienia** → **Tryb użytkownika**.

„Polecenie” to pytanie lub instrukcja, którą dajesz AI. Lepsze polecenia dają lepsze odpowiedzi. Ten przewodnik pokazuje, jak je pisać.

## Bądź konkretny

Źle: „Opowiedz mi o miłości.”
Lepiej: „W 1 Koryntian 13, jaką miłość opisuje Paweł i czym różni się od miłości romantycznej?”

Im więcej szczegółów podasz, tym bardziej przydatna będzie odpowiedź.

## Podaj kontekst

Źle: „Co oznacza ten werset?”
Lepiej: „Czytam Rzymian 8 w małej grupie. Co oznacza «brak potępienia» w tym rozdziale i jak łączy się z resztą rozdziału?”

Kontekst pomaga AI dostosować odpowiedź do Twojej sytuacji.

## Pytaj o jedną rzecz na raz

Źle: „Opowiedz mi o modlitwie, wierze i uzdrawianiu.”
Lepiej: „Najpierw opowiedz mi o modlitwie. Potem zapytam o wiarę.”

Pytanie o jedną rzecz na raz utrzymuje odpowiedzi w skupieniu.

## Poproś AI o przyjęcie roli

Możesz poprosić AI, aby odpowiedziała określonym głosem. Na przykład:

- „Odpowiedz, jakbyś uczył nowego chrześcijanina.”
- „Odpowiedz jak biblistyczny uczony.”
- „Odpowiedz dla dziesięciolatka.”

AI dostosuje odpowiedź do roli.

## Używaj pytań uzupełniających

Jeśli pierwsza odpowiedź nie jest do końca właściwa, zadaj pytanie uzupełniające:

- „Możesz to powiedzieć prościej?”
- „Możesz podać przykład?”
- „Co mówi oryginalny tekst grecki?”
- „Gdzie jeszcze w Biblii się to pojawia?”

Dobra rozmowa to wymiana zdań. AI pamięta ostatnie kilka wiadomości.

## Sprawdzaj odpowiedzi AI

AI może popełniać błędy. To narzędzie, nie nauczyciel.

- Porównaj odpowiedź AI z wersetami, do których Cię odsyła.
- Użyj komentarzy i leksykonów w aplikacji, aby uzyskać drugą opinię.
- Jeśli odpowiedź dotyczy doktryny, zapytaj pastora lub zaufanego przyjaciela.

## Wzorce poleceń, które działają

Oto kilka sprawdzonych wzorów:

- „Wyjaśnij mi ten werset, jakbym był nowym chrześcijaninem.”
- „Jaka jest główna myśl tego rozdziału w jednym zdaniu?”
- „Wymień trzy zastosowania do mojego codziennego życia z tego fragmentu.”
- „Jakie pytania powinienem zadać o ten werset, zanim go będę głosić?”
