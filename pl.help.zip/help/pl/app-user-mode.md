---
title: Tryb użytkownika
level: beginner
categories: [user-mode]
summary: Wybieraj między trybami Czytelnik, Standardowy i Badacz, aby kontrolować, które funkcje są dostępne w aplikacji.
---

# Tryb użytkownika

Theodia oferuje trzy tryby użytkownika, które kontrolują widoczne funkcje. Wybierz ten, który najlepiej odpowiada sposobowi, w jaki chcesz korzystać z aplikacji.

## Czytelnik

Najprostszy tryb. Tryb **Czytelnik** służy do czytania Biblii bez rozpraszania uwagi.

- Czytaj dowolny przekład Biblii
- Używaj **Trybu skupienia** do czystego, pełnoekranowego czytania
- Nawiguj po księgach i rozdziałach
- Brak narzędzi studialnych, AI, zakładek i podświetleń

Tryb Czytelnik jest idealny, jeśli chcesz, aby Theodia była prostą cyfrową Biblią bez dodatków.

## Standardowy

Tryb **Standardowy** dodaje codzienne funkcje do osobistego studium Biblii.

Wszystko z trybu Czytelnik, plus:

- Zakładki, podświetlenia i notatki
- Czytanie na głos
- Czytnik studyjny z menu wersetu
- Biblię równoległą
- Szybkie polecenie
- Wyszukiwanie w Biblii
- Codzienne rozważania i wbudowane księgi

Tryb Standardowy to właściwy wybór dla większości użytkowników, którzy chcą czytać, oznaczać i przeszukiwać Biblię bez zaawansowanych narzędzi studialnych.

## Badacz

Pełny tryb. Tryb **Badacz** odblokowuje wszystkie narzędzia Theodii do głębokiego studium Biblii.

Wszystko z trybu Standardowy, plus:

- Komentarze i leksykony
- Odniesienia krzyżowe
- Słownik biblijny
- Informacje o słowie (wyszukiwanie Stronga)
- Asystent AI i Komentarz AI
- Menu szybkiego dostępu

Tryb Badacz jest przeznaczony dla pastorów, studentów seminarium i każdego, kto chce korzystać z narzędzi języków oryginalnych oraz wsparcia AI.

## Jak zmienić tryb

1. Otwórz **Ustawienia**.
2. Stuknij **Tryb użytkownika**.
3. Wybierz **Czytelnik**, **Standardowy** lub **Badacz**.

Zmiana następuje natychmiast. Menu i przyciski niedostępne w bieżącym trybie zostają ukryte.

## Wybór trybu

- **Czytelnik** — Chcesz tylko czytać Biblię, nic więcej.
- **Standardowy** — Chcesz zakładki, podświetlenia, notatki, wyszukiwanie i rozważania.
- **Badacz** — Chcesz wszystkie narzędzia studialne, w tym AI, komentarze i leksykony.

Możesz zmieniać tryby w dowolnym momencie. Twoje zakładki, podświetlenia i notatki nigdy nie są usuwane przy zmianie trybu; po prostu są ukryte, dopóki nie wrócisz do trybu, który je obsługuje.
