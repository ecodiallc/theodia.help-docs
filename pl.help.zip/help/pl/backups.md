---
title: Tworzenie kopii zapasowych danych
level: everyday
categories: settings
summary: Jak zapisać i przywrócić notatki, podświetlenia, zakładki i ustawienia.
---

# Tworzenie kopii zapasowych danych

Twoje notatki, podświetlenia, zakładki i ustawienia są zapisywane na urządzeniu. Jeśli zgubisz telefon, kupisz nowy lub odinstalujesz aplikację, te dane mogą zniknąć. Ten przewodnik pokazuje, jak je zabezpieczyć.

## Jak otworzyć ustawienia kopii zapasowej

1. Otwórz **Ustawienia**.
2. Stuknij **Kopia zapasowa aplikacji**.

## Jak utworzyć kopię zapasową aplikacji

1. Otwórz **Ustawienia**.
2. Stuknij **Kopia zapasowa aplikacji**.
3. Stuknij **Utwórz kopię zapasową aplikacji**.
4. Wybierz folder na urządzeniu, w którym chcesz zapisać plik. Możesz też wybrać dysk w chmurze.
5. Aplikacja utworzy jeden plik zawierający wszystkie dane. Plik kończy się rozszerzeniem `.zip`.

## Jak często robić kopię zapasową

Wykonuj kopię zapasową:

- Po napisaniu wielu notatek.
- Przed aktualizacją systemu operacyjnego urządzenia.
- Przed odinstalowaniem aplikacji lub zmianą telefonu.

Dobrym nawykiem jest jedna kopia zapasowa miesięcznie. Niektórzy robią ją co tydzień.

## Jak przywrócić z kopii zapasowej aplikacji

1. Otwórz **Ustawienia**.
2. Stuknij **Kopia zapasowa aplikacji**.
3. Stuknij **Przywróć z kopii zapasowej aplikacji**.
4. Wybierz plik kopii zapasowej `.zip`.
5. Dla każdego rodzaju danych (notatki, podświetlenia, zakładki itp.) wybierz, czy zachować dane na urządzeniu, zastąpić je kopią zapasową, czy pominąć.
6. Stuknij **Przywróć**.

Aplikacja zastępuje Twoje dane danymi z kopii zapasowej. Obejmuje to:

- Notatki
- Podświetlenia
- Zakładki
- Foldery zakładek
- Ustawienia (motyw, rozmiar czcionki, język)

## Kopia zapasowa sekretów

**Kopia zapasowa aplikacji** **nie zawiera** wrażliwych sekretów, takich jak klucz API AI czy token GitHub. Aby zabezpieczyć je osobno, użyj **Kopii zapasowej sekretów**.

### Zapisywanie kopii zapasowej sekretów

1. Otwórz **Ustawienia**.
2. Stuknij **Kopia zapasowa aplikacji**.
3. W sekcji **Kopia zapasowa sekretów** stuknij **Zapisz kopię zapasową sekretów**.
4. Wpisz silne hasło i potwierdź je.
5. Aplikacja zaszyfruje Twoje sekrety i udostępni zaszyfrowany plik. Zapisz go w bezpiecznym miejscu.

### Przywracanie kopii zapasowej sekretów

1. Otwórz **Ustawienia**.
2. Stuknij **Kopia zapasowa aplikacji**.
3. W sekcji **Kopia zapasowa sekretów** stuknij **Przywróć kopię zapasową sekretów**.
4. Wybierz zaszyfrowany plik kopii zapasowej sekretów.
5. Wpisz to samo hasło, którego użyłeś podczas zapisywania.
6. Twoje sekrety zostaną przywrócone.

> **Ważne:** Jeśli zapomnisz hasła, sekretów nie da się odzyskać. Nie ma resetu.

## Informacje

- Przywracanie **zastępuje** wybrane kategorie. Wszystko, co dodałeś po wykonaniu kopii zapasowej, zostanie utracone dla tych kategorii.
- Kopia zapasowa aplikacji to jeden plik `.zip`. Przechowuj go w bezpiecznym miejscu.
- Możesz kopiować, przenosić lub przechowywać plik w dowolnej usłudze chmurowej.
- Kopie zapasowe aplikacji nie zawierają samych przekładów Biblii. Można je ponownie pobrać w **Ustawienia** → **Zarządzaj zasobami**.
- Kopie zapasowe sekretów są szyfrowane Twoim hasłem. Wybierz hasło, które zapamiętasz.

## Wskazówka

Jeśli masz więcej niż jedno urządzenie, możesz skopiować plik kopii zapasowej na każde z nich i przywrócić go. Twoje dane będą takie same na obu.
