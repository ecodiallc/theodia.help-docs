---
title: Dodawanie zakładek do wersetów
level: everyday
categories: [annotate, read]
summary: Jak zapisywać wersety, aby móc do nich wrócić.
---

# Dodawanie zakładek do wersetów

> **Tryb:** Zakładki są dostępne w trybach **Standardowy** i **Badacz**. Tryb skupienia służy tylko do czystego czytania bez rozpraszania uwagi. Możesz zmienić tryb w **Ustawienia** → **Tryb użytkownika**.

Zakładka zapisuje werset lub rozdział księgi, abyś mógł do niego wrócić. Zakładki działają jak zakładki w książce.

## Jak dodać zakładkę do wersetu

1. Otwórz werset.
2. Stuknij werset, aby wyświetlić menu.
3. Stuknij **Zakładka** w menu. Ikona gwiazdki oznacza zapisany werset.

Znaczek wyboru na ikonie oznacza, że werset jest teraz dodany do zakładek.

## Jak dodać zakładkę do rozdziału księgi

Podczas czytania księgi (nie Biblii) możesz dodać zakładkę do całego rozdziału:

1. Otwórz rozdział.
2. Stuknij ikonę **Zakładka** u góry ekranu.

## Jak wyświetlić swoje zakładki

Stuknij zakładkę **Zakładki** na dole ekranu. Zobaczysz listę każdego zapisanego wersetu i rozdziału księgi.

## Jak usunąć zakładkę

- **Jeden werset:** Otwórz werset. Stuknij werset, a następnie ponownie stuknij ikonę **Zakładka**. Znaczek wyboru zniknie.
- **Z listy:** Na zakładce **Zakładki** przytrzymaj zakładkę. Pojawi się małe menu. Stuknij **Usuń**. (Możesz też stuknąć mały przycisk × w wierszu.)

## Organizuj za pomocą folderów

Możesz umieszczać zakładki w folderach. Na przykład możesz mieć folder „Przygotowanie kazania” i inny „Pociecha.”

Aby utworzyć folder:

1. Otwórz zakładkę **Zakładki**.
2. Stuknij **Zarządzaj folderami** u góry.
3. Stuknij **Utwórz folder** u góry listy folderów.
4. Wpisz nazwę i stuknij **Zapisz**.

Nie możesz utworzyć dwóch folderów o tej samej nazwie. Jeśli nazwa już istnieje, w polu tworzenia folderu pojawi się błąd, dzięki czemu możesz zmienić nazwę i spróbować ponownie.

Aby umieścić zakładkę w folderze:

1. Na zakładce **Zakładki** przytrzymaj zakładkę.
2. Stuknij **Przenieś do folderu**.
3. Wybierz folder, a następnie stuknij **Gotowe**.

## Importowanie zakładek

Możesz importować zakładki do Theodii z innych aplikacji i plików.

Przejdź do **Ustawienia** → **Zakładki** → **Importuj zakładki**. Wybierz **Importuj z pliku** lub wklej ze schowka. Aplikacja automatycznie wykryje format.

### Obsługiwane formaty

**Natywny eksport JSON** — format używany przez własną funkcję eksportu Theodii. Zachowuje foldery i daty utworzenia.

**Netscape Bookmark HTML** — format używany przez Chrome, Firefox i Safari podczas eksportu zakładek. Foldery są zachowane.

**CSV** — arkusz kalkulacyjny z kolumnami. Aplikacja szuka kolumn `url` i `folder` (lub `href` / `category`). Przykład:

```csv
url,folder
/bible/KJV/John/3,Favorites
/bible/KJV/Genesis/1,Sermon Prep
```

**Zwykły tekst** — każdy wiersz to albo odniesienie biblijne, albo adres URL aplikacji, albo dyrektywa folderu. Przykład:

```
folder: Favorites
John 3:16
Genesis 1:1
folder: Sermon Prep
Matthew 5:1
```

- Wiersze zaczynające się od `folder: <nazwa>` ustawiają aktywny folder dla kolejnych zakładek.
- Odniesienia biblijne, takie jak `John 3:16`, są konwertowane na zakładki w Twojej domyślnej Biblii.
- Adresy URL aplikacji, takie jak `/bible/KJV/John/3#v3_16` lub `/book/MyBook/1`, są importowane bezpośrednio.
- Wiersze zaczynające się od `#` lub `//` są traktowane jako komentarze i pomijane.

### Wskazówki dotyczące importu

- Duplikaty zakładek są automatycznie pomijane.
- Zewnętrzne adresy URL (takie jak linki BibleGateway) są konwertowane na zakładki aplikacji, gdy to możliwe.
- Jeśli folder z pliku importu już istnieje, zakładki trafiają do istniejącego folderu.

## Wskazówki

- Możesz dodać do zakładek ten sam werset w wielu przekładach. Wszystkie pojawią się na liście.
- Zakładki pozostają na Twoim urządzeniu. Nie są synchronizowane z chmurą.
- Zobacz przewodnik [Tworzenie kopii zapasowych danych](theodia://help/backups), aby je zabezpieczyć.
