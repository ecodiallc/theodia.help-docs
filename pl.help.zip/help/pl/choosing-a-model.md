---
title: Wybór modelu AI
level: advanced
categories: ai
summary: Jak wybrać model dobrze współpracujący z wbudowanymi narzędziami i możliwościami Theodii.
---

# Wybór modelu AI

> **Tryb:** Asystent AI wymaga trybu **Badacz**. Możesz zmienić tryb w **Ustawienia** → **Tryb użytkownika**.

Nie każdy model AI działa w Theodii tak samo. Najlepsze doświadczenie zapewnia model obsługujący **wywoływanie narzędzi** — zdolność AI do korzystania z wbudowanych funkcji Theodii, takich jak wyszukiwanie wersetów, przeszukiwanie Pisma, czytanie komentarzy i nawigacja po aplikacji.

## Czym jest wywoływanie narzędzi?

Gdy zadasz pytanie asystentowi AI w Theodii, AI może zrobić więcej niż tylko mówić. Może też **działać**. Na przykład:

- Mówisz: „Pokaż mi Jana 3:16 w ESV.” AI wywołuje narzędzie, aby otworzyć ten werset w czytniku.
- Mówisz: „Co mówią moje komentarze o Rzymian 8:28?” AI wywołuje narzędzie, aby pobrać treść komentarza.
- Mówisz: „Zapisz ten werset jako zakładkę.” AI wywołuje narzędzie, aby utworzyć zakładkę.

Modele, które nie obsługują wywoływania narzędzi, mogą dawać tylko tekstowe odpowiedzi. Nie mogą niczego wyszukiwać, nawigować ani zmieniać w aplikacji.

## Które modele obsługują narzędzia?

### Modele zdalne

Większość nowoczesnych zdalnych modeli dużych dostawców obsługuje wywoływanie narzędzi zgodne z OpenAI. Ogólnie:

- **Duże modele** (takie jak GPT-4o, Claude Sonnet/Opus, Gemini Pro) niezawodnie obsługują narzędzia i mogą łączyć wiele wywołań narzędzi w jednej rozmowie. Nazwy dostawców i identyfikatory modeli są pokazywane w aplikacji dla wygody; rzeczywistą usługę, z którą się łączysz, określa skonfigurowany przez Ciebie punkt końcowy i klucz.
- **Mniejsze lub tańsze modele** mogą obsługiwać narzędzia, ale być mniej niezawodne. Mogą zignorować wywołanie narzędzia lub sformatować je niepoprawnie.
- **Bardzo stare lub wyspecjalizowane modele** często nie obsługują narzędzi wcale.

Jeśli nie masz pewności, przetestuj model w Theodii. Zapytaj „Pokaż mi Rodzaju 1:1” lub „Wyszukaj w Biblii wersety o miłości.” Jeśli werset się otworzy lub pojawią się wyniki wyszukiwania, wywoływanie narzędzi działa.

## Zalecane modele dla Theodii

To dobre wybory, które łączą koszt, jakość i obsługę narzędzi:

- **OpenAI GPT-4o** — doskonała obsługa narzędzi, szybkość, dobrze radzi sobie ze złożonymi, wielokrokowymi pytaniami.
- **Anthropic Claude Sonnet / Opus** — bardzo niezawodne użycie narzędzi, świetne do długich fragmentów i szczegółowych studiów.
- **Groq** (różne modele) — szybkie wnioskowanie, często darmowe lub bardzo tanie, obsługa narzędzi zależy od modelu.
- **OpenRouter** — pozwala testować wiele modeli z jednego konta. Szukaj modeli, które w swoich możliwościach wymieniają „function calling” lub „tools”.
- **[GitHub Models](theodia://help/github-models)** — zalecany darmowy dostawca. Dostęp do modeli OpenAI, Anthropic i innych przez Twoje konto GitHub z hojnym dziennym limitem darmowym. Używa tych samych identyfikatorów modeli w stylu `openai/gpt-4o`.

## Modeli, których lepiej unikać

- **Modele czysto tekstowe** (takie jak podstawowy GPT-3 lub surowy LLaMA bez dostrojenia instrukcji) zazwyczaj nie obsługują narzędzi.
- **Modele tylko obrazowe lub wizyjne** skupione na obrazach mogą nie mieć obsługi narzędzi.
- **Bardzo małe modele** poniżej 1 miliarda parametrów mogą nie używać narzędzi poprawnie, nawet jeśli API twierdzi, że je obsługują.

## Jak przetestować obsługę narzędzi

Theodia automatycznie sprawdza obsługę narzędzi. Po skonfigurowaniu modelu w **Ustawienia → Asystent AI** stuknij **Sprawdź połączenie**. Gdy połączenie się powiedzie, aplikacja wysyła drugie żądanie z przykładową definicją narzędzia. Zobaczysz jeden z dwóch wyników:

- **✓ Narzędzia obsługiwane** — model akceptuje wywołania narzędzi i może korzystać z wbudowanych funkcji Theodii.
- **✗ Narzędzia nieobsługiwane** — model odrzuca żądanie narzędzia. Będzie odpowiadał tylko tekstem i nie może otwierać wersetów, wyszukiwać ani zarządzać zakładkami.

Jeśli zobaczysz „Narzędzia nieobsługiwane”, model nadal może działać jako zwykły tekstowy asystent czatu, ale nie uzyskasz zintegrowanego doświadczenia bez użycia rąk.

Możesz też sprawdzić ręcznie, prosząc AI o coś:

- „Pokaż mi Mateusza 5:3 w KJV.” — Powinien otworzyć werset w czytniku.
- „Co mówi leksykon o słowie «agape» w Jana 3:16?” — Powinien zwrócić dane leksykonu.
- „Wyszukaj w Biblii wersety o przebaczeniu.” — Powinien zwrócić wyniki wyszukiwania.
- „Dodaj zakładkę Marka 12:30.” — Powinien utworzyć zakładkę.

Jeśli AI opisuje rzecz tekstem zamiast jej faktycznie wykonać, model ma trudności z użyciem narzędzi, mimo że aplikacja zgłosiła obsługę.

## Co zrobić, jeśli mój model nie obsługuje narzędzi?

Nadal możesz go używać. AI będzie odpowiadać tekstem, a Ty samodzielnie możesz wyszukiwać wersety, przeszukiwać i nawigować po aplikacji. Ale stracisz bezdotykowe, zintegrowane doświadczenie, które czyni Theodię potężną.

## Podsumowanie

- Wybierz model z obsługą **wywoływania narzędzi / function calling**, aby uzyskać najlepsze doświadczenie z Theodią.
- **Duże modele zdalne** najbardziej niezawodnie obsługują narzędzia.
- Testuj każdy model prostymi poleceniami, takimi jak „Pokaż mi Rodzaju 1:1”, aby sprawdzić obsługę narzędzi.
