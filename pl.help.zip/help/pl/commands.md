---
title: Polecenia
level: everyday
categories: [layout, study]
summary: Pole Szybkiego polecenia pozwala przejść do dowolnej funkcji, wpisując krótkie polecenie. Poznaj obsługiwane formaty i przykłady.
---

# Polecenia

Pole **Szybkie polecenie** pozwala przejść do prawie każdej części Theodii, wpisując krótką instrukcję. Możesz go używać na zakładce Strona główna lub z **Menu szybkiego dostępu** (ikona **▼** w nagłówku).

## Jak to działa

1. Stuknij pole polecenia.
2. Wpisz polecenie.
3. Stuknij klawisz przejścia na klawiaturze.

Aplikacja odczytuje polecenie i przenosi Cię bezpośrednio na właściwy ekran.

## Bez prefiksu /

Polecenia **nie** używają prefiksu `/`. Wprowadza się je jako zwykły tekst:

```
john 3:16
search love
backup
```

Jeśli wpiszesz `/settings`, wiodący `/` sprawi, że polecenie nie zostanie rozpoznane.

## Odniesienia biblijne

Wpisz dowolne odniesienie biblijne, aby otworzyć je w czytniku.

```
psalms 23
john 3:16
matthew 5:1
1 cor 15:10
```

Nazwy ksiąg mogą być dopasowane po pełnej nazwie lub skrócie. W językach interfejsu innych niż angielski możesz też wpisywać nazwy ksiąg w aktywnym języku.

## Wyszukiwanie

```
search abraham
search love
search faith not works
```

## Zakładki, porównanie, komentarz, odniesienia krzyżowe i informacje o słowie

```
bookmark john 3:16
compare genesis 1:1
commentary john 1
aicommentary eph 2:8
xref 1 cor 15:10
word info john 1:1
```

Te polecenia otwierają nazwane narzędzie dla podanego fragmentu.

## Leksykon

Wpisz numer Stronga, aby otworzyć hasło leksykonu.

```
g1161
h7225
```

## Rozważania

```
devotional
devotional smith
devotional daily
```

Bez nazwy otwiera listę rozważań.

## Skróty nawigacji

```
notes
highlights
bookmarks
flashcards
playlist
theoscript
resources
read john 3:16
```

Te polecenia przechodzą bezpośrednio do nazwanego ekranu lub otwierają fragment w czytniku.

## Zmiana przekładu

Wpisz skrót przekładu, aby do niego przełączyć.

```
kjv
web
trlit
ohgb
```

Na ekranie czytnika przekład zmienia się w miejscu. W innym miejscu otwiera przekład w ostatnio czytanym fragmencie.

## Zlokalizowane czasowniki poleceń

Publiczne czasowniki poleceń można wpisywać w aktywnym języku interfejsu **lub** po angielsku. Angielski zawsze działa jako rezerwowa opcja. Ukryte polecenia (skróty ustawień, polecenia instalacji, Easter eggi) zachowują wyłącznie angielską składnię.

## Pomoc

Wpisz `help` lub `commands` w polu polecenia, aby w dowolnym momencie otworzyć wbudowaną referencję poleceń.
