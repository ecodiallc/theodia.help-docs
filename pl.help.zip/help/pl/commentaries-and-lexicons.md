---
title: Komentarze i leksykony
level: everyday
categories: study
summary: Jak sprawdzać znaczenia słów i czytać notatki studialne.
---

# Komentarze i leksykony

> **Tryb:** Komentarze i leksykony wymagają trybu **Badacz**. Możesz zmienić tryb w **Ustawienia** → **Tryb użytkownika**.

Theodia zawiera dwa narzędzia studialne: **komentarze** i **leksykony**. Pomagają zrozumieć Biblię głębiej.

## Czym jest komentarz?

Komentarz to księga notatek studialnych napisanych przez biblistę. Dla danego wersetu komentarz podaje tło, znaczenie i to, jak werset wpisuje się w resztę Biblii.

## Czym jest leksykon?

Leksykon to słownik słów biblijnych. Podaje oryginalne słowo hebrajskie lub greckie, jego znaczenie i sposób użycia w Biblii.

## Jak otworzyć komentarz

1. Otwórz rozdział.
2. Stuknij werset.
3. Stuknij **Komentarz**.

Otworzy się panel z notatkami biblisty dotyczącymi tego wersetu.

## Jak otworzyć leksykon

1. Otwórz rozdział w Biblii zawierającej numery Stronga.
2. Stuknij numer Stronga w wersecie (na przykład G1234 lub H1234).
3. Otworzy się panel pokazujący oryginalne słowo hebrajskie lub greckie, jego znaczenie i inne wersety, w których jest używane.

Numery Stronga pojawiają się w innym kolorze w tekście wersetu, aby wyróżniać się od zwykłych słów.

## Wybór innego komentarza

Komentarz wybiera się z rozwijanej listy u góry samego panelu komentarza. Otwórz panel, a następnie stuknij rozwijaną listę, aby zobaczyć zainstalowane komentarze. Wybierz inny.

## Wybór innego leksykonu

Leksykon wybiera się z rozwijanej listy u góry panelu leksykonu. Otwórz panel, a następnie stuknij rozwijaną listę, aby zobaczyć zainstalowane leksykony. Wybierz inny.

## Zasoby wbudowane

Theodia dostarcza wbudowany zestaw komentarzy i leksykonów. Są one dołączone do aplikacji i działają offline. Dodatkowych komentarzy i leksykonów nie można instalować ani pobierać osobno.

## Kiedy ich używać

- **Komentarze** sprawdzają się, gdy werset jest trudny do zrozumienia. Notatki podają kontekst.
- **Leksykony** sprawdzają się przy studiach słów. Podają dokładne znaczenie słowa w języku oryginalnym.

## Wskazówka

Jeśli werset zawiera notatkę, którą chcesz zachować, zrób zrzut ekranu lub skopiuj tekst do notatki. (Zobacz przewodnik [Pisanie notatek](theodia://help/notes).)

## Prosty słownik biblijny

Aby uzyskać angielskie definicje słów i pojęć biblijnych (przymierze, przebłaganie, faryzeusze itp.), Theodia zawiera narzędzie Słownik biblijny. Otwórz je z menu wersetu, stukając **Słownik** (📖). Różni się od leksykonu: leksykony wyjaśniają oryginalne słowa hebrajskie i greckie, podczas gdy słownik wyjaśnia angielskie słowo prostym językiem. Jak z niego korzystać, zobacz w przewodniku [Słownik biblijny](theodia://help/dictionary).
