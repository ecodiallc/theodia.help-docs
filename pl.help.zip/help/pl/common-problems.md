---
title: Częste problemy
level: everyday
categories: trouble
summary: Szybkie rozwiązania problemów, na które możesz natrafić.
---

# Częste problemy

Ten przewodnik obejmuje problemy, na które ludzie najczęściej natrafiają. Jeśli Twojego problemu tu nie ma, zobacz przewodnik [Gdzie szukać pomocy](theodia://help/getting-more-help).

## Aplikacja działa wolno

1. Zamknij inne aplikacje działające w tle.
2. Uruchom ponownie aplikację.
3. Uruchom ponownie urządzenie.

## Nie mogę znaleźć przekładu Biblii

1. Otwórz **Ustawienia** → **Zarządzaj zasobami**, aby zobaczyć, co jest zainstalowane.
2. Jeśli przekładu nie ma, stuknij **Zainstaluj z GitHuba**.
3. W oknie pobierania stuknij zakładkę **Biblie** (lub **Biblie globalne**) i wybierz żądany przekład.
4. Stuknij **Zainstaluj wybrane** i poczekaj na zakończenie pobierania.
5. Aby pobrać nowy przekład, potrzebujesz internetu.

## Zniknęły mi notatki lub zakładki

1. Sprawdź, czy patrzysz na właściwą zakładkę. Notatki są na zakładce **Notatki biblijne**. Zakładki są na zakładce **Zakładki**.
2. Jeśli niedawno przywróciłeś kopię zapasową, mogła ona zastąpić Twoje dane. Sprawdź datę kopii zapasowej.
3. Jeśli odinstalowałeś i ponownie zainstalowałeś aplikację, Twoje dane zostały utracone. Następnym razem najpierw wykonaj kopię zapasową.

## Wyszukiwanie nie znajduje wersetów

1. Upewnij się, że słowo jest poprawnie napisane.
2. Spróbuj krótszego słowa. „Love” znajduje więcej wersetów niż „loving.”
3. Upewnij się, że masz zainstalowany właściwy przekład Biblii. Wyszukiwanie działa tylko w przekładach, które posiadasz.

## Czytanie na głos nie działa

1. Upewnij się, że głośność urządzenia jest podgłośniona.
2. Upewnij się, że aplikacja ma zezwolenie na używanie głośnika.
3. Spróbuj innego przekładu. Niektóre przekłady lepiej współpracują z czytaniem na głos niż inne.
4. Aby uzyskać szczegółową listę kroków, zobacz przewodnik [Czytanie na głos](theodia://help/tts).

## Aplikacja ciągle się zawiesza

1. Uruchom ponownie aplikację.
2. Uruchom ponownie urządzenie.
3. Jeśli problem się powtarza, zgłoś go. Zobacz przewodnik [Gdzie szukać pomocy](theodia://help/getting-more-help).

## Chcę odinstalować aplikację

Theodia możesz odinstalować jak każdą inną aplikację. Zanim to zrobisz, wykonaj kopię zapasową danych. Po odinstalowaniu dane na urządzeniu znikną.

## Nadal utknąłeś?

Zobacz przewodnik [Gdzie szukać pomocy](theodia://help/getting-more-help). Znajdziesz tam linki do zgłaszania problemu i zadawania pytań społeczności.

Możesz też przeszukiwać przewodniki pomocy z głównego ekranu **Pomoc i przewodniki**. Wpisz słowo, takie jak `powiadomienia`, `wyszukiwanie` lub `zakładki`, aby znaleźć pasujący przewodnik.
