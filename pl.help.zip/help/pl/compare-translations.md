---
title: Porównywanie przekładów
level: everyday
categories: [read, study]
summary: Jak zobaczyć ten sam werset w każdym zainstalowanym przekładzie.
---

# Porównywanie przekładów

> **Tryb:** Narzędzie Porównaj jest dostępne w trybach **Standardowy** i **Badacz**. Tryb skupienia służy do czystego czytania bez rozpraszania uwagi. Możesz zmienić tryb w **Ustawienia** → **Tryb użytkownika**.

Narzędzie **Porównaj** pokazuje jeden werset w każdym zainstalowanym przekładzie Biblii, wszystkie w jednym panelu. Jest przydatne, gdy chcesz zobaczyć, jak różni tłumacze podchodzą do trudnego wersetu, lub gdy wybierasz przekład i chcesz porównać ten sam werset w każdym z nich.

## Jak otworzyć Porównaj

1. Otwórz rozdział w dowolnym przekładzie.
2. Stuknij werset, aby wyświetlić menu wersetu.
3. Stuknij **Porównaj** (⇄).

Otworzy się panel. Pasek tytułu pokazuje odniesienie (na przykład „Jan 3:16 — Porównaj”). Panel wyświetla ten sam werset w każdym zainstalowanym przekładzie. Twój bieżący przekład jest wymieniony jako pierwszy; reszta jest posortowana alfabetycznie.

## Jak wygląda panel

Panel to **lista pionowa**, a nie kolumny obok siebie. Każdy wiersz to jeden przekład:

- **Nazwa przekładu** (na przykład „KJV”) znajduje się u góry wiersza. Można ją stuknąć.
- **Tekst wersetu** znajduje się poniżej nazwy.

Przewijaj panel, aby zobaczyć wszystkie przekłady. Każdy przekład zainstalowany na urządzeniu pojawi się tutaj. Jeśli przekład nie zawiera danej księgi lub wersetu, zostanie pominięty.

## Jak czytać werset w innym przekładzie

Stuknij nazwę przekładu w wierszu. Panel Porównaj zamknie się, a ten sam rozdział otworzy się w wybranym przekładzie z zaznaczeniem tego wersetu. To najszybszy sposób, aby przejść z porównania bezpośrednio do czytania konkretnego przekładu.

## Jak zamknąć Porównaj

- **Na telefonie:** stuknij X w prawym górnym rogu panelu.
- **Na tablecie:** stuknij X na nagłówku panelu lub stuknij poza panelem.

Wracasz do widoku rozdziału w oryginalnym przekładzie.

## Kiedy używać Porównaj

- **Wybór przekładu.** Otwórz znany werset w bieżącym przekładzie, a następnie użyj Porównaj, aby zobaczyć go w innych. Różnice stają się wyraźne.
- **Trudne wersety.** Werset, który jest niejasny w jednym przekładzie, często jest jaśniejszy w innym.
- **Studia słów.** Zobacz, jak różni tłumacze traktują kluczowe słowo lub frazę.

Aby uzyskać szybki przegląd całego rozdziału w wielu przekładach jednocześnie, użyj zamiast tego widoku równoległego. Jak go włączyć, zobacz w przewodniku [Tryb studyjny](theodia://help/study-mode).
