---
title: Tworzenie własnych zasobów
level: advanced
categories: resources
summary: Jak tworzyć własne Biblie, komentarze, księgi, rozważania i leksykony, a następnie importować je do Theodii.
---

# Tworzenie własnych zasobów

Theodia obsługuje niestandardowe zasoby w formacie Unique Bible App. Każdy zasób to plik SQLite o określonej strukturze tabel. Możesz utworzyć te pliki na komputerze, a potem zaimportować je do aplikacji.

## Typy plików i wymagane tabele

### Biblie (`.bible`)

Plik Biblii to baza SQLite z przynajmniej jedną z tabel:

- **`Verses`** — kolumny: `Book` (liczba, 1-66), `Chapter` (liczba), `Verse` (liczba), `Scripture` (tekst)
- **`Bible`** — kolumny: `Book` (liczba), `Chapter` (liczba), `Verse` (liczba), `Scripture` (tekst)

Możesz też dodać tabelę **`Details`** z metadanymi, takimi jak `Description`, `Abbreviation` i `Version`.

Przykładowe zapytanie SQL:

```sql
-- Główna tabela tekstu
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- Opcjonalna tabela metadanych
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### Komentarze (`.commentary`)

Komentarze dzielą się na trzy rodzaje: **do księgi**, **do rozdziału** i **do wersetu**. Rodzaj rozpoznaje się po **pierwszej literze nazwy pliku**.

#### Komentarze do księgi — nazwa zaczyna się od `b`

Komentarz do księki obejmuje całą księgę w jednym wpisie. Tabela `Commentary` potrzebuje kolumn `Book` i `Scripture` (lub `Content`). Nie potrzeba kolumn `Chapter` ani `Verse`.

- **`Commentary`** — kolumny: `Book` (liczba), `Scripture` (tekst) lub `Content` (tekst)

Przykładowe zapytanie SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

Przykład nazwy pliku: `bMyCommentary.commentary`

#### Komentarze do rozdziału — nazwa zaczyna się od `c`

Komentarz do rozdziału obejmuje każdy rozdział księgi biblijnej.

- **`Commentary`** — kolumny: `Book` (liczba), `Chapter` (liczba), `Scripture` (tekst) lub `Content` (tekst)

Przykładowe zapytanie SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

Przykład nazwy pliku: `cMyCommentary.commentary`

#### Komentarze do wersetu — nazwa zaczyna się od `v`

Komentarz do wersetu obejmuje pojedyncze wersety. Tabela `Commentary` potrzebuje kolumn `Book`, `Chapter`, `Verse` oraz `Scripture` (lub `Content`).

- **`Commentary`** — kolumny: `Book` (liczba), `Chapter` (liczba), `Verse` (liczba), `Scripture` (tekst) lub `Content` (tekst)

Przykładowe zapytanie SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

Przykład nazwy pliku: `vMyCommentary.commentary`

### Księgi (`.book`)

Plik księgi to baza SQLite z tabelą `Reference`.

- **`Reference`** — kolumny: `id` (liczba), `Chapter` (tekst), `Content` (tekst)

Każdy wiersz to jeden rozdział. Kolumna `Chapter` to tytuł rozdziału. Kolumna `Content` to treść rozdziału, która może zawierać HTML (`<b>`, `<i>`, `<br>` itp.).

Przykładowe zapytanie SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

Możesz też tworzyć księgi z plików Markdown. Aplikacja potrafi importować pliki `.md`, w których `#` to tytuł księgi, a `##` oznacza rozdziały. Markdown jest automatycznie konwertowany na HTML.

### Rozważania (`.devotional`)

Plik rozważania to baza SQLite z tabelą `devotional`.

- **`devotional`** — kolumny: `month` (liczba, 1-12), `day` (liczba, 1-31), `devotion` (tekst)

Każdy wiersz to czytanie na jeden dzień. Aplikacja wyszukuje wpis na podstawie dzisiejszego miesiąca i dnia.

Przykładowe zapytanie SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### Leksykony (`.lexicon`)

Plik leksykonu to baza SQLite z tabelą `Lexicon`.

- **`Lexicon`** — kolumny: `Topic` (tekst, numer Stronga), `Definition` (tekst, hasło leksykonu)

Kolumna `Topic` przechowuje numer Stronga (na przykład `G1161` lub `H7225`). Kolumna `Definition` zawiera pełne hasło, które może zawierać HTML.

Przykładowe zapytanie SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

Leksykony zasilają narzędzie **Informacje o słowie**. Gdy dotkniesz słowa w Biblii międzywierszowej, aplikacja wyszukuje numer Stronga w zainstalowanych leksykonach.

## Tworzenie pliku na komputerze

1. Zainstaluj edytor SQLite (DB Browser for SQLite, SQLiteStudio lub narzędzie `sqlite3` w wierszu poleceń).
2. Utwórz nową bazę danych.
3. Utwórz wymaganą tabelę i wstaw dane.
4. Zapisz plik z właściwym rozszerzeniem (`.bible`, `.commentary`, `.book`, `.devotional` lub `.lexicon`).

## Importowanie do Theodii

1. Przenieś plik na urządzenie (AirDrop, e-mail, chmura lub USB).
2. Otwórz **Theodię**.
3. Przejdź do **Ustawienia** → **Zarządzaj zasobami**.
4. Dotknij **Importuj z pliku**.
5. Wybierz swój plik.

Aplikacja sprawdza poprawność pliku (czy ma wymaganą tabelę), kopiuje go do folderu z danymi i włącza automatycznie. Jeśli plik jest niepoprawny, zobaczysz komunikat z wyjaśnieniem.

## Ograniczenia

- Nie możesz nadpisać wbudowanych zasobów. Jeśli spróbujesz zaimportować plik o takiej samej nazwie jak wbudowana Biblia, komentarz lub księga, import się nie powiedzie.
- Pliki Biblii muszą zawierać tabelę `Verses` lub `Bible`. Jeśli żadnej nie ma, import się nie powiedzie.
- Pliki komentarzy muszą zawierać tabelę `Commentary`.
  - Komentarze do księgi potrzebują kolumn `Book` i `Scripture` (lub `Content`).
  - Komentarze do rozdziału potrzebują kolumn `Book`, `Chapter` i `Scripture` (lub `Content`).
  - Komentarze do wersetu potrzebują kolumn `Book`, `Chapter`, `Verse` i `Scripture` (lub `Content`).
- Pliki ksiąg potrzebują tabeli `Reference`.
- Pliki leksykonów potrzebują tabeli `Lexicon`.
- Pliki rozważań potrzebują tabeli `devotional`.

## Wskazówki

- Utrzymuj rozsądne rozmiary plików. Bardzo duże pliki SQLite mogą powodować problemy z pamięcią na starszych urządzeniach.
- Najpierw przetestuj plik na komputerze. Otwórz go w przeglądarce SQLite i wykonaj `SELECT * FROM` wymaganej tabeli, aby sprawdzić, czy dane wyglądają poprawnie.
- W przypadku Biblii kolumna `Book` musi zawierać liczby (1 = Księga Rodzaju, 66 = Księga Apokalipsy).
- W komentarzach możesz używać kolumny `Scripture` lub `Content` jako tekstu komentarza.
- W księgach HTML w kolumnie `Content` jest renderowany podczas czytania. Używaj prostych znaczników: `<b>`, `<i>`, `<br>` i `<hr>`.

## Gdzie znaleźć istniejące zasoby

Theodia potrafi odczytywać zasoby z projektu [Unique Bible App](https://github.com/eliranwong/UniqueBible). Można tam znaleźć wiele Biblii, komentarzy, ksiąg i innych zasobów we właściwym formacie SQLite. Zobacz przewodnik [Pobieranie podstawowych plików](theodia://help/getting-core-files), aby dowiedzieć się, jak je znaleźć i dodać.
