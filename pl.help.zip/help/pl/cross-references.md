---
title: Odniesienia krzyżowe
level: everyday
categories: study
summary: Jak znaleźć wersety powiązane z tym, który właśnie czytasz.
---

# Odniesienia krzyżowe

> **Tryb:** Odniesienia krzyżowe są dostępne w trybie **Standardowy** i **Uczony**. Tryb **Czytanie** służy tylko spokojnemu, pozbawionemu rozpraszaczy czytaniu. Tryb możesz zmienić w **Ustawienia** → **Tryb użytkownika aplikacji**.

**Odniesienie krzyżowe** to inny werset, który mówi o tym samym co werset, który czytasz. Panel odniesień pokazuje, które wersety w Biblii łączą się ze sobą.

## Jak otworzyć odniesienia krzyżowe

1. Otwórz rozdział.
2. Dotknij wersetu, aby wyświetlić menu wersetu.
3. Dotknij **Odniesienia krzyżowe**.

Otworzy się panel z listą wersetów powiązanych z tym, który dotknąłeś.

## Jak czytać listę

Każdy wiersz to jeden powiązany werset. Zobaczysz:

- Księgę, rozdział i werset.
- Krótki fragment tekstu wersetu.
- Wynik pokazujący, jak silne jest powiązanie.

## Jak przejść do powiązanego wersetu

Dotknij dowolnego wiersza. Aplikacja otworzy ten werset. Gdy skończysz, dotknij przycisku **Wstecz**, aby wrócić.

## Co oznacza wynik

Wynik mówi, jak blisko są ze sobą powiązane wersety. Wysoki wynik oznacza silne, bezpośrednie powiązanie. Niski wynik oznacza luźniejsze.

## Używanie odniesień do studiów

Odniesienia krzyżowe przydają się do:

- **Studiów słowa.** Zobacz, jak Biblia używa danego słowa w różnych miejscach.
- **Studiów tematycznych.** Prześledź motyw, taki jak „miłość” czy „przymierze", przez całe Pismo.
- **Przygotowania kazań.** Szybko znajdź wersety wspierające.

## Wskazówka

Odniesienia krzyżowe działają najlepiej z tłumaczeniem typu słowo za słowo, takim jak WEB.
