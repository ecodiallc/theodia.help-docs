---
title: Codzienne rozważania
level: everyday
categories: [content, read]
summary: Jak czytać krótkie rozważanie każdego dnia.
---

# Codzienne rozważania

Rozważanie to krótkie czytanie na jeden dzień. Często zawiera werset, krótką myśl i pytanie do przemyślenia. Theodia zawiera małą bibliotekę rozważań.

## Jak otworzyć rozważanie

1. Dotknij zakładki **Rozważania** na dole ekranu.
2. Zobaczysz listę rozważań zainstalowanych na urządzeniu.
3. Dotknij jednego, aby je otworzyć.

## Jak czytać rozważanie

1. Otwórz rozważanie.
2. Przewijaj, aby czytać.
3. Użyj przycisków u góry:
   - Dotknij **daty**, aby przejść do innego dnia.
   - Dotknij **gwiazdki**, aby zapisać dzień w zakładkach.
   - Dotknij **głośnika**, aby czytać na głos (jeśli urządzenie to obsługuje). Zobacz przewodnik [Czytanie na głos](theodia://help/tts), aby wybrać głos.
   - Dotknij **Poprzedni** lub **Następny**, aby przejść do poprzedniego lub następnego dnia.

## Jak zapisać werset z rozważania

1. Otwórz rozważanie.
2. Dotknij wersetu.
3. Dotknij **Zakładka** lub **Podświetl**.

Werset zostanie zapisany w **Zakładkach** lub **Podświetleniach**.

## Jak napisać notatkę do rozważania

1. Otwórz rozważanie.
2. Dotknij wersetu.
3. Dotknij **Notatka**. Wpisz swoją refleksję lub modlitwę. Dotknij **Zapisz**.

Notatka pojawi się w zakładce **Notatki biblijne**.

## Wskazówki

- Rozważania nie wymagają internetu. Działają offline.
- Jeśli chcesz więcej rozważań, zobacz przewodnik [Pobieranie dodatkowych zasobów z GitHuba](theodia://help/getting-core-files).
