---
title: Słownik biblijny
level: everyday
categories: study
summary: Sprawdzaj znaczenia słów i pojęć biblijnych w zainstalowanych słownikach. Otwórz go z menu wersetu lub z hasła leksykonu, a następnie dotknij dowolnego słowa, aby zobaczyć je we wszystkich słownikach.
---

# Słownik biblijny

> **Tryb:** Słownik biblijny wymaga trybu **Uczony**. Tryb możesz zmienić w **Ustawienia** → **Tryb użytkownika aplikacji**.

Narzędzie **Słownik biblijny** wyszukuje słowo lub frazę we wszystkich zainstalowanych słownikach. Przydaje się, gdy chcesz znaleźć potoczną definicję słowa biblijnego, opis osoby lub miejsca, albo krótki artykuł o pojęciu teologicznym.

Słownik biblijny różni się od narzędzia **Informacje o słowie**, które szuka greckiego lub hebrajskiego słowa kryjącego się za wersem. Słownik czyta **angielskie** słowo, które dotknąłeś, i pokazuje, co mówią o nim zainstalowane słowniki. Jeśli chcesz przeczytać uwagi do tłumaczenia słowo po słowie, zobacz przewodnik [Komentarze i leksykony](theodia://help/commentaries-and-lexicons).

## Jak otworzyć słownik

Są dwa sposoby.

### Z menu wersetu

1. Otwórz rozdział w [trybie Studium](theodia://help/study-mode).
2. Dotknij wersetu, aby otworzyć menu wersetu.
3. Dotknij **Słownik** (📖).

Otworzy się panel zatytułowany odwołaniem do wersetu (na przykład „Jana 3:16”). Na górze znajduje się tekst wersetu z klikalnymi słowami. Poniżej wersetu jest pasek z wszystkimi zainstalowanymi słownikami. Pod nim znajduje się definicja, która jest pusta, dopóki nie dotkniesz słowa.

### Z hasła leksykonu

Gdy czytasz hasło leksykonu w panelu **Informacje o słowie**, niektóre wpisy zawierają niebieskie linki do powiązanych artykułów słownika. Dotknij któregoś z nich. Leksykon zamknie się, a słownik otworzy w tym artykule. To najszybszy sposób, aby przejść od greckiego lub hebrajskiego słowa do potocznego wyjaśnienia jego znaczenia.

## Jak działa widok wersetu

Gdy otworzysz słownik z menu wersetu, werset pojawia się na górze panelu jako lista klikalnych słów. Pospolite angielskie słowa, takie jak „the”, „and”, „of”, „to” i „a”, nie są klikalne. Wszystkie pozostałe są. Każde klikalne słowo jest pogrubione i wyróżnione kolorem, aby odróżniać się od reszty wersetu.

Dotknij dowolnego słowa w wersiecie. Theodia przeszukuje wszystkie zainstalowane słowniki, szukając dokładnego dopasowania. Pasek słowników u dołu aktualizuje się i pokazuje, które słowniki mają hasło: słowniki bez hasła są przygaszone. Pierwszy słownik z hasłem wybiera się automatycznie, a jego definicja pojawia się pod paskiem.

Dotknięte słowo jest podświetlone w tekście wersetu na górze panelu, więc zawsze wiesz, co sprawdzasz.

## Przełączanie się między słownikami

Każdy zainstalowany słownik widoczny jest jako mała etykieta pod wersetem. Po dotknięciu słowa:

- **Etykieta w pełnym kolorze** — ten słownik zawiera hasło dla dotkniętego słowa. Dotknij jej, aby przełączyć się na definicję z tego słownika.
- **Przygaszona etykieta** — ten słownik nie zawiera hasła dla tego słowa. Jest szara, aby od razu widać było, które słowniki je pokrywają, i nie można jej dotknąć.

Wybrany słownik jest wyróżniony. Dotknij innej pełnokolorowej etykiety, aby przeczytać to samo słowo w innym słowniku. Definicja poniżej aktualizuje się natychmiast.

Jeśli słowo istnieje tylko w jednym z zainstalowanych słowników, tylko ta jedna etykieta jest pełnokolorowa, a pozostałe są przygaszone.

## Co pokazuje panel

Panel słownika ma trzy części, od góry do dołu:

- **Werset** — werset, z którego otwarto słownik. Słowa są klikalne, a ostatnio dotknięte słowo jest podświetlone.
- **Pasek słowników** — wszystkie zainstalowane słowniki. Pełny kolor oznacza „słownik zawiera hasło”. Przygaszenie oznacza „brak hasła”.
- **Definicja** — artykuł z wybranego słownika. Zwykły tekst sformatowany w akapitach i nagłówkach. Wewnętrzne linki do innych haseł są klikalne; dotknięcie ich otwiera dane hasło w słowniku.

## Co się dzieje, gdy nie znaleziono hasła

Jeśli dotkniesz słowa, którego nie pokrywa żaden z zainstalowanych słowników, panel zamiast definicji wyświetli krótki komunikat „nie znaleziono haseł”. Zdarza się to często dla bardzo pospolitych słów, takich jak „year” czy „come”, które nie są właściwie słowami teologicznymi, choć pojawiają się w całej Biblii. Spróbuj bardziej szczegółowego słowa lub użyj narzędzia **Informacje o słowie** z leksykonu, które działa na greckim i hebrajskim tekście źródłowym.

## Co się dzieje, gdy nie ma zainstalowanego słownika

Słownik potrzebuje przynajmniej jednego pliku zasobu słownika, aby być użytecznym. Theodia dostarcza go w zestawie. Jeśli go usunąłeś lub używasz instalacji bez słowników, widok wersetu nadal się pojawi, słowa będą klikalne, ale pasek słowników będzie pusty, a każde wyszukiwanie zwróci „nie znaleziono haseł”.

Dodatkowych słowników nie można instalować osobno.

## Wskazówki

- Słownik szuka **dokładnych dopasowań słów**. Dotknięcie „love” znajdzie hasło „love”, ale nie „loved” ani „loving”. Aby sprawdzić pokrewną formę, użyj narzędzia **Informacje o słowie** na greckim lub hebrajskim słowie.
- Pasek słowników wygląda tak samo na telefonie i tablecie. Na tablecie słownik otwiera się jako panel boczny obok rozdziału; na telefonie jako pełnoekranowy modal. W obu przypadkach układ ma te same trzy części.
- Dotknięcie słowa w innym wersiecie otwiera nowy werset w panelu. Poprzedni wybór zostaje wyczyszczony. Dotknij słowa w nowym wersiecie, aby rozpocząć nowe wyszukiwanie.
- Niektóre hasła słownika odsyłają do tego samego słowa w innym słowniku. Dotknij tych wewnętrznych linków, aby podążyć śladem przez wszystkie zainstalowane słowniki.

## Różnice między Słownikiem a Informacjami o słowie

Oba narzędzia otwierają się z menu wersetu, ale robią co innego:

- **Słownik** (📖) czyta angielskie słowo, które dotknąłeś, i znajduje je w zainstalowanych angielskich słownikach. To właściwe narzędzie do potocznych definicji słów teologicznych, takich jak „covenant”, „atonement” czy „Pharisee”.
- **Informacje o słowie** (?) czyta greckie lub hebrajskie słowo kryjące się za wersem i znajduje je w zainstalowanych leksykonach. To właściwe narzędzie do poważnych studiów słowa, znajdowania wszystkich miejsc, w których użyto danego greckiego słowa, i czytania definicji w językach oryginalnych.

W razie wątpliwości zacznij od słownika. Jeśli chcesz zagłębić się w język oryginalny, przełącz się na **Informacje o słowie**. Pełny opis znajdziesz w przewodniku [Komentarze i leksykony](theodia://help/commentaries-and-lexicons).

## Powiązane przewodniki

- Przewodnik [Tryb studium](theodia://help/study-mode) szczegółowo wyjaśnia menu wersetu i położenie narzędzia **Słownik** (📖) obok **Zakładka**, **Podświetl**, **Czytaj**, **Porównaj**, **Odniesienia krzyżowe**, **Komentarz AI**, **Informacje o słowie** i **Notatki**.
- Przewodnik [Komentarze i leksykony](theodia://help/commentaries-and-lexicons) opisuje **Informacje o słowie** i leksykony języków oryginalnych.
- Przewodnik [Czym są zasoby?](theodia://help/what-are-resources) wyjaśnia rodzaje plików używanych przez Theodię, w tym zasoby słownikowe.
- Przewodnik [Typowe problemy](theodia://help/common-problems) zawiera rozwiązania pustych wyników i innych problemów ze słownikiem.
