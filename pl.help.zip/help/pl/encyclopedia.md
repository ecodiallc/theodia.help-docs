---
title: Encyklopedia
level: everyday
categories: study
summary: Jak przeglądać hasła encyklopedyczne i prace referencyjne.
---

# Encyklopedia

Theodia zawiera wbudowaną **Encyklopedię** do sprawdzania haseł związanych z Biblią: osób, miejsc, tematów i pojęć. Aplikacja dostarcza w zestawie komentarz ilustrowany KITto (*Kitto's Illustrated Commentary*, KIT), a dodatkowe encyklopedie można pobrać z repozytorium.

## Czym jest encyklopedia w Theodii?

Encyklopedia to praca referencyjna złożona z krótkich artykułów. Każdy artykuł opisuje osobę, miejsce, wydarzenie lub temat biblijny. W przeciwieństwie do komentarza, który wyjaśnia konkretny werset, artykuł encyklopedyczny wyjaśnia sam temat.

## Jak otworzyć Encyklopedię

1. Dotknij **Encyklopedie** na dolnym pasku narzędzi.
2. Wybierz encyklopedię z rzędu skrótów u góry.
3. Wpisz temat, osobę lub miejsce w polu wyszukiwania.

Wyszukiwanie wymaga co najmniej **3 znaków**, zanim pojawią się wyniki i podpowiedzi.

## Czytanie artykułu

- Na **telefonie** dotknij dowolnego wyniku, aby otworzyć artykuł na nowym ekranie.
- Na **tablecie** artykuł otwiera się w panelu po prawej stronie, a lista pozostaje po lewej.

## Wybieranie encyklopedii

Dotknij etykiety ze skrótem (na przykład **KIT**), aby przełączyć się na daną encyklopedię. Aby przeszukiwać kilka encyklopedii jednocześnie, użyj zakładki **Szukaj** i wybierz tryb wyszukiwania **Encyklopedia**.

## Pobieranie dodatkowych encyklopedii

1. Otwórz **Ustawienia**.
2. Dotknij **Zarządzaj zasobami**.
3. Dotknij **Pobierz z GitHuba**.
4. Wybierz zakładkę **Encyklopedie**.
5. Dotknij przycisku pobierania obok wybranej encyklopedii.

Encyklopedie pobierane są z repozytorium GitHub Theodii i instalowane automatycznie. Zainstalowane encyklopedie pojawiają się na ekranie Encyklopedii i w wyszukiwarce.

Możesz też zainstalować encyklopedię z pliku lokalnego: w **Zarządzaj zasobami** dotknij **Zainstaluj plik lokalny** i wybierz plik `.encyclopedia`. Plik zostanie skopiowany do folderu encyklopedii aplikacji i dodany do wspólnego indeksu wyszukiwania.

## Przytrzymaj, aby zobaczyć pełny tytuł

Na ekranie wyszukiwania etykiety encyklopedii pokazują krótkie skróty. Przytrzymaj etykietę, aby zobaczyć pełną nazwę encyklopedii.

## Kiedy używać Encyklopedii

- Sprawdź osobę, miejsce lub temat przed lub podczas czytania fragmentu.
- Zdobądź informacje o biblijnym słowie lub pojęciu obejmującym wiele wersetów.
- Czytaj obok komentarza, aby pogłębić studium.
