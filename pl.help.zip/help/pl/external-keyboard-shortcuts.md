---
title: Skróty klawiatury zewnętrznej
level: everyday
categories: [tablet, settings]
summary: Pełna lista skrótów klawiatury dla iPada z podłączoną zewnętrzną klawiaturą.
---

# ⌨️ Skróty klawiatury zewnętrznej

Jeśli używasz Theodii na iPadzie z zewnętrzną klawiaturą (Magic Keyboard, klawiatura Bluetooth lub USB), możesz nawigować po aplikacji bez dotykania ekranu.

> **Tryb:** Niektóre skróty działają tylko wtedy, gdy odpowiednia funkcja jest dostępna w aktualnym trybie użytkownika. Na przykład `Cmd + Option + 6` (Zakładki) i `Cmd + Option + 7` (Podświetlenia) nic nie robią w trybie **Czytanie**. Tryb możesz zmienić w **Ustawienia** → **Tryb użytkownika aplikacji**.

Skróty działają na **iPadzie**.

## Skróty globalne (z dowolnego miejsca)

| Skrót | Działanie |
| ----- | --------- |
| `Cmd + /` | Pokaż pomoc skrótów klawiatury |
| `Cmd + .` | Zamknij modal / panel (alternatywa dla Escape) |
| `Cmd + Option + 1` | Przejdź do zakładki Strona główna |
| `Cmd + Option + 2` | Przejdź do zakładki Biblie |
| `Cmd + Option + 3` | Przejdź do zakładki Księgi |
| `Cmd + Option + 4` | Przejdź do zakładki Rozważania |
| `Cmd + Option + 5` | Przejdź do zakładki Szukaj |
| `Cmd + Option + 6` | Przejdź do zakładki Zakładki (Standardowy i Uczony) |
| `Cmd + Option + 7` | Przejdź do zakładki Podświetlenia (Standardowy i Uczony) |
| `Cmd + Option + 8` | Przejdź do zakładki Notatki (Standardowy i Uczony) |
| `Cmd + Option + 9` | Przejdź do zakładki AI (tylko Uczony, jeśli włączone) |
| `Cmd + Option + 0` | Przejdź do zakładki Pomoc |
| `Cmd + Option + I` | Przejdź do zakładki O aplikacji |
| `Cmd + [` | Wróć |
| `Cmd + F` | Otwórz wyszukiwanie |
| `Cmd + K` | Otwórz Szybkie menu (Uczony) |
| `Cmd + ,` | Otwórz Ustawienia |
| `Cmd + Shift + M` | Otwórz główne menu |
| `Cmd + Shift + T` | Przełączaj motyw (domyślny / ciemny) |
| `Cmd + Shift + U` | Otwórz wybór trybu użytkownika |
| `Escape` | Zamknij modal / panel |

## Skróty w czytniku Biblii

Działają zarówno w **czytniku studyjnym**, jak i **czytniku skupienia**.

| Skrót | Działanie |
| ----- | --------- |
| `← Strzałka w lewo` | Poprzedni rozdział |
| `→ Strzałka w prawo` | Następny rozdział |
| `Cmd + R` | Przełącz między czytnikiem studyjnym a skupienia (Standardowy i Uczony) |
| `Cmd + Option + V` | Otwórz wybór wersji Biblii |
| `Cmd + Option + B` | Otwórz wybór księgi |
| `Cmd + Option + C` | Otwórz wybór rozdziału |
| `Cmd + T` | Przełączaj czytanie na głos (zatrzymaj, gdy gra lub jest wstrzymane; zacznij, gdy bezczynne) |
| `Cmd + Option + T` | Odtwórz / Wstrzymaj czytanie na głos |

## Tylko czytnik studyjny

| Skrót | Działanie |
| ----- | --------- |
| `↑ Strzałka w górę` | Zaznacz poprzedni werset |
| `↓ Strzałka w dół` | Zaznacz następny werset |
| `Cmd + ↑` | Zaznacz pierwszy werset |
| `Cmd + ↓` | Zaznacz ostatni werset |
| `Cmd + ←` | Przejdź do rozdziału 1 |
| `Cmd + →` | Przejdź do ostatniego rozdziału |
| `Cmd + 0`–`9` | Bezpośredni skok do wersetu (wpisz cyfry, np. `Cmd + 1` `Cmd + 6` dla wersetu 16) |
| `Cmd + P` | Przełączaj Biblię równoległą (Standardowy i Uczony) |
| `Cmd + B` | Dodaj zakładkę do zaznaczonego wersetu (Standardowy i Uczony) |
| `Cmd + H` | Podświetl zaznaczony werset (Standardowy i Uczony) |
| `Cmd + N` | Dodaj notatkę do zaznaczonego wersetu (Standardowy i Uczony) |
| `Cmd + C` | Porównaj zaznaczony werset w innych tłumaczeniach (Standardowy i Uczony) |
| `Cmd + X` | Otwórz odniesienia krzyżowe dla zaznaczonego wersetu (Standardowy i Uczony) |
| `Cmd + I` | Otwórz informacje o słowie (Uczony) |
| `Cmd + D` | Otwórz słownik dla zaznaczonego wersetu (Uczony) |
| `Cmd + A` | Otwórz panel AI dla zaznaczonego wersetu (Uczony) |
| `Cmd + Option + S` | Przełączaj nagłówki sekcji |
| `Cmd + Option + W` | Zamknij wszystkie otwarte panele studyjne |
| `Cmd + Option + M` | Otwórz menu czynności dla wersetu |

## Tylko czytnik skupienia

| Skrót | Działanie |
| ----- | --------- |
| `↑ Strzałka w górę` | Przewiń w górę |
| `↓ Strzałka w dół` | Przewiń w dół |
| `Cmd + ↑` | Przewiń na górę |
| `Cmd + ↓` | Przewiń na dół |
| `Cmd + =` | Powiększ |
| `Cmd + -` | Pomniejsz |

## Wyszukiwanie

| Skrót | Działanie |
| ----- | --------- |
| `Return` | Wykonaj wyszukiwanie |
| `Cmd + Return` | Wyczyść wyszukiwanie i ustaw fokus w polu |
| `Cmd + ↑` | Przewiń wyniki w górę |
| `Cmd + ↓` | Przewiń wyniki w dół |
| `Cmd + Option + A` | Zaznacz wszystkie elementy zakresu |
| `Cmd + Option + C` | Odznacz wszystkie elementy zakresu |
| `Cmd + Option + B` | Tryb wyszukiwania Biblii |
| `Cmd + Option + O` | Tryb wyszukiwania ksiąg |
| `Cmd + Option + D` | Tryb wyszukiwania słownika (Uczony) |
| `Cmd + Option + X` | Tryb wyszukiwania leksykonu (Uczony) |

## Wyniki wyszukiwania

| Skrót | Działanie |
| ----- | --------- |
| `Cmd + S` | Otwórz panel zapisu wszystkich wyników |
| `Cmd + ↑` | Przewiń wyniki w górę |
| `Cmd + ↓` | Przewiń wyniki w dół |

## Czytnik ksiąg

| Skrót | Działanie |
| ----- | --------- |
| `← Strzałka w lewo` | Poprzedni rozdział |
| `→ Strzałka w prawo` | Następny rozdział |
| `Cmd + ↑` | Poprzedni rozdział |
| `Cmd + ↓` | Następny rozdział |
| `↑ Strzałka w górę` | Przewiń w górę |
| `↓ Strzałka w dół` | Przewiń w dół |
| `Cmd + B` | Dodaj zakładkę bieżącego rozdziału |
| `Cmd + J` | Otwórz wybór rozdziału |
| `Cmd + L` | Otwórz wybór głosu |
| `Cmd + T` | Przełączaj czytanie na głos |
| `Cmd + Option + T` | Odtwórz / Wstrzymaj czytanie na głos |

## Czytnik rozważań

| Skrót | Działanie |
| ----- | --------- |
| `← Strzałka w lewo` | Poprzedni dzień |
| `→ Strzałka w prawo` | Następny dzień |
| `↑ Strzałka w górę` | Przewiń w górę |
| `↓ Strzałka w dół` | Przewiń w dół |
| `Cmd + ↑` | Przewiń w górę (duży skok) |
| `Cmd + ↓` | Przewiń w dół (duży skok) |
| `Cmd + D` | Otwórz wybór daty |
| `Cmd + T` | Przełączaj czytanie na głos |
| `Cmd + Option + T` | Odtwórz / Wstrzymaj czytanie na głos |

## Czat AI

| Skrót | Działanie |
| ----- | --------- |
| `Cmd + Return` | Wyślij wiadomość |
| `Cmd + N` | Nowy czat |
| `Cmd + D` | Przełączaj szufladę rozmów |
| `Cmd + Option + C` | Wyczyść bieżący czat |
| `Cmd + S` | Otwórz menu zapisu |
| `Escape` | Zamknij szufladę / menu |

## Zakładki

| Skrót | Działanie |
| ----- | --------- |
| `↑ Strzałka w górę` / `↓ Strzałka w dół` | Zaznacz zakładkę |
| `Return` | Otwórz zakładkę (tablet: zaznacz) |
| `Cmd + R` | Czytaj zakładkę w kontekście |
| `Cmd + M` | Przenieś zaznaczoną zakładkę do folderów |
| `Cmd + N` | Zarządzaj folderami |
| `Escape` | Zamknij panel szczegółów / wybór folderu |

W oknie **Przenieś do folderu** `↑ Strzałka w górę` / `↓ Strzałka w dół` przesuwa zaznaczenie, `Return` przełącza zaznaczony folder lub aktywuje podświetloną akcję, a `Escape` zamyka okno. Wiersz **+ Utwórz folder** znajduje się na górze listy.

## Notatki biblijne

| Skrót | Działanie |
| ----- | --------- |
| `↑ Strzałka w górę` / `↓ Strzałka w dół` | Zaznacz notatkę |
| `Return` | Otwórz notatkę |
| `Cmd + Return` | Ustaw fokus w polu filtra |
| `Escape` | Zamknij szczegóły / edytor |

## Podświetlenia

| Skrót | Działanie |
| ----- | --------- |
| `↑ Strzałka w górę` / `↓ Strzałka w dół` | Zaznacz podświetlenie |
| `Return` | Otwórz podświetlenie |
| `Cmd + Return` | Ustaw fokus w polu filtra |
| `Escape` | Zamknij panel szczegółów |

## Lista Biblii

| Skrót | Działanie |
| ----- | --------- |
| `Tab` / `→ Strzałka w prawo` / `↓ Strzałka w dół` | Następna Biblia |
| `← Strzałka w lewo` / `↑ Strzałka w górę` | Poprzednia Biblia |
| `Return` | Otwórz zaznaczoną Biblię |
| `Cmd + Shift + S` | Przełącz ulubioną dla zaznaczonej Biblii |
| `Escape` | Wróć |

## Ekran ksiąg biblijnych

| Skrót | Działanie |
| ----- | --------- |
| `Tab` / `→ Strzałka w prawo` | Następna księga |
| `← Strzałka w lewo` | Poprzednia księga |
| `↓ Strzałka w dół` | Księga poniżej w siatce |
| `↑ Strzałka w górę` | Księga powyżej w siatce |
| `Cmd + ↓` | Następna sekcja (ST / NT) |
| `Cmd + ↑` | Poprzednia sekcja (ST / NT) |
| `Return` | Otwórz zaznaczoną księgę |
| `Escape` | Wróć |

## Lista ksiąg

| Skrót | Działanie |
| ----- | --------- |
| `Tab` / `→ Strzałka w prawo` / `↓ Strzałka w dół` | Następna księga |
| `← Strzałka w lewo` / `↑ Strzałka w górę` | Poprzednia księga |
| `Return` | Otwórz zaznaczoną księgę |
| `Escape` | Wróć |

## Ekran rozdziałów Biblii

| Skrót | Działanie |
| ----- | --------- |
| `Tab` / `→ Strzałka w prawo` / `↓ Strzałka w dół` | Następny rozdział |
| `← Strzałka w lewo` / `↑ Strzałka w górę` | Poprzedni rozdział |
| `Return` | Otwórz zaznaczony rozdział |
| `Escape` | Wróć |

## Ekran rozdziałów ksiąg

| Skrót | Działanie |
| ----- | --------- |
| `Tab` / `↓ Strzałka w dół` | Następny rozdział |
| `↑ Strzałka w górę` | Poprzedni rozdział |
| `Return` | Otwórz zaznaczony rozdział |
| `Cmd + Return` | Ustaw fokus w polu wyszukiwania / filtra |
| `Escape` | Wróć |

## Lista rozważań

| Skrót | Działanie |
| ----- | --------- |
| `Tab` / `→ Strzałka w prawo` / `↓ Strzałka w dół` | Następne rozważanie |
| `← Strzałka w lewo` / `↑ Strzałka w górę` | Poprzednie rozważanie |
| `Return` | Otwórz zaznaczone rozważanie |
| `Escape` | Wróć |

## Główne menu (gdy otwarte)

| Skrót | Działanie |
| ----- | --------- |
| `↑ Strzałka w górę` | Poprzednia pozycja menu |
| `↓ Strzałka w dół` | Następna pozycja menu |
| `Return` | Wybierz podświetloną pozycję |
| `Escape` | Zamknij menu |

## Ustawienia

| Skrót | Działanie |
| ----- | --------- |
| `Escape` | Zamknij otwarty modal / picker |

## Okna edytora

| Skrót | Działanie |
| ----- | --------- |
| `Cmd + S` | Zapisz |
| `Escape` | Anuluj / zamknij |

## Ochrona podczas pisania

Gdy fokus znajduje się w polu tekstowym (pole wyszukiwania, edytor notatek, pole AI), skróty bez klawisza `Cmd`, takie jak strzałki i `Spacja`, są wyciszone, aby przypadkowo nie wywołały nawigacji. Skróty z klawiszem `Cmd` (np. `Cmd + S`, `Cmd + B`) nadal działają podczas pisania.
