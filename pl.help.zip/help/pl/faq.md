---
title: Najczęściej zadawane pytania
level: everyday
categories: faq
summary: Odpowiedzi na najczęstsze pytania o korzystaniu z Theodii.
---

# Najczęściej zadawane pytania

## Czy Theodia jest płatna?

Theodia to zakup jednorazowy. Nie ma subskrypcji, reklam, zakupów w aplikacji ani próśb o datki. Wszystkie dodatkowe zasoby w katalogu są bezpłatne do pobrania po zakupie aplikacji.

## Czy potrzebuję połączenia internetowego?

Nie. Gdy aplikacja i jej pliki danych zostaną zainstalowane, wszystko działa offline. Możesz czytać, szukać, podświetlać, pisać notatki i używać większości narzędzi studyjnych bez zasięgu.

Jedyną funkcją wymagającą internetu jest pobieranie nowych zasobów.

## Gdzie przechowywane są moje dane?

Wszystkie zakładki, podświetlenia, notatki i ustawienia zapisywane są na Twoim urządzeniu. Nie są wysyłane na żaden serwer.

Możesz wykonać kopię zapasową ręcznie. Zobacz przewodnik [Tworzenie kopii zapasowych danych](theodia://help/backups), aby dowiedzieć się jak.

## Czy mogę słuchać Biblii na głos?

Tak. Otwórz dowolny rozdział, dotknij menu i wybierz opcję czytania na głos. Na urządzeniu musi być zainstalowany głos syntezy mowy. Więcej informacji znajdziesz w przewodniku [Czytanie na głos](theodia://help/tts).

## Jak wyszukać werset?

Możesz wpisać odwołanie, takie jak `Jan 3:16`, w pole **Szybkie polecenie** na ekranie głównym, lub użyć zakładki **Szukaj**, aby szukać po słowie lub frazie.

## Jak zgłosić błąd lub zaproponować funkcję?

Dotknij **Prześlij sugestię/problem** na ekranie **O aplikacji**, [zgłoś to na GitHubie](https://github.com/ecodiallc/theodia.app/issues/new) lub odwiedź stronę [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions).

## Jakie urządzenia są obsługiwane?

Theodia działa na iPhonie, iPadzie oraz telefonach i tabletach z Androidem. Najlepiej sprawdza się na urządzeniach z co najmniej 2 GB wolnej pamięci na podstawowe pliki danych.

## Czy mogę używać zewnętrznej klawiatury?

Tak. Theodia obsługuje klawiatury Bluetooth i USB na iPadzie. Nawigacja, wyszukiwanie i wiele funkcji czytania ma skróty klawiszowe. Pełną listę znajdziesz w przewodniku [Skróty klawiatury zewnętrznej](theodia://help/external-keyboard-shortcuts).

## Jakie języki są obsługiwane?

Interfejs aplikacji jest dostępny po angielsku, arabsku, po chińsku (uproszczonym i tradycyjnym), czesku, duńsku, holendersku, filipińsku, francusku, niemiecku, grecku, hebrajsku, hindi, indonezyjsku, włosku, japońsku, koreańsku, polsku, portugalsku (Brazylia), rumuńsku, rosyjsku, hiszpańsku, szwedzku, tajsku, turecku, ukraińsku i wietnamsku.

Język tekstu biblijnego zależy od zainstalowanych tłumaczeń.

## Jak zmienić język?

Przejdź do **Ustawienia** i znajdź opcję języka.

## Nie ma tu mojego pytania. Gdzie mogę uzyskać więcej pomocy?

Przeglądaj pozostałe przewodniki pomocy według tematu lub zadaj pytanie w społeczności [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions).

Wskazówka: Na głównym ekranie **Pomoc i przewodniki** wpisz słowo w polu wyszukiwania, np. `powiadomienia` lub `szukaj`, aby znaleźć pasujący przewodnik.
