---
title: Czytanie pierwszego rozdziału
level: beginner
categories: [start, read]
summary: Przewodnik krok po kroku: jak otworzyć i przeczytać rozdział.
---

# Czytanie pierwszego rozdziału

Ten przewodnik prowadzi Cię przez otwieranie rozdziału po raz pierwszy.

## Krok 1: Otwórz zakładkę Biblia

Spójrz na dolną część ekranu. Zobaczysz rząd zakładek. Dotknij tej, która nazywa się **Biblie**.

## Krok 2: Wybierz księgę

Zobaczysz listę ksiąg biblijnych. Księga Rodzaju jest pierwsza. Ewangelia Jana jest mniej więcej w środku. Apokalipsa jest ostatnia.

Dotknij nazwy księgi, którą chcesz czytać.

## Krok 3: Wybierz rozdział

Zobaczysz liczby od 1 do liczby rozdziałów w danej księdze. Dotknij wybranego rozdziału.

Rozdział się otworzy. Wersety pojawią się na ekranie.

## Krok 4: Poruszaj się po tekście

- Przesuń palcem **w lewo**, aby przejść do następnego rozdziału.
- Przesuń palcem **w prawo**, aby wrócić.

## Krok 5: Interakcja z wersetem

To, co możesz zrobić z wersem, zależy od trybu użytkownika.

### Tryb Czytanie

Tryb **Czytanie** jest czysty i pozbawiony rozpraszaczy.

- Dotknij wersetu, aby na chwilę go podświetlić.
- Nie ma narzędzi studyjnych, zakładek ani menu.
- Jeśli chcesz więcej funkcji, przełącz się na tryb **Standardowy** lub **Uczony** w **Ustawienia**.

### Tryb Standardowy

Tryb **Standardowy** dodaje codzienne funkcje do osobistego studium Biblii.

Dotknij wersetu, aby otworzyć menu z opcjami:

- **Zakładka** — zapisz werset.
- **Podświetl** — oznacz werset kolorem.
- **Notatka** — dodaj do niego notatkę.
- **Kopiuj** — skopiuj tekst wersetu.
- **Porównaj** — porównaj werset w innym tłumaczeniu.
- **Odniesienia krzyżowe** — znajdź powiązane wersety.

### Tryb Uczony

Tryb **Uczony** odblokowuje wszystkie narzędzia do głębokiego studium Biblii.

Dotknij wersetu, aby otworzyć menu ze wszystkimi opcjami z trybu Standardowego oraz:

- **Komentarz** do wersetu.
- **Informacje o słowie** i wyszukiwania w językach oryginalnych.
- **Słownik** — definicje.
- **Asystent AI** do pogłębionych studiów.

Tryb możesz zmienić w dowolnym momencie w **Ustawienia**.

## Potrzebujesz pomocy z konkretnym narzędziem?

Każde narzędzie ma swój przewodnik. Dotknij **Pomoc** na ekranie głównym, aby zobaczyć je wszystkie. Dobrym miejscem na start jest przewodnik [Tryb studium](theodia://help/study-mode) — opisuje każde narzędzie w menu wersetu.

Jeśli nadal uczysz się, gdzie co jest, zobacz przewodnik [Układ aplikacji i nawigacja](theodia://help/navigating-the-app). Wyjaśnia ekran główny, główne menu i dolny pasek narzędzi.

## Chcesz więcej zasobów?

Aplikacja zawiera kilka bezpłatnie dostępnych wersji Biblii. Jeśli chcesz dodać więcej tłumaczeń, komentarzy, ksiąg lub rozważań, zobacz przewodnik [Pobieranie dodatkowych zasobów z GitHuba](theodia://help/getting-core-files). Pokazuje, gdzie je znaleźć i jak dodać.
