---
title: Tryb skupienia
level: beginner
categories: [layout, read]
summary: Czysty, pozbawiony rozpraszaczy sposób czytania dłuższych fragmentów.
---

# Tryb skupienia

> **Tryb:** Tryb skupienia to czytnik w trybie **Czytanie**. Jest też dostępny w trybach **Standardowy** i **Uczony** jako alternatywa dla trybu studium. Tryb możesz zmienić w **Ustawienia** → **Tryb użytkownika aplikacji**.

Tryb skupienia pozwala czytać rozdział Biblii bez przycisków i menu na drodze. Sprawdza się przy dłuższych sesjach czytania.

## Jak włączyć

1. Otwórz dowolny rozdział.
2. W rzędzie ikon u góry ekranu dotknij przycisku 📖. Otworzy się ten sam rozdział w trybie skupienia.
3. Menu i przyciski ukryją. Zostanie sam tekst Biblii.

W trybie **Czytanie** rozdziały otwierają się automatycznie w trybie skupienia. Przycisk 📖 jest ukryty, ponieważ nie ma tam trybu studium, na który można by przełączyć.

## Co możesz robić w trybie skupienia

- **Przewijaj**, aby czytać.
- **Przesuwaj palcem**, aby przejść do następnego lub poprzedniego rozdziału.
- **Dotknij przycisku 📖** na dolnym pasku, aby wrócić do trybu studium. (Ukryty w trybie Czytanie.)
- **Dotknij przycisku 🔊** na dolnym pasku, aby rozdział był czytany na głos. Pojawi się mini pasek sterowania z odtwarzaniem, wstrzymywaniem, przewijaniem, szybkim przewijaniem i wyborem głosu. (Ukryty w trybie Czytanie — czytanie na głos wymaga trybu Standardowy lub Uczony.)

## Kiedy warto używać trybu skupienia

- Czytanie całej księgi, rozdział po rozdziale.
- Czytanie dłuższego fragmentu na czytanie lub chwilę ciszy.
- Czytanie na głos i podążanie wzrokiem bez rozpraszaczy.

## Przełączanie do trybu studium

Tryb skupienia ukrywa wszystkie narzędzia studyjne, ale są one w zasięgu jednego dotknięcia. Dotknij przycisku 📖 u góry ekranu, aby otworzyć ten sam rozdział w [trybie studium](theodia://help/study-mode). Tryb studium to pełny czytnik z komentarzami, odniesieniami krzyżowymi, wyszukiwaniem w leksykonach i notatkami. Aby dowiedzieć się, co potrafi tryb studium, zobacz przewodnik [Tryb studium](theodia://help/study-mode).

W trybie **Czytanie** przycisk 📖 jest ukryty, ponieważ tryb studium nie jest tam dostępny.
