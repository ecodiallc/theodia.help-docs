---
title: Szybka nawigacja
level: beginner
categories: layout
summary: Wszystkie szybkie sposoby na przejście do wersetu, rozdziału lub ekranu w Theodii.
---

# Szybka nawigacja

Ten przewodnik to ściągawka z nawigacji. Opisuje każdy szybki sposób na przejście z miejsca, w którym jesteś, do miejsca, w które chcesz trafić.

## Skok bezpośrednio do wersetu

Najszybszy sposób to **Szybkie polecenie** na ekranie głównym.

- Wpisz `Jan 3:16` i dotknij **Idź**.
- Wpisz `Psalmy 23` i dotknij **Idź**.
- Wpisz `Rdz 1` i dotknij **Idź**.

Aplikacja otworzy dokładny rozdział (i przewinie do wersetu, jeśli go podałeś).

## Przesuwanie między rozdziałami

Gdy czytasz rozdział:

- **Przesunięcie w lewo** → następny rozdział.
- **Przesunięcie w prawo** → poprzedni rozdział.

Działa to także między księgami. Po Księdze Wyjścia 40 przesunięcie w lewo przeniesie Cię do Księgi Kapłańskiej 1.

## Górny pasek

Podczas czytania u góry ekranu widoczne są aktualne **tłumaczenie**, **księga** i **rozdział**.

- Dotknij nazwy tłumaczenia, aby zmienić Biblię.
- Dotknij nazwy księgi, aby wybrać inną księgę.
- Dotknij numeru rozdziału, aby wybrać inny rozdział.

## Skok z zakładki

Jeśli zapisałeś werset:

1. Otwórz zakładkę **Zakładki**.
2. Dotknij dowolnego wpisu.
3. Przeniesiesz się bezpośrednio do tego wersetu.

## Skok z wyszukiwania

1. Otwórz zakładkę **Szukaj**.
2. Wpisz słowo lub frazę.
3. Dotknij dowolnego wyniku.
4. Aplikacja otworzy rozdział z wyszukiwanymi słowami podświetlonymi na żółto.

## Przełączanie układów czytania

Czytnik Biblii ma dwa układy:

- **Tryb studium** — pokazuje rozdział z narzędziami studyjnymi w zasięgu jednego dotknięcia.
- **Tryb skupienia** — ukrywa wszystkie narzędzia i menu, zostawiając sam tekst.

Aby przełączyć: dotknij przycisku **📖** u góry ekranu podczas czytania. Dotknij go ponownie, aby wrócić. (W trybie Czytanie zawsze pozostajesz w trybie skupienia.)

## Dolne zakładki

Rząd ikon na dole ekranu jest zawsze widoczny. Dotknij dowolnej zakładki, aby przejść do tej sekcji. Dokładny zestaw zależy od trybu użytkownika:

**Wszystkie tryby:**

- **Strona główna** — powrót na ekran główny.
- **Biblie** — lista tłumaczeń.
- **Szukaj** — wyszukiwanie biblijne.
- **Ustawienia** — preferencje i zasoby.

**Standardowy i Uczony dodatkowo widzą:**

- **Zakładki** — zapisane wersety.
- **Podświetlenia** — wersety oznaczone kolorem.
- **Notatki biblijne** — Twoje prywatne notatki.

**Uczony dodatkowo widzi:**

- **AI** — asystent AI (jeśli włączony w Ustawieniach).

### Zapamiętywanie miejsca

Każda zakładka prowadzi własną historię nawigacji. Gdy wracasz do zakładki, trafiasz do **miejsca, w którym skończyłeś**, a nie na początkowy ekran sekcji.

- Otwierasz zakładkę **Biblie**, wybierasz tłumaczenie, otwierasz rozdział, a potem przechodzisz do **Szukaj**. Później dotkniesz **Biblie** i wracasz dokładnie do tego samego rozdziału.
- Otwierasz zakładkę **Zakładki**, dotkniesz zapisanego wersetu, a potem przechodzisz do **Ustawienia**. Dotknięcie **Zakładki** ponownie zwraca Cię do listy zakładek.

Dotyczy to każdej zakładki. Każda pamięta Twoje miejsce, dopóki sam nie przejdziesz do innego ekranu w tej zakładce.

### Co resetuje zakładkę

Zakładka wraca do swojego ekranu początkowego tylko wtedy, gdy:

- Jesteś już na tej zakładce i dotkniesz jej ikony ponownie. To szybki sposób na reset.
- Aplikacja została zamknięta na siłę i otworzona ponownie.

### Dolne zakładki a główne menu

- **Dolne zakładki** — każda zakładka pamięta własny stos. Dotknięcie zakładki wraca Cię do miejsca, w którym skończyłeś.
- **Główne menu** — dotknięcie pozycji przenosi Cię do danego ekranu. To lista rozwijana, nie nakładka.

Przykład:

- Czytasz Jana 3. Dotkniesz zakładki **Zakładki**, a potem ponownie **Biblie**. Wracasz do Jana 3.
- Czytasz Jana 3. Otwierasz menu i dotkniesz **Notatki biblijne**. Przejrzyj notatki, a potem dotknij zakładki **Biblie**, aby wrócić do Jana 3.

## Wskazówki

- Ekran główny pamięta, które sekcje są rozwinięte, a które zwinięte.
- Jeśli brakuje jakiejś zakładki, sprawdź swój **tryb użytkownika** w **Ustawienia** → **Tryb użytkownika aplikacji**. Tryb Czytanie ukrywa zakładki Zakładki, Podświetlenia, Notatki i AI. Tryb Standardowy ukrywa AI. Może być też konieczne włączenie funkcji w **Ustawienia** lub zainstalowanie zasobu.
