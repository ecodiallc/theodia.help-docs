---
title: Pobieranie dodatkowych zasobów
level: everyday
categories: resources
summary: Jak dodawać do Theodii Biblie, komentarze, księgi i inne zasoby.
---

# Pobieranie dodatkowych zasobów

Theodia zawiera w zestawie kilka zasobów, ale możesz dodać więcej. Najłatwiejszy sposób to ekran **Zarządzaj zasobami** wewnątrz aplikacji.

## Co możesz dodać

- **Biblie** — więcej tłumaczeń w różnych językach
- **Komentarze** — notatki studyjne wyjaśniające wersety
- **Księgi** — klasyka chrześcijańska i prace referencyjne
- **Rozważania** — codzienne czytania dewocyjne
- **Pliki podstawowe** — większe pliki danych, takie jak morfologia, odniesienia krzyżowe i Biblia międzywierszowa Marvel (MIB)

## Jak dodawać zasoby z poziomu aplikacji

1. Otwórz **Ustawienia**.
2. Dotknij **Zarządzaj zasobami**.
3. Wybierz zakładkę: **Rdzeń**, **Biblie**, **Komentarze**, **Księgi** lub **Rozważania**.
4. Przeglądaj listę. Dotknij zasobu, aby przeczytać o nim więcej.
5. Dotknij pola wyboru, aby zaznaczyć to, czego chcesz.
6. Dotknij **Pobierz** u dołu. Pliki pobiorą się i zainstalują automatycznie.

Po zainstalowaniu zasób pojawia się w aplikacji od razu. Nie musisz uruchamiać jej ponownie.

## Pliki podstawowe

Zakładka **Podstawowe** zawiera duże pliki danych zasilające głębsze narzędzia studyjne. Obejmują:

- Dane morfologiczne (formy słów w językach oryginalnych)
- Bazy odniesień krzyżowych
- Biblię międzywierszową Marvel (MIB)

Pliki podstawowe wystarczy pobrać raz. Pozostają na urządzeniu i działają offline.

## Globalne Biblie

Zakładka **Globalne Biblie** zawiera tłumaczenia z szerszej kolekcji. Jeśli nie widzisz potrzebnego tłumaczenia w głównej zakładce **Biblie**, sprawdź tutaj.

## Zarządzanie zainstalowanymi zasobami

Na głównym ekranie **Zarządzaj zasobami** (nie w zakładce pobierania) możesz:

- **Włącz lub wyłącz** zasób bez usuwania go. Wyłączone zasoby pozostają na urządzeniu, ale są ukryte w menu.
- **Usuń** zasób, aby zwolnić miejsce. Możesz go pobrać ponownie później.

## Dodawanie własnych plików

Jeśli masz plik zasobu z innego źródła — od znajomego, innego projektu lub strony — możesz zaimportować go bezpośrednio:

1. W **Zarządzaj zasobami** dotknij **Zainstaluj plik lokalny**.
2. Wybierz plik z urządzenia.
3. Aplikacja odczyta plik i doda go do biblioteki.

Aplikacja akceptuje takie typy plików:

- `.bible` — tłumaczenia Biblii
- `.commentary` — komentarze
- `.lexicon` — leksykony
- `.book` — księgi
- `.devotional` — rozważania

## Podłączanie niestandardowego repozytorium GitHub

Jeśli ktoś prowadzi repozytorium GitHub z zasobami kompatybilnymi z Theodią, możesz dodać je jako własne źródło:

1. Przejdź do **Ustawienia → Repozytoria GitHub**.
2. Dotknij **Dodaj repozytorium**.
3. Wpisz adres URL GitHub (na przykład `https://github.com/użytkownik/nazwa-repozytorium`).
4. Wybierz, jakie rodzaje zasobów zawiera repozytorium (Biblie, komentarze lub księgi).
5. Zapisz.
6. Wróć do **Zarządzaj zasobami**. Pojawi się nowa zakładka z zasobami z tego repozytorium.

Jeśli repozytorium jest prywatne, musisz dodać **Personal Access Token** w **Ustawienia → Repozytoria GitHub**, aby aplikacja mogła je odczytać.

## Uwaga o rozmiarach plików

Pliki zasobów mogą być duże. Biblie są zwykle małe (kilka megabajtów). Komentarze i pliki podstawowe mogą być znacznie większe (setki megabajtów). Kiedy to możliwe, pobieraj przez Wi-Fi.

## Podsumowanie

- Użyj **Ustawienia → Zarządzaj zasobami**, aby przeglądać i instalować zasoby.
- Pliki podstawowe odblokowują głębsze narzędzia studyjne, takie jak morfologia i odniesienia krzyżowe.
- Importuj pliki lokalne, jeśli masz własne.
- Dodawaj niestandardowe repozytoria GitHub, jeśli chcesz zasoby z innego źródła.
