---
title: Gdzie zadawać pytania
level: everyday
categories: trouble
summary: Jak uzyskać pomoc od zespołu i społeczności Theodii oraz jak znaleźć tematy pomocy w aplikacji.
---

# Gdzie zadawać pytania

Jeśli utknąłeś, jest kilka miejsc, w których możesz zapytać o pomoc.

## Znajdowanie tematu pomocy

Jeśli szukasz informacji o konkretnej funkcji, spróbuj jednej z tych ścieżek:

- **Przeglądaj według kategorii.** Otwórz **Pomoc i przewodniki** i dotknij kategorii, takiej jak **Ustawienia i dostosowywanie** lub **Rozwiązywanie problemów**. Każda karta zawiera powiązane przewodniki.
- **Szukaj po słowie kluczowym.** Na głównym ekranie **Pomoc i przewodniki** wpisz słowo w polu wyszukiwania u góry. Na przykład wpisanie `powiadomienia` pokaże przewodnik [Powiadomienia i przypomnienia](theodia://help/notifications); wpisanie `szukaj` pokaże przewodnik [Wyszukiwanie w Biblii](theodia://help/search-the-bible).
- **Najpierw sprawdź Ustawienia.** Wiele funkcji konfiguruje się w **Ustawienia**. Jeśli chcesz ustawić przypomnienia, otwórz **Ustawienia** → **Powiadomienia**. Ekran ustawień ma też link **Pomoc** dla każdej sekcji.

## W aplikacji

Otwórz ekran **O aplikacji**. Zobaczysz dwa przyciski:

- **Prześlij sugestię/problem** — otwiera formularz do wysłania zespołowi pytania, pomysłu lub zgłoszenia błędu.
- **Dyskusja/opinia** — otwiera tablicę dyskusyjną społeczności.

## Strona GitHub

Listę znanych problemów i ostatnich zmian znajdziesz na [GitHubie](https://github.com/ecodiallc/theodia.app).

## Dyskusja społecznościowa

Inni użytkownicy Theodii zadają pytania i dzielą się wskazówkami na [tablicy dyskusyjnej społeczności](https://github.com/ecodiallc/theodia.app/discussions). Możesz przeczytać stare wątki i rozpocząć nowy.

## Zanim zapytasz

Kilka informacji pomoże nam odpowiedzieć szybciej:

- **Jakie masz urządzenie?** (np. iPhone 13, Pixel 7)
- **Jaka wersja aplikacji?** (Zobacz na ekranie **O aplikacji**.)
- **Co zrobiłeś?** Krótki opis kroków.
- **Co się stało?** To, co zobaczyłeś na ekranie.
- **Co się spodziewałeś?** To często najbardziej pomocna część.

## Czego się spodziewać

- W przypadku zgłoszeń błędów zespół zazwyczaj odpowiada w ciągu kilku dni.
- Pomysły czytamy wszystkie. Nie możemy obiecać, kiedy dana funkcja zostanie dodana.
- W przypadku pytań społecznościowych inni użytkownicy często odpowiadają szybciej niż zespół.

## Uwaga o prywatności

Gdy przesyłasz pytanie, nie dołączaj prywatnych informacji. Zespół widzi to, co wysyłasz.
