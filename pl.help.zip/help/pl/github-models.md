---
title: GitHub Models
level: advanced
categories: ai
summary: Skonfiguruj GitHub Models — bezpłatny sposób na rozpoczęcie eksploracji AI w Theodii bez istniejącej subskrypcji API.
---

# GitHub Models

> **Tryb:** Asystent AI wymaga trybu **Uczony**. Tryb możesz zmienić w **Ustawienia** → **Tryb użytkownika aplikacji**.

Jeśli nie płacisz jeszcze za usługę AI, **GitHub Models** to najłatwiejszy sposób na rozpoczęcie eksploracji AI w Theodii. Pozwala zacząć bezpłatnie, a wszystko, czego potrzebujesz, to darmowe konto GitHub.

## Czym jest GitHub Models?

GitHub Models to usługa GitHub, która pozwala uruchamiać nowoczesne modele AI przez API. Obsługuje ten sam format co OpenAI, więc działa z Theodią bez problemu.

## Dlaczego GitHub Models?

- **Nie wymaga karty kredytowej** — wystarczy konto GitHub.
- **Wysokiej jakości modele** — dostajesz dostęp do GPT-4o, GPT-4.1 i innych niezawodnych modeli obsługujących narzędzia Theodii.
- **Łatwa konfiguracja** — jeden token, jeden adres URL i gotowe.

## Krok 1: Utwórz konto GitHub

Jeśli już masz konto GitHub, przejdź do kroku 2.

1. Wejdź na [github.com](https://github.com).
2. Dotknij **Sign up** i postępuj zgodnie z instrukcjami, aby utworzyć darmowe konto.
3. Zweryfikuj adres e-mail, gdy GitHub wyśle potwierdzenie.

## Krok 2: Utwórz Personal Access Token

Ten token to Twój klucz API. Informuje GitHub, kim jesteś, gdy Theodia wysyła pytania.

1. Wejdź na [github.com/settings/tokens](https://github.com/settings/tokens).
2. Dotknij **Generate new token** i wybierz **Generate new token (classic)**.
3. Nadaj tokenowi nazwę, na przykład **Theodia AI**.
4. W sekcji **Select scopes** zaznacz pole **`models:read`**.
   - To jedyny uprawnienie, którego potrzebuje Theodia.
5. Przewiń na dół i dotknij **Generate token**.
6. **Skopiuj token natychmiast.** GitHub pokaże go tylko raz. Wklej go w bezpieczne miejsce (np. notatki w telefonie), dopóki nie dodasz go do Theodii.

## Krok 3: Wybierz model

GitHub Models oferuje kilka modeli. Dla Theodii najlepsze są te opcje:

| Model | Dzienny darmowy limit | Najlepszy do |
| ----- | --------------------- | ------------ |
| `openai/gpt-4.1-nano` | 150 zapytań / dzień | Szybkich pytań i prostych wyjaśnień wersetów |
| `openai/gpt-4.1-mini` | 150 zapytań / dzień | Ogólnych studiów z dobrym wsparciem narzędzi |
| `openai/gpt-4.1` | 50 zapytań / dzień | Głębszych studiów i złożonych pytań wieloetapowych |
| `openai/gpt-4o` | 50 zapytań / dzień | Wszechstronnych zastosowań, doskonałego wsparcia narzędzi |

Zacznij od **`openai/gpt-4.1-mini`** — jest szybki, niezawodny i ma wyższy dzienny limit zapytań.

## Krok 4: Skonfiguruj Theodię

1. Otwórz **Theodię**.
2. Przejdź do **Ustawienia** → **Asystent AI**.
3. Upewnij się, że wybrano **Model zdalny**.
4. Dotknij rozwijanej listy **Dostawca** i wybierz **GitHub Models**.
   - Jeśli GitHub Models nie ma na liście, dotknij **Niestandardowy** i wpisuj podstawowy adres URL ręcznie: `https://models.github.ai`
5. Wklej swój GitHub Personal Access Token w pole **Klucz API**.
6. Wpisz wybrany identyfikator modelu w pole **Model** (na przykład: `openai/gpt-4.1-mini`).
7. Dotknij **Testuj połączenie**.
8. Poczekaj na zakończenie sprawdzania. Powinieneś zobaczyć:
   - **✓ Połączenie udane**
   - **✓ Narzędzia obsługiwane**

Jeśli zobaczysz **✗ Narzędzia nieobsługiwane**, spróbuj innego identyfikatora modelu z tabeli powyżej.

## Krok 5: Zacznij rozmowę

1. Dotknij zakładki **AI** na dole ekranu.
2. Wpisz pytanie i dotknij **Wyślij**.
3. Lub, czytając dowolny rozdział Biblii, dotknij numeru wersetu i wybierz **Komentarz AI**, aby rozpocząć rozmowę dotyczącą konkretnego wersetu.

## Rozwiązywanie problemów

### „Connection failed” lub „HTTP 401”

- Upewnij się, że skopiowałeś **cały** token. To długi ciąg znaków zaczynający się od `ghp_`.
- Tokeny wygasają, jeśli długo nie są używane. Wróć na GitHuba i wygeneruj nowy.
- Sprawdź, czy podczas tworzenia tokena wybrałeś **models:read**.

### „Tools not supported”

- Niektóre modele w GitHub Models nie akceptują wywołań narzędzi. Spróbuj zamiast tego **`openai/gpt-4o`** lub **`openai/gpt-4.1-mini`**.
- Upewnij się, że identyfikator modelu jest wpisany dokładnie jak w tabeli, wraz z prefiksem `openai/`.

### Błędy limitu zapytań

- Jeśli osiągnąłeś dzienny limit, przełącz się na model z wyższym limitem (np. `openai/gpt-4.1-nano` z 150 zapytaniami dziennie).
- Limity resetują się co 24 godziny.

## Podsumowanie

- GitHub Models to **zalecany sposób na rozpoczęcie eksploracji AI** w Theodii.
- Potrzebujesz **bezpłatnego konta GitHub** i **Personal Access Token** z uprawnieniem `models:read`.
- Najlepszy model na start to **`openai/gpt-4.1-mini`**.
- Wpisz token i model w **Ustawienia → Asystent AI**, dotknij **Testuj połączenie** i zacznij rozmawiać.
