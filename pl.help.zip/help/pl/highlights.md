---
title: Podświetlanie wersetów
level: everyday
categories: [annotate, read]
summary: Jak oznaczać wersety kolorem i odnajdywać je później.
---

# Podświetlanie wersetów

> **Tryb:** Podświetlenia są dostępne w trybach **Standardowy** i **Badacz**. Tryb skupienia służy tylko do czystego czytania bez rozpraszania uwagi. Możesz zmienić tryb w **Ustawienia** → **Tryb użytkownika**.

Podświetlenie oznacza werset kolorem. Działa jak żółty marker na papierze. Werset pozostaje podświetlony przy następnym otwarciu.

## Jak podświetlić werset

1. Otwórz werset.
2. Stuknij werset, aby wyświetlić menu.
3. Stuknij ikonę **Podświetl**.
4. Wybierz kolor.

Werset jest teraz podświetlony tym kolorem.

## Jak zmienić kolor podświetlenia

1. Otwórz werset.
2. Stuknij werset, a następnie stuknij ikonę **Podświetl**.
3. Wybierz nowy kolor.

## Jak usunąć podświetlenie

1. Otwórz werset.
2. Stuknij werset, a następnie stuknij **Podświetl** w menu.
3. Stuknij **Usuń podświetlenie** u dołu palety kolorów.

## Powszechny sposób użycia kolorów

Wielu czytelników używa małego zestawu kolorów do określonych celów:

- **Żółty** dla ulubionych wersetów.
- **Zielony** dla wersetów o Bogu.
- **Niebieski** dla wersetów o modlitwie.
- **Różowy** dla wersetów o pocieszeniu.
- **Pomarańczowy** dla wersetów o ostrzeżeniu lub naprawie.
- **Fioletowy** dla wersetów o proroctwie lub czasach ostatecznych.

Wybierz system, który Ci odpowiada.

## Jak zobaczyć wszystkie podświetlenia

Stuknij zakładkę **Podświetlenia** na dole ekranu. Zobaczysz listę każdego podświetlonego wersetu, od najnowszego. U góry jest rząd kolorowych chipsów — stuknij kolor, aby pokazać tylko podświetlenia tego koloru, lub stuknij **Wszystko**, aby wyczyścić filtr.

## Importowanie podświetleń

Możesz importować podświetlenia do Theodii z innych aplikacji i plików.

Przejdź do **Ustawienia** → **Zakładki** → **Importuj podświetlenia**. Wybierz **Importuj z pliku** lub wklej ze schowka. Aplikacja automatycznie wykryje format.

### Obsługiwane formaty

**Natywny eksport JSON** — format używany przez własną funkcję eksportu Theodii:

```json
{
  "/bible/KJV/John/3#v3_16": "yellow",
  "/bible/KJV/Genesis/1#v1_1": "green"
}
```

**CSV** — arkusz kalkulacyjny z kolumnami `url` i `color`. Przykład:

```csv
url,color
/bible/KJV/John/3#v3_16,yellow
/bible/KJV/Genesis/1#v1_1,green
```

**Zwykły tekst** — każdy wiersz to odniesienie biblijne lub adres URL, opcjonalnie z nazwą koloru. Przykład:

```
John 3:16 yellow
Genesis 1:1 green
Matthew 5:1
```

- Dostępne kolory: `yellow`, `green`, `blue`, `pink`, `orange`, `purple`.
- Jeśli nie podano koloru, podświetlenie domyślnie staje się żółte.
- Wiersze zaczynające się od `#` lub `//` są traktowane jako komentarze i pomijane.

## Wskazówki

- Podświetlenia pozostają na Twoim urządzeniu. Nie są synchronizowane z chmurą.
- Możesz podświetlić werset w jednym przekładzie, a podświetlenie pojawi się w innych przekładach tego samego wersetu.
- Zobacz przewodnik [Tworzenie kopii zapasowych danych](theodia://help/backups), aby je zabezpieczyć.
