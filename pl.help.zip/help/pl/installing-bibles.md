---
title: Instalowanie przekładów Biblii
level: beginner
categories: start
summary: Jak dodać przekład Biblii do swojej biblioteki.
---

# Instalowanie przekładów Biblii

Theodia zawiera kilka przekładów Biblii gotowych do czytania. Możesz dodać więcej w dowolnej chwili. „Przekład” to inna wersja tekstu biblijnego, na przykład King James Version.

## Jak dodać przekład

Zakładka Biblii pokazuje listę już zainstalowanych przekładów. Aby dodać więcej, otwórz menedżera zasobów:

1. Otwórz **Ustawienia**.
2. Stuknij **Zarządzaj zasobami**.
3. Stuknij **Pobierz z GitHuba**.
4. W oknie pobierania stuknij zakładkę **Biblie**.
5. Stuknij pole wyboru obok każdego przekładu, którego chcesz.
6. Stuknij **Zainstaluj wybrane** u dołu.
7. Poczekaj, aż pobieranie się zakończy.

Przekład jest teraz w Twojej bibliotece. Aby go zobaczyć, otwórz zakładkę **Biblie**.

## Jak przełączać się między przekładami

1. Otwórz rozdział, który chcesz czytać.
2. Stuknij nazwę przekładu u góry ekranu.
3. Wybierz przekład z listy.

Aplikacja zapamiętuje Twój wybór na przyszłość.

## Jak usunąć przekład

1. Otwórz **Ustawienia**.
2. Stuknij **Zarządzaj zasobami**.
3. Znajdź przekład, który chcesz usunąć.
4. Stuknij **X** obok niego.
5. Potwierdź usunięcie.

Usunięcie przekładu nie usuwa Twoich notatek, podświetleń ani zakładek. Pozostają bezpieczne.

## Ile miejsca zajmują przekłady?

Większość przekładów ma od 2 do 10 MB. Są przechowywane na Twoim urządzeniu, nie w chmurze. Możesz zachować ich tyle, ile pomieści urządzenie.

## Co zrobić, jeśli przekładu nie ma w aplikacji?

Niektóre przekłady nie znajdują się na liście w aplikacji. Możesz je jednak dodać.

1. Otwórz aplikację i przejdź do **Ustawienia** → **Zarządzaj zasobami**.
2. Stuknij **Pobierz z GitHuba**.
3. W oknie pobierania zajrzyj do zakładki **Biblie** i **Biblie globalne**. Jeśli Twój przekład tam jest, zaznacz go i stuknij **Zainstaluj wybrane**.
4. Jeśli go nie ma, stuknij **Importuj z pliku**, aby zaimportować plik `.bible`. Pobierz plik ze strony GitHub projektu. Zobacz przewodnik [Pobieranie dodatkowych zasobów z GitHuba](theodia://help/getting-core-files), aby uzyskać szczegółowe instrukcje.
