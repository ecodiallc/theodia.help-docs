---
title: Dodawanie plików rdzenia
level: beginner
categories: start
summary: Jak pobrać duże pliki danych potrzebne do głębszego studiowania Biblii.
---

# Dodawanie plików rdzenia

Theodia zawiera Biblię i kilka małych dodatków gotowych do użycia. Aby w pełni wykorzystać aplikację, musisz także pobrać **pliki rdzenia**. Są to duże pliki danych, które dodają narzędzia do studiowania, takie jak komentarze, informacje o słowach i notatki gramatyczne. Bez nich aplikacja działa, ale funkcje studiowania są ograniczone.

## Po co są pliki rdzenia

Pliki rdzenia dodają:

- **Informacje o słowach.** Stuknij dowolne słowo w wersecie, aby zobaczyć oryginalne hebrajskie lub greckie słowo oraz jego znaczenie.
- **Komentarz.** Komentarz AI do każdego wersetu.
- **Gramatyka.** Informacje o każdym słowie w języku oryginalnym.
- **Biblia interlinearna.** Czytaj tekst w języku oryginalnym z angielskim pod każdym słowem.

Możesz czytać Biblię bez nich, ale większość narzędzi do studiowania ich wymaga.

## Jak zainstalować pliki rdzenia

**[Zainstaluj pliki rdzenia](theodia://manage/core)**

1. Otwórz **Ustawienia**.
2. Stuknij **Zarządzaj zasobami**.
3. Otworzy się zakładka **Rdzeń**. Zobaczysz listę plików rdzenia. Każdy ma nazwę, rozmiar i pole wyboru.
4. Stuknij każdy plik, który chcesz zainstalować. Znaczek wyboru oznacza wybrany plik.
5. Stuknij **Zainstaluj wybrane**.
6. Poczekaj, aż pliki się pobiorą i zainstalują. Są duże, więc na wolnym połączeniu może to potrwać kilka minut.

Pliki pobierają się na Twoje urządzenie. Wystarczy to zrobić raz. Aplikacja używa tych plików od tej pory, nawet gdy jesteś offline.

## Wskazówki

- Używaj Wi-Fi. Pliki są duże.
- Podłącz telefon lub tablet. Duże pobieranie zużywa baterię.
- Jeśli pobieranie się nie powiedzie, stuknij plik ponownie, aby spróbować.
- Możesz zainstalować wszystkie lub tylko te, których potrzebujesz.

## Co zrobić, jeśli pliku nie ma na liście?

Aplikacja pobiera listę ze strony GitHub projektu. Jeśli lista jest pusta, sprawdź połączenie internetowe i spróbuj ponownie. Jeśli nadal jest pusta, zobacz przewodnik [Gdzie szukać pomocy](theodia://help/getting-more-help).

Aby poznać bardziej zaawansowane sposoby dodawania zasobów, zobacz przewodnik [Pobieranie dodatkowych zasobów z GitHuba](theodia://help/getting-core-files).
