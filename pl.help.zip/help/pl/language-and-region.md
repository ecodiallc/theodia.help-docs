---
title: Język i region aplikacji
level: everyday
categories: settings
summary: Jak zmienić język aplikacji.
---

# Język i region aplikacji

Theodia jest dostępna w wielu językach. Aplikacja może zmienić język menu i przycisków. Treść pomocy jest dostępna w wielu z tych języków i jest wbudowana w aplikację. Możesz też pobrać lub zaktualizować pakiet pomocy dla danego języka — otwórz **Ustawienia** → **Pomoc** lub **Zarządzaj zasobami** → **Pobierz z GitHuba** → **Dokumentacja pomocy**.

## Jak otworzyć ustawienia języka

1. Otwórz **Ustawienia**.
2. Stuknij **Język**.

## Jak zmienić język aplikacji

1. Na liście **Język** stuknij wybrany język.
2. Aplikacja natychmiast stosuje nowy język.

Widoczne opcje zależą od języków obsługiwanych przez aplikację.

## Jak wybierany jest język przy pierwszej instalacji

Podczas pierwszej instalacji Theodia wybiera język na podstawie ustawień urządzenia. Możesz go zmienić w dowolnej chwili.

## Co jest tłumaczone

- Menu, przyciski i etykiety.
- Ekrany ustawień.
- Komunikaty błędów.
- Wyszukiwanie i narzędzia do studiowania.

## Co pozostaje tylko po angielsku

- Niektóre treści ksiąg i rozważań.

## Przekłady Biblii a język aplikacji

Język aplikacji i język przekładu Biblii to dwie różne rzeczy. Możesz mieć aplikację po hiszpańsku, a Biblię po angielsku, lub odwrotnie.

Aby zmienić przekład Biblii, zobacz przewodnik [Instalowanie przekładów Biblii](theodia://help/installing-bibles).

## Wskazówki

- Jeśli przycisk lub etykieta jest pusty, aplikacji brakuje tłumaczenia. Zazwyczaj dostępna jest angielska wersja zapasowa.
- Jeśli chcesz pomóc w tłumaczeniu aplikacji, zobacz przewodnik [Gdzie szukać pomocy](theodia://help/getting-more-help).
