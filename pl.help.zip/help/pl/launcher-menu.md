---
title: Menu launcher
level: everyday
categories: layout
summary: Szybki sposób na przejście do ostatnich wersetów, uruchamianie poleceń i przełączanie układów Biblii bez opuszczania bieżącego ekranu.
---

# Menu launcher

> **Tryb:** Menu launcher wymaga trybu **Badacz**. Możesz zmienić tryb w **Ustawienia** → **Tryb użytkownika**.

Menu launcher to panel szybkiego dostępu, który możesz otworzyć niemal w dowolnym miejscu aplikacji. Zawiera ostatnie wersety, polecenia i zapisane układy Biblii w jednym miejscu.

## Jak je otworzyć

Stuknij **ikonę rozwijania (⌄)** w prawym górnym rogu nagłówka ekranu głównego. Panel wsuwa się z góry.

## Co znajduje się wewnątrz

### 1. Pole poleceń

Na górze panelu znajduje się pole tekstowe z ikoną klawiatury. Wpisz polecenie i stuknij **Przejdź** na klawiaturze. Aplikacja odczytuje polecenie i przeniesie Cię tam.

Przykłady:

- `John 3:16` — otwiera ten werset.
- `search love` — szuka słowa „love" w Biblii.
- `bookmark psalms 23` — dodaje zakładkę do wersetu.
- `kjv` — przełącza na przekład KJV.

Pełną listę poleceń znajdziesz w przewodniku [Polecenia](theodia://help/commands).

### 2. Zestawy równoległe

Jeśli zapisałeś zestawy równoległych Biblii, pojawiają się tutaj jako zwijana lista. Stuknij jeden, aby natychmiast załadować dany układ równoległy.

Aby utworzyć zestaw równoległy:

1. Otwórz **Ustawienia** → **Biblia równoległa**.
2. Dodaj przekłady i stuknij **Zapisz zestaw**.
3. Nadaj nazwę. Pojawi się w menu launcher.

Przytrzymaj zestaw równoległy w menu launcher, aby go usunąć.

### 3. Kolekcje Biblii

Kolekcje Biblii to skróty jednym stuknięciem, które jednocześnie zmieniają przekład i widok równoległy. Jeśli utworzyłeś jakiekolwiek, pojawiają się tutaj jako zwijana lista.

Przytrzymaj kolekcję, aby ją usunąć.

### 4. Ikony funkcji

Pod polem poleceń możesz zobaczyć rząd okrągłych przycisków z emoji. To skróty jednym stuknięciem do głównych funkcji aplikacji.

Dostępne ikony obejmują:

- **O aplikacji**, **Biblie**, **Notatki biblijne**, **Zakładki**, **Księgi**
- **Rozważania**, **Fiszki**, **Pomoc**, **Podświetlenia**
- **Playlisty**, **Wtyczki**, **Szukaj**, **Ustawienia**, **Theoscript**

Aby wybrać, które ikony się pojawiają i w jakiej kolejności:

1. Otwórz **Ustawienia** → **Menu launcher**.
2. Stuknij **Ikony menu launcher**.
3. Użyj przełączników, aby pokazywać lub ukrywać poszczególne ikony.
4. Użyj strzałek góra/dół, aby zmienić kolejność włączonych ikon.

Kolejność w ustawieniach to kolejność w menu launcher.

### 5. Ostatnie wersety

Aplikacja pamięta ostatnie otwierane rozdziały i wersety. Pojawiają się jako lista u dołu panelu. Stuknij dowolny wpis, aby natychmiast do niego wrócić.

- **Stuknij**, aby otworzyć.
- **Przesuń w lewo** lub **przytrzymaj**, aby usunąć z listy.
- Stuknij **Wyczyść wszystko**, aby usunąć wszystkie wpisy na raz.

## Kiedy używać menu launcher

Użyj go, gdy chcesz:

- Wrócić do wersetu, który właśnie czytałeś.
- Wpisać polecenie bez przechodzenia na ekran główny.
- Przełączyć przekład lub układ równoległy jednym stuknięciem.
- Otworzyć główną funkcję z dowolnego miejsca w aplikacji.
- Sprawdzić coś szybko, bez nawigowania przez menu.

## Wskazówki

- Menu launcher jest dostępny na niemal każdym ekranie, więc możesz go otworzyć podczas czytania rozdziału.
- Pole poleceń obsługuje te same polecenia, co pole poleceń na ekranie głównym.
- Ikony funkcji i ich kolejność są zapisywane lokalnie na urządzeniu. Przetrwają restart aplikacji.
- Ostatnie wersety są zapisywane lokalnie na urządzeniu. Przetrwają restart aplikacji.
