---
title: Poruszanie się między księgami, rozdziałami i wersetami
level: everyday
categories: [layout, read]
summary: Jak poruszać się po Biblii i przechodzić tam, gdzie chcesz.
---

# Poruszanie się między księgami, rozdziałami i wersetami

Ten przewodnik pokazuje wszystkie sposoby poruszania się po Biblii.

## Najłatwiejszy sposób: przesunięcie

- Przesuń w lewo po rozdziale, aby przejść do następnego rozdziału.
- Przesuń w prawo, aby wrócić.
- Działa to również przy następnej księdze. Po ostatnim rozdziale np. Księgi Wyjścia przesunięcie przeniesie Cię do pierwszego rozdziału Księgi Kapłańskiej.

## Sposób przez menu

- Stuknij nazwę przekładu u góry, aby przełączyć na inną Biblię.
- Stuknij nazwę księgi u góry, aby wybrać inną księgę.
- Stuknij numer rozdziału, aby wybrać inny rozdział.

## Szybki sposób: wpisanie

- Na ekranie głównym u góry znajduje się pole. Wpisz odniesienie, np. `John 3:16` lub `psalms 23`, i stuknij klawisz **Przejdź** na klawiaturze.
- Aplikacja otworzy werset.

## Sposób przez zakładki

Jeśli zapisałeś werset, otwórz zakładkę **Zakładki**. Stuknij dowolny wpis, aby do niego przejść.

## Sposób przez wyszukiwanie

Stuknij zakładkę **Szukaj**. Wpisz słowo. Aplikacja pokaże każdy werset, który je zawiera. Stuknij dowolny wynik, aby go otworzyć.

## Sposób przez historię

Aplikacja pamięta otwierane rozdziały. Aby je ponownie znaleźć, zajrzyj do zakładki **Zakładki** (dla zapisanych wersetów) lub przewijaj listę ksiąg na zakładce **Biblie**, aby znaleźć niedawno czytaną księgę.

## Wskazówki

- Zakładka Biblii pokazuje księgi w kolejności od Rodzaju do Apokalipsy.
- W przypadku Psalmów, Przysłów i innych długich ksiąg stuknij księgę i użyj listy rozdziałów, aby skoczyć daleko do przodu.
