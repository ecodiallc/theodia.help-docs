---
title: Układ aplikacji i nawigacja
level: beginner
categories: layout
summary: Przewodnik po ekranie głównym, głównym menu i dolnym pasku narzędzi — gdzie znajduje się wszystko.
---

# Układ aplikacji i nawigacja

Theodia ma trzy główne obszary, między którymi możesz się przemieszczać: **ekran główny**, **główne menu** i **dolny pasek narzędzi**. Ten przewodnik przeprowadzi Cię przez każdy z nich, abyś zawsze wiedział, gdzie iść.

## Szybka mapa

- **Ekran główny** to strona, którą widzisz po otwarciu aplikacji. Ma pole wyszukiwania, duże przyciski do każdej części aplikacji oraz listę zainstalowanych Biblii, ksiąg i rozważań.
- **Dolny pasek narzędzi** (nazywany także paskiem zakładek) to rząd ikon u dołu ekranu. Stuknij dowolną z nich, aby przejść bezpośrednio do tej części aplikacji.
- **Główne menu** to ikona z trzema liniami (☰) w prawym górnym rogu ekranu głównego. Stuknij ją, aby otworzyć listę wszystkich ekranów aplikacji, w tym tych, które nie mają własnej zakładki.

## Ekran główny

Po pierwszym otwarciu Theodia lądujesz na ekranie głównym. Jest podzielony na cztery części, od góry do dołu.

### Nagłówek

Samej górze znajduje się kolorowy pasek. Po lewej stronie jest ikona aplikacji i nazwa „Theodia". Po prawej stronie jest przycisk głównego menu (☰). Gdy jesteś wewnątrz księgi lub rozdziału, po lewej stronie zamiast tego pojawia się przycisk wstecz (←). Stuknij menu główne, aby je otworzyć (zobacz poniżej).

### Polecenie

Tuż pod nagłówkiem znajduje się pole tekstowe w stylu wyszukiwania z etykietą **Polecenie**. Wpisz krótką instrukcję i stuknij klawisz przejdź na klawiaturze. Aplikacja odczytuje instrukcję i przenosi Cię na odpowiedni ekran. Przykłady:

- `psalms 23` — otwiera Psalm 23
- `john 3:16` — otwiera Jana 3:16
- `search love` — szuka słowa „love" w Biblii
- `bookmark john 3:16` — zapisuje Jana 3:16 jako zakładkę
- `commentary romans 8:28` — otwiera komentarz do tego wersetu
- `xref` (po którym następuje odniesienie) — otwiera odniesienia krzyżowe do tego wersetu
- `help` — otwiera listę poleceń z przykładami

Jeśli aplikacja nie rozumie tego, co wpisałeś, wyświetli mały alert z podpowiedzią. Zobacz przewodnik **Częste problemy**, jeśli polecenia nie działają.

### Siatka przycisków

Pod polem Polecenie znajduje się siatka dużych przycisków, dwa w rzędzie. Każdy przycisk prowadzi do innej części aplikacji. Przyciski to:

- 📖 **Biblie** — lista przekładów Biblii
- 🔍 **Szukaj** — wyszukiwanie słowa lub frazy w Biblii
- 📚 **Księgi** — biblioteka chrześcijańskiej klasyki
- 📅 **Rozważania** — codzienne rozważania
- 🔖 **Zakładki** — zapisane wersety i rozdziały
- 🖍 **Podświetlenia** — wersety oznaczone kolorem
- 📝 **Notatki biblijne** — prywatne notatki do wersetów
- ⚙️ **Ustawienia** — język, motyw, zasoby i więcej
- ❓ **Pomoc** — system pomocy (ta strona)
- ℹ️ **O aplikacji** — wersja aplikacji i podziękowania

### Listy zasobów

Pod siatką przycisków znajdują się rozwijane sekcje: **Biblie**, **Księgi** i **Rozważania**. Każda sekcja pokazuje zainstalowane pozycje. Stuknij nagłówek sekcji, aby ją rozwinąć lub zwinąć. Stuknij dowolną pozycję w sekcji, aby ją otworzyć.

Sekcja Biblii to najszybszy sposób, aby przejść do konkretnego przekładu — bez menu, po prostu stuknij.

## Dolny pasek narzędzi

Dolny pasek narzędzi (pasek zakładek) to rząd ikon u dołu ekranu. Jest widoczny niemal wszędzie w aplikacji, więc zawsze możesz przejść do innej sekcji. Widoczne zakładki zależą od Twojego trybu użytkownika.

**Wszystkie tryby widzą:**

- 🏠 **Strona główna** — otwiera ekran główny
- 📖 **Biblie** — otwiera listę przekładów Biblii
- 📚 **Księgi** — otwiera bibliotekę ksiąg
- 🔍 **Szukaj** — otwiera wyszukiwanie biblijne
- ⚙️ **Ustawienia** — otwiera ustawienia

**Tryby Standardowy i Badacz widzą również:**

- 🔖 **Zakładki** — otwiera zapisane wersety
- 🖍 **Podświetlenia** — otwiera wersety oznaczone kolorem
- 📝 **Notatki biblijne** — otwiera prywatne notatki

**Tryb Badacz widzi również:**

- 💻 **AI** — otwiera asystenta AI (jeśli włączyłeś go w Ustawieniach)

Bieżąca zakładka jest podświetlona. Stuknij inną zakładkę, aby przełączyć.

### Jak zachowuje się pasek narzędzi

Każda zakładka na pasku ma własny **stos** ekranów. Gdy stukniesz zakładkę, wracasz do **miejsca, w którym ją opuściłeś** w stosie tej zakładki, a nie do ekranu startowego. Na przykład:

- Stuknij **Biblie** → widzisz listę przekładów Biblii.
- Stuknij przekład → widzisz listę ksiąg.
- Stuknij księgę → widzisz listę rozdziałów.
- Stuknij rozdział → czytasz rozdział.
- Przełącz się na **Zakładki**, aby coś sprawdzić.
- Stuknij ponownie **Biblie** → wracasz do czytanego rozdziału.

Każda zakładka pamięta Twoje miejsce. Aplikacja zachowuje historię nawigacji wewnątrz każdej zakładki, więc przełączanie się między zakładkami nie traci postępów.

### Co resetuje zakładkę

Zakładka resetuje się do ekranu głównego tylko wtedy, gdy:

- Jesteś już na tej zakładce i stukniesz ponownie tę samą ikonę. To szybki sposób na powrót na start.
- Aplikacja zostanie zamknięta siłowo i ponownie otwarta.

### Dolne zakładki kontra główne menu

- **Dolne zakładki** — każda zakładka pamięta własny stos. Stuknięcie zakładki wraca do miejsca, w którym ją opuściłeś.
- **Główne menu** — stuknięcie pozycji nawiguje do tego ekranu za pomocą tego samego systemu zakładek. Nie otwiera się jako nakładka.

Używaj zakładek do przełączania zadań. Używaj głównego menu, gdy chcesz zobaczyć pełną listę wszystkich ekranów aplikacji.

### Kiedy używać paska narzędzi

Używaj paska narzędzi, gdy chcesz przełączyć to, co robisz:

- Czytasz rozdział i chcesz czegoś innego wyszukać → stuknij **Szukaj**.
- Wyszukujesz i chcesz sprawdzić zakładki → stuknij **Zakładki**.
- Jesteś w dowolnym miejscu aplikacji i chcesz wrócić na ekran główny → stuknij **Strona główna**.

## Główne menu

Główne menu to przycisk z trzema ułożonymi liniami (☰) w prawym górnym rogu ekranu głównego. Stuknij go, a panel wsunie się z prawej strony. Panel pokazuje każdy ekran obsługiwany przez Twój bieżący tryb:

- 🏠 **Strona główna**
- 📖 **Biblie**
- 📚 **Księgi**
- 🙏 **Rozważania**
- 🔍 **Szukaj**
- 🔖 **Zakładki** (Standardowy i Badacz)
- 🖍 **Podświetlenia** (Standardowy i Badacz)
- 📝 **Notatki biblijne** (Standardowy i Badacz)
- 💻 **Asystent AI** (tylko Badacz i tylko jeśli AI jest włączone)
- ⚙️ **Ustawienia**
- ❓ **Pomoc**
- ℹ️ **O aplikacji**

Pozycja odpowiadająca bieżącemu ekranowi jest podświetlona i ma obok siebie małą kropkę. Stuknij dowolną pozycję, aby przejść bezpośrednio do niej. Stuknij poza panelem, X na górze lub przycisk wstecz urządzenia, aby zamknąć panel bez zmiany ekranu.

### Czym różni się główne menu

Główne menu to panel rozwijany, nie osobna warstwa nawigacji. Gdy stukniesz pozycję, aplikacja nawiguje do tego ekranu tak samo, jak gdybyś użył dolnej zakładki lub siatki przycisków. Stos bieżącej zakładki jest zachowany, więc możesz wrócić do miejsca, w którym byłeś, stukając ponownie pierwotną zakładkę.

Na przykład:

- Czytasz Jana 3. Stukniesz zakładkę **Zakładki**. Przechodzisz do zakładek. Gdy stukniesz ponownie **Biblie**, wracasz do Jana 3 — dokładnie tam, gdzie skończyłeś.
- Czytasz Jana 3. Otwierasz główne menu i stukasz **Notatki biblijne**. Otwierają się notatki. Aby wrócić do Jana 3, stuknij zakładkę **Biblie**, a wrócisz do rozdziału automatycznie.

Zakładki przełączają kontekst i pamiętają Twoje miejsce. Główne menu to po prostu inny sposób na dotarcie do tych samych ekranów.

### Kiedy używać głównego menu

Używaj głównego menu, gdy:

- Chcesz otworzyć **Podświetlenia**, **Notatki biblijne**, **Rozważania**, **Pomoc** lub **O aplikacji** — ekrany, które nie mają własnej zakładki na pasku.
- Jesteś głęboko w rozdziale lub wyszukiwaniu i chcesz szybko coś sprawdzić, nie tracąc miejsca.
- Chcesz otworzyć **Ustawienia**, nie opuszczając bieżącego ekranu.

## Tryb Badacz

Jeśli Twój tryb użytkownika jest ustawiony na **Badacz**, układ zyskuje dodatkowe zakładki, pozycje menu i narzędzia czytelnika, które tryby Czytelnik i Standardowy ukrywają. Zobacz przewodnik [Tryb Badacz](theodia://help/scholar-mode), aby zapoznać się z pełnym opisem każdej funkcji.

## Jak pasują do siebie trzy obszary

- **Przełączyć na inną główną sekcję** (Biblie, Szukaj, Zakładki itd.) → Dolny pasek narzędzi
- **Przejść do konkretnego wersetu lub polecenia** → Polecenie na ekranie głównym
- **Przeglądać wszystkie dostępne ekrany** → Siatka przycisków na ekranie głównym
- **Sprawdzić notatki, podświetlenia lub pomoc, nie opuszczając miejsca** → Główne menu
- **Otworzyć Ustawienia z dowolnego miejsca** → Główne menu lub pasek narzędzi

Używasz wszystkich trzech. Żaden z nich nie jest „właściwy". Wybierz ten, który jest najłatwiejszy dla tego, co robisz.

### Pasek narzędzi kontra główne menu: szybki przykład

Wyobraź sobie, że czytasz Rzymian 8 i chcesz podświetlić werset, który Ci się podoba.

**Używając paska narzędzi:**

1. Stuknij werset, aby otworzyć menu wersetu.
2. Stuknij **Podświetl** i wybierz kolor.
3. Gotowe. Nie opuściłeś rozdziału.

**Używając głównego menu (jeśli chcesz przejrzeć swoje podświetlenia):**

1. Stuknij ☰, aby otworzyć menu.
2. Stuknij **Podświetlenia**. Otwiera się lista podświetleń.
3. Przejrzyj je, a następnie stuknij zakładkę **Biblie**, aby wrócić do Rzymian 8.

**Używając paska narzędzi (jeśli chcesz przełączyć zadanie):**

1. Stuknij **Strona główna** lub **Zakładki** na pasku narzędzi.
2. Opuszczasz Rzymian 8 i przechodzisz do nowego ekranu.
3. Aby wrócić do Rzymian 8, stuknij ponownie **Biblie** — wrócisz do rozdziału automatycznie.

## Wskazówki

- Ekran główny pamięta, które sekcje są rozwinięte, a które zwinięte. Ustawisz to tylko raz.
- Jeśli nie widzisz oczekiwanej zakładki, sprawdź dwie rzeczy:

1. **Twój tryb użytkownika** — tryb Czytelnik ukrywa zakładki, podświetlenia, notatki i AI. Tryb Standardowy ukrywa AI. Przełącz tryby w **Ustawienia** → **Tryb użytkownika**.
2. **Ustawienia funkcji** — niektóre zakładki trzeba włączyć w **Ustawieniach** (na przykład asystent AI).
