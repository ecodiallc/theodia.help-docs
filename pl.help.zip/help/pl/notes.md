---
title: Pisanie notatek
level: everyday
categories: [annotate, read]
summary: Jak zapisywać własne przemyślenia przy wersie.
---

# Pisanie notatek

> **Tryb:** Notatki są dostępne w trybach **Standardowy** i **Badacz**. Tryb skupienia służy tylko do czystego czytania bez rozpraszania uwagi. Możesz zmienić tryb w **Ustawienia** → **Tryb użytkownika**.

Notatki to miejsce, gdzie zapisujesz własne przemyślenia, modlitwy lub pomysły do studium przy wersie. Każda notatka jest powiązana z konkretnym wersetem.

## Jak dodać notatkę

1. Otwórz werset.
2. Stuknij werset, aby wyświetlić menu.
3. Stuknij **Notatka biblijna** w menu. Ma ikonę ołówka.
4. Wpisz swoją notatkę.
5. Stuknij **Zapisz**.

Notatka jest teraz zapisana razem z wersetem.

## Jak przeczytać notatkę

1. Otwórz werset.
2. Poszukaj znaczka ołówka obok wersetu. Oznacza on obecność notatki.
3. Stuknij werset. Notatka pojawi się poniżej.

## Jak edytować notatkę

1. Otwórz werset z notatką.
2. Stuknij werset.
3. Stuknij **Notatka biblijna** w menu.
4. Wprowadź zmiany.
5. Stuknij **Zapisz**.

## Jak usunąć notatkę

1. Otwórz werset z notatką.
2. Stuknij werset.
3. Stuknij **Notatka biblijna** w menu.
4. Stuknij **Usuń**.

## Jak zobaczyć wszystkie notatki

Stuknij zakładkę **Notatki biblijne** na dole ekranu. Zobaczysz listę wszystkich napisanych notatek, posortowanych według daty.

## Wyszukiwanie notatek

Na zakładce **Notatki biblijne** stuknij pole **Szukaj**. Wpisz słowo. Aplikacja znajdzie każdą notatkę, która je zawiera.

## Wskazówki

- Notatki świetnie sprawdzają się w kazaniach, rozważaniach i pytaniach do studium.
- Notatki są prywatne. Pozostają na Twoim urządzeniu.
- Zobacz przewodnik [Tworzenie kopii zapasowych danych](theodia://help/backups), aby je zabezpieczyć.
