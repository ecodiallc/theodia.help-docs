---
title: Powiadomienia i przypomnienia
level: everyday
categories: [settings]
summary: Jak włączać, dostosowywać i zarządzać offline'owymi przypomnieniami o modlitwie, rozważaniach, planach czytania Biblii i nie tylko.
---

# Powiadomienia i przypomnienia

Theodia może przypominać o modlitwie, rozważaniach, planach czytania Biblii, fiszkach i innych aktywnościach — nawet gdy aplikacja jest offline. Wszystkie przypomnienia są planowane na urządzeniu; nie potrzeba połączenia internetowego ani serwera powiadomień push.

## Jak włączyć lub wyłączyć przypomnienia

1. Otwórz **Ustawienia**.
2. Stuknij **Powiadomienia**.
3. Włącz lub wyłącz **Włącz przypomnienia**.

Za pierwszym razem, gdy włączysz przypomnienia, aplikacja poprosi o zgodę na wysyłanie powiadomień. Stuknij **Zezwól**, aby przypomnienia mogły się pojawiać.

Jeśli wcześniej odmówiłeś zgody, iOS lub Android może zablokować prośbę. W takim przypadku przejdź do aplikacji **Ustawienia** systemowych, znajdź **Theodia** i włącz tam powiadomienia.

## Rodzaje przypomnień

Ekran powiadomień jest podzielony na kanały. Każdy kanał to rodzina przypomnień, które można włączać lub wyłączać niezależnie:

- **Przypomnienia o modlitwie** — ogólne przypomnienia o modlitwie.
- **Rutyna modlitewna** — przypomnienia powiązane z konkretną rutyną modlitewną.
- **Rozważanie** — dzienny werset lub przypomnienie o rozważaniu.
- **Przypomnienia o planie czytania Biblii** — przypomnienia o aktywnym planie czytania Biblii.
- **Przypomnienia o Theoscript** — przypomnienia o uruchomieniu Theoscriptu.
- **Przypomnienia od AI** — przypomnienia generowane przez AI.
- **Przypomnienia o powtórce fiszek** — monity o powtórce fiszek.
- **Przypomnienia o nawyku czytania** — codzienne monity o czytaniu.
- **Przypomnienia liturgiczne i sezonowe** — przypomnienia powiązane z kalendarzem kościelnym.
- **Moje przypomnienia** — przypomnienia utworzone z zakładek, podświetleń, playlist, rozdziałów Biblii lub ksiąg.
- **Niestandardowe przypomnienia** — w pełni własne przypomnienia utworzone przez Ciebie.

Stuknij dowolny kanał, aby zobaczyć jego przypomnienia, zmienić godzinę, wybrać dni, w które ma się uruchamiać, lub je wyłączyć.

## Niestandardowe przypomnienia

Niestandardowe przypomnienia to monity budowane od podstaw.

1. W **Ustawienia** → **Powiadomienia** stuknij **Niestandardowe przypomnienia**.
2. Stuknij przycisk **+**.
3. Wpisz **Tytuł** i **Treść**.
4. Wybierz **Godzinę**.
5. Wybierz **Dni**, w które ma się powtarzać.
6. Opcjonalnie wybierz, co otwiera przypomnienie po stuknięciu.
7. Stuknij **Zapisz**.

Możesz edytować lub usuwać niestandardowe przypomnienie w dowolnej chwili, stukając je na liście.

## Co się dzieje po stuknięciu przypomnienia

Większość przypomnień otwiera konkretny ekran aplikacji. Na przykład przypomnienie o rutynie modlitewnej otwiera tę rutynę, a przypomnienie o planie czytania Biblii otwiera następne czytanie.

Jeśli przypomnienie nie ma powiązanego ekranu, otwiera aplikację na ekranie głównym.

## Cichy czas

Cichy czas wycisza dźwięki powiadomień, pozwalając nadal wyświetlać wizualne przypomnienia.

1. W **Ustawienia** → **Powiadomienia** stuknij **Cichy czas**.
2. Ustaw godzinę **Początek** i **Koniec**.

Przypomnienia zaplanowane w cichym czasie pojawią się na ekranie bez dźwięku.

## Nadchodzące przypomnienia i historia

- **Nadchodzące przypomnienia** pokazuje wszystko, co jest zaplanowane do następnego uruchomienia.
- **Historia powiadomień** pokazuje ostatnio dostarczone, zaplanowane i anulowane przypomnienia.

Użyj tych list, aby potwierdzić, że przypomnienie jest ustawione poprawnie lub zobaczyć, dlaczego się nie pojawiło.

## Jeśli przypomnienia się nie pojawiają

- Upewnij się, że **Włącz przypomnienia** jest włączone.
- Sprawdź, czy powiadomienia są dozwolone w ustawieniach systemowych urządzenia.
- Upewnij się, że kanał przypomnienia jest włączony i wybrano przynajmniej jeden dzień.
- Jeśli ustawiłeś cichy czas, przypomnienie może być ciche.
- Niektórzy producenci Androida usypiają aplikacje. Dodaj Theodię do listy dozwolonych, jeśli Twoje urządzenie oferuje ustawienia optymalizacji baterii.
- Jeśli przypomnienie jest powiązane z treścią, którą usunąłeś (na przykład usunięty plan czytania Biblii lub rutyna), przypomnienie może nie uruchomić się, dopóki nie wybierzesz ponownie prawidłowego celu.

## Dźwięki powiadomień

Możesz wybrać dźwięk odtwarzany przez przypomnienia, które go obsługują. Stuknij **Dźwięk** wewnątrz przypomnienia lub kanału, aby wybrać spośród dostępnych opcji. Dźwięki są dołączone do aplikacji, więc działają offline.

Użyj przycisku **Podgląd dźwięku**, aby usłyszeć wybrany dźwięk przed zapisaniem.

## Badges

Niektóre przypomnienia mogą dodać plakietkę do ikony aplikacji. Stuknij **Wyczyść plakietkę** na ekranie powiadomień, aby ją zresetować.
