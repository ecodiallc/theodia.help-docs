---
title: PDF-y
level: everyday
categories: [read, resources]
summary: Importuj, porządkuj i czytaj dokumenty PDF w Theodii.
---

# PDF-y

> **Tryb:** Pliki PDF są dostępne w trybach **Standardowy** i **Badacz**. Tryb skupienia służy tylko do czystego czytania bez rozpraszania uwagi. Możesz zmienić tryb w **Ustawienia** → **Tryb użytkownika**.

Theodia może przechowywać i czytać pliki PDF. Zaimportowane PDF-y pozostają na Twoim urządzeniu, więc działają offline.

## Otwórz bibliotekę PDF

Stuknij zakładkę **PDF** na dole ekranu albo stuknij kafelek **PDF** na ekranie głównym.

## Importowanie pliku PDF

1. Otwórz zakładkę **PDF**.
2. Stuknij przycisk **+** w prawym dolnym rogu.
3. Wybierz plik PDF ze swojego urządzenia.
4. (Opcjonalnie) Wpisz lub wybierz kategorię, aby go uporządkować.

## Porządkowanie plików PDF

Przytrzymaj dowolną kartę PDF, aby otworzyć menu z tymi opcjami:

- **Zmień nazwę** — zmienia tytuł pokazywany w bibliotece.
- **Zmień kategorię** — przenosi plik PDF do kategorii.
- **Usuń** — usuwa plik PDF z Theodii. Usuwa też zapisaną pozycję czytania.

Kategorie to dowolny tekst. Wpisz nową nazwę albo wybierz istniejącą, gdy importujesz plik lub zmieniasz kategorię.

## Czytanie pliku PDF

Stuknij kartę PDF, aby ją otworzyć. Czytnik pokazuje:

- Tytuł dokumentu na pasku u góry.
- Rząd przycisków stron: **Pierwsza strona**, **Poprzednia**, bieżącą stronę („3 / 120”), **Następną** i **Ostatnią stronę**.
- Pasek narzędzi z narzędziami dokumentu: **Spis treści**, **Pomniejsz**, **Powiększ**, **Resetuj powiększenie**, **Zakładka**, **Szukaj**, **Czytaj** i **Widok tekstu**.

Niektóre narzędzia są wyszarzone, gdy nie można ich użyć — na przykład **Szukaj** i **Czytaj** są wyszarzone, dopóki nie zostanie zainstalowany tekst przeszukiwalny pliku PDF.

### Przerzucanie stron

- Stuknij **strzałkę w lewo** lub **w prawo**, aby cofnąć się lub pójść o stronę dalej.
- Stuknij **Pierwszą stronę** lub **Ostatnią stronę**, aby przeskoczyć na początek albo koniec dokumentu.
- Stuknij numer strony (na przykład „3 / 120”), aby otworzyć siatkę stron, a następnie stuknij stronę, której szukasz. Siatka otwiera się w pobliżu strony, na której jesteś.
- Użyj **klawiszy strzałek w lewo i w prawo** na klawiaturze zewnętrznej.

### Powiększenie

- Stuknij **Powiększ** (+) lub **Pomniejsz** (−), aby zmienić rozmiar strony.
- Stuknij **Resetuj powiększenie**, aby przywrócić stronie normalny rozmiar.
- Jeśli powiększysz, przerzucisz stronę, a potem pomniejszysz, Theodia wróci z Tobą do strony, którą czytałeś.

## Szukanie w pliku PDF

1. Otwórz plik PDF i stuknij przycisk **Szukaj** (lupa) na pasku narzędzi.
2. Wpisz, czego szukasz. Wyniki pojawiają się w trakcie pisania, razem z numerem strony i fragmentem otaczającego tekstu.
3. Stuknij wynik, aby przeskoczyć do tej strony.

Wyszukiwanie wymaga zainstalowanego tekstu przeszukiwalnego pliku PDF. Jeśli jeszcze go nie ma, przycisk Szukaj jest wyszarzony. PDF-y zainstalowane ze społecznościowego repozytorium GitHub zawierają tekst przeszukiwalny; PDF-y importowane samodzielnie nie mają go, dopóki nie zostanie dodany.

## Spis treści

Jeśli plik PDF ma wbudowany spis treści, przycisk **Spis treści** na pasku narzędzi pokazuje go jako konspekt. Stuknij tytuł sekcji, aby przeskoczyć do tej strony. Sekcje można rozwijać i zwijać. Jeśli plik PDF nie ma spisu treści, przycisk jest wyszarzony.

## Zakładki w pliku PDF

1. Otwórz plik PDF i stuknij przycisk **Zakładka** na pasku narzędzi.
2. Stuknij **Dodaj zakładkę**, aby zapisać bieżącą stronę. Nazwą początkowo jest numer strony — jeśli wolisz, wpisz własną nazwę — a potem stuknij **Zapisz**.
3. Stuknij dowolną zakładkę na liście, aby przeskoczyć do jej strony.
4. Stuknij **×** obok zakładki, aby ją usunąć.

Zakładki w plikach PDF są niezależne od zakładek w Biblii. Każdy plik PDF prowadzi własną listę.

## Czytanie pliku PDF na głos

Jeśli tekst przeszukiwalny pliku PDF jest zainstalowany, Theodia może przeczytać na głos bieżącą stronę:

1. Otwórz plik PDF i stuknij przycisk **Czytaj** (głośnik) na pasku narzędzi.
2. Pojawia się pasek sterowania z **Odtwarzaj/Wstrzymaj**, **Przewiń wstecz**, **Przewiń w przód**, **Zatrzymaj**, paskiem postępu, którego możesz stuknąć, aby przeskoczyć wewnątrz strony, oraz z szybkością czytania i głosem.
3. Gdy strona się kończy, czytanie automatycznie przechodzi na następną stronę.

Głos i szybkość są takie same jak przy czytaniu Biblii — zobacz przewodnik [Czytanie na głos](theodia://help/tts), aby dowiedzieć się, jak je zmienić.

## Kopiowanie, udostępnianie i zapisywanie tekstu strony

Stuknij przycisk **Widok tekstu** na pasku narzędzi, aby zobaczyć bieżącą stronę jako zwykły tekst. Stamtąd możesz:

- **Kopiuj** — kopiuje tekst strony do schowka.
- **Udostępnij** — udostępnia tekst strony przez dowolną aplikację na Twoim urządzeniu.
- **Dodaj do notatek** — otwiera edytor notatek z tekstem strony, cytatem i linkiem z powrotem do tej strony, już wypełnionymi za Ciebie.

## Wznawianie czytania

Theodia zapamiętuje ostatnio oglądaną stronę i następnym razem otwiera plik PDF na niej.

## Pobieranie plików PDF z GitHuba

W trybie **Badacz** na dole biblioteki pojawia się przycisk **Pobierz z GitHuba**. Łączy się on ze społecznościowym repozytorium PDF-ów, dzięki czemu możesz instalować spakowane dokumenty PDF w ten sam sposób, w jaki instalujesz Biblie lub księgi.

## Uwagi

- Pliki PDF są przechowywane w prywatnym folderze dokumentów Theodii. Nie są włączane do kopii zapasowych, więc po przejściu na nowe urządzenie trzeba je zaimportować ponownie.
