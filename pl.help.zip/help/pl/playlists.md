---
title: Playlisty
level: everyday
categories: playlists
summary: Twórz i słuchaj mówionych playlist z fragmentów Biblii, zwykłego tekstu lub dowolnego wersetu, który chcesz usłyszeć.
---

# Playlisty

**Playlista** to lista utworów, które Theodia może przeczytać na głos. Każdy utwór to albo fragment Biblii, albo krótka notatka tekstowa. Playlisty są przydatne do słuchania bez użycia rąk podczas dojazdu, spaceru, czasu rozważań lub nauki na pamięć.

Playlisty pojawiają się w aplikacji, gdy utworzona lub wypełniona zostanie co najmniej jedna playlista.

## Gdzie znaleźć Playlisty

Gdy playlisty są dostępne, możesz do nich dotrzeć na dwa sposoby:

- **Ekran główny:** W sekcji **Wtyczki i więcej** stuknij **Playlisty**.
- **Główne menu:** Otwórz menu (☰) i stuknij **Playlisty**.

Jeśli nie istnieje jeszcze żadna playlista, kafelek Playlists i pozycja w menu są ukryte.

## Co zawiera playlista

Każda playlista zawiera:

- **Nazwę** — na przykład „Wersety poranne" lub „Naucz się Psalmu 23".
- Opcjonalną **kategorię** — przydatną do grupowania playlist według celu.
- Listę **utworów** — elementów do przeczytania na głos.

Każdy utwór zawiera:

- **Treść** — albo odniesienie biblijne, albo zwykły tekst.
- **Etykietę** — wyświetlaną na ekranie podczas odtwarzania utworu.
- Opcjonalny **głos** — wybierz inny głos dla tego utworu, jeśli chcesz.

## Tworzenie playlisty

1. Otwórz ekran **Playlisty**.
2. Stuknij **Utwórz playlistę** (lub przycisk **+**).
3. Nadaj playlistie nazwę.
4. (Opcjonalnie) Wybierz lub utwórz kategorię.
5. Zacznij dodawać utwory.

### Dodawanie utworu z fragmentu Biblii

1. Stuknij **Dodaj utwór**.
2. Jako typ treści wybierz **Fragment biblijny**.
3. Wpisz odniesienie, takie jak `John 3:16` lub `Psalm 23:1-6`.
4. Dodaj etykietę, jeśli chcesz, lub zostaw ją pustą, aby użyć odniesienia.
5. Zapisz utwór.

### Dodawanie utworu z zwykłego tekstu

1. Stuknij **Dodaj utwór**.
2. Wybierz **Zwykły tekst**.
3. Wpisz tekst, który ma przeczytać Theodia.
4. Dodaj etykietę.
5. Zapisz utwór.

### Dodawanie wsadowe

Jeśli masz listę odniesień lub wierszy tekstu, użyj **Dodaj wsadowo**:

1. Otwórz playlistę.
2. Stuknij menu i wybierz **Dodaj wsadowo**.
3. Wklej jedno odniesienie lub wiersz tekstu na linię.
4. Włącz **Wykrywaj odwołania biblijne**, jeśli większość linii to odniesienia do wersetów.
5. Stuknij **Dodaj**. Każda linia staje się utworem.

## Słuchanie playlisty

1. Otwórz playlistę, którą chcesz usłyszeć.
2. Stuknij przycisk **Odtwórz** u góry lub obok utworu.
3. Theodia czyta kolejno każdy utwór.

Podczas odtwarzania playlisty pojawia się pasek sterowania z tymi przyciskami:

- **Odtwórz / Wstrzymaj**
- **Następny utwór**
- **Poprzedni utwór**
- **Zatrzymaj**

Możesz także ustawić:

- **Tempo** — jak szybko głos czyta.
- **Powtarzaj** — powtarzaj całą playlistę, powtarzaj jeden utwór lub graj raz.
- **Losowo** — odtwarzaj utwory w losowej kolejności.
- **Ignoruj tekst w nawiasach** — pomijaj tekst w nawiasach.
- **Pauza między utworami** — dodaj krótką ciszę między utworami.
- **Timer uśpienia** — zatrzymaj odtwarzanie po ustawionym czasie.

## Edycja playlisty

Aby zmienić playlistę, najpierw wstrzymaj odtwarzanie, jeśli trwa.

Możesz:

- **Zmienić nazwę** playlisty.
- **Zmienić kolejność utworów** — przeciągnij utwory w nową kolejność.
- **Edytować utwór** — zmienić jego odniesienie, tekst, etykietę lub głos.
- **Usunąć utwór** — usunąć go z playlisty.
- **Usunąć całą playlistę** — tego nie można cofnąć.

## Eksportowanie i importowanie playlist

Playlisty są eksportowane jako pliki JSON zawierające wszystkie utwory, kategorie i ustawienia. Możesz udostępnić plik innemu urządzeniu, zachować jako kopię zapasową lub edytować na komputerze.

- **Eksportuj wszystkie playlisty** — tworzy plik `playlists-YYYY-MM-DD.json`.
- **Eksportuj kategorię** — tworzy plik JSON zawierający tylko playlisty z jednej kategorii.
- **Importuj playlisty** — przywraca playlisty z pliku kopii zapasowej JSON.

## Szybkie sposoby na zbudowanie playlisty

Możesz też utworzyć pełną playlistę jako JSON i zaimportować ją. Oto przykład:

```json
{
  "playlists": [
    {
      "name": "Wersety poranne",
      "category": "Rozważania",
      "tracks": [
        {
          "info": "John 3:16",
          "contentSource": "passage",
          "content": "For God so loved the world...",
          "rawContent": "John 3:16"
        },
        {
          "info": "Psalm 23",
          "contentSource": "passage",
          "content": "The Lord is my shepherd...",
          "rawContent": "Psalm 23:1-6"
        }
      ]
    }
  ]
}
```

Zapisz plik, a następnie użyj **Importuj playlisty**, aby załadować go do Theodii.

## Wskazówki

- Playlisty najlepiej sprawdzają się z krótkimi, spójnymi zestawami wersetów.
- Używaj kategorii, aby oddzielić playlisty rozważaniowe od playlist do nauki na pamięć.
- Ustaw timer uśpienia, jeśli słuchasz podczas zasypiania.
- Jeśli utwór używa niewłaściwego głosu, sprawdź, czy język głosu zgadza się z językiem tekstu.
- Theodia czyta zwykły tekst dokładnie tak, jak napisano; sprawdź pisownię, aby uzyskać najlepsze efekty.
