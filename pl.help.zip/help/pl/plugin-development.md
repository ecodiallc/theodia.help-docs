---
title: Tworzenie wtyczek
categories: plugins
level: advanced
summary: Co zawiera pakiet wtyczki Theodia i jak napisać manifest wtyczki.
---

# Tworzenie wtyczek

Wtyczka Theodia to samodzielny pakiet, który dodaje powierzchnie interfejsu, treść lub obsługę zdarzeń do aplikacji. Wtyczki są tworzone poza główną aplikacją i instalowane przez użytkowników przez Ustawienia → Wtyczki.

## Struktura pakietu wtyczki

Pakiet wtyczki to archiwum ZIP z rozszerzeniem `.plugin.zip`. Wewnątrz pliki znajdują się na najwyższym poziomie — nie w zagnieżdżonym folderze.

Typowy pakiet zawiera:

```
my-plugin.plugin.zip
├── plugin.json       (wymagany)
├── data.sqlite       (opcjonalnie, dla wtyczek treściowych/interfejsowych)
├── template.html     (opcjonalnie)
├── style.css         (opcjonalnie)
└── logo.png          (opcjonalnie)
```

Wymagane pliki:

- `plugin.json` — manifest wtyczki (zobacz poniżej).

Opcjonalne pliki:

- Baza danych SQLite dla wtyczek przechowujących treść lub dane interfejsu.
- Zasoby HTML, Markdown, obrazów lub JSON przywoływane przez manifest.

Wszystkie odwołania do zasobów w `plugin.json` muszą używać dokładnych, płaskich nazw plików bez ścieżek. Na przykład użyj `template.html` zamiast `templates/template.html`.

## Podstawy manifestu

Minimalny `plugin.json` wygląda tak:

```json
{
  "id": "org.example.myplugin",
  "name": "Example Plugin",
  "version": "0.1.0",
  "type": "ui",
  "description": "A short description of what the plugin does.",
  "extensions": [
    {
      "surface": "bible-verse-menu",
      "config": {
        "label": "Example",
        "icon": "🔌",
        "screenType": "template",
        "templateFile": "template.html"
      }
    }
  ]
}
```

### Częste pola manifestu

| Pole            | Wymagane                          | Opis                                                              |
| --------------- | --------------------------------- | ----------------------------------------------------------------- |
| `id`            | Tak                               | Identyfikator w stylu odwrotnej domeny, na przykład `org.example.myplugin`. |
| `name`          | Tak                               | Nazwa wyświetlana użytkownikowi.                                    |
| `version`       | Tak                               | Wersja wtyczki w formacie semver.                                 |
| `type`          | Tak                               | `ui`, `content` lub `composite`.                                    |
| `description`   | Nie                               | Krótkie podsumowanie działania wtyczki.                           |
| `minAppVersion` | Nie                               | Minimalna wersja aplikacji Theodia wymagana przez wtyczkę.        |
| `apiVersion`    | Nie                               | Wersja API wtyczki, na którą jest ukierunkowana.                  |
| `extensions`    | Wymagane dla `ui` i `composite` | Tablica deklaracji powierzchni (zobacz poniżej).                 |

### Powierzchnie

Każdy wpis `extensions` deklaruje, gdzie wtyczka się pojawia i co robi:

```json
{
  "surface": "home-screen",
  "config": {
    "title": "My Plugin",
    "icon": "📝",
    "screenType": "list",
    "dbTable": "Articles",
    "titleColumn": "Title"
  }
}
```

Obsługiwane powierzchnie:

- `bottom-toolbar` — wpis w dolnej zakładce Wtyczki.
- `home-screen` — kafelek na ekranie głównym.
- `hamburger-menu` — pozycja w głównym menu.
- `bible-verse-menu` — akcja po długim przytrzymaniu wersetu w czytelniku Biblii.
- `bible-chapter-toolbar` — akcja na pasku narzędzi rozdziału w czytelniku Biblii.
- `book-chapter-toolbar` — akcja na pasku narzędzi rozdziału w czytelniku ksiąg.
- `ai-verse-action` — akcja AI na wersecie (wymaga włączenia AI).
- `ai-chapter-action` — akcja AI na rozdziale (wymaga włączenia AI).
- `event` — obsługa zdarzenia cyklu życia aplikacji.

### Typy ekranów

Pole `screenType` w konfiguracji powierzchni mówi aplikacji, jak renderować ekran wtyczki:

- `list` — przewijana lista wierszy bazy danych.
- `data-list` — lista z dodawaniem, edycją i usuwaniem.
- `detail` — pojedynczy wiersz lub treść fragmentu.
- `markdown` — statyczny plik Markdown wyrenderowany jako HTML.
- `html` — statyczny plik HTML wyrenderowany za pomocą `react-native-render-html`.
- `template` — plik HTML z zamianą symboli zastępczych `{{key}}`.
- `flashcard` — interfejs fiszek używający dwóch kolumn bazy danych.

## Dystrybucja

Po spakowaniu do pliku `.plugin.zip` wtyczka może być:

- Importowana bezpośrednio przez użytkownika z pliku.
- Serwowana z repozytorium katalogu.

## Wskazówki

- Upewnij się, że `plugin.json` jest prawidłowym JSON. Aplikacja odrzuca nieprawidłowe manifesty podczas instalacji.
- Używaj dokładnych nazw plików dla wszystkich przywoływanych zasobów.
- Identyfikatory wtyczek powinny być w stylu odwrotnej domeny, aby uniknąć konfliktów.
- Testuj treść wtyczki offline, ponieważ użytkownicy mogą nie mieć połączenia sieciowego.
