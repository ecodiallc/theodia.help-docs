---
title: Włączanie i konfigurowanie wtyczek
level: advanced
categories: plugins
summary: Jak włączać, wyłączać i importować wtyczki.
---

# Włączanie i konfigurowanie wtyczek

Gdy wtyczka jest zainstalowana, możesz ją włączyć, wyłączyć lub usunąć. Ten przewodnik pokazuje, jak to zrobić.

## Jak otworzyć ustawienia wtyczek

1. Otwórz **Ustawienia**.
2. Stuknij **Wtyczki**.
3. Stuknij **Zarządzaj wtyczkami**.

## Jak włączyć lub wyłączyć wtyczkę

Na liście **Zainstalowane wtyczki** znajdź wtyczkę, której chcesz użyć. Stuknij przełącznik po prawej stronie.

- **Włączone** — wtyczka jest aktywna.
- **Wyłączone** — wtyczka jest wstrzymana.

Niektóre wtyczki mają również przełącznik włącz/wyłącz w wierszu **Wtyczki** na ekranie głównym.

## Jak usunąć wtyczkę

1. Znajdź wtyczkę na liście **Zainstalowane wtyczki**.
2. Stuknij **Odinstaluj**.
3. Potwierdź.

## Jak zainstalować nową wtyczkę

1. Otwórz ustawienia wtyczek (powyżej).
2. Stuknij **Importuj z pliku**.
3. Wybierz plik wtyczki z urządzenia.

Wtyczka pojawi się na liście **Zainstalowane wtyczki**. Włącz ją, aby zacząć korzystać.

## Wskazówki

- Niektóre wtyczki potrzebują internetu do działania. Mogą nie działać offline.
- Niektóre wtyczki wymagają konta lub klucza. Strona wtyczki to wyjaśni.
- Jeśli wtyczka powoduje problemy, wyłącz ją. Reszta aplikacji nadal będzie działać.
- Usunięcie wtyczki nie usuwa Twoich notatek, podświetleń ani zakładek. Pozostają bezpieczne.
