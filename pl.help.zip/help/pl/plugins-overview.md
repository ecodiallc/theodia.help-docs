---
title: Czym są wtyczki?
level: advanced
categories: plugins
summary: Przewodnik po wtyczkach w przystępnym języku i tym, co mogą dodać.
---

# Czym są wtyczki?

Wtyczka to małe rozszerzenie dla Theodii. Wtyczki dodają nowe funkcje, nowe zasoby lub nowe narzędzia. Tworzą je ludzie ze społeczności Theodii.

## Co może zrobić wtyczka?

Wtyczki mogą robić wiele rzeczy. Kilka przykładów:

- Dodać nowy przekład Biblii.
- Dodać nowy komentarz lub leksykon.
- Dodać przycisk do dolnego paska narzędzi.
- Dodać kafelek na ekranie głównym.
- Dodać pozycję do głównego menu.
- Dodać niestandardowe narzędzie do studiowania.

## Jak znaleźć zainstalowane wtyczki

Wtyczki mogą pojawiać się w trzech miejscach:

- **Dolny pasek narzędzi** — zakładka **Wtyczki** u dołu ekranu.
- **Ekran główny** — siatka wtyczek na ekranie głównym.
- **Główne menu** — pozycja **Wtyczki** w głównym menu.

Miejsce, w którym pojawia się wtyczka, zależy od tego, co jej autor zadeklarował w manifeście. Stuknij dowolną ikonę wtyczki, aby ją otworzyć.

## Formaty plików wtyczek

Theodia obsługuje dwa formaty plików wtyczek:

- **`.plugin.zip`** — archiwum ZIP zawierające `plugin.json`, bazę danych wtyczki i ewentualne zasoby. To zalecany format. Nazwa pliku wygląda np. tak: `org.example.myplugin.plugin.zip`.
- **Starsze zasoby jednoplikowe** — starsze pliki `.bible`, `.commentary`, `.lexicon`, `.book`, `.sqlite` lub `.db`, które osadzają manifest wewnątrz bazy danych. Nadal działają, ale mają mniej funkcji.

## Jak zainstalować nową wtyczkę

Theodia nie ma sklepu z wtyczkami wewnątrz aplikacji. Aby zainstalować wtyczkę:

1. Znajdź plik wtyczki na swoim urządzeniu.
2. Otwórz **Ustawienia** → **Wtyczki** → **Zarządzaj wtyczkami**.
3. Stuknij **Importuj z pliku**.
4. Wybierz plik wtyczki.

Wtyczka pojawi się na liście **Zainstalowane wtyczki**. Włącz ją, aby zacząć korzystać.

## Jak włączyć lub wyłączyć wtyczkę

W **Ustawienia** → **Wtyczki** → **Zarządzaj wtyczkami** znajdź wtyczkę na liście **Zainstalowane wtyczki**. Stuknij przełącznik po prawej stronie.

- **Włączone** — wtyczka jest aktywna.
- **Wyłączone** — wtyczka jest wstrzymana.

Wyłączenie wtyczki ukrywa jej funkcje. Nie usuwa wtyczki.

## Jak usunąć wtyczkę

1. Otwórz **Ustawienia** → **Wtyczki** → **Zarządzaj wtyczkami**.
2. Znajdź wtyczkę na liście **Zainstalowane wtyczki**.
3. Stuknij **Odinstaluj**.
4. Potwierdź.

## Co znajduje się w pliku `.plugin.zip`?

Plik `.plugin.zip` to archiwum ZIP. Musi zawierać:

- `plugin.json` — manifest wtyczki.
- Bazę danych wtyczki, nazwaną dokładnie tak, jak zadeklarowano w manifeście.

Może również zawierać:

- Zasoby HTML lub Markdown przywoływane przez manifest.

Manifest deklaruje identyfikator wtyczki `id`, nazwę `name`, wersję `version` oraz to, co zapewnia:

- `type`: `content`, `ui` lub `composite`.
- `content`: baza danych SQLite i schemat dla treści biblijnej, komentarza, leksykonu, książki lub rozważań.
- `extensions`: powierzchnie, takie jak `bottom-toolbar`, `home-screen`, `hamburger-menu`, akcje na wersetach, przyciski paska narzędzi rozdziału lub obsługa zdarzeń.

## Słowo ostrzeżenia

Wtyczki tworzą inni ludzie, a nie zespół Theodii. Przeczytaj opis wtyczki przed instalacją. Niektóre wtyczki mogą wymagać internetu lub zbierać dane.

## Tworzenie wtyczek

Jeśli chcesz tworzyć lub edytować wtyczki w repozytorium źródłowym Theodii, zobacz przewodnik [Tworzenie wtyczek](theodia://help/plugin-development). Wyjaśnia, jak pakować wtyczki za pomocą `npm run package-plugins` i importować je z powrotem do edycji za pomocą `npm run import-plugin-dev`.

## Gdzie uzyskać pomoc dotyczącą wtyczki?

Każda wtyczka ma własną stronę w **Zarządzaj wtyczkami**. Sprawdź tam najpierw. Jeśli nadal masz pytanie, zobacz przewodnik [Gdzie szukać pomocy](theodia://help/getting-more-help).
