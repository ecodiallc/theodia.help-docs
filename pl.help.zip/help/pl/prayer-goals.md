---
title: Cele modlitewne
level: everyday
categories: [prayer]
summary: Śledź osobiste nawyki i cele modlitewne.
---

# Cele modlitewne

> **Tryb:** Cele modlitewne są dostępne w trybach **Standardowy** i **Uczony**. Tryb **Skupienie** ukrywa dodatkowe narzędzia, aby zapewnić czytanie bez rozpraszania. Tryb możesz zmienić w **Ustawienia** → **Tryb użytkownika**.

Cele modlitewne pozwalają śledzić nawyki, na których Ci zależy — codzienne odmawianie stałej modlitwy, wykonanie trzech rutyn dziennie, pisanie w dzienniku przed snem, dziesięć minut ciszy lub dowolny inny wzorzec, który wybierzesz. Theodia już rejestruje Twoją aktywność modlitewną, więc cel po prostu obserwuje tę aktywność i pokazuje, jak Ci idzie.

## Co mierzy cel

Tworząc cel, wybierasz, co ma być liczone:

- **Rutyny** — wykonanie dowolnej rutyny, konkretnej rutyny lub rutyny zawierającej określony typ kroku, np. cisza albo lectio divina.
- **Wpisy dziennika** — pisanie w dzienniku modlitwy.
- **Minuty minutnika** — czas spędzony w minutniku modlitwy.
- **Stałe modlitwy** — czytanie stałej modlitwy lub credo.
- **Sesje prowadzone** — ukończenie prowadzonej modlitwy audio.
- **Ręczny check-in** — samodzielnie stukasz **Oznacz jako wykonane**, gdy się pomodlisz.

Możesz też ustawić liczbowy cel i harmonogram: codziennie, co tydzień, co miesiąc, konkretne dni tygodnia lub jednorazowo.

## Utwórz cel

1. Przejdź do zakładki **Modlitwa**.
2. Stuknij **Cele** (lub przycisk **+**, jeśli wiersz Celów już widoczny).
3. Stuknij unoszony się przycisk **+**, aby otworzyć kreator celu.
4. Wybierz szablon, aby szybko zacząć, albo opcję **Zacznij od podstaw**.
5. Wypełnij szczegóły: nazwę, ikonę, kolor, cel, harmonogram i godzinę przypomnienia.
6. Stuknij **Zapisz cel**.

Pierwszy utworzony cel jest automatycznie przypinany do ekranu głównego Modlitwy.

## Przypnij cel do ekranu głównego

Przypięte cele pojawiają się na karcie **Aktywny cel** na górze zakładki Modlitwa oraz w wierszu **Cele modlitewne** poniżej Statystyk. Aby przypiąć lub odpiąć cel:

1. Otwórz listę celów.
2. Znajdź wybrany cel.
3. Stuknij cel, a następnie **Przypnij do ekranu głównego**. Stuknij ponownie, aby **Odepnij**.

Możesz przypiąć maksymalnie dwa cele. Przypiąć można tylko aktywne cele.

## Oznacz cel jako wykonany

Jeśli cel ma ustawiony **ręczny check-in**, Theodia nie wie automatycznie, że się pomodliłeś. Zaznaczasz to sam:

1. Otwórz ekran szczegółów celu.
2. Stuknij **Oznacz jako wykonane dziś**.
3. Opcjonalnie dodaj krótką notatkę, potem ponownie stuknij **Oznacz jako wykonane**.

Możesz też otworzyć menu przepełnienia na karcie Aktywny cel i stuknąć **Oznacz jako wykonane**.

## Czytaj postęp

Stuknij dowolny cel, aby otworzyć jego szczegóły. Zobaczysz tam:

- **Dzisiejszy postęp** — jak blisko jesteś celu w tym momencie.
- **Serie** — aktualna seria i najdłuższa seria.
- **Skuteczność** — procent zaplanowanych dni zakończonych sukcesem.
- **Mini kalendarz** — zielone dni to wykonane, zarysowany dzień to dziś.
- **Ostatnia historia** — postęp z ostatnich dwóch tygodni.

### Działania na celu

Z ekranu szczegółów możesz:

- **Przypnij** lub **odepnij** z ekranu głównego.
- **Wstrzymaj**, aby na jakiś czas przestać śledzić (serie zostają zamrożone).
- **Wznów**, aby zacząć śledzić ponownie.
- **Edytuj**, aby zmienić cel, harmonogram, przypomnienie lub styl.
- **Usuń**, aby usunąć cel i jego historię.

## Wgląd

Ekran **Wgląd w cele** pokazuje trendy we wszystkich celach:

- Cele spełnione dziś, w tym tygodniu i w tym miesiącu.
- Aktualna najdłuższa seria.
- Tygodniowa i miesięczna skuteczność.
- Średni dzienny czas modlitwy (z celów minutnikowych).
- Najbardziej konsekwentny cel.
- Rozkład celów według typu.

Otwórz Wgląd z menu przepełnienia na liście Celów modlitewnych.

## Skróty klawiszowe

Jeśli używasz zewnętrznej klawiatury:

- **Escape** — wróć do tyłu.
- **Cmd + S** (iOS) lub **Ctrl + S** (Android) — zapisz cel w kreatorze.
- **Cmd + E** (iOS) lub **Ctrl + E** (Android) — skopiuj podsumowanie do schowka z ekranu szczegółów celu lub wglądu.

## Przypomnienia i dni łaski

Cel może przypominać w wybrane dni o wybranej godzinie. Przypomnienia korzystają z lokalnych powiadomień urządzenia i szanują główne ustawienie powiadomień w **Ustawienia** → **Powiadomienia**.

**Dni łaski** chronią serię, gdy opuszczasz dzień. Jeśli ustawisz 1 lub 2 dni łaski, seria nie przerwie się, dopóki nie opuścisz tylu zaplanowanych dni z rzędu.

## Wskazówki

- Zacznij od jednego celu. Łatwiej budować nawyk, gdy masz jeden punkt skupienia.
- Używaj szablonów dla popularnych wzorów, potem dostosuj cel lub harmonogram.
- Wstrzymaj cel podczas podróży lub choroby zamiast go usuwać — serie zamrażają się i wznawiają po powrocie.
- Cele z ręcznym check-inem sprawdzają się w sytuacjach, których Theodia nie mierzy automatycznie, np. modlitwa za konkretną osobę lub rodzinę.
- Raz w tygodniu sprawdzaj Wgląd, aby zobaczyć, które cele idą najłatwiej, a które wymagają uwagi.
