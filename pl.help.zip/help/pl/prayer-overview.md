---
title: Modlitwa — przegląd
level: beginner
categories: prayer
summary: Szybkie wprowadzenie do zakładki Modlitwa i jej głównych sekcji.
---

# Modlitwa — przegląd

Zakładka **Modlitwa** to dedykowane miejsce modlitwy. Znajdziesz tu listy, sesje prowadzone, dziennik, minutnik, harmonogramy lekcjonarza i klasyczne stałe modlitwy.

## Główne sekcje

- **Lista próśb** — śledź osoby, sytuacje i tematy, za które się modlisz.
- **Dziennik** — zapisuj refleksje, odpowiedzi na modlitwy i myśli na przestrzeni czasu.
- **Wygeneruj modlitwę** — poproś Teofila, aby ułożył modlitwę na podstawie prośby lub wpisu dziennika.
- **Wyznania i stałe modlitwy** — klasyczne modlitwy i wyznania wiary z tradycji chrześcijańskiej.
- **Lekcjonarz** — harmonogramy czytania Pisma na każdy dzień lub sezon.
- **Prowadzona modlitwa** — sesje modlitwy prowadzonej głosem przez syntezator mowy.
- **Minutnik** — czasowe sesje modlitwy z opcjonalnymi dzwonkami.
