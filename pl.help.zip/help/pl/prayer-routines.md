---
title: Rutyny
level: everyday
categories: [prayer]
summary: Buduj codzienny nawyk, tworząc i wykonując rutyny modlitwy, czytania Biblii, rozważań, zakładek, podświetleń i nie tylko.
---

# Rutyny

**Rutyna** to uporządkowana lista kroków. Możesz o niej myśleć jak o playliście dla Twojego życia duchowego: może zawierać modlitwę, fragment Biblii, rozważanie, stałą modlitwę, np. Modlitwę Pańską, ciszę, refleksję, Twoje prośby modlitewne, zakładki, podświetlenia, hymny i fiszki.

Rutyny mieszczą się na własnej zakładce **Rutyny**. Gdy funkcja jest włączona, zakładka **Rutyny** widoczna jest na dolnym pasku aplikacji.

## Dlaczego rutyny są ważne

- **Nawyki:** Rutyna zamienia rozproszone chwile w jedną spójną sesję.
- **Elastyczność:** Możesz budować rutyny na poranną modlitwę, wieczorne czytanie Biblii, nabożeństwo rodzinne, dziennik wdzięczności, powtórkę memorowanych fragmentów lub dowolny inny okres.
- **Wszystko w jednym miejscu:** Modlitwa, Pismo, zakładki, podświetlenia i narzędzia do studiów mogą płynąć razem w jednej rutynie.

## Rozpocznij rutynę

1. Stuknij zakładkę **Rutyny**.
2. Stuknij wybraną rutynę.
3. Stuknij **Rozpocznij**, aby otworzyć wykonawcę rutyn i przejść przez kolejne kroki.

## Zbuduj rutynę

1. Na liście **Rutyny** stuknij przycisk **+**.
2. Nadaj rutynie nazwę i opcjonalny opis.
3. Stuknij **Dodaj krok** i wybierz typ kroku:
   - **Fragment** — czytaj fragment Biblii.
   - **Stała modlitwa** — credo, modlitwa lub liturgia z biblioteki.
   - **Lista próśb** — módl się za swoje aktywne prośby.
   - **Cisza / Refleksja / Wolna modlitwa** — czas z ograniczeniem lub bez.
   - **Segment prowadzony** — fragment prowadzonej modlitwy audio.
   - **Hymn** — czytaj lub śpiewaj hymn.
   - **Fiszki** — powtarzaj karty pamięciowe.
   - **Rozważanie** — czytaj dzisiejszy wpis rozważania.
   - **Przegląd zakładek** — wróć do zapisanych zakładek.
   - **Przegląd podświetleń** — powtórz podświetlone wersety.
4. Zmień kolejność kroków, stukając strzałki góra/dół przy każdym kroku. Ustaw czas trwania lub etykietę, jeśli chcesz.
5. Stuknij **Zapisz**.

## Przypnij rutynę

Przypięte rutyny pojawiają się na górze listy Rutyn.

1. Otwórz listę **Rutyny**.
2. Przytrzymaj rutynę.
3. Stuknij **Przypnij rutynę**.

## Dodaj coś do rutyny

Prawie wszystko w aplikacji może stać się krokiem rutyny:

- **Czytnik Biblii:** Stuknij werset, potem przycisk **+** i wybierz rutynę.
- **Zakładki:** Przytrzymaj biblijną zakładkę lub stuknij przycisk **+** i wybierz rutynę.
- **Stałe modlitwy:** Stuknij przycisk **+** w wierszu stałej modlitwy.
- **Prośby modlitewne:** Stuknij przycisk **+** w wierszu prośby.
- **Podświetlenia:** Wybierz krok przeglądu podświetleń, aby wrócić do zaznaczonych wersetów.

Element możesz wstawić na początku, na końcu lub po konkretnym kroku.

## Ukończ rutynę

Wykonawca rutyn prowadzi Cię przez każdy krok. Niektóre kroki przechodzą automatycznie, inne czekają, aż stukniesz **Dalej**. Na końcu widzisz ekran gratulacji z opcjami dodania rutyny do playlisty lub rozpoczęcia kolejnej.

Zielona fajka pojawia się na karcie rutyny do końca dnia, pokazując, że została ukończona.

## Usuń lub edytuj rutynę

- **Edytuj:** Otwórz listę rutyn, stuknij rutynę, potem **Edytuj rutynę**.
- **Usuń:** Przytrzymaj rutynę i stuknij **Usuń**. Rutyn wbudowanych nie można usuwać, ale możesz je ukryć, odpinając je.

## Uwaga o prywatności

Rutyny i ich dane pozostają na Twoim urządzeniu. Statystyki i odznaki są opcjonalne; aby je wyłączyć, przejdź do **Ustawienia** → **Modlitwa** i wyłącz opcje śledzenia.
