---
title: Statystyki modlitwy i serie
level: everyday
categories: prayer
summary: Jak działają serie modlitewne i jak wyłączyć statystyki oraz odznaki.
---

# Statystyki modlitwy i serie

Ekran **Statystyki** na zakładce Modlitwa śledzi Twoją aktywność modlitewną i serie, gdy w **Ustawienia** → **Modlitwa** włączona jest opcja **Włącz statystyki modlitwy**. Zaprojektowano go, aby zachęcać do codziennej modlitwy, nie będąc natrętnym.

## Co liczy się jako aktywność

Jako aktywność modlitewną rejestrowane jest:

- Ukończone **rutyny**
- Ukończone **sesje prowadzone**
- Ukończone **sesje minutnika**
- Odmówione **prośby modlitewne**
- Przeczytane **stałe modlitwy**
- Przeczytane wpisy **lekcjonarza**
- Dodane **wpisy dziennika**

Wszystkie te działania pojawiają się w podsumowaniu aktywności.

## Tylko rutyny przedłużają serię

Twoja **seria modlitewna** to liczba kolejnych dni, w których ukończono co najmniej jedną rutynę modlitewną.

- Ukończenie rutyny przedłuża serię.
- Inna aktywność modlitewna jest rejestrowana, ale sama nie przedłuża serii.
- Jeśli opuścisz dzień, seria resetuje się do zera.
- Ukończenie kilku rutyn w jednym dniu liczy się jako jeden dzień serii.

> **Wskazówka:** Jeśli chcesz budować lub utrzymać serię, uczyń rutyny centrum codziennego czasu modlitwy.

## Co pokazuje ekran Statystyki

- **Aktualna seria** — kolejne dni z ukończoną rutyną.
- **Najdłuższa seria** — Twój rekord wszech czasów.
- **Podsumowanie aktywności** — sumy z tego tygodnia, miesiąca i ogółem.
- **Kalendarz** — miesięczny widok dni z aktywnością modlitewną.

## Odznaki

Gdy włączona jest opcja **Pokaż odznaki modlitewne**, możesz zdobywać ukryte osiągnięcia za kamienie milowe w modlitwie. Odznaki to lekka funkcja typu Easter Egg, nie wymóg.

Odznaki wymagają włączonych Statystyk modlitwy. Gdy statystyki są wyłączone, odznaki również znikają.

## Jak wyłączyć statystyki i odznaki

W dowolnej chwili możesz je wyłączyć:

1. Otwórz **Ustawienia** → **Modlitwa**.
2. Wyłącz przełącznik **Włącz statystyki modlitwy**.
3. Wyłącz przełącznik **Pokaż odznaki modlitewne**.

Po wyłączeniu statystyk:

- Serie przestają być liczone.
- Sekcja Statystyki znika z zakładki Modlitwa.
- Odznaki są ukryte.
- Istniejące dane modlitwy pozostają na urządzeniu; nic nie jest usuwane.

Aby włączyć statystyki ponownie, po prostu włącz przełącznik z powrotem.
