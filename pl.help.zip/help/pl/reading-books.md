---
title: Czytanie wbudowanych ksiąg
level: beginner
categories: [content, read]
summary: Jak czytać klasyki chrześcijańskie dołączone do aplikacji.
---

# Czytanie wbudowanych ksiąg

Theodia zawiera małą bibliotekę ksiąg chrześcijańskich. Są to klasyki, które możesz czytać na urządzeniu.

## Jak otworzyć bibliotekę

Stuknij zakładkę **Księgi** na dolnym pasku ekranu. Zobaczysz listę ksiąg w bibliotece.

## Jak czytać książkę

1. Stuknij tytuł książki.
2. Książka otworzy się na pierwszym rozdziale.
3. Użyj przycisków **Poprzedni** i **Następny** u góry, aby poruszać się między rozdziałami.

## Jak przejść do rozdziału

Stuknij nazwę rozdziału u góry ekranu. Pojawi się lista rozdziałów. Wybierz jeden, aby do niego przejść.

## Jak zmienić rozmiar czcionki

Otwórz **Ustawienia** → **Wygląd** i wybierz rozmiar czcionki. Rozmiar tekstu zmieni się w całej aplikacji, także w księgach.

## Jak dodać zakładkę w księdze

Stuknij ikonę **gwiazdki** u góry po prawej. Aktualny rozdział zostanie zapisany. Stuknij zakładkę **Zakładki**, aby zobaczyć zapisane strony.

## Jak słuchać książki

Stuknij ikonę **głośnika** u góry po prawej. Aplikacja przeczyta rozdział na głos. Stuknij ponownie, aby zatrzymać.

## Jakie książki są dostępne?

Biblioteka zawiera klasyki, takie jak:

- Pilgrim's Progress
- The Imitation of Christ
- Practice of the Presence of God
- The Hymn Book

Lista ksiąg może rosnąć w czasie. Aktualizacje aplikacji mogą dodawać kolejne.

## Wskazówki

- Książki przechowywane są na urządzeniu. Nie potrzebujesz internetu.
- Książki nie synchronizują się z chmurą.
