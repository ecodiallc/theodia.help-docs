---
title: Szukanie zasobów na GitHubie
level: everyday
categories: resources
summary: Przeszukaj jednocześnie wszystkie repozytoria GitHuba znane aplikacji, a potem zainstaluj to, co znajdziesz.
---

# Szukanie zasobów na GitHubie

Theodia prowadzi listę repozytoriów GitHuba, które publikują zasoby — Biblie, komentarze, księgi, rozważania, playlisty, pakiety modlitw i więcej. **Szukaj w repozytoriach GitHuba** przeszukuje je wszystkie naraz, więc nie musisz otwierać każdej zakładki i przeglądać ich osobno.

> Sekcja GitHub w Ustawieniach jest dostępna tylko w trybie **Badacz**. Aby ją włączyć, przejdź do **Ustawienia → Tryb użytkownika → Badacz**.

## Jak szukać

1. Otwórz **Ustawienia**.
2. Stuknij **Szukaj w repozytoriach GitHuba**.
3. Wpisz słowo w polu wyszukiwania. Aplikacja szuka tego słowa w **nazwie** i **opisie** każdego zasobu w każdym repozytorium.

Kilka rzeczy wartych uwagi przy wyszukiwaniu:

- **Każde słowo musi pasować.** Szukanie `morning evening` znajduje tylko zasoby, których nazwa lub opis zawiera *oba* słowa.
- **Wielkość liter nie ma znaczenia.** `Morning` i `morning` znajdują te same zasoby.
- **Najlepsze dopasowanie przychodzi pierwsze.** Zasób, którego nazwa *zaczyna się* od szukanego tekstu, jest pokazywany przed zasobem, który wspomina go tylko w opisie.

## Filtry

Stuknij pasek filtrów nad wynikami, aby jeszcze bardziej zawęzić listę. Są dwa filtry i działają razem:

- **Autor** — tylko zasoby danego autora.
- **Tradycja** — tylko zasoby danej tradycji.

Stuknij filtr ponownie, aby go wyczyścić, albo stuknij **Wyczyść filtry**, aby wyczyścić oba.

## Instalowanie z wyników

Każdy wynik pokazuje nazwę zasobu, jakiego jest typu, kto go stworzył i z jakiego repozytorium pochodzi. Po prawej stronie wiersza jest jeden przycisk:

- **Zainstaluj** — zasobu jeszcze nie ma na Twoim urządzeniu.
- **Aktualizuj** — dostępna jest nowsza wersja. Aplikacja najpierw prosi o potwierdzenie, ponieważ aktualizacja usuwa starą kopię wraz z notatkami, podświetleniami i zakładkami, które do niej prowadzą.
- **Otwórz** — zasób jest już zainstalowany; stuknięcie przenosi Cię na ekran, na którym z niego korzystasz.

Stuknij **Odśwież** u góry, aby od razu pobrać z GitHuba najnowszą listę. Aplikacja odświeża listę sama raz dziennie, więc ręczne odświeżenie jest potrzebne tylko wtedy, gdy wiesz, że coś nowego zostało opublikowane.

## Szukanie bez połączenia

Aplikacja przechowuje kopię listy na Twoim urządzeniu, więc wyszukiwanie działa nawet offline. Jeśli aplikacja nie może połączyć się z GitHubem, aby odświeżyć listę, baner u góry informuje, że widzisz wyniki z pamięci podręcznej.

## Gdy wyszukiwanie nic nie znajduje

- Spróbuj krótszego, pojedynczego słowa.
- Sprawdź, czy filtr **Autor** albo **Tradycja** wciąż nie jest ustawiony — przycisk **Wyczyść filtry** pojawia się zawsze, gdy któryś jest.
- Niektóre repozytoria publikują swoje zasoby w innym języku niż nazwa zasobu, więc szukanie przetłumaczonego słowa może ich nie znaleźć.
