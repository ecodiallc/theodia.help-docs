---
title: Tryb Uczony
level: advanced
categories: [layout, read, study]
summary: Najgłębszy tryb studiów w Theodii, odblokowujący komentarze, leksykony, odniesienia krzyżowe, narzędzia AI i Szybkie menu.
---

# Tryb Uczony

> **Tryb:** Tryb Uczony jest dostępny tylko wtedy, gdy Twój tryb użytkownika ustawiony jest na **Uczony**. Przełączasz go w **Ustawienia** → **Tryb użytkownika**.

Tryb Uczony odblokowuje wszystkie narzędzia studiów w Theodii. Jest on nakładką na tryb Studium, więc wciąż masz menu wersetu, Biblię równoległą, zakładki, podświetlenia i notatki — plus zaawansowane narzędzia wymienione poniżej.

## Jak otworzyć tryb Uczony

Tryb Uczony to nie osobny ekran. To zestaw dodatkowych narzędzi, które pojawiają się w czytniku i nawigacji, gdy Twój tryb użytkownika to Uczony.

1. Otwórz **Ustawienia**.
2. Stuknij **Tryb użytkownika**.
3. Wybierz **Uczony**.

Zmiana działa od razu. Ukryte wcześniej menu i przyciski stają się widoczne.

## Dodatkowe narzędzia w czytniku

Gdy otworzysz rozdział w trybie [Studium](theodia://help/study-mode), tryb Uczony dodaje do menu wersetu te narzędzia:

- **Komentarz AI** (◈) — poproś Asystenta AI, aby napisał notatkę studialną do tego wersetu. (Niedostępne we wszystkich regionach.)
- **Informacje o słowie** (?) — otwórz hasło leksykonu dla oryginalnego hebrajskiego lub greckiego słowa za wersetem. Zobacz przewodnik [Komentarze i leksykony](theodia://help/commentaries-and-lexicons).
- **Słownik** (📖) — sprawdź ogólne słowa biblijne w zainstalowanych zasobach słownikowych. Zobacz przewodnik [Słownik biblijny](theodia://help/dictionary).

Te narzędzia wymagają zainstalowanych zasobów (komentarze, leksykony, pliki słownikowe). Jeśli narzędzie jest wyszarzone lub pokazuje „nie znaleziono”, otwórz **Ustawienia** → **Zarządzaj zasobami** i dodaj brakujący zasób.

## Dodatkowa nawigacja

### Dodatkowa zakładka paska narzędzi

Dolny pasek narzędzi zyskuje jedną dodatkową zakładkę:

- 💻 **AI** — otwiera Asystenta AI (tylko jeśli włączyłeś AI w Ustawieniach). Ta zakładka znajduje się po prawej stronie Notatek.

### Dodatkowe pozycje w menu głównym

W menu głównym pojawia się pozycja **Asystent AI** pod tym samym warunkiem.

## Szybkie menu

Tryb Uczony włącza **Szybkie menu**, czyli szybki sposób na przejście do ostatnich wersetów, uruchomienie poleceń i zmianę układu Biblii bez opuszczania aktualnego ekranu. Jak z niego korzystać, opisuje przewodnik [Szybkie menu](theodia://help/launcher-menu).

## Kiedy używać trybu Uczony

- Chcesz mieć Asystenta AI, komentarze lub wyszukiwanie w językach oryginalnych podczas czytania.
- Chcesz używać Szybkiego menu do szybkiej nawigacji wersetami i czatu AI.
- Studiujesz fragment dogłębnie i potrzebujesz wszystkich narzędzi na wyciągnięcie ręki.

## Przełączenie na lżejszy tryb

Jeśli chcesz prostszy czytnik bez zaawansowanych narzędzi, przełącz się na tryb **Standardowy** w **Ustawienia** → **Tryb użytkownika**. Tryb Standardowy zachowuje zakładki, podświetlenia, notatki i tryb Studium, ale ukrywa AI, komentarze, leksykony i Szybkie menu.

Jeśli chcesz najczystsze możliwe czytanie, otwórz rozdział w trybie [Skupienie](theodia://help/focus-mode).

Twoje zakładki, podświetlenia i notatki nigdy nie są usuwane przy zmianie trybu; są po prostu ukryte, dopóki nie wrócisz do trybu, który je obsługuje.

## Pomoc i pytania

Jeśli brakuje narzędzia lub pokazuje błąd, zobacz przewodnik [Typowe problemy](theodia://help/common-problems). Jeśli dopiero zaczynasz przygodę z Theodią, przewodnik [Czytanie pierwszego rozdziału](theodia://help/first-read) prowadzi krok po kroku przez podstawy.
