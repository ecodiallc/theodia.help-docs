---
title: Szukanie w Biblii
level: everyday
categories: [study, read]
summary: Jak znajdować wersety po słowie, frazie lub odwołaniu.
---

# Szukanie w Biblii

Pasek wyszukiwania pomaga szybko znaleźć wersety. Możesz szukać po słowie, frazie lub odwołaniu biblijnym.

## Jak rozpocząć wyszukiwanie

1. Stuknij zakładkę **Szukaj** na dolnym pasku ekranu.
2. Wpisz to, co chcesz znaleźć.
3. Stuknij **Szukaj** na klawiaturze.

Wyniki pojawiają się jako lista wersetów. Każdy wynik pokazuje księgę, rozdział, werset oraz treść wersetu.

## Wyszukiwanie po kombinacji słów

Gdy wpiszesz więcej niż jedno słowo, np. `miłość radość`, aplikacja znajduje wersety zawierające **oba** słowa. To wyszukiwanie typu **AND** — wszystkie słowa muszą pojawić się w wersecie. Nie działa logika **OR** (wersety z dowolnym pojedynczym słowem).

Aby szukać wersetów zawierających dowolne ze słów, musisz jawnie użyć słowa kluczowego `OR`: `miłość OR radość`.

## Wyszukiwanie po słowie

Wpisz jedno słowo, np. `miłość` lub `miłosierdzie`. Aplikacja pokaże każdy werset w Biblii, w którym ono występuje.

## Wyszukiwanie po frazie

Wpisz dwa lub trzy słowa w cudzysłowie, np. `"nie bójcie się"`. Aplikacja pokaże wersety zawierające dokładnie tę frazę.

## Filtrowanie wyników

Po wyszukaniu wyniki są filtrowane do zainstalowanych przekładów Biblii. Aby dodatkowo zawęzić, otwórz zakładkę **Biblie** i wybierz konkretny przekład — wyszukiwanie działa wśród zainstalowanych przekładów.

## Wskazówki dla lepszych wyszukiwań

- Używaj krótszych słów. Wyszukanie `miłość` da więcej wyników niż `miłujący`.
- Cudzysłów wokół frazy sprawia, że wyszukiwanie jest dokładne.
- Aplikacja przeszukuje tylko zainstalowane przekłady Biblii.
- Aby przejść do konkretnego wersetu po odwołaniu (np. `Jana 3:16`), użyj pola **Szybkie polecenie** na ekranie głównym zamiast zakładki Szukaj.

## Historia wyszukiwania

Aplikacja pamięta ostatnie wyszukiwania. Gdy otworzysz zakładkę **Szukaj**, na górze zobaczysz listę ostatnich haseł. Stuknij jedno, aby je ponownie uruchomić. Aby wyczyścić listę, stuknij **Wyczyść wszystko** u góry ostatnich wyszukiwań.

## Szukanie w PDF-ach

Zakładka Szukaj może też przeszukiwać Twoje dokumenty PDF:

1. Stuknij zakładkę **Szukaj**, a potem tryb **PDF** u góry.
2. Wybierz, które PDF-y przeszukać. Stuknij PDF, aby go uwzględnić lub wykluczyć; użyj **Wszystkie** lub **Wyczyść** nad listą, aby uwzględnić wszystko albo zacząć od nowa. Wybrać można tylko PDF-y, których tekst przeszukiwalny jest zainstalowany.
3. Wpisz, czego szukasz, i stuknij **Szukaj**.

Każdy wynik pokazuje tytuł PDF-a, numer strony i fragment pasującego tekstu. Stuknij wynik, aby otworzyć ten PDF na tej stronie.

Aby szukać w pojedynczym pliku PDF podczas jego czytania, użyj zamiast tego przycisku **Szukaj** w czytniku PDF — zobacz [PDF-y](theodia://help/pdfs).
