---
title: Tryb Studium
level: everyday
categories: [layout, read]
summary: Pełny czytnik Biblii w Theodii z narzędziami studialnymi: komentarzami, odniesieniami krzyżowymi, leksykonem i notatkami.
---

# Tryb Studium

> **Tryb:** Tryb Studium jest dostępny w trybach **Standardowy** i **Uczony**. Tryb Czytanie otwiera rozdziały w trybie Skupienie. Przełączasz go w **Ustawienia** → **Tryb użytkownika**.

Tryb Studium to główny czytnik Biblii w Theodii. Ma wbudowane wszystkie narzędzia studialne: komentarze, odniesienia krzyżowe, wyszukiwanie słów, przekłady równoległe, notatki i nie tylko.

Tryb Skupienie to prostszy czytnik bez narzędzi studialnych. Jeśli chcesz tylko czysty tekst, zobacz przewodnik [Tryb Skupienie](theodia://help/focus-mode). Ten przewodnik dotyczy trybu Studium.

## Jak otworzyć tryb Studium

Otworzyć rozdział w trybie Studium można na kilka sposobów:

- Stuknij zakładkę **Biblie** na dolnym pasku ekranu. Wybierz przekład, księgę i rozdział.
- Stuknij werset w wynikach wyszukiwania na zakładce **Szukaj**.
- Stuknij zakładkę z zakładek na zakładce **Zakładki**.
- W trybie Skupienie stuknij przycisk 📖 u góry ekranu, aby przełączyć się na Studium.

## Czytanie rozdziału

Rozdział otwiera się z wersetami w kolejności. U góry ekranu znajdują się przyciski do najczęstszych działań. Na dole ekranu jest pasek stanu.

- **Przesuń w lewo**, aby przejść do następnego rozdziału.
- **Przesuń w prawo**, aby wrócić do poprzedniego rozdziału.
- **Stuknij werset**, aby otworzyć menu wersetu z narzędziami studialnymi (patrz poniżej).
- **Stuknij numer Stronga w wersecie** (np. G1234 lub H1234), aby szybko sprawdzić hasło leksykonu dla tego słowa.

Jeśli masz włączony przekład równoległy, druga kopia rozdziału pojawi się poniżej głównego tekstu, w wybranym przekładzie. Więcej w sekcji **Czytanie dwóch przekładów na raz** poniżej.

## Menu wersetu

Gdy stukniesz werset, otwiera się menu z tytułem „Księga Rozdział:Werset”. Dostępne narzędzia zależą od trybu użytkownika.

### Narzędzia w trybach Standardowy i Uczony

- **Zakładka** (★) — zapisz werset, aby łatwo go później odnaleźć. Stuknij ponownie, aby usunąć zakładkę. Pierwsze stuknięcie dodaje ją. Zobacz przewodnik [Zakładki](theodia://help/bookmarks).
- **Podświetl** (□) — pokoloruj werset, aby się wyróżniał. Stuknij, aby otworzyć wybór koloru. Stuknij ten sam kolor ponownie, aby usunąć podświetlenie. Zobacz przewodnik [Podświetlenia](theodia://help/highlights).
- **Czytaj** (🔊) — przeczytaj werset na głos głosem syntezy mowy urządzenia. Ukryte dla Biblii międzywierszowych. Jak tego używać i wybrać głos, opisuje przewodnik [Czytanie na głos](theodia://help/tts).
- **Kopiuj** (⎘) — skopiuj tekst wersetu do schowka, aby wkleić go gdzie chcesz.
- **Porównaj** (⇄) — otwórz panel pokazujący ten sam werset w każdym zainstalowanym przekładzie. Stuknij przekład w panelu, aby czytać werset w tym przekładzie. Zobacz przewodnik [Porównywanie przekładów](theodia://help/compare-translations).
- **Odniesienia krzyżowe** (↗) — otwórz listę powiązanych wersetów z bazy odniesień krzyżowych. Zobacz przewodnik [Odniesienia krzyżowe](theodia://help/cross-references).
- **Dodaj/Edytuj notatkę biblijną** (✎) — napisz prywatną notatkę przypisaną do wersetu. Zobacz przewodnik [Notatki](theodia://help/notes).

### Narzędzia tylko w trybie Uczony

- **Komentarz AI** (◈) — poproś Asystenta AI, aby napisał notatkę studialną do tego wersetu. (Niedostępne we wszystkich regionach.)
- **Informacje o słowie** (?) — otwórz hasło leksykonu dla oryginalnego hebrajskiego lub greckiego słowa za wersetem. Zobacz przewodnik [Komentarze i leksykony](theodia://help/commentaries-and-lexicons).
- **Słownik** (📖) — sprawdź ogólne słowa biblijne w zainstalowanych zasobach słownikowych. Zobacz przewodnik [Słownik biblijny](theodia://help/dictionary).

Niektóre narzędzia wymagają dodatkowych zasobów. Jeśli narzędzie jest wyszarzone lub pokazuje „nie znaleziono”, otwórz **Ustawienia** → **Zarządzaj zasobami** i dodaj brakujący zasób.

## Przyciski u góry ekranu

Nad tekstem rozdziału znajduje się rząd ikon. To szybkie działania:

- **Wersja Biblii** — stuknij nazwę przekładu (np. „KJV”), aby przełączyć na inny przekład.
- **Księga** — stuknij nazwę księgi, aby przejść do innej księgi.
- **Rozdział** — stuknij numer rozdziału, aby przejść do innego rozdziału.
- **Otwórz w AI** (🤖) — wyślij aktualny rozdział do Asystenta AI z pytaniem. (Tylko tryb Uczony.)
- **Tryb Skupienie** (📖) — przełącz się na czyste czytanie.
- **Biblie równoległe** (🔵 / ⚪) — stuknij, aby włączyć lub wyłączyć przekłady równoległe. Gdy włączone, ten sam rozdział pokazuje się w wybranych przekładach równoległych poniżej głównego tekstu. Gdy wyłączone, widoczny jest tylko główny przekład. Więcej w sekcji **Czytanie wielu przekładów na raz** poniżej.
- **Czytaj** — przeczytaj cały rozdział na głos. Zobacz przewodnik [Czytanie na głos](theodia://help/tts).
- **Więcej** — otwórz dodatkowe działania na rozdział (notatka do rozdziału, komentarz do rozdziału, udostępnij itp.).

## Czytanie wielu przekładów na raz

Możesz wyświetlić do czterech dodatkowych przekładów obok głównego. Nazywa się to **widokiem równoległym**.

1. Otwórz **Ustawienia**.
2. Włącz **Biblia równoległa**.
3. Stuknij **Dodaj Biblię równoległą** i wybierz przekład.
4. Powtórz, aby dodać więcej. Możesz mieć do czterech przekładów równoległych.

Gdy widok równoległy jest włączony, każdy werset najpierw pokazuje się w głównym przekładzie, a następnie w każdym przekładzie równoległym. Dzięki temu łatwo porównać, jak różni tłumacze podchodzą do trudnego wersetu, nie opuszczając rozdziału.

Możesz zapisać aktualny układ równoległy jako **zestaw**. Stuknij przycisk zapisu obok wybranych przekładów, nadaj nazwę, a stanie się on szybką opcją przełączania. Stuknij dowolny zestaw później, aby natychmiast wczytać tę kombinację. Przytrzymaj zestaw, aby go usunąć.

Możesz też porównać pojedynczy werset za pomocą narzędzia **Porównaj** (⇄) w menu wersetu. Otwiera ono panel pokazujący werset w każdym zainstalowanym przekładzie.

## Podtytuły

Niektóre przekłady mają wbudowane nagłówki sekcji (np. „Kazanie na górze”). Jeśli Twój przekład je zawiera, możesz pokazać lub ukryć je w ustawieniu **Pokaż nagłówki sekcji** w **Ustawienia**. Podtytuły pojawiają się jako małe szare tytuły między wersetami.

## Notatka do rozdziału

Notatka do rozdziału to jedna notatka przypisana do całego rozdziału, a nie pojedynczego wersetu. Przydaje się, gdy masz jedną ogólną myśl o rozdziale.

Aby otworzyć notatkę do rozdziału:

1. Stuknij przycisk **Więcej** u góry ekranu.
2. Stuknij **Notatka do rozdziału**.
3. Napisz notatkę. Stuknij **Zapisz**.

Notatka do rozdziału jest zapisywana razem z rozdziałem. Pojawia się przy każdym otwarciu tego rozdziału.

## Podświetlenie słów wyszukiwania

Gdy trafisz do rozdziału z wyszukiwania, szukane słowa są podświetlone na żółto w tekście wersetu. Łatwo wtedy zobaczyć, dlaczego werset pasował do zapytania.

Możesz też ponownie przeszukać rozdział, który czytasz. Otwórz zakładkę **Szukaj**, wpisz słowo. Z wyników możesz stuknąć i wrócić do rozdziału z podświetlonymi trafieniami.

Biblii międzywierszowe (MIB — Marvel Interlinear Bible — i OHGB) zawsze otwierają się w trybie Studium, ponieważ wymagają układu na poziomie słowa.

## Przełączenie na tryb Skupienie dla jednego rozdziału

Z dowolnego rozdziału w trybie Studium stuknij przycisk 📖 u góry. Ten sam rozdział otworzy się w trybie Skupienie z ukrytymi menu. Stuknij przycisk 📖 na dolnym pasku, aby wrócić do trybu Studium.

## Kiedy używać trybu Studium

Tryb Studium to dobry wybór, gdy chcesz:

- **Czytać i studiować jednocześnie.** Wszystkie narzędzia są na wyciągnięcie ręki.
- **Sprawdzić nieznane słowo.** Stuknij numer Stronga w wersecie, aby szybko otworzyć hasło leksykonu.
- **Porównać przekłady.** Użyj narzędzia Porównaj w menu wersetu lub włącz widok równoległy.
- **Zobaczyć, jak werset łączy się z resztą Biblii.** Użyj Odniesień krzyżowych.
- **Robić notatki podczas czytania.** W menu wersetu jest szybka opcja dodania notatki.

Na długie, bezrozpraszające czytanie przełącz się w tryb Skupienie.

## Przełączenie w tryb Skupienie

Z dowolnego rozdziału w trybie Studium stuknij przycisk 📖 u góry. Ten sam rozdział otworzy się w trybie [Skupienie](theodia://help/focus-mode) z ukrytymi menu i narzędziami studialnymi. Stuknij przycisk 📖 na dolnym pasku, aby wrócić do trybu Studium. Pełny opis trybu Skupienie znajdziesz w przewodniku [Tryb Skupienie](theodia://help/focus-mode).

## Pomoc i pytania

Jeśli brakuje narzędzia lub pokazuje błąd, zobacz przewodnik [Typowe problemy](theodia://help/common-problems). Jeśli dopiero zaczynasz przygodę z Theodią, przewodnik [Czytanie pierwszego rozdziału](theodia://help/first-read) prowadzi krok po kroku przez podstawy.
