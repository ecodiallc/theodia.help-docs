---
title: Funkcje tabletu
level: everyday
categories: [layout, tablet]
summary: Jak układ Theodii dostosowuje się do tabletów i większych ekranów — widoki podzielone, panele boczne i czytanie w dwóch panelach.
---

# 📱 Funkcje tabletu

Theodia została zaprojektowana tak, aby wykorzystywać większe ekrany tabletów. Na tablecie (lub dowolnym urządzeniu szerszym niż około 700 pikseli) aplikacja automatycznie przełącza się na układ dwukolumnowy w wielu miejscach.

> **Tryb:** Opisane tu funkcje pojawiają się tylko wtedy, gdy aktualny tryb użytkownika je obsługuje. Na przykład panele boczne z komentarzami i czat AI dostępne są tylko w trybie Uczony. Widoki podzielone zakładek, podświetleń i notatek wymagają trybu Standardowy lub Uczony. Tryb Skupienie pokazuje tylko czyste, jednokolumnowe czytanie. Tryb zmienisz w **Ustawienia** → **Tryb użytkownika**.

## Menu wersetu w czytniku

Gdy stukniesz numer wersetu (lub przytrzymasz tekst wersetu), **menu wersetu** pojawia się jako **wyśrodkowana karta** na ciemnym tle.

- Przyciski **Kopiuj** i **Udostępnij** zawsze widoczne są na górze menu.
- **Zakładki** i **Podświetlenia** pokazywane są w aktualnym stanie.
- **Komentarz**, **Słownik** i **Porównaj** otwierają się z menu. Na tablecie narzędzia te mogą pojawić się w panelu bocznym lub szerokiej karcie po wybraniu.
- Stuknij w tło lub strzałkę zamknięcia, aby zamknąć menu.

## Panel komentarza do wersetu

Narzędzie **Komentarz** otwiera na tablecie **dedykowany panel boczny**:

- Tekst komentarza pojawia się obok tekstu Biblii.
- Możesz przewijać komentarz niezależnie od Biblii.
- Stuknij **X** lub przesuń, aby zamknąć.
- **Ikona książki** u góry panelu pozwala przełączyć źródło komentarza.
- **Ikona rozdziału** pozwala zobaczyć komentarz na poziomie rozdziału.

Na telefonie komentarz otwiera się jako pełnoekranowy modal.

## Komentarz do rozdziału

Do **Komentarza do rozdziału** dostaniesz się z przycisku **Więcej** u góry ekranu, a nie z menu wersetu. Na tablecie otwiera się jako panel boczny, podobnie jak Komentarz do wersetu, więc możesz czytać komentarz i tekst Biblii razem.

## Zakładka Porównaj

Zakładka **Porównaj** (w menu wersetu) otwiera się na tablecie jako **panel boczny**. Pokazuje wybrany werset w każdym włączonym przekładzie równoległym. Możesz stuknąć dowolny przekład, aby przejść do tego fragmentu w czytniku.

## Wyskakujący słownik / Strong

Narzędzie **Słownik** (menu wersetu → Słownik) otwiera się na tablecie jako szeroka karta. Pokazuje greckie lub hebrajskie słowo, jego transliterację, definicję i numer Stronga. Stuknij przycisk **Konkordancja**, aby zobaczyć każde wystąpienie tego słowa w Biblii.

## Stuknij słowo, aby otworzyć leksykon

W panelu bocznym **Informacje o słowie** na tablecie każda karta słowa, która ma numer Stronga, jest dotykowa. Stuknij kartę, aby bezpośrednio otworzyć panel **Leksykon** dla tego słowa. Panel Leksykon zastępuje panel Informacje o słowie, więc możesz kontynuować studia bez zamykania czytnika.

Na telefonie karty Informacji o słowie nie są dotykowe, ponieważ ekran jest za mały na dwa panele.

## Biblię równoległe obok siebie

W Ustawieniach stuknij **Biblie równoległe** i wybierz do trzech wersji. Na tablecie wersje pojawiają się jako **pionowe panele** obok siebie:

- Każdy panel przewija się niezależnie.
- Możesz stuknąć numer wersetu, aby otworzyć panel z narzędziami.
- Zakładka **Porównaj** pokazuje wszystkie wybrane wersety w jednym miejscu.
- Stuknij **X** na dowolnym panelu, aby go zamknąć i wrócić do widoku jednokolumnowego.
- Stuknij ikonę **Biblie równoległe** (🔵 / ⚪) na górnym pasku ikon, aby włączyć lub wyłączyć widok równoległy bez otwierania Ustawień.

Na telefonie przekłady równoległe pokazywane są jeden pod drugim (pionowo). Ta sama ikona przełącznika działa też na telefonach.

## Widok podzielony zakładek i podświetleń

Na tablecie zakładki **Zakładki** i **Podświetlenia** używają układu master-detail:

- **Lewa strona** — lista zakładek lub podświetleń.
- **Prawa strona** — stuknięcie elementu otwiera panel podglądu z tekstem wersetu lub fragmentu.

Możesz przeglądać zapisane elementy i podglądać je, nie opuszczając zakładki. Na telefonie stuknięcie elementu przechodzi do ekranu czytnika.

## Widok podzielony notatek

Zakładka **Notatki biblijne** na tablecie pokazuje listę notatek po lewej stronie, a wybraną notatkę po prawej. Stuknięcie notatki otwiera ją w panelu bocznym, więc możesz przeglądać kilka notatek z rzędu bez opuszczania listy. Tworzenie lub edycja notatki również używa panelu bocznego.

## Wyszukiwanie z podziałem

Na tablecie zakładka **Szukaj** pokazuje formularz wyszukiwania po lewej, a wyniki po prawej, gdy tylko uruchomisz wyszukiwanie. Możesz poprawiać zapytanie i obserwować aktualizację wyników bez zmiany ekranu. Na telefonie wyniki wyszukiwania otwierają się na osobnym ekranie.

## Pasek boczny kategorii ustawień

Ekran **Ustawienia** na tablecie pokazuje listę kategorii po lewej (AI, Wygląd, Kopia zapasowa, Biblie itd.). Stuknij kategorię, aby przejść bezpośrednio do jej ustawień po prawej. Rozwinięta jest tylko wybrana kategoria, więc nie musisz przewijać całej listy ustawień.

## Nawigacja biblijna na tabletach

Ekrany **Biblie**, **Księgi biblijne** i **Rozdziały biblijne** pozostają jednokolumnowe na tabletach, ale używają większych celów dotykowych, szerszych siatek i bardziej rozległego odstępu, aby treść była łatwiejsza do czytania i stukania. Nie używają układu podzielonego, ponieważ każdy krok potrzebuje pełnej szerokości, aby wyraźnie pokazać listę lub siatkę.

## Krajobraz i portret

Obrót tabletu automatycznie dostosowuje układ. W **trybie poziomym** panele boczne mają dużo miejsca. W **trybie pionowym** panele stają się węższe, ale wciąż pozostają obok tekstu.

## Czat AI dla wybranego wersetu

Czat **AI** otwiera się w panelu bocznym menu wersetu. Pokazuje interfejs rozmowy, w którym możesz zadawać pytania dotyczące wybranego wersetu. Odpowiedź AI pojawia się w panelu, a Ty możesz kontynuować rozmowę bez opuszczania czytnika.

## Pasek boczny rozmów na ekranie AI

Na tablecie w zakładce **AI** lista rozmów zawsze widoczna jest jako stały lewy pasek boczny. Możesz przełączać się między czatami bez otwierania menu. Przycisk **Nowy czat** również zawsze widoczny. Na telefonie lista rozmów znajduje się w wysuwanym szufladzie.

## Co pozostaje bez zmian

Nie każdy ekran dzieli się na dwa panele. Na tabletach te ekrany pozostają jednokolumnowe:

- **Biblie** — lista przekładów Biblii (pełna szerokość)
- **Księgi biblijne** — siatka ksiąg i sekcje (pełna szerokość)
- **Rozdziały biblijne** — siatka rozdziałów (pełna szerokość)
- **Ustawienia** — poszczególne strony ustawień (pełna szerokość)
- **Pomoc** — artykuły pomocy (pełna szerokość)

## Podsumowanie

Na tablecie otrzymujesz:

- **Biblię równoległą** w pionowych panelach obok siebie
- **Komentarz** w stałych panelach bocznych
- **Porównaj** i **Słownik** w szerokich kartach
- **Leksykon** po stuknięciu karty Informacji o słowie
- **Zakładki, Podświetlenia, Notatki, Rozważania, Księgi, Ustawienia** w układzie master-detail
- **Wyszukiwanie** z wynikami obok formularza
- **Tryb poziomy** i **pionowy** obsługiwane z automatyczną zmianą układu

Na telefonie wszystko używa tradycyjnej jednokolumnowej nawigacji typu drill-down. Aplikacja wykrywa szerokość ekranu przy uruchomieniu i wybiera odpowiedni układ automatycznie.
