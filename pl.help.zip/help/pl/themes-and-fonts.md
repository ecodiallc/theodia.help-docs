---
title: Zmiana motywu i czcionki
level: everyday
categories: settings
summary: Jak zmienić wygląd aplikacji.
---

# Zmiana motywu i czcionki

Theodia pozwala zmieniać wygląd aplikacji. Możesz wybrać motyw (jasny lub ciemny) oraz rozmiar czcionki.

## Jak otworzyć ustawienia wyglądu

1. Otwórz **Ustawienia**.
2. Stuknij **Wygląd**.

## Jak zmienić motyw

W sekcji **Wygląd** widzisz dwa przyciski motywu:

- **Domyślny** — jasne tło z ciemnym tekstem. Dobre na dzień.
- **Ciemny** — ciemne tło z jasnym tekstem. Dobre na noc i oszczędza baterię.

Stuknij motyw, aby go zastosować. Zmiana jest natychmiastowa.

## Jak zmienić rozmiar czcionki

W sekcji **Wygląd** stuknij jeden z przycisków rozmiaru: **---**, **--**, **-**, **Normalny**, **+**, **++**, **+++**. Tekst stanie się mniejszy lub większy w całej aplikacji. Wybierz rozmiar, który najłatwiej Ci się czyta.

## Wskazówki

- Ciemny motyw oszczędza baterię na telefonach z ekranami OLED.
- Jeśli tekst jest za mały, zwiększ rozmiar czcionki w aplikacji, a nie w systemie. Ustawienie aplikacji jest dokładniejsze.
- Na długie czytanie wypróbuj ciemny motyw i większą czcionkę.
- [Aktywuj motyw pustyni](theodia://unlock-desert)
