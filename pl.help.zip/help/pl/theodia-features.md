---
title: Funkcje Theodii
level: beginner
categories: welcome
summary: Szybki przegląd tego, co wyróżnia Theodię i jak pomaga w studiowaniu Biblii.
---

# Funkcje Theodii

Theodia została stworzona jako kompletny towarzysz studiów biblijnych. Oto co ją wyróżnia.

## Offline jako priorytet

Wszystko działa bez internetu. Biblie, komentarze, leksykony, księgi i rozważania przechowywane są na urządzeniu. Możesz czytać, szukać i studiować w dowolnym miejscu — w samolocie, w terenie bez zasięgu lub gdziekolwiek nie ma sieci.

## Dbałość o prywatność

Twoje dane pozostają przy Tobie. Notatki, podświetlenia, zakładki i historia czytania przechowywane są lokalnie na urządzeniu. Nie potrzebujesz konta, a nic nie jest wysyłane na serwer, chyba że sam zdecydujesz się użyć opcjonalnego Asystenta AI.

## Obsługa tabletów

Theodia zaprojektowano zarówno dla telefonów, jak i tabletów. Na większym ekranie masz więcej miejsca na czytanie, widoki równoległych Biblii oraz układ wykorzystujący dodatkową przestrzeń.

## Instalowalne zasoby

Nie jesteś ograniczony do tego, co dołączono do aplikacji. Możesz dodawać więcej wersji Biblii, komentarzy, leksykonów, ksiąg i rozważań. Zasoby dostępne są na stronie GitHub projektu i można je instalować bezpośrednio w aplikacji.

## Asystent AI

Opcjonalny Asystent AI pomaga rozumieć wersety, wyjaśniać kontekst i odpowiadać na pytania. Jest aktywny tylko wtedy, gdy go włączysz. Domyślnie łączy się ze zdalnym modelem, który sam skonfigurujesz — podajesz adres końcówki i klucz API. Przy pierwszym użyciu AI aplikacja prosi o zgodę i pokazuje dokładnie, co jest wysyłane.

## Czytanie Biblii równoleglej

Czytaj do czterech wersji Biblii jednocześnie. Gdy otworzysz rozdział, najpierw pojawia się Twój główny przekład, a każdy werset jest następnie powtarzany w wybranych przekładach równoległych. Porównuj brzmienie, studiuj różnice i zobacz pełniejszy obraz tekstu. Zapisuj ulubione kombinacje jako zestawy i szybko między nimi przełączaj.

## Wyszukiwanie pełnotekstowe

Przeszukuj dowolną wersję Biblii. Szukaj słów, fraz lub częściowych dopasowań. Możesz też ograniczyć wyszukiwanie do zakresu ksiąg.

## Odniesienia krzyżowe

Stuknij odwołanie do wersetu, aby przejść bezpośrednio do tego fragmentu. Odniesienia krzyżowe wbudowane są w całą Biblię.

## Leksykon i numery Stronga

Stuknij numer Stronga, aby zobaczyć definicję oryginalnego greckiego lub hebrajskiego słowa. Hasła leksykonów uwzględniono dla głębszego studium słów.

## Zakładki i podświetlenia

Zapisuj wersety zakładkami i zaznaczaj je kolorami. Wszystko przechowywane jest lokalnie i pozostaje między sesjami.

## Notatki

Zapisuj własne przemyślenia obok dowolnego wersetu. Notatki powiązane są z wersetem i łatwo je później odnaleźć.

## Codzienne rozważanie

Rozpocznij dzień od krótkiego czytania rozważania. Aplikacja zawiera rozważania, które automatycznie otwierają dzisiejszy wpis.

## Księgi chrześcijańskie

Czytaj klasyczną literaturę chrześcijańską wewnątrz aplikacji. Księgi sformatowano dla wygodnego czytania i zawierają spis treści dla szybkiej nawigacji.

## Wiele języków

Theodia obsługuje wiele języków zarówno dla interfejsu aplikacji, jak i treści biblijnych. Zmień język w ustawieniach, aby studiować w preferowanym języku.

## Ciemny motyw i motywy

Wybieraj między trybem jasnym i ciemnym lub wybierz motyw odpowiadający Twoim preferencjom. Komfort czytania ma znaczenie, zwłaszcza przy słabym oświetleniu.

## Kopia zapasowa danych

Twórz kopię zapasową notatek, zakładek i podświetleń. Zabezpiecz dane i przenieś je na nowe urządzenie, gdy zajdzie potrzeba.

## Brak reklam, brak rozpraszaczy

Theodia zbudowano dla skupienia. Nie ma reklam, wyskakujących okienek ani przerwań. Tylko tekst i Twoje narzędzia studialne.
