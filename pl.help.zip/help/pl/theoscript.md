---
title: Theoscript
level: everyday
categories: theoscript
summary: Automatyzuj czytanie Biblii, mowę, zakładki i nie tylko za pomocą prostych poleceń Theoscript.
---

# Theoscript

**Theoscript** to małe skrypty, które automatyzują działania w Theodii. Skrypt może przeczytać fragment na głos, otworzyć rozdział, ustawić zakładkę, pokazać komunikat, uruchomić inne polecenie i nie tylko. To szybki sposób na budowanie osobistych skrótów lub małych pomocników dewocyjnych bez opuszczania aplikacji.

## Gdzie mieszkają Theoscript

Otwórz **Theoscript** z ekranu głównego lub z menu głównego. Ekran pojawia się tylko wtedy, gdy istnieje co najmniej jeden skrypt.

Biblioteka pokazuje:

- **Skrypty** — każdy skrypt, który utworzyłeś lub zaimportowałeś.
- **Kategorie** — opcjonalne foldery grupujące powiązane skrypty.

Stuknij skrypt, aby go uruchomić. Przytrzymaj skrypt, aby edytować, duplikować lub usunąć.

## Tworzenie nowego skryptu

1. Przejdź do **Theoscript**.
2. Stuknij **Dodaj skrypt**.
3. Nadaj skryptowi nazwę.
4. Wpisz polecenia w polu **Treść skryptu**.
5. Stuknij **Zapisz**.

Każde polecenie w osobnym wierszu. Wiersze wewnątrz bloku wcińnij o dwie spacje.

## Popularne polecenia

| Polecenie              | Co robi                                | Przykład                                      |
| ---------------------- | -------------------------------------- | --------------------------------------------- |
| `speak`                | Czyta tekst lub fragment na głos       | `speak "Dzień dobry"` lub `speak John 3:16`   |
| `open`, `read`, `show` | Otwiera fragment w czytniku            | `open Psalm 23`                               |
| `bookmark`             | Zapisuje aktualny fragment do zakładek | `bookmark`                                    |
| `highlight`            | Podświetla aktualny werset             | `highlight yellow`                            |
| `message`              | Pokazuje wyskakujący komunikat         | `message "Czytanie skończone"`                |
| `set`                  | Zmienia ustawienie lub wartość         | `set theme dark`                              |
| `return`               | Kończy skrypt wcześniej                | `return`                                      |
| `with playlist`        | Dodaje utwory do playlisty             | `with playlist "Morning" track John 3:16 end` |
| `start playlist`       | Odtwarza playlistę                     | `start playlist "Morning"`                    |
| `with note`            | Tworzy notatkę                         | `with note "John 3:16" "My thoughts" end`     |

## Sterowanie przepływem

Użyj `if`, aby wykonać polecenia tylko wtedy, gdy warunek jest prawdziwy:

```text
if chapter == 1 {
  message "Zaczynamy nową księgę!"
}
```

Użyj `repeat`, aby powtórzyć blok poleceń:

```text
repeat 3 {
  speak "Pokój z tobą"
}
```

Użyj `for`, aby przejść przez listę:

```text
for $ref in ["John 3:16", "Psalm 23:1", "Romans 8:28"] {
  open $ref
  speak $ref
}
```

Użyj `function` i `call`, aby wielokrotnie wykorzystywać bloki kodu:

```text
function greet $name {
  message "Hello, " + $name
}
call greet "friend"
```

## Zmienne

Przechowuj wartość w zmiennej za pomocą `let`:

```text
let $name = "Theophilus"
message "Welcome, " + $name
```

Literały tekstowe po prawej stronie muszą być otoczone cudzysłowem prostym lub podwójnym. Zapobiega to pomyleniu wartości z poleceniem lub nazwą zmiennej. Liczby, zmienne i wyrażenia poleceń nie wymagają cudzysłowu:

```text
let $count = 42
let $text = $last.passageText
let $words = count words in $text
let $greeting = "Hello, " + $name
```

Zmienne przydają się w pętlach, funkcjach i definicjach playlist.

## Przykładowe skrypty

### Powitanie i werset

```text
speak "Dzień dobry. Oto Twój werset na dziś."
open John 3:16
speak John 3:16
```

### Zakładka trzech ulubionych wersetów

```text
open John 3:16
bookmark
open Psalm 23:1
bookmark
open Romans 8:28
bookmark
message "Ulubione zapisane."
```

### Zbuduj playlistę do słuchania

```text
with playlist "Dojazd" {
  track John 3:16
  track Psalm 23
  track Romans 8:28
}
start playlist "Dojazd"
```

### Warunkowy komunikat

```text
open Genesis 1:1
if book == "Genesis" {
  message "Na początku..."
}
```

## Organizowanie skryptów

Stuknij **Zarządzaj kategoriami**, aby utworzyć kategorie. Edytując skrypt, wybierz kategorię, do której ma należeć. Kategorie pomagają trzymać osobne skrypty, przykłady i skrypty mowy w porządku.

## Eksport i import

Stuknij menu wewnątrz biblioteki Theoscript, aby:

- **Eksportuj Theoscript** — zapisać wszystkie skrypty do pliku.
- **Eksportuj tę kategorię** — zapisać tylko wybraną kategorię.
- **Importuj Theoscript** — wczytać wcześniej wyeksportowany plik.

Wyeksportowane pliki to zwykły tekst, który można udostępniać innym użytkownikom Theodii.

## Uruchamianie skryptów z Poleceń

Theoscript można też uruchamiać po nazwie z **Szybkiego menu** lub pytając o nie przez Polecenia. Na przykład powiedzenie lub wpisanie `run My Morning Script` znajdzie i uruchomi skrypt o nazwie _My Morning Script_, jeśli istnieje.

## Rozwiązywanie problemów

- **Nic się nie dzieje, gdy stuknę Uruchom.** Sprawdź, czy treść skryptu nie jest pusta i czy każde polecenie jest poprawnie napisane.
- **Speak nic nie czyta.** Upewnij się, że fragment jest otwarty, lub przekaż tekst w cudzysłowie bezpośrednio do `speak`.
- **Polecenie podświetlone na czerwono.** Theoscript pokazuje błędy, gdy polecenie jest nieznane lub odwołanie nieprawidłowe. Edytuj skrypt i spróbuj ponownie.
