---
title: Czytanie na głos (TTS)
level: everyday
categories: tts
summary: Niech Theodia czyta Biblię lub rozważanie na głos. Jak tego używać, jak wybrać głos i co zrobić, gdy jest cisza.
---

# Czytanie na głos (TTS)

> **Tryb:** Czytanie na głos dostępne jest w trybach **Standardowy** i **Uczony**. Tryb Skupienie służy tylko czystemu, bezrozpraszającemu czytaniu. Przełączasz go w **Ustawienia** → **Tryb użytkownika**.

Theodia może czytać tekst na głos za pomocą głosu syntezy mowy (TTS) Twojego urządzenia. Możesz słuchać pojedynczego wersetu, całego rozdziału lub rozważania. Przydaje się to do czytania bez użycia rąk, słuchania podczas spaceru lub dojazdu, czytania wraz z głosem lub po prostu odpoczynku dla oczu.

## Gdzie jest przycisk słuchania

Przycisk słuchania znajdziesz w trzech miejscach.

### 1. W menu wersetu (pojedynczy werset)

To najszybszy sposób na słuchanie jednego wersetu na raz. Otwórz rozdział w trybie [Studium](theodia://help/study-mode), stuknij werset, aby otworzyć menu wersetu, potem stuknij **Czytaj** (🔊). Czytanie zaczyna się od tego wersetu. Na dole ekranu pojawia się mały pasek sterowania z odtwarzaniem, wstrzymaniem, przewijaniem wstecz, przewijaniem do przodu i wyborem głosu.

Opcja Czytaj nie jest pokazywana dla Biblii międzywierszowych (MIB — Marvel Interlinear Bible — i OHGB), ponieważ wyświetlają słowa w układzie, który nie czyta się naturalnie.

### 2. U góry rozdziału (cały rozdział)

Gdy czytasz rozdział, spójrz na rząd ikon u góry ekranu. Stuknij **Czytaj** (🔊), aby zacząć czytać cały rozdział od początku. Podczas odtwarzania przycisk zmienia się w przycisk zatrzymania (⏹). Stuknij ponownie, aby zatrzymać. Ten sam pasek sterowania pojawia się na dole.

Możesz przejść do innego wersetu, a przycisk Czytaj tam rozpocznie czytanie od tego wersetu.

### 3. W rozważaniu

Otwórz dowolny dzień rozważania, potem stuknij przycisk **Czytaj** (🔊) u góry czytania. Cały tekst rozważania czytany jest zdanie po zdaniu. Pasek sterowania na dole daje odtwarzanie, wstrzymanie, przewijanie i sterowanie głosem.

## Używanie paska sterowania

Podczas odtwarzania audio na dole ekranu widoczny jest mały pasek. Ma sześć elementów sterujących:

- ⏪ **Wstecz** — wróć o jeden werset (lub jedno zdanie w rozważaniu)
- ⏸ **Wstrzymaj / ▶ Wznów** — wstrzymaj bez utraty miejsca. Stuknij ponownie, aby kontynuować od tego samego miejsca.
- ⏩ **Do przodu** — przeskocz do następnego wersetu (lub następnego zdania w rozważaniu)
- 🎙 **Głos** — otwórz wybór głosu bez opuszczania rozdziału (patrz poniżej)
- ⚙ **Opcje** — otwórz rozszerzony panel opcji (patrz poniżej)
- **Zatrzymaj** — stuknij przycisk 🔊 u góry ekranu lub ⏹, który go zastępuje podczas odtwarzania, aby zatrzymać i zamknąć pasek.

Pasek zamyka się, gdy rozdział dobiegnie końca lub gdy stukniesz stop.

### Opcje rozszerzone

Stuknij ⚙, aby rozwinąć dodatkowe opcje odtwarzania. Ustawienia te obowiązują tylko dla aktualnego rozdziału i resetują się przy przejściu do innego rozdziału lub zatrzymaniu słuchania.

- ⏮ **Początek zakresu** — skocz do pierwszego wersetu ustawionego zakresu.
- **Początek** — wpisz numer wersetu, aby ustalić, gdzie czytanie ma się zacząć.
- **Koniec** — wpisz numer wersetu, aby ustalić, gdzie czytanie ma się skończyć.
- **Wszystko** — zresetuj zakres do całego rozdziału.
- **()** — przełączaj, czy tekst w nawiasach czytany jest na głos.
- 🔁 **Powtarzaj** — automatycznie zacznij od początku zakresu po dojściu do końca, z krótką pauzą między powtórzeniami. Jeśli włączysz to bez ustawiania początku ani końca, powtarzany będzie cały rozdział.

## Jak zmienić głos

Możesz wybrać głos, którym Theodia czyta. Przydaje się to, gdy chcesz inny akcent, inny język lub głos szybszy bądź wolniejszy niż domyślny urządzenia.

1. Otwórz **Ustawienia**.
2. Znajdź sekcję **Mowa**.
3. Stuknij **Wybierz głos**.
4. Pojawi się lista głosów. Pierwszy wiersz, **Domyślny głos systemowy**, używa głosu preferowanego przez urządzenie. Wybierz inny wiersz, aby ustawić go jako nowy domyślny.
5. Twój wybór jest zapisywany i używany przy następnym stuknięciu **Czytaj**.

Możesz też stuknąć ikonę 🎙 w pasku słuchania, aby otworzyć ten sam wybór bez opuszczania rozdziału.

Dostępność głosów zależy całkowicie od Twojego urządzenia. iOS i Android dostarczają zestaw wbudowanych głosów. Więcej głosów możesz zainstalować w ustawieniach systemowych urządzenia: **Dostępność** lub **Język i wprowadzanie**. Theodia może używać każdego głosu zainstalowanego na urządzeniu.

## Ulubione głosy

Jeśli na urządzeniu masz wiele głosów, przewijanie pełnej listy za każdym razem może być uciążliwe. Możesz stworzyć krótką listę **ulubionych głosów**, a wybory głosu będą pokazywać tylko te głosy.

1. Otwórz **Ustawienia**.
2. Znajdź sekcję **Mowa**.
3. Stuknij **Ulubione głosy** (pierwszy wiersz na górze sekcji).
4. Stuknij **Ustaw ulubione głosy**, aby otworzyć ekran ulubionych.
5. Stuknij przycisk odtwarzania obok głosu, aby go podglądnąć. Stuknij gwiazdkę, aby dodać do ulubionych. Możesz oznaczyć dowolną liczbę głosów.
6. Wróć. Wybory głosu w Theodii będą teraz pokazywać tylko Twoje ulubione głosy.

Jeśli usuniesz wszystkie ulubione, wybory wrócą do pokazywania wszystkich głosów. Ulubione głosy są uwzględniane przy tworzeniu kopii zapasowej i przywracaniu ustawień Theodii.

## Inny głos dla każdej Biblii

Możesz przypisać osobny głos każdemu przekładowi Biblii. Przydaje się to, gdy przełączasz się między przekładami czytającymi się bardzo inaczej — na przykład bardziej formalny głos dla King James Version i bardziej swobodny dla nowoczesnego przekładu, jak NIV czy NLT. Pomaga też, gdy słuchasz Biblii w różnych językach i chcesz, aby każda brzmiała właściwym akcentem.

1. Otwórz **Ustawienia**.
2. Znajdź sekcję **Mowa**.
3. Poszukaj **Głosy biblijne**.
4. Stuknij dowolną Biblię na liście.
5. Wybierz głos dla tego przekładu. Pierwszy wiersz, **Domyślny głos systemowy**, używa głównego głosu TTS dla tej Biblii.
6. Powtórz dla innych Biblii.

Nagłówek pokazuje, ile przekładów Biblii ma ustawiony własny głos. **Wybierz głos**, **Głos komentarza**, **Głos notatek biblijnych** i **Głos rozważania** również pokazują liczbę, gdy ustawiono głos.

Przy następnym słuchaniu rozdziału z danej Biblii Theodia użyje wybranego głosu. Pozostałe Biblie nadal używają głównego domyślnego głosu, chyba że też go zmienisz.

## Kontynuacja mowy w tle

Domyślnie Theodia zatrzymuje mowę, gdy opuszczasz ekran czytnika, przechodzisz do innej aplikacji lub blokujesz telefon. Zapobiega to nieoczekiwanemu dźwiękowi, gdy już nie czytasz aktywnie.

Aby pozwolić mowie grać w tle:

1. Otwórz **Ustawienia**.
2. Znajdź sekcję **Mowa**.
3. Włącz **Kontynuuj mowę w tle**.

Gdy to włączone, możesz przełączać zakładki, otworzyć inną aplikację lub zablokować ekran, a rozdział lub rozważanie będzie czytane dalej. Pasek sterowania pozostaje aktywny, więc możesz wstrzymać lub przeskoczyć z obszaru powiadomień (jeśli urządzenie to obsługuje).

Wyłączenie tego przełącznika **podczas odtwarzania** natychmiast zatrzyma mowę.

## Co zrobić, gdy nie działa

Czytanie na głos zależy od urządzenia. Theodia przesyła tekst do systemu operacyjnego, a ten odczytuje go na głos za pomocą głosu. Jeśli nie działa, spróbuj tych kroków w kolejności.

### Theodia mówi, że TTS jest niedostępne

Niektóre urządzenia i wersja webowa w ogóle nie mają TTS. Otwórz **Ustawienia** i poszukaj sekcji **TTS**. Jeśli jej nie ma, Twoje urządzenie nie obsługuje TTS w tej wersji.

### Lista głosów jest pusta

Wybór głosu może pokazywać „nie znaleziono głosów”. Zazwyczaj oznacza to, że urządzenie jeszcze nie załadowało głosów.

1. Otwórz **Ustawienia → Mowa → Wybierz głos**.
2. Jeśli lista jest pusta, poszukaj przycisku **Sprawdź ponownie** tuż pod rozwijaną listą. Stuknij go. Theodia ponownie odpyta urządzenie o głosy.
3. Jeśli wciąż pusto, sprawdź ustawienia systemowe urządzenia. Na iOS: **Ustawienia → Dostępność → Treść mówiona → Głosy** i pobierz głos dla swojego języka. Na Androidzie: **Ustawienia → Język i wprowadzanie → Wyjście tekstu na mowę** i stuknij **Zainstaluj dane głosu**.
4. Zamknij i ponownie otwórz Theodię, aby nowy głos został wykryty.

Jeśli ustawiłeś ulubione głosy i lista jest pusta, upewnij się, że przynajmniej jeden z ulubionych pasuje do głosu zainstalowanego na tym urządzeniu.

### Stuknę Czytaj, ale nic się nie dzieje

- Sprawdź, czy urządzenie nie jest w trybie cichym. Większość urządzeń nie odtwarza dźwięku TTS w trybie cichym.
- Upewnij się, że głośność urządzenia jest włączona.
- Spróbuj przycisku **Sprawdź ponownie** w **Ustawienia → Mowa**.
- Otwórz **Ustawienia** i spójrz na sekcję **System** na dole. Wiersz **TTS** powinien pokazywać **Dostępne**. Jeśli pokazuje **Niedostępne**, TTS jest wyłączone na poziomie systemu operacyjnego. Włącz je tam, potem ponownie otwórz Theodię.

### Dźwięk gra, ale w złym języku

Theodia przesyła tekst w języku aktualnej treści i prosi urządzenie o wybrany głos. Jeśli wybrany głos jest dla innego języka, urządzenie może nadal przeczytać tekst, ale będzie to brzmieć dziwnie.

1. Otwórz **Ustawienia → Mowa → Wybierz głos**.
2. Wybierz **Domyślny głos systemowy**, aby urządzenie samo dobrało odpowiedni głos, lub wybierz głos w języku tekstu, który czytasz.

Theodia obecnie nie czyta na głos Biblii międzywierszowych po grecku ani hebrajsku. Przyciski Czytaj są na tych przekładach ukryte.

### Dźwięk gra, ale przerywa

Jeśli werset brakuje lub jest nieczytelny, rozdział przeskakuje do następnego. Jeśli pasek sam się zamyka po kilku wersetach, stuknij przycisk **Czytaj** (🔊) u góry ekranu, aby zacząć od nowa.

### Mowa gra, ale nie wiem, skąd się zaczęła

Jeśli włączyłeś **Kontynuuj mowę w tle** i później słyszysz dźwięk, ale nie możesz znaleźć ekranu, który go uruchomił, możesz zatrzymać mowę z dowolnego miejsca w aplikacji.

1. Otwórz **Ustawienia**.
2. Znajdź sekcję **Mowa**.
3. Stuknij czerwony przycisk **Zatrzymaj mowę** na dole sekcji.

To natychmiast zatrzymuje każdą uruchomioną syntezę mowy w Theodii. Możesz też otworzyć przełącznik aplikacji na urządzeniu i przesunąć Theodię, aby wymusić zatrzymanie dźwięku.

### Czyta za szybko lub za wolno

Theodia nie kontroluje szybkości czytania. Szybkość ustawia wybrany głos. Aby ją zmienić:

- Na iOS: **Ustawienia → Dostępność → Treść mówiona → Tempo mowy**.
- Na Androidzie: **Ustawienia → Język i wprowadzanie → Wyjście tekstu na mowę → Tempo mowy**.

## Wskazówki

- Pasek sterowania pozostaje widoczny podczas nawigacji między rozdziałami, więc możesz wstrzymać, przeskoczyć lub zmienić głos bez utraty miejsca.
- Theodia czyta numery wersetów jako krótkie pauzy. Możesz zatrzymać pasek, przesunąć się do innego wersetu, potem stuknąć odtwarzanie, aby kontynuować od tamtego miejsca.
- Na długie sesje słuchania włącz **Nie przeszkadzać**, aby powiadomienia nie przerywały dźwięku.
- Przycisk 🔊 używa aktualnej głośności urządzenia. Jeśli podłączysz słuchawki, głośność przełączy się na poziom słuchawkowy.

## Powiązane przewodniki

- Przewodnik [Tryb Studium](theodia://help/study-mode) szczegółowo opisuje menu wersetu i przyciski u góry ekranu.
- Przewodnik [Tryb Skupienie](theodia://help/focus-mode) opisuje czystszy widok czytania, który również obsługuje TTS przez przycisk 🔊 na dolnym pasku.
- Przewodnik [Typowe problemy](theodia://help/common-problems) zawiera rozwiązania innych problemów z dźwiękiem, głosem i językiem.
- Przewodnik [Codzienne rozważania](theodia://help/daily-devotionals) opisuje czytanie rozważań i przycisk słuchania na tym ekranie.
