---
title: Witamy w Theodii
level: beginner
categories: welcome
summary: Krótkie oprowadzenie po aplikacji i tym, co może dla Ciebie zrobić.
---

# Witamy w Theodii

Theodia to aplikacja do studiowania Biblii. Działa na telefonie lub tablecie, nawet bez internetu. Wszystko, co czytasz, szukasz i studiujesz, zapisywane jest na Twoim urządzeniu.

## Co możesz robić

Theodia ma trzy tryby użytkownika. Każdy tryb pokazuje inny zestaw funkcji.

- **Czytanie** — czytaj Biblię w czystym, bezrozpraszającym widoku.
- **Standardowy** — wszystko z trybu Czytanie plus zakładki, podświetlenia, notatki, czytanie na głos, wyszukiwanie i codzienne rozważania.
- **Uczony** — wszystko z trybu Standardowy plus komentarze, leksykony, słownik biblijny, Asystent AI i nie tylko.

Tryb możesz zmienić w dowolnej chwili w **Ustawienia** → **Tryb użytkownika**.

### Funkcje zawsze dostępne

Niezależnie od wybranego trybu zawsze możesz:

- **Czytać Biblię.** Wybierz spośród wielu przekładów. Przełączaj się między nimi w dowolnej chwili.
- **Szukać w Biblii.** Szukaj słowa lub frazy. Aplikacja pokaże każdy pasujący werset.
- **Czytać księgi i rozważania.** Aplikacja zawiera klasyki chrześcijańskie i codzienne rozważanie.

W zależności od trybu możesz też:

- **Słuchać.** Niech wersety czytają na głos dzięki funkcji czytania na głos. (Standardowy i Uczony.)
- **Robić notatki.** Zapisuj własne przemyślenia obok wersetu. (Standardowy i Uczony.)
- **Podświetlać.** Zaznacz ulubione wersety kolorem. (Standardowy i Uczony.)
- **Dodawać zakładki.** Zapisuj wersety, aby szybko je odnaleźć. (Standardowy i Uczony.)
- **Pytać Asystenta AI.** Poproś o pomoc w zrozumieniu wersetu. (Tylko Uczony.)

## Od czego zacząć

1. Otwórz zakładkę **Biblie** na dolnym pasku ekranu.
2. Wybierz przekład.
3. Stuknij dowolną księgę, aby zacząć czytać.

Jeśli chcesz dowiedzieć się więcej, pozostałe przewodniki pomocy są dla Ciebie. Wybierz temat z listy na stronie głównej pomocy.

## Kilka rzeczy warte wiedzy

- Nie potrzebujesz konta.
- Twoje notatki, podświetlenia i zakładki pozostają na urządzeniu.
- Możesz je skopiować. Jak to zrobić, opisuje przewodnik [Kopia zapasowa danych](theodia://help/backups).

## Chcesz więcej zasobów?

Aplikacja zawiera kilka dostępnych swobodnie wersji Biblii. Dodatkowe Biblie, komentarze, leksykony, księgi i rozważania znajdziesz w przewodniku [Pobieranie dodatkowych zasobów z GitHuba](theodia://help/getting-core-files). Pokazuje on, jak znaleźć i dodać więcej zasobów ze strony GitHub projektu.

Witamy. Mamy nadzieję, że Theodia pomoże Ci czytać i studiować.
