---
title: Czym są zasoby?
level: beginner
categories: resources
summary: Przegląd różnych rodzajów plików używanych przez Theodię — Biblie, komentarze, księgi i nie tylko.
---

# Czym są zasoby?

W Theodii „zasób” to dowolny plik, który dodaje materiał do czytania lub studiowania w aplikacji. Sama aplikacja to tylko czytnik i notatnik. Biblie, komentarze, księgi i inne materiały, z którymi studiujesz, to osobne pliki, które do niej wczytujesz.

Ten przewodnik wyjaśnia różne rodzaje zasobów i do czego służą.

## Dlaczego to ma znaczenie?

Gdy pierwszy raz otworzysz Theodię, znajdziesz tam już kilka rzeczy do przeczytania. Podczas eksploracji zobaczysz przyciski do instalowania kolejnych. Znajomość rodzajów zasobów pomoże Ci zdecydować, co dodać.

## Różne rodzaje zasobów

Theodia rozpoznaje pliki po rozszerzeniu. Każde rozszerzenie to inny rodzaj zasobu.

### `.bible` — przekład Biblii

Przekład Biblii to pełna kopia Biblii w konkretnej wersji, jak King James Version. Theodia zawiera kilka przekładów i pozwala dodawać więcej.

Szczegóły znajdziesz w przewodniku [Instalowanie przekładów Biblii](theodia://help/installing-bibles).

### `.commentary` — komentarz

Komentarz to księga notatek studialnych napisanych przez biblistę. Dla danego wersetu komentarz podaje kontekst, znaczenie i to, jak werset wpisuje się w resztę Biblii.

Szczegóły znajdziesz w przewodniku [Komentarze i leksykony](theodia://help/commentaries-and-lexicons).

### `.lexicon` — leksykon

Leksykon to słownik słów biblijnych. Podaje oryginalne hebrajskie lub greckie słowo, jego znaczenie i użycie w Biblii.

Szczegóły znajdziesz w przewodniku [Komentarze i leksykony](theodia://help/commentaries-and-lexicons).

### `.book` — księga chrześcijańska

Księga to dłuższe dzieło chrześcijańskie, jak klasyk z historii Kościoła. Czytanie ksiąg w aplikacji działa podobnie do czytania Biblii. Theodia zawiera małą bibliotekę swobodnie dostępnych klasyków chrześcijańskich.

Szczegóły znajdziesz w przewodniku [Czytanie wbudowanych ksiąg](theodia://help/reading-books).

### `.devotional` — rozważanie

Rozważanie to krótkie codzienne czytanie. Każdy wpis zazwyczaj zawiera werset, krótką refleksję oraz modlitwę lub pytanie do przemyślenia. Wiele rozważań projektowano tak, by czytać jeden wpis dziennie przez rok.

Szczegóły znajdziesz w przewodniku [Codzienne rozważania](theodia://help/daily-devotionals).

### `.sqlite` — baza odniesień

Baza odniesień to duży plik pomocniczy, który aplikacja wykorzystuje, aby dostarczyć dodatkowe informacje podczas czytania. Są dwa rodzaje:

- **Odniesienia krzyżowe** — listy wersetów powiązanych z wersetem, który czytasz.
- **Morfologia** — informacje o oryginalnych hebrajskich lub greckich słowach w wersecie.

Nie otwierasz ich bezpośrednio. Działają w tle i dodają funkcje do czytnika Biblii. Szczegóły znajdziesz w przewodniku [Odniesienia krzyżowe](theodia://help/cross-references).

### `.data` — dane słów

Plik danych słów przechowuje dodatkowe informacje o oryginalnych słowach biblijnych. Używany jest przez leksykon i narzędzia studialne. Podobnie jak bazy odniesień, nie otwierasz go bezpośrednio. Aplikacja wykorzystuje go w tle.

## Jak dodać zasób

Najłatwiejszy sposób to ekran **Zarządzaj zasobami**.

1. Otwórz **Ustawienia**.
2. Stuknij **Zarządzaj zasobami**.
3. Stuknij **Zainstaluj z GitHuba**.
4. W oknie pobierania wybierz zakładkę — **Biblie**, **Komentarze**, **Księgi**, **Rozważania** lub **Rdzeń** — a następnie wybierz to, czego potrzebujesz, i stuknij **Zainstaluj wybrane**.
5. Lub stuknij **Importuj z pliku**, aby zaimportować plik, który już pobrałeś.

Instrukcję krok po kroku dotyczącą pobierania plików bezpośrednio z GitHuba znajdziesz w przewodniku [Pobieranie dodatkowych zasobów z GitHuba](theodia://help/getting-core-files).

## Jak usunąć zasób

1. Otwórz **Ustawienia**.
2. Stuknij **Zarządzaj zasobami**.
3. Znajdź zasób, który chcesz usunąć.
4. Stuknij ikonę kosza obok niego.
5. Potwierdź usunięcie.

Usunięcie zasobu nie usuwa Twoich notatek, podświetleń ani zakładek. Pozostają bezpieczne.

## Gdzie zasoby znajdują się na urządzeniu

Zasoby przechowywane są na urządzeniu, a nie w chmurze. Po zainstalowaniu zasobu nie potrzebujesz internetu, aby go czytać. Możesz tworzyć kopię zapasową urządzenia, ale same zasoby nie są przez Theodię zapisywane w chmurze. Jeśli odinstalujesz i ponownie zainstalujesz aplikację, będziesz musiał dodać zainstalowane wcześniej zasoby od nowa.

## Pomoc i pytania

Jeśli masz trudności, zobacz przewodnik [Gdzie zadawać pytania](theodia://help/getting-more-help). Zespół i społeczność chętnie pomogą.
