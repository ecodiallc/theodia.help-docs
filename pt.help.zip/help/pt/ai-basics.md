---
title: IA Básica
level: advanced
categories: ai
summary: Como usar o assistente de IA para entender versículos.
---

# IA Básica

> **Modo:** O assistente de IA exige o modo **Estudioso**. Você pode trocar de modo em **Configurações** → **Modo de Usuário do Aplicativo**.

O Theodia tem um assistente de IA. Ele pode ajudá-lo a entender um versículo, responder a uma pergunta ou conversar sobre um tópico bíblico.

## Como ligar a IA

A IA está desligada por padrão. Para ligar:

1. Abra **Configurações**.
2. Toque em **Assistente de IA**.
3. Toque no botão para ativar.

Talvez seja necessário configurar uma conta ou uma chave. O aplicativo o guiará.

## Como abrir a IA

Toque na aba **IA** na parte inferior da tela. Uma janela de chat se abre.

## Como fazer uma pergunta

Toque na caixa na parte inferior. Digite sua pergunta. Toque em **Enviar**.

Algumas coisas que você pode perguntar:

- "O que João 3:16 significa?"
- "Fale-me sobre o livro de Romanos."
- "O que é o fruto do Espírito?"
- "Compare o Sermão do Monte em Mateus e Lucas."

## Como perguntar sobre um versículo específico

1. Abra um capítulo.
2. Toque em um versículo para abrir o menu do versículo.
3. Toque em **Comentário de IA**.

O versículo é enviado para a IA. O painel de IA se abre com o versículo pré-preenchido. Você pode adicionar uma pergunta, como "O que isso significa?" ou "Como devo aplicar isso?"

## Coisas importantes para saber

- A IA é uma ferramenta, não uma pessoa. Ela pode cometer erros.
- Sempre verifique as respostas da IA na própria Bíblia.
- A IA pode precisar de internet. Não funciona offline.
- Quando você usa a IA, suas perguntas, contexto do versículo e chave de API são enviados ao endpoint que você escolhe. Na primeira vez, o aplicativo pede permissão e mostra exatamente o que é enviado. Você pode alterar ou revogar essa permissão depois em **Configurações → Assistente de IA → Compartilhamento de Dados de IA Remota**.
- Algumas regiões, como a build da App Store para a China continental, não oferecem o assistente de IA. Nessa build, apenas recursos offline da Bíblia estão disponíveis.

## Como gerenciar conversas

A tela de IA mantém uma lista de conversas passadas. Na lista você pode abrir uma conversa antiga, começar uma nova ou excluir uma que não precisa mais.

## Aprofunde-se com IA

Esta página cobre o básico. A IA do Theodia pode fazer muito mais do que conversar. Aqui está para onde ir a seguir:

- **[Recursos de IA](theodia://help/ai-features)** — Descubra tudo o que Teófilo pode fazer: estudo de versículo em grego e hebraico com um toque, cadeias de referências cruzadas, esboços de sermão, geração de oração, morfologia do idioma original, consultas de dicionário e navegação no aplicativo sem as mãos. Este é o guia que mostra como transformar a IA de um chatbot em um parceiro completo de estudo.
- **[Escrevendo Melhores Prompts de IA](theodia://help/ai-prompts)** — Aprenda a arte de fazer perguntas que geram respostas ricas e precisas. Alguns ajustes na forma de formular seu pedido podem desbloquear respostas drasticamente mais profundas da IA.
- **[Escolhendo um Modelo de IA](theodia://help/choosing-a-model)** — Nem todos os modelos de IA são iguais. Descubra quais modelos suportam as ferramentas integradas do Theodia (como abrir versículos e pesquisar na Escritura) e quais tornam a IA um verdadeiro assistente de estudo bíblico sem as mãos.
- **[GitHub Models](theodia://help/github-models)** — O provedor gratuito recomendado. Obtenha uma chave de API gratuita com uma conta do GitHub e comece a fazer perguntas em um generoso limite diário. Sem cartão de crédito, sem assinatura.
- **[Chaves de API e Custos](theodia://help/ai-keys-and-costs)** — Entenda como funciona a precificação de API entre provedores e como manter os custos próximos de zero.
