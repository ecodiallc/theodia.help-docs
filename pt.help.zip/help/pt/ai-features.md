---
title: Recursos de IA
level: advanced
categories: ai
summary: Descubra tudo o que a IA do Theodia pode fazer — de estudo versículo por versículo a preparação de sermão, exploração do idioma original e navegação sem as mãos.
---

# Recursos de IA

> **Modo:** O assistente de IA exige o modo **Estudioso**. Você pode trocar de modo em **Configurações** → **Modo de Usuário do Aplicativo**.

O assistente de IA do Theodia, Teófilo, não é apenas um chatbot. É um parceiro de estudo que pode ler a Bíblia junto com você, consultar comentários, pesquisar na Escritura, gerenciar suas notas e até navegar no aplicativo — tudo por voz ou texto.

Antes de Teófilo enviar dados a um endpoint de IA pela primeira vez, o aplicativo mostra um prompt de consentimento explicando o que é enviado e pedindo permissão. Você pode alterar ou revogar essa permissão a qualquer momento em **Configurações → Assistente de IA → Compartilhamento de Dados de IA Remota**.

## Chat de Versículo com IA: Estude um Versículo a Fundo

O **Chat de Versículo com IA** é o coração da experiência de IA do Theodia. Enquanto você lê qualquer capítulo, toque no número do versículo (ou pressione longamente o texto do versículo) e escolha **Comentário de IA**. Um painel de chat se abre com aquele versículo já carregado. A IA sabe exatamente o que você está lendo e está pronta para explorá-lo com você.

### Iniciadores de um toque

Não sabe o que perguntar? O painel mostra oito iniciadores instantâneos:

- **Explique este versículo** — Obtenha uma explicação clara e cuidadosa do significado e da importância.
- **Idioma original** — Veja as palavras em grego ou hebraico, transliterações e definições léxicas por trás do texto em inglês.
- **Contexto histórico** — Aprenda sobre a cultura, política e eventos ao redor do versículo.
- **Contexto textual** — Veja como o versículo se encaixa no parágrafo, capítulo e livro ao redor.
- **Temas principais** — Descubra as grandes ideias que este versículo contribui para a teologia bíblica.
- **Aplicar à minha vida** — Obtenha aplicações práticas e pessoais que você pode colocar em prática hoje.
- **Gerar uma oração** — Transforme o versículo em uma oração modelada em sua linguagem e verdades.
- **Gerar esboço de sermão** — Obtenha um esboço de três pontos com introdução e conclusão, pronto para pregar.

Toque em qualquer iniciador e a IA começa imediatamente. Você pode fazer perguntas de acompanhamento, pedir esclarecimentos ou direcionar a conversa para outro rumo.

### Acompanhamento como uma conversa real

A IA lembra as últimas mensagens do chat, então você pode aprofundar naturalmente:

- "Você pode dizer isso de forma mais simples?"
- "O que diz o grego original aqui?"
- "Mostre referências cruzadas que se conectam a isso."
- "Compare este versículo em três traduções diferentes."
- "Como isso se pareceria em um ambiente de trabalho moderno?"
- "Me dê mais três aplicações para um pai."

A conversa permanece ligada ao versículo, então cada resposta é fundamentada no texto que você está lendo.

### Toque em qualquer referência bíblica

Quando a IA menciona outro versículo — por exemplo, "Isso espelha Romanos 8:28" — a referência aparece como um **link tocável**. Toque nela e o aplicativo salta para aquela passagem no leitor da Bíblia. Você pode explorar a cadeia de referências sem nunca sair da conversa.

## O Que a IA Pode Fazer Além do Chat de Versículo

Teófilo tem acesso a todo o conteúdo do Theodia — Bíblias, comentários, léxicos, dicionários, livros, devocionais, suas notas, favoritos e destaques. Veja o que isso significa na prática.

### Ler e navegar na Escritura

- **Leia qualquer versículo ou capítulo** — "Leia João 3:16 na WEB" ou "Leia o Salmo 23 em voz alta."
- **Abra passagens no leitor** — "Leve-me a Gênesis 1" ou "Abra Romanos 8:28."
- **Compare versões** — "Mostre-me João 3:16 em todas as minhas Bíblias."
- **Pesquise a Bíblia** — "Encontre versículos sobre perdão" ou "Pesquise por 'paz que excede todo entendimento.'"
- **Obtenha referências cruzadas** — "Quais outros versículos se relacionam com Isaías 53:5?"
- **Leia títulos de seção** — "Quais são os subtítulos de Mateus 5?"

### Explorar idiomas originais

- **Consultas de léxico** — "O que significa a palavra grega 'agape' em João 3:16?" ou "Consulte Strong G26."
- **Morfologia** — "Analise os verbos gregos em Romanos 8:28" ou "O que significa o código de morfologia V-PAI-3S?"
- **Informação da Palavra** — A IA pode ver a mesma análise palavra por palavra que você vê no aplicativo — transliteração, glossa, gramática e números de Strong.

### Ler comentários e livros de estudo

- **Comentário de versículo** — "O que Matthew Henry diz sobre Efésios 2:8?"
- **Comentário de capítulo** — "Me dê a visão geral do capítulo de Romanos 8."
- **Comentário de livro** — "Resuma o comentário de nível de livro de Apocalipse."
- **Livros de estudo** — "Leia um capítulo de Hymn Lyrics English" ou "Pesquise meus livros por 'paciência.'"
- **Devocionais** — "Leia o devocional de hoje" ou "Encontre um devocional sobre ansiedade."

### Pesquisar dicionários

- "Quem foi Melquisedeque?"
- "O que o dicionário bíblico diz sobre Gilgal?"
- "Consulte 'propitiation' no Easton's."

### Gerenciar sua vida de estudo

A IA pode agir sobre seus dados pessoais — sempre armazenados localmente no dispositivo:

- **Favoritos** — "Salve este versículo na minha pasta Preparação de Sermão" ou "Liste meus favoritos."
- **Destaques** — "Destaque João 3:16 em amarelo" ou "Mostre todos os meus destaques."
- **Notas** — "Crie uma nota bíblica neste versículo" ou "Leia minhas notas de Gênesis 1."
- **Notas de estudo** — "Salve esta conversa como nota de estudo" ou "Crie um novo caderno de notas chamado Estudo de Romanos."
- **Pastas** — "Crie uma pasta chamada Devocional da Manhã" ou "Mova meu favorito de João 3:16 para a pasta Oração."

### Alterar configurações do aplicativo

- "Mude para o modo escuro."
- "Faça da BSB minha Bíblia padrão."
- "Ative Bíblias paralelas com a NET."
- "Aumente o tamanho da fonte."

### Ler em voz alta

- "Leia o Salmo 23 em voz alta" — A IA pode acionar a leitura em voz alta para qualquer passagem, livro ou nota.
- "Pare de ler" — Pausa a TTS a qualquer momento.

## Salvar Suas Conversas

Todo chat de versículo com IA pode ser salvo. Toque no menu no painel de chat e escolha:

- **Salvar como Nota Bíblica** — Anexa a conversa completa à nota do versículo no leitor da Bíblia.
- **Salvar como Nota de Estudo** — Armazena a conversa em seu livro de Notas de Estudo para referência posterior.

Isso transforma uma rápida exploração de IA em material de estudo permanente que você pode revisitar, editar ou construir sermões.

## A Aba Completa de IA

Além do painel de chat de versículo, o Theodia tem uma aba dedicada **IA** na navegação inferior. É um chat livre onde você pode perguntar qualquer coisa — nenhum versículo pré-selecionado. Use para:

- Estudos temáticos por toda a Bíblia
- Pesquisa e esboço de sermões
- Comparação de temas teológicos entre livros
- Devocionais diários e prompts de oração
- Curiosidades bíblicas e planos de leitura
- Ajuda do aplicativo — "Como funcionam as Bíblias paralelas?"

Suas conversas são salvas automaticamente. Você pode retornar a chats anteriores, começar novos e excluir conversas antigas.

## Ideias para Começar

Aqui estão algumas formas interessantes de usar a IA. Escolha uma e experimente hoje.

**Crescimento Pessoal**

- "Explique Filipenses 4:6–7 e me dê uma oração para quando eu estiver ansioso."
- "O que a Bíblia diz sobre descanso? Me encontre cinco versículos e explique cada um."

**Família e Paternidade**

- "Como Efésios 6:4 deve guiar a paternidade moderna? Me dê três regras práticas."
- "Encontre versículos sobre criar filhos e leia-os em voz alta para mim."

**Preparação de Sermão e Ensino**

- "Esboce um sermão de 25 minutos sobre Romanos 8:28 com introdução, três pontos e conclusão."
- "O que meus comentários dizem sobre a 'armadura de Deus' em Efésios 6?"
- "Compare o Sermão do Monte em Mateus com a versão de Lucas. Quais são as diferenças?"

**Estudo do Idioma Original**

- "Mostre a morfologia de cada palavra em João 1:1."
- "Qual é a diferença entre 'agape' e 'philia' no Novo Testamento?"

**Profundidade Devocional**

- "Leia o devocional de hoje e conecte-o a um versículo dos Salmos."
- "Me dê um esboço de devocional de sete dias sobre o fruto do Espírito."

**Cadeias de Referências Cruzadas**

- "Comece com Isaías 53:5 e trace o tema de 'feridas' e 'cura' pelo Novo Testamento."
- "Onde o conceito de 'aliança' aparece de Gênesis a Hebreus?"

**Memorização e Revisão**

- "Me faça um quiz sobre os livros da Bíblia em ordem."
- "Crie uma nota de estudo resumindo o ponto principal de cada capítulo de Romanos."

## Algumas Notas Importantes

- A IA é uma **ferramenta**, não um substituto para a Bíblia ou orientação pastoral. Sempre compare suas respostas à própria Escritura.
- Quando você usa a IA, suas perguntas viajam pela internet para os servidores do provedor. A maioria dos provedores não treina com seus dados, mas o texto deixa seu dispositivo.
- A IA pode cometer erros. Use comentários, léxicos e o próprio texto bíblico como autoridade final.

## Resumo

A IA do Theodia é projetada para tornar o estudo bíblico mais rápido, profundo e pessoal. Seja uma explicação de uma frase sobre um versículo confuso, um esboço completo de sermão, um estudo de palavra em grego ou uma cadeia de referências cruzadas que abrange toda a Bíblia, Teófilo está pronto para ajudar. Toque em um versículo, faça uma pergunta e veja onde a conversa o leva.
