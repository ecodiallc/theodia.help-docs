---
title: Chaves de API e Custos
level: advanced
categories: ai
summary: Por que você precisa de uma chave de API, como obtê-la e quanto custa tipicamente usar um modelo de IA remoto.
---

# Chaves de API e Custos

> **Modo:** O assistente de IA exige o modo **Estudioso**. Você pode trocar de modo em **Configurações** → **Modo de Usuário do Aplicativo**.

O assistente de IA se conecta a modelos de IA remotos. Se quiser usar um, você precisa de uma chave de API. Esta página explica por quê, como obtê-la e quanto isso costuma.

## Por que você precisa de uma chave de API

Um modelo de IA remoto reside em um servidor na internet. A chave de API é como uma senha que diz ao servidor: "Esta pessoa tem permissão para fazer perguntas." Sem ela, o servidor não responde.

O aplicativo não fornece uma chave integrada. Você deve criar sua própria conta com um provedor e colar sua chave no aplicativo.

## Como obter uma chave de API

1. Abra **Configurações** no Theodia.
2. Toque em **Assistente de IA**.
3. Escolha **Modelo remoto**.
4. Escolha um provedor na lista, ou **Personalizado** e insira uma URL base.
5. Toque no link para a página de chaves do provedor. Crie uma conta se não tiver uma.
6. Gere uma nova chave de API no site do provedor.
7. Copie a chave e cole-a no Theodia.
8. Toque em **Testar conexão** para confirmar que funciona.

## Provedores suportados

O Theodia pode se conectar a qualquer provedor que use uma API compatível com OpenAI. Aqui estão os que têm links pré-configurados no aplicativo:

- **GitHub Models** — github.com/marketplace/models (limite diário gratuito, recomendado)
- **OpenAI** — platform.openai.com
- **OpenRouter** — openrouter.ai
- **Anthropic** — console.anthropic.com
- **Groq** — console.groq.com
- **Mistral** — console.mistral.ai
- **Together AI** — api.together.xyz

Você também pode usar uma URL base **Personalizada** se executar seu próprio servidor ou usar outro serviço.

## Quanto custa?

A maioria dos provedores cobra por **token**. Um token é aproximadamente uma palavra ou parte de uma palavra. Você paga pelos tokens que envia (sua pergunta) mais os tokens que a IA devolve (a resposta).

### Preços típicos

Os preços mudam, mas aqui vai uma ideia aproximada em meados de 2026:

- **Modelos pequenos e rápidos** (como endpoints mais baratos da classe GPT-3.5) custam uma fração de centavo por mil tokens.
- **Modelos intermediários** (como GPT-4o ou Claude Sonnet) tipicamente custam alguns centavos por mil tokens.
- **Modelos grandes de raciocínio** (como GPT-4.5 ou Claude Opus) podem custar de dez a vinte centavos por mil tokens.

Uma pergunta típica sobre a Bíblia no Theodia pode usar de algumas centenas a alguns milhares de tokens no total. Isso significa que a maioria das perguntas custa de **menos de um centavo a alguns centavos**.

### Dicas para manter os custos baixos

- Comece com um modelo mais barato. A maioria das perguntas sobre a Bíblia não precisa do modelo mais caro.
- Use Groq ou OpenRouter se quiser experimentar diferentes modelos e comparar preços.
- Acompanhe seu painel de uso no site do provedor.

## GitHub Models

[GitHub Models](https://github.com/marketplace/models) oferece um nível gratuito sem assinatura necessária. Tudo o que você precisa é de uma conta gratuita do GitHub e de um token de acesso pessoal com permissão para ler modelos.

**Como configurar:**

1. Vá para [github.com/settings/tokens](https://github.com/settings/tokens) e crie um **Personal access token (classic)**.
2. Dê a ele o escopo `models:read` (ou apenas selecione a permissão de modelos).
3. No Theodia, escolha **GitHub Models** como provedor e cole seu token.

**Modelos do nível gratuito:**

- `openai/gpt-4.1-nano` — **15 requisições por minuto, 150 requisições por dia**
- `openai/gpt-4.1-mini` — **15 requisições por minuto, 150 requisições por dia**
- `openai/gpt-4.1` — **10 requisições por minuto, 50 requisições por dia**
- `openai/gpt-4o` — **10 requisições por minuto, 50 requisições por dia**

Esses limites reiniciam diariamente e são suficientes para estudo bíblico regular.

Para um guia passo a passo completo com capturas de tela, veja o guia dedicado [GitHub Models](theodia://help/github-models).

## Nota de privacidade

Quando você usa um modelo de IA remoto, o aplicativo primeiro mostra um prompt de consentimento explicando o que é enviado: suas mensagens, contexto do versículo ou capítulo, chamadas de ferramentas e resultados, nome do modelo configurado e sua chave de API no cabeçalho da requisição. A requisição vai diretamente ao endpoint que você configurou, não passa pelo Theodia. A maioria dos provedores não usa seus dados para treinar seus modelos, mas o texto deixa seu dispositivo. Você pode alterar ou revogar a permissão a qualquer momento em **Configurações → Assistente de IA → Compartilhamento de Dados de IA Remota**.

## Resumo

- Você precisa de uma chave de API para usar o assistente de IA.
- Crie uma conta com um provedor, gere uma chave e cole-a no Theodia.
- A maioria das perguntas custa alguns centavos ou menos.
