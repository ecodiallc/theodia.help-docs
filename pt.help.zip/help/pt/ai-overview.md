---
title: O Assistente de IA
level: advanced
category: ai
summary: Como usar o assistente de IA para entender versículos.
---

# O Assistente de IA

O Theodia tem um assistente de IA. Ele pode ajudá-lo a entender um versículo, responder a uma pergunta ou conversar sobre um tópico bíblico.

## Como ligar a IA

A IA está desligada por padrão. Para ligar:

1. Abra **Configurações**.
2. Toque em **Assistente de IA**.
3. Toque no botão para ativar.

Talvez seja necessário configurar uma conta ou uma chave. O aplicativo o guiará.

## Como abrir a IA

Toque na aba **IA** na parte inferior da tela. Uma janela de chat se abre.

## Como fazer uma pergunta

Toque na caixa na parte inferior. Digite sua pergunta. Toque em **Enviar**.

Algumas coisas que você pode perguntar:

- "O que João 3:16 significa?"
- "Fale-me sobre o livro de Romanos."
- "O que é o fruto do Espírito?"
- "Compare o Sermão do Monte em Mateus e Lucas."

## Como perguntar sobre um versículo específico

1. Abra um capítulo.
2. Toque em um versículo para abrir o menu do versículo.
3. Toque em **Comentário de IA**.

O versículo é enviado para a IA. O painel de IA se abre com o versículo pré-preenchido. Você pode adicionar uma pergunta, como "O que isso significa?" ou "Como devo aplicar isso?"

## Coisas importantes para saber

- A IA é uma ferramenta, não uma pessoa. Ela pode cometer erros.
- Sempre verifique as respostas da IA na própria Bíblia.
- A IA pode precisar de internet. Não funciona offline.
- Quando você usa a IA, suas perguntas, contexto do versículo e chave de API são enviados ao endpoint que você escolhe. Na primeira vez, o aplicativo pede permissão e mostra exatamente o que é enviado. Você pode alterar ou revogar essa permissão depois em **Configurações → Assistente de IA → Compartilhamento de Dados de IA Remota**.
- Algumas regiões, como a build da App Store para a China continental, não oferecem o assistente de IA. Nessa build, apenas recursos offline da Bíblia estão disponíveis.

## Como gerenciar conversas

A tela de IA mantém uma lista de conversas passadas. Na lista você pode abrir uma conversa antiga, começar uma nova ou excluir uma que não precisa mais.

Para dicas mais avançadas, veja o guia [Escrevendo Melhores Prompts de IA](theodia://help/ai-prompts).
