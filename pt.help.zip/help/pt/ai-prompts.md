---
title: Escrevendo Melhores Prompts de IA
level: advanced
categories: ai
summary: Como fazer perguntas ao assistente de IA de forma a obter boas respostas.
---

# Escrevendo Melhores Prompts de IA

> **Modo:** O assistente de IA exige o modo **Estudioso**. Você pode trocar de modo em **Configurações** → **Modo de Usuário do Aplicativo**.

Um "prompt" é a pergunta ou instrução que você dá à IA. Prompts melhores geram respostas melhores. Este guia mostra como.

## Seja específico

Ruim: "Fale-me sobre amor."
Melhor: "Em 1 Coríntios 13, que tipo de amor Paulo descreve e como ele é diferente do amor romântico?"

Quanto mais detalhes você der, mais útil será a resposta.

## Dê contexto

Ruim: "O que este versículo significa?"
Melhor: "Estou lendo Romanos 8 com um pequeno grupo. O que 'nenhuma condenação' significa neste capítulo, e como isso se conecta ao resto do capítulo?"

O contexto ajuda a IA a adequar sua resposta à sua situação.

## Peça uma coisa de cada vez

Ruim: "Fale-me sobre oração, fé e cura."
Melhor: "Fale-me primeiro sobre oração. Depois disso, perguntarei sobre fé."

Pedir uma coisa de cada vez mantém as respostas focadas.

## Peça à IA para assumir um papel

Você pode pedir à IA para responder em uma certa voz. Por exemplo:

- "Responda como se estivesse ensinando um novo cristão."
- "Responda como um estudioso da Bíblia."
- "Responda para uma criança de 10 anos."

A IA ajusta sua resposta ao papel.

## Use perguntas de acompanhamento

Se a primeira resposta não estiver certa, faça uma pergunta de acompanhamento:

- "Você pode dizer isso de forma mais simples?"
- "Você pode me dar um exemplo?"
- "O que diz o grego original?"
- "Onde mais na Bíblia isso aparece?"

Uma boa conversa é uma ida e volta. A IA lembra as últimas mensagens.

## Verifique as respostas da IA

A IA pode cometer erros. É uma ferramenta, não um mestre.

- Compare a resposta da IA com os versículos que ela indica.
- Use os comentários e léxicos do aplicativo como segunda opinião.
- Se a resposta for sobre doutrina, pergunte a um pastor ou a um amigo de confiança.

## Padrões comuns de prompt

Aqui estão alguns que funcionam bem:

- "Explique este versículo para mim como se eu fosse um novo cristão."
- "Qual é o ponto principal deste capítulo em uma frase?"
- "Liste três aplicações para o meu dia a dia a partir desta passagem."
- "Que perguntas devo fazer sobre este versículo antes de pregá-lo?"
