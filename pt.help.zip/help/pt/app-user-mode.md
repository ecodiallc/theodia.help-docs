---
title: Modo de Usuário do Aplicativo
level: beginner
categories: [user-mode]
summary: Escolha entre os modos Leitor, Padrão e Estudioso para controlar quais recursos estão disponíveis no aplicativo.
---

# Modo de Usuário do Aplicativo

O Theodia oferece três modos de usuário que controlam quais recursos você vê. Escolha o que combina com a forma como quer usar o aplicativo.

## Leitor

O modo mais simples. O modo Leitor é para leitura da Bíblia sem distrações.

- Leia qualquer tradução da Bíblia
- Use o Modo de Foco para uma leitura limpa em tela cheia
- Navegue pelos livros e capítulos
- Sem ferramentas de estudo, sem IA, sem favoritos, sem destaques

O modo Leitor é ideal se você quer que o Theodia seja uma Bíblia digital limpa, sem nada extra.

## Padrão

O modo Padrão adiciona recursos do dia a dia para o estudo pessoal da Bíblia.

Tudo do modo Leitor, mais:

- Favoritos, destaques e notas
- Leitura em voz alta
- Leitor no Modo de Estudo com menu do versículo
- Bíblias paralelas
- Entrada de comando
- Pesquisa na Bíblia
- Devocionais diários e livros integrados

O modo Padrão é a escolha certa para a maioria dos usuários que querem ler, marcar e pesquisar a Bíblia sem ferramentas avançadas de estudo.

## Estudioso

O modo completo. O modo Estudioso desbloqueia todas as ferramentas do Theodia para um estudo bíblico aprofundado.

Tudo do modo Padrão, mais:

- Comentários e léxicos
- Referências cruzadas
- Dicionário Bíblico
- Informação da Palavra (consultas Strong)
- Assistente de IA e Comentário de IA
- Menu Lançador

O modo Estudioso foi projetado para pastores, estudantes de seminário e qualquer pessoa que queira ferramentas de idioma original e auxiliares de estudo com IA.

## Como trocar de modo

1. Abra **Configurações**.
2. Toque em **Modo de Usuário do Aplicativo**.
3. Escolha **Leitor**, **Padrão** ou **Estudioso**.

A mudança entra em vigor imediatamente. Menus e botões que não estão disponíveis no modo atual ficam ocultos.

## Escolhendo um modo

- **Leitor** — Você só quer ler a Bíblia, nada mais.
- **Padrão** — Você quer favoritos, destaques, notas, pesquisa e devocionais.
- **Estudioso** — Você quer todas as ferramentas de estudo, incluindo IA, comentários e léxicos.

Você pode trocar de modo a qualquer momento. Seus favoritos, destaques e notas nunca são excluídos quando você muda de modo; eles apenas ficam ocultos até você voltar a um modo que os suporte.
