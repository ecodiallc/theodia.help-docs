---
title: Fazendo Backup dos Seus Dados
level: everyday
categories: settings
summary: Como salvar e restaurar suas notas, destaques, favoritos e segredos.
---

# Fazendo Backup dos Seus Dados

Suas notas, destaques, favoritos e configurações são salvos no dispositivo. Se você perder o celular, trocar de aparelho ou desinstalar o aplicativo, esses dados podem ser perdidos. Este guia mostra como fazer backup deles.

## Como abrir as configurações de backup

1. Abra **Configurações**.
2. Toque em **Backup do Aplicativo**.

## Como fazer um backup do aplicativo

1. Abra **Configurações**.
2. Toque em **Backup do Aplicativo**.
3. Toque em **Criar Backup do Aplicativo**.
4. Escolha uma pasta no dispositivo para salvar o arquivo. Você também pode escolher um armazenamento em nuvem.
5. O aplicativo cria um único arquivo com todos os seus dados. O arquivo termina em `.zip`.

## Com que frequência fazer backup

Faça um backup:

- Depois de escrever muitas notas.
- Antes de atualizar o sistema operacional do dispositivo.
- Antes de desinstalar o aplicativo ou trocar de celular.

Um bom hábito é um backup por mês. Algumas pessoas fazem backup toda semana.

## Como restaurar a partir de um backup do aplicativo

1. Abra **Configurações**.
2. Toque em **Backup do Aplicativo**.
3. Toque em **Restaurar a partir do Backup do Aplicativo**.
4. Escolha o arquivo de backup `.zip`.
5. Para cada tipo de dado (notas, destaques, favoritos etc.), escolha se quer manter o que está no dispositivo, substituir pelo backup ou ignorar.
6. Toque em **Restaurar**.

O aplicativo substitui seus dados pelos dados do backup. Isso inclui:

- Notas
- Destaques
- Favoritos
- Pastas de favoritos
- Configurações (tema, tamanho da fonte, idioma)

## Backup de Segredos

Seu **Backup do Aplicativo** **não** inclui segredos sensíveis como sua chave de API de IA ou token do GitHub. Para fazer backup deles separadamente, use o **Backup de Segredos**.

### Salvar um backup de segredos

1. Abra **Configurações**.
2. Toque em **Backup do Aplicativo**.
3. Em **Backup de Segredos**, toque em **Salvar Backup de Segredos**.
4. Digite uma senha forte e confirme.
5. O aplicativo criptografa seus segredos e compartilha o arquivo criptografado. Salve-o em um lugar seguro.

### Restaurar um backup de segredos

1. Abra **Configurações**.
2. Toque em **Backup do Aplicativo**.
3. Em **Backup de Segredos**, toque em **Restaurar Backup de Segredos**.
4. Escolha o arquivo de backup de segredos criptografado.
5. Digite a mesma senha que usou ao salvar.
6. Seus segredos são restaurados.

> **Importante:** Se você esquecer a senha, os segredos não podem ser recuperados. Não há como redefinir.

## Coisas para saber

- Uma restauração **substitui** as categorias que você escolheu. Tudo o que você adicionou depois do backup será perdido para essas categorias.
- Um backup do aplicativo é um único arquivo `.zip`. Mantenha-o em um lugar seguro.
- Você pode copiar, mover ou armazenar o arquivo em qualquer serviço de nuvem.
- Backups do aplicativo não incluem as próprias traduções da Bíblia. Elas podem ser baixadas novamente em **Configurações** → **Gerenciar Recursos**.
- Backups de segredos são criptografados com sua senha. Escolha uma senha que você vai lembrar.

## Dica

Se você tem mais de um dispositivo, pode copiar o arquivo de backup para cada um e restaurá-lo. Seus dados ficarão iguais nos dois.
