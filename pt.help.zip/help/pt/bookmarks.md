---
title: Salvando Versículos como Favoritos
level: everyday
categories: [annotate, read]
summary: Como salvar versículos para encontrá-los depois.
---

# Salvando Versículos como Favoritos

> **Modo:** Favoritos estão disponíveis nos modos **Padrão** e **Estudioso**. O Modo de Foco é apenas para leitura limpa e sem distrações. Você pode trocar de modo em **Configurações** → **Modo de Usuário do Aplicativo**.

Um favorito salva um versículo ou um capítulo de livro para que você possa encontrá-lo de novo. Favoritos são como as abas de um livro.

## Como favoritar um versículo

1. Abra o versículo.
2. Toque no versículo para abrir o menu.
3. Toque em **Favorito** no menu. Um ícone de estrela marca o versículo como salvo.

Um sinal de verificação no ícone significa que o versículo agora é favorito.

## Como favoritar um capítulo de livro

Quando estiver lendo um livro (não a Bíblia), você pode favoritar o capítulo inteiro:

1. Abra o capítulo.
2. Toque no ícone **Favorito** na parte superior da tela.

## Como ver seus favoritos

Toque na aba **Favoritos** na parte inferior. Você vê uma lista de todos os versículos e capítulos de livros salvos.

## Como remover um favorito

- **Um versículo:** Abra o versículo. Toque no versículo e depois no ícone **Favorito** novamente. O sinal de verificação desaparece.
- **Pela lista:** Na aba **Favoritos**, pressione longamente um favorito. Um pequeno menu aparece. Toque em **Excluir**. (Você também pode tocar no pequeno × na linha.)

## Organizar com pastas

Você pode colocar favoritos em pastas. Por exemplo, você pode ter uma pasta chamada "Preparação de Sermão" e outra chamada "Encorajamento".

Para criar uma pasta:

1. Abra a aba **Favoritos**.
2. Toque em **Gerenciar Pastas** na parte superior.
3. Toque em **+ Criar Pasta** na parte superior da lista de pastas.
4. Digite um nome e toque em **Salvar**.

Você não pode criar duas pastas com o mesmo nome. Se o nome já existir, um erro aparece dentro da caixa de criar pasta para que você mude e tente de novo.

Para colocar um favorito em uma pasta:

1. Na aba **Favoritos**, pressione longamente um favorito.
2. Toque em **Mover para Pasta**.
3. Escolha a pasta e toque em **Concluído**.

## Importando favoritos

Você pode trazer favoritos para o Theodia de outros aplicativos e arquivos.

Vá em **Configurações** → **Favoritos** → **Importar Favoritos**. Escolha **Importar de Arquivo** ou cole da área de transferência. O aplicativo detecta o formato automaticamente.

### Formatos suportados

**Exportação nativa JSON** — O formato usado pelo próprio recurso de exportação do Theodia. Isso preserva pastas e datas de criação.

**HTML de favoritos Netscape** — O formato usado pelo Chrome, Firefox e Safari ao exportar favoritos. As pastas são preservadas.

**CSV** — Uma planilha com colunas. O aplicativo procura por colunas `url` e `folder` (ou `href` / `category`). Exemplo:

```csv
url,folder
/bible/KJV/John/3,Favorites
/bible/KJV/Genesis/1,Sermon Prep
```

**Texto simples** — Cada linha é uma referência bíblica, uma URL do aplicativo ou uma diretiva de pasta. Exemplo:

```
folder: Favorites
John 3:16
Genesis 1:1
folder: Sermon Prep
Matthew 5:1
```

- Linhas que começam com `folder: <nome>` definem a pasta ativa para todos os favoritos seguintes.
- Referências bíblicas como `John 3:16` são convertidas em favoritos na sua Bíblia padrão.
- URLs do aplicativo como `/bible/KJV/John/3#v3_16` ou `/book/MyBook/1` são importadas diretamente.
- Linhas que começam com `#` ou `//` são tratadas como comentários e ignoradas.

### Dicas para importar

- Favoritos duplicados são ignorados automaticamente.
- URLs externas (como links do BibleGateway) são convertidas em favoritos do aplicativo quando possível.
- Se uma pasta do arquivo de importação já existir, os favoritos vão para a pasta existente.

## Dicas

- Você pode favoritar o mesmo versículo em várias traduções. Todos aparecem na lista.
- Favoritos ficam no dispositivo. Não são sincronizados com a nuvem.
- Veja o guia [Fazendo Backup dos Seus Dados](theodia://help/backups) para mantê-los em segurança.
