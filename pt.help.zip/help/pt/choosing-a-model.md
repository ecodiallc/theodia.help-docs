---
title: Escolhendo um Modelo de IA
level: advanced
categories: ai
summary: Como escolher um modelo que funcione bem com as ferramentas integradas e recursos do Theodia.
---

# Escolhendo um Modelo de IA

> **Modo:** O assistente de IA exige o modo **Estudioso**. Você pode trocar de modo em **Configurações** → **Modo de Usuário do Aplicativo**.

Nem todo modelo de IA funciona da mesma forma no Theodia. A melhor experiência vem de um modelo que suporta **chamadas de ferramentas** — a capacidade da IA de usar recursos integrados do Theodia, como consultar versículos da Bíblia, pesquisar, ler comentários e navegar no aplicativo.

## O que é chamada de ferramentas?

Quando você pergunta algo à IA do Theodia, ela pode fazer mais do que apenas falar. Ela também pode **agir**. Por exemplo:

- Você diz: "Mostre-me João 3:16 na ESV." A IA chama uma ferramenta para abrir aquele versículo no leitor.
- Você diz: "O que meus comentários dizem sobre Romanos 8:28?" A IA chama uma ferramenta para buscar o conteúdo do comentário.
- Você diz: "Salve este versículo como favorito." A IA chama uma ferramenta para criar um favorito.

Modelos que não suportam chamadas de ferramentas só podem dar respostas em texto. Eles não conseguem consultar, navegar ou alterar nada no aplicativo.

## Quais modelos suportam ferramentas?

### Modelos remotos

A maioria dos modelos remotos modernos de grandes provedores suporta chamadas de ferramentas compatíveis com OpenAI. Em geral:

- **Modelos grandes** (como GPT-4o, Claude Sonnet/Opus, Gemini Pro) lidam com ferramentas de forma confiável e podem encadear várias chamadas em uma conversa. Nomes de provedores e IDs de modelo são mostrados no aplicativo para conveniência; o serviço real ao qual você se conecta é aquele cujo endpoint e chave você configurar.
- **Modelos menores ou mais baratos** podem suportar ferramentas, mas podem ser menos confiáveis. Eles podem ignorar uma chamada de ferramenta ou formatá-la incorretamente.
- **Modelos muito antigos ou especializados** frequentemente não suportam ferramentas.

Se não tiver certeza, teste o modelo no Theodia. Pergunte "Mostre-me Gênesis 1:1" ou "Pesquise na Bíblia versículos sobre amor." Se o versículo abrir ou os resultados da pesquisa aparecerem, a chamada de ferramentas está funcionando.

## Modelos recomendados para o Theodia

Estas são boas escolhas que equilibram custo, qualidade e suporte a ferramentas:

- **OpenAI GPT-4o** — excelente suporte a ferramentas, rápido, lida bem com perguntas complexas de várias etapas.
- **Anthropic Claude Sonnet / Opus** — uso de ferramentas muito confiável, ótimo para passagens longas e estudos detalhados.
- **Groq** (vários modelos) — inferência rápida, muitas vezes gratuito ou muito barato; o suporte a ferramentas varia por modelo.
- **OpenRouter** — permite experimentar muitos modelos com uma conta. Procure modelos que listem "function calling" ou "tools" em suas capacidades.
- **[GitHub Models](theodia://help/github-models)** — o provedor gratuito recomendado. Acesso a modelos OpenAI, Anthropic e outros através de sua conta GitHub com um generoso limite diário gratuito. Usa os mesmos IDs de modelo no estilo `openai/gpt-4o`.

## Modelos a evitar

- **Modelos de texto puro** (como GPT-3 base ou LLaMA bruto sem ajuste de instrução) geralmente não suportam ferramentas.
- **Modelos de imagem ou visão** focados em imagens em vez de texto podem carecer de suporte a ferramentas.
- **Modelos extremamente pequenos** com menos de 1 bilhão de parâmetros dificilmente usarão ferramentas corretamente, mesmo que a API diga que as suportam.

## Como testar o suporte a ferramentas

O Theodia verifica o suporte a ferramentas automaticamente. Depois de configurar um modelo em **Configurações → Assistente de IA**, toque em **Testar conexão**. Quando a conexão for bem-sucedida, o aplicativo envia uma segunda requisição com uma definição de ferramenta de exemplo. Você verá um de dois resultados:

- **✓ Ferramentas suportadas** — O modelo aceita chamadas de ferramentas e pode usar os recursos integrados do Theodia.
- **✗ Ferramentas não suportadas** — O modelo rejeita a requisição de ferramenta. Ele responderá apenas em texto e não poderá abrir versículos, pesquisar ou gerenciar favoritos para você.

Se você vir "Ferramentas não suportadas", o modelo ainda pode funcionar como um assistente de chat em texto simples, mas você não terá a experiência integrada e sem as mãos.

Você também pode verificar manualmente pedindo à IA para fazer algo:

- "Mostre-me Mateus 5:3 na KJV." — Deve abrir o versículo no leitor.
- "O que o léxico diz sobre a palavra 'agape' em João 3:16?" — Deve retornar dados do léxico.
- "Pesquise na Bíblia versículos sobre perdão." — Deve retornar resultados de pesquisa.
- "Salve Marcos 12:30 como favorito." — Deve criar um favorito.

Se a IA der uma descrição em texto em vez de realmente fazer a coisa, o modelo está tendo dificuldade de usar suas ferramentas, mesmo que o aplicativo tenha relatado suporte.

## E se meu modelo não suportar ferramentas?

Você ainda pode usá-lo. A IA responderá em texto, e você pode consultar versículos, pesquisar e navegar no aplicativo manualmente. Mas perderá a experiência integrada e sem as mãos que torna o Theodia poderoso.

## Resumo

- Escolha um modelo com suporte a **chamadas de ferramentas / function calling** para a melhor experiência no Theodia.
- **Modelos remotos grandes** lidam com ferramentas de forma mais confiável.
- Teste qualquer modelo com comandos simples como "Mostre-me Gênesis 1:1" para verificar o suporte a ferramentas.
