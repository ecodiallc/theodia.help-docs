---
title: Comandos e Barra de Comando
level: advanced
categories: [search, navigation]
summary: Como usar a barra de comando e comandos de texto para abrir passagens, trocar versões, buscar palavras e muito mais.
---

# ⌨️ Comandos e Barra de Comando

O Theodia possui uma **barra de comando** que permite controlar o aplicativo digitando comandos curtos. Ela é útil para navegação rápida, pesquisas avançadas e ações frequentes.

## Como abrir a barra de comando

Você pode abrir a barra de comando de várias maneiras:

- Toque no campo de comando na parte superior da tela quando ele estiver visível.
- Use o atalho `/` quando um campo de texto não estiver focado.
- Use o atalho de teclado `Ctrl` + `Shift` + `P` (ou `Cmd` + `Shift` + `P`) quando disponível.

## Como usar a barra de comando

1. Comece a digitar.
2. Sugestões aparecem abaixo do campo.
3. Use as setas para cima e para baixo para selecionar uma sugestão.
4. Pressione **Enter** ou toque na sugestão para executar.

## Comandos comuns

### Abrir uma passagem

Digite uma referência bíblica para ir diretamente para ela:

```
João 3 16
Gênesis 1 1
Sl 23 4
```

O comando reconhece nomes de livros em vários idiomas quando o idioma do aplicativo está configurado. Por exemplo, se o aplicativo estiver em português, você pode usar `João 3 16` ou abreviações comuns em português.

### Trocar a Bíblia

```
/bible KJV
/version NVI
```

Isso abre a versão selecionada no livro e capítulo atual, se possível.

### Pesquisar

```
/search love
/love
```

Inicia uma pesquisa por texto no texto bíblico atual.

### Abrir uma ferramenta

```
/compare
/dictionary
/commentary
/crossrefs
/highlights
/bookmarks
/notes
```

Abre a ferramenta para o versículo atualmente selecionado ou em foco.

### Configurações

```
/settings
/theme dark
/font large
/mode scholar
```

Abre configurações ou altera aparência e modo de usuário.

### IA

```
/ai explain this verse
/ai summarize Romans 8
```

Abre o chat de IA e envia a pergunta fornecida.

### Orar

```
/pray
/prayer routine
```

Abre a tela de oração ou uma rotina de oração específica.

## Prefixos de comando

A maioria dos comandos começa com `/`. Referências bíblicas podem ser digitadas sem prefixo. O comando `/` é apenas um jeito de dizer ao aplicativo que você quer executar uma ação especial.

## Autocomplete

A barra de comando completa automaticamente:

- Nomes de livros bíblicos.
- Nomes de versões da Bíblia.
- Nomes de comandos.
- Referências parciais.

## Comandos localizados

Os comandos suportam o idioma ativo do aplicativo. Se o idioma for português, alguns verbos de comando podem ser reconhecidos em português, com fallback para o inglês quando necessário.

## Histórico

A barra de comando lembra comandos usados recentemente. Pressione a seta para cima dentro do campo para navegar pelo histórico.

## Dicas

- Comandos funcionam melhor em telas grandes com teclado externo, mas também estão disponíveis em celulares.
- Se um comando não funcionar, verifique se você digitou o nome do livro corretamente.
- A barra de comando respeita o modo de usuário atual. Recursos bloqueados em certos modos não aparecem.
