---
title: Comentários e Léxicos
level: everyday
categories: study
summary: Como consultar significados de palavras e ler notas de estudo.
---

# Comentários e Léxicos

> **Modo:** Comentários e léxicos exigem o modo **Estudioso**. Você pode trocar de modo em **Configurações** → **Modo de Usuário do Aplicativo**.

O Theodia inclui duas ferramentas de estudo: **comentários** e **léxicos**. Elas ajudam a entender a Bíblia com mais profundidade.

## O que é um comentário?

Um comentário é um livro de notas de estudo escrito por um estudioso da Bíblia. Para um determinado versículo, um comentário conta o contexto, o significado e como o versículo se encaixa no resto da Bíblia.

## O que é um léxico?

Um léxico é um dicionário de palavras bíblicas. Ele informa a palavra original em hebraico ou grego, o que ela significa e como é usada na Bíblia.

## Como abrir um comentário

1. Abra um capítulo.
2. Toque em um versículo.
3. Toque em **Comentário**.

Um painel se abre. Ele mostra notas de um estudioso da Bíblia sobre aquele versículo.

## Como abrir um léxico

1. Abra um capítulo em uma Bíblia que inclua números de Strong.
2. Toque em um número Strong no versículo (por exemplo, G1234 ou H1234).
3. Um painel se abre mostrando a palavra original em hebraico ou grego, seu significado e outros versículos que usam a palavra.

Os números Strong aparecem em uma cor diferente no texto do versículo para se destacarem das palavras normais.

## Escolher outro comentário

O comentário é escolhido a partir de uma lista suspensa na parte superior do próprio painel de comentário. Abra o painel e toque na lista suspensa para ver os comentários instalados. Escolha outro.

## Escolher outro léxico

O léxico é escolhido a partir de uma lista suspensa na parte superior do painel de léxico. Abra o painel e toque na lista suspensa para ver os léxicos instalados. Escolha outro.

## Recursos integrados

O Theodia vem com um conjunto integrado de comentários e léxicos. Eles acompanham o aplicativo e funcionam offline. Comentários e léxicos adicionais não podem ser instalados ou baixados separadamente.

## Quando usar estas ferramentas

- **Comentários** são bons quando um versículo é difícil de entender. As notas dão contexto.
- **Léxicos** são bons para estudos de palavras. Eles informam o significado exato de uma palavra no idioma original.

## Dica

Se um versículo tiver uma nota que você quer guardar, tire uma captura de tela ou copie o texto para uma nota. (Veja o guia [Escrevendo Notas](theodia://help/notes).)

## Dicionário bíblico em linguagem simples

Para definições em inglês de palavras e conceitos bíblicos (aliança, expiação, fariseus etc.), o Theodia também inclui uma ferramenta de Dicionário Bíblico. Abra-a a partir do menu do versículo tocando em **Dicionário** (📖). Ela é diferente do léxico: os léxicos explicam as palavras originais em hebraico e grego, enquanto o dicionário explica a palavra em inglês em linguagem simples. Veja o guia [Dicionário Bíblico](theodia://help/dictionary) para saber como usá-lo.
