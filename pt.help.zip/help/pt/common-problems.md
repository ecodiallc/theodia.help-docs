---
title: Problemas Comuns
level: everyday
categories: trouble
summary: Soluções rápidas para problemas que você pode encontrar.
---

# Problemas Comuns

Este guia cobre os problemas que as pessoas mais encontram. Se o seu problema não estiver aqui, veja o guia [Onde Fazer Perguntas](theodia://help/getting-more-help).

## O aplicativo está lento

1. Feche outros aplicativos em execução em segundo plano.
2. Reinicie o aplicativo.
3. Reinicie o dispositivo.

## Não consigo encontrar uma tradução da Bíblia

1. Abra **Configurações** → **Gerenciar Recursos** para ver o que está instalado.
2. Se a tradução não estiver lá, toque em **Instalar do GitHub**.
3. No modal de download, toque na aba **Bíblias** (ou **Bíblias Globais**) e selecione a tradução desejada.
4. Toque em **Instalar Selecionados** e aguarde o download terminar.
5. Você precisa de internet para baixar uma nova tradução.

## Minhas notas ou favoritos sumiram

1. Verifique se está na aba certa. Notas ficam na aba **Notas Bíblicas**. Favoritos ficam na aba **Favoritos**.
2. Se você restaurou um backup recentemente, o backup pode ter substituído seus dados. Verifique a data do backup.
3. Se você desinstalou e reinstalou o aplicativo, seus dados foram perdidos. Da próxima vez, faça um backup primeiro.

## A pesquisa não encontra versículos

1. Certifique-se de ter digitado a palavra corretamente.
2. Tente uma palavra mais curta. "Amor" encontra mais versículos do que "amando".
3. Certifique-se de ter a tradução correta da Bíblia instalada. A pesquisa só funciona nas traduções que você tem.

## A leitura em voz alta não funciona

1. Certifique-se de que o volume do dispositivo está alto.
2. Certifique-se de que o aplicativo tem permissão para usar o alto-falante.
3. Tente outra tradução. Algumas traduções funcionam melhor com leitura em voz alta do que outras.
4. Para uma lista de verificação passo a passo, veja o guia [Leitura em Voz Alta](theodia://help/tts).

## O aplicativo trava repetidamente

1. Reinicie o aplicativo.
2. Reinicie o dispositivo.
3. Se o problema persistir, por favor relate. Veja o guia [Onde Fazer Perguntas](theodia://help/getting-more-help).

## Quero desinstalar o aplicativo

Você pode desinstalar o Theodia como qualquer outro aplicativo. Antes disso, faça um backup dos seus dados. Depois de desinstalar, os dados no dispositivo desaparecem.

## Ainda preso?

Veja o guia [Onde Fazer Perguntas](theodia://help/getting-more-help). Lá você encontra links para relatar um problema e perguntar à comunidade.

Você também pode pesquisar os guias de ajuda na tela principal de **Ajuda e Guias**. Digite uma palavra como `notificações`, `pesquisa` ou `favoritos` para encontrar o guia correspondente.
