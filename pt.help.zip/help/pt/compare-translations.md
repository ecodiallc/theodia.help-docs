---
title: Comparando Traduções
level: everyday
categories: [read, study]
summary: Como ver o mesmo versículo em todas as traduções instaladas.
---

# Comparando Traduções

> **Modo:** A ferramenta Comparar está disponível nos modos **Padrão** e **Estudioso**. O Modo de Foco é apenas para leitura limpa e sem distrações. Você pode trocar de modo em **Configurações** → **Modo de Usuário do Aplicativo**.

A ferramenta **Comparar** mostra um único versículo em todas as traduções da Bíblia instaladas, tudo em um painel. É útil quando você quer ver como diferentes tradutores tratam um versículo difícil, ou quando está escolhendo uma tradução e quer olhar o mesmo versículo em cada uma.

## Como abrir Comparar

1. Abra um capítulo em qualquer tradução.
2. Toque em um versículo para abrir o menu do versículo.
3. Toque em **Comparar** (⇄).

Um painel se abre. A barra de título mostra a referência (por exemplo, "João 3:16 — Comparar"). O painel lista o mesmo versículo em todas as traduções instaladas. Sua tradução atual aparece primeiro; o restante está em ordem alfabética.

## Como o painel se parece

O painel é uma **lista vertical**, não colunas lado a lado. Cada linha é uma tradução:

- O **nome da tradução** (por exemplo, "KJV") fica no topo da linha. É tocável.
- O **texto do versículo** fica abaixo do nome.

Role o painel para ver todas as traduções. Toda tradução instalada no dispositivo aparecerá aqui. Se uma tradução não tiver aquele livro ou versículo, ela fica de fora.

## Como ler o versículo em outra tradução

Toque no nome da tradução na linha. O painel Comparar fecha e o mesmo capítulo abre com o versículo escolhido mostrado naquela tradução. Esta é a forma mais rápida de ir de uma comparação diretamente para ler uma tradução específica.

## Como fechar Comparar

- **No celular:** toque no X no canto superior direito do painel.
- **No tablet:** toque no X no cabeçalho do painel, ou toque fora do painel.

Você volta à visualização do capítulo na sua tradução original.

## Quando usar Comparar

- **Escolhendo uma tradução.** Abra um versículo que você conhece bem na sua tradução atual e depois use Comparar para vê-lo nas outras. As diferenças se destacam.
- **Versículos difíceis.** Um versículo confuso em uma tradução costuma ficar mais claro em outra.
- **Estudos de palavras.** Veja como diferentes tradutores tratam uma palavra ou frase-chave.

Para uma comparação rápida de um capítulo inteiro em várias traduções ao mesmo tempo, use a **visualização paralela** em vez disso. Veja o guia [Modo de Estudo](theodia://help/study-mode) para saber como ativá-la.
