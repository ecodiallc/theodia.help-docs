---
title: Criando Recursos Personalizados
level: advanced
categories: resources
summary: Como criar arquivos de recursos personalizados do Theodia para Bíblias, comentários, dicionários, livros e devocionais.
---

# 🛠️ Criando Recursos Personalizados

Você pode criar seus próprios recursos para o Theodia. Isso permite adicionar traduções da Bíblia, comentários, livros, devocionais e muito mais.

## O que você precisa saber

Recursos do Theodia são principalmente arquivos **SQLite** com um formato específico. Você precisa:

- Saber como criar um banco de dados SQLite.
- Seguir o esquema de tabelas esperado pelo aplicativo.
- Usar a extensão de arquivo correta (`.bible`, `.commentary`, `.lexicon`, `.book`, `.devotional`).

## Formatos de recurso

### Bíblia (.bible)

Um arquivo `.bible` precisa de três tabelas principais:

- `Details` — informações sobre a tradução (nome, abreviação, idioma).
- `Books` — lista dos livros da Bíblia, com números e nomes.
- `Verses` — texto de cada versículo, com colunas `Book`, `Chapter`, `Verse`, `Scripture`.

Veja os arquivos `.bible` existentes como referência para os nomes de colunas e formatos exatos.

### Comentário (.commentary)

Um arquivo `.commentary` contém uma tabela `Commentary` com colunas como:

- `Book`
- `Chapter`
- `Verse`
- `Scripture`

Cada linha é um comentário para um versículo específico.

### Léxico (.lexicon)

Um arquivo `.lexicon` contém entradas de palavras em grego ou hebraico. Colunas comuns incluem:

- Número Strong.
- Forma transliterada.
- Definição.
- Palavra original.

### Livro (.book)

Arquivos `.book` contêm capítulos e seções de texto. O formato é similar a um comentário, mas organizado por capítulo e tópico em vez de versículo bíblico.

### Devocional (.devotional)

Arquivos `.devotional` contêm leituras diárias. Cada leitura geralmente inclui data, versículo, título, corpo e oração.

## Ferramentas recomendadas

- **DB Browser for SQLite** (Windows, Mac, Linux) — para visualizar e editar arquivos SQLite.
- **Python** com `sqlite3` — para converter textos em lote.
- **Scripts de conversão** — scripts existentes no projeto podem ser usados como ponto de partida para formatos comuns.

## Preparando o conteúdo

1. Colete o texto que você quer incluir.
2. Divida-o em unidades lógicas (versículos, capítulos, dias).
3. Atribua números de livro, capítulo e versículo corretamente.
4. Certifique-se de que o texto esteja formatado como texto simples ou Markdown, conforme esperado pelo leitor.

## Testando o recurso

1. Coloque o arquivo no dispositivo ou emulador.
2. Abra **Configurações** → **Gerenciar Recursos**.
3. Toque em **Importar arquivo** e selecione o arquivo.
4. Abra o leitor e tente usá-lo.

Se o arquivo não aparecer ou não funcionar, verifique o esquema, a extensão e se há dados nas tabelas corretas.

## Empacotando recursos

Você pode agrupar vários recursos em um pacote para instalação fácil. Os pacotes são descritos por um arquivo de manifesto. Veja a documentação de empacotamento de recursos (se disponível) ou pacotes existentes no repositório.

## Compartilhando recursos

Recursos personalizados podem ser compartilhados com outras pessoas. Certifique-se de que você tem permissão para distribuir o texto. Materiais em domínio público ou licenciados apropriadamente são os melhores candidatos.

## Dicas

- Comece copiando um arquivo existente e substituindo os dados.
- Mantenha backups antes de alterar arquivos de recursos do aplicativo.
- Teste em um dispositivo ou emulador, não apenas no navegador.
- Se você encontrar erros, verifique os logs do aplicativo para mensagens de banco de dados.
