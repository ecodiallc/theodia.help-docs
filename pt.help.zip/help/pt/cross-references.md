---
title: Referências Cruzadas
level: everyday
categories: study
summary: Como encontrar versículos que se conectam ao que você está lendo.
---

# Referências Cruzadas

> **Modo:** Referências cruzadas estão disponíveis nos modos **Padrão** e **Estudioso**. O Modo de Foco é apenas para leitura limpa e sem distrações. Você pode trocar de modo em **Configurações** → **Modo de Usuário do Aplicativo**.

Uma "referência cruzada" é outro versículo que fala sobre a mesma coisa do versículo que você está lendo. O painel de referências cruzadas mostra quais versículos da Bíblia se conectam entre si.

## Como abrir as referências cruzadas

1. Abra um capítulo.
2. Toque em um versículo para abrir o menu do versículo.
3. Toque em **Referências Cruzadas**.

Um painel se abre. Ele mostra uma lista de outros versículos que se conectam ao que você tocou.

## Como ler a lista

Cada linha é um versículo conectado. Você vê:

- O livro, capítulo e versículo.
- Uma pequena prévia do texto do versículo.
- Uma pontuação mostrando quão forte é a conexão.

## Como ir a um versículo conectado

Toque em qualquer linha. O aplicativo abre aquele versículo para você. Quando terminar, toque no botão voltar para retornar.

## O que significa a pontuação

A pontuação diz quão próximos os versículos estão conectados. Uma pontuação alta significa uma conexão forte e direta. Uma pontuação baixa significa uma conexão mais solta.

## Usar referências cruzadas para estudar

As referências cruzadas são úteis para:

- **Estudos de palavras.** Veja como a Bíblia usa uma palavra em diferentes lugares.
- **Estudos de temas.** Acompanhe um tema, como "amor" ou "aliança", por toda a Escritura.
- **Preparação de sermão.** Encontre versículos de apoio rapidamente.

## Dica

As referências cruzadas funcionam melhor com uma tradução palavra por palavra, como a WEB.
