---
title: Devocionais Diários
level: everyday
categories: [content, read]
summary: Como ler uma meditação curta a cada dia.
---

# Devocionais Diários

Um devocional é uma leitura curta para um dia. Geralmente tem um versículo, uma breve reflexão e uma pergunta para pensar. O Theodia vem com uma pequena biblioteca de devocionais.

## Como abrir um devocional

1. Toque na aba **Devocionais** na parte inferior da tela.
2. Você verá uma lista dos devocionais instalados no dispositivo.
3. Toque em um para abri-lo.

## Como ler um devocional

1. Abra o devocional.
2. Role a tela para ler.
3. Use os botões na parte superior para:
   - Toque na **data** para ir a outro dia.
   - Toque na **estrela** para salvar o dia como favorito.
   - Toque no **alto-falante** para ouvir em voz alta (se o dispositivo suportar). Veja o guia [Leitura em Voz Alta](theodia://help/tts) para escolher uma voz.
   - Toque em **Anterior** ou **Próximo** para ir ao dia anterior ou seguinte.

## Como salvar um versículo de um devocional

1. Abra o devocional.
2. Toque em um versículo.
3. Toque em **Favorito** ou **Destacar**.

O versículo é salvo em seus Favoritos ou Destaques.

## Como escrever uma nota em um devocional

1. Abra o devocional.
2. Toque em um versículo.
3. Toque em **Nota**. Digite sua reflexão ou oração. Toque em **Salvar**.

A nota aparece na sua aba Notas Bíblicas.

## Dicas

- Devocionais não precisam de internet. Funcionam offline.
- Se quiser mais devocionais, veja o guia [Obtendo Recursos Extras no GitHub](theodia://help/getting-core-files).
