---
title: Dicionário Bíblico
level: everyday
categories: study
summary: Consulte palavras e conceitos bíblicos nos recursos de dicionário instalados. Abra-o pelo menu do versículo ou por uma entrada de léxico, depois toque em qualquer palavra para vê-la em todos os dicionários.
---

# Dicionário Bíblico

> **Modo:** O Dicionário Bíblico exige o modo **Estudioso**. Você pode trocar de modo em **Configurações** → **Modo de Usuário do Aplicativo**.

A ferramenta Dicionário Bíblico consulta uma palavra ou frase em todos os recursos de dicionário instalados. É útil quando você quer uma definição em linguagem simples de uma palavra bíblica, uma descrição de uma pessoa ou lugar, ou um pequeno artigo sobre um conceito teológico.

O Dicionário Bíblico é diferente da ferramenta **Informação da Palavra**, que consulta a palavra original em hebraico ou grego por trás de um versículo. O dicionário lê a palavra em **inglês** que você toca e mostra o que seus dicionários instalados dizem sobre ela. Para notas de tradução palavra por palavra da Bíblia, veja o guia [Comentários e Léxicos](theodia://help/commentaries-and-lexicons).

## Como abrir o Dicionário

Há duas formas de abrir o dicionário.

### Pelo menu do versículo

1. Abra um capítulo no [Modo de Estudo](theodia://help/study-mode).
2. Toque em um versículo para abrir o menu do versículo.
3. Toque em **Dicionário** (📖).

Um painel se abre intitulado com a referência do versículo (por exemplo, "João 3:16"). O texto do versículo fica na parte superior com todas as palavras tocáveis. Abaixo do versículo há uma fileira de chips mostrando todos os dicionários instalados. Abaixo disso está a definição, que fica vazia até você tocar em uma palavra.

### Por uma entrada de léxico

Quando você está lendo uma entrada de léxico no painel Informação da Palavra, algumas entradas contêm links azuis para artigos relacionados do dicionário. Toque em qualquer um desses links. O léxico fecha e o dicionário abre naquele artigo. Esta é a forma mais rápida de ir de uma palavra em grego ou hebraico para uma explicação simples do que ela significa.

## Como funciona a visualização do versículo

Quando você abre o dicionário a partir do menu do versículo, o versículo aparece na parte superior do painel como uma lista de palavras tocáveis. Palavras comuns como "o", "e", "de", "para" e "um" não são tocáveis. Todas as outras são. Cada palavra tocável está colorida e em negrito para se destacar do resto do versículo.

Toque em qualquer palavra do versículo. O Theodia pesquisa em todos os dicionários instalados uma correspondência exata com aquela palavra. A fileira de chips na parte inferior se atualiza para mostrar quais dicionários têm uma entrada: dicionários que não têm entrada para aquela palavra ficam mais claros. O primeiro dicionário com entrada é selecionado automaticamente, e sua definição aparece abaixo da fileira de chips.

A palavra que você tocou fica destacada no texto do versículo na parte superior do painel, então você sempre sabe o que está consultando.

## Trocar entre dicionários

Cada dicionário instalado é mostrado como um pequeno chip abaixo do versículo. Depois de tocar em uma palavra:

- **Chip colorido** — este dicionário tem uma entrada para a palavra que você tocou. Toque nele para trocar para a definição desse dicionário.
- **Chip esmaecido** — este dicionário não tem entrada para aquela palavra. Ele aparece acinzentado para que você veja rapidamente quais dicionários cobrem a palavra, e o chip não pode ser tocado.

O dicionário selecionado fica destacado. Toque em qualquer outro chip colorido para ler a mesma palavra naquele dicionário. A definição abaixo se atualiza imediatamente.

Se a palavra existir em apenas um dos dicionários instalados, apenas aquele chip estará colorido e os outros estarão esmaecidos.

## O que o painel mostra

O painel do dicionário tem três partes, de cima para baixo:

- **O versículo** — o versículo a partir do qual você abriu o dicionário. As palavras são tocáveis, e a palavra que você tocou por último fica destacada.
- **A fileira de chips** — todos os dicionários instalados. Colorido significa "tem entrada para a palavra tocada". Esmaecido significa "não tem entrada para aquela palavra".
- **A definição** — o artigo do dicionário selecionado. Texto simples, formatado com parágrafos e títulos. Links internos para outras entradas do dicionário são tocáveis; tocar em um deles abre aquela entrada no dicionário.

## O que acontece se nenhuma entrada for encontrada

Se você tocar em uma palavra que nenhum dos dicionários instalados cobre, o painel mostra uma pequena mensagem "nenhuma entrada encontrada" em vez de uma definição. Isso é comum para palavras muito comuns como "ano" ou "vir", que não são palavras de teologia bíblica, mesmo aparecendo por toda a Bíblia. Tente uma palavra mais específica, ou use a ferramenta Informação da Palavra do léxico, que trabalha com o texto original em grego e hebraico.

## O que acontece se nenhum dicionário estiver instalado

O dicionário precisa de pelo menos um arquivo de recurso de dicionário para ser útil. O Theodia vem com um. Se você o removeu ou está executando uma instalação personalizada sem dicionários, a visualização do versículo ainda aparece e as palavras ainda são tocáveis, mas a fileira de chips fica vazia e toda pesquisa retorna "nenhuma entrada encontrada".

Dicionários adicionais não podem ser instalados separadamente.

## Dicas

- O dicionário pesquisa por **correspondência exata de palavras**. Tocar em "amor" encontra entradas intituladas "amor", mas não "amado" ou "amar". Para consultar uma forma relacionada, use a ferramenta Informação da Palavra do léxico na palavra em grego ou hebraico.
- A fileira de chips é a mesma em celulares e tablets. Em um tablet, o dicionário abre como um painel lateral ao lado do capítulo; em um celular, abre como um modal em tela cheia. Ambos têm o mesmo layout de três partes.
- Tocar em uma palavra em um versículo diferente abre um novo versículo no painel. Sua seleção anterior é limpa. Toque em uma palavra no novo versículo para iniciar uma nova consulta.
- Algumas entradas de dicionário referenciam a mesma palavra em outro dicionário. Toque nesses links internos para seguir a trilha por todos os dicionários instalados.

## Diferenças entre Dicionário e Informação da Palavra

Ambas as ferramentas abrem a partir do menu do versículo, mas fazem coisas diferentes:

- **Dicionário** (📖) lê a palavra em inglês que você toca e a encontra em seus dicionários em inglês instalados. É a ferramenta certa para definições simples de palavras de teologia bíblica como "aliança", "expiação" ou "fariseus".
- **Informação da Palavra** (?) lê a palavra original em grego ou hebraico por trás do versículo e a encontra em seus léxicos instalados. É a ferramenta certa para estudos sérios de palavras, encontrar todos os lugares onde uma palavra grega é usada e ler as definições no idioma original.

Na dúvida, comece com o dicionário. Se quiser aprofundar no idioma original, troque para Informação da Palavra. Veja o guia [Comentários e Léxicos](theodia://help/commentaries-and-lexicons) para o guia completo de Informação da Palavra.

## Guias relacionados

- O guia [Modo de Estudo](theodia://help/study-mode) explica o menu do versículo em detalhe e onde a ferramenta Dicionário (📖) fica ao lado de Favorito, Destacar, Falar, Comparar, Referências Cruzadas, Comentário de IA, Informação da Palavra e Notas.
- O guia [Comentários e Léxicos](theodia://help/commentaries-and-lexicons) cobre Informação da Palavra e os léxicos do idioma original.
- O guia [O que são Recursos?](theodia://help/what-are-resources) explica os diferentes tipos de arquivos que o Theodia usa, incluindo os recursos de dicionário.
- O guia [Problemas Comuns](theodia://help/common-problems) tem soluções para resultados vazios e outros problemas do dicionário.
