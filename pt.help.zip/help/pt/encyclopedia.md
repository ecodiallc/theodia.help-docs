---
title: Enciclopédia
level: everyday
categories: study
summary: Como consultar artigos de enciclopédia e navegar por obras de referência.
---

# Enciclopédia

O Theodia inclui uma **Enciclopédia** integrada para consultar artigos relacionados à Bíblia, pessoas, lugares e tópicos. O aplicativo vem com o _Kitto's Illustrated Commentary_ (KIT) integrado, e você pode baixar enciclopédias adicionais do repositório.

## O que é uma enciclopédia no Theodia?

Uma enciclopédia é uma obra de referência feita de artigos curtos. Cada artigo cobre uma pessoa, lugar, evento ou tópico bíblico. Diferente de um comentário, que explica um versículo específico, um artigo de enciclopédia explica o próprio tópico.

## Como abrir a Enciclopédia

1. Toque em **Enciclopédias** na barra inferior.
2. Escolha uma enciclopédia na fileira de abreviações na parte superior.
3. Digite um tópico, pessoa ou lugar na caixa de pesquisa.

A pesquisa exige pelo menos **3 caracteres** antes que resultados e sugestões de preenchimento automático apareçam.

## Lendo um artigo

- No **celular**, toque em qualquer resultado para abrir o artigo em uma nova tela.
- No **tablet**, o artigo abre no painel da direita enquanto a lista fica na esquerda.

## Selecionando enciclopédias

Toque em um chip de abreviação (como **KIT**) para trocar para aquela enciclopédia. Para pesquisar em mais de uma enciclopédia ao mesmo tempo, use a aba **Pesquisar** e selecione **Enciclopédia** como modo de pesquisa.

## Obtendo mais enciclopédias

1. Abra **Configurações**.
2. Toque em **Gerenciar Recursos**.
3. Toque em **Instalar do GitHub**.
4. Selecione a aba **Enciclopédias**.
5. Toque no botão de download ao lado da enciclopédia desejada.

As enciclopédias são baixadas do repositório do Theodia no GitHub e instaladas automaticamente. Enciclopédias instaladas aparecem na tela Enciclopédia e em Pesquisa.

Você também pode instalar uma enciclopédia a partir de um arquivo local: em **Gerenciar Recursos**, toque em **Importar Arquivo Local** e escolha um arquivo `.encyclopedia`. O arquivo é copiado para a pasta de enciclopédias do aplicativo e adicionado ao índice de consulta compartilhado.

## Pressione longamente para ver o título completo

Na tela de Pesquisa, os chips de enciclopédia mostram abreviações curtas. Pressione longamente um chip para ver o nome completo da enciclopédia.

## Quando usar a Enciclopédia

- Consulte uma pessoa, lugar ou tópico antes ou enquanto lê uma passagem.
- Obtenha contexto sobre uma palavra ou conceito bíblico que abrange muitos versículos.
- Leia junto com um comentário para um estudo mais profundo.
