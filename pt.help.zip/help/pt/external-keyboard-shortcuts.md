---
title: Atalhos de Teclado Externo
level: advanced
categories: [accessibility, tablet]
summary: Atalhos de teclado para iPad e tablet Android quando um teclado externo está conectado.
---

# ⌨️ Atalhos de Teclado Externo

Você pode usar um teclado físico com iPad, tablet Android e até mesmo alguns celulares com suporte a teclado. O Theodia suporta atalhos para navegação, leitura bíblica, pesquisa e ferramentas de estudo.

## Atalhos globais

Esses atalhos funcionam na maioria das telas.

| Teclas | Ação |
| --- | --- |
| `Ctrl` + `F` | Abrir a aba **Pesquisar** e focar o campo de busca. |
| `Ctrl` + `,` | Abrir **Configurações**. |
| `Ctrl` + `1` | Ir para a aba **Início**. |
| `Ctrl` + `2` | Ir para a aba **Bíblia**. |
| `Ctrl` + `3` | Ir para a aba **Pesquisar**. |
| `Ctrl` + `4` | Ir para a aba **Favoritos**. |
| `Ctrl` + `5` | Ir para a aba **Mais**. |
| `Ctrl` + `=` | Aumentar o tamanho da fonte. |
| `Ctrl` + `-` | Diminuir o tamanho da fonte. |
| `Ctrl` + `0` | Redefinir o tamanho da fonte para o padrão. |
| `Ctrl` + `T` | Trocar entre tema claro e escuro. |
| `Esc` | Fechar a tela atual, menu ou diálogo aberto. |
| `Tab` | Mover o foco para o próximo controle. |
| `Shift` + `Tab` | Mover o foco para o controle anterior. |

## Atalhos do leitor bíblico

Use estes atalhos quando você estiver lendo a Bíblia.

| Teclas | Ação |
| --- | --- |
| `Ctrl` + `→` | Ir para o próximo capítulo. |
| `Ctrl` + `←` | Ir para o capítulo anterior. |
| `Ctrl` + `↑` | Subir para a lista de capítulos do livro atual. |
| `Ctrl` + `↓` | Abrir o menu do versículo para o versículo atual. |
| `Ctrl` + `B` | Adicionar/remover o capítulo atual de **Favoritos**. |
| `Ctrl` + `D` | Abrir a ferramenta **Dicionário** para o versículo selecionado. |
| `Ctrl` + `C` | Abrir **Comentário** para o versículo selecionado. |
| `Ctrl` + `V` | Abrir **Comparar** para o versículo selecionado. |
| `Ctrl` + `R` | Abrir **Referências Cruzadas** para o versículo selecionado. |
| `Ctrl` + `N` | Criar uma **Nota Bíblica** para o versículo selecionado. |
| `Ctrl` + `H` | Abrir **Destaques** para o versículo selecionado. |
| `Ctrl` + `I` | Abrir **Informação da Palavra** para o versículo selecionado. |
| `Ctrl` + `M` | Iniciar o botão **Falar** para leitura em voz alta. |
| `Espaço` | Pausar ou continuar a leitura em voz alta quando o botão **Falar** está ativo. |
| `Setas` | Rolar o texto da Bíblia para cima e para baixo. |
| `Home` | Ir para o início do capítulo. |
| `End` | Ir para o final do capítulo. |

## Atalhos de pesquisa

Use estes atalhos na aba **Pesquisar**.

| Teclas | Ação |
| --- | --- |
| `Ctrl` + `F` | Focar o campo de busca (já funciona globalmente). |
| `Enter` | Executar a pesquisa quando o campo de busca está focado. |
| `↓` / `↑` | Navegar pelos resultados da pesquisa. |
| `Enter` | Abrir o resultado selecionado. |
| `Esc` | Limpar a pesquisa ou voltar para a tela anterior. |

## Atalhos da barra de comandos

Se você abrir a barra de comandos do menu do versículo com `/`, ou usar a **Barra de Comando** da tela, estes atalhos ajudam.

| Teclas | Ação |
| --- | --- |
| `/` | Abrir a barra de comando (quando disponível). |
| `↓` / `↑` | Navegar pelas sugestões de comando. |
| `Enter` | Executar o comando selecionado. |
| `Esc` | Fechar a barra de comando. |

## Atalhos de menus e modais

Quando um menu, modal ou diálogo está aberto:

| Teclas | Ação |
| --- | --- |
| `Esc` | Fechar o menu/modal. |
| `Enter` | Ativar o botão padrão. |
| `↓` / `↑` | Mover entre itens de uma lista ou menu. |

## Teclas modificadoras

- No iPad e em muitos tablets Android, use a tecla `Command` (⌘) como alternativa ao `Ctrl`.
- Se um atalho parecer não funcionar, tente `Command` + a mesma tecla.

## Dicas

- Conecte um teclado Bluetooth ou USB-C para usar os atalhos.
- Mantenha a lista de atalhos deste guia aberta em outra tela enquanto memoriza os favoritos.
- Os atalhos funcionam melhor em tablets e iPads com telas grandes.
