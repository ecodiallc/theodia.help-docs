---
title: Perguntas Frequentes
level: everyday
categories: faq
summary: Respostas às perguntas mais comuns sobre o uso do Theodia.
---

# Perguntas Frequentes

## O Theodia custa alguma coisa?

O Theodia é uma compra única. Não há assinatura, publicidade, compras dentro do aplicativo ou pedidos de doação. Todos os recursos adicionais disponíveis no catálogo são gratuitos para download depois que você compra o aplicativo.

## Preciso de conexão com a internet?

Não. Depois que o aplicativo e seus arquivos de dados estão instalados, tudo funciona offline. Você pode ler, pesquisar, destacar, fazer anotações e usar a maioria das ferramentas de estudo sem sinal.

A única funcionalidade que precisa de internet é baixar novos recursos.

## Onde meus dados são armazenados?

Todos os seus favoritos, destaques, notas e configurações são salvos no dispositivo. Eles não são enviados para nenhum servidor.

Você pode fazer backup manualmente. Veja o guia [Fazendo Backup dos Seus Dados](theodia://help/backups) para saber como.

## Posso ouvir a Bíblia em voz alta?

Sim. Abra qualquer capítulo, toque no menu e escolha a opção de leitura em voz alta. Seu dispositivo deve ter uma voz de texto para fala instalada. Veja o guia [Leitura em Voz Alta](theodia://help/tts) para mais detalhes.

## Como pesquiso por um versículo?

Você pode digitar uma referência como `João 3:16` no Comando na tela inicial, ou usar a aba **Pesquisar** para pesquisar por palavra ou frase.

## Como relato um bug ou sugiro uma funcionalidade?

Toque em **Enviar Sugestão / Problema** na tela Sobre, [relatar no GitHub](https://github.com/ecodiallc/theodia.app/issues/new), ou visite a página de [Discussões do GitHub](https://github.com/ecodiallc/theodia.app/discussions).

## Quais dispositivos são suportados?

O Theodia roda em iPhone, iPad e celulares e tablets Android. Funciona melhor em dispositivos com pelo menos 2 GB de armazenamento livre para os arquivos de dados principais.

## Posso usar um teclado externo?

Sim. O Theodia suporta teclados Bluetooth e USB no iPad. Navegação, pesquisa e muitos recursos de leitura têm atalhos de teclado. Veja o guia [Atalhos de Teclado Externo](theodia://help/external-keyboard-shortcuts) para a lista completa.

## Quais idiomas são suportados?

A interface do aplicativo está disponível em inglês, árabe, chinês (simplificado e tradicional), tcheco, dinamarquês, holandês, filipino, francês, alemão, grego, hebraico, hindi, indonésio, italiano, japonês, coreano, polonês, português (Brasil), romeno, russo, espanhol, sueco, tailandês, turco, ucraniano e vietnamita.

O idioma do texto bíblico depende das traduções que você instalou.

## Como mudo o idioma?

Vá em **Configurações** e procure a opção de idioma.

## Minha pergunta não está aqui. Onde posso obter mais ajuda?

Navegue pelo resto dos guias de ajuda por tópico, ou faça uma pergunta na [comunidade de Discussões do GitHub](https://github.com/ecodiallc/theodia.app/discussions).

Dica: Na tela principal de **Ajuda e Guias**, use a caixa de pesquisa para digitar um tópico como `notificações` ou `pesquisa` e encontrar o guia correspondente.
