---
title: Lendo Seu Primeiro Capítulo
level: beginner
categories: [start, read]
summary: Um passo a passo para abrir e ler um capítulo pela primeira vez.
---

# Lendo Seu Primeiro Capítulo

Este guia mostra como abrir um capítulo pela primeira vez.

## Etapa 1: Abra a aba Bíblia

Olhe para a parte inferior da tela. Você verá uma fileira de abas. Toque na que diz **Bíblia**.

## Etapa 2: Escolha um livro

Você verá uma lista dos livros da Bíblia. Gênesis é o primeiro. João está perto do meio. Apocalipse é o último.

Toque no nome do livro que deseja.

## Etapa 3: Escolha um capítulo

Você verá os números de 1 até a quantidade de capítulos que o livro tem. Toque no capítulo desejado.

O capítulo se abre. Os versículos aparecem na tela.

## Etapa 4: Navegue

- Deslize para a **esquerda** para ir ao próximo capítulo.
- Deslize para a **direita** para voltar.

## Etapa 5: Interaja com um versículo

O que você pode fazer com um versículo depende do seu modo de uso.

### Modo Leitor

O modo Leitor é limpo e sem distrações.

- Toque em um versículo para destacá-lo brevemente.
- Não há ferramentas de estudo, favoritos ou menus.
- Se quiser mais recursos, mude para o modo **Padrão** ou **Estudioso** em **Configurações**.

### Modo Padrão

O modo Padrão adiciona recursos do dia a dia para o estudo pessoal da Bíblia.

Toque em um versículo para abrir um menu com estas opções:

- **Salvar** o versículo como favorito.
- **Destacar** o versículo com uma cor.
- **Adicionar uma nota** ao versículo.
- **Copiar** o texto do versículo.
- **Comparar** o versículo em outra tradução.
- **Consultar referências cruzadas** do versículo.

### Modo Estudioso

O modo Estudioso desbloqueia todas as ferramentas para um estudo bíblico aprofundado.

Toque em um versículo para abrir um menu com tudo do modo Padrão, mais:

- **Comentário** sobre o versículo.
- **Informação da Palavra** e consultas no idioma original.
- **Dicionário** de definições.
- **Assistente de IA** para estudos mais aprofundados.

Você pode mudar de modo a qualquer momento em **Configurações**.

## Precisa de ajuda com uma ferramenta específica?

Cada ferramenta tem seu próprio guia. Toque em **Ajuda** na página inicial para ver todos. O guia [Modo de Estudo](theodia://help/study-mode) é um bom ponto de partida — ele explica todas as ferramentas do menu do versículo.

Se você ainda está aprendendo onde as coisas ficam, veja o guia [Layout e Navegação do Aplicativo](theodia://help/navigating-the-app). Ele explica a tela inicial, o menu principal e a barra inferior.

## Quer mais recursos?

O aplicativo já vem com várias versões da Bíblia disponíveis gratuitamente. Se quiser adicionar mais, ou adicionar comentários, livros ou devocionais, veja o guia [Obtendo Recursos Extras no GitHub](theodia://help/getting-core-files). Ele mostra onde encontrá-los e como adicioná-los.
