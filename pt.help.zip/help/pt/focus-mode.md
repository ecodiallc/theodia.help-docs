---
title: Modo de Foco
level: beginner
categories: [layout, read]
summary: Uma forma limpa e sem distrações de ler passagens longas.
---

# Modo de Foco

> **Modo:** O Modo de Foco é o leitor do modo **Leitor**. Também está disponível nos modos **Padrão** e **Estudioso** como alternativa ao Modo de Estudo. Você pode trocar de modo em **Configurações** → **Modo de Usuário do Aplicativo**.

O Modo de Foco é uma forma de ler um capítulo da Bíblia sem botões ou menus no caminho. É bom para sessões longas de leitura.

## Como ativar

1. Abra qualquer capítulo.
2. Na fileira de ícones na parte superior da tela, toque no botão 📖. Ele abre o mesmo capítulo no Modo de Foco.
3. Os menus e botões se escondem. Sobra apenas o texto bíblico.

No modo **Leitor**, os capítulos abrem automaticamente no Modo de Foco. O botão 📖 fica oculto porque não há Modo de Estudo para o qual trocar.

## O que você pode fazer no Modo de Foco

- **Rolar** a tela para ler.
- **Deslizar** para ir ao próximo ou ao capítulo anterior.
- **Toque no botão 📖** na barra inferior para voltar ao Modo de Estudo. (Oculto no modo Leitor.)
- **Toque no botão 🔊** na barra inferior para ouvir o capítulo em voz alta. Uma mini barra de controle aparece com reproduzir, pausar, retroceder, avançar e seletor de voz. (Oculto no modo Leitor — TTS requer Padrão ou Estudioso.)

## Um bom uso para o Modo de Foco

- Ler um livro inteiro, um capítulo de cada vez.
- Ler uma passagem longa para devocional ou momento de silêncio.
- Ler em voz alta e acompanhar sem distrações.

## Trocando para o Modo de Estudo

O Modo de Foco esconde todas as ferramentas de estudo, mas elas estão a um toque. Toque no botão 📖 na parte superior da tela para abrir o mesmo capítulo no [Modo de Estudo](theodia://help/study-mode). O Modo de Estudo é o leitor completo, com comentário, referências cruzadas, consultas de léxico e notas. Para saber o que o Modo de Estudo pode fazer, veja o guia [Modo de Estudo](theodia://help/study-mode).

No modo **Leitor**, o botão 📖 fica oculto porque o Modo de Estudo não está disponível.
