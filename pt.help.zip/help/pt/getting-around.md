---
title: Navegando Rapidamente
level: beginner
categories: layout
summary: Todas as formas rápidas de ir a um versículo, capítulo ou tela no Theodia.
---

# Navegando Rapidamente

Este guia é uma cola para navegação. Ele cobre todas as formas rápidas de ir de onde você está para onde quer chegar.

## Ir direto a um versículo

A forma mais rápida de abrir qualquer versículo é o **Comando** na tela inicial.

- Digite `João 3:16` e toque em Ir.
- Digite `Salmos 23` e toque em Ir.
- Digite `Gênesis 1` e toque em Ir.

O aplicativo abre o capítulo exato (e rola até o versículo, se você tiver incluído um).

## Deslizar entre capítulos

Quando estiver lendo um capítulo:

- **Deslize para a esquerda** → próximo capítulo.
- **Deslize para a direita** → capítulo anterior.

Isso funciona entre livros também. Depois de Êxodo 40, deslizar para a esquerda leva a Levítico 1.

## Usar a barra superior

Enquanto lê, a parte superior da tela mostra a **tradução**, o **livro** e o **capítulo** atuais.

- Toque no nome da tradução para trocar de Bíblia.
- Toque no nome do livro para escolher outro livro.
- Toque no número do capítulo para escolher outro capítulo.

## Ir a partir de um favorito

Se você salvou um versículo:

1. Abra a aba **Favoritos**.
2. Toque em qualquer item.
3. Você vai direto para aquele versículo.

## Ir a partir da pesquisa

1. Abra a aba **Pesquisar**.
2. Digite uma palavra ou frase.
3. Toque em qualquer resultado.
4. O aplicativo abre o capítulo com as palavras da pesquisa destacadas em amarelo.

## Trocar o layout de leitura

O leitor da Bíblia tem dois layouts:

- **Modo de Estudo** — mostra o capítulo com todas as ferramentas de estudo a um toque.
- **Modo de Foco** — esconde todas as ferramentas e menus, deixando apenas o texto.

Para alternar: toque no botão **📖** na parte superior da tela enquanto lê. Toque novamente para voltar. (No modo Leitor, sempre fica no Modo de Foco.)

## Usar as abas inferiores

A fileira de ícones na parte inferior da tela fica sempre visível. Toque em qualquer aba para mudar de seção. As abas exatas dependem do seu modo de uso:

**Todos os modos:**

- **Início** — volta para a tela inicial.
- **Bíblias** — lista de traduções.
- **Pesquisar** — pesquisa na Bíblia, em livros, dicionários, léxicos e PDFs.
- **Configurações** — preferências e recursos.

**Padrão e Estudioso também veem:**

- **Favoritos** — versículos salvos.
- **Destaques** — versículos marcados com cor.
- **Notas Bíblicas** — suas notas particulares.
- **PDFs** — seus documentos PDF importados.

**Estudioso também vê:**

- **IA** — o assistente de IA (se ativado em Configurações).

### Lembrando onde você parou

Cada aba mantém seu próprio histórico de navegação. Quando você volta para uma aba, retorna **onde parou**, não à tela inicial daquela seção.

- Você abre a aba **Bíblias**, escolhe uma tradução, abre um capítulo e muda para **Pesquisar**. Depois, toca em **Bíblias** novamente e volta ao mesmo capítulo.
- Você abre a aba **Favoritos**, toca em um versículo favorito e muda para **Configurações**. Tocar em **Favoritos** novamente retorna à lista de favoritos.

Isso vale para todas as abas. Cada uma lembra seu lugar até que você navegue explicitamente para outra tela dentro dela.

### O que reinicia uma aba

Uma aba só volta à sua tela raiz quando:

- Você já está nela e toca no mesmo ícone novamente. É uma forma rápida de voltar ao início.
- O aplicativo é fechado à força e reaberto.

### Abas inferiores vs. menu principal

- **Abas inferiores** — cada aba lembra sua própria pilha. Tocar em uma aba retorna onde você parou.
- **Menu principal** — tocar em um item navega para aquela tela. É uma lista suspensa, não uma sobreposição.

Exemplo:

- Você está lendo João 3. Toca na aba **Favoritos**, depois em **Bíblias** novamente. Volta a João 3.
- Você está lendo João 3. Abre o menu e toca em **Notas Bíblicas**. Revisa suas notas, depois toca na aba **Bíblias** para voltar a João 3.

## Dicas

- A tela inicial lembra quais seções estão expandidas ou recolhidas.
- Se uma aba estiver faltando, verifique seu **modo de usuário** em **Configurações** → **Modo de Usuário do Aplicativo**. O modo Leitor esconde favoritos, destaques, notas e IA. O modo Padrão esconde IA. Talvez você também precise ativar um recurso em **Configurações** ou instalar um recurso.
