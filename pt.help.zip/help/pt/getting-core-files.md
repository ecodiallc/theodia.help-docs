---
title: Obtendo Recursos Extras
level: everyday
categories: resources
summary: Como adicionar Bíblias, comentários, livros e outros recursos ao Theodia.
---

# Obtendo Recursos Extras

O Theodia vem com alguns recursos integrados, mas você pode adicionar mais. A forma mais fácil é pela tela **Gerenciar Recursos** dentro do aplicativo.

## O que você pode adicionar

- **Bíblias** — mais traduções em diferentes idiomas
- **Comentários** — notas de estudo que explicam versículos
- **Livros** — clássicos cristãos e obras de referência
- **Devocionais** — leituras devocionais diárias
- **Arquivos principais** — arquivos de dados maiores como morfologia, referências cruzadas e a Marvel Interlinear Bible (MIB)

## Como adicionar recursos de dentro do aplicativo

1. Abra **Configurações**.
2. Toque em **Gerenciar Recursos**.
3. Escolha uma aba: **Principal**, **Bíblias**, **Comentários**, **Livros** ou **Devocionais**.
4. Navegue pela lista. Toque em um recurso para ler mais sobre ele.
5. Toque na caixa de seleção para escolher o que deseja.
6. Toque em **Baixar** na parte inferior. Os arquivos são baixados e instalados automaticamente.

Uma vez instalado, o recurso aparece no aplicativo imediatamente. Você não precisa reiniciar.

## Arquivos principais

A aba **Principal** tem grandes arquivos de dados que alimentam ferramentas de estudo mais profundo. Eles incluem:

- Dados de morfologia (formas de palavras no idioma original)
- Bancos de dados de referências cruzadas
- A Marvel Interlinear Bible (MIB)

Você só precisa baixar os arquivos principais uma vez. Eles ficam no dispositivo e funcionam offline.

## Bíblias Globais

A aba **Bíblias Globais** tem traduções da Bíblia de uma coleção mais ampla. Se você não vir uma tradução desejada na aba principal **Bíblias**, verifique aqui.

## Gerenciando recursos instalados

Na tela principal de **Gerenciar Recursos** (não na aba de download), você pode:

- **Ativar ou desativar** um recurso sem excluí-lo. Recursos desativados ficam no dispositivo, mas ficam ocultos dos menus.
- **Excluir** um recurso para liberar espaço. Você pode baixá-lo novamente depois.

## Adicionando seus próprios arquivos

Se você tem um arquivo de recurso de outro lugar — um amigo, outro projeto ou um site — pode importá-lo diretamente:

1. Em **Gerenciar Recursos**, toque em **Importar Arquivo Local**.
2. Escolha o arquivo no dispositivo.
3. O aplicativo lê o arquivo e o adiciona à sua biblioteca.

O aplicativo aceita estes tipos de arquivo:

- `.bible` — traduções da Bíblia
- `.commentary` — comentários
- `.lexicon` — léxicos
- `.book` — livros
- `.devotional` — devocionais

## Conectando um repositório GitHub personalizado

Se alguém mantém um repositório GitHub com recursos compatíveis com o Theodia, você pode adicioná-lo como uma fonte personalizada:

1. Vá em **Configurações → Repositórios GitHub**.
2. Toque em **Adicionar Repositório**.
3. Digite a URL do GitHub (por exemplo, `https://github.com/username/repo-name`).
4. Escolha quais tipos de recursos o repositório contém (Bíblias, comentários ou livros).
5. Salve.
6. Volte para **Gerenciar Recursos**. Uma nova aba aparece com os recursos daquele repositório.

Se o repositório for privado, você precisará adicionar um **Personal Access Token** em **Configurações → Repositórios GitHub** para que o aplicativo possa lê-lo.

## Uma nota sobre tamanhos de arquivo

Arquivos de recurso podem ser grandes. Bíblias geralmente são pequenas (alguns megabytes). Comentários e arquivos principais podem ser muito maiores (centenas de megabytes). Faça download por Wi-Fi quando possível.

## Resumo

- Use **Configurações → Gerenciar Recursos** para navegar e instalar recursos.
- Arquivos principais desbloqueiam ferramentas de estudo mais profundo, como morfologia e referências cruzadas.
- Importe arquivos locais se você tiver os seus.
- Adicione repositórios GitHub personalizados se quiser recursos de outra fonte.
