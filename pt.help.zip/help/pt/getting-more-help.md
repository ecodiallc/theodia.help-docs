---
title: Onde Fazer Perguntas
level: everyday
categories: trouble
summary: Como obter ajuda da equipe e da comunidade do Theodia, e como encontrar tópicos de ajuda dentro do aplicativo.
---

# Onde Fazer Perguntas

Se você estiver preso, há alguns lugares para pedir ajuda.

## Encontrando um tópico de ajuda

Se você está procurando informações sobre uma funcionalidade específica, experimente um destes caminhos:

- **Navegar por categoria.** Abra **Ajuda e Guias** e toque em uma categoria como **Configurações e Personalização** ou **Solução de Problemas**. Cada cartão lista guias relacionados.
- **Pesquisar por palavra-chave.** Na tela principal de **Ajuda e Guias**, digite uma palavra na caixa de pesquisa na parte superior. Por exemplo, digitar `notificações` mostra o guia [Notificações e Lembretes](theodia://help/notifications); digitar `pesquisa` mostra o guia [Pesquisando na Bíblia](theodia://help/search-the-bible).
- **Verifique Configurações primeiro.** Muitas funcionalidades são configuradas em **Configurações**. Se quiser configurar lembretes, abra **Configurações** → **Notificações**. A tela de configurações também tem um link **Ajuda** para cada seção.

## Dentro do aplicativo

Abra a tela **Sobre**. Você verá dois botões:

- **Enviar Sugestão / Problema** — abre um formulário para enviar à equipe uma dúvida, ideia ou relatório de bug.
- **Discussão / Feedback** — abre o quadro de discussão da comunidade.

## A página do GitHub

Você pode ver a lista de problemas conhecidos e alterações recentes no [GitHub](https://github.com/ecodiallc/theodia.app).

## Discussão da comunidade

Outras pessoas que usam o Theodia fazem perguntas e compartilham dicas no [quadro de discussão da comunidade](https://github.com/ecodiallc/theodia.app/discussions). Você pode ler tópicos antigos e iniciar um novo.

## Antes de perguntar

Algumas coisas nos ajudam a responder mais rápido:

- **Qual é o seu dispositivo?** (por exemplo, iPhone 13, Pixel 7)
- **Qual versão do aplicativo?** (Abra **Sobre** para ver.)
- **O que você fez?** Uma breve descrição dos passos.
- **O que aconteceu?** O que você viu na tela.
- **O que você esperava que acontecesse?** Esta geralmente é a parte mais útil.

## O que esperar

- Para relatórios de bug, a equipe geralmente responde em poucos dias.
- Para ideias, a equipe lê todas. Não podemos prometer quando uma ideia será adicionada.
- Para perguntas da comunidade, outros usuários frequentemente respondem mais rápido do que a equipe.

## Uma nota sobre privacidade

Quando você enviar uma pergunta, por favor não inclua informações privadas. A equipe pode ver o que você envia.
