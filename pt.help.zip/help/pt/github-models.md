---
title: GitHub Models
level: advanced
categories: ai
summary: Configure o GitHub Models — uma forma gratuita de começar a explorar a IA no Theodia sem uma assinatura de API existente.
---

# GitHub Models

> **Modo:** O assistente de IA exige o modo **Estudioso**. Você pode trocar de modo em **Configurações** → **Modo de Usuário do Aplicativo**.

Se você ainda não paga por um serviço de IA, o **GitHub Models** é a forma mais fácil de começar a explorar a IA do Theodia. É gratuito para começar, e tudo o que você precisa é de uma conta gratuita do GitHub.

## O que é GitHub Models?

GitHub Models é um serviço do GitHub que permite executar modelos de IA modernos por meio de uma API. Ele suporta o mesmo formato da OpenAI, então funciona perfeitamente com o Theodia.

## Por que escolher GitHub Models?

- **Sem cartão de crédito** — Apenas uma conta do GitHub.
- **Modelos de alta qualidade** — Você tem acesso a GPT-4o, GPT-4.1 e outros modelos confiáveis que suportam as ferramentas do Theodia.
- **Configuração fácil** — Um token, uma URL e pronto.

## Etapa 1: Criar uma conta no GitHub

Se você já tem uma conta no GitHub, pule para a Etapa 2.

1. Vá para [github.com](https://github.com).
2. Toque em **Sign up** e siga as instruções para criar uma conta gratuita.
3. Verifique seu e-mail quando o GitHub enviar a confirmação.

## Etapa 2: Criar um Token de Acesso Pessoal

Este token é sua chave de API. Ele diz ao GitHub quem você é quando o Theodia envia perguntas.

1. Vá para [github.com/settings/tokens](https://github.com/settings/tokens).
2. Toque em **Generate new token** e escolha **Generate new token (classic)**.
3. Dê ao token um nome como **Theodia AI**.
4. Em **Select scopes**, marque a caixa para **`models:read`**.
   - Esta é a única permissão que o Theodia precisa.
5. Role até a parte inferior e toque em **Generate token**.
6. **Copie o token imediatamente.** O GitHub só o mostrará uma vez. Cole-o em um lugar seguro (como o aplicativo de notas do celular) até adicioná-lo ao Theodia.

## Etapa 3: Escolher um modelo

O GitHub Models oferece vários modelos. Para o Theodia, estas são as melhores opções:

| Modelo | Limite Diário Gratuito | Melhor Para |
| --------------------- | ------------------ | --------------------------------------------- |
| `openai/gpt-4.1-nano` | 150 requisições / dia | Perguntas rápidas e explicações simples de versículos |
| `openai/gpt-4.1-mini` | 150 requisições / dia | Estudo geral com bom suporte a ferramentas |
| `openai/gpt-4.1` | 50 requisições / dia | Estudo mais profundo e perguntas complexas de várias etapas |
| `openai/gpt-4o` | 50 requisições / dia | Versátil, excelente suporte a ferramentas |

Comece com **`openai/gpt-4.1-mini`** — é rápido, confiável e oferece um limite diário maior.

## Etapa 4: Configurar o Theodia

1. Abra o **Theodia**.
2. Vá em **Configurações** → **Assistente de IA**.
3. Certifique-se de que **Modelo remoto** está selecionado.
4. Toque na lista suspensa **Provedor** e escolha **GitHub Models**.
   - Se GitHub Models não estiver na lista, toque em **Personalizado** e insira a URL base manualmente: `https://models.github.ai`
5. Cole seu GitHub Personal Access Token no campo **Chave de API**.
6. Digite o ID do modelo escolhido no campo **Modelo** (por exemplo: `openai/gpt-4.1-mini`).
7. Toque em **Testar conexão**.
8. Aguarde a verificação terminar. Você deverá ver:
   - **✓ Conexão bem-sucedida**
   - **✓ Ferramentas suportadas**

Se você vir **✗ Ferramentas não suportadas**, tente um ID de modelo diferente da tabela acima.

## Etapa 5: Começar a conversar

1. Toque na aba **IA** na parte inferior da tela.
2. Digite uma pergunta e toque em **Enviar**.
3. Ou, enquanto lê qualquer capítulo da Bíblia, toque no número de um versículo e escolha **Comentário de IA** para iniciar um chat específico do versículo.

## Solução de problemas

### "Connection failed" ou "HTTP 401"

- Certifique-se de ter copiado o **token inteiro**. É uma longa sequência que começa com `ghp_`.
- Tokens expiram se não forem usados por muito tempo. Volte ao GitHub e gere um novo.
- Verifique se selecionou **models:read** ao criar o token.

### "Tools not supported"

- Alguns modelos no GitHub Models não aceitam chamadas de ferramentas. Tente **`openai/gpt-4o`** ou **`openai/gpt-4.1-mini`**.
- Certifique-se de que o ID do modelo está escrito exatamente como mostrado, incluindo o prefixo `openai/`.

### Erros de limite de taxa

- Se atingir o limite diário, troque para um modelo com limite mais alto (como `openai/gpt-4.1-nano` com 150 requisições por dia).
- Os limites reiniciam a cada 24 horas.

## Resumo

- GitHub Models é a **forma recomendada de começar a explorar a IA** no Theodia.
- Você precisa de uma **conta gratuita do GitHub** e um **Personal Access Token** com `models:read`.
- O melhor modelo inicial é **`openai/gpt-4.1-mini`**.
- Insira o token e o modelo em **Configurações → Assistente de IA**, toque em **Testar conexão** e comece a conversar.
