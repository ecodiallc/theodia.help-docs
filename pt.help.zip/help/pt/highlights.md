---
title: Destacando Versículos
level: everyday
categories: [annotate, read]
summary: Como marcar versículos com cores e encontrá-los depois.
---

# Destacando Versículos

> **Modo:** Destaques estão disponíveis nos modos **Padrão** e **Estudioso**. O Modo de Foco é apenas para leitura limpa e sem distrações. Você pode trocar de modo em **Configurações** → **Modo de Usuário do Aplicativo**.

Destacar marca um versículo com uma cor. Funciona como um marca-texto amarelo no papel. O versículo continua destacado na próxima vez que você abri-lo.

## Como destacar um versículo

1. Abra o versículo.
2. Toque no versículo para abrir o menu.
3. Toque no ícone **Destacar**.
4. Escolha uma cor.

O versículo agora está destacado com aquela cor.

## Como mudar a cor do destaque

1. Abra o versículo.
2. Toque no versículo e depois no ícone **Destacar**.
3. Escolha uma nova cor.

## Como remover um destaque

1. Abra o versículo.
2. Toque no versículo e depois em **Destacar** no menu.
3. Toque em **Remover Destaque** na parte inferior do seletor de cores.

## Uma forma comum de usar as cores

Muitos leitores usam um pequeno conjunto de cores para propósitos específicos:

- **Amarelo** para favoritos em geral.
- **Verde** para versículos sobre Deus.
- **Azul** para versículos sobre oração.
- **Rosa** para versículos sobre conforto.
- **Laranja** para versículos sobre advertência ou correção.
- **Roxo** para versículos sobre profecia ou fim dos tempos.

Escolha um sistema que funcione para você.

## Como ver todos os seus destaques

Toque na aba **Destaques** na parte inferior. Você vê uma lista de todos os versículos destacados, com os mais recentes primeiro. Há uma fileira de chips de cores na parte superior — toque em uma cor para mostrar apenas os destaques daquela cor, ou toque em **Tudo** para limpar o filtro.

## Importando destaques

Você pode trazer destaques para o Theodia de outros aplicativos e arquivos.

Vá em **Configurações** → **Favoritos** → **Importar Destaques**. Escolha **Importar de Arquivo** ou cole da área de transferência. O aplicativo detecta o formato automaticamente.

### Formatos suportados

**Exportação nativa JSON** — O formato usado pelo próprio recurso de exportação do Theodia:

```json
{
  "/bible/KJV/John/3#v3_16": "yellow",
  "/bible/KJV/Genesis/1#v1_1": "green"
}
```

**CSV** — Uma planilha com colunas `url` e `color`. Exemplo:

```csv
url,color
/bible/KJV/John/3#v3_16,yellow
/bible/KJV/Genesis/1#v1_1,green
```

**Texto simples** — Cada linha é uma referência bíblica ou URL, seguida opcionalmente por um nome de cor. Exemplo:

```
John 3:16 yellow
Genesis 1:1 green
Matthew 5:1
```

- Cores disponíveis: `yellow`, `green`, `blue`, `pink`, `orange`, `purple`.
- Se nenhuma cor for informada, o destaque usa amarelo como padrão.
- Linhas que começam com `#` ou `//` são tratadas como comentários e ignoradas.

## Dicas

- Destaques ficam no dispositivo. Não são sincronizados com a nuvem.
- Você pode destacar um versículo em uma tradução e ele aparece em suas outras traduções do mesmo versículo.
- Veja o guia [Fazendo Backup dos Seus Dados](theodia://help/backups) para mantê-los em segurança.
