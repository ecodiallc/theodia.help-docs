---
title: Instalando Traduções da Bíblia
level: beginner
categories: start
summary: Como adicionar uma tradução da Bíblia à sua biblioteca.
---

# Instalando Traduções da Bíblia

O Theodia vem com algumas traduções da Bíblia prontas para ler. Você pode adicionar mais a qualquer momento. Uma "tradução" é uma versão diferente do texto bíblico, como a King James Version.

## Como adicionar uma tradução

A aba Bíblia mostra uma lista das traduções já instaladas. Para adicionar mais, abra o gerenciador de recursos:

1. Abra **Configurações**.
2. Toque em **Gerenciar Recursos**.
3. Toque em **Instalar do GitHub**.
4. No modal de download, toque na aba **Bíblias**.
5. Toque na caixa de seleção ao lado de cada tradução desejada.
6. Toque em **Instalar Selecionados** na parte inferior.
7. Aguarde o download terminar.

A tradução agora está na sua biblioteca. Para vê-la, abra a aba **Bíblia**.

## Como alternar entre traduções

1. Abra um capítulo que deseja ler.
2. Toque no nome da tradução na parte superior da tela.
3. Escolha a desejada na lista.

O aplicativo salva sua escolha para a próxima vez.

## Como remover uma tradução

1. Abra **Configurações**.
2. Toque em **Gerenciar Recursos**.
3. Encontre a tradução que deseja remover.
4. Toque no **X** ao lado dela.
5. Confirme que deseja removê-la.

Remover uma tradução não exclui suas notas, destaques ou favoritos. Eles permanecem seguros.

## Quanto espaço as traduções ocupam?

A maioria das traduções tem entre 2 e 10 MB. Elas ficam armazenadas no dispositivo, não na nuvem. Você pode manter quantas quiser, desde que o dispositivo tenha espaço.

## E se uma tradução não estiver no aplicativo?

Algumas traduções não estão na lista dentro do aplicativo. Você ainda pode adicioná-las.

1. Abra o aplicativo e vá em **Configurações** → **Gerenciar Recursos**.
2. Toque em **Instalar do GitHub**.
3. No modal de download, olhe as abas **Bíblias** e **Bíblias Globais**. Se sua tradução estiver lá, selecione-a e toque em **Instalar Selecionados**.
4. Se não estiver, toque em **Importar Arquivo Local** para importar um arquivo `.bible`. Obtenha o arquivo na página do GitHub do projeto. Veja o guia [Obtendo Recursos Extras no GitHub](theodia://help/getting-core-files) para ajuda passo a passo.
