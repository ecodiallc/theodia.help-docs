---
title: Adicionando os Arquivos Principais
level: beginner
categories: start
summary: Como baixar os grandes arquivos de dados que o aplicativo precisa para estudar a Bíblia em profundidade.
---

# Adicionando os Arquivos Principais

O Theodia vem com uma Bíblia e alguns pequenos extras prontos para usar. Para aproveitar o máximo do aplicativo, você também precisa baixar os **arquivos principais**. São grandes arquivos de dados que adicionam ferramentas de estudo como comentário, consultas de palavras e notas gramaticais. Sem eles, o aplicativo funciona, mas os recursos de estudo são limitados.

## Por que você precisa dos arquivos principais

Os arquivos principais adicionam:

- **Consultas de palavras.** Toque em uma palavra de qualquer versículo para ver o hebraico ou grego original e o que significa.
- **Comentário.** Comentário de IA em cada versículo.
- **Gramática.** Informações sobre cada palavra no idioma original.
- **Bíblia Interlinear.** Leia o texto no idioma original com o inglês embaixo de cada palavra.

Você pode ler a Bíblia sem eles, mas a maioria das ferramentas de estudo os precisa.

## Como instalar os arquivos principais

**[Instalar Arquivos Principais](theodia://manage/core)**

1. Abra **Configurações**.
2. Toque em **Gerenciar Recursos**.
3. A aba **Principal** se abre. Você vê uma lista dos arquivos principais. Cada um tem um nome, um tamanho e uma caixa de seleção.
4. Toque em cada arquivo que deseja instalar. Um sinal de verificação indica que foi escolhido.
5. Toque em **Instalar Selecionados**.
6. Aguarde os arquivos serem baixados e instalados. Eles são grandes, então isso pode levar alguns minutos em uma conexão lenta.

Os arquivos são baixados para o dispositivo. Você só precisa fazer isso uma vez. O aplicativo os usa daí em diante, mesmo quando você está offline.

## Dicas

- Use Wi-Fi. Os arquivos são grandes.
- Conecte o celular ou tablet em uma fonte de energia. Downloads grandes usam bateria.
- Se um download falhar, toque no arquivo novamente para tentar.
- Você pode instalar todos ou apenas os que precisa.

## E se um arquivo estiver faltando na lista?

O aplicativo obtém a lista da página do GitHub do projeto. Se a lista estiver vazia, verifique sua conexão com a internet e tente novamente. Se ainda estiver vazia, veja o guia [Onde Fazer Perguntas](theodia://help/getting-more-help).

Para formas mais avançadas de adicionar recursos, veja o guia [Obtendo Recursos Extras no GitHub](theodia://help/getting-core-files).
