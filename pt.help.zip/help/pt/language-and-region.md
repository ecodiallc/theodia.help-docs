---
title: Idioma e Região do Aplicativo
level: everyday
categories: settings
summary: Como mudar o idioma do aplicativo.
---

# Idioma e Região do Aplicativo

O Theodia está disponível em muitos idiomas. O aplicativo pode mudar o idioma dos menus e botões. O conteúdo de ajuda também está disponível em muitos desses idiomas e já vem embutido no aplicativo. Você também pode baixar ou atualizar o pacote de ajuda de um idioma — abra **Configurações** → **Ajuda** ou **Gerenciar Recursos** → **Instalar do GitHub** → **Documentos de ajuda**.

## Como abrir as configurações de idioma

1. Abra **Configurações**.
2. Toque em **Idioma**.

## Como mudar o idioma do aplicativo

1. Na lista de **Idioma**, toque no idioma desejado.
2. O aplicativo aplica o novo idioma imediatamente.

As opções que você vê dependem dos idiomas suportados pelo aplicativo.

## Como o idioma é escolhido na primeira instalação

Quando você instala o Theodia pela primeira vez, o aplicativo escolhe um idioma com base nas configurações do dispositivo. Você pode mudá-lo a qualquer momento.

## O que é traduzido

- Menus, botões e rótulos.
- Telas de configurações.
- Mensagens de erro.
- Ferramentas de pesquisa e estudo.

## O que está apenas em inglês

- Algum conteúdo de livros e devocionais.

## Idioma do aplicativo e idioma da tradução bíblica

O idioma do aplicativo e o idioma da tradução da Bíblia são coisas diferentes. Você pode ter o aplicativo em espanhol e a Bíblia em inglês, ou vice-versa.

Para mudar a tradução da Bíblia, veja o guia [Instalando Traduções da Bíblia](theodia://help/installing-bibles).

## Dicas

- Se um botão ou rótulo estiver vazio, o aplicativo está faltando uma tradução. A versão em inglês geralmente aparece como fallback.
- Se você quiser ajudar a traduzir o aplicativo, veja o guia [Onde Fazer Perguntas](theodia://help/getting-more-help).
