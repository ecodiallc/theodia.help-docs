---
title: Menu Inicial do Aplicativo
level: everyday
categories: navigation
summary: Como usar o menu do canto superior esquerdo da tela Inicial para abrir recursos, ferramentas e configurações rapidamente.
---

# 🚀 Menu Inicial do Aplicativo

Na tela **Início**, o botão no canto superior esquerdo abre um menu rápido. Esse menu permite pular para recursos, ferramentas e configurações sem navegar por várias telas.

## Como abrir o menu

1. Vá para a aba **Início**.
2. Toque no botão com três linhas no canto superior esquerdo.
3. O menu desliza para baixo.

## Itens do menu

- **Bíblias** — abre a lista de traduções da Bíblia.
- **Livros** — abre a biblioteca de livros.
- **Devocionais** — abre a coleção de devocionais.
- **Playlist** — abre sua lista de reprodução atual.
- **Favoritos** — abre a aba de favoritos.
- **Pesquisar** — abre a tela de pesquisa.
- **Configurações** — abre as configurações do aplicativo.
- **Sobre** — abre a tela com informações sobre o Theodia.
- **Ajuda** — abre os artigos de ajuda.

## Versão Plus

Alguns itens do menu podem mostrar uma etiqueta **Plus** se você tiver desbloqueado recursos adicionais.

## Dicas

- Use o menu quando quiser ir diretamente para **Configurações** ou **Pesquisar** sem passar pelas abas.
- O menu é especialmente útil se você estiver com pressa ou não lembrar em qual aba está um recurso.
