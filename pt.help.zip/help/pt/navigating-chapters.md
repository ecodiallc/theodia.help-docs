---
title: Navegando Entre Livros, Capítulos e Versículos
level: everyday
categories: [layout, read]
summary: Como se mover pela Bíblia e ir para onde você quer.
---

# Navegando Entre Livros, Capítulos e Versículos

Este guia mostra todas as formas de se mover pela Bíblia.

## O jeito fácil: deslizar

- Deslize para a **esquerda** em um capítulo para ir ao próximo capítulo.
- Deslize para a **direita** para voltar.
- Isso funciona para o próximo livro também. Depois do último capítulo de Êxodo, por exemplo, o deslize leva ao primeiro capítulo de Levítico.

## O jeito pelo menu

- Toque no nome da tradução no topo para trocar de Bíblia.
- Toque no nome do livro no topo para escolher outro livro.
- Toque no número do capítulo para escolher outro capítulo.

## O jeito rápido: digitar

- Na tela inicial, há uma caixa no topo. Digite uma referência, como `João 3:16` ou `salmos 23`, e toque na tecla **Ir** do teclado.
- O aplicativo abre o versículo.

## O jeito pelo favorito

Se você salvou um versículo, abra a aba **Favoritos**. Toque em qualquer item para ir até ele.

## O jeito pela pesquisa

Toque na aba **Pesquisar**. Digite uma palavra. O aplicativo mostra todos os versículos que a contêm. Toque em qualquer resultado para abri-lo.

## O jeito pelo histórico

O aplicativo lembra os capítulos que você abriu. Para encontrá-los de novo, olhe na aba **Favoritos** (para versículos salvos) ou role a lista de livros na aba **Bíblia** para encontrar um livro lido recentemente.

## Dicas

- A aba Bíblia mostra os livros em ordem, de Gênesis a Apocalipse.
- Para Salmos, Provérbios e outros livros longos, toque no livro e use a lista de capítulos para avançar rápido.
