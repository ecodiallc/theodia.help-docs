---
title: Layout e Navegação do Aplicativo
level: beginner
categories: layout
summary: Um tour pela tela inicial, menu principal e barra inferior — onde tudo fica.
---

# Layout e Navegação do Aplicativo

O Theodia tem três áreas principais para navegar: a **tela inicial**, o **menu principal** e a **barra inferior**. Este guia explica cada uma para que você sempre saiba para onde ir.

## Mapa rápido

- A **tela inicial** é a página que você vê ao abrir o aplicativo. Tem uma caixa de pesquisa, grandes botões para cada parte do aplicativo e uma lista das Bíblias, livros e devocionais instalados.
- A **barra inferior** (também chamada de barra de abas) é a fileira de ícones na parte inferior da tela. Toque em qualquer uma para ir direto àquela parte do aplicativo.
- O **menu principal** é o ícone de três linhas (☰) no canto superior direito da tela inicial. Toque nele para abrir uma lista com todas as telas do aplicativo, inclusive as que não têm aba própria.

## A tela inicial

Quando você abre o Theodia, cai na tela inicial. Ela é dividida em quatro partes, de cima para baixo.

### O cabeçalho

No topo há uma barra colorida. À esquerda estão o ícone do aplicativo e o nome "Theodia". À direita está o botão do menu principal (☰). Quando você está dentro de um livro ou capítulo, o lado esquerdo mostra um botão de voltar (←). Toque no menu principal para abrir o menu (veja abaixo).

### O Comando

Logo abaixo do cabeçalho há uma caixa de texto estilo pesquisa, com o rótulo **Comando**. Digite uma instrução curta e toque na tecla de confirmação do teclado. O aplicativo lê a instrução e o leva à tela certa. Exemplos:

- `salmos 23` — abre Salmos 23
- `joão 3:16` — abre João 3:16
- `pesquisar amor` — pesquisa na Bíblia por "amor"
- `favorito joão 3:16` — salva João 3:16 como favorito
- `comentário romanos 8:28` — abre o comentário daquele versículo
- `xref` seguido de uma referência — abre as referências cruzadas daquele versículo
- `ajuda` — abre a lista de comandos com exemplos

Se o aplicativo não entender o que você digitou, mostra um pequeno alerta com uma dica. Veja o guia **Problemas Comuns** se os comandos não funcionarem.

### A grade de botões

Abaixo do Comando há uma grade de botões grandes, dois por fileira. Cada botão leva a uma parte diferente do aplicativo. Os botões são:

- 📖 **Bíblias** — sua lista de traduções da Bíblia
- 🔍 **Pesquisar** — pesquisa na Bíblia por palavra ou frase
- 📚 **Livros** — sua biblioteca de clássicos cristãos
- 📅 **Devocionais** — devocionais diários
- 🔖 **Favoritos** — seus versículos e capítulos salvos
- 🖍 **Destaques** — seus versículos marcados com cor
- 📝 **Notas Bíblicas** — suas notas particulares sobre versículos
- ⚙️ **Configurações** — idioma, tema, recursos e mais
- ❓ **Ajuda** — o sistema de ajuda (esta página)
- ℹ️ **Sobre** — versão do aplicativo e créditos

### As listas de recursos

Abaixo da grade de botões há seções expansíveis: **Bíblias**, **Livros** e **Devocionais**. Cada seção mostra os itens instalados. Toque no cabeçalho da seção para expandir ou recolher. Toque em qualquer item da seção para abri-lo.

A seção Bíblias é a forma mais rápida de entrar em uma tradução específica — sem menus, apenas toque.

## A barra inferior

A barra inferior (barra de abas) é a fileira de ícones na parte inferior da tela. Ela fica visível em quase todo o aplicativo, então você pode sempre pular para outra seção. As abas que você vê dependem do seu modo de uso.

**Todos os modos veem:**

- 🏠 **Início** — abre a tela inicial
- 📖 **Bíblias** — abre sua lista de traduções da Bíblia
- 📚 **Livros** — abre sua biblioteca de livros
- 🔍 **Pesquisar** — abre a pesquisa na Bíblia
- ⚙️ **Configurações** — abre as configurações

**Padrão e Estudioso também veem:**

- 🔖 **Favoritos** — abre seus versículos salvos
- 🖍 **Destaques** — abre seus versículos marcados com cor
- 📝 **Notas Bíblicas** — abre suas notas particulares

**Estudioso também vê:**

- 💻 **IA** — abre o assistente de IA (se você o ativou em Configurações)

A aba atual fica destacada. Toque em qualquer outra para trocar.

### Como a barra se comporta

Cada aba da barra tem sua própria **pilha** de telas. Quando você toca em uma aba, volta a **onde parou** naquela pilha, não à tela inicial da seção. Por exemplo:

- Toque em **Bíblias** → você vê a lista de traduções.
- Toque em uma tradução → você vê a lista de livros.
- Toque em um livro → você vê a lista de capítulos.
- Toque em um capítulo → você está lendo o capítulo.
- Mude para **Favoritos** para consultar algo.
- Toque em **Bíblias** novamente → você volta ao capítulo que estava lendo.

Cada aba lembra seu lugar. O aplicativo mantém seu histórico de navegação dentro de cada aba, então trocar de aba não faz você perder o progresso.

### O que reinicia uma aba

Uma aba só volta à tela raiz quando:

- Você já está nela e toca no mesmo ícone novamente. É uma forma rápida de voltar ao início.
- O aplicativo é fechado à força e reaberto.

### Abas inferiores vs. menu principal

- **Abas inferiores** — cada aba lembra sua própria pilha. Tocar em uma aba retorna onde você parou.
- **Menu principal** — tocar em um item navega para aquela tela usando o mesmo sistema de abas. Não abre como uma sobreposição.

Use as abas para trocar de tarefa. Use o menu principal quando quiser uma lista completa de todas as telas do aplicativo.

### Quando usar a barra inferior

Use a barra inferior quando quiser trocar o que está fazendo:

- Você está lendo um capítulo e quer pesquisar outra coisa → toque em **Pesquisar**.
- Você está pesquisando e quer consultar seus favoritos → toque em **Favoritos**.
- Você está em qualquer lugar do aplicativo e quer ir para a tela inicial → toque em **Início**.

## O menu principal

O menu principal é o botão com três linhas empilhadas (☰) no canto superior direito da tela inicial. Toque nele e um painel desliza da direita. O painel mostra todas as telas suportadas pelo seu modo atual:

- 🏠 **Início**
- 📖 **Bíblias**
- 📚 **Livros**
- 🙏 **Devocionais**
- 🔍 **Pesquisar**
- 🔖 **Favoritos** (Padrão e Estudioso)
- 🖍 **Destaques** (Padrão e Estudioso)
- 📝 **Notas Bíblicas** (Padrão e Estudioso)
- 💻 **Assistente de IA** (somente Estudioso, e somente se IA estiver ativada)
- ⚙️ **Configurações**
- ❓ **Ajuda**
- ℹ️ **Sobre**

O item que corresponde à tela em que você está fica destacado e tem um pequeno ponto ao lado. Toque em qualquer item para ir direto a ele. Toque fora do painel, no X no topo ou no botão voltar do dispositivo para fechar sem mudar de tela.

### Como o menu principal é diferente

O menu principal é um painel suspenso, não uma camada de navegação separada. Quando você toca em um item, o aplicativo navega para aquela tela da mesma forma que se tivesse usado a aba inferior ou o botão da grade. A pilha da aba atual é preservada, então você pode voltar aonde estava tocando na aba original novamente.

Por exemplo:

- Você está lendo João 3. Toca na aba **Favoritos**. Vai para seus favoritos. Quando toca em **Bíblias** novamente, volta a João 3 — exatamente onde parou.
- Você está lendo João 3. Abre o menu principal e toca em **Notas Bíblicas**. Suas notas abrem. Para voltar a João 3, toque na aba **Bíblias** e você retorna ao capítulo automaticamente.

As abas trocam seu contexto e lembram seu lugar. O menu principal é apenas outra forma de chegar às mesmas telas.

### Quando usar o menu principal

Use o menu principal quando:

- Você quer abrir **Destaques**, **Notas Bíblicas**, **Devocionais**, **Ajuda** ou **Sobre** — telas que não têm aba própria na barra inferior.
- Você está no meio de um capítulo ou pesquisa e quer consultar algo rapidamente sem perder seu lugar.
- Você quer abrir **Configurações** sem sair da tela em que está.

## Modo Estudioso

Se seu modo de usuário estiver em **Estudioso**, o layout ganha abas, itens de menu e ferramentas de leitura extras que o modo Leitor e o modo Padrão escondem. Veja o guia [Modo Estudioso](theodia://help/scholar-mode) para uma explicação completa de cada recurso.

## Como as três áreas se encaixam

- **Trocar para uma seção principal** (Bíblias, Pesquisar, Favoritos etc.) → barra inferior
- **Ir a um versículo específico ou dar um comando** → Comando da tela inicial
- **Navegar por todas as telas disponíveis** → grade de botões da tela inicial
- **Consultar Notas, Destaques ou Ajuda sem sair do lugar** → menu principal
- **Abrir Configurações de qualquer lugar** → menu principal ou barra inferior

Você usará as três. Nenhuma é "a forma certa". Escolha a mais fácil para o que está fazendo.

### Barra inferior vs. menu principal: um exemplo rápido

Imagine que você está lendo Romanos 8 e quer destacar um versículo que gostou.

**Usando a barra inferior:**

1. Toque no versículo para abrir o menu do versículo.
2. Toque em **Destacar** e escolha uma cor.
3. Pronto. Você nunca saiu do capítulo.

**Usando o menu principal (se quiser revisar seus destaques):**

1. Toque em ☰ para abrir o menu.
2. Toque em **Destaques**. Sua lista de destaques abre.
3. Revise-os, depois toque na aba **Bíblias** para voltar a Romanos 8.

**Usando a barra inferior (se quiser trocar de tarefa):**

1. Toque em **Início** ou **Favoritos** na barra inferior.
2. Você sai de Romanos 8 e vai para a nova tela.
3. Para voltar a Romanos 8, toque em **Bíblias** novamente — você retorna ao capítulo automaticamente.

## Dicas

- A tela inicial lembra quais seções estão expandidas ou recolhidas. Você só precisa configurar isso uma vez.
- Se uma aba esperada não aparecer, verifique duas coisas:

1. **Seu modo de usuário** — o modo Leitor esconde favoritos, destaques, notas e IA. O modo Padrão esconde IA. Mude de modo em **Configurações** → **Modo de Usuário do Aplicativo**.
2. **Configurações de recursos** — algumas abas precisam ser ativadas em **Configurações** (por exemplo, o assistente de IA).
