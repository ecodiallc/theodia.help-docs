---
title: Escrevendo Notas
level: everyday
categories: [annotate, read]
summary: Como escrever seus próprios pensamentos ao lado de um versículo.
---

# Escrevendo Notas

> **Modo:** Notas estão disponíveis nos modos **Padrão** e **Estudioso**. O Modo de Foco é apenas para leitura limpa e sem distrações. Você pode trocar de modo em **Configurações** → **Modo de Usuário do Aplicativo**.

As notas são onde você escreve seus próprios pensamentos, orações ou ideias de estudo ao lado de um versículo. Cada nota está ligada a um versículo específico.

## Como adicionar uma nota

1. Abra o versículo.
2. Toque no versículo para abrir o menu.
3. Toque em **Nota** no menu. Ela tem um ícone de lápis.
4. Digite sua nota.
5. Toque em **Salvar**.

A nota agora está salva com o versículo.

## Como ler uma nota

1. Abra o versículo.
2. Procure a marca de lápis ao lado do versículo. Significa que há uma nota.
3. Toque no versículo. A nota aparece abaixo.

## Como editar uma nota

1. Abra o versículo que tem a nota.
2. Toque no versículo.
3. Toque em **Nota** no menu.
4. Faça suas alterações.
5. Toque em **Salvar**.

## Como excluir uma nota

1. Abra o versículo que tem a nota.
2. Toque no versículo.
3. Toque em **Nota** no menu.
4. Toque em **Excluir**.

## Como ver todas as suas notas

Toque na aba **Notas Bíblicas** na parte inferior. Você vê uma lista de todas as notas que escreveu, ordenadas por data.

## Pesquisar suas notas

Na aba **Notas Bíblicas**, toque na caixa **Pesquisar**. Digite uma palavra. O aplicativo encontra todas as notas que contêm essa palavra.

## Dicas

- Notas são ótimas para sermões, devocionais e perguntas de estudo.
- Notas são privadas. Ficam no dispositivo.
- Veja o guia [Fazendo Backup dos Seus Dados](theodia://help/backups) para mantê-las em segurança.
