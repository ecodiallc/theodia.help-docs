---
title: Notificações e Lembretes
level: everyday
categories: [settings]
summary: Como ligar, personalizar e gerenciar lembretes offline para oração, devocionais, planos de leitura da Bíblia e muito mais.
---

# Notificações e Lembretes

O Theodia pode lembrá-lo de oração, devocionais, planos de leitura da Bíblia, flashcards e outras atividades — mesmo quando o aplicativo está offline. Todos os lembretes são agendados no dispositivo; não é necessária conexão com a internet ou servidor de notificações push.

## Como ligar ou desligar os lembretes

1. Abra **Configurações**.
2. Toque em **Notificações**.
3. Ative ou desative **Ativar lembretes**.

Na primeira vez que ativar os lembretes, o aplicativo pede permissão para enviar notificações. Toque em **Permitir** para que os lembretes possam aparecer.

Se você negou a permissão anteriormente, o iOS ou Android pode bloquear o pedido. Nesse caso, vá ao aplicativo de **Configurações** do dispositivo, encontre **Theodia** e ative as notificações lá.

## Tipos de lembretes

A tela de notificações é dividida em canais. Cada canal é uma família de lembretes que você pode ligar ou desligar independentemente:

- **Lembretes de oração** — lembretes gerais de oração.
- **Rotina de oração** — lembretes ligados a uma rotina de oração específica.
- **Devocional** — lembrete do versículo diário ou devocional.
- **Lembretes de plano de leitura** — lembretes para um plano de leitura da Bíblia ativo.
- **Lembretes de Theoscript** — lembretes para executar um Theoscript.
- **Lembretes de insights de IA** — lembretes gerados por IA.
- **Lembretes de revisão de flashcards** — avisos para revisar flashcards.
- **Lembretes de hábito de leitura** — prompts diários de hábito de leitura.
- **Lembretes litúrgicos e sazonais** — lembretes ligados ao calendário da igreja.
- **Meus lembretes** — lembretes que você criou a partir de favoritos, destaques, playlists, capítulos da Bíblia ou livros.
- **Lembretes personalizados** — lembretes totalmente personalizados que você cria.

Toque em qualquer canal para ver seus lembretes, mudar o horário, escolher em quais dias dispara ou desligá-lo.

## Lembretes personalizados

Lembretes personalizados são lembretes que você constrói do zero.

1. Em **Configurações** → **Notificações**, toque em **Lembretes personalizados**.
2. Toque no botão **+**.
3. Digite um **Título** e uma **Mensagem**.
4. Escolha um **Horário**.
5. Escolha os **Dias** em que deseja que repita.
6. Escolha o que o lembrete abre ao ser tocado (opcional).
7. Toque em **Salvar**.

Você pode editar ou excluir um lembrete personalizado a qualquer momento tocando nele na lista.

## O que acontece ao tocar em um lembrete

A maioria dos lembretes abre uma tela específica no aplicativo. Por exemplo, um lembrete de rotina de oração abre aquela rotina; um lembrete de plano de leitura abre a próxima leitura.

Se um lembrete não tiver tela vinculada, ele abre o aplicativo na tela Inicial.

## Horário de silêncio

O horário de silêncio silencia os sons das notificações, mas ainda permite que lembretes visuais apareçam.

1. Em **Configurações** → **Notificações**, toque em **Horário de silêncio**.
2. Defina um horário de **Início** e **Fim**.

Lembretes agendados durante o horário de silêncio aparecerão na tela sem som.

## Lembretes futuros e histórico

- **Lembretes futuros** mostra tudo o que está agendado para disparar em seguida.
- **Histórico de notificações** mostra lembretes entregues recentemente, agendados e cancelados.

Use essas listas para confirmar se um lembrete está configurado corretamente ou para ver por que um não apareceu.

## Se os lembretes não estiverem aparecendo

- Certifique-se de que **Ativar lembretes** está ligado.
- Verifique se as notificações são permitidas nas configurações do sistema do dispositivo.
- Certifique-se de que o canal do lembrete está ativado e pelo menos um dia está selecionado.
- Se você definiu horário de silêncio, o lembrete pode estar silencioso.
- Alguns fabricantes de Android colocam aplicativos para dormir. Adicione o Theodia à lista de permissões se seu dispositivo oferecer configurações de otimização de bateria.
- Se um lembrete estiver vinculado a conteúdo que você removeu (por exemplo, um plano de leitura ou rotina excluída), o lembrete pode não disparar até que você selecione um destino válido novamente.

## Sons de notificação

Você pode escolher o som tocado por lembretes que suportam sons. Toque em **Som** dentro de um lembrete ou canal para escolher entre as opções disponíveis. Os sons acompanham o aplicativo, então funcionam offline.

Use o botão **Visualizar som** para ouvir o som selecionado antes de salvar.

## Badges

Alguns lembretes podem adicionar um badge ao ícone do aplicativo. Toque em **Limpar badge** na tela de notificações para redefini-lo.
