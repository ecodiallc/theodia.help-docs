---
title: PDFs
level: everyday
categories: [read, resources]
summary: Importe, organize e leia documentos PDF no Theodia.
---

# PDFs

> **Modo:** Os PDFs estão disponíveis nos modos **Padrão** e **Estudioso**. O Modo de Foco é apenas para leitura limpa e sem distrações. Você pode trocar de modo em **Configurações** → **Modo de Usuário do Aplicativo**.

O Theodia pode armazenar e ler arquivos PDF. Os PDFs importados ficam no seu dispositivo, então funcionam offline.

## Abrir a biblioteca de PDFs

Toque na aba **PDFs** na parte inferior da tela, ou toque no bloco **PDFs** na tela inicial.

## Importar um PDF

1. Abra a aba **PDFs**.
2. Toque no botão **+** no canto inferior direito.
3. Escolha um PDF do seu dispositivo.
4. (Opcional) Digite ou escolha uma categoria para organizá-lo.

## Organizar PDFs

Pressione longamente qualquer cartão de PDF para abrir um menu com estas opções:

- **Renomear** — muda o título mostrado na biblioteca.
- **Mudar categoria** — move o PDF para uma categoria.
- **Excluir** — remove o PDF do Theodia. Isso também exclui a posição de leitura salva.

As categorias são texto livre. Digite um novo nome ou escolha um existente quando importar ou mudar a categoria.

## Ler um PDF

Toque em um cartão de PDF para abri-lo. O leitor mostra:

- O título do documento em uma barra na parte superior.
- Uma fileira de botões de página: **Primeira página**, **Anterior**, a página atual ("3 / 120"), **Próxima** e **Última página**.
- Uma barra de ferramentas com as ferramentas do documento: **Sumário**, **Diminuir zoom**, **Aumentar zoom**, **Redefinir zoom**, **Favorito**, **Pesquisar**, **Ouvir** e **Visualização de texto**.

Algumas ferramentas ficam acinzentadas quando não podem ser usadas — por exemplo, **Pesquisar** e **Ouvir** ficam acinzentadas até que o texto pesquisável do PDF seja instalado.

### Passar páginas

- Toque na **seta esquerda** ou **direita** para voltar ou avançar uma página.
- Toque em **Primeira página** ou **Última página** para pular para qualquer uma das extremidades do documento.
- Toque no número da página (por exemplo "3 / 120") para abrir uma grade de páginas e toque na página desejada. A grade abre perto da página em que você está.
- Use as **teclas de seta esquerda e direita** de um teclado externo.

### Zoom

- Toque em **Aumentar zoom** (+) ou **Diminuir zoom** (−) para mudar o tamanho da página.
- Toque em **Redefinir zoom** para devolver a página ao tamanho normal.
- Se você aumentar o zoom, passar a página e depois diminuir o zoom, o Theodia o devolve à página que você estava lendo.

## Pesquisar dentro de um PDF

1. Abra o PDF e toque no botão **Pesquisar** (lupa) na barra de ferramentas.
2. Digite o que você está procurando. Os resultados aparecem enquanto você digita, com o número da página e um trecho do texto ao redor.
3. Toque em um resultado para ir para essa página.

A pesquisa exige que o texto pesquisável do PDF esteja instalado. Se ainda não estiver, o botão Pesquisar fica acinzentado. Os PDFs instalados do repositório GitHub da comunidade incluem texto pesquisável; os PDFs que você mesmo importar não o têm até que ele seja adicionado.

## Sumário

Se o PDF tiver um sumário incorporado, o botão **Sumário** na barra de ferramentas o mostra como um esquema. Toque no título de uma seção para ir a essa página. As seções podem ser expandidas e recolhidas. Se o PDF não tiver sumário, o botão fica acinzentado.

## Favoritos em um PDF

1. Abra o PDF e toque no botão **Favorito** na barra de ferramentas.
2. Toque em **Marcar página** para salvar a página atual. O nome começa com o número da página — digite um nome se preferir — e depois toque em **Salvar**.
3. Toque em qualquer favorito da lista para ir à sua página.
4. Toque no **×** ao lado de um favorito para excluí-lo.

Os favoritos de PDFs são separados dos seus favoritos da Bíblia. Cada PDF mantém a própria lista.

## Ouvir um PDF

Se o texto pesquisável do PDF estiver instalado, o Theodia pode ler a página atual em voz alta:

1. Abra o PDF e toque no botão **Ouvir** (alto-falante) na barra de ferramentas.
2. Uma barra de controle aparece com **Reproduzir/Pausar**, **Retroceder**, **Avançar**, **Parar**, uma barra de progresso que você pode tocar para pular dentro da página, a velocidade de leitura e a voz.
3. Quando a página termina, a leitura continua automaticamente na página seguinte.

A voz e a velocidade são as mesmas usadas para a leitura da Bíblia — veja [Leitura em Voz Alta](theodia://help/tts) para saber como mudá-las.

## Copiar, compartilhar ou salvar o texto da página

Toque no botão **Visualização de texto** na barra de ferramentas para ver a página atual como texto simples. A partir daí você pode:

- **Copiar** — copia o texto da página para a área de transferência.
- **Compartilhar** — compartilha o texto da página por qualquer aplicativo do seu dispositivo.
- **Adicionar às notas** — abre um editor de notas com o texto da página, uma citação e um link de volta a esta página já preenchidos para você.

## Retomar a leitura

O Theodia lembra a última página que você visualizou e abre o PDF nela na próxima vez.

## Baixar PDFs do GitHub

No modo **Estudioso**, um botão **Baixar do GitHub** aparece na parte inferior da biblioteca. Ele se conecta ao repositório GitHub da comunidade de PDFs para que você possa instalar documentos PDF empacotados da mesma forma que instala Bíblias ou livros.

## Notas

- Os PDFs são armazenados na pasta de documentos privados do Theodia. Eles não são incluídos nos backups, então, se você mudar para um novo dispositivo, precisará importá-los novamente.
