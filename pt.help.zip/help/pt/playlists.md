---
title: Playlists
level: everyday
categories: [media, bookmarks]
summary: Como criar e usar playlists de passagens bíblicas, capítulos e livros para leitura, estudo ou leitura em voz alta contínua.
---

# 🎵 Playlists

Uma **playlist** no Theodia é uma lista de itens que você pode ouvir ou ler em sequência. Você pode criar playlists de versículos, capítulos ou livros e usar a função **Falar** para ouvir o conteúdo continuamente.

## Como abrir as playlists

- No menu inicial da tela **Início**, toque em **Playlist**.
- Ou vá para **Configurações** → **Playlist**.

## Como criar uma playlist

1. Abra a tela de playlists.
2. Toque no botão **Nova playlist** ou **+**.
3. Dê um nome à playlist.
4. Toque em **Salvar**.

## Como adicionar itens a uma playlist

Você pode adicionar itens de vários lugares:

- No **Leitor Bíblico**, toque no botão **Mais** ou pressione longamente uma passagem e escolha **Adicionar à playlist**.
- Em **Favoritos**, toque em **Adicionar à playlist** em um item.
- Em resultados de **Pesquisar**, toque em **Adicionar à playlist**.

Cada item na playlist guarda uma referência a uma passagem, capítulo ou livro.

## Como reproduzir uma playlist

1. Abra a playlist.
2. Toque no botão **Tocar**.
3. O Theodia começa a ler o primeiro item em voz alta.
4. Use os controles de mídia para pausar, avançar, voltar ou parar.

## Ordenando os itens

- Toque e segure um item na lista para arrastá-lo para uma nova posição.
- Ou toque em **Editar** e use os controles de reordenação.

## Removendo itens

- Deslize um item para o lado e toque em **Excluir**.
- Ou toque em **Editar**, selecione os itens e toque em **Remover**.

## Compartilhando uma playlist

Você pode compartilhar uma playlist com outras pessoas que usam o Theodia:

1. Abra a playlist.
2. Toque em **Compartilhar**.
3. Escolha como enviar o arquivo ou link.

## Usando playlists com leitura em voz alta

Playlists funcionam bem com a função **Falar**. O aplicativo lê cada item em sequência, passando automaticamente para o próximo quando termina.

Para ajustar a voz ou velocidade, veja [Leitura em Voz Alta](theodia://help/text-to-speech).

## Dicas

- Crie uma playlist para sua leitura devocional diária.
- Use playlists para ouvir capítulos completos enquanto dirige ou faz exercícios.
- Reordene os itens para seguir um plano de estudo personalizado.
