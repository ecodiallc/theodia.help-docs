---
title: Desenvolvimento de Plugins
level: advanced
categories: [plugins, development]
summary: Como criar plugins do Theodia usando Theoscript, incluindo comandos, ações de menu e lembretes.
---

# 🔌 Desenvolvimento de Plugins

Plugins permitem que você estenda o Theodia com comportamentos personalizados. Eles são escritos em **Theoscript**, uma linguagem de script leve projetada para o Theodia.

## O que um plugin pode fazer

Um plugin pode:

- Adicionar comandos à barra de comando.
- Adicionar ações ao menu do versículo.
- Criar lembretes personalizados.
- Ler e reagir a passagens bíblicas.
- Interagir com recursos instalados.
- Mostrar telas ou diálogos simples.

## Estrutura de um plugin

Um plugin é um arquivo de texto com a extensão `.theoscript` (ou um pacote que contém um script principal). Ele contém:

- Metadados no topo, como nome, versão e descrição.
- Funções registradas que respondem a eventos do aplicativo.

Exemplo mínimo:

```theoscript
plugin: MeuPlugin
version: 1.0.0
author: eu

onCommand("/hello") {
  showToast("Olá do Theodia!");
}
```

> A sintaxe exata pode variar. Consulte a referência do Theoscript e plugins de exemplo no repositório.

## Registrando comandos

Para adicionar um comando:

```theoscript
registerCommand("/meucomando", (args) => {
  const passage = args[0];
  openPassage(passage);
});
```

O comando aparecerá na barra de comando quando o usuário digitar `/meucomando`.

## Ações do menu do versículo

Para adicionar uma ação ao menu que aparece ao tocar no número de um versículo:

```theoscript
registerVerseAction("Copiar URL", (context) => {
  copyToClipboard(context.url);
});
```

## Lembretes

Plugins podem agendar lembretes:

```theoscript
scheduleReminder({
  id: "meu-lembrete",
  title: "Leitura diária",
  time: "08:00",
  days: ["monday", "tuesday", "wednesday", "thursday", "friday"],
  action: "open://bible/KJV/John/3"
});
```

Lembretes de plugins são armazenados localmente e funcionam offline.

## Contexto do aplicativo

Quando uma função de plugin é chamada, ela recebe um contexto que inclui:

- O versículo ou passagem atual.
- A Bíblia ativa.
- A URL ou caminho profundo atual.
- Os recursos instalados.

Use o contexto para tomar decisões ou preencher dados.

## Instalando um plugin

1. Coloque o arquivo `.theoscript` no dispositivo.
2. Abra **Configurações** → **Plugins**.
3. Toque em **Importar plugin** e selecione o arquivo.
4. O plugin será carregado e registrado.

## Depurando plugins

- Use `log()` ou `print()` no Theoscript para enviar mensagens ao console do aplicativo.
- Verifique a tela **Configurações** → **Plugins** → **Logs** para ver erros.
- Desative o plugin se ele causar falhas.

## Segurança

Plugins podem executar ações no aplicativo. Só instale plugins de fontes confiáveis. O Theodia executa plugins em um ambiente isolado, mas eles ainda podem interagir com seus dados locais.

## Recursos adicionais

- Veja [Plugins](theodia://help/plugins-overview) para uma visão geral.
- Veja [Theoscript](theodia://help/theoscript) para a linguagem de script.
- Veja [Configurações de Plugins](theodia://help/plugin-settings) para gerenciar plugins instalados.
