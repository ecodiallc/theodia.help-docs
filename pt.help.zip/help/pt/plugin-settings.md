---
title: Configurações de Plugins
level: advanced
categories: [plugins, settings]
summary: Como gerenciar plugins instalados no Theodia, incluindo permissões, configurações e exclusão.
---

# ⚙️ Configurações de Plugins

A tela **Plugins** em **Configurações** mostra todos os plugins instalados e permite gerenciá-los.

## Abrir as configurações de plugins

1. Abra **Configurações**.
2. Toque em **Plugins**.

## Lista de plugins

A lista mostra:

- Nome e versão de cada plugin.
- Se o plugin está **ativado** ou **desativado**.
- Indicadores de atualização disponível.

## Ativar ou desativar

Toque no interruptor ao lado de um plugin para ligar ou desligar. Plugins desativados não executam comandos nem mostram ações, mas permanecem instalados.

## Abrir configurações de um plugin

Toque no nome do plugin para abrir sua tela de detalhes. Lá você pode:

- Ver a descrição e autor.
- Ativar/desativar o plugin.
- Ajustar opções específicas do plugin, se houver.
- Ver permissões concedidas.
- Atualizar ou excluir o plugin.

## Permissões

Plugins podem precisar de permissões para:

- Agendar lembretes.
- Acessar seus favoritos, destaques ou notas.
- Ler recursos instalados.
- Executar comandos.

Você pode revisar e revogar permissões na tela do plugin.

## Logs

A tela de plugins pode ter uma opção para ver **logs**. Logs mostram mensagens enviadas pelo plugin, erros e eventos registrados. Use logs para diagnosticar problemas.

## Atualização

Se uma nova versão de um plugin estiver disponível, toque em **Atualizar**. O Theodia baixa a nova versão e substitui a antiga. Seus dados e configurações do plugin geralmente são preservados.

## Exclusão

Para remover um plugin:

1. Toque no plugin.
2. Toque em **Excluir** ou **Remover**.
3. Confirme.

A exclusão remove o plugin, seus comandos, ações e lembretes agendados por ele.

## Instalação manual

Você também pode instalar plugins a partir de um arquivo:

1. Toque em **Importar plugin** ou **Instalar do arquivo**.
2. Selecione o arquivo `.theoscript` no dispositivo.
3. Confirme a instalação.

Veja [Desenvolvimento de Plugins](theodia://help/plugin-development) para aprender a criar seus próprios plugins.

## Dicas

- Desative plugins que você não usa para economizar recursos.
- Verifique as permissões antes de instalar um plugin de terceiros.
- Use logs quando um plugin não se comportar como esperado.
