---
title: Plugins
level: advanced
categories: plugins
summary: O que são plugins no Theodia, para que servem e como instalar, ativar e gerenciar plugins.
---

# 🔌 Plugins

Plugins são extensões que adicionam funcionalidade ao Theodia. Eles permitem personalizar o aplicativo sem alterar o código principal.

## O que os plugins podem fazer

Plugins podem adicionar:

- Comandos personalizados na barra de comando.
- Ações extras no menu do versículo.
- Lembretes personalizados.
- Integrações com recursos ou serviços.
- Telas e diálogos simples.

## Onde encontrar plugins

Plugins podem vir de várias fontes:

- Incluídos no aplicativo ou em pacotes de recursos.
- Instalados do repositório do Theodia em **Configurações** → **Plugins** → **Instalar**.
- Importados de um arquivo `.theoscript` do seu dispositivo.
- Criados por você. Veja [Desenvolvimento de Plugins](theodia://help/plugin-development).

## Como instalar um plugin

1. Abra **Configurações**.
2. Toque em **Plugins**.
3. Toque em **Instalar plugin** ou **Importar arquivo**.
4. Selecione a fonte do plugin.
5. Confirme a instalação.

O plugin aparece na lista de plugins instalados.

## Como ativar ou desativar um plugin

1. Abra **Configurações** → **Plugins**.
2. Toque no plugin.
3. Ative ou desative a chave **Habilitado**.

Plugins desativados não aparecem nos menus nem respondem a comandos, mas permanecem instalados.

## Como atualizar um plugin

Quando uma nova versão de um plugin está disponível, a tela de plugins mostra uma indicação. Toque em **Atualizar** para substituir a versão antiga.

## Como remover um plugin

1. Abra **Configurações** → **Plugins**.
2. Toque no plugin.
3. Toque em **Excluir** ou **Remover**.
4. Confirme.

A remoção exclui o plugin e todas as ações que ele registrou.

## Configurações de um plugin

Alguns plugins têm opções que você pode ajustar. Toque em **Configurações** dentro da tela do plugin para ver as opções disponíveis.

Veja [Configurações de Plugins](theodia://help/plugin-settings) para mais detalhes.

## Segurança

- Instale plugins apenas de fontes confiáveis.
- Plugins podem ler dados do aplicativo e agendar lembretes.
- O Theodia executa plugins em um ambiente restrito, mas eles ainda têm acesso limitado ao seu dispositivo.

## Dicas

- Plugins são ótimos para automatizar tarefas de estudo.
- Se um plugin causar problemas, desative-o antes de removê-lo.
- Mantenha seus plugins atualizados para obter correções e novos recursos.
