---
title: Metas de Oração
level: everyday
categories: prayer
summary: Como definir e acompanhar metas de oração, como orar por um número de dias seguidos ou por um tempo total.
---

# 🎯 Metas de Oração

**Metas de oração** ajudam você a construir consistência. Você pode definir objetivos como orar todos os dias por uma semana ou passar um certo tempo em oração durante o mês.

## Como criar uma meta

1. Vá para a aba **Mais** → **Oração**.
2. Toque em **Metas**.
3. Toque em **Nova meta** ou **+**.
4. Escolha o tipo de meta:
   - **Sequência de dias** — orar por X dias seguidos.
   - **Tempo total** — orar por X minutos/horas no período.
   - **Rotinas concluídas** — completar X rotinas.
5. Defina o valor e o prazo.
6. Toque em **Salvar**.

## Acompanhando o progresso

Cada meta mostra:

- Quanto você já completou.
- Quanto falta.
- O prazo.
- Uma barra de progresso visual.

Toque em uma meta para ver detalhes e histórico.

## Tipos de metas

### Sequência de dias

Defina quantos dias seguidos você quer orar. O Theodia conta os dias em que você registrou alguma oração. Se você perder um dia, a sequência reinicia.

### Tempo total

Defina um tempo total de oração para um período (semana, mês, ano). O aplicativo soma todos os minutos de oração até atingir a meta.

### Rotinas concluídas

Defina quantas rotinas você quer completar. Cada rotina concluída conta um ponto.

## Lembretes de metas

Para cada meta, você pode ativar lembretes:

1. Abra a meta.
2. Toque em **Lembrete**.
3. Escolha o horário e os dias.
4. Toque em **Salvar**.

Os lembretes aparecem mesmo quando o aplicativo está fechado.

## Concluindo uma meta

Quando você atinge o objetivo, o Theodia mostra uma mensagem de parabéns. A meta é marcada como concluída e fica no histórico.

Você pode escolher:

- Arquivar a meta.
- Renovar a meta para um novo período.
- Excluir a meta.

## Dicas

- Comece com metas pequenas e alcançáveis.
- Use lembretes no mesmo horário todos os dias.
- Não desanime se perder um dia; comece novamente.
- Celebre quando atingir uma meta.

Veja [Rotinas de Oração](theodia://help/prayer-routines) e [Estatísticas de Oração](theodia://help/prayer-statistics) para complementar suas metas.
