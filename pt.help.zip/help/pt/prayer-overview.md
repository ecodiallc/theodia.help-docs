---
title: Oração no Theodia
level: everyday
categories: prayer
summary: Uma introdução aos recursos de oração do Theodia, incluindo rotinas, lembretes, estatísticas e metas.
---

# 🙏 Oração no Theodia

O Theodia ajuda você a manter uma vida de oração consistente. Ele oferece ferramentas para organizar orações, lembrar horários de oração e acompanhar seu progresso espiritual.

## Principais recursos de oração

- **Rotinas de Oração** — listas de orações para horários específicos do dia.
- **Lembretes de Oração** — notificações que lembram você de orar.
- **Estatísticas de Oração** — veja quanto tempo você passou orando e com que frequência.
- **Metas de Oração** — defina objetivos como orar por um certo número de dias seguidos.

## Como acessar a oração

1. Vá para a aba **Mais**.
2. Toque em **Oração**.

Ou use a barra de comando e digite `/pray`.

## Criando suas próprias orações

Você pode criar orações personalizadas:

1. Abra a tela de **Oração**.
2. Toque em **Nova oração** ou **+**.
3. Dê um título à oração.
4. Escreva o texto da oração.
5. Toque em **Salvar**.

As orações podem ser organizadas em pastas ou rotinas.

## Oração guiada

O Theodia pode guiá-lo através de uma oração passo a passo. Cada passo pode incluir:

- Uma breve instrução.
- Um texto bíblico para ler.
- Um momento de silêncio.
- Uma pergunta para reflexão.

Veja [Rotinas de Oração](theodia://help/prayer-routines) para aprender a criar rotinas guiadas.

## Dicas

- Comece com uma rotina simples, como manhã e noite.
- Use lembretes para construir o hábito de orar diariamente.
- Revise suas estatísticas semanalmente para se manter motivado.
- Combine oração com leitura bíblica para um tempo devocional completo.
