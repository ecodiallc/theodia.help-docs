---
title: Rotinas de Oração
level: everyday
categories: prayer
summary: Como criar rotinas de oração com passos, temporizador e lembretes.
---

# ⏰ Rotinas de Oração

Uma **rotina de oração** é uma sequência de passos de oração que você segue em um horário específico. Ela ajuda você a orar de forma organizada e consistente.

## Como criar uma rotina

1. Vá para a aba **Mais** → **Oração**.
2. Toque em **Rotinas**.
3. Toque em **Nova rotina** ou **+**.
4. Dê um nome à rotina, como "Manhã" ou "Antes de Dormir".
5. Toque em **Adicionar passo** para incluir orações, leituras, silêncios ou reflexões.
6. Toque em **Salvar**.

## Tipos de passos

Cada passo de uma rotina pode ser:

- **Oração** — recite uma oração salva.
- **Leitura bíblica** — leia um versículo ou passagem.
- **Silêncio** — um período de meditação silenciosa.
- **Reflexão** — uma pergunta ou instrução para refletir.
- **Louvor** — um hino ou cântico.

## Usando o temporizador

Você pode definir um tempo para cada passo:

1. Ao adicionar ou editar um passo, toque em **Temporizador**.
2. Escolha a duração.
3. Durante a rotina, o temporizador mostra quanto tempo resta.

O temporizador ajuda você a dedicar tempo adequado a cada parte da oração.

## Reordenando passos

- Toque e segure um passo para arrastá-lo.
- Ou toque em **Editar** e use os controles de ordenação.

## Agendando uma rotina

Para receber lembretes de uma rotina:

1. Abra a rotina.
2. Toque em **Lembrete**.
3. Escolha os dias e horários.
4. Toque em **Salvar**.

Os lembretes funcionam offline e aparecem mesmo quando o aplicativo está fechado.

## Iniciando uma rotina

1. Abra a rotina.
2. Toque em **Iniciar**.
3. Siga os passos na tela.
4. Toque em **Próximo** para avançar.
5. Toque em **Concluir** quando terminar.

## Dicas

- Mantenha as rotinas curtas no início para criar o hábito.
- Inclua silêncio e reflexão, não apenas palavras.
- Use leituras bíblicas curtas para ancorar sua oração na Palavra.
- Crie rotinas diferentes para momentos diferentes do dia.
