---
title: Estatísticas de Oração
level: everyday
categories: prayer
summary: Como visualizar e usar as estatísticas de oração para acompanhar sua consistência.
---

# 📊 Estatísticas de Oração

O Theodia registra seu tempo de oração e frequência para ajudá-lo a manter consistência. As estatísticas ficam no dispositivo e não são compartilhadas.

## Como ver suas estatísticas

1. Vá para a aba **Mais** → **Oração**.
2. Toque em **Estatísticas**.

## O que é rastreado

- **Tempo total de oração** — quanto tempo você passou orando.
- **Dias orados** — em quantos dias diferentes você orou.
- **Sequência atual** — quantos dias seguidos você orou.
- **Sequência mais longa** — seu maior período de oração consecutiva.
- **Rotinas concluídas** — quantas rotinas você completou.
- **Orações individuais** — quantas orações você fez fora de rotinas.

## Períodos de visualização

Você pode ver estatísticas por:

- Hoje
- Esta semana
- Este mês
- Este ano
- Todos os tempos

Toque nas abas na parte superior para mudar o período.

## Gráficos

A tela de estatísticas mostra gráficos simples, como:

- Um calendário com dias orados destacados.
- Um gráfico de barras do tempo de oração ao longo da semana.
- Um gráfico de linha da sequência de dias.

## Exportando estatísticas

Você pode exportar seus dados para si mesmo:

1. Toque em **Exportar**.
2. Escolha o formato (CSV ou JSON).
3. Escolha onde salvar o arquivo.

A exportação pode ser útil para reflexão pessoal ou para compartilhar com um mentor espiritual.

## Como os dados são coletados

O Theodia registra o tempo quando você:

- Inicia e conclui uma rotina de oração.
- Usa o temporizador de oração.
- Marca uma oração como concluída manualmente.

Apenas o tempo passado dentro do aplicativo é rastreado. Orações fora do aplicativo não são registradas automaticamente.

## Dicas

- Use as estatísticas para motivação, não para culpa.
- Tente manter uma sequência curta primeiro, depois aumente gradualmente.
- Revise suas estatísticas no fim de cada semana.
- Combine estatísticas com metas de oração para maior consistência.

Veja [Metas de Oração](theodia://help/prayer-goals) para definir objetivos.
