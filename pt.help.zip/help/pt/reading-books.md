---
title: Lendo Livros Integrados
level: beginner
categories: [content, read]
summary: Como ler os clássicos cristãos que acompanham o aplicativo.
---

# Lendo Livros Integrados

O Theodia vem com uma pequena biblioteca de livros cristãos. São clássicos que você pode ler no dispositivo.

## Como abrir a biblioteca

Toque na aba **Livros** na parte inferior da tela. Você verá uma lista dos livros da sua biblioteca.

## Como ler um livro

1. Toque no título do livro.
2. O livro abre no primeiro capítulo.
3. Use os botões **Anterior** e **Próximo** na parte superior para mover-se entre os capítulos.

## Como ir a um capítulo

Toque no nome do capítulo na parte superior da tela. Uma lista de capítulos aparece. Escolha um para ir até ele.

## Como mudar o tamanho da fonte

Abra **Configurações** → **Aparência** e escolha um tamanho de fonte. O tamanho do texto muda em todo o aplicativo, inclusive nos livros.

## Como adicionar um favorito em um livro

Toque no ícone de **estrela** no canto superior direito. O capítulo atual é salvo. Toque na aba **Favoritos** para ver suas páginas salvas.

## Como ouvir um livro

Toque no ícone de **alto-falante** no canto superior direito. O aplicativo lê o capítulo em voz alta. Toque novamente para parar.

## Quais livros estão disponíveis?

A biblioteca tem clássicos como:

- O Peregrino
- A Imitação de Cristo
- Prática da Presença de Deus
- O Hinário

A lista de livros pode crescer com o tempo. Atualizações do aplicativo podem adicionar mais.

## Dicas

- Os livros ficam armazenados no dispositivo. Não é necessário internet.
- Os livros não são sincronizados com a nuvem.
