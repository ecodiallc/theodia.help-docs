---
title: Encontrando Recursos no GitHub
level: everyday
categories: resources
summary: Pesquise todos os repositórios do GitHub que o aplicativo conhece de uma vez, e instale o que encontrar.
---

# Encontrando Recursos no GitHub

O Theodia mantém uma lista de repositórios do GitHub que publicam recursos — Bíblias, comentários, livros, devocionais, playlists, pacotes de oração e mais. **Pesquisar Repositórios do GitHub** pesquisa todos eles de uma vez, para que você não precise abrir cada aba e navegar separadamente.

> A seção GitHub das Configurações está disponível apenas no **modo Estudioso**. Para ativá-la, vá em **Configurações → Modo de Usuário → Estudioso**.

## Como pesquisar

1. Abra **Configurações**.
2. Toque em **Pesquisar Repositórios do GitHub**.
3. Digite uma palavra na caixa de pesquisa. O aplicativo procura essa palavra no **nome** e na **descrição** de cada recurso em cada repositório.

Algumas coisas para saber sobre a pesquisa:

- **Cada palavra tem que corresponder.** Pesquisar `morning evening` só encontra recursos cujo nome ou descrição contenham *ambas* as palavras.
- **Maiúsculas não importam.** `Morning` e `morning` encontram os mesmos recursos.
- **A melhor correspondência vem primeiro.** Um recurso cujo nome *começa* com a sua pesquisa é mostrado antes de um que só a menciona na descrição.

## Filtros

Toque na barra de filtros acima dos resultados para estreitar ainda mais a lista. Há dois filtros, e eles funcionam juntos:

- **Autor** — apenas recursos desse autor.
- **Tradição** — apenas recursos dessa tradição.

Toque em um filtro novamente para limpá-lo, ou toque em **Limpar filtros** para redefinir ambos.

## Instalar a partir de um resultado

Cada resultado mostra o nome do recurso, que tipo de recurso é, quem o criou e de qual repositório ele vem. À direita da linha há um único botão:

- **Instalar** — o recurso ainda não está no seu dispositivo.
- **Atualizar** — uma versão mais nova está disponível. O aplicativo pede que você confirme primeiro, porque atualizar remove a cópia antiga junto com quaisquer notas, destaques ou favoritos que apontem para ela.
- **Abrir** — o recurso já está instalado; tocá-lo leva você à tela em que o usa.

Toque em **Atualizar lista** na parte superior para buscar a lista mais recente do GitHub imediatamente. O aplicativo atualiza a lista sozinho uma vez por dia, então uma atualização manual só é necessária quando você sabe que algo novo foi publicado.

## Pesquisar sem conexão

O aplicativo mantém uma cópia da lista no seu dispositivo, então a pesquisa funciona mesmo quando você está offline. Se o aplicativo não conseguir alcançar o GitHub para atualizar a lista, um banner na parte superior avisa que você está vendo os resultados em cache.

## Se uma pesquisa não encontrar nada

- Tente uma palavra única mais curta.
- Verifique se nenhum filtro **Autor** ou **Tradição** ainda está aplicado — o botão **Limpar filtros** aparece sempre que um estiver.
- Alguns repositórios publicam seus recursos em um idioma diferente do nome do recurso, então pesquisar por uma palavra traduzida pode não encontrá-los.
