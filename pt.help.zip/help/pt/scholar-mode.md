---
title: Modo Estudioso
level: advanced
categories: [layout, read, study]
summary: O modo de estudo mais aprofundado do Theodia, desbloqueando comentários, léxicos, referências cruzadas, ferramentas de IA e o Menu Lançador.
---

# Modo Estudioso

> **Modo:** O modo Estudioso está disponível apenas quando seu modo de usuário está definido como **Estudioso**. Troque de modo em **Configurações** → **Modo de Usuário do Aplicativo**.

O modo Estudioso desbloqueia todas as ferramentas de estudo do Theodia. Ele é construído sobre o Modo de Estudo, então você ainda tem o menu do versículo, Bíblias paralelas, favoritos, destaques e notas — mais as ferramentas avançadas listadas abaixo.

## Como abrir o modo Estudioso

O modo Estudioso não é uma tela separada. É um conjunto de ferramentas extras que aparecem dentro do leitor e da navegação existentes quando seu modo de usuário está definido como Estudioso.

1. Abra **Configurações**.
2. Toque em **Modo de Usuário do Aplicativo**.
3. Escolha **Estudioso**.

A mudança entra em vigor imediatamente. Menus e botões que estavam ocultos agora aparecem.

## Ferramentas extras do leitor

Quando você abre um capítulo no [Modo de Estudo](theodia://help/study-mode), o modo Estudioso adiciona estas ferramentas ao menu do versículo:

- **Comentário de IA** (◈) — pede ao assistente de IA para escrever uma nota de estudo para este versículo. (Não disponível em todas as regiões.)
- **Informação da Palavra** (?) — abre uma entrada de léxico para a palavra original em hebraico ou grego por trás do versículo. Veja o guia [Comentários e Léxicos](theodia://help/commentaries-and-lexicons).
- **Dicionário** (📖) — consulta palavras gerais da Bíblia nos recursos de dicionário instalados. Veja o guia [Dicionário Bíblico](theodia://help/dictionary).

Essas ferramentas precisam que recursos estejam instalados (comentários, léxicos, arquivos de dicionário). Se uma ferramenta estiver acinzentada ou mostrar "não encontrado", abra **Configurações** → **Gerenciar Recursos** e adicione o recurso necessário.

## Navegação extra

### Aba extra na barra inferior

A barra inferior ganha uma aba extra:

- 💻 **IA** — abre o assistente de IA (somente se você tiver ativado a IA em Configurações). Esta aba fica à direita de Notas Bíblicas.

### Itens extras no menu principal

O menu principal inclui uma entrada **Assistente de IA** nas mesmas condições.

## O Menu Lançador

O modo Estudioso ativa o **Menu Lançador**, uma forma rápida de ir a versículos recentes, executar comandos e trocar layouts da Bíblia sem sair da tela atual. Veja o guia [Menu Lançador](theodia://help/launcher-menu) para saber como usá-lo.

## Quando usar o modo Estudioso

- Você quer o assistente de IA, comentários ou consultas no idioma original enquanto lê.
- Você quer o Menu Lançador para navegação rápida de versículos e chat com IA.
- Você está estudando uma passagem a fundo e precisa de todas as ferramentas a um toque.

## Trocando para um modo mais leve

Se você quer um leitor mais simples sem as ferramentas avançadas, troque para o modo **Padrão** em **Configurações** → **Modo de Usuário do Aplicativo**. O modo Padrão mantém favoritos, destaques, notas e o Modo de Estudo, mas oculta IA, comentários, léxicos e o Menu Lançador.

Se você quer a experiência de leitura mais limpa possível, abra um capítulo no [Modo de Foco](theodia://help/focus-mode).

Seus favoritos, destaques e notas nunca são excluídos quando você muda de modo; eles apenas ficam ocultos até você voltar a um modo que os suporte.

## Ajuda e dúvidas

Se uma ferramenta estiver faltando ou mostrar um erro, veja o guia [Problemas Comuns](theodia://help/common-problems). Se você é novo no Theodia, o guia [Lendo Seu Primeiro Capítulo](theodia://help/first-read) o conduz pelos conceitos básicos passo a passo.
