---
title: Pesquisando na Bíblia
level: everyday
categories: [study, read]
summary: Como encontrar versículos por palavra, frase ou referência.
---

# Pesquisando na Bíblia

A barra de pesquisa ajuda a encontrar versículos rapidamente. Você pode pesquisar por uma palavra, uma frase ou uma referência bíblica.

## Como iniciar uma pesquisa

1. Toque na aba **Pesquisar** na parte inferior da tela.
2. Digite o que quer encontrar.
3. Toque em **Pesquisar** no teclado.

Os resultados aparecem como uma lista de versículos. Cada resultado mostra o livro, capítulo e versículo, além do texto do versículo.

## Pesquisar por combinações de palavras

Quando você digita mais de uma palavra, como `amor alegria`, o aplicativo encontra versículos que contêm **ambas** as palavras. Isso é uma pesquisa **E** — todas as palavras devem aparecer no versículo. Ele **não** usa lógica **OU** (versículos com qualquer uma das palavras).

Para pesquisar versículos que contenham uma palavra ou outra, use a palavra-chave `OR` explicitamente: `amor OR alegria`.

## Pesquisar por palavra

Digite uma única palavra, como `amor` ou `misericórdia`. O aplicativo mostra todos os versículos da Bíblia que contêm essa palavra.

## Pesquisar por frase

Digite duas ou três palavras entre aspas, como `"não temas"`. O aplicativo mostra versículos que contêm exatamente essa frase.

## Filtrar os resultados

Depois de uma pesquisa, os resultados são filtrados pelas traduções da Bíblia instaladas. Para restringir mais, abra a aba **Bíblia** e olhe uma tradução específica — as pesquisas são executadas nas traduções que você tem.

## Dicas para pesquisas melhores

- Use palavras curtas. Pesquisar por `amor` encontra mais versículos do que pesquisar por `amando`.
- Aspas ao redor de uma frase tornam a pesquisa exata.
- O aplicativo só pesquisa nas traduções da Bíblia instaladas.
- Para ir a um versículo específico por referência (por exemplo, `João 3:16`), use a caixa **Comando** na tela inicial em vez da aba Pesquisar.

## Histórico de pesquisa

O aplicativo lembra suas pesquisas mais recentes. Quando você abre a aba **Pesquisar**, a lista mostra suas pesquisas recentes na parte superior. Toque em uma para executá-la de novo. Para limpar a lista, toque em **Limpar tudo** na parte superior das pesquisas recentes.
