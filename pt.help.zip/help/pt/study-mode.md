---
title: Modo de Estudo
level: everyday
categories: [layout, read]
summary: O leitor completo da Bíblia no Theodia, com ferramentas de estudo como comentário, referências cruzadas, léxico e notas.
---

# Modo de Estudo

> **Modo:** O Modo de Estudo está disponível nos modos **Padrão** e **Estudioso**. O modo Leitor abre capítulos no Modo de Foco. Você pode trocar de modo em **Configurações** → **Modo de Usuário do Aplicativo**.

O Modo de Estudo é o leitor principal da Bíblia no Theodia. Ele tem todas as ferramentas de estudo integradas: comentário, referências cruzadas, consultas de palavras, traduções paralelas, notas e mais.

O Modo de Foco é um leitor mais simples, sem ferramentas de estudo. Veja o guia [Modo de Foco](theodia://help/focus-mode) se você quiser apenas texto limpo. Este guia é sobre o Modo de Estudo.

## Como abrir o Modo de Estudo

Há várias formas de abrir um capítulo no Modo de Estudo:

- Toque na aba **Bíblia** na parte inferior da tela. Escolha uma tradução, um livro e um capítulo.
- Toque em um versículo nos resultados da **Pesquisa**.
- Toque em um favorito na aba **Favoritos**.
- No Modo de Foco, toque no botão 📖 na parte superior da tela para trocar para o Modo de Estudo.

## Lendo o capítulo

O capítulo abre com os versículos em ordem. Na parte superior da tela há botões para as ações mais comuns. Na parte inferior há uma barra de status.

- **Deslize para a esquerda** para ir ao próximo capítulo.
- **Deslize para a direita** para ir ao capítulo anterior.
- **Toque em um versículo** para abrir o menu do versículo com ferramentas de estudo (veja abaixo).
- **Toque em um número Strong em um versículo** (por exemplo, G1234 ou H1234) para abrir uma consulta rápida de léxico para aquela palavra.

Se você tiver uma tradução paralela ativada, uma segunda cópia do capítulo aparece abaixo da principal, na tradução escolhida. Veja **Lendo duas traduções ao mesmo tempo** abaixo.

## O menu do versículo

Quando você toca em um versículo, um menu se abre com o título "Livro Capítulo:Versículo". As ferramentas que você vê dependem do seu modo de usuário.

### Ferramentas no modo Padrão e Estudioso

- **Favorito** (★) — salva o versículo para encontrá-lo de novo. Toque novamente para remover o favorito. O primeiro toque adiciona. Veja o guia [Salvando Versículos como Favoritos](theodia://help/bookmarks).
- **Destacar** (□) — colore o versículo para destacá-lo. Toque para abrir o seletor de cores. Toque na mesma cor novamente para remover o destaque. Veja o guia [Destacando Versículos](theodia://help/highlights).
- **Falar** (🔊) — faz o versículo ser lido em voz alta usando a voz de TTS do dispositivo. Não é mostrado para Bíblias interlineares. Veja o guia [Leitura em Voz Alta](theodia://help/tts) para saber como usar e como escolher uma voz.
- **Copiar** (⎘) — coloca o texto do versículo na área de transferência para colar onde quiser.
- **Comparar** (⇄) — abre um painel que mostra o mesmo versículo em todas as traduções instaladas. Toque em uma tradução no painel para ler o versículo naquela tradução. Veja o guia [Comparando Traduções](theodia://help/compare-translations).
- **Referências Cruzadas** (↗) — abre uma lista de versículos relacionados do banco de dados de referências cruzadas. Veja o guia [Referências Cruzadas](theodia://help/cross-references).
- **Adicionar/Editar Nota Bíblica** (✎) — escreve sua nota particular ligada ao versículo. Veja o guia [Escrevendo Notas](theodia://help/notes).

### Ferramentas somente no modo Estudioso

- **Comentário de IA** (◈) — pede ao assistente de IA para escrever uma nota de estudo para este versículo. (Não disponível em todas as regiões.)
- **Informação da Palavra** (?) — abre uma entrada de léxico para a palavra original em hebraico ou grego por trás do versículo. Veja o guia [Comentários e Léxicos](theodia://help/commentaries-and-lexicons).
- **Dicionário** (📖) — consulta palavras gerais da Bíblia nos recursos de dicionário instalados. Veja o guia [Dicionário Bíblico](theodia://help/dictionary).

Algumas ferramentas precisam de recursos extras instalados. Se uma ferramenta estiver acinzentada ou mostrar "não encontrado", abra **Configurações** → **Gerenciar Recursos** e adicione o recurso necessário.

## Botões na parte superior da tela

Acima do texto do capítulo há uma fileira de ícones. São as ações rápidas:

- **Versão da Bíblia** — toque no nome da tradução (por exemplo, "KJV") para trocar para outra tradução.
- **Livro** — toque no nome do livro para ir a outro livro.
- **Capítulo** — toque no número do capítulo para ir a outro capítulo.
- **Abrir na IA** (🤖) — envia o capítulo atual para o assistente de IA com sua pergunta. (Somente modo Estudioso.)
- **Modo de Foco** (📖) — troca para o Modo de Foco para leitura limpa.
- **Bíblias Paralelas** (🔵 / ⚪) — toque para ligar ou desligar traduções paralelas. Quando ativado, o mesmo capítulo é mostrado nas traduções paralelas escolhidas abaixo do texto principal. Quando desativado, só a tradução principal é mostrada. Veja **Lendo várias traduções ao mesmo tempo** abaixo.
- **Ouvir** — faz o capítulo inteiro ser lido em voz alta. Veja o guia [Leitura em Voz Alta](theodia://help/tts).
- **Mais** — abre ações extras do capítulo (nota bíblica de capítulo, comentário de capítulo, compartilhar etc.).

## Lendo várias traduções ao mesmo tempo

Você pode mostrar até quatro traduções extras ao lado da principal. Isso é chamado de **visualização paralela**.

1. Abra **Configurações**.
2. Ative **Bíblias Paralelas**.
3. Toque em **Adicionar Bíblia Paralela** e escolha uma tradução.
4. Repita para adicionar mais. Você pode ter até quatro traduções paralelas.

Quando a visualização paralela está ativa, cada versículo do capítulo mostra sua tradução principal primeiro, seguido do mesmo versículo em cada tradução paralela. Isso facilita comparar como diferentes tradutores tratam um versículo difícil sem sair do capítulo.

Você pode salvar sua configuração paralela atual como uma **predefinição**. Toque no botão de salvar ao lado das traduções selecionadas, dê um nome, e ela se torna uma opção de troca rápida. Toque em qualquer predefinição depois para carregar aquela combinação instantaneamente. Pressione longamente uma predefinição para excluí-la.

Você também pode comparar apenas um versículo de cada vez com a ferramenta **Comparar** (⇄) no menu do versículo. Ela abre um painel mostrando o versículo em todas as traduções instaladas.

## Subtítulos

Algumas traduções têm títulos de seção embutidos (por exemplo, "O Sermão do Monte"). Se sua tradução os tiver, você pode mostrar ou ocultá-los com a configuração **Mostrar subtítulos** em **Configurações**. Os subtítulos aparecem como pequenos títulos cinzas entre os versículos.

## A nota do capítulo

Uma nota de capítulo é uma única nota ligada ao capítulo inteiro, não a um versículo específico. É útil para um pensamento geral sobre o capítulo.

Para abrir a nota do capítulo:

1. Toque no botão **Mais** na parte superior da tela.
2. Toque em **Nota do capítulo**.
3. Escreva sua nota. Toque em **Salvar**.

A nota de capítulo é salva com o capítulo. Ela aparece sempre que você abre aquele capítulo.

## Destaques de pesquisa

Se você chegou ao capítulo a partir de uma pesquisa, suas palavras de pesquisa são destacadas em amarelo no texto do versículo. Isso facilita ver por que um versículo correspondia.

Você também pode executar uma pesquisa novamente em um capítulo que está lendo. Abra a aba **Pesquisar** e digite uma palavra. Os resultados permitem tocar e voltar direto ao capítulo com as correspondências destacadas.

Bíblias interlineares (MIB — Marvel Interlinear Bible — e OHGB) sempre abrem no Modo de Estudo porque precisam do layout de nível de palavra.

## Trocando para o Modo de Foco para um único capítulo

De qualquer capítulo no Modo de Estudo, toque no botão 📖 na parte superior. O mesmo capítulo abre no Modo de Foco com todos os menus ocultos. Toque no botão 📖 na barra inferior para voltar ao Modo de Estudo.

## Quando usar o Modo de Estudo

O Modo de Estudo é a escolha certa quando você quer:

- **Ler e estudar ao mesmo tempo.** Todas as ferramentas estão a um toque.
- **Consultar uma palavra que não conhece.** Toque em um número Strong no versículo para uma entrada rápida de léxico.
- **Comparar traduções.** Use a ferramenta Comparar no menu do versículo ou ative a visualização paralela.
- **Ver como um versículo se conecta com o resto da Bíblia.** Use Referências Cruzadas.
- **Fazer anotações enquanto lê.** O menu do versículo tem uma opção rápida de adicionar nota.

Para leitura longa e sem distrações, troque para o Modo de Foco.

## Trocando para o Modo de Foco

De qualquer capítulo no Modo de Estudo, toque no botão 📖 na parte superior. O mesmo capítulo abre no [Modo de Foco](theodia://help/focus-mode) com os menus e ferramentas de estudo ocultos. Toque no botão 📖 na barra inferior para voltar ao Modo de Estudo. Para uma descrição completa do que o Modo de Foco faz, veja o guia [Modo de Foco](theodia://help/focus-mode).

## Ajuda e dúvidas

Se uma ferramenta estiver faltando ou mostrar um erro, veja o guia [Problemas Comuns](theodia://help/common-problems). Se você é novo no Theodia, o guia [Lendo Seu Primeiro Capítulo](theodia://help/first-read) o conduz pelos conceitos básicos passo a passo.
