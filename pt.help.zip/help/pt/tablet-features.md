---
title: Recursos do Tablet
level: everyday
categories: [layout, tablet]
summary: Como o layout do Theodia se adapta a tablets e telas maiores, com visualizações divididas, painéis laterais e modos de leitura em dois painéis.
---

# 📱 Recursos do Tablet

O Theodia foi projetado para aproveitar telas maiores em tablets. Em um tablet (ou qualquer dispositivo com largura superior a cerca de 700 pixels), o aplicativo muda automaticamente para um layout de duas colunas em muitos lugares.

> **Modo:** Os recursos descritos aqui só aparecem se seu modo de usuário atual os suportar. Por exemplo, painéis laterais de comentário e chat de IA só estão disponíveis no modo Estudioso. Visualizações divididas de favoritos, destaques e notas exigem Padrão ou Estudioso. O Modo de Foco mostra apenas leitura em coluna única e limpa. Você pode trocar de modo em **Configurações** → **Modo de Usuário do Aplicativo**.

## Menu do versículo no leitor

Quando você toca no número de um versículo (ou pressiona longamente o texto do versículo), o **menu do versículo** aparece como um **cartão centralizado** sobre um fundo escuro.

- Os botões **Copiar** e **Compartilhar** ficam sempre visíveis na parte superior do menu.
- **Favoritos** e **Destaques** são mostrados com seu estado atual.
- **Comentário**, **Dicionário** e **Comparar** abrem a partir do menu. Em um tablet, essas ferramentas podem aparecer em um painel lateral ou cartão largo depois de selecionadas.
- Toque no fundo ou na seta de fechar para dispensar o menu.

## Painel de Comentário de Versículo

A ferramenta **Comentário** abre um **painel lateral dedicado** em um tablet:

- O texto do comentário aparece ao lado do texto bíblico.
- Você pode rolar o comentário independentemente da Bíblia.
- Toque no **X** ou deslize para fechar.
- Um **ícone de livro** na parte superior do painel permite trocar as fontes de comentário.
- Um **ícone de capítulo** permite visualizar o comentário de nível de capítulo.

Em um celular, o comentário abre como um modal em tela cheia.

## Comentário de Capítulo

O **Comentário de Capítulo** é acessado pelo botão **Mais** na parte superior da tela, não pelo menu do versículo. Em um tablet, ele abre como um painel lateral, assim como o Comentário de Versículo, para que você possa ler o comentário e o texto bíblico juntos.

## Aba Comparar

A aba **Comparar** (no menu do versículo) abre como um **painel lateral** em um tablet. Ela mostra o versículo selecionado em todas as versões paralelas que você ativou. Você pode tocar em qualquer versão para ir àquela passagem no leitor.

## Popup de Dicionário / Strong

A ferramenta **Dicionário** (menu do versículo → Dicionário) abre como um cartão largo em um tablet. Ela mostra a palavra em grego ou hebraico, sua transliteração, definição e número de Strong. Toque no botão **Concordância** para ver todas as ocorrências daquela palavra na Bíblia.

## Toque em uma palavra para abrir seu Léxico

No painel lateral **Informação da Palavra** em um tablet, cada cartão de palavra que tem um número Strong é tocável. Toque no cartão para abrir o painel **Léxico** para aquela palavra diretamente. O painel de Léxico substitui o painel de Informação da Palavra, para que você possa continuar estudando sem fechar o leitor.

Em um celular, os cartões de Informação da Palavra não são tocáveis porque a tela é pequena demais para dois painéis.

## Bíblias paralelas lado a lado

Em Configurações, toque em **Bíblias Paralelas** e escolha até três versões. Em um tablet, as versões aparecem como **painéis verticais** lado a lado:

- Cada painel rola independentemente.
- Você pode tocar no número de um versículo para abrir um painel lateral com ferramentas.
- A aba **Comparar** mostra todos os versículos selecionados em um só lugar.
- Toque no **X** de qualquer painel para fechá-lo e voltar à visualização de coluna única.
- Toque no ícone **Bíblias Paralelas** (🔵 / ⚪) na barra de ícones superior para ligar ou desligar a visualização paralela sem abrir Configurações.

Em um celular, as versões paralelas são mostradas uma abaixo da outra (verticalmente) em vez de lado a lado. O mesmo ícone de alternância funciona nos celulares também.

## Visualização dividida de Favoritos e Destaques

Em um tablet, as abas **Favoritos** e **Destaques** usam um layout mestre-detalhe:

- **Lado esquerdo** — a lista de favoritos ou destaques.
- **Lado direito** — tocar em um item abre um painel de pré-visualização com o texto do versículo ou passagem.

Você pode folhear seus itens salvos e pré-visualizá-los sem sair da aba. Em um celular, tocar em um item navega para a tela do leitor.

## Visualização dividida de Notas

A aba **Notas Bíblicas** em um tablet mostra sua lista de notas à esquerda e a nota selecionada à direita. Tocar em uma nota a abre em um painel lateral, para que você possa folhear várias notas em sequência sem sair da lista. Criar ou editar uma nota também usa um painel lateral.

## Pesquisa dividida

Em um tablet, a aba **Pesquisar** mostra o formulário de pesquisa à esquerda e os resultados à direita assim que você executa uma pesquisa. Você pode refinar sua consulta e ver os resultados atualizarem sem trocar de tela. Em um celular, os resultados da pesquisa abrem em uma tela separada.

## Barra lateral de categorias de Configurações

A tela **Configurações** em um tablet mostra uma lista de categorias à esquerda (IA, Aparência, Backup, Bíblias etc.). Toque em uma categoria para ir diretamente às suas configurações à direita. Apenas a categoria selecionada fica expandida, então você nunca precisa rolar por toda a lista de configurações.

## Navegação bíblica em tablets

As telas **Lista de Bíblias**, **Livros da Bíblia** e **Capítulos da Bíblia** permanecem em coluna única em tablets, mas usam alvos de toque maiores, grades mais largas e espaçamento mais generoso, para que o conteúdo seja mais fácil de ler e tocar. Elas não usam layout dividido porque cada etapa precisa da largura total para mostrar sua lista ou grade claramente.

## Paisagem e retrato

Girar o tablet ajusta o layout automaticamente. Em **paisagem**, os painéis laterais têm bastante espaço. Em **retrato**, os painéis ficam mais estreitos, mas ainda permanecem ao lado do texto.

## Chat de IA do versículo selecionado

O chat de **IA** abre no painel lateral do menu do versículo. Ele mostra uma interface de conversação onde você pode fazer perguntas sobre o versículo selecionado. A resposta da IA aparece no painel, e você pode continuar a conversa sem sair do leitor.

## Barra lateral de conversas na tela de IA

Na aba **IA** em um tablet, a lista de conversações fica sempre visível como uma barra lateral esquerda persistente. Você pode trocar entre chats sem abrir um menu. O botão **Novo chat** também fica sempre visível. Em um celular, a lista de conversações é uma gaveta popup.

## O que permanece igual

Nem toda tela se divide em dois painéis. As seguintes telas permanecem em coluna única em tablets:

- **Lista de Bíblias** — lista de versões da Bíblia (largura total)
- **Livros da Bíblia** — grade de livros e seções (largura total)
- **Capítulos da Bíblia** — grade de capítulos (largura total)
- **Configurações** — páginas individuais de configurações (largura total)
- **Ajuda** — artigos de ajuda (largura total)

## Resumo

Em um tablet, você obtém:

- **Bíblias paralelas** em painéis verticais lado a lado
- **Comentário** em painéis laterais persistentes
- **Comparar** e **Dicionário** em cartões largos
- **Léxico** a partir de um toque em qualquer cartão de Informação da Palavra
- **Favoritos, Destaques, Notas, Devocionais, Livros, Configurações** em visualizações mestre-detalhe
- **Pesquisa** com resultados ao lado do formulário de pesquisa
- **Paisagem** e **retrato** suportados com mudanças automáticas de layout

Em um celular, tudo usa a navegação tradicional de coluna única com afunilamento. O aplicativo detecta a largura da tela ao iniciar e escolhe o layout correto automaticamente.
