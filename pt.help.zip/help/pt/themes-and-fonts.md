---
title: Mudando Tema e Fonte
level: everyday
categories: settings
summary: Como mudar a aparência do aplicativo.
---

# Mudando Tema e Fonte

O Theodia permite mudar a aparência do aplicativo. Você pode escolher um tema (claro ou escuro) e um tamanho de fonte.

## Como abrir as configurações de aparência

1. Abra **Configurações**.
2. Toque em **Aparência**.

## Como mudar o tema

Na seção **Aparência**, você vê dois botões de tema:

- **Padrão** — fundo claro com texto escuro. Bom para o dia.
- **Escuro** — fundo escuro com texto claro. Bom para a noite e economiza bateria.

Toque em um tema para aplicá-lo. A mudança é instantânea.

## Como mudar o tamanho da fonte

Na seção **Aparência**, toque em um dos botões de tamanho: **---**, **--**, **-**, **Normal**, **+**, **++**, **+++**. O texto fica menor ou maior em todo o aplicativo. Escolha o tamanho mais fácil de ler.

## Dicas

- O tema escuro economiza bateria em celulares com tela OLED.
- Se o texto estiver pequeno demais para ler, aumente o tamanho da fonte no aplicativo, não no dispositivo. A configuração do aplicativo é mais precisa.
- Para leituras longas, experimente o tema escuro e uma fonte maior.
- [Ative o tema deserto](theodia://unlock-desert)
