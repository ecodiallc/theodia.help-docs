---
title: Recursos do Theodia
level: beginner
categories: welcome
summary: Uma visão rápida do que torna o Theodia especial e como ele ajuda você a estudar a Bíblia.
---

# Recursos do Theodia

O Theodia foi construído para ser um companheiro completo de estudo bíblico. Veja o que o faz se destacar.

## Funciona offline

Tudo funciona sem internet. Bíblias, comentários, léxicos, livros e devocionais ficam armazenados no seu dispositivo. Você pode ler, pesquisar e estudar em qualquer lugar — em um avião, em uma região remota ou em qualquer lugar sem sinal.

## Focado em privacidade

Seus dados ficam com você. Notas, destaques, favoritos e histórico de leitura são armazenados localmente no seu dispositivo. Nenhuma conta é necessária, e nada é enviado a um servidor, a menos que você escolha usar o assistente de IA opcional.

## Suporte a tablets

O Theodia foi projetado para celulares e tablets. Em uma tela maior, você tem mais espaço para leitura, visualizações de Bíblias paralelas e um layout que aproveita o espaço extra.

## Recursos instaláveis

Você não está limitado ao que vem com o aplicativo. Você pode adicionar mais versões da Bíblia, comentários, léxicos, livros e devocionais. Os recursos estão disponíveis na página do GitHub do projeto e podem ser instalados diretamente no aplicativo.

## Assistente de IA

O assistente de IA opcional ajuda você a entender versículos, explicar o contexto e responder perguntas. Ele só fica ativo se você o ligar. Por padrão, ele se conecta a um modelo remoto que você fornece por meio de um endpoint e de uma chave de API que você configura. Na primeira vez que você usar a IA, o aplicativo pede sua permissão e mostra exatamente o que é enviado.

## Leitura de Bíblias paralelas

Leia até quatro versões da Bíblia ao mesmo tempo. Quando você abre um capítulo, sua tradução principal aparece primeiro, e cada versículo é seguido pelo mesmo versículo nas traduções paralelas que você escolheu. Compare palavras, estude as diferenças e obtenha uma visão mais completa do texto. Salve suas combinações favoritas como predefinições e alterne entre elas rapidamente.

## Pesquisa de texto completo

Pesquise em qualquer versão da Bíblia. Procure palavras, frases ou correspondências parciais. Você também pode limitar a pesquisa a um intervalo de livros.

## Referências cruzadas

Toque em uma referência para ir direto àquela passagem. As referências cruzadas vêm incorporadas e funcionam em toda a Bíblia.

## Léxico e números de Strong

Toque em um número de Strong para ver a definição da palavra original em grego ou hebraico. Entradas de léxico estão incluídas para um estudo de palavras mais aprofundado.

## Favoritos e destaques

Salve versículos com favoritos e marque-os com cores. Tudo é armazenado localmente e permanece salvo entre as sessões.

## Notas

Escreva seus próprios pensamentos ao lado de qualquer versículo. As notas ficam vinculadas ao versículo e são fáceis de encontrar depois.

## Devocional diário

Comece o dia com uma leitura devocional curta. O aplicativo inclui devocionais que abrem automaticamente na entrada de hoje.

## Livros cristãos

Leia literatura cristã clássica dentro do aplicativo. Os livros são formatados para leitura fácil e incluem um sumário para navegação rápida.

## Leitura de PDFs

Importe seus próprios documentos PDF e leia-os offline, organizados em categorias. O leitor oferece pesquisa, sumário, favoritos, zoom e leitura em voz alta. Você também pode instalar coleções de PDFs empacotadas do repositório da comunidade.

## Vários idiomas

O Theodia oferece suporte a muitos idiomas, tanto para a interface do aplicativo quanto para o conteúdo bíblico. Troque o idioma nas configurações para estudar no seu idioma preferido.

## Modo escuro e temas

Escolha entre o modo claro ou o escuro, ou escolha um tema do seu agrado. O conforto de leitura é importante, principalmente com pouca luz.

## Backup de dados

Faça backup das suas notas, favoritos e destaques. Mantenha seus dados seguros e leve-os para um novo dispositivo quando necessário.

## Sem anúncios, sem distrações

O Theodia foi feito para concentração. Não há anúncios, pop-ups nem interrupções. Apenas o texto e suas ferramentas de estudo.
