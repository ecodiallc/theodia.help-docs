---
title: O Que Torna o Theodia Diferente
level: everyday
categories: about
summary: Uma visão geral dos recursos exclusivos do Theodia e de como eles ajudam você a estudar a Bíblia offline.
---

# ✨ O Que Torna o Theodia Diferente

O Theodia é um aplicativo de estudo bíblico construído para funcionar completamente offline. Ele combina muitas ferramentas de estudo em um só lugar e não precisa de internet.

## Aplicação de estudo bíblico completa

Em um único aplicativo, você obtém:

- **Bíblias** — muitas traduções e idiomas.
- **Comentários** — explicações de versículos e capítulos.
- **Dicionários e léxicos** — palavras originais em grego e hebraico.
- **Livros e devocionais** — leituras extras para estudo pessoal.
- **Referências cruzadas** — veja onde um tema ou versículo aparece em outra parte da Bíblia.
- **Morfologia** — forma gramatical das palavras originais.

## Funciona offline

Depois que você instala recursos, tudo funciona sem internet:

- Leitura e pesquisa da Bíblia.
- Comentários, dicionários e referências cruzadas.
- Favoritos, destaques e notas.
- Planos de leitura, rotinas de oração e lembretes.
- Leitura em voz alta e textos bíblicos.

Isso é útil quando você está em viagem, em igrejas com pouca conectividade ou simplesmente quer economizar dados.

## Não há servidor

O Theodia não envia seus dados para um servidor. Seus favoritos, notas e configurações ficam no dispositivo. A IA local roda no próprio celular ou tablet, sem necessidade de conexão.

## Recursos abertos e expansíveis

Você pode adicionar seus próprios recursos:

- Traduções da Bíblia em formatos de arquivo de recursos do Theodia.
- Comentários, dicionários, livros e devocionais.
- Plugins escritos com Theoscript.
- Pacotes de ajuda e pacotes de idioma.

Veja [O Que São Recursos?](theodia://help/what-are-resources) e [Plugins](theodia://help/plugins-overview) para mais detalhes.

## Ferramentas integradas

- **Falar** — ouça a Bíblia em voz alta.
- **Comparar** — veja um versículo em várias versões.
- **Destaques** — marque versículos com cores.
- **Notas Bíblicas** — escreva observações ligadas a versículos.
- **Favoritos** — salve passagens.
- **Pesquisar** — busque por palavra, frase, referência ou Strong.
- **Flashcards** — memorize versículos com repetição espaçada.
- **Planos de leitura** — acompanhe sua leitura ao longo do tempo.
- **Rotinas de oração** — organize seus horários de oração.

## Leitura em voz alta avançada

O Theodia pode ler a Bíblia para você usando vozes do dispositivo. Você pode escolher a voz, ajustar a velocidade e até continuar ouvindo enquanto o aplicativo está em segundo plano.

Veja [Leitura em Voz Alta](theodia://help/text-to-speech) para mais.

## IA local e privada

A IA do Theodia roda no dispositivo. Ela pode explicar versículos, responder perguntas, comparar textos e sugerir ideias — sem enviar dados para a nuvem. Você controla se a IA está ativada e quais recursos ela pode usar.

## Uma única base de código

O Theodia é construído com uma única base de código. Isso significa que novos recursos chegam ao iOS, Android e web (quando suportado) de forma consistente.

## Resumo

O Theodia combina um aplicativo de Bíblia, biblioteca de estudo, ferramentas de IA local, recursos offline e opções de personalização em um só lugar. Ele foi projetado para leitores da Bíblia, estudantes, líderes e qualquer pessoa que queira levar a Palavra consigo, mesmo sem internet.
