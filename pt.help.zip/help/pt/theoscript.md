---
title: Theoscript
level: advanced
categories: [plugins, development]
summary: Uma introdução à linguagem de script Theoscript usada para escrever plugins do Theodia.
---

# 🧩 Theoscript

**Theoscript** é a linguagem de script usada para escrever plugins no Theodia. Ela foi projetada para ser simples o suficiente para não-programadores, mas poderosa o suficiente para adicionar novos comportamentos ao aplicativo.

## O que é Theoscript

Theoscript é uma linguagem leve baseada em configuração. Um script descreve o que o plugin faz e quais eventos do aplicativo ele responde.

## Estrutura básica

Um arquivo Theoscript começa com metadados:

```theoscript
plugin: MeuPlugin
version: 1.0.0
author: eu
description: Um plugin de exemplo.
```

Depois dos metadados, você escreve regras e funções.

## Eventos comuns

Plugins respondem a eventos. Alguns eventos comuns incluem:

- `onCommand` — quando o usuário executa um comando.
- `onVerseAction` — quando o usuário escolhe uma ação no menu do versículo.
- `onReminder` — quando um lembrete agendado dispara.
- `onStartup` — quando o aplicativo inicia.

## Exemplo simples

```theoscript
plugin: Saudacao
version: 1.0.0

onCommand("/saudacao") {
  showToast("Paz do Senhor!");
}
```

Quando o usuário digitar `/saudacao` na barra de comando, o aplicativo mostra uma mensagem curta.

## Funções embutidas

Theoscript oferece funções para interagir com o aplicativo:

- `showToast(texto)` — mostra uma mensagem temporária.
- `openPassage(livro, capitulo, versiculo)` — abre uma passagem bíblica.
- `copyToClipboard(texto)` — copia texto para a área de transferência.
- `scheduleReminder(opcoes)` — agenda um lembrete.
- `log(texto)` — envia uma mensagem para os logs.
- `getInstalledResources()` — retorna a lista de recursos instalados.
- `getSetting(chave)` e `setSetting(chave, valor)` — leem e escrevem configurações.

## Variáveis e argumentos

Você pode receber argumentos dos comandos:

```theoscript
onCommand("/abrir") {
  const livro = args[0];
  const capitulo = args[1];
  openPassage(livro, capitulo);
}
```

## Condições

Use condições simples para tomar decisões:

```theoscript
onCommand("/tema") {
  if (args[0] === "escuro") {
    setTheme("dark");
  } else {
    setTheme("light");
  }
}
```

## Armazenamento de dados

Plugins podem armazenar dados próprios usando `setSetting` e `getSetting`. Os dados ficam no dispositivo e são separados das configurações do aplicativo.

```theoscript
setSetting("MeuPlugin.contador", 1);
const contador = getSetting("MeuPlugin.contador");
```

## Depuração

Use `log()` para rastrear o que seu plugin faz. Verifique os logs do plugin em **Configurações** → **Plugins** → detalhes do plugin.

## Limitações

Theoscript não é uma linguagem de programação completa. Ela não suporta:

- Acesso à rede.
- Arquivos fora do diretório do plugin.
- Código nativo do dispositivo.
- Recursão complexa.

Ela é projetada para ser segura e previsível.

## Recursos adicionais

- Veja [Desenvolvimento de Plugins](theodia://help/plugin-development) para criar plugins.
- Veja [Plugins](theodia://help/plugins-overview) para gerenciar plugins.
- Veja [Configurações de Plugins](theodia://help/plugin-settings) para opções de gerenciamento.
