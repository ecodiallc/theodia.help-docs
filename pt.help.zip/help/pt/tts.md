---
title: Leitura em Voz Alta (Texto para Fala)
level: everyday
categories: tts
summary: Faça o Theodia ler a Bíblia ou um devocional em voz alta. Como usar, como escolher uma voz e o que fazer quando fica em silêncio.
---

# Leitura em Voz Alta (Texto para Fala)

> **Modo:** A leitura em voz alta está disponível nos modos **Padrão** e **Estudioso**. O Modo de Foco é apenas para leitura limpa e sem distrações. Você pode trocar de modo em **Configurações** → **Modo de Usuário do Aplicativo**.

O Theodia pode ler textos em voz alta usando a voz de texto para fala (TTS) do seu dispositivo. Você pode ouvir um único versículo, um capítulo inteiro ou um devocional. Isso é útil para leitura sem as mãos, ouvir enquanto caminha ou viaja, acompanhar a leitura com áudio ou simplesmente dar um descanso aos olhos.

## Onde está o botão de ouvir

Você encontrará um botão de ouvir em três lugares.

### 1. No menu do versículo (versículo único)

Esta é a forma mais rápida de ouvir um versículo de cada vez. Abra um capítulo no [Modo de Estudo](theodia://help/study-mode), toque em um versículo para abrir o menu do versículo e depois toque em **Falar** (🔊). A leitura começa a partir daquele versículo. Uma pequena barra de controle aparece na parte inferior da tela com reproduzir, pausar, retroceder, avançar e um seletor de voz.

A opção Falar não é mostrada para Bíblias interlineares (MIB — Marvel Interlinear Bible — e OHGB), pois elas exibem palavras em um layout diferente que não lê de forma natural.

### 2. Na parte superior de um capítulo (capítulo inteiro)

Quando você está lendo um capítulo, olhe a fileira de ícones na parte superior da tela. Toque em **Ouvir** (🔊) para começar a ler o capítulo inteiro desde o início. O botão vira um botão de parar (⏹) enquanto o áudio está tocando. Toque nele novamente para parar. A mesma barra de controle aparece na parte inferior.

Você pode pular para outro versículo, e o botão Ouvir ali começará a partir daquele versículo.

### 3. Em um devocional

Abra qualquer dia de devocional e toque no botão **Ouvir** (🔊) na parte superior da leitura. O texto completo do devocional é lido em voz alta, frase por frase. Uma barra de controle na parte inferior oferece reproduzir, pausar, retroceder e controles de voz.

## Usando a barra de controle

Enquanto o áudio está tocando, uma pequena barra permanece visível na parte inferior da tela. Ela tem seis controles:

- ⏪ **Retroceder** — volta um versículo (ou uma frase em um devocional)
- ⏸ **Pausar / ▶ Continuar** — pausa sem perder o lugar. Toque de novo para continuar do mesmo ponto.
- ⏩ **Avançar** — pula para o próximo versículo (ou próxima frase em um devocional)
- 🎙 **Voz** — abre o seletor de voz sem sair do capítulo (veja abaixo)
- ⚙ **Opções** — abre o painel de opções estendidas (veja abaixo)
- **Parar** — toque no botão 🔊 na parte superior da tela, ou no ⏹ que o substitui enquanto o áudio toca, para parar e fechar a barra.

A barra de controle fecha quando o capítulo termina ou quando você toca em parar.

### Opções estendidas

Toque em ⚙ para expandir opções extras de reprodução. Essas configurações duram apenas para o capítulo atual e são reiniciadas quando você troca de capítulo ou para de ouvir.

- ⏮ **Voltar ao início** — pula para o primeiro versículo do intervalo definido.
- **Início** — digite um número de versículo para definir onde a leitura começa.
- **Fim** — digite um número de versículo para definir onde a leitura termina.
- **Tudo** — redefine o intervalo para o capítulo inteiro.
- **()** — alterna se textos entre parênteses são lidos em voz alta.
- 🔁 **Repetir** — reinicia automaticamente no início do intervalo quando chega ao fim, com uma pequena pausa no meio. Se você ligar isso sem definir um versículo de início ou fim, o capítulo inteiro se repete.

## Como mudar a voz

Você pode escolher qual voz o Theodia usa para ler. Isso é útil se quiser um sotaque diferente, outro idioma, ou uma voz mais rápida ou mais lenta do que a padrão do dispositivo.

1. Abra **Configurações**.
2. Encontre a seção **Fala**.
3. Toque em **Selecionar voz**.
4. Uma lista de vozes aparece. A primeira linha, **Padrão**, usa a voz preferida pelo dispositivo. Escolha qualquer outra linha para torná-la a nova padrão.
5. Sua escolha é salva e usada na próxima vez que tocar em **Ouvir** ou **Falar**.

Você também pode tocar no ícone 🎙 na barra de controle de leitura para abrir o mesmo seletor sem sair do capítulo.

A disponibilidade de vozes depende totalmente do seu dispositivo. iOS e Android vêm com um conjunto de vozes integradas. Você pode instalar mais vozes nas configurações do dispositivo em **Acessibilidade** ou **Idioma e Entrada**. O Theodia pode usar qualquer voz instalada no dispositivo.

## Vozes favoritas

Se seu dispositivo tem muitas vozes, rolar pela lista completa toda vez pode ser lento. Você pode criar uma lista curta de **vozes favoritas** e os seletores de voz mostrarão apenas essas vozes.

1. Abra **Configurações**.
2. Encontre a seção **Fala**.
3. Toque em **Vozes Favoritas** (a primeira linha na parte superior da seção).
4. Toque em **Definir Vozes Favoritas** para abrir a tela de favoritos.
5. Toque no botão de reproduzir ao lado de uma voz para ouvi-la. Toque na estrela para adicioná-la aos favoritos. Você pode favoritar quantas vozes quiser.
6. Volte. Os seletores de voz no Theodia agora mostram apenas suas vozes favoritas.

Se você remover todos os favoritos, os seletores voltam a mostrar todas as vozes. Vozes favoritas são incluídas quando você faz backup e restaura as configurações do Theodia.

## Definindo uma voz diferente para cada Bíblia

Você pode dar a cada tradução da Bíblia sua própria voz. Isso é útil quando alterna entre traduções que leem de forma muito diferente — por exemplo, uma voz mais formal para a King James Version e uma voz mais conversacional para uma tradução moderna como NIV ou NLT. Também ajuda se você ouve Bíblias em idiomas diferentes e quer que cada uma seja falada no sotaque certo.

1. Abra **Configurações**.
2. Encontre a seção **Fala**.
3. Procure por **Vozes da Bíblia**.
4. Toque em qualquer Bíblia da lista.
5. Escolha a voz que deseja para aquela tradução. A primeira linha, **Padrão**, usa sua voz principal de TTS para aquela Bíblia.
6. Repita para outras Bíblias.

O cabeçalho mostra quantas traduções da Bíblia têm uma voz personalizada definida. **Selecionar voz**, **Voz de comentário**, **Voz de notas bíblicas** e **Voz de devocional** também mostram uma contagem quando uma voz está definida.

Na próxima vez que ouvir um capítulo dessa Bíblia, o Theodia usará a voz escolhida. Todas as outras Bíblias continuam usando a voz padrão principal, a menos que você também as altere.

## Continuar a fala em segundo plano

Por padrão, o Theodia para a fala quando você sai da tela de leitura, muda para outro aplicativo ou bloqueia o celular. Isso evita áudio inesperado quando você não está mais lendo ativamente.

Para deixar a fala continuar tocando em segundo plano:

1. Abra **Configurações**.
2. Encontre a seção **Fala**.
3. Ative **Continuar fala em segundo plano**.

Quando isso está ligado, você pode trocar de aba, abrir outro aplicativo ou bloquear a tela, e o capítulo ou devocional continuará sendo lido. A barra de controle permanece ativa para que você possa pausar ou pular pela área de notificação (se o dispositivo suportar).

Desligar essa opção **enquanto a fala já está tocando** a interrompe imediatamente.

## O que fazer se não estiver funcionando

A leitura em voz alta depende do dispositivo. O Theodia envia o texto para o sistema operacional, e o sistema operacional o lê em voz alta usando uma voz. Se não estiver funcionando, tente estas etapas em ordem.

### O Theodia diz que TTS não está disponível

Alguns dispositivos não têm TTS. Abra **Configurações** e procure a seção **TTS**. Se a seção não estiver lá, seu dispositivo não suporta TTS nesta versão.

### A lista de vozes está vazia

O seletor de voz pode mostrar "nenhuma voz encontrada". Isso geralmente significa que o dispositivo ainda não terminou de carregar suas vozes.

1. Abra **Configurações → Fala → Selecionar voz**.
2. Se a lista estiver vazia, procure um botão **Testar novamente** logo abaixo da lista suspensa. Toque nele. O Theodia consulta o dispositivo por vozes novamente.
3. Se ainda estiver vazia, verifique as configurações do sistema do dispositivo. No iOS, vá em **Configurações → Acessibilidade → Conteúdo Falado → Vozes** e baixe uma voz para o seu idioma. No Android, vá em **Configurações → Idioma e Entrada → Saída de Texto para Fala** e toque em **Instalar dados de voz**.
4. Feche e reabra o Theodia para que ele reconheça a nova voz.

Se você definiu vozes favoritas e a lista está vazia, verifique se pelo menos uma das favoritas corresponde a uma voz instalada neste dispositivo.

### Toque em Falar, mas nada acontece

- Verifique se o dispositivo não está no modo silencioso. A maioria dos dispositivos não reproduz áudio de TTS enquanto no modo silencioso.
- Certifique-se de que o volume do dispositivo está alto.
- Tente o botão **Testar novamente** em **Configurações → Fala**.
- Abra **Configurações** e olhe a seção **Sistema** na parte inferior. A linha **TTS** deve dizer **Disponível**. Se disser **Indisponível**, o TTS está desligado no nível do sistema operacional. Reative-o lá e reabra o Theodia.

### O áudio toca, mas está no idioma errado

O Theodia envia o texto no idioma do conteúdo atual e pede a voz que você selecionou. Se a voz selecionada for de um idioma diferente, o dispositivo ainda pode ler o texto, mas soará estranho.

1. Abra **Configurações → Fala → Selecionar voz**.
2. Escolha **Padrão** para deixar o dispositivo escolher a voz certa, ou escolha uma voz cujo idioma corresponda ao texto que está lendo.

O Theodia atualmente não lê Bíblias interlineares em grego ou hebraico em voz alta. Os botões Falar e Ouvir ficam ocultos nessas traduções.

### O áudio toca, mas para cedo

Se um versículo estiver ausente ou ilegível, o capítulo pula para o próximo. Se a barra fechar sozinha depois de alguns versículos, toque no botão **Ouvir** (🔊) na parte superior da tela para começar de novo.

### A fala está tocando, mas não sei onde começou

Se você ativou **Continuar fala em segundo plano** e depois ouve áudio, mas não encontra a tela que começou, pode parar a fala de qualquer lugar no aplicativo.

1. Abra **Configurações**.
2. Encontre a seção **Fala**.
3. Toque no botão vermelho **Parar Fala** na parte inferior da seção.

Isso para imediatamente qualquer texto para fala em execução no Theodia. Você também pode abrir o alternador de aplicativos do dispositivo e deslizar o Theodia para forçar a parada do áudio.

### Lê rápido demais ou devagar demais

O Theodia não controla a velocidade de leitura. A velocidade é definida pela voz escolhida. Para alterar:

- No iOS: **Configurações → Acessibilidade → Conteúdo Falado → Velocidade de Fala**.
- No Android: **Configurações → Idioma e Entrada → Saída de Texto para Fala → Velocidade da Fala**.

## Dicas

- A barra de controle permanece visível enquanto você navega entre capítulos, então você pode pausar, pular ou mudar de voz sem perder o lugar.
- O Theodia lê os números dos versículos como pequenas pausas. Você pode parar a barra, deslizar para outro versículo e tocar em reproduzir para continuar dali.
- Para longas sessões de escuta, ative **Não Perturbe** para notificações não interromperem o áudio.
- O botão 🔊 usa o volume atual do dispositivo. Se você conectar fones de ouvido, o volume muda para o nível do fone.

## Lendo um PDF em voz alta

O Theodia também pode ler páginas de PDF em voz alta. Abra um PDF e toque no botão **Ouvir** (alto-falante) na barra de ferramentas dele. Uma barra de controle aparece com Reproduzir/Pausar, Retroceder, Avançar, Parar, uma barra de progresso e os seletores de velocidade e voz. Quando uma página termina, a leitura continua automaticamente na página seguinte.

A leitura de PDFs usa o texto pesquisável instalado do PDF e as mesmas vozes e velocidade da leitura da Bíblia.

## Guias relacionados

- O guia [Modo de Estudo](theodia://help/study-mode) cobre o menu do versículo e os botões superiores da tela com mais detalhes.
- O guia [Modo de Foco](theodia://help/focus-mode) é uma visualização de leitura mais limpa que também suporta TTS pelo botão 🔊 na barra inferior.
- O guia [Problemas Comuns](theodia://help/common-problems) tem soluções para outros problemas de áudio, voz e idioma.
- O guia [Devocionais Diários](theodia://help/daily-devotionals) cobre a leitura devocional e onde o botão de ouvir fica nessa tela.
- O guia [PDFs](theodia://help/pdfs) cobre o leitor de PDFs e o botão de ouvir dele.
