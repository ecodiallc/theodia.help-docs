---
title: Bem-vindo ao Theodia
level: beginner
categories: welcome
summary: Um tour rápido pelo aplicativo e pelo que ele pode fazer por você.
---

# Bem-vindo ao Theodia

O Theodia é um aplicativo de estudo bíblico. Funciona no seu celular ou tablet, mesmo sem internet. Tudo o que você lê, pesquisa e estuda fica salvo no dispositivo.

## O que você pode fazer

O Theodia tem três modos de uso. Cada modo mostra um conjunto diferente de recursos.

- **Leitor** — leia a Bíblia em uma visualização limpa e sem distrações.
- **Padrão** — tudo do Leitor, mais favoritos, destaques, notas, leitura em voz alta, pesquisa e devocionais diários.
- **Estudioso** — tudo do Padrão, mais comentários, léxicos, dicionário bíblico, assistente de IA e muito mais.

Você pode mudar de modo a qualquer momento em **Configurações** → **Modo de Usuário do Aplicativo**.

### Recursos disponíveis para você

Independentemente do modo escolhido, você sempre pode:

- **Ler a Bíblia.** Escolha entre várias traduções. Mude entre elas a qualquer momento.
- **Pesquisar a Bíblia.** Procure por uma palavra ou frase. O aplicativo mostra todos os versículos correspondentes.
- **Ler livros e devocionais.** O aplicativo vem com clássicos cristãos e um devocional diário.

Dependendo do modo, você também pode:

- **Ouvir.** Ouça versículos em voz alta com a leitura em voz alta. (Padrão e Estudioso.)
- **Fazer anotações.** Escreva seus próprios pensamentos ao lado de um versículo. (Padrão e Estudioso.)
- **Destacar.** Marque seus versículos favoritos com cores. (Padrão e Estudioso.)
- **Salvar como favorito.** Guarde versículos para encontrá-los rapidamente. (Padrão e Estudioso.)
- **Perguntar ao assistente de IA.** Peça ajuda para entender um versículo. (Somente Estudioso.)

## Por onde começar

1. Abra a aba **Bíblia** na parte inferior da tela.
2. Escolha uma tradução.
3. Toque em qualquer livro para começar a ler.

Se quiser saber mais, os outros guias de ajuda estão aqui para você. Escolha um tópico na lista da página inicial de ajuda.

## Algumas coisas importantes

- Você não precisa de uma conta.
- Suas notas, destaques e favoritos ficam no dispositivo.
- Você pode fazer backup deles. Veja o guia [Fazendo Backup dos Seus Dados](theodia://help/backups).

## Quer mais recursos?

O aplicativo já vem com várias versões da Bíblia disponíveis gratuitamente. Para Bíblias, comentários, léxicos, livros e devocionais extras, veja o guia [Obtendo Recursos Extras no GitHub](theodia://help/getting-core-files). Ele mostra como encontrar e adicionar mais recursos a partir da página do projeto no GitHub.

Bem-vindo. Esperamos que o Theodia o ajude a ler e estudar.
