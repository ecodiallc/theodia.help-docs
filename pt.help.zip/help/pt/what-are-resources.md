---
title: O Que São Recursos?
level: everyday
categories: resources
summary: Uma explicação dos arquivos de recursos do Theodia — Bíblias, comentários, dicionários, livros, devocionais e plugins — e como eles funcionam offline.
---

# 📦 O Que São Recursos?

O Theodia armazena seu conteúdo como **recursos**. Um recurso é um arquivo que contém textos, dados ou configurações. Recursos permitem que o aplicativo funcione offline e que você personalize o que está disponível.

## Tipos de recursos

### Bíblias

Arquivos `.bible` contêm uma tradução completa da Bíblia. Cada arquivo tem:

- O texto de cada versículo.
- Informações sobre o livro e capítulo.
- Detalhes sobre a tradução.

Exemplo: `KJV.bible`, `NVI.bible`, `TRLIT.bible`.

### Comentários

Arquivos `.commentary` contêm explicações de versículos e capítulos. Eles ajudam você a entender melhor o texto.

Exemplo: `vAIC.commentary`.

### Léxicos e dicionários

Arquivos `.lexicon` contêm definições de palavras originais em grego e hebraico. Eles funcionam com os números Strong e a ferramenta **Informação da Palavra**.

Exemplo: `TRLIT.lexicon`.

### Livros

Arquivos `.book` contêm livros cristãos, sermões, histórias da igreja ou outros textos longos.

Exemplo: `HymnLyricsEnglish.book`.

### Devocionais

Arquivos `.devotional` contêm leituras diárias. Eles geralmente incluem um versículo, uma reflexão e uma oração para cada dia.

### Referências Cruzadas

Arquivos `.sqlite` especiais, como `cross-reference.sqlite`, mostram onde temas e versículos estão conectados na Bíblia.

### Morfologia

Arquivos `.sqlite` de morfologia mostram a forma gramatical das palavras originais. Eles são usados pelas ferramentas de estudo avançado.

### Plugins

Plugins adicionam funcionalidade ao Theodia. Eles são escritos em **Theoscript**, uma linguagem de script leve do aplicativo. Plugins podem adicionar comandos, lembretes, ações de menu e integrações com recursos.

Veja [Plugins](theodia://help/plugins-overview) para mais.

## Como os recursos são instalados

Há várias maneiras de adicionar recursos ao aplicativo:

1. **Empacotados** — alguns recursos vêm com o aplicativo quando você instala.
2. **Gerenciar Recursos** — abra **Configurações** → **Gerenciar Recursos** para instalar recursos do repositório do Theodia ou de uma URL.
3. **Instalar do GitHub** — instale pacotes de recursos ou documentos de ajuda de um repositório do GitHub.
4. **Importar arquivo** — copie arquivos `.bible`, `.commentary`, `.book` ou outros para o dispositivo e importe-os no aplicativo.

Veja [Instalando Traduções da Bíblia](theodia://help/installing-bibles) para instruções específicas de Bíblias.

## Formato dos recursos

A maioria dos recursos usa arquivos **SQLite**. Isso permite que o aplicativo faça buscas rápidas, mesmo com milhares de capítulos e versículos. Os arquivos são compactados e otimizados para uso em dispositivos móveis.

## Recursos são locais

Depois de instalados, os recursos ficam no dispositivo. Não há streaming. Isso significa que:

- Você não precisa de internet para usar.
- Os recursos ocupam espaço de armazenamento.
- Você pode excluir recursos que não usa para liberar espaço.

## Criar seus próprios recursos

Você pode criar recursos personalizados se souber converter dados para o formato do Theodia. Veja [Criando Recursos](theodia://help/creating-resources) para uma introdução.

## Resumo

Recursos são os blocos de construção do conteúdo do Theodia. Bíblias, comentários, dicionários, livros, devocionais e plugins são todos recursos que você pode instalar, remover e gerenciar para personalizar seu aplicativo.
