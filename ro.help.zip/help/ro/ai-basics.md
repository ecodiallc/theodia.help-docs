---
title: Bazele IA
level: advanced
categories: ai
summary: Cum folosești asistentul IA pentru a înțelege versetele.
---

# Bazele IA

> **Mod:** Asistentul IA necesită modul **Savant**. Poți schimba modul în **Setări** → **Mod utilizator aplicație**.

Theodia are un asistent IA care te poate ajuta să înțelegi un verset, să răspunzi la o întrebare sau să discuți despre un subiect biblic.

## Cum activezi IA

IA este oprit implicit. Pentru a o activa:

1. Deschide **Setări**.
2. Atinge **Asistent IA**.
3. Atinge comutatorul pentru a o activa.

## Cum deschizi IA

Atinge fila **IA** din partea de jos a ecranului. Se deschide o fereastră de chat.

## Cum pui o întrebare

Atinge caseta din partea de jos. Tastează întrebarea. Atinge **Trimite**.

Câteva exemple de întrebări:

- „Ce înseamnă Ioan 3:16?”
- „Spune-mi despre cartea Romani.”
- „Care este rodul Duhului?”
- „Compară Predica de pe Munte din Matei și Luca.”

## Cum întrebi despre un verset anume

1. Deschide un capitol.
2. Atinge un verset pentru a deschide meniul de verset.
3. Atinge **Comentariu IA**.

Versetul este trimis către IA. Panoul IA se deschide cu versetul deja completat. Poți adăuga o întrebare, precum „Ce înseamnă asta?” sau „Cum ar trebui să aplic?”

## Lucruri importante de știut

- IA este un instrument, nu o persoană. Poate face greșeli.
- Verifică întotdeauna răspunsurile IA în lumina Bibliei.
- IA poate avea nevoie de internet. Nu funcționează offline.
- Când folosești IA, întrebările, contextul versetului și cheia API sunt trimise către endpointul ales. Prima dată când faci asta, aplicația îți cere permisiunea și îți arată exact ce este trimis. Poți schimba sau revoca acea permisiune ulterior în **Setări → Asistent IA → Partajarea datelor IA la distanță**.
- În unele regiuni, precum build-ul App Store din China continentală, asistentul IA nu este disponibil. În acel build sunt disponibile doar funcțiile offline ale Bibliei.

## Cum gestionezi conversațiile

Ecranul IA păstrează o listă cu conversațiile anterioare. Din listă poți deschide o conversație veche, începe una nouă sau șterge una de care nu mai ai nevoie.

## Mergi mai adânc cu IA

Această pagină acoperă bazele. IA din Theodia poate face mult mai mult decât să converseze. Iată unde poți merge în continuare:

- **[Funcțiile IA](theodia://help/ai-features)** — Descoperă tot ce poate face Theofil: studiu verset-cu-verset în greacă și ebraică, lanțuri de referințe încrucișate, schițe de predici, generare de rugăciuni, morfologie în limbile originale, căutări în dicționare și navigare hands-free în aplicație. Acest ghid îți arată cum transformi IA dintr-un simplu chatbot într-un partener de studiu complet.
- **[Scrierea unor prompteri mai buni](theodia://help/ai-prompts)** — Învață arta de a pune întrebări care primesc răspunsuri bogate și precise. Câteva ajustări ale felului în care formulezi cererea pot debloca răspunsuri mult mai profunde de la IA.
- **[Alegerea unui model IA](theodia://help/choosing-a-model)** — Nu toate modelele IA sunt egale. Află care modele suportă instrumentele încorporate ale Theodia (precum deschiderea versetelor și căutarea în Scriptură) și care transformă IA într-un adevărat asistent hands-free pentru studiul Bibliei.
- **[GitHub Models](theodia://help/github-models)** — Furnizorul gratuit recomandat pentru Theodia. Obține o cheie API gratuită cu un cont GitHub și începe să pui întrebări într-un nivel zilnic generos. Fără card de credit, fără abonament.
- **[Chei API și costuri](theodia://help/ai-keys-and-costs)** — Înțelege cum funcționează tarifarea API între furnizori și cum să păstrezi costurile aproape de zero.
