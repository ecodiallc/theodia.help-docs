---
title: Funcțiile IA
level: advanced
categories: ai
summary: Descoperă tot ce poate face IA din Theodia — de la studiul verset-cu-verset la pregătirea predicilor, explorarea limbilor originale și navigarea hands-free.
---

# Funcțiile IA

> **Mod:** Asistentul IA necesită modul **Savant**. Poți schimba modul în **Setări** → **Mod utilizator aplicație**.

Asistentul IA al Theodia, Theofil, nu este doar un chatbot. Este un partener de studiu care poate citi Biblia alături de tine, poate consulta comentarii, căuta în Scriptură, îți poate gestiona notițele și poate chiar naviga în aplicație — totul prin voce sau text.

Înainte ca Theofil să trimită date către un endpoint IA pentru prima dată, aplicația arată un dialog de consimțământ care explică ce este trimis și îți cere permisiunea. Poți schimba sau revoca acea permisiune oricând în **Setări → Asistent IA → Partajarea datelor IA la distanță**.

## Chat pe verset: studiază un verset în profunzime

**Chatul IA pe verset** este inima experienței IA din Theodia. Cât timp citești un capitol, atinge un număr de verset (sau apasă lung pe textul versetului) și alege **Comentariu IA**. Se deschide un panou de chat cu acel verset deja încărcat. IA știe exact ce citești și este gata să îl exploreze împreună cu tine.

### Pornitori la un singur atingere

Nu ești sigur ce să întrebi? Panoul arată opt pornitori instant:

- **Explică acest verset** — Obține o explicație clară și chibzuită a sensului și semnificației.
- **Limba originală** — Vezi cuvintele grecești sau ebraice, transliterările și definițiile lexicale din spatele textului românesc.
- **Context istoric** — Află despre cultura, politica și evenimentele din jurul versetului.
- **Context textual** — Vezi cum se potrivește versetul în paragraful, capitolul și cartea din jurul lui.
- **Teme principale** — Descoperă ideile mari pe care acest verset le aduce teologiei biblice.
- **Aplică în viața mea** — Obține aplicații practice și personale pe care le poți pune în practică astăzi.
- **Generează o rugăciune** — Transformă versetul într-o rugăciune modelată pe limbajul și adevărurile lui.
- **Generează o schiță de predică** — Obține o schiță în trei puncte, cu introducere și concluzie, gata de predicat.

Atinge orice pornitor și IA începe imediat. Poți continua cu propriile întrebări, cere clarificări sau redirecționa conversația.

### Continuă ca într-o conversație reală

IA își amintește ultimele câteva mesaje din chat, așa că poți aprofunda în mod natural:

- „Poți spune mai simplu?”
- „Ce spune greaca originală aici?”
- „Arată-mi referințele încrucișate care se leagă de acesta.”
- „Compară acest verset în trei traduceri diferite.”
- „Cum ar arăta asta într-un loc de muncă modern?”
- „Dă-mi trei aplicații pentru un părinte.”

Conversația rămâne atașată de verset, așa că fiecare răspuns este ancorat în textul pe care îl citești.

### Atinge orice referință biblică

Când IA menționează un alt verset — de exemplu, „Acest lucru oglindește Romani 8:28” — referința apare ca **link pe care îl poți atinge**. Atinge-o și aplicația sare la acel pasaj în Cititorul biblic. Poți explora lanțul de referințe fără să părăsești conversația.

## Ce poate face IA dincolo de chatul pe verset

Theofil are acces la întreg conținutul Theodia — Biblia, comentariile, lexicoanele, dicționarele, cărțile, devoționalele, notițele, marcajele și evidențierile tale. Iată ce înseamnă asta în practică.

### Citește și navighează în Scriptură

- **Citește orice verset sau capitol** — „Citește Ioan 3:16 în WEB” sau „Citește Psalmii 23 cu voce tare.”
- **Deschide pasaje în Cititor** — „Du-mă la Geneza 1” sau „Deschide Romani 8:28.”
- **Compară versiuni** — „Arată-mi Ioan 3:16 în toate traducerile mele biblice.”
- **Caută în Biblie** — „Găsește versete despre iertare” sau „Caută 'pacea care întrece orice pricepere.'"
- **Obține referințe încrucișate** — „Ce alte versete se leagă de Isaia 53:5?”
- **Citește titlurile de secțiune** — „Care sunt subtitlurile în Matei 5?”

### Explorează limbile originale

- **Căutări în lexicon** — „Ce înseamnă cuvântul grecesc 'agape' în Ioan 3:16?” sau „Caută Strong G26.”
- **Morfologie** — „Analizează verbele grecești din Romani 8:28” sau „Ce înseamnă codul morfologic V-PAI-3S?”
- **Informații cuvânt** — IA poate vedea aceeași analiză cuvânt-cu-cuvânt pe care o vezi tu în aplicație — transliterare, glossă, gramatică și numere Strong.

### Citește comentarii și cărți de studiu

- **Comentariu pe verset** — „Ce spune Matthew Henry despre Efeseni 2:8?”
- **Comentariu pe capitol** — „Dă-mi prezentarea capitolului pentru Romani 8.”
- **Comentariu pe carte** — „Rezumă comentariul la nivel de carte despre Apocalipsa.”
- **Cărți de studiu** — „Citește-mi un capitol din Hymn Lyrics English” sau „Caută în cărțile mele cuvântul 'răbdare.'"
- **Devoționale** — „Citește devoționalul de azi” sau „Găsește un devoțional despre anxietate.”

### Caută în dicționare

- „Cine a fost Melhisedec?”
- „Ce spune dicționarul biblic despre Ghilgal?”
- „Caută 'ispășire' în Easton's.”

### Gestionează-ți viața de studiu

IA poate acționa asupra datelor tale personale — stocate întotdeauna local pe dispozitiv:

- **Marcaje** — „Salvează acest verset în folderul meu Pregătire Predică” sau „Listează-mi marcajele.”
- **Evidențieri** — „Evidențiază Ioan 3:16 în galben” sau „Arată-mi toate evidențierile mele.”
- **Notițe** — „Creează o notă biblică la acest verset” sau „Citește-mi notițele pentru Geneza 1.”
- **Note de studiu** — „Salvează această conversație ca notă de studiu” sau „Creează un nou caiet de studiu numit Studiu Romani.”
- **Foldere** — „Creează un folder numit Devoțional Dimineața” sau „Mută marcajul meu Ioan 3:16 în folderul Rugăciune.”

### Schimbă setările aplicației

- „Comută la modul întunecat.”
- „Fă din BSB Biblia mea implicită.”
- „Activează Biblia paralelă cu NET.”
- „Mărește dimensiunea fontului.”

### Citește cu voce tare

- „Citește Psalmii 23 cu voce tare” — IA poate declanța citirea text-to-speech pentru orice pasaj, carte sau notă.
- „Oprește citirea” — Oprește citirea cu voce tare oricând.

## Salvează-ți conversațiile

Orice chat IA pe verset poate fi salvat. Atinge meniul din panoul de chat și alege:

- **Salvează ca notă biblică** — Adaugă întreaga conversație la nota versetului din Cititorul biblic.
- **Salvează ca notă de studiu** — Stochează conversația în caietul tău de Note de studiu pentru referință ulterioară.

Astfel transformi o explorare rapidă cu IA într-un material de studiu permanent pe care îl poți revedea, edita sau dezvolta predici.

## Fila IA completă

Dincolo de panoul de chat pe verset, Theodia are o filă dedicată **IA** în navigarea de jos. Acesta este un chat liber în care poți întreba orice — fără verset preselectat. Folosește-l pentru:

- Studii tematice în întreaga Biblie
- Cercetare și schițează predici
- Compararea temelor teologice între cărți
- Devoționale zilnice și stimulente de rugăciune
- Trivia biblică și planuri de citire
- Ajutor pentru aplicație — „Cum funcționează Biblia paralelă?”

Conversațiile tale sunt salvate automat. Poți reveni la chat-uri anterioare, începe unele noi și șterge threaduri vechi.

## Idei pentru început

Iată câteva moduri interesante de a folosi IA. Alege unul și încearcă astăzi.

**Creștere personală**

- „Explică Filipeni 4:6–7 și dă-mi o rugăciune pentru când mă simt anxios.”
- „Ce spune Biblia despre odihnă? Găsește-mi cinci versete și explică fiecare.”

**Familie și părinți**

- „Cum ar trebui să călăuzească Efeseni 6:4 creșterea modernă a copiilor? Dă-mi trei reguli practice.”
- „Găsește versete despre creșterea copiilor și citește-mi-le cu voce tare.”

**Pregătire pentru predică și învățătură**

- „Schițează o predică de 25 de minute despre Romani 8:28, cu introducere, trei puncte și concluzie.”
- „Ce spun comentariile mele despre 'armura lui Dumnezeu' în Efeseni 6?”
- „Compară Predica de pe Munte din Matei cu versiunea lui Luca. Care sunt diferențele?”

**Studiul limbii originale**

- „Arată-mi morfologia pentru fiecare cuvânt din Ioan 1:1.”
- „Care este diferența dintre 'agape' și 'philia' în Noul Testament?”

**Profunzime devoțională**

- „Citește devoționalul de azi și leagă-l de un verset din Psalmi.”
- „Dă-mi o schiță devoțională de șapte zile despre rodul Duhului.”

**Lanțuri de referințe încrucișate**

- „Începe cu Isaia 53:5 și urmărește tema 'rănilor' și 'vindecării' prin Noul Testament.”
- „Unde apare conceptul de 'legământ' de la Geneza la Evrei?”

**Memorare și recapitulare**

- „Testează-mă cu cărțile Bibliei în ordine.”
- „Creează o notă de studiu care rezumă ideea principală a fiecărui capitol din Romani.”

## Câteva note importante

- IA este un **instrument**, nu un înlocuitor al Bibliei sau al îndrumării pastorale. Compară întotdeauna răspunsurile ei cu Scriptura însăși.
- Când folosești IA, întrebările tale circulă prin internet către serverele furnizorului. Majoritatea furnizorilor nu își antrenează modelele pe datele tale, dar textul părăsește dispozitivul.
- IA poate face greșeli. Folosește comentariile, lexicoanele și textul biblic drept autoritate finală.

## Rezumat

IA din Theodia este concepută pentru a face studiul Bibliei mai rapid, mai profund și mai personal. Fie că vrei o explicație de o propoziție pentru un verset confuz, o schiță de predică completă, un studiu al unui cuvânt grecesc sau un lanț de referințe încrucișate care traversează întreaga Biblie, Theofil este gata să te ajute. Atinge un verset, pune o întrebare și vezi unde duce conversația.
