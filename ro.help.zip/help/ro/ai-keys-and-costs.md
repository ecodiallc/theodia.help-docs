---
title: Chei API și costuri
level: advanced
categories: ai
summary: De ce ai nevoie de o cheie API, cum obții una și cât costă de obicei să folosești un model IA la distanță.
---

# Chei API și costuri

> **Mod:** Asistentul IA necesită modul **Savant**. Poți schimba modul în **Setări** → **Mod utilizator aplicație**.

Asistentul IA se conectează la modele IA la distanță. Dacă vrei să folosești unul, ai nevoie de o cheie API. Această pagină explică de ce, cum obții una și ce costă de obicei.

## De ce ai nevoie de o cheie API

Un model IA la distanță trăiește pe un server pe internet. Cheia API este ca o parolă care îi spune serverului: „Această persoană are voie să pună întrebări.” Fără ea, serverul nu răspunde.

Aplicația nu furnizează o cheie încorporată. Trebuie să îți creezi propriul cont la un furnizor și să lipești cheia în aplicație.

## Cum obții o cheie API

1. Deschide **Setări** în Theodia.
2. Atinge **Asistent IA**.
3. Alege **Model la distanță**.
4. Selectează un furnizor din listă sau alege **Personalizat** și introdu un URL de bază.
5. Atinge linkul către pagina de chei a furnizorului. Creează un cont dacă nu ai unul.
6. Generează o nouă cheie API pe site-ul furnizorului.
7. Copiază cheia și lipește-o în Theodia.
8. Atinge **Verificare conexiune** pentru a te asigura că funcționează.

## Furnizori suportați

Theodia se poate conecta la orice furnizor care folosește un API compatibil OpenAI. Iată cei cu linkuri presetate în aplicație:

- **GitHub Models** — github.com/marketplace/models (nivel zilnic gratuit, recomandat)
- **OpenAI** — platform.openai.com
- **OpenRouter** — openrouter.ai
- **Anthropic** — console.anthropic.com
- **Groq** — console.groq.com
- **Mistral** — console.mistral.ai
- **Together AI** — api.together.xyz

Poți folosi și un URL de bază **Personalizat** dacă rulezi propriul server sau folosești un alt serviciu.

## Cât costă?

Majoritatea furnizorilor taxează per **token**. Un token este aproximativ un cuvânt sau o parte dintr-un cuvânt. Plătești pentru tokenii pe care îi trimiți (întrebarea ta) plus tokenii pe care IA îi trimite înapoi (răspunsul).

### Prețuri tipice

Prețurile se schimbă, dar iată o idee aproximativă pentru mijlocul anului 2026:

- **Modele mici și rapide** (precum endpointurile mai ieftine de clasă GPT-3.5) costă o fracțiune de cent per mie de tokeni.
- **Modele mid-range** (precum GPT-4o sau Claude Sonnet) costă de obicei câțiva cenți per mie de tokeni.
- **Modele mari de raționament** (precum GPT-4.5 sau Claude Opus) pot costa între zece și douăzeci de cenți per mie de tokeni.

O întrebare tipică despre Biblie în Theodia ar putea folosi câteva sute până la câteva mii de tokeni în total. Asta înseamnă că majoritatea întrebărilor costă între **sub un cent și câțiva cenți**.

### Sfaturi pentru a păstra costurile scăzute

- Începe cu un model mai ieftin. Majoritatea întrebărilor biblice nu necesită cel mai scump model.
- Folosește Groq sau OpenRouter dacă vrei să încerci diferite modele și să compari prețurile.
- Urmărește-ți panoul de utilizare pe site-ul furnizorului.

## GitHub Models

[GitHub Models](https://github.com/marketplace/models) oferă un nivel gratuit fără abonament. Tot ce ai nevoie este un cont GitHub gratuit și un token de acces personal cu permisiunea de a citi modele.

**Cum să configurezi:**

1. Mergi la [github.com/settings/tokens](https://github.com/settings/tokens) și creează un **Token de acces personal (classic)**.
2. Oferă-i scope-ul `models:read` (sau selectează pur și simplu permisiunea pentru modele).
3. În Theodia, alege **GitHub Models** ca furnizor și lipește tokenul.

**Modelele din nivelul gratuit:**

- `openai/gpt-4.1-nano` — **15 cereri pe minut, 150 cereri pe zi**
- `openai/gpt-4.1-mini` — **15 cereri pe minut, 150 cereri pe zi**
- `openai/gpt-4.1` — **10 cereri pe minut, 50 cereri pe zi**
- `openai/gpt-4o` — **10 cereri pe minut, 50 cereri pe zi**

Aceste limite se resetează zilnic și sunt suficiente pentru studiul biblic obișnuit.

Pentru un ghid pas cu pas complet cu capturi de ecran, vezi ghidul dedicat [GitHub Models](theodia://help/github-models).

## Notă de confidențialitate

Când folosești un model IA la distanță, aplicația arată mai întâi un dialog de consimțământ care explică ce este trimis: mesajele tale, contextul versetului sau capitolului, apelurile și rezultatele instrumentelor, numele modelului configurat și cheia API în headerul cererii. Cererea merge direct către endpointul configurat de tine, nu prin Theodia. Majoritatea furnizorilor nu își folosesc datele tale pentru a-și antrena modelele, dar textul părăsește dispozitivul. Poți schimba sau revoca permisiunea oricând în **Setări → Asistent IA → Partajarea datelor IA la distanță**.

## Rezumat

- Ai nevoie de o cheie API pentru a folosi asistentul IA.
- Creează un cont la un furnizor, generează o cheie și lipește-o în Theodia.
- Majoritatea întrebărilor costă câțiva cenți sau mai puțin.
