---
title: Asistentul IA
level: advanced
category: ai
summary: Cum folosești asistentul IA pentru a înțelege versetele.
---

# Asistentul IA

Theodia are un asistent IA. Acesta te poate ajuta să înțelegi un verset, să răspunzi la o întrebare sau să discuți despre un subiect biblic.

## Cum activezi IA

IA este oprit implicit. Pentru a o activa:

1. Deschide **Setări**.
2. Atinge **Asistent IA**.
3. Atinge comutatorul pentru a o activa.

S-ar putea să ai nevoie să configurezi un cont sau o cheie. Aplicația te va ghida.

## Cum deschizi IA

Atinge fila **IA** din partea de jos a ecranului. Se deschide o fereastră de chat.

## Cum pui o întrebare

Atinge caseta din partea de jos. Tastează întrebarea. Atinge **Trimite**.

Câteva exemple de întrebări:

- „Ce înseamnă Ioan 3:16?”
- „Spune-mi despre cartea Romani.”
- „Care este rodul Duhului?”
- „Compară Predica de pe Munte din Matei și Luca.”

## Cum întrebi despre un verset anume

1. Deschide un capitol.
2. Atinge un verset pentru a deschide meniul de verset.
3. Atinge **Comentariu IA**.

Versetul este trimis către IA. Panoul IA se deschide cu versetul deja completat. Poți adăuga o întrebare, precum „Ce înseamnă asta?” sau „Cum ar trebui să aplic?”

## Lucruri importante de știut

- IA este un instrument, nu o persoană. Poate face greșeli.
- Verifică întotdeauna răspunsurile IA în lumina Bibliei.
- IA poate avea nevoie de internet. Nu funcționează offline.
- Când folosești IA, întrebările, contextul versetului și cheia API sunt trimise către endpointul ales. Prima dată când faci asta, aplicația îți cere permisiunea și îți arată exact ce este trimis. Poți schimba sau revoca acea permisiune ulterior în **Setări → Asistent IA → Partajarea datelor IA la distanță**.
- În unele regiuni, precum build-ul App Store din China continentală, asistentul IA nu este disponibil. În acel build sunt disponibile doar funcțiile offline ale Bibliei.

## Cum gestionezi conversațiile

Ecranul IA păstrează o listă cu conversațiile anterioare. Din listă poți deschide o conversație veche, începe una nouă sau șterge una de care nu mai ai nevoie.

Pentru sfaturi mai avansate, vezi ghidul [Scrierea unor prompteri mai buni](theodia://help/ai-prompts).
