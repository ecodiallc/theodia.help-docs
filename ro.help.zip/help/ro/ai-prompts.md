---
title: Scrierea unor prompteri mai buni
level: advanced
categories: ai
summary: Cum să îi pui întrebări asistentului IA astfel încât să primești răspunsuri bune.
---

# Scrierea unor prompteri mai buni

> **Mod:** Asistentul IA necesită modul **Savant**. Poți schimba modul în **Setări** → **Mod utilizator aplicație**.

Un „prompt" este întrebarea sau instrucțiunea pe care o dai IA. Prompteri mai buni primesc răspunsuri mai bune. Acest ghid îți arată cum.

## Fii specific

Greșit: „Spune-mi despre dragoste."
Mai bine: „În 1 Corinteni 13, ce fel de dragoste descrie Pavel și cum diferă ea de dragostea romantică?"

Cu cât oferi mai multe detalii, cu atât răspunsul este mai util.

## Oferă context

Greșit: „Ce înseamnă acest verset?"
Mai bine: „Citesc Romani 8 cu un grup mic. Ce înseamnă 'nicio condamnare' în acest capitol și cum se leagă de restul capitolului?"

Contextul ajută IA să își potrivească răspunsul situației tale.

## Cere un lucru pe rând

Greșit: „Spune-mi despre rugăciune, credință și vindecare."
Mai bine: „Spune-mi mai întâi despre rugăciune. După aceea voi întreba despre credință."

Să ceri un lucru pe rând păstrează răspunsurile concentrate.

## Cere IA să joace un rol

Poți cere IA să răspundă într-un anumit fel. De exemplu:

- „Răspunde ca și cum ai predica unui creștin nou.”
- „Răspunde ca un biblist.”
- „Răspunde pentru un copil de 10 ani.”

IA își potrivește răspunsul rolului.

## Folosește întrebări de continuare

Dacă primul răspuns nu este chiar potrivit, pune o întrebare de clarificare:

- „Poți spune mai simplu?”
- „Îmi poți da un exemplu?”
- „Ce spune greaca originală?”
- „Unde mai apare acest lucru în Biblie?”

O conversație bună este un dialog. IA își amintește ultimele câteva mesaje.

## Verifică răspunsurile IA

IA poate face greșeli. Este un instrument, nu un învățător.

- Compară răspunsul IA cu versetele la care te trimite.
- Folosește comentariile și lexicoanele din aplicație pentru o a doua opinie.
- Dacă răspunsul este despre doctrină, întreabă un pastor sau un prieten de încredere.

## Tipare comune de prompt

Iată câteva care funcționează bine:

- „Explică-mi acest verset ca și cum aș fi un creștin nou.”
- „Care este ideea principală a acestui capitol într-o singură propoziție?”
- „Listează trei aplicații pentru viața mea zilnică din acest pasaj.”
- „Ce întrebări ar trebui să pun despre acest verset înainte să predic?”
