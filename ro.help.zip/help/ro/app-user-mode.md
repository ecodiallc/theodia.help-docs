---
title: Modul de utilizator al aplicației
level: beginner
categories: [user-mode]
summary: Alege între modurile Cititor, Standard și Savant pentru a controla ce funcții sunt disponibile în aplicație.
---

# Modul de utilizator al aplicației

Theodia oferă trei moduri de utilizator care controlează ce funcții vezi. Alege-l pe cel care se potrivește modului în care vrei să folosești aplicația.

## Cititor

Cel mai simplu mod. Modul Cititor este pentru citirea Bibliei fără distrageri.

- Citește orice traducere biblică
- Folosește Modul focus pentru citire curată, pe tot ecranul
- Navighează prin cărți și capitole
- Fără instrumente de studiu, fără IA, fără marcaje, fără evidențieri

Modul Cititor este ideal dacă vrei ca Theodia să se simtă ca o Biblie digitală curată, fără nimic în plus.

## Standard

Modul Standard adaugă funcții de zi cu zi pentru studiul personal al Bibliei.

Tot ce are Cititor, plus:

- Marcaje, evidențieri și note
- Citire cu voce tare
- Cititor în Modul de studiu cu meniu pentru versete
- Biblia paralelă
- Comandă rapidă
- Căutare în Biblie
- Devoționale zilnice și cărți încorporate

Modul Standard este alegerea potrivită pentru majoritatea utilizatorilor care vor să citească, să marcheze și să caute în Biblie fără instrumente avansate de studiu.

## Savant

Modul cu toate funcțiile. Modul Savant deblochează toate instrumentele din Theodia pentru studiu biblic aprofundat.

Tot ce are Standard, plus:

- Comentarii și lexicoane
- Referințe încrucișate
- Dicționar biblic
- Informații cuvânt (căutări Strong)
- Asistent IA și Comentariu IA
- Meniul rapid

Modul Savant este conceput pentru pastori, studenți la seminar și oricine dorește instrumente de studiu în limbile originale și ajutoare bazate pe IA.

## Cum comuți între moduri

1. Deschide **Setări**.
2. Atinge **Mod utilizator aplicație**.
3. Alege **Cititor**, **Standard** sau **Savant**.

Schimbarea are efect imediat. Meniurile și butoanele la care nu ai acces în modul curent sunt ascunse.

## Cum alegi un mod

- **Cititor** — Vrei doar să citești Biblia, nimic altceva.
- **Standard** — Vrei marcaje, evidențieri, note, căutare și devoționale.
- **Savant** — Vrei fiecare instrument de studiu, inclusiv IA, comentarii și lexicoane.

Poți schimba modul oricând. Marcajele, evidențierile și notele tale nu sunt niciodată șterse când schimbi modul; sunt pur și simplu ascunse până când revii la un mod care le suportă.
