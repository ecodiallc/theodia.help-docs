---
title: Salvarea datelor tale
level: everyday
categories: settings
summary: Cum salvezi și restaurezi notele, evidențierile, marcajele și secretele tale.
---

# Salvarea datelor tale

Notele, evidențierile, marcajele și setările tale sunt salvate pe dispozitiv. Dacă îți pierzi telefonul, primești unul nou sau dezinstalezi aplicația, aceste date pot fi pierdute. Acest ghid îți arată cum să le salvezi.

## Cum deschizi setările de backup

1. Deschide **Setări**.
2. Atinge **Backup aplicație**.

## Cum faci un backup al aplicației

1. Deschide **Setări**.
2. Atinge **Backup aplicație**.
3. Atinge **Creează backup aplicație**.
4. Alege un folder pe dispozitiv pentru a salva fișierul. Poți alege și un drive în cloud.
5. Aplicația creează un singur fișier cu toate datele tale. Fișierul se termină în `.zip`.

## Cât de des să faci un backup

Fă un backup:

- După ce ai scris multe note.
- Înainte de a actualiza sistemul de operare al dispozitivului.
- Înainte de a dezinstala aplicația sau de a schimba telefonul.

Un obicei bun este un backup pe lună. Unii oameni fac backup în fiecare săptămână.

## Cum restaurezi dintr-un backup al aplicației

1. Deschide **Setări**.
2. Atinge **Backup aplicație**.
3. Atinge **Restaurează din backup aplicație**.
4. Alege fișierul de backup `.zip`.
5. Pentru fiecare tip de date (note, evidențieri, marcaje etc.), alege dacă să păstrezi ce este pe dispozitiv, să îl înlocuiești cu backupul sau să îl sari.
6. Atinge **Restaurează**.

Aplicația înlocuiește datele tale cu cele din backup. Acest lucru include:

- Note
- Evidențieri
- Marcaje
- Dosare de marcaje
- Setări (temă, mărime font, limbă)

## Backup de secrete

**Backupul aplicației** **nu** include secrete sensibile precum cheia ta API pentru IA sau tokenul GitHub. Pentru a le face backup separat, folosește **Backup secrete**.

### Salvează un backup de secrete

1. Deschide **Setări**.
2. Atinge **Backup aplicație**.
3. Sub **Backup secrete**, atinge **Salvează backup secrete**.
4. Introdu o parolă puternică și confirm-o.
5. Aplicația criptează secretele tale și partajează fișierul criptat. Salvează-l într-un loc sigur.

### Restaurează un backup de secrete

1. Deschide **Setări**.
2. Atinge **Backup aplicație**.
3. Sub **Backup secrete**, atinge **Restaurează backup secrete**.
4. Alege fișierul de backup de secrete criptat.
5. Introdu aceeași parolă pe care ai folosit-o la salvare.
6. Secretele tale sunt restaurate.

> **Important:** Dacă uiți parola, secretele nu pot fi recuperate. Nu există resetare.

## Lucruri de știut

- O restaurare **înlocuiește** categoriile alese de tine. Orice ai adăugat după backup va fi pierdut pentru acele categorii.
- Un backup al aplicației este un singur fișier `.zip`. Păstrează-l într-un loc sigur.
- Poți copia fișierul, îl poți muta sau îl poți stoca în orice serviciu de cloud.
- Backupurile aplicației nu includ traducerile biblice în sine. Acestea pot fi descărcate din nou din **Setări** → **Gestionează resursele**.
- Backupurile de secrete sunt criptate cu parola ta. Alege o parolă pe care o vei aminti.

## Sfat

Dacă ai mai mult de un dispozitiv, poți copia fișierul de backup pe fiecare dispozitiv și să îl restaurezi. Datele tale vor fi la fel pe ambele.
