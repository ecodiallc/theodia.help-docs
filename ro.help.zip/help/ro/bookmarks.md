---
title: Salvarea versetelor ca marcaje
level: everyday
categories: [annotate, read]
summary: Cum salvezi versete pentru a le găsi din nou.
---

# Salvarea versetelor ca marcaje

> **Mod:** Marcajele sunt disponibile în modurile **Standard** și **Savant**. Modul focus este doar pentru citire curată, fără distrageri. Poți schimba modurile în **Setări** → **Mod utilizator aplicație**.

Un marcaj salvează un verset sau un capitol de carte, ca să îl poți găsi din nou. Marcajele sunt ca semnele de carte dintr-o carte.

## Cum salvezi un verset ca marcaj

1. Deschide versetul.
2. Atinge versetul pentru a deschide meniul.
3. Atinge **Salvează** în meniu. O pictogramă în formă de stea marchează versetul ca salvat.

O bifă pe pictogramă înseamnă că versetul este acum marcat.

## Cum salvezi un capitol de carte

Când citești o carte (nu Biblia), poți marca tot capitolul:

1. Deschide capitolul.
2. Atinge pictograma **Marcaj** din partea de sus a ecranului.

## Cum îți vezi marcajele

Atinge fila **Marcaje** din partea de jos. Vezi o listă cu fiecare verset și capitol de carte salvat.

## Cum elimini un marcaj

- **Un singur verset:** Deschide versetul. Atinge versetul, apoi atinge din nou pictograma **Marcaj**. Bifa dispare.
- **Din listă:** În fila **Marcaje**, apasă lung pe un marcaj. Apare un meniu mic. Atinge **Șterge**. (Poți atinge și butonul mic × de pe rând.)

## Organizează cu dosare

Poți pune marcajele în dosare. De exemplu, poți avea un dosar numit „Pregătire predică" și altul numit „Încurajare".

Pentru a crea un dosar:

1. Deschide fila **Marcaje**.
2. Atinge **Gestionează dosarele** în partea de sus.
3. Atinge **+ Creează dosar** în partea de sus a listei de dosare.
4. Tastează un nume și atinge **Salvează**.

Nu poți crea două dosare cu același nume. Dacă un nume există deja, apare o eroare în caseta de creare a dosarului, ca să îl poți schimba și încerca din nou.

Pentru a pune un marcaj într-un dosar:

1. În fila **Marcaje**, apasă lung pe un marcaj.
2. Atinge **Mută în dosar**.
3. Alege dosarul, apoi atinge **Gata**.

## Importarea marcajelor

Poți aduce marcaje în Theodia din alte aplicații și fișiere.

Mergi la **Setări** → **Marcaje** → **Importă marcaje**. Alege **Importă din fișier** sau lipește din clipboard. Aplicația detectează automat formatul.

### Formate suportate

**Export JSON nativ** — Formatul folosit de funcția de export proprie a Theodia. Acesta păstrează dosarele și datele de creare.

**HTML de marcaje Netscape** — Formatul folosit de Chrome, Firefox și Safari când exportează marcaje. Dosarele sunt păstrate.

**CSV** — O foaie de calcul cu coloane. Aplicația caută coloanele `url` și `folder` (sau `href` / `category`). Exemplu:

```csv
url,folder
/bible/KJV/John/3,Favorite
/bible/KJV/Genesis/1,Pregătire predică
```

**Text simplu** — Fiecare linie este fie o referință biblică, fie un URL de aplicație, fie o directivă de dosar. Exemplu:

```
folder: Favorite
Ioan 3:16
Geneza 1:1
folder: Pregătire predică
Matei 5:1
```

- Liniile care încep cu `folder: <nume>` setează dosarul activ pentru toate marcajele următoare.
- Referințele biblice precum `Ioan 3:16` sunt convertite în marcaje în Biblia ta implicită.
- URL-urile de aplicație precum `/bible/KJV/John/3#v3_16` sau `/book/MyBook/1` sunt importate direct.
- Liniile care încep cu `#` sau `//` sunt tratate ca comentarii și ignorate.

### Sfaturi pentru import

- Marcajele duplicate sunt ignorate automat.
- URL-urile externe (cum ar fi linkuri BibleGateway) sunt convertite în marcaje de aplicație când este posibil.
- Dacă un dosar din fișierul de import există deja, marcajele sunt plasate în dosarul existent.

## Sfaturi

- Poți marca același verset în mai multe traduceri. Toate apar în listă.
- Marcajele rămân pe dispozitiv. Nu se sincronizează în cloud.
- Vezi ghidul [Salvarea datelor tale](theodia://help/backups) pentru a le păstra în siguranță.
