---
title: Alegerea unui model IA
level: advanced
categories: ai
summary: Cum alegi un model care funcționează bine cu instrumentele încorporate și capabilitățile Theodia.
---

# Alegerea unui model IA

> **Mod:** Asistentul IA necesită modul **Savant**. Poți schimba modul în **Setări** → **Mod utilizator aplicație**.

Nu fiecare model IA funcționează la fel în Theodia. Cea mai bună experiență vine de la un model care suportă **apelul de instrumente** — capacitatea IA de a folosi funcțiile încorporate ale Theodia, precum căutarea de versete, căutarea în Scriptură, citirea de comentarii și navigarea în aplicație.

## Ce este apelul de instrumente?

Când îi pui o întrebare asistentului IA al Theodia, IA poate face mai mult decât să vorbească. Poate și **acționa**. De exemplu:

- Spui: „Arată-mi Ioan 3:16 în ESV.” IA apelează un instrument pentru a deschide acel verset în Cititor.
- Spui: „Ce spun comentariile mele despre Romani 8:28?” IA apelează un instrument pentru a prelua conținutul comentariului.
- Spui: „Salvează acest verset ca marcaj.” IA apelează un instrument pentru a crea un marcaj.

Modelele care nu suportă apelul de instrumente pot oferi doar răspunsuri text. Ele nu pot căuta, naviga sau schimba nimic în aplicație.

## Ce modele suportă instrumente?

### Modele la distanță

Majoritatea modelelor moderne la distanță de la furnizori majori suportă apelul de instrumente compatibil OpenAI. În general:

- **Modele mari** (precum GPT-4o, Claude Sonnet/Opus, Gemini Pro) gestionează instrumentele în mod fiabil și pot înlănțui mai multe apeluri într-o singură conversație. Numele furnizorului și ID-urile modelului sunt afișate în aplicație pentru comoditate; serviciul real la care te conectezi este cel al cărui endpoint și cheie le configurezi.
- **Modele mai mici sau mai ieftine** pot suporta instrumente, dar sunt mai puțin fiabile. S-ar putea să ignore un apel de instrument sau să îl formateze incorect.
- **Modele foarte vechi sau specializate** adesea nu suportă deloc instrumentele.

Dacă nu ești sigur, testează modelul în Theodia. Întreabă-l „Arată-mi Geneza 1:1” sau „Caută în Biblie versete despre dragoste.” Dacă versetul se deschide sau apar rezultatele căutării, apelul de instrumente funcționează.

## Modele recomandate pentru Theodia

Acestea sunt alegeri bune care echilibrează costul, calitatea și suportul pentru instrumente:

- **OpenAI GPT-4o** — suport excelent pentru instrumente, rapid, gestionează bine întrebări complexe în mai mulți pași.
- **Anthropic Claude Sonnet / Opus** — folosire foarte fiabilă a instrumentelor, excelent pentru pasaje lungi și studiu detaliat.
- **Groq** (diverse modele) — inferență rapidă, adesea gratuită sau foarte ieftină, suportul pentru instrumente variază în funcție de model.
- **OpenRouter** — îți permite să încerci multe modele dintr-un singur cont. Caută modele care listează „function calling" sau „tools" printre capabilități.
- **[GitHub Models](theodia://help/github-models)** — furnizorul gratuit recomandat. Acces la modele OpenAI, Anthropic și altele prin contul tău GitHub, cu un nivel zilnic gratuit generos. Folosește aceleași ID-uri de model de tipul `openai/gpt-4o`.

## Modele de evitat

- **Modele pure de completare text** (precum GPT-3 base sau LLaMA brut, fără tuning de instrucțiuni) de obicei nu suportă instrumente.
- **Modele de imagine sau vision** axate pe imagini mai degrabă decât text pot lipsi suportul pentru instrumente.
- **Modele extrem de mici** sub 1 miliard de parametri este puțin probabil să folosească instrumentele corect, chiar dacă API-ul pretinde că le suportă.

## Cum testezi suportul pentru instrumente

Theodia verifică automat suportul pentru instrumente. După ce configurezi un model în **Setări → Asistent IA**, atinge **Verificare conexiune**. Odată ce conexiunea reușește, aplicația trimite o a doua cerere cu o definiție de instrument de exemplu. Vei vedea unul dintre cele două rezultate:

- **✓ Instrumente suportate** — Modelul acceptă apeluri de instrumente și poate folosi funcțiile încorporate ale Theodia.
- **✗ Instrumente nesuportate** — Modelul respinge cererea de instrument. Va răspunde doar în text și nu poate deschide versete, căuta sau gestiona marcaje pentru tine.

Dacă vezi „Instrumente nesuportate", modelul poate funcționa în continuare ca asistent de chat simplu, dar nu vei avea experiența integrată hands-free.

Poți verifica și manual cerând IA să facă ceva:

- „Arată-mi Matei 5:3 în KJV.” — Ar trebui să deschidă versetul în Cititor.
- „Ce spune lexiconul despre cuvântul 'agape' în Ioan 3:16?” — Ar trebui să returneze date de lexicon.
- „Caută în Biblie versete despre iertare.” — Ar trebui să returneze rezultate de căutare.
- „Salvează un marcaj la Marcu 12:30.” — Ar trebui să creeze un marcaj.

Dacă IA îți dă o descriere text în loc să facă efectiv acțiunea, modelul se luptă să își folosească instrumentele, chiar dacă aplicația a raportat suport.

## Ce se întâmplă dacă modelul meu nu suportă instrumente?

Îl poți folosi în continuare. IA va răspunde în text, iar tu poți căuta manual versete, căuta și naviga în aplicație singur. Dar vei pierde experiența hands-free și integrată care face Theodia puternică.

## Rezumat

- Alege un model cu suport pentru **apel de instrumente / function calling** pentru cea mai bună experiență Theodia.
- **Modelele mari la distanță** gestionează instrumentele cel mai fiabil.
- Testează orice model cu comenzi simple precum „Arată-mi Geneza 1:1” pentru a verifica suportul.
