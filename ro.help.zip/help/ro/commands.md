---
title: Comenzi rapide
level: everyday
categories: [layout, study]
summary: Caseta de comandă rapidă îți permite să sari la orice funcție tastând o scurtă instrucțiune. Învață formatele și exemplele suportate.
---

# Comenzi rapide

**Comanda rapidă** îți permite să sari la aproape orice parte a Theodia tastând o scurtă instrucțiune. O poți folosi de pe fila Acasă sau din **Meniu rapid** (pictograma **▼** din antet).

## Cum funcționează

1. Atinge caseta Comandă rapidă.
2. Tastează o comandă.
3. Apasă tasta de execuție de pe tastatură.

Aplicația citește comanda și te duce direct la ecranul potrivit.

## Fără prefix slash

Comenzile **nu** folosesc prefixul `/`. Sunt introduse ca text simplu:

```
ioan 3:16
caută dragoste
backup
```

Dacă tastezi `/settings`, prefixul `/` o face nerecunoscută.

## Referințe biblice

Tastează orice referință biblică pentru a o deschide în cititor.

```
psalmii 23
ioan 3:16
matei 5:1
1 cor 15:10
```

Numele cărților pot fi recunoscute prin nume complet sau abreviere. În limbile UI non-engleză poți tasta numele cărților și în limba activă.

## Căutare

```
caută avraam
caută dragoste
caută credință nu fapte
```

## Marcaje, comparare, comentariu, referințe încrucișate și informații cuvânt

```
marcaj ioan 3:16
compară geneza 1:1
comentariu ioan 1
comentariuia efeseni 2:8
xref 1 cor 15:10
informații cuvânt ioan 1:1
```

Aceste comenzi deschid instrumentul numit pentru pasajul dat.

## Lexicon

Tastează un număr Strong pentru a deschide intrarea de lexicon.

```
g1161
h7225
```

## Devoționale

```
devoțional
devoțional smith
devoțional daily
```

Fără nume, aceasta deschide lista de devoționale.

## Scurtături de navigare

```
note
repere
marcaje
flashcarduri
playlist
theoscript
resurse
citește ioan 3:16
```

Acestea sări direct la ecranul numit sau deschid un pasaj în cititor.

## Comutare traducere

Tastează abrevierea unei traduceri pentru a comuta la ea.

```
kjv
web
trlit
ohgb
```

Pe ecranul cititorului, traducerea se schimbă în loc. Oriunde altundeva, deschide traducerea la pasajul tău cel mai recent.

## Verbe de comandă localizate

Verbele de comandă publice pot fi tastate în limba UI activă **sau** în engleză. Engleza funcționează întotdeauna ca rezervă. Comenzile ascunse (scurtături de setări, comenzi de instalare, Easter eggs) păstrează doar sintaxa engleză.

## Ajutor

Tastează `ajutor` sau `comenzi` în caseta Comandă rapidă pentru a deschide oricând referința de comenzi din aplicație.
