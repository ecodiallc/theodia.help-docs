---
title: Comentarii și lexicoane
level: everyday
categories: study
summary: Cum cauți înțelesuri ale cuvintelor și citești note de studiu.
---

# Comentarii și lexicoane

> **Mod:** Comentariile și lexicoanele necesită modul **Savant**. Poți schimba modurile în **Setări** → **Mod utilizator aplicație**.

Theodia include două instrumente de studiu: **comentarii** și **lexicoane**. Te ajută să înțelegi Biblia mai în profunzime.

## Ce este un comentariu?

Un comentariu este o carte de note de studiu scrisă de un biblist. Pentru un verset dat, un comentariu îți spune contextul, înțelesul și cum se potrivește versetul în restul Bibliei.

## Ce este un lexicon?

Un lexicon este un dicționar al cuvintelor biblice. Îți spune cuvântul original în ebraică sau greacă, ce înseamnă și cum este folosit în Biblie.

## Cum deschizi un comentariu

1. Deschide un capitol.
2. Atinge un verset.
3. Atinge **Comentariu**.

Se deschide un panou. Acesta arată note de la un biblist despre acel verset.

## Cum deschizi un lexicon

1. Deschide un capitol într-o Biblie care include numerele Strong.
2. Atinge un număr Strong în verset (de exemplu, G1234 sau H1234).
3. Se deschide un panou care arată cuvântul original în ebraică sau greacă, înțelesul lui și alte versete care îl folosesc.

Numerele Strong apar într-o culoare diferită în textul versetului, așa că ies în evidență față de cuvintele obișnuite.

## Alege un alt comentariu

Comentariul este ales dintr-un meniu derulant în partea de sus a panoului de comentariu. Deschide panoul, apoi atinge meniul derulant pentru a vedea comentariile instalate. Alege altul.

## Alege un alt lexicon

Lexiconul este ales dintr-un meniu derulant în partea de sus a panoului de lexicon. Deschide panoul, apoi atinge meniul derulant pentru a vedea lexicoanele instalate. Alege altul.

## Resurse încorporate

Theodia vine cu un set încorporat de comentarii și lexicoane. Acestea sunt incluse în aplicație și funcționează offline. Comentarii și lexicoane suplimentare nu pot fi instalate sau descărcate separat.

## Când să le folosești

- **Comentariile** sunt bune când un verset este greu de înțeles. Notele îți oferă context.
- **Lexicoanele** sunt bune pentru studiile de cuvinte. Îți spun înțelesul exact al unui cuvânt în limba originală.

## Sfat

Dacă un verset are o notă pe care vrei să o păstrezi, fă o captură de ecran sau copiază textul într-o notă. (Vezi ghidul [Scrierea de note](theodia://help/notes).)

## Dicționarul biblic în limbaj simplu

Pentru definiții în engleză ale cuvintelor și conceptelor biblice (covenant, atonement, Pharisees etc.), Theodia include și instrumentul Dicționar biblic. Deschide-l din meniul versetului atingând **Dicționar** (📖). Acesta este diferit de lexicon: lexicoanele explică cuvintele originale în ebraică și greacă, în timp ce dicționarul explică cuvântul englez în limbaj simplu. Vezi ghidul [Dicționarul biblic](theodia://help/dictionary) pentru cum să îl folosești.
