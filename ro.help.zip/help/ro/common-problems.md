---
title: Probleme comune
level: everyday
categories: trouble
summary: Soluții rapide pentru problemele pe care le poți întâlni.
---

# Probleme comune

Acest ghid acoperă problemele cele mai frecvente. Dacă problema ta nu este aici, vezi ghidul [Unde să pui întrebări](theodia://help/getting-more-help).

## Aplicația este lentă

1. Închide alte aplicații care rulează în fundal.
2. Repornește aplicația.
3. Repornește dispozitivul.

## Nu găsesc o traducere biblică

1. Deschide **Setări** → **Gestionează resursele** pentru a vedea ce este instalat.
2. Dacă traducerea nu este acolo, atinge **Descarcă de pe GitHub**.
3. În modalul de descărcare, atinge fila **Biblii** (sau **Biblii globale**) și selectează traducerea dorită.
4. Atinge **Instalează selectate** și așteaptă finalizarea descărcării.
5. Ai nevoie de internet pentru a descărca o nouă traducere.

## Notițele sau marcajele mele au dispărut

1. Verifică că te uiți la fila potrivită. Notițele sunt în fila **Note biblice**. Marcajele sunt în fila **Marcaje**.
2. Dacă ai restaurat recent un backup, este posibil ca backupul să fi înlocuit datele tale. Verifică data backupului.
3. Dacă ai dezinstalat și reinstalat aplicația, datele tale au fost pierdute. Data viitoare, fă mai întâi un backup.

## Căutarea nu găsește versete

1. Asigură-te că ai scris cuvântul corect.
2. Încearcă un cuvânt mai scurt. „Dragoste" găsește mai multe versete decât „iubind".
3. Asigură-te că ai instalată traducerea biblică potrivită. Căutarea funcționează doar în traducerile pe care le ai.

## Citirea cu voce tare nu funcționează

1. Asigură-te că volumul dispozitivului este ridicat.
2. Asigură-te că aplicația are permisiunea de a folosi difuzorul.
3. Încearcă o altă traducere. Unele traduceri funcționează mai bine cu citirea cu voce tare decât altele.
4. Pentru o listă de verificare pas cu pas, vezi ghidul [Citirea cu voce tare](theodia://help/tts).

## Aplicația se blochează repetat

1. Repornește aplicația.
2. Repornește dispozitivul.
3. Dacă problema persistă, te rugăm să o raportezi. Vezi ghidul [Unde să pui întrebări](theodia://help/getting-more-help).

## Vreau să dezinstalez aplicația

Poți dezinstala Theodia ca orice altă aplicație. Înainte de a face acest lucru, fă un backup al datelor tale. După dezinstalare, datele de pe dispozitiv sunt pierdute.

## Încă nu ieși din impas?

Vezi ghidul [Unde să pui întrebări](theodia://help/getting-more-help). Acolo poți găsi linkuri pentru a raporta o problemă și pentru a întreba comunitatea.

Poți căuta și ghidurile de ajutor de pe ecranul principal **Ajutor și ghiduri**. Tastează un cuvânt precum `notificări`, `caută` sau `marcaje` pentru a găsi ghidul potrivit.
