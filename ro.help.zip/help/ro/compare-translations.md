---
title: Compararea traducerilor
level: everyday
categories: [read, study]
summary: Cum să vezi același verset în fiecare traducere pe care ai instalat-o.
---

# Compararea traducerilor

> **Mod:** Instrumentul **Compară** este disponibil în modurile **Standard** și **Savant**. Modul focus este doar pentru citire curată, fără distrageri. Poți schimba modurile în **Setări** → **Mod utilizator aplicație**.

Instrumentul **Compară** arată un singur verset în fiecare traducere biblică instalată, totul într-un singur panou. Este util când vrei să vezi cum tratează diferiți traducători un verset dificil, sau când alegi o traducere și vrei să privești același verset în fiecare.

## Cum deschizi Compară

1. Deschide un capitol în orice traducere.
2. Atinge un verset pentru a deschide meniul versetului.
3. Atinge **Compară** (⇄).

Se deschide un panou. Bara de titlu arată referința (de exemplu, „Ioan 3:16 — Compară"). Panoul listează același verset în fiecare traducere instalată. Traducerea ta curentă apare prima; restul sunt sortate alfabetic.

## Cum arată panoul

Panoul este o **listă verticală**, nu coloane una lângă alta. Fiecare rând este o traducere:

- **Numele traducerii** (de exemplu, „KJV") este în partea de sus a rândului. Poate fi atins.
- **Textul versetului** este sub nume.

Derulează panoul pentru a vedea toate traducerile. Orice traducere instalată pe dispozitiv va apărea aici. Dacă o traducere nu are cartea sau versetul respectiv, este omisă.

## Cum citești versetul într-o altă traducere

Atinge numele traducerii din rând. Panoul Compară se închide și același capitol se deschide în traducerea aleasă, cu versetul respectiv vizibil. Aceasta este cea mai rapidă cale de a sări de la comparație direct la citirea unei traduceri anume.

## Cum închizi Compară

- **Pe telefon:** atinge X-ul din dreapta sus a panoului.
- **Pe tabletă:** atinge X-ul din antetul panoului, sau atinge în afara panoului.

Revii la vizualizarea capitolului în traducerea ta originală.

## Când să folosești Compară

- **Alegi o traducere.** Deschide un verset pe care îl știi bine în traducerea curentă, apoi Compară pentru a-l vedea în altele. Diferențele ies în evidență.
- **Verset dificile.** Un verset confuz într-o traducere este adesea mai clar în alta.
- **Studii de cuvinte.** Uită-te cum tratează diferiți traducători un cuvânt sau o expresie cheie.

Pentru o comparație rapidă a unui capitol întreg în mai multe traduceri simultan, folosește în schimb **vizualizarea paralelă**. Vezi ghidul [Mod de studiu](theodia://help/study-mode) pentru a afla cum o activezi.
