---
title: Crearea propriilor resurse
level: advanced
categories: resources
summary: Cum creezi Biblii, comentarii, cărți, devoționale și lexicoane personalizate și cum le imporți în Theodia.
---

# Crearea propriilor resurse

Theodia suportă resurse personalizate în formatul Unique Bible App. Fiecare resursă este un fișier SQLite cu o structură specifică de tabele. Poți crea aceste fișiere pe un computer și apoi să le imporți în aplicație.

## Tipuri de fișiere și tabele necesare

### Biblii (`.bible`)

Un fișier de Biblie este o bază de date SQLite cu cel puțin una dintre aceste tabele:

- **`Verses`** — coloane: `Book` (integer, 1-66), `Chapter` (integer), `Verse` (integer), `Scripture` (text)
- **`Bible`** — coloane: `Book` (integer), `Chapter` (integer), `Verse` (integer), `Scripture` (text)

Poți include și un tabel **`Details`** cu coloane de metadate precum `Description`, `Abbreviation` și `Version`.

Exemplu SQL:

```sql
-- Tabelul principal de text
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- Tabel opțional de metadate
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### Comentarii (`.commentary`)

Comentariile vin în trei tipuri: **carte**, **capitol** și **verset**. Tipul este determinat de **prima literă a numelui fișierului**.

#### Comentarii de carte — numele fișierului începe cu `b`

Un comentariu de carte acoperă o întreagă carte a Bibliei într-o singură intrare. Tabelul `Commentary` are nevoie de coloanele `Book` și `Scripture` (sau `Content`). Nu sunt necesare coloane `Chapter` sau `Verse`.

- **`Commentary`** — coloane: `Book` (integer), `Scripture` (text) sau `Content` (text)

Exemplu SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

Exemplu de nume de fișier: `bMyCommentary.commentary`

#### Comentarii de capitol — numele fișierului începe cu `c`

Un comentariu de capitol acoperă fiecare capitol al unei cărți biblice.

- **`Commentary`** — coloane: `Book` (integer), `Chapter` (integer), `Scripture` (text) sau `Content` (text)

Exemplu SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

Exemplu de nume de fișier: `cMyCommentary.commentary`

#### Comentarii de verset — numele fișierului începe cu `v`

Un comentariu de verset acoperă versete individuale. Tabelul `Commentary` are nevoie de coloanele `Book`, `Chapter`, `Verse` și `Scripture` (sau `Content`).

- **`Commentary`** — coloane: `Book` (integer), `Chapter` (integer), `Verse` (integer), `Scripture` (text) sau `Content` (text)

Exemplu SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

Exemplu de nume de fișier: `vMyCommentary.commentary`

### Cărți (`.book`)

Un fișier de carte este o bază de date SQLite cu un tabel `Reference`.

- **`Reference`** — coloane: `id` (integer), `Chapter` (text), `Content` (text)

Fiecare rând este un capitol. Coloana `Chapter` este titlul capitolului. Coloana `Content` este corpul capitolului, care poate include HTML (`<b>`, `<i>`, `<br>`, etc.).

Exemplu SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

Poți crea cărți și din fișiere Markdown. Aplicația poate importa fișiere `.md` unde `#` este titlul cărții și `##` marchează capitolele. Markdown este convertit automat în HTML.

### Devoționale (`.devotional`)

Un fișier devoțional este o bază de date SQLite cu un tabel `devotional`.

- **`devotional`** — coloane: `month` (integer, 1-12), `day` (integer, 1-31), `devotion` (text)

Fiecare rând este citirea unei zile. Aplicația caută intrarea după luna și ziua curente.

Exemplu SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### Lexicoane (`.lexicon`)

Un fișier de lexicon este o bază de date SQLite cu un tabel `Lexicon`.

- **`Lexicon`** — coloane: `Topic` (text, numărul Strong), `Definition` (text, intrarea din lexicon)

Coloana `Topic` conține numărul Strong (de exemplu, `G1161` sau `H7225`). Coloana `Definition` conține textul complet al intrării, care poate include HTML.

Exemplu SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

Lexicoanele alimentează instrumentul Informații cuvânt. Când atingi un cuvânt într-o Biblie interlineară, aplicația caută numărul Strong în lexicoanele instalate.

## Crearea unui fișier pe computer

1. Instalează un editor SQLite (DB Browser for SQLite, SQLiteStudio sau instrumentul în linie de comandă `sqlite3`).
2. Creează un nou fișier de bază de date.
3. Creează tabelul necesar și inserează datele.
4. Salvează fișierul cu extensia corectă (`.bible`, `.commentary`, `.book`, `.devotional` sau `.lexicon`).

## Importarea în Theodia

1. Transferă fișierul pe dispozitiv (AirDrop, email, cloud storage sau USB).
2. Deschide **Theodia**.
3. Mergi la **Setări** → **Gestionează resursele**.
4. Atinge **Importă din fișier**.
5. Selectează fișierul tău.

Aplicația validează fișierul (verifică existența tabelului necesar), îl copiază în folderul de date al aplicației și îl activează automat. Dacă fișierul este invalid, vezi un mesaj de eroare care explică ce este în neregulă.

## Limitări

- Nu poți suprascrie resursele încorporate. Dacă încerci să imporți un fișier cu același nume ca o Biblie, comentariu sau carte încorporată, importul eșuează.
- Fișierele de Biblie au nevoie de un tabel `Verses` sau `Bible`. Dacă niciunul nu există, importul eșuează.
- Fișierele de comentarii au nevoie de un tabel `Commentary`.
  - Comentariile de carte au nevoie de coloanele `Book` și `Scripture` (sau `Content`).
  - Comentariile de capitol au nevoie de coloanele `Book`, `Chapter` și `Scripture` (sau `Content`).
  - Comentariile de verset au nevoie de coloanele `Book`, `Chapter`, `Verse` și `Scripture` (sau `Content`).
- Fișierele de cărți au nevoie de un tabel `Reference`.
- Fișierele de lexicoane au nevoie de un tabel `Lexicon`.
- Fișierele devoționale au nevoie de un tabel `devotional`.

## Sfaturi

- Menține dimensiunile fișierelor rezonabile. Fișiere SQLite foarte mari pot cauza probleme de memorie pe dispozitivele mai vechi.
- Testează fișierul pe computer mai întâi. Deschide-l într-un browser SQLite și rulează `SELECT * FROM` tabelul necesar pentru a verifica că datele arată corect.
- Pentru Biblii, asigură-te că coloana `Book` folosește numere (1 = Geneza, 66 = Apocalipsa).
- Pentru Comentarii, poți folosi fie `Scripture`, fie `Content` ca coloană de text al comentariului.
- Pentru Cărți, HTML-ul din coloana `Content` este redat la citire. Păstrează-l simplu: `<b>`, `<i>`, `<br>` și `<hr>` sunt sigure.

## Unde găsești resurse existente

Theodia poate citi resurse din proiectul [Unique Bible App](https://github.com/eliranwong/UniqueBible). Sunt disponibile acolo multe Biblii, comentarii, cărți și alte resurse în formatul SQLite corect. Vezi ghidul [Obținerea de resurse suplimentare](theodia://help/getting-core-files) pentru cum să le găsești și să le adaugi.
