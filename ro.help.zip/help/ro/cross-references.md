---
title: Referințe încrucișate
level: everyday
categories: study
summary: Cum găsești versete care se leagă de cel pe care îl citești.
---

# Referințe încrucișate

> **Mod:** Referințele încrucișate sunt disponibile în modurile **Standard** și **Savant**. Modul focus este doar pentru citire curată, fără distrageri. Poți schimba modurile în **Setări** → **Mod utilizator aplicație**.

O „referință încrucișată" este un alt verset care vorbește despre același lucru ca versetul pe care îl citești. Panoul de referințe încrucișate îți arată ce versete din Biblie se leagă între ele.

## Cum deschizi referințele încrucișate

1. Deschide un capitol.
2. Atinge un verset pentru a deschide meniul.
3. Atinge **Referințe încrucișate**.

Se deschide un panou. Acesta arată o listă de alte versete care se leagă de cel pe care l-ai atins.

## Cum citești lista

Fiecare rând este un verset conectat. Vezi:

- Cartea, capitolul și versetul.
- O scurtă previzualizare a textului versetului.
- Un scor care arată cât de puternică este legătura.

## Cum sari la un verset conectat

Atinge orice rând. Aplicația deschide acel verset pentru tine. Când termini, atinge butonul înapoi pentru a reveni.

## Ce înseamnă scorul

Scorul îți spune cât de strâns sunt conectate versetele. Un scor mare înseamnă o legătură puternică și directă. Un scor mic înseamnă o legătură mai slabă.

## Folosește referințele încrucișate pentru studiu

Referințele încrucișate sunt utile pentru:

- **Studii de cuvinte.** Vezi cum folosește Biblia un cuvânt în diferite locuri.
- **Studii tematice.** Urmărește o temă, precum „dragoste" sau „legământ", prin Scriptură.
- **Pregătirea predicilor.** Găsești versete de susținere rapid.

## Sfat

Referințele încrucișate funcționează cel mai bine cu o traducere cuvânt-cu-cuvânt precum WEB.
