---
title: Devoționale zilnice
level: everyday
categories: [content, read]
summary: Cum citești un scurt devoțional în fiecare zi.
---

# Devoționale zilnice

Un devoțional este o scurtă citire pentru o zi. De obicei conține un verset, o scurtă reflecție și o întrebare de meditat. Theodia vine cu o mică bibliotecă de devoționale.

## Cum deschizi un devoțional

1. Atinge fila **Devotionale** din partea de jos a ecranului.
2. Vezi o listă cu devoționalele instalate pe dispozitiv.
3. Atinge unul pentru a-l deschide.

## Cum citești un devoțional

1. Deschide devoționalul.
2. Derulează pentru a citi.
3. Folosește butoanele din partea de sus pentru a:
   - Atinge **data** pentru a sări la o altă zi.
   - Atinge **steaua** pentru a marca ziua.
   - Atinge **difuzorul** pentru a-l citi cu voce tare (dacă dispozitivul tău suportă). Vezi ghidul [Citirea cu voce tare](theodia://help/tts) pentru a alege o voce.
   - Atinge **Anterior** sau **Următorul** pentru a trece la ziua precedentă sau următoare.

## Cum salvezi un verset dintr-un devoțional

1. Deschide devoționalul.
2. Atinge un verset.
3. Atinge **Salvează** sau **Evidențiază**.

Versetul este salvat în Marcaje sau în Repere.

## Cum scrii o notă pe un devoțional

1. Deschide devoționalul.
2. Atinge un verset.
3. Atinge **Notă**. Scrie reflecția sau rugăciunea ta. Atinge **Salvează**.

Nota apare în fila Note biblice.

## Sfaturi

- Devoționalele nu au nevoie de internet. Funcționează offline.
- Dacă dorești mai multe devoționale, vezi ghidul [Obținerea de resurse suplimentare de pe GitHub](theodia://help/getting-core-files).
