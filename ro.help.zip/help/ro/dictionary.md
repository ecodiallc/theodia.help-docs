---
title: Dicționarul biblic
level: everyday
categories: study
summary: Caută cuvinte și concepte biblice în resursele de dicționar instalate. Deschide-l din meniul versetului sau dintr-o intrare de lexicon, apoi atinge orice cuvânt pentru a-l vedea în fiecare dicționar.
---

# Dicționarul biblic

> **Mod:** Dicționarul biblic necesită modul **Savant**. Poți schimba modurile în **Setări** → **Mod utilizator aplicație**.

Instrumentul Dicționar biblic caută un cuvânt sau o expresie în fiecare resursă de dicționar pe care ai instalat-o. Este util când vrei o definiție în limbaj simplu a unui cuvânt biblic, o descriere a unei persoane sau a unui loc, sau un scurt articol despre un concept teologic.

Dicționarul biblic este diferit de instrumentul **Informații cuvânt**, care caută cuvântul ebraic sau grecesc original din spatele unui verset. Dicționarul citește cuvântul **englez** pe care îl atingi și îți arată ce spun dicționarele tale instalate despre el. Pentru note de traducere cuvânt-cu-cuvânt, vezi ghidul [Comentarii și lexicoane](theodia://help/commentaries-and-lexicons).

## Cum deschizi Dicționarul

Sunt două căi de a deschide dicționarul.

### Din meniul versetului

1. Deschide un capitol în [Mod de studiu](theodia://help/study-mode).
2. Atinge un verset pentru a deschide meniul versetului.
3. Atinge **Dicționar** (📖).

Se deschide un panou cu titlul referinței versetului (de exemplu, „Ioan 3:16"). Textul versetului este în partea de sus, fiecare cuvânt putând fi atins. Sub verset este un rând de jetoane care arată fiecare dicționar instalat. Dedesubt este definiția, care este goală până când atingi un cuvânt.

### Dintr-o intrare de lexicon

Când citești o intrare de lexicon în panoul Informații cuvânt, unele intrări conțin linkuri albastre către articole de dicționar înrudite. Atinge oricare dintre acele linkuri. Lexiconul se închide și dicționarul se deschide la articolul respectiv. Aceasta este cea mai rapidă cale de a sări de la un cuvânt grecesc sau ebraic la o explicație simplă a înțelesului lui.

## Cum funcționează vizualizarea versetului

Când deschizi dicționarul din meniul unui verset, versetul apare în partea de sus a panoului ca o listă de cuvinte pe care poți să atingi. Cuvintele comune în engleză precum „the", „and", „of", „to" și „a" nu sunt atingibile. Toate celelalte cuvinte sunt. Fiecare cuvânt atingibil este colorat și îngroșat, ca să iasă în evidență din restul versetului.

Atinge orice cuvânt din verset. Theodia caută în fiecare dicționar instalat o potrivire exactă pentru acel cuvânt. Rândul de jetoane de jos se actualizează pentru a arăta ce dicționare au o intrare: dicționarele care nu au o intrare pentru cuvânt sunt estompate. Primul dicționar cu o intrare este selectat automat, iar definiția lui apare sub rândul de jetoane.

Cuvântul pe care l-ai atins este evidențiat în textul versetului din partea de sus a panoului, așa că știi mereu ce cauți.

## Comutarea între dicționare

Fiecare dicționar instalat este arătat ca un mic jeton sub verset. După ce atingi un cuvânt:

- **Jeton cu culoare solidă** — acest dicționar are o intrare pentru cuvântul atins. Atinge-l pentru a comuta la definiția acelui dicționar.
- **Jeton estompat** — acest dicționar nu are o intrare pentru acel cuvânt. Este afișat cenușiu, ca să vezi dintr-o privire care dicționare acoperă cuvântul, iar jetonul nu poate fi atins.

Dicționarul selectat este evidențiat. Atinge orice alt jeton solid pentru a citi același cuvânt în acel dicționar. Definiția de dedesubt se actualizează imediat.

Dacă cuvântul există doar într-unul dintre dicționarele tale instalate, doar acel jeton este solid, iar restul sunt estompate.

## Ce arată panoul

Panoul de dicționar are trei părți, de sus în jos:

- **Versetul** — versetul din care ai deschis dicționarul. Cuvintele sunt atingibile, iar cuvântul atins cel mai recent este evidențiat.
- **Rândul de jetoane** — fiecare dicționar instalat. Solid înseamnă „are intrare pentru cuvântul atins". Estompat înseamnă „nu are intrare pentru acel cuvânt".
- **Definiția** — articolul din dicționarul selectat. Text simplu, formatat cu paragrafe și titluri. Linkurile interne către alte intrări de dicționar sunt atingibile; atingând una se deschide acea intrare în dicționar.

## Ce se întâmplă dacă nu se găsește nicio intrare

Dacă atingi un cuvânt pe care niciunul dintre dicționarele tale instalate nu îl acoperă, panoul arată un scurt mesaj „nu s-au găsit intrări" în locul unei definiții. Acest lucru este comun pentru cuvinte foarte obișnuite precum „year" sau „come", care nu sunt cuvinte teologice biblice, chiar dacă apar frecvent în Biblie. Încearcă un cuvânt mai specific, sau folosește în schimb instrumentul Informații cuvânt al lexiconului, care lucrează cu textul grecesc și ebraic original.

## Ce se întâmplă dacă nu este instalat niciun dicționar

Dicționarul are nevoie de cel puțin un fișier de resurse dicționar pentru a fi util. Theodia vine cu unul. Dacă l-ai eliminat sau rulezi o instalare personalizată fără dicționare, vizualizarea versetului apare în continuare și cuvintele sunt atingibile, dar rândul de jetoane este gol și fiecare căutare returnează „nu s-au găsit intrări".

Dicționarele suplimentare nu pot fi instalate separat.

## Sfaturi

- Dicționarul caută **potriviri exacte de cuvinte**. Atingând „love" găsești intrări intitulate „love", dar nu „loved" sau „loving". Pentru a căuta o formă înrudită, folosește instrumentul Informații cuvânt al lexiconului pe cuvântul grecesc sau ebraic.
- Rândul de jetoane este la fel pe telefon și pe tabletă. Pe tabletă dicționarul se deschide ca un panou lateral lângă capitol; pe telefon se deschide ca un modal pe tot ecranul. Ambele au aceeași structură în trei părți.
- Atingerea unui cuvânt dintr-un alt verset deschide un verset nou în panou. Selecția ta anterioară este ștearsă. Atinge un cuvânt în noul verset pentru a începe o nouă căutare.
- Unele intrări de dicționar fac trimitere la același cuvânt în alt dicționar. Atinge acele linkuri interne pentru a urmări firul prin toate dicționarele tale instalate.

## Diferențele dintre Dicționar și Informații cuvânt

Ambele instrumente se deschid din meniul versetului, dar fac lucruri diferite:

- **Dicționar** (📖) citește cuvântul englez pe care îl atingi și îl găsește în dicționarele tale englezești instalate. Este instrumentul potrivit pentru definiții simple ale cuvintelor teologice biblice precum „covenant", „atonement" sau „Pharisee".
- **Informații cuvânt** (?) citește cuvântul grecesc sau ebraic original din spatele versetului și îl găsește în lexicoanele tale instalate. Este instrumentul potrivit pentru studii serioase de cuvinte, pentru a găsi fiecare loc unde este folosit un cuvânt grecesc și pentru a citi definițiile în limbile originale.

În caz de îndoială, începe cu dicționarul. Dacă vrei să aprofundezi limba originală, treci la Informații cuvânt. Vezi ghidul [Comentarii și lexicoane](theodia://help/commentaries-and-lexicons) pentru prezentarea completă a instrumentului Informații cuvânt.

## Ghiduri înrudite

- Ghidul [Mod de studiu](theodia://help/study-mode) explică meniul versetului în detaliu și unde se află instrumentul Dicționar (📖) lângă Marcaj, Evidențiază, Citește, Compară, Referințe încrucișate, Comentariu IA, Informații cuvânt și Note.
- Ghidul [Comentarii și lexicoane](theodia://help/commentaries-and-lexicons) acoperă Informații cuvânt și lexicoanele în limbile originale.
- Ghidul [Ce sunt resursele?](theodia://help/what-are-resources) explică diferitele tipuri de fișiere pe care le folosește Theodia, inclusiv resursele de dicționar.
- Ghidul [Probleme comune](theodia://help/common-problems) conține soluții pentru rezultate goale și alte probleme ale dicționarului.
