---
title: Enciclopedia
level: everyday
categories: study
summary: Cum cauți articole de enciclopedie și cum răsfoiești lucrări de referință.
---

# Enciclopedia

Theodia include o **Enciclopedie** încorporată pentru a căuta articole legate de Biblie, persoane, locuri și subiecte. Aplicația vine cu _Kitto's Illustrated Commentary_ (KIT) încorporat, iar enciclopedii suplimentare pot fi descărcate din depozit.

## Ce este o enciclopedie în Theodia?

O enciclopedie este o lucrare de referință formată din articole scurte. Fiecare articol acoperă o persoană, un loc, un eveniment sau un subiect biblic. Spre deosebire de un comentariu, care explică un verset anume, un articol de enciclopedie explică subiectul în sine.

## Cum deschizi Enciclopedia

1. Atinge **Enciclopedii** în bara de jos.
2. Alege o enciclopedie din rândul de abrevieri de sus.
3. Tastează un subiect, o persoană sau un loc în caseta de căutare.

Căutarea necesită cel puțin **3 caractere** înainte să apară rezultate și sugestii de completare automată.

## Citești un articol

- Pe **telefon**, atinge orice rezultat pentru a deschide articolul pe un ecran nou.
- Pe **tabletă**, articolul se deschide în panoul din dreapta, în timp ce lista rămâne în stânga.

## Selectarea enciclopediilor

Atinge un jeton de abreviere (cum ar fi **KIT**) pentru a comuta la acea enciclopedie. Pentru a căuta în mai multe enciclopedii simultan, folosește fila **Caută** și selectează **Enciclopedie** ca mod de căutare.

## Obținerea de enciclopedii suplimentare

1. Deschide **Setări**.
2. Atinge **Gestionează resursele**.
3. Atinge **Descarcă de pe GitHub**.
4. Selectează fila **Enciclopedii**.
5. Atinge butonul de descărcare lângă enciclopedia dorită.

Enciclopediile sunt descărcate din depozitul GitHub al Theodia și instalate automat. Enciclopediile instalate apar în ecranul Enciclopedie și în Căutare.

Poți instala o enciclopedie și dintr-un fișier local: în **Gestionează resursele**, atinge **Importă din fișier** și alege un fișier `.encyclopedia`. Fișierul este copiat în folderul de enciclopedii al aplicației și adăugat la indexul comun de căutare.

## Apasă lung pentru titlul complet

Pe ecranul Căutare, jetoanele de enciclopedie arată abrevieri scurte. Apasă lung pe un jeton pentru a vedea numele complet al enciclopediei.

## Când să folosești Enciclopedia

- Caută o persoană, un loc sau un subiect înainte sau în timp ce citești un pasaj.
- Obține informații de fond despre un cuvânt sau concept biblic care se întinde pe multe versete.
- Citește alături de un comentariu pentru studiu aprofundat.
