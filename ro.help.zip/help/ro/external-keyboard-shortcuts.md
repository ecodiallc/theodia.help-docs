---
title: Scurtături de tastatură externă
level: everyday
categories: [tablet, settings]
summary: Referința completă a scurtăturilor de tastatură pentru iPad cu o tastatură externă atașată.
---

# ⌨️ Scurtături de tastatură externă

Dacă folosești Theodia pe iPad cu o tastatură externă (Magic Keyboard, tastatură Bluetooth sau tastatură USB), poți naviga în aplicație fără a atinge ecranul.

> **Mod:** Unele scurtături funcționează doar când funcția corespunzătoare este disponibilă în modul tău de utilizator curent. De exemplu, `Cmd + Option + 6` (Marcaje) și `Cmd + Option + 7` (Repere) nu fac nimic în modul Cititor. Schimbă modurile în **Setări** → **Mod utilizator aplicație**.

Scurtăturile funcționează pe **iPad**.

## Scurtături globale (oriunde)

| Scurtătură          | Acțiune                                      |
| ------------------- | ------------------------------------------- |
| `Cmd + /`           | Afișează acest ajutor pentru scurtături     |
| `Cmd + .`           | Închide modal/panou (alternativă Escape)    |
| `Cmd + Option + 1`  | Mergi la fila Acasă                         |
| `Cmd + Option + 2`  | Mergi la fila Biblia                        |
| `Cmd + Option + 3`  | Mergi la fila Cărți                         |
| `Cmd + Option + 4`  | Mergi la fila Devotionale                   |
| `Cmd + Option + 5`  | Mergi la fila Caută                         |
| `Cmd + Option + 6`  | Mergi la fila Marcaje (Standard și Savant)  |
| `Cmd + Option + 7`  | Mergi la fila Repere (Standard și Savant) |
| `Cmd + Option + 8`  | Mergi la fila Note biblice (Standard și Savant) |
| `Cmd + Option + 9`  | Mergi la fila IA (doar Savant, dacă este activat) |
| `Cmd + Option + 0`  | Mergi la fila Ajutor                         |
| `Cmd + Option + I`  | Mergi la fila Despre                        |
| `Cmd + [`           | Înapoi                                      |
| `Cmd + F`           | Deschide Caută                              |
| `Cmd + K`           | Deschide Meniul rapid (Savant)         |
| `Cmd + ,`           | Deschide Setări                             |
| `Cmd + Shift + M`   | Deschide meniul principal                   |
| `Cmd + Shift + T`   | Comută tema (implicită / întunecată)       |
| `Cmd + Shift + U`   | Deschide selectorul de mod utilizator       |
| `Escape`            | Respinge modal / închide panou              |

## Scurtături în Cititorul biblic

Acestea funcționează atât în **Cititorul de studiu**, cât și în **Cititorul focus**.

| Scurtătură          | Acțiune                                                       |
| ------------------- | ------------------------------------------------------------- |
| `← Săgeată stânga`  | Capitolul anterior                                            |
| `→ Săgeată dreapta` | Capitolul următor                                             |
| `Cmd + R`           | Comută între Cititorul de studiu și Cititorul focus (Standard și Savant) |
| `Cmd + Option + V`  | Deschide selectorul de versiune                               |
| `Cmd + Option + B`  | Deschide selectorul de carte                                  |
| `Cmd + Option + C`  | Deschide selectorul de capitol                                |
| `Cmd + T`           | Comută TTS (oprește când rulează/este pus pe pauză, pornește când este inactiv) |
| `Cmd + Option + T`  | Redare / Pauză TTS                                            |

## Doar Cititorul de studiu

| Scurtătură          | Acțiune                                                                 |
| ------------------- | ----------------------------------------------------------------------- |
| `↑ Săgeată sus`     | Selectează versetul anterior                                            |
| `↓ Săgeată jos`     | Selectează versetul următor                                             |
| `Cmd + ↑`           | Selectează primul verset                                               |
| `Cmd + ↓`           | Selectează ultimul verset                                               |
| `Cmd + ←`           | Sari la capitolul 1                                                     |
| `Cmd + →`           | Sari la ultimul capitol                                                 |
| `Cmd + 0`–`9`       | Sari direct la verset (tastează cifre, ex. `Cmd + 1` `Cmd + 6` pentru versetul 16) |
| `Cmd + P`           | Comută Biblia paralelă (Standard și Savant)                           |
| `Cmd + B`           | Salvează versetul selectat ca marcaj (Standard și Savant)                 |
| `Cmd + H`           | Evidențiază versetul selectat (Standard și Savant)                      |
| `Cmd + N`           | Adaugă notă pentru versetul selectat (Standard și Savant)               |
| `Cmd + C`           | Compară traducerile versetului selectat (Standard și Savant)            |
| `Cmd + X`           | Deschide referințele încrucișate pentru versetul selectat (Standard și Savant) |
| `Cmd + I`           | Deschide informații cuvânt (Savant)                                      |
| `Cmd + D`           | Deschide dicționarul pentru versetul selectat (Savant)                 |
| `Cmd + A`           | Deschide panoul IA pentru versetul selectat (Savant)                   |
| `Cmd + Option + S`  | Comută subtitlurile                                                     |
| `Cmd + Option + W`  | Închide toate panourile de studiu deschise                              |
| `Cmd + Option + M`  | Deschide meniul de acțiuni al versetului                                |

## Doar Cititorul focus

| Scurtătură        | Acțiune           |
| ----------------- | ----------------- |
| `↑ Săgeată sus`   | Derulează în sus  |
| `↓ Săgeată jos`   | Derulează în jos  |
| `Cmd + ↑`         | Sari la început   |
| `Cmd + ↓`         | Sari la sfârșit   |
| `Cmd + =`         | Mărește           |
| `Cmd + -`         | Micșorează        |

## Caută

| Scurtătură          | Acțiune                           |
| ------------------- | --------------------------------- |
| `Return`            | Execută căutarea                  |
| `Cmd + Return`      | Șterge căutarea și focalizează inputul |
| `Cmd + ↑`           | Derulează rezultatele în sus      |
| `Cmd + ↓`           | Derulează rezultatele în jos      |
| `Cmd + Option + A`  | Selectează toate elementele din domeniu |
| `Cmd + Option + C`  | Deselectează toate elementele din domeniu |
| `Cmd + Option + B`  | Mod de căutare Biblie             |
| `Cmd + Option + O`  | Mod de căutare Cărți              |
| `Cmd + Option + D`  | Mod de căutare Dicționar (Savant) |
| `Cmd + Option + X`  | Mod de căutare Lexicon (Savant)   |

## Rezultatele căutării

| Scurtătură  | Acțiune              |
| ----------- | -------------------- |
| `Cmd + S`   | Deschide foaia de salvare totală |
| `Cmd + ↑`   | Derulează rezultatele în sus |
| `Cmd + ↓`   | Derulează rezultatele în jos |

## Cititor de cărți

| Scurtătură          | Acțiune                   |
| ------------------- | ------------------------- |
| `← Săgeată stânga`  | Capitolul anterior        |
| `→ Săgeată dreapta` | Capitolul următor         |
| `Cmd + ↑`           | Capitolul anterior        |
| `Cmd + ↓`           | Capitolul următor         |
| `↑ Săgeată sus`     | Derulează în sus          |
| `↓ Săgeată jos`     | Derulează în jos          |
| `Cmd + B`           | Salvează capitolul curent |
| `Cmd + J`           | Deschide selectorul de capitol |
| `Cmd + L`           | Deschide selectorul de voce |
| `Cmd + T`           | Comută TTS                |
| `Cmd + Option + T`  | Redare / Pauză TTS        |

## Cititor devoțional

| Scurtătură          | Acțiune              |
| ------------------- | -------------------- |
| `← Săgeată stânga`  | Ziua anterioară      |
| `→ Săgeată dreapta` | Ziua următoare       |
| `↑ Săgeată sus`     | Derulează în sus     |
| `↓ Săgeată jos`     | Derulează în jos     |
| `Cmd + ↑`           | Derulează în sus (mare) |
| `Cmd + ↓`           | Derulează în jos (mare) |
| `Cmd + D`           | Deschide selectorul de dată |
| `Cmd + T`           | Comută TTS           |
| `Cmd + Option + T`  | Redare / Pauză TTS   |

## Chat IA

| Scurtătură          | Acțiune                     |
| ------------------- | --------------------------- |
| `Cmd + Return`      | Trimite mesajul             |
| `Cmd + N`           | Chat nou                    |
| `Cmd + D`           | Comută sertarul de conversație |
| `Cmd + Option + C`  | Șterge chatul curent        |
| `Cmd + S`           | Deschide meniul de salvare  |
| `Escape`            | Închide sertarul / meniul   |

## Marcaje

| Scurtătură                  | Acțiune                             |
| --------------------------- | ----------------------------------- |
| `↑ Săgeată sus` / `↓ Săgeată jos` | Selectează marcajul                 |
| `Return`                    | Deschide marcajul (tabletă: selectează) |
| `Cmd + R`                   | Citește marcajul în context         |
| `Cmd + M`                   | Mută marcajul selectat în dosare    |
| `Cmd + N`                   | Gestionează dosarele                |
| `Escape`                    | Închide panoul de detalii / selectorul de dosar |

În selectorul **Mută în dosar**, `↑ Săgeată sus` / `↓ Săgeată jos` mișcă selecția, `Return` comută dosarul selectat sau activează acțiunea evidențiată, iar `Escape` închide selectorul. Rândul **+ Creează dosar** este în partea de sus a listei.

## Note biblice

| Scurtătură                  | Acțiune                |
| --------------------------- | ---------------------- |
| `↑ Săgeată sus` / `↓ Săgeată jos` | Selectează nota        |
| `Return`                    | Deschide nota          |
| `Cmd + Return`              | Focalizează inputul de filtrare |
| `Escape`                    | Închide detaliul / editorul |

## Repere

| Scurtătură                  | Acțiune                |
| --------------------------- | ---------------------- |
| `↑ Săgeată sus` / `↓ Săgeată jos` | Selectează evidențierea |
| `Return`                    | Deschide evidențierea  |
| `Cmd + Return`              | Focalizează inputul de filtrare |
| `Escape`                    | Închide panoul de detalii |

## Lista de Biblii

| Scurtătură                                | Acțiune                            |
| ----------------------------------------- | ---------------------------------- |
| `Tab` / `→ Săgeată dreapta` / `↓ Săgeată jos` | Biblia următoare                   |
| `← Săgeată stânga` / `↑ Săgeată sus`            | Biblia anterioară                  |
| `Return`                                  | Deschide Biblia focalizată         |
| `Cmd + Shift + S`                         | Comută favorite pentru Biblia focalizată |
| `Escape`                                  | Înapoi                             |

## Ecranul de cărți biblice

| Scurtătură              | Acțiune                     |
| ----------------------- | --------------------------- |
| `Tab` / `→ Săgeată dreapta` | Cartea următoare            |
| `← Săgeată stânga`          | Cartea anterioară           |
| `↓ Săgeată jos`             | Cartea de dedesubt în grilă |
| `↑ Săgeată sus`             | Cartea de deasupra în grilă |
| `Cmd + ↓`                 | Secțiunea următoare (VT / NT) |
| `Cmd + ↑`                 | Secțiunea anterioară (VT / NT) |
| `Return`                  | Deschide cartea focalizată  |
| `Escape`                  | Înapoi                      |

## Lista de cărți

| Scurtătură                                | Acțiune            |
| ----------------------------------------- | ------------------ |
| `Tab` / `→ Săgeată dreapta` / `↓ Săgeată jos` | Cartea următoare   |
| `← Săgeată stânga` / `↑ Săgeată sus`            | Cartea anterioară  |
| `Return`                                  | Deschide cartea focalizată |
| `Escape`                                  | Înapoi             |

## Ecranul de capitole biblice

| Scurtătură                                | Acțiune              |
| ----------------------------------------- | -------------------- |
| `Tab` / `→ Săgeată dreapta` / `↓ Săgeată jos` | Capitolul următor    |
| `← Săgeată stânga` / `↑ Săgeată sus`            | Capitolul anterior   |
| `Return`                                  | Deschide capitolul focalizat |
| `Escape`                                  | Înapoi               |

## Ecranul de capitole de cărți

| Scurtătură             | Acțiune                    |
| ---------------------- | -------------------------- |
| `Tab` / `↓ Săgeată jos` | Capitolul următor          |
| `↑ Săgeată sus`        | Capitolul anterior         |
| `Return`               | Deschide capitolul focalizat |
| `Cmd + Return`         | Focalizează inputul de căutare/filtrare |
| `Escape`               | Înapoi                     |

## Lista de devoționale

| Scurtătură                                | Acțiune                  |
| ----------------------------------------- | ------------------------ |
| `Tab` / `→ Săgeată dreapta` / `↓ Săgeată jos` | Devoționalul următor     |
| `← Săgeată stânga` / `↑ Săgeată sus`            | Devoționalul anterior  |
| `Return`                                  | Deschide devoționalul focalizat |
| `Escape`                                  | Înapoi                   |

## Meniul principal (când este deschis)

| Scurtătură      | Acțiune                  |
| --------------- | ------------------------ |
| `↑ Săgeată sus`   | Elementul anterior de meniu |
| `↓ Săgeată jos`   | Elementul următor de meniu |
| `Return`          | Selectează elementul evidențiat |
| `Escape`          | Închide meniul           |

## Setări

| Scurtătură | Acțiune                    |
| ---------- | -------------------------- |
| `Escape`   | Închide modalul / selectorul deschis |

## Modale de editare

| Scurtătură  | Acțiune         |
| ----------- | --------------- |
| `Cmd + S`   | Salvează        |
| `Escape`    | Anulează / închide |

## Gard de tastare

Când ești focalizat într-un câmp de text (casetă de căutare, editor de note, input IA), scurtăturile non-Cmd precum săgețile și `Space` sunt suprimate, ca să nu declanșeze accidental navigarea. Scurtăturile care folosesc tasta `Cmd` (de ex., `Cmd + S`, `Cmd + B`) funcționează în continuare în timpul tastării.
