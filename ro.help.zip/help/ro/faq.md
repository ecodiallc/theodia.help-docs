---
title: Întrebări frecvente
level: everyday
categories: faq
summary: Răspunsuri la cele mai comune întrebări despre folosirea Theodia.
---

# Întrebări frecvente

## Theodia costă ceva?

Theodia este o achiziție unică. Nu există abonament, publicitate, achiziții în aplicație sau cereri de donații. Toate resursele suplimentare disponibile în catalog sunt gratuite pentru descărcare după ce cumperi aplicația.

## Am nevoie de conexiune la internet?

Nu. Odată ce aplicația și fișierele ei de date sunt instalate, totul funcționează offline. Poți citi, căuta, evidenția, lua notițe și folosi majoritatea instrumentelor de studiu fără semnal.

Singura funcție care are nevoie de internet este descărcarea de resurse noi.

## Unde sunt stocate datele mele?

Toate marcajele, evidențierile, notițele și setările tale sunt salvate pe dispozitiv. Nu sunt încărcate pe niciun server.

Le poți face backup manual. Vezi ghidul [Salvarea datelor tale](theodia://help/backups) pentru detalii.

## Pot asculta Biblia cu voce tare?

Da. Deschide orice capitol, atinge meniul și alege opțiunea de citire cu voce tare. Dispozitivul tău trebuie să aibă instalată o voce text-to-speech. Vezi ghidul [Citirea cu voce tare](theodia://help/tts) pentru mai multe.

## Cum caut un verset?

Poți tasta o referință precum `Ioan 3:16` în Comanda rapidă de pe ecranul principal, sau folosești fila **Caută** pentru a căuta după cuvânt sau expresie.

## Cum raportez un bug sau sugerez o funcție?

Atinge **Trimite sugestie / problemă** pe ecranul Despre, [raportează pe GitHub](https://github.com/ecodiallc/theodia.app/issues/new), sau vizitează pagina [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions).

## Ce dispozitive sunt suportate?

Theodia rulează pe iPhone, iPad și telefoane și tablete Android. Funcționează cel mai bine pe dispozitive cu cel puțin 2 GB de spațiu liber pentru fișierele de bază.

## Pot folosi o tastatură externă?

Da. Theodia suportă tastaturi Bluetooth și USB pe iPad. Navigarea, căutarea și multe funcții de citire au scurtături de tastatură. Vezi ghidul [Scurtături de tastatură externă](theodia://help/external-keyboard-shortcuts) pentru lista completă.

## Ce limbi sunt suportate?

Interfața aplicației este disponibilă în engleză, arabă, chineză (simplificată și tradițională), cehă, daneză, olandeză, filipineză, franceză, germană, greacă, ebraică, hindi, indoneziană, italiană, japoneză, coreeană, poloneză, portugheză (Brazilia), română, rusă, spaniolă, suedeză, thailandeză, turcă, ucraineană și vietnameză.

Limba textului biblic depinde de traducerile pe care le-ai instalat.

## Cum schimb limba?

Mergi la **Setări** și caută opțiunea de limbă.

## Întrebarea mea nu este aici. Unde pot găsi mai mult ajutor?

Răsfoiește restul ghidurilor de ajutor după subiect, sau pune o întrebare în comunitatea [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions).

Sfat: Pe ecranul principal **Ajutor și ghiduri**, folosește caseta de căutare pentru a tasta un subiect precum `notificări` sau `caută` și a găsi ghidul potrivit.
