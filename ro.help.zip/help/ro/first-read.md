---
title: Citești primul capitol
level: beginner
categories: [start, read]
summary: Un ghid pas cu pas pentru a deschide și a citi un capitol.
---

# Citești primul capitol

Acest ghid te însoțește să deschizi un capitol pentru prima oară.

## Pasul 1: Deschide fila Biblia

Uită-te în partea de jos a ecranului. Vei vedea un rând de file. Atinge fila care scrie **Biblia**.

## Pasul 2: Alege o carte

Vei vedea o listă cu cărțile Bibliei. Geneza este prima. Ioan este aproximativ la mijloc. Apocalipsa este ultima.

Atinge numele cărții pe care o dorești.

## Pasul 3: Alege un capitol

Vei vedea numerele de la 1 până la câte capitole are cartea. Atinge capitolul dorit.

Capitolul se deschide. Versetele apar pe ecran.

## Pasul 4: Deplasează-te

- Glisează la **stânga** pentru a merge la capitolul următor.
- Glisează la **dreapta** pentru a te întoarce.

## Pasul 5: Interacționează cu un verset

Ce poți face cu un verset depinde de modul tău de utilizare.

### Modul Cititor

Modul Cititor este curat și fără distrageri.

- Atinge un verset pentru a-l evidenția scurt.
- Nu există instrumente de studiu, marcaje sau meniuri.
- Dacă vrei mai multe funcții, treci la modul **Standard** sau **Savant** în **Setări**.

### Modul Standard

Modul Standard adaugă funcții de zi cu zi pentru studiul personal al Bibliei.

Atinge un verset pentru a deschide un meniu cu aceste opțiuni:

- **Salvează** versetul ca marcaj.
- **Evidențiază** cu o culoare.
- **Adaugă o notă** biblică.
- **Copiază** textul versetului.
- **Compară** versetul în altă traducere.
- **Vezi referințele încrucișate** pentru verset.

### Modul Savant

Modul Savant deblochează toate instrumentele pentru studiu biblic aprofundat.

Atinge un verset pentru a deschide un meniu cu tot ce este în modul Standard, plus:

- **Comentariu** pe verset.
- **Informații cuvânt** și căutări în limbile originale.
- Definiții de **dicționar**.
- **Asistent IA** pentru studiu aprofundat.

Poți schimba modul oricând în **Setări**.

## Ai nevoie de ajutor pentru un anumit instrument?

Fiecare instrument are propriul ghid. Atinge **Ajutor** de pe pagina principală pentru a le vedea pe toate. Ghidul [Mod de studiu](theodia://help/study-mode) este un bun punct de plecare — prezintă fiecare instrument din meniul versetului.

Dacă încă înveți unde se află lucrurile, vezi ghidul [Aspectul aplicației și navigarea](theodia://help/navigating-the-app). Acesta explică ecranul principal, meniul principal și bara de jos.

## Vrei mai multe resurse?

Aplicația vine cu mai multe versiuni ale Bibliei disponibile gratuit. Dacă vrei să adaugi mai multe Biblii, comentarii, cărți sau devoționale, vezi ghidul [Obținerea de resurse suplimentare de pe GitHub](theodia://help/getting-core-files). Acesta arată unde le găsești și cum le adaugi.
