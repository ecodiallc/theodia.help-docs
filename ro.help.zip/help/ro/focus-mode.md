---
title: Mod focus
level: beginner
categories: [layout, read]
summary: O metodă curată și fără distrageri de a citi pasaje lungi.
---

# Mod focus

> **Mod:** Modul focus este cititorul în modul **Cititor**. Este disponibil și în modurile **Standard** și **Savant** ca alternativă la Modul de studiu. Poți schimba modurile în **Setări** → **Mod utilizator aplicație**.

Modul focus este o metodă de a citi un capitol biblic fără butoane sau meniuri în cale. Este bun pentru sesiuni lungi de citire.

## Cum îl activezi

1. Deschide orice capitol.
2. În rândul de pictograme din partea de sus a ecranului, atinge butonul 📖. Acesta deschide același capitol în Mod focus.
3. Meniurile și butoanele se ascund. Rămâne doar textul biblic.

În modul **Cititor**, capitolele se deschid automat în Mod focus. Butonul 📖 este ascuns, deoarece nu există Mod de studiu la care să comuți.

## Ce poți face în Mod focus

- **Derulează** pentru a citi.
- **Glisează** pentru a merge la capitolul următor sau anterior.
- **Atinge butonul 📖** din bara de jos pentru a reveni la Modul de studiu. (Ascuns în modul Cititor.)
- **Atinge butonul 🔊** din bara de jos pentru a citi capitolul cu voce tare. O mini-bară de control apare cu redare, pauză, derulare înapoi, derulare înainte și selector de voce. (Ascuns în modul Cititor — TTS necesită Standard sau Savant.)

## O utilizare bună pentru Mod focus

- Citirea unei cărți întregi, capitol cu capitol.
- Citirea unui pasaj lung pentru devoțional sau timp de liniște.
- Citirea cu voce tare și urmărirea textului fără distrageri.

## Trecerea în Modul de studiu

Modul focus ascunde toate instrumentele de studiu, dar ele sunt la un atingere distanță. Atinge butonul 📖 din partea de sus a ecranului pentru a deschide același capitol în [Modul de studiu](theodia://help/study-mode). Modul de studiu este cititorul complet, cu comentarii, referințe încrucișate, căutări în lexicon și note. Pentru a afla ce poate face Modul de studiu, vezi ghidul [Mod de studiu](theodia://help/study-mode).

În modul Cititor, butonul 📖 este ascuns, deoarece Modul de studiu nu este disponibil.
