---
title: Navigare rapidă
level: beginner
categories: layout
summary: Toate metodele rapide pentru a sări la un verset, capitol sau ecran în Theodia.
---

# Navigare rapidă

Acest ghid este un rezumat pentru navigare. Acoperă fiecare metodă rapidă de a te mișca de unde ești până unde vrei să ajungi.

## Sari direct la un verset

Cea mai rapidă cale de a deschide orice verset este **Comanda rapidă** de pe ecranul principal.

- Tastează `Ioan 3:16` și apasă pe Mergi.
- Tastează `Psalmii 23` și apasă pe Mergi.
- Tastează `Geneza 1` și apasă pe Mergi.

Aplicația deschide capitolul exact (și derulează la verset, dacă ai inclus unul).

## Glisează între capitole

Când citești un capitol:

- **Glisează la stânga** → capitolul următor.
- **Glisează la dreapta** → capitolul anterior.

Aceasta funcționează și între cărți. După Exod 40, glisarea la stânga te duce la Levitic 1.

## Folosește bara de sus

În timpul citirii, partea de sus a ecranului arată **traducerea**, **cartea** și **capitolul** curente.

- Atinge numele traducerii pentru a schimba Biblia.
- Atinge numele cărții pentru a alege o altă carte.
- Atinge numărul capitolului pentru a alege un alt capitol.

## Sari dintr-un marcaj

Dacă ai salvat un verset:

1. Deschide fila **Marcaje**.
2. Atinge orice intrare.
3. Te duci direct la acel verset.

## Sari din căutare

1. Deschide fila **Caută**.
2. Tastează un cuvânt sau o expresie.
3. Atinge orice rezultat.
4. Aplicația deschide capitolul cu cuvintele tale de căutare evidențiate în galben.

## Schimbă modurile de citire

Cititorul biblic are două moduri:

- **Mod de studiu** — arată capitolul cu toate instrumentele de studiu la un atingere distanță.
- **Mod focus** — ascunde toate instrumentele și meniurile, lăsând doar textul.

Pentru a comuta: atinge butonul **📖** din partea de sus a ecranului în timpul citirii. Atinge-l din nou pentru a reveni. (Modul Cititor rămâne întotdeauna în Mod focus.)

## Folosește filele de jos

Rândul de pictograme din partea de jos a ecranului este mereu vizibil. Atinge orice filă pentru a trece la acea secțiune. Filele exacte depind de modul tău de utilizare:

**Toate modurile:**

- **Acasă** — înapoi la ecranul principal.
- **Biblia** — lista de traduceri.
- **Caută** — căutare în Biblie, cărți, dicționare, lexicoane și PDF-uri.
- **Setări** — preferințe și resurse.

**Standard și Savant văd și:**

- **Marcaje** — versete salvate.
- **Repere** — versete marcate cu culoare.
- **Note biblice** — notițele tale private.
- **PDF-uri** — documentele tale PDF importate.

**Savant vede și:**

- **IA** — asistentul IA (dacă este activat în Setări).

### Reținerea locului unde ai rămas

Fiecare filă își păstrează propriul istoric de navigare. Când te întorci la o filă, revii **unde ai rămas**, nu la ecranul de început al secțiunii.

- Deschizi fila **Biblia**, alegi o traducere, deschizi un capitol, apoi treci la **Caută**. Mai târziu atingi **Biblia** și ești din nou la acel capitol.
- Deschizi fila **Marcaje**, atingi un verset marcat, apoi treci la **Setări**. Atingând **Marcaje** din nou te întorci la lista de marcaje.

Acest lucru se aplică fiecărei file. Fiecare își amintește locul până când navighezi explicit la un alt ecran în acea filă.

### Ce resetează o filă

O filă revine la ecranul ei de bază doar când:

- Ești deja pe acea filă și atingi din nou aceeași pictogramă. Este o metodă rapidă de resetare.
- Aplicația este închisă forțat și redeschisă.

### Filele de jos față de meniul principal

- **Filele de jos** — fiecare filă își amintește propria stivă. Atingerea unei file te întoarce unde ai rămas.
- **Meniul principal** — atingerea unui element navighează la acel ecran. Este o listă derulantă, nu o suprapunere.

Exemplu:

- Citești Ioan 3. Atingi fila **Marcaje**, apoi iar **Biblia**. Revii la Ioan 3.
- Citești Ioan 3. Deschizi meniul și atingi **Note biblice**. Îți revezi notițele, apoi atingi fila **Biblia** pentru a reveni la Ioan 3.

## Sfaturi

- Ecranul principal își amintește care secțiuni sunt extinse sau restrânse.
- Dacă îți lipsește o filă, verifică **modul de utilizare** în **Setări** → **Mod utilizator aplicație**. Modul Cititor ascunde marcajele, evidențierile, notele și IA. Modul Standard ascunde IA. Este posibil să fie nevoie să activezi o funcție în **Setări** sau să instalezi o resursă.
