---
title: Obținerea de resurse suplimentare
level: everyday
categories: resources
summary: Cum adaugi Biblii, comentarii, cărți și alte resurse în Theodia.
---

# Obținerea de resurse suplimentare

Theodia vine cu câteva resurse încorporate, dar poți adăuga mai multe. Cea mai ușoară cale este prin ecranul **Gestionează resursele** din interiorul aplicației.

## Ce poți adăuga

- **Biblii** — mai multe traduceri în diferite limbi
- **Comentarii** — note de studiu care explică versetele
- **Cărți** — clasice creștine și lucrări de referință
- **Devoționale** — citiri devoționale zilnice
- **Fișiere de bază** — fișiere mari de date precum morfologia, referințele încrucișate și Biblia Interlineară Marvel (MIB)

## Cum adaugi resurse din interiorul aplicației

1. Deschide **Setări**.
2. Atinge **Gestionează resursele**.
3. Alege o filă: **Bază**, **Biblii**, **Comentarii**, **Cărți** sau **Devoționale**.
4. Răsfoiește lista. Atinge o resursă pentru a citi mai multe despre ea.
5. Atinge căsuța de selectare pentru a alege ce vrei.
6. Atinge **Descarcă** în partea de jos. Fișierele se descarcă și se instalează automat.

Odată instalată, resursa apare în aplicație imediat. Nu trebuie să repornești.

## Fișiere de bază

Fila **Bază** conține fișiere mari de date care alimentează funcțiile de studiu aprofundat. Acestea includ:

- Date de morfologie (formele cuvintelor în limbile originale)
- Baze de date de referințe încrucișate
- Biblia Interlineară Marvel (MIB)

Trebuie să descarci fișierele de bază doar o dată. Rămân pe dispozitiv și funcționează offline.

## Biblii globale

Fila **Biblii globale** conține traduceri biblice dintr-o colecție mai largă. Dacă nu vezi o traducere pe care o dorești în fila principală **Biblii**, verifică aici.

## Gestionarea resurselor instalate

Pe ecranul principal **Gestionează resursele** (nu fila de descărcare), poți:

- **Activa sau dezactiva** o resursă fără a o șterge. Resursele dezactivate rămân pe dispozitiv, dar sunt ascunse din meniuri.
- **Șterge** o resursă pentru a elibera spațiu. O poți descărca din nou mai târziu.

## Adăugarea propriilor fișiere

Dacă ai un fișier de resurse de altundeva — de la un prieten, un alt proiect sau un site web — îl poți importa direct:

1. În **Gestionează resursele**, atinge **Importă fișier local**.
2. Alege fișierul de pe dispozitiv.
3. Aplicația citește fișierul și îl adaugă în biblioteca ta.

Aplicația acceptă aceste tipuri de fișiere:

- `.bible` — traduceri biblice
- `.commentary` — comentarii
- `.lexicon` — lexicoane
- `.book` — cărți
- `.devotional` — devoționale

## Conectarea unui depozit GitHub personalizat

Dacă cineva întreține un depozit GitHub cu resurse compatibile Theodia, îl poți adăuga ca sursă personalizată:

1. Mergi la **Setări → Depozite GitHub**.
2. Atinge **Adaugă depozit**.
3. Introdu URL-ul GitHub (de exemplu, `https://github.com/username/repo-name`).
4. Alege ce tipuri de resurse conține depozitul (Biblii, comentarii sau cărți).
5. Salvează-l.
6. Întoarce-te la **Gestionează resursele**. Va apărea o filă nouă cu resursele din acel depozit.

Dacă depozitul este privat, va trebui să adaugi un **Token de acces personal** în **Setări → Depozite GitHub**, ca aplicația să îl poată citi.

## O notă despre dimensiunile fișierelor

Fișierele de resurse pot fi mari. Bibliile sunt de obicei mici (câțiva megabyte). Comentariile și fișierele de bază pot fi mult mai mari (sute de megabyte). Descarcă prin Wi-Fi când este posibil.

## Rezumat

- Folosește **Setări → Gestionează resursele** pentru a răsfoi și instala resurse.
- Fișierele de bază deblochează instrumente de studiu aprofundat precum morfologia și referințele încrucișate.
- Importă fișiere locale dacă ai propriile tale resurse.
- Adaugă depozite GitHub personalizate dacă vrei resurse din altă sursă.
