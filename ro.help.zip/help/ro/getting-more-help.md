---
title: Unde să pui întrebări
level: everyday
categories: trouble
summary: Cum obții ajutor de la echipa și comunitatea Theodia, și cum găsești subiecte de ajutor în interiorul aplicației.
---

# Unde să pui întrebări

Dacă ești blocat, există câteva locuri unde poți cere ajutor.

## Găsirea unui subiect de ajutor

Dacă cauți informații despre o anumită funcție, încearcă una dintre aceste căi:

- **Răsfoiește pe categorii.** Deschide **Ajutor și ghiduri** și atinge o categorie precum **Setări și personalizare** sau **Depanare**. Fiecare card listează ghiduri înrudite.
- **Caută după cuvânt-cheie.** Pe ecranul principal **Ajutor și ghiduri**, tastează un cuvânt în caseta de căutare de sus. De exemplu, tastând `notificări` apare ghidul [Notificări și memento-uri](theodia://help/notifications); tastând `caută` apare ghidul [Căutarea în Biblie](theodia://help/search-the-bible).
- **Verifică mai întâi Setări.** Multe funcții sunt configurate în **Setări**. Dacă vrei să setezi memento-uri, deschide **Setări** → **Notificări**. Ecranul de setări are și un link **Ajutor** pentru fiecare secțiune.

## În interiorul aplicației

Deschide ecranul **Despre**. Vei vedea două butoane:

- **Trimite sugestie / problemă** — deschide un formular pentru a trimite echipei o întrebare, o idee sau un raport de bug.
- **Discuții / feedback** — deschide tabla de discuții a comunității.

## Pagina de GitHub

Poți vedea lista de probleme cunoscute și modificări recente pe [GitHub](https://github.com/ecodiallc/theodia.app).

## Discuții în comunitate

Alți oameni care folosesc Theodia pun întrebări și împărtășesc sfaturi în [tabla de discuții a comunității](https://github.com/ecodiallc/theodia.app/discussions). Poți citi discuțiile vechi și poți începe una nouă.

## Înainte de a întreba

Câteva lucruri ne ajută să îți răspundem mai repede:

- **Ce dispozitiv ai?** (de ex. iPhone 13, Pixel 7)
- **Ce versiune a aplicației?** (Deschide **Despre** pentru a vedea.)
- **Ce ai făcut?** O scurtă descriere a pașilor.
- **Ce s-a întâmplat?** Ce ai văzut pe ecran.
- **La ce te așteptai să se întâmple?** Aceasta este adesea partea cea mai utilă.

## La ce să te aștepți

- Pentru rapoarte de bug, echipa răspunde de obicei în câteva zile.
- Pentru idei, echipa le citește pe toate. Nu putem promite când va fi adăugată o idee.
- Pentru întrebări din comunitate, alți utilizatori răspund adesea mai repede decât echipa.

## O notă despre confidențialitate

Când trimiți o întrebare, te rugăm să nu incluzi informații private. Echipa poate vedea ceea ce trimiți.
