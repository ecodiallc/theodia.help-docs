---
title: GitHub Models
level: advanced
categories: ai
summary: Configurează GitHub Models — o modalitate gratuită de a începe să explorezi IA în Theodia fără un abonament IA existent.
---

# GitHub Models

> **Mod:** Asistentul IA necesită modul **Savant**. Poți schimba modul în **Setări** → **Mod utilizator aplicație**.

Dacă nu plătești deja pentru un serviciu IA, **GitHub Models** este cea mai ușoară modalitate de a începe să explorezi IA din Theodia. Este gratuit la început, iar tot ce ai nevoie este un cont GitHub gratuit.

## Ce este GitHub Models?

GitHub Models este un serviciu de la GitHub care îți permite să rulezi modele IA moderne printr-un API. Suportă același format ca OpenAI, așa că funcționează perfect cu Theodia.

## De ce să alegi GitHub Models?

- **Nu este necesar card de credit** — Doar un cont GitHub.
- **Modele de înaltă calitate** — Ai acces la GPT-4o, GPT-4.1 și alte modele fiabile care suportă instrumentele Theodia.
- **Configurare ușoară** — Un token, un URL și gata.

## Pasul 1: Creează un cont GitHub

Dacă ai deja un cont GitHub, treci la Pasul 2.

1. Mergi la [github.com](https://github.com).
2. Atinge **Sign up** și urmează instrucțiunile pentru a crea un cont gratuit.
3. Verifică-ți adresa de email când GitHub trimite confirmarea.

## Pasul 2: Creează un token de acces personal

Acest token este cheia ta API. El îi spune GitHub cine ești când Theodia trimite întrebări.

1. Mergi la [github.com/settings/tokens](https://github.com/settings/tokens).
2. Atinge **Generate new token** și alege **Generate new token (classic)**.
3. Dă tokenului un nume precum **Theodia AI**.
4. Sub **Select scopes**, bifează **`models:read`**.
   - Aceasta este singura permisiune de care are nevoie Theodia.
5. Derulează în jos și atinge **Generate token**.
6. **Copiază tokenul imediat.** GitHub îl va arăta o singură dată. Lipește-l într-un loc sigur (precum aplicația de notițe a telefonului) până îl adaugi în Theodia.

## Pasul 3: Alege un model

GitHub Models oferă mai multe modele. Pentru Theodia, acestea sunt cele mai bune opțiuni:

| Model                 | Limită zilnică gratuită | Cel mai bun pentru                                       |
| --------------------- | ----------------------- | ---------------------------------------------------------|
| `openai/gpt-4.1-nano` | 150 cereri / zi         | Întrebări rapide și explicații simple de versete          |
| `openai/gpt-4.1-mini` | 150 cereri / zi         | Studiu general cu bun suport pentru instrumente          |
| `openai/gpt-4.1`      | 50 cereri / zi          | Studiu mai adânc și întrebări complexe în mai mulți pași |
| `openai/gpt-4o`       | 50 cereri / zi          | Versatil, suport excelent pentru instrumente              |

Începe cu **`openai/gpt-4.1-mini`** — este rapid, fiabil și oferă o limită zilnică mai mare de cereri.

## Pasul 4: Configurează Theodia

1. Deschide **Theodia**.
2. Mergi la **Setări** → **Asistent IA**.
3. Asigură-te că este selectat **Model la distanță**.
4. Atinge dropdown-ul **Furnizor** și alege **GitHub Models**.
   - Dacă GitHub Models nu este în listă, atinge **Personalizat** și introdu manual URL-ul de bază: `https://models.github.ai`
5. Lipește **Tokenul de acces personal GitHub** în câmpul **Cheie API**.
6. Introdu ID-ul modelului ales în câmpul **Model** (de exemplu: `openai/gpt-4.1-mini`).
7. Atinge **Verificare conexiune**.
8. Așteaptă finalizarea verificării. Ar trebui să vezi:
   - **✓ Conexiune reușită**
   - **✓ Instrumente suportate**

Dacă vezi **✗ Instrumente nesuportate**, încearcă un alt ID de model din tabelul de mai sus.

## Pasul 5: Începe conversația

1. Atinge fila **IA** din partea de jos a ecranului.
2. Tastează o întrebare și atinge **Trimite**.
3. Sau, cât timp citești orice capitol biblic, atinge un număr de verset și alege **Comentariu IA** pentru a începe un chat specific unui verset.

## Depanare

### „Conexiune eșuată" sau „HTTP 401"

- Asigură-te că ai copiat **întreg** tokenul. Este un șir lung care începe cu `ghp_`.
- Tokenurile expiră dacă nu sunt folosite mult timp. Întoarce-te pe GitHub și generează unul nou.
- Verifică că ai selectat **models:read** când ai creat tokenul.

### „Instrumente nesuportate"

- Unele modele pe GitHub Models nu acceptă apeluri de instrumente. Încearcă în schimb **`openai/gpt-4o`** sau **`openai/gpt-4.1-mini`**.
- Asigură-te că ID-ul modelului este scris exact ca în tabel, inclusiv prefixul `openai/`.

### Erori de limită de rată

- Dacă atingi limita zilnică, comută la un model cu o alocație mai mare (cum ar fi `openai/gpt-4.1-nano` la 150 cereri pe zi).
- Limitele se resetează la fiecare 24 de ore.

## Rezumat

- GitHub Models este **modalitatea recomandată de a începe să explorezi IA** în Theodia.
- Ai nevoie de un **cont GitHub gratuit** și de un **Token de acces personal** cu `models:read`.
- Cel mai bun model de început este **`openai/gpt-4.1-mini`**.
- Introdu tokenul și modelul în **Setări → Asistent IA**, atinge **Verificare conexiune** și începe conversația.
