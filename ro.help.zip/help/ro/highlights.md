---
title: Evidențierea versetelor
level: everyday
categories: [annotate, read]
summary: Cum marchezi versete în culori și cum le găsești mai târziu.
---

# Evidențierea versetelor

> **Mod:** Evidențierile sunt disponibile în modurile **Standard** și **Savant**. Modul focus este doar pentru citire curată, fără distrageri. Poți schimba modurile în **Setări** → **Mod utilizator aplicație**.

Evidențierea marchează un verset cu o culoare. Funcționează ca un marker galben pe hârtie. Versetul rămâne evidențiat și data viitoare când îl deschizi.

## Cum evidențiezi un verset

1. Deschide versetul.
2. Atinge versetul pentru a deschide meniul.
3. Atinge pictograma **Evidențiază**.
4. Alege o culoare.

Versetul este acum evidențiat în acea culoare.

## Cum schimbi culoarea evidențierii

1. Deschide versetul.
2. Atinge versetul, apoi atinge pictograma **Evidențiază**.
3. Alege o culoare nouă.

## Cum elimini o evidențiere

1. Deschide versetul.
2. Atinge versetul, apoi atinge **Evidențiază** în meniu.
3. Atinge **Elimină evidențierea** în partea de jos a selectorului de culori.

## O metodă comună de folosire a culorilor

Mulți cititori folosesc un set mic de culori pentru scopuri clare:

- **Galben** pentru favorite generale.
- **Verde** pentru versete despre Dumnezeu.
- **Albastru** pentru versete despre rugăciune.
- **Roz** pentru versete despre mângâiere.
- **Portocaliu** pentru versete despre avertisment sau îndreptare.
- **Violet** pentru versete despre profeție sau sfârșitul timpurilor.

Alege un sistem care funcționează pentru tine.

## Cum vezi toate evidențierile

Atinge fila **Repere** din partea de jos. Vezi o listă cu fiecare verset evidențiat, cele mai noi primele. În partea de sus este un rând de jetoane colorate — atinge o culoare pentru a arăta doar evidențierile acelei culori, sau atinge **Toate** pentru a șterge filtrul.

## Importarea evidențierilor

Poți aduce evidențieri în Theodia din alte aplicații și fișiere.

Mergi la **Setări** → **Marcaje** → **Importă evidențieri**. Alege **Importă din fișier** sau lipește din clipboard. Aplicația detectează automat formatul.

### Formate suportate

**Export JSON nativ** — Formatul folosit de funcția de export proprie a Theodia:

```json
{
  "/bible/KJV/John/3#v3_16": "yellow",
  "/bible/KJV/Genesis/1#v1_1": "green"
}
```

**CSV** — O foaie de calcul cu coloanele `url` și `color`. Exemplu:

```csv
url,color
/bible/KJV/John/3#v3_16,yellow
/bible/KJV/Genesis/1#v1_1,green
```

**Text simplu** — Fiecare linie este o referință biblică sau un URL, opțional urmat de un nume de culoare. Exemplu:

```
Ioan 3:16 yellow
Geneza 1:1 green
Matei 5:1
```

- Culorile disponibile: `yellow`, `green`, `blue`, `pink`, `orange`, `purple`.
- Dacă nu este dată nicio culoare, evidențierea implicită este galben.
- Liniile care încep cu `#` sau `//` sunt tratate ca comentarii și ignorate.

## Sfaturi

- Evidențierile rămân pe dispozitiv. Nu se sincronizează în cloud.
- Poți evidenția un verset într-o traducere și să apară în celelalte traduceri ale aceluiași verset.
- Vezi ghidul [Salvarea datelor tale](theodia://help/backups) pentru a le păstra în siguranță.
