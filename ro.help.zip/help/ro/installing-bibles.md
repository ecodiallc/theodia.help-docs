---
title: Instalarea traducerilor biblice
level: beginner
categories: start
summary: Cum adaugi o traducere biblică în biblioteca ta.
---

# Instalarea traducerilor biblice

Theodia vine cu câteva traduceri biblice gata de citit. Poți adăuga mai multe oricând. O „traducere" este o altă versiune a textului biblic, precum King James Version.

## Cum adaugi o traducere

Fila Biblia arată o listă cu traducerile deja instalate. Pentru a adăuga mai multe, deschide managerul de resurse:

1. Deschide **Setări**.
2. Atinge **Gestionează resursele**.
3. Atinge **Descarcă de pe GitHub**.
4. În modalul de descărcare, atinge fila **Biblii**.
5. Atinge căsuța de selectare lângă fiecare traducere dorită.
6. Atinge **Instalează selectate** în partea de jos.
7. Așteaptă să se finalizeze descărcarea.

Traducerea este acum în biblioteca ta. Pentru a o vedea, deschide fila **Biblia**.

## Cum comuți între traduceri

1. Deschide un capitol pe care vrei să îl citești.
2. Atinge numele traducerii din partea de sus a ecranului.
3. Alege-o pe cea dorită din listă.

Aplicația îți salvează alegerea pentru data viitoare.

## Cum elimini o traducere

1. Deschide **Setări**.
2. Atinge **Gestionează resursele**.
3. Găsește traducerea pe care vrei să o elimini.
4. Atinge **X** lângă ea.
5. Confirmă că vrei să o elimini.

Eliminarea unei traduceri nu îți șterge notițele, evidențierile sau marcajele. Acestea rămân în siguranță.

## Cât spațiu ocupă traducerile?

Majoritatea traducerilor au între 2 și 10 MB. Sunt stocate pe dispozitiv, nu în cloud. Poți păstra câte dorești, atâta timp cât dispozitivul tău are spațiu.

## Ce faci dacă o traducere nu este în aplicație?

Unele traduceri nu sunt în lista din aplicație. Totuși, le poți adăuga.

1. Deschide aplicația și mergi la **Setări** → **Gestionează resursele**.
2. Atinge **Descarcă de pe GitHub**.
3. În modalul de descărcare, uită-te la fila **Biblii** și la fila **Biblii globale**. Dacă traducerea ta este acolo, selecteaz-o și atinge **Instalează selectate**.
4. Dacă nu este, atinge **Importă fișier local** pentru a importa un fișier `.bible`. Obține fișierul de pe pagina de GitHub a proiectului. Vezi ghidul [Obținerea de resurse suplimentare de pe GitHub](theodia://help/getting-core-files) pentru ajutor pas cu pas.
