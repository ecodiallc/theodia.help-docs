---
title: Adăugarea fișierelor de bază
level: beginner
categories: start
summary: Cum descarci fișierele mari de date de care aplicația are nevoie pentru a studia Biblia în profunzime.
---

# Adăugarea fișierelor de bază

Theodia vine cu o Biblie și câteva mici extra-uri gata de folosit. Pentru a profita la maximum de aplicație, trebuie să descarci și **fișierele de bază**. Acestea sunt fișiere mari de date care adaugă instrumente de studiu precum comentarii, căutări de cuvinte și note gramaticale. Fără ele, aplicația funcționează, dar funcțiile de studiu sunt limitate.

## De ce ai nevoie de fișierele de bază

Fișierele de bază adaugă:

- **Căutări de cuvinte.** Atinge un cuvânt în orice verset pentru a vedea ebraica sau greaca originală și ce înseamnă.
- **Comentariu.** Comentariu IA pentru fiecare verset.
- **Gramatică.** Informații despre fiecare cuvânt în limba originală.
- **Biblie interlineară.** Citește textul în limba originală cu engleza sub fiecare cuvânt.

Poți citi Biblia fără ele, dar majoritatea instrumentelor de studiu au nevoie de ele.

## Cum instalezi fișierele de bază

**[Instalează fișierele de bază](theodia://manage/core)**

1. Deschide **Setări**.
2. Atinge **Gestionează resursele**.
3. Se deschide fila **Bază**. Vezi o listă cu fișierele de bază. Fiecare are un nume, o dimensiune și o căsuță de selectare.
4. Atinge fiecare fișier pe care vrei să îl instalezi. O bifă arată că este selectat.
5. Atinge **Instalează selectate**.
6. Așteaptă ca fișierele să se descarce și să se instaleze. Sunt mari, deci poate dura câteva minute pe o conexiune lentă.

Fișierele se descarcă pe dispozitiv. Trebuie să faci acest lucru doar o dată. Aplicația folosește fișierele de atunci înainte, chiar și când ești offline.

## Sfaturi

- Folosește Wi-Fi. Fișierele sunt mari.
- Conectează telefonul sau tableta la încărcător. Descărcările mari folosesc baterie.
- Dacă o descărcare eșuează, atinge din nou fișierul pentru a reîncerca.
- Poți instala toate sau doar cele de care ai nevoie.

## Ce faci dacă un fișier lipsește din listă?

Aplicația preia lista de pe pagina de GitHub a proiectului. Dacă lista este goală, verifică conexiunea la internet și încearcă din nou. Dacă este încă goală, vezi ghidul [Unde să pui întrebări](theodia://help/getting-more-help).

Pentru modalități mai avansate de a adăuga resurse, vezi ghidul [Obținerea de resurse suplimentare de pe GitHub](theodia://help/getting-core-files).
