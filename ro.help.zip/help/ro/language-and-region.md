---
title: Limba și regiunea aplicației
level: everyday
categories: settings
summary: Cum schimbi limba aplicației.
---

# Limba și regiunea aplicației

Theodia este disponibil în multe limbi. Aplicația poate schimba limba meniurilor și butoanelor. Conținutul de ajutor poate fi descărcat și în mai multe limbi; deschide **Setări** → **Ajutor** sau **Gestionează resursele** → **Descarcă de pe GitHub** → **Documentație ajutor** pentru a adăuga o limbă.

## Cum deschizi setările de limbă

1. Deschide **Setări**.
2. Atinge **Limbă**.

## Cum schimbi limba aplicației

1. În lista **Limbă**, atinge limba dorită.
2. Aplicația aplică noua limbă imediat.

Opțiunile pe care le vezi depind de limbile suportate de aplicație.

## Cum este aleasă limba la prima instalare

Când instalezi Theodia pentru prima dată, aplicația alege o limbă bazată pe setările dispozitivului. O poți schimba oricând.

## Ce este tradus

- Meniuri, butoane și etichete.
- Ecranele de setări.
- Mesajele de eroare.
- Instrumentele de căutare și studiu.

## Ce este doar în engleză

- Unele conținuturi de cărți și devoționale.
- Ghidurile de ajutor sunt disponibile în engleză și ca pachete descărcabile pentru alte limbi. Adaugă o limbă în **Setări** → **Ajutor** sau **Gestionează resursele** → **Descarcă de pe GitHub** → **Documentație ajutor**.

## Traducerile biblice și limba aplicației

Limba aplicației și limba traducerii biblice sunt lucruri diferite. Poți avea aplicația în spaniolă și Biblia în engleză, sau invers.

Pentru a schimba traducerea biblică, vezi ghidul [Instalarea traducerilor biblice](theodia://help/installing-bibles).

## Sfaturi

- Dacă un buton sau o etichetă este gol, aplicației îi lipsește o traducere. De obicei, versiunea în engleză este acolo ca rezervă.
- Dacă dorești să ajuți la traducerea aplicației, vezi ghidul [Unde să pui întrebări](theodia://help/getting-more-help).
