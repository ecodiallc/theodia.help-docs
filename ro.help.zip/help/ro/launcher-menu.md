---
title: Meniu rapid
level: everyday
categories: layout
summary: O cale rapidă de a sări la versete recente, a rula comenzi și a comuta aspectele cititorului fără a părăsi ecranul curent.
---

# Meniu rapid

> **Mod:** Meniul rapid necesită modul **Savant**. Poți schimba modurile în **Setări** → **Mod utilizator aplicație**.

Meniul rapid este un panou de acces rapid pe care îl poți deschide de aproape oriunde din aplicație. Acolo ții versetele recente, comenzile și configurațiile salvate ale Bibliei într-un singur loc.

## Cum îl deschizi

Atinge **pictograma de extindere (⌄)** în colțul din dreapta sus al antetului ecranului principal. Un panou alunecă din partea de sus.

## Ce conține

### 1. Caseta de comandă

În partea de sus a panoului este o casetă de text cu o pictogramă de tastatură. Tastează o comandă și apasă **Mergi** pe tastatură. Aplicația citește comanda și te duce direct acolo.

Exemple:

- `Ioan 3:16` — deschide acel verset.
- `caută dragoste` — caută în Biblie cuvântul „dragoste".
- `marcaj psalmii 23` — salvează versetul ca marcaj.
- `kjv` — comută la traducerea KJV.

Pentru lista completă de comenzi, vezi ghidul [Comenzi rapide](theodia://help/commands).

### 2. Seturi paralele

Dacă ai salvat presetări de Biblie paralelă, ele apar aici ca o listă restrânsă. Atinge una pentru a încărca instantaneu acea configurație paralelă.

Pentru a crea o presetare paralelă:

1. Deschide **Setări** → **Biblie paralelă**.
2. Adaugă traduceri și atinge **Salvează presetarea**.
3. Dă-i un nume. Va apărea în Meniul rapid.

Apasă lung pe un set paralel în Meniul rapid pentru a-l șterge.

### 3. Colecții biblice

Colecțiile biblice sunt scurtături la un atingere care comută traducerea și vizualizarea paralelă în același timp. Dacă ai creat vreuna, ele apar aici ca o listă restrânsă.

Apasă lung pe o colecție pentru a o șterge.

### 4. Pictograme de funcții

Sub caseta de comandă poți vedea un rând de butoane rotunde cu emoji. Acestea sunt scurtături la un atingere către funcțiile principale ale aplicației.

Pictogramele disponibile includ:

- **Despre**, **Biblia**, **Note biblice**, **Marcaje**, **Cărți**
- **Devotionale**, **Flashcarduri**, **Ajutor**, **Repere**
- **Playlisturi**, **Plugin-uri**, **Caută**, **Setări**, **Theoscript**

Pentru a alege ce pictograme apar și în ce ordine:

1. Deschide **Setări** → **Meniu rapid**.
2. Atinge **Pictograme meniu de lansare**.
3. Folosește comutatoarele pentru a arăta sau ascunde fiecare pictogramă.
4. Folosește săgețile sus/jos pentru a reordona cele activate.

Ordinea din setări este ordinea în care apar în Meniul rapid.

### 5. Versete recente

Aplicația își amintește ultimele capitole și versete pe care le-ai deschis. Ele apar ca o listă în partea de jos a panoului. Atinge orice intrare pentru a sări direct înapoi la ea.

- **Atinge** pentru a deschide.
- **Glisează la stânga** sau **apasă lung** pentru a elimina din listă.
- Atinge **Șterge tot** pentru a elimina toate intrările deodată.

## Când să folosești Meniul rapid

Folosește-l când vrei să:

- Sari înapoi la un verset pe care tocmai l-ai citit.
- Tastezi o comandă fără a merge la ecranul principal.
- Comuți traducerea sau configurația paralelă la un atingere.
- Deschizi o funcție majoră de oriunde din aplicație.
- Verifici ceva rapid fără a naviga prin meniuri.

## Sfaturi

- Meniul rapid este disponibil pe aproape fiecare ecran, deci îl poți deschide în timp ce citești un capitol.
- Caseta de comandă suportă aceleași comenzi ca și caseta de comandă de pe ecranul principal.
- Pictogramele de funcții și ordinea lor sunt salvate local pe dispozitiv. Supraviețuiesc repornirilor aplicației.
- Versetele recente sunt salvate local pe dispozitiv. Supraviețuiesc repornirilor aplicației.
