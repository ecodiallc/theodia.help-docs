---
title: Navigarea între cărți, capitole și versete
level: everyday
categories: [layout, read]
summary: Cum te deplasezi prin Biblie și cum sari unde vrei să ajungi.
---

# Navigarea între cărți, capitole și versete

Acest ghid îți arată toate modalitățile de a te deplasa prin Biblie.

## Calea ușoară: glisare

- Glisează la **stânga** pe un capitol pentru a merge la capitolul următor.
- Glisează la **dreapta** pentru a te întoarce.
- Funcționează și pentru cartea următoare. După ultimul capitol al Exodului, glisarea te duce la Levitic 1.

## Calea prin meniu

- Atinge numele traducerii din partea de sus pentru a schimba Biblia.
- Atinge numele cărții din partea de sus pentru a alege o altă carte.
- Atinge numărul capitolului pentru a alege un alt capitol.

## Calea rapidă: tastare

- Pe pagina principală este o casetă în partea de sus. Tastează o referință, cum ar fi `Ioan 3:16` sau `psalmii 23`, și apasă tasta **Mergi** de pe tastatură.
- Aplicația deschide versetul.

## Calea prin marcaje

Dacă ai salvat un verset, deschide fila **Marcaje**. Atinge orice intrare pentru a sări la el.

## Calea prin căutare

Atinge fila **Caută**. Tastează un cuvânt. Aplicația îți arată fiecare verset care îl conține. Atinge orice rezultat pentru a-l deschide.

## Calea prin istoric

Aplicația își amintește capitolele pe care le-ai deschis. Pentru a le regăsi, caută în fila **Marcaje** (pentru versetele salvate) sau derulează lista de cărți din fila **Biblia** pentru a găsi o carte citită recent.

## Sfaturi

- Fila Biblia arată cărțile în ordine, de la Geneza la Apocalipsa.
- Pentru Psalmii, Proverbe și alte cărți lungi, atinge cartea și folosește lista de capitole pentru a sări departe.
