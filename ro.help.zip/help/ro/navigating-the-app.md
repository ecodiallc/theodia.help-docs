---
title: Aspectul aplicației și navigarea
level: beginner
categories: layout
summary: Un tur al ecranului principal, al meniului principal și al barei de jos — unde se află totul.
---

# Aspectul aplicației și navigarea

Theodia are trei zone principale între care te poți deplasa: **ecranul principal**, **meniul principal** și **bara de jos**. Acest ghid trece prin fiecare, ca să știi mereu încotro să mergi.

## O hartă rapidă

- **Ecranul principal** este pagina pe care o vezi când deschizi aplicația. Are o casetă de căutare, butoane mari pentru fiecare parte a aplicației și o listă cu Biblia, cărțile și devoționalele instalate.
- **Bara de jos** (sau bara de file) este rândul de pictograme din partea de jos a ecranului. Atinge oricare pentru a sări direct în acea parte a aplicației.
- **Meniul principal** este pictograma cu trei linii (☰) în colțul din dreapta sus al ecranului principal. Atinge-o pentru a deschide o listă cu toate ecranele aplicației, inclusiv cele care nu au propria filă.

## Ecranul principal

Când deschizi Theodia pentru prima dată, ajungi pe ecranul principal. Este împărțit în patru părți, de sus în jos.

### Antetul

În partea de sus este o bară colorată. În stânga se află pictograma aplicației și numele „Theodia”. În dreapta este butonul meniului principal (☰). Când ești într-o carte sau capitol, în stânga apare în schimb un buton de înapoi (←). Atinge meniul principal pentru a-l deschide (vezi mai jos).

### Comanda rapidă

Chiar sub antet este o casetă de text în stil de căutare, etichetată **Comandă rapidă**. Tastează o scurtă instrucțiune și apasă tasta de execuție de pe tastatură. Aplicația citește instrucțiunea și te duce la ecranul potrivit. Exemple:

- `psalmii 23` — deschide Psalmul 23
- `ioan 3:16` — deschide Ioan 3:16
- `caută dragoste` — caută în Biblie cuvântul „dragoste"
- `marcaj ioan 3:16` — salvează Ioan 3:16 ca marcaj
- `comentariu romani 8:28` — deschide comentariul pentru acel verset
- `xref` (urmât de o referință) — deschide referințele încrucișate pentru acel verset
- `ajutor` — deschide lista de comenzi cu exemple

Dacă aplicația nu înțelege ce ai tastat, arată un mic indiciu. Vezi ghidul **Probleme comune** dacă comenzile nu funcționează.

### Grila de butoane

Sub Comanda rapidă este o grilă de butoane mari, câte două pe rând. Fiecare buton te duce într-o altă parte a aplicației. Butoanele sunt:

- 📖 **Biblia** — lista ta de traduceri biblice
- 🔍 **Caută** — caută în Biblie un cuvânt sau o expresie
- 📚 **Cărți** — biblioteca ta de clasice creștine
- 📅 **Devotionale** — devoționale zilnice
- 🔖 **Marcaje** — versetele și capitolele tale salvate
- 🖍 **Repere** — versetele tale marcate cu culoare
- 📝 **Note biblice** — notițele tale private despre versete
- ⚙️ **Setări** — limbă, temă, resurse și multe altele
- ❓ **Ajutor** — sistemul de ajutor (această pagină)
- ℹ️ **Despre** — versiunea aplicației și mulțumiri

### Listele de resurse

Sub grila de butoane sunt secțiuni extensibile: **Biblia**, **Cărți** și **Devotionale**. Fiecare secțiune arată elementele instalate. Atinge antetul unei secțiuni pentru a o extinde sau restrânge. Atinge orice element dintr-o secțiune pentru a-l deschide.

Secțiunea Biblia este cea mai rapidă cale de a sări într-o traducere anume — fără meniuri, doar atinge.

## Bara de jos

Bara de jos (bara de file) este rândul de pictograme din partea de jos a ecranului. Este vizibilă aproape pretutindeni în aplicație, așa că poți sări oricând în altă secțiune. Filele pe care le vezi depind de modul tău de utilizare.

**Toate modurile văd:**

- 🏠 **Acasă** — deschide ecranul principal
- 📖 **Biblia** — deschide lista de traduceri biblice
- 📚 **Cărți** — deschide biblioteca de cărți
- 🔍 **Caută** — deschide căutarea în Biblie
- ⚙️ **Setări** — deschide setările

**Modurile Standard și Savant văd și:**

- 🔖 **Marcaje** — deschide versetele salvate
- 🖍 **Repere** — deschide versetele marcate cu culoare
- 📝 **Note biblice** — deschide notițele private

**Modul Savant vede și:**

- 💻 **Asistent IA** — deschide asistentul IA (dacă l-ai activat în Setări)

Fila curentă este evidențiată. Atinge orice altă filă pentru a comuta.

### Cum se comportă bara de jos

Fiecare filă din bară are propria **stivă** de ecrane. Când atingi o filă, te întorci **unde ai rămas** în stiva ei, nu la ecranul de start. De exemplu:

- Atingi **Biblia** → vezi lista de traduceri biblice.
- Atingi o traducere → vezi lista de cărți.
- Atingi o carte → vezi lista de capitole.
- Atingi un capitol → citești capitolul.
- Treci la **Marcaje** pentru a verifica ceva.
- Atingi **Biblia** din nou → revii la capitolul pe care îl citeai.

Fiecare filă își amintește locul. Aplicația păstrează istoricul de navigare în interiorul fiecărei file, deci comutarea între file nu îți pierde progresul.

### Ce resetează o filă

O filă revine la ecranul ei de bază doar când:

- Ești deja pe acea filă și atingi din nou aceeași pictogramă. Este o metodă rapidă de a reveni la start.
- Aplicația este închisă forțat și redeschisă.

### Filele de jos față de meniul principal

- **Filele de jos** — fiecare filă își amintește propria stivă. Atingerea unei file te întoarce unde ai rămas.
- **Meniul principal** — atingerea unui element navighează la acel ecran folosind același sistem de file. Nu se deschide ca o suprapunere.

Folosește filele pentru a comuta sarcinile. Folosește meniul principal când vrei o listă completă cu toate ecranele aplicației.

### Când să folosești bara de jos

Folosește bara de jos când vrei să schimbi ceea ce faci:

- Citești un capitol și vrei să cauți altceva → atinge **Caută**.
- Cauți și vrei să verifici marcajele → atinge **Marcaje**.
- Ești oriunde în aplicație și vrei să mergi acasă → atinge **Acasă**.

## Meniul principal

Meniul principal este butonul cu trei linii suprapuse (☰) în colțul din dreapta sus al ecranului principal. Atinge-l și un panou alunecă din partea dreaptă. Panoul arată fiecare ecran suportat de modul tău curent:

- 🏠 **Acasă**
- 📖 **Biblia**
- 📚 **Cărți**
- 🙏 **Devotionale**
- 🔍 **Caută**
- 🔖 **Marcaje** (Standard și Savant)
- 🖍 **Repere** (Standard și Savant)
- 📝 **Note biblice** (Standard și Savant)
- 💻 **Asistent IA** (doar Savant, și doar dacă IA este activată)
- ⚙️ **Setări**
- ❓ **Ajutor**
- ℹ️ **Despre**

Elementul care se potrivește ecranului curent este evidențiat și are un mic punct lângă el. Atinge orice element pentru a merge direct acolo. Atinge în afara panoului, X-ul de sus sau butonul înapoi al dispozitivului pentru a-l închide fără a schimba ecranele.

### Cum diferă meniul principal

Meniul principal este un panou derulant, nu un strat de navigare separat. Când atingi un element, aplicația navighează la acel ecran la fel ca atunci când ai folosi fila de jos sau grila de butoane. Stiva filei tale curente este păstrată, deci te poți întoarce unde ai fost atingând din nou fila originală.

De exemplu:

- Citești Ioan 3. Atingi fila **Marcaje**. Mergi la marcaje. Când atingi **Biblia** din nou, revii la Ioan 3 — exact unde ai rămas.
- Citești Ioan 3. Deschizi meniul principal și atingi **Note biblice**. Se deschid notițele. Pentru a reveni la Ioan 3, atinge fila **Biblia** și revii automat la capitol.

Filele comută contextul și își amintesc locul. Meniul principal este doar o altă cale de a ajunge la aceleași ecrane.

### Când să folosești meniul principal

Folosește meniul principal când:

- Vrei să deschizi **Repere**, **Note biblice**, **Devotionale**, **Ajutor** sau **Despre** — ecrane care nu au propria filă în bara de jos.
- Ești adânc într-un capitol sau într-o căutare și vrei să verifici ceva rapid, fără să îți pierzi locul.
- Vrei să deschizi **Setări** fără să părăsești ecranul curent.

## Modul Savant

Dacă modul tău de utilizare este **Savant**, aspectul câștigă file suplimentare, elemente de meniu și instrumente în cititor, pe care modurile Cititor și Standard le ascund. Vezi ghidul [Mod Savant](theodia://help/scholar-mode) pentru un tur complet al fiecărei funcții.

## Cum se potrivesc cele trei zone

- **Treci la o secțiune principală diferită** (Biblia, Caută, Marcaje etc.) → bara de jos
- **Sari la un verset sau o comandă** → Comanda rapidă de pe ecranul principal
- **Răsfoiești toate ecranele disponibile** → grila de butoane de pe ecranul principal
- **Verifici Note, Repere sau Ajutor fără să pleci** → meniul principal
- **Deschizi Setări de oriunde** → meniul principal sau bara de jos

Vei folosi toate trei. Niciuna nu este „cea corectă”. Alege-o pe cea mai ușoară pentru ceea ce faci.

### Bara de jos față de meniul principal: un exemplu rapid

Imaginază că citești Romani 8 și vrei să evidențiezi un verset care îți place.

**Folosind bara de jos:**

1. Atinge versetul pentru a deschide meniul versetului.
2. Atinge **Evidențiază** și alege o culoare.
3. Gata. Nu ai părăsit capitolul.

**Folosind meniul principal (dacă vrei să îți revezi evidențierile):**

1. Atinge ☰ pentru a deschide meniul.
2. Atinge **Repere**. Se deschide lista evidențierilor.
3. Revezi-le, apoi atinge fila **Biblia** pentru a reveni la Romani 8.

**Folosind bara de jos (dacă vrei să schimbi sarcina):**

1. Atinge **Acasă** sau **Marcaje** în bara de jos.
2. Părăsești Romani 8 și mergi la ecranul nou.
3. Pentru a reveni la Romani 8, atinge **Biblia** din nou — revii automat la capitol.

## Sfaturi

- Ecranul principal își amintește care secțiuni sunt extinse sau restrânse. Trebuie să le setezi o singură dată.
- Dacă nu vezi o filă la care te aștepți, verifică două lucruri:

1. **Modul tău de utilizare** — modul Cititor ascunde marcajele, evidențierile, notele și IA. Modul Standard ascunde IA. Schimbă modul în **Setări** → **Mod utilizator aplicație**.
2. **Setările funcțiilor** — unele file trebuie activate în **Setări** (de exemplu, asistentul IA).
