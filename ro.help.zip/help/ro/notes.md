---
title: Scrierea de note
level: everyday
categories: [annotate, read]
summary: Cum îți scrii gândurile lângă un verset.
---

# Scrierea de note

> **Mod:** Notele sunt disponibile în modurile **Standard** și **Savant**. Modul focus este doar pentru citire curată, fără distrageri. Poți schimba modurile în **Setări** → **Mod utilizator aplicație**.

Notele sunt locul unde îți scrii gândurile, rugăciunile sau ideile de studiu lângă un verset. Fiecare notă este legată de un verset anume.

## Cum adaugi o notă

1. Deschide versetul.
2. Atinge versetul pentru a deschide meniul.
3. Atinge **Notă** în meniu. Are o pictogramă în formă de creion.
4. Scrie nota.
5. Atinge **Salvează**.

Nota este acum salvată cu versetul.

## Cum citești o notă

1. Deschide versetul.
2. Caută semnul de creion lângă verset. Înseamnă că există o notă.
3. Atinge versetul. Nota apare dedesubt.

## Cum editezi o notă

1. Deschide versetul cu nota.
2. Atinge versetul.
3. Atinge **Notă** în meniu.
4. Fă modificările.
5. Atinge **Salvează**.

## Cum ștergi o notă

1. Deschide versetul cu nota.
2. Atinge versetul.
3. Atinge **Notă** în meniu.
4. Atinge **Șterge**.

## Cum vezi toate notele

Atinge fila **Note biblice** din partea de jos. Vezi o listă cu fiecare notă scrisă, sortată după dată.

## Caută în note

În fila **Note biblice**, atinge caseta **Caută**. Tastează un cuvânt. Aplicația găsește fiecare notă care îl conține.

## Sfaturi

- Notele sunt excelente pentru predici, devoționale și întrebări de studiu.
- Notele sunt private. Rămân pe dispozitiv.
- Vezi ghidul [Salvarea datelor tale](theodia://help/backups) pentru a le păstra în siguranță.
