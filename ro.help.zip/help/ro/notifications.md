---
title: Notificări și memento-uri
level: everyday
categories: [settings]
summary: Cum activezi, personalizezi și gestionezi memento-urile offline pentru rugăciune, devoționale, planuri biblice și multe altele.
---

# Notificări și memento-uri

Theodia îți poate aminti de rugăciune, devoționale, planuri biblice, flashcarduri și alte activități — chiar și când aplicația este offline. Toate memento-urile sunt programate pe dispozitiv; nu este nevoie de conexiune la internet sau de server de notificări push.

## Cum activezi sau dezactivezi memento-urile

1. Deschide **Setări**.
2. Atinge **Notificări**.
3. Activează sau dezactivează **Activează memento-uri**.

Prima dată când activezi memento-urile, aplicația cere permisiunea de a trimite notificări. Atinge **Permite**, ca memento-urile să poată apărea.

Dacă ai refuzat anterior permisiunea, iOS sau Android pot bloca cererea. În acest caz, mergi la aplicația **Setări** a dispozitivului, găsește **Theodia** și activează notificările acolo.

## Tipuri de memento-uri

Ecranul de notificări este împărțit în canale. Fiecare canal este o familie de memento-uri pe care le poți activa sau dezactiva independent:

- **Memento-uri de rugăciune** — memento-uri generale de rugăciune.
- **Rutină de rugăciune** — memento-uri legate de o rutină de rugăciune anume.
- **Devoțional** — memento-ul pentru versetul sau devoționalul zilei.
- **Memento-uri plan biblic** — memento-uri pentru un plan biblic activ.
- **Memento-uri Theoscript** — memento-uri pentru a rula un Theoscript.
- **Memento-uri insight IA** — memento-uri generate de IA.
- **Memento-uri de revizuire flashcard** — îndemnuri pentru a revizui flashcarduri.
- **Memento-uri de obicei de citire** — îndemnuri zilnice pentru obiceiul de citire.
- **Memento-uri liturgice și sezoniere** — memento-uri legate de calendarul bisericesc.
- **Memento-urile mele** — memento-uri create din marcaje, evidențieri, playlisturi, capitole biblice sau cărți.
- **Memento-uri personalizate** — memento-uri complet personalizate create de tine.

Atinge orice canal pentru a-i vedea memento-urile, a schimba ora, a alege zilele în care se declanșează sau a-l dezactiva.

## Memento-uri personalizate

Memento-urile personalizate sunt memento-uri pe care le construiești de la zero.

1. În **Setări** → **Notificări**, atinge **Memento-uri personalizate**.
2. Atinge butonul **+**.
3. Introdu un **Titlu** și un **Mesaj**.
4. Alege o **Oră**.
5. Alege **Zilele** în care vrei să se repete.
6. Alege ce deschide memento-ul când este atins (opțional).
7. Atinge **Salvează**.

Poți edita sau șterge un memento personalizat oricând atingându-l în listă.

## Ce se întâmplă când atingi un memento

Majoritatea memento-urilor deschid un anumit ecran în aplicație. De exemplu, un memento pentru o rutină de rugăciune deschide acea rutină; un memento pentru un plan biblic deschide citirea următoare.

Dacă un memento nu are un ecran legat, deschide aplicația la ecranul principal.

## Ore de liniște

Orele de liniște silențiază sunetele notificărilor, lăsând totuși memento-urile vizuale să apară.

1. În **Setări** → **Notificări**, atinge **Ore de liniște**.
2. Setează o **Oră de început** și o **Oră de sfârșit**.

Memento-urile programate în orele de liniște vor apărea pe ecran fără sunet.

## Memento-uri viitoare și istoric

- **Memento-uri viitoare** arată tot ce este programat să se declanșeze în continuare.
- **Istoric notificări** arată memento-urile livrate recent, programate și anulate.

Folosește aceste liste pentru a confirma că un memento este setat corect sau pentru a vedea de ce unul nu a apărut.

## Dacă memento-urile nu apar

- Asigură-te că **Activează memento-uri** este pornit.
- Verifică că notificările sunt permise în setările de sistem ale dispozitivului.
- Asigură-te că canalul memento-ului este activat și că cel puțin o zi este selectată.
- Dacă ai setat ore de liniște, memento-ul poate fi silențios.
- Unii producători de Android pun aplicațiile în stare de repaus. Adaugă Theodia în lista de excepții dacă dispozitivul tău oferă setări de optimizare a bateriei.
- Dacă un memento este legat de conținut pe care l-ai eliminat (de exemplu, un plan biblic sau o rutină șterse), memento-ul poate să nu se declanșeze până când nu selectezi din nou o țintă validă.

## Sunete de notificare

Poți alege sunetul redat de memento-urile care suportă sunete. Atinge **Sunet** în interiorul unui memento sau canal pentru a alege din opțiunile disponibile. Sunetele sunt incluse în aplicație, deci funcționează offline.

Folosește butonul **Previzualizează sunetul** pentru a auzi sunetul selectat înainte de salvare.

## Insigne

Unele memento-uri pot adăuga o insignă pe pictograma aplicației. Atinge **Șterge insigna** pe ecranul de notificări pentru a o reseta.
