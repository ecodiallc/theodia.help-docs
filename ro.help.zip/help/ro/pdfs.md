---
title: PDF-uri
level: everyday
categories: [read, resources]
summary: Importă, organizează și citește documente PDF în Theodia.
---

# PDF-uri

> **Mod:** Fișierele PDF sunt disponibile în modurile **Standard** și **Savant**. Modul focus este doar pentru citire curată, fără distrageri. Poți schimba modurile în **Setări** → **Mod utilizator aplicație**.

Theodia poate stoca și citi fișiere PDF. PDF-urile importate rămân pe dispozitivul tău, deci funcționează offline.

## Deschide biblioteca de PDF-uri

Atinge fila **PDF-uri** din partea de jos a ecranului, sau atinge dala **PDF-uri** de pe ecranul principal.

## Importarea unui PDF

1. Deschide fila **PDF-uri**.
2. Atinge butonul **+** din colțul din dreapta jos.
3. Alege un PDF de pe dispozitivul tău.
4. (Opțional) Scrie sau alege o categorie pentru a-l organiza.

## Organizarea PDF-urilor

Apasă lung pe orice card PDF pentru a deschide un meniu cu aceste opțiuni:

- **Redenumește** — schimbă titlul arătat în bibliotecă.
- **Schimbă categoria** — mută PDF-ul într-o categorie.
- **Șterge** — elimină PDF-ul din Theodia. Asta șterge și poziția de citire salvată.

Categoriile sunt text liber. Scrie un nume nou sau alege unul existent când importi sau schimbi categoria.

## Citirea unui PDF

Atinge un card PDF pentru a-l deschide. Cititorul arată:

- Titlul documentului într-o bară sus.
- Un rând de butoane de pagină: **Prima pagină**, **Anterior**, pagina curentă („3 / 120”), **Următor** și **Ultima pagină**.
- O bară de unelte cu instrumentele documentului: **Cuprins**, **Micșorează zoom**, **Mărește zoom**, **Resetează zoom**, **Marcaj**, **Caută**, **Ascultă** și **Vizualizare text**.

Unele instrumente apar cenușii când nu pot fi folosite — de exemplu, **Caută** și **Ascultă** sunt cenușii până când textul căutabil al PDF-ului este instalat.

### Răsfoirea paginilor

- Atinge **chevronul din stânga** sau **din dreapta** pentru a merge cu o pagină înapoi sau înainte.
- Atinge **Prima pagină** sau **Ultima pagină** pentru a sări la oricare dintre capetele documentului.
- Atinge numărul paginii (de exemplu „3 / 120”) pentru a deschide o grilă de pagini, apoi atinge pagina pe care o vrei. Grila se deschide lângă pagina pe care ești.
- Folosește **tastele cu săgeți stânga și dreapta** de pe o tastatură externă.

### Zoom

- Atinge **Mărește zoom** (+) sau **Micșorează zoom** (−) pentru a schimba dimensiunea paginii.
- Atinge **Resetează zoom** pentru a readuce pagina la dimensiunea normală.
- Dacă mărești zoomul, răsfoști și apoi micșorezi zoomul, Theodia te întoarce la pagina pe care o citeai.

## Căutarea în interiorul unui PDF

1. Deschide PDF-ul și atinge butonul **Caută** (lupa) din bara de unelte.
2. Scrie ce cauți. Rezultatele apar pe măsură ce scrii, cu numărul paginii și un fragment din textul din jur.
3. Atinge un rezultat pentru a sări la pagina respectivă.

Căutarea are nevoie de textul căutabil al PDF-ului instalat. Dacă nu este încă instalat, butonul Caută este cenușiu. PDF-urile instalate din repository-ul GitHub al comunității includ text căutabil; PDF-urile pe care le imporți tu nu îl au până când nu este adăugat.

## Cuprins

Dacă PDF-ul are un cuprins încorporat, butonul **Cuprins** din bara de unelte îl arată ca schiță. Atinge titlul unei secțiuni pentru a sări la pagina respectivă. Secțiunile pot fi extinse și restrânse. Dacă PDF-ul nu are cuprins, butonul este cenușiu.

## Marcaje într-un PDF

1. Deschide PDF-ul și atinge butonul **Marcaj** din bara de unelte.
2. Atinge **Marchează pagina** pentru a salva pagina curentă. Numele începe ca numărul paginii — scrie un nume dacă preferi — apoi atinge **Salvează**.
3. Atinge orice marcaj din listă pentru a sări la pagina lui.
4. Atinge **×** lângă un marcaj pentru a-l șterge.

Marcajele din PDF-uri sunt separate de marcajele tale din Biblie. Fiecare PDF își păstrează propria listă.

## Ascultarea unui PDF

Dacă textul căutabil al PDF-ului este instalat, Theodia poate citi cu voce tare pagina curentă:

1. Deschide PDF-ul și atinge butonul **Ascultă** (difuzorul) din bara de unelte.
2. Apare o bară de control cu **Redă/Pauză**, **Derulează înapoi**, **Derulează înainte**, **Oprește**, o bară de progres pe care o poți atinge pentru a sări în interiorul paginii, viteza de citire și vocea.
3. Când pagina se termină, citirea continuă automat pe pagina următoare.

Vocea și viteza sunt aceleași folosite la citirea Bibliei — vezi ghidul [Citirea cu voce tare](theodia://help/tts) pentru cum să le schimbi.

## Copierea, partajarea sau salvarea textului paginii

Atinge butonul **Vizualizare text** din bara de unelte pentru a vedea pagina curentă ca text simplu. De acolo poți:

- **Copiază** — copiază textul paginii în clipboard.
- **Partajează** — partajează textul paginii prin orice aplicație de pe dispozitivul tău.
- **Adaugă în note** — deschide un editor de note cu textul paginii, o citare și un link înapoi la această pagină, completate deja pentru tine.

## Reluarea citirii

Theodia își amintește ultima pagină pe care ai văzut-o și data viitoare deschide PDF-ul acolo.

## Descărcarea de PDF-uri de pe GitHub

În modul **Savant**, un buton **Descarcă de pe GitHub** apare în partea de jos a bibliotecii. Acesta se conectează la repository-ul GitHub al comunității cu PDF-uri, ca să poți instala documente PDF ambalate în același mod în care instalezi Biblie sau cărți.

## Note

- PDF-urile sunt stocate în folderul privat de documente al Theodia. Nu sunt incluse în backup-uri, deci dacă treci la un dispozitiv nou va trebui să le imporți din nou.
