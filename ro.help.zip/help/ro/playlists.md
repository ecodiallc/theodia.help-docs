---
title: Playlisturi
level: everyday
categories: playlists
summary: Creează și ascultă playlisturi vorbite de pasaje biblice, text simplu sau orice verset pe care vrei să îl auzi.
---

# Playlisturi

Un **playlist** este o listă de piese pe care Theodia le poate citi cu voce tare pentru tine. Fiecare piesă este fie un pasaj biblic, fie o scurtă notă în text simplu. Playlisturile sunt utile pentru ascultarea fără mâini în timpul unei călătorii, al unei plimbări, al timpului devoțional sau al practicii de memorare.

Playlisturile apar în aplicație odată ce cel puțin un playlist a fost creat sau populat.

## Unde găsești Playlisturile

Când playlisturile sunt disponibile, le poți accesa în două moduri:

- **Ecranul principal:** În secțiunea **Plugin-uri și altele**, atinge **Playlisturi**.
- **Meniul principal:** Deschide meniul (☰) și atinge **Playlisturi**.

Dacă nu există încă playlisturi, dala și elementul de meniu Playlisturi sunt ascunse.

## Ce conține un playlist

Fiecare playlist are:

- Un **nume** — de exemplu, „Versete de dimineață" sau „Memorează Psalmii 23".
- O **categorie** opțională — utilă pentru gruparea playlisturilor după scop.
- O listă de **piese** — elementele de citit cu voce tare.

Fiecare piesă conține:

- **Conținut** — fie o referință de pasaj biblic, fie text simplu.
- O **etichetă** — arătată pe ecran cât timp piesa este redată.
- O **voce** opțională — alege o voce diferită pentru această piesă dacă vrei.

## Crearea unui playlist

1. Deschide ecranul **Playlisturi**.
2. Atinge **Creează playlist** (sau butonul **+**).
3. Dă playlistului un nume.
4. (Opțional) Alege sau creează o categorie.
5. Începe să adaugi piese.

### Adăugarea unei piese dintr-un pasaj biblic

1. Atinge **Adaugă piesă**.
2. Alege **Pasaj biblic** ca tip de conținut.
3. Introdu o referință, precum `Ioan 3:16` sau `Psalmii 23:1-6`.
4. Adaugă o etichetă dacă vrei, sau las-o goală pentru a folosi referința.
5. Salvează piesa.

### Adăugarea unei piese în text simplu

1. Atinge **Adaugă piesă**.
2. Alege **Text simplu**.
3. Tastează textul pe care vrei să îl citească Theodia.
4. Adaugă o etichetă.
5. Salvează piesa.

### Adăugare în lot

Dacă ai o listă de referințe sau linii de text, folosește **Adăugare în lot**:

1. Deschide un playlist.
2. Atinge meniul și alege **Adăugare în lot**.
3. Lipește câte o referință sau linie de text pe linie.
4. Activează **Detectează referințe biblice** dacă majoritatea liniilor sunt referințe de versete.
5. Atinge **Adaugă**. Fiecare linie devine o piesă.

## Ascultarea unui playlist

1. Deschide playlistul pe care vrei să îl asculți.
2. Atinge butonul **Redă** din partea de sus sau lângă o piesă.
3. Theodia citește fiecare piesă în ordine.

Cât timp un playlist este redat, apare o bară de control cu aceste controale:

- **Redă / Pauză**
- **Piesa următoare**
- **Piesa anterioară**
- **Oprește**

Poți seta și:

- **Viteză** — cât de repede citește vocea.
- **Repetă** — repetă tot playlistul, repetă o piesă sau redă o singură dată.
- **Amestecă** — redă piesele în ordine aleatorie.
- **Ignoră parantezele** — sari peste textul din paranteze.
- **Pauză între piese** — adaugă o scurtă tăcere între piese.
- **Temporizator de oprire** — oprește redarea după un anumit timp.

## Editarea unui playlist

Pentru a modifica un playlist, pune mai întâi redarea pe pauză dacă rulează.

Poți:

- **Redenumi** playlistul.
- **Reordona piesele** — trage piesele într-o ordine nouă.
- **Edita o piesă** — schimbă referința, textul, eticheta sau vocea.
- **Șterge o piesă** — elimin-o din playlist.
- **Șterge tot playlistul** — acest lucru nu poate fi anulat.

## Exportarea și importarea playlisturilor

Playlisturile sunt exportate ca fișiere JSON care includ toate piesele, categoriile și setările. Poți partaja fișierul cu alt dispozitiv, îl poți păstra ca backup sau îl poți edita pe un computer.

- **Exportă toate playlisturile** — creează un fișier `playlists-AAAA-LL-ZZ.json`.
- **Exportă o categorie** — creează un fișier JSON care conține doar playlisturile dintr-o categorie.
- **Importă playlisturi** — restaurează playlisturile dintr-un fișier backup JSON.

## Căi rapide pentru a construi un playlist

Poți crea un playlist complet ca JSON și apoi să îl imporți. Iată un exemplu:

```json
{
  "playlists": [
    {
      "name": "Versete de dimineață",
      "category": "Devoțional",
      "tracks": [
        {
          "info": "Ioan 3:16",
          "contentSource": "passage",
          "content": "For God so loved the world...",
          "rawContent": "Ioan 3:16"
        },
        {
          "info": "Psalmul 23",
          "contentSource": "passage",
          "content": "The Lord is my shepherd...",
          "rawContent": "Psalmii 23:1-6"
        }
      ]
    }
  ]
}
```

Salvează fișierul, apoi folosește **Importă playlisturi** pentru a-l încărca în Theodia.

## Sfaturi

- Playlisturile funcționează cel mai bine cu seturi scurte și concentrate de versete.
- Folosește categorii pentru a separa playlisturile devoționale de cele de memorare.
- Setează un temporizator de oprire dacă asculți în timp ce adormi.
- Dacă o piesă folosește vocea greșită, verifică că limba vocii se potrivește cu limba textului.
- Theodia citește textul simplu exact așa cum este scris; verifică ortografia pentru cele mai bune rezultate.
