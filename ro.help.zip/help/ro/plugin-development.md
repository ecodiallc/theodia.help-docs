---
title: Dezvoltarea pluginurilor
level: advanced
categories: plugins
summary: Ce conține un pachet de plugin Theodia și cum să creezi un manifest de plugin.
---

# Dezvoltarea pluginurilor

Un plugin Theodia este un pachet autonom care adaugă suprafețe UI, conținut sau gestionare de evenimente în aplicație. Pluginurile sunt create în afara aplicației principale și instalate de utilizatori prin Setări → Pluginuri.

## Structura pachetului de plugin

Un pachet de plugin este o arhivă ZIP cu extensia `.plugin.zip`. În interior, fișierele se află la nivelul superior — nu într-un folder imbricat.

Un pachet tipic conține:

```
my-plugin.plugin.zip
├── plugin.json       (obligatoriu)
├── data.sqlite       (opțional, pentru pluginuri de conținut/UI)
├── template.html     (opțional)
├── style.css         (opțional)
└── logo.png          (opțional)
```

Fișiere obligatorii:

- `plugin.json` — manifestul pluginului (vezi mai jos).

Fișiere opționale:

- O bază de date SQLite pentru pluginurile care stochează conținut sau date UI.
- Resurse HTML, Markdown, imagini sau JSON la care se face referire în manifest.

Toate referințele la resurse în `plugin.json` trebuie să folosească nume exacte de fișiere plate, fără căi. De exemplu, folosește `template.html` în loc de `templates/template.html`.

## Bazele manifestului

Un `plugin.json` minim arată astfel:

```json
{
  "id": "org.example.myplugin",
  "name": "Example Plugin",
  "version": "0.1.0",
  "type": "ui",
  "description": "A short description of what the plugin does.",
  "extensions": [
    {
      "surface": "bible-verse-menu",
      "config": {
        "label": "Example",
        "icon": "🔌",
        "screenType": "template",
        "templateFile": "template.html"
      }
    }
  ]
}
```

### Câmpuri comune ale manifestului

| Câmp            | Obligatoriu                       | Descriere                                                          |
| --------------- | --------------------------------- | -------------------------------------------------------------------|
| `id`            | Da                                | Identificator în stil domeniu inversat, de exemplu `org.example.myplugin`. |
| `name`          | Da                                | Numele afișat utilizatorilor.                                      |
| `version`       | Da                                | Versiunea pluginului în format semver.                             |
| `type`          | Da                                | `ui`, `content` sau `composite`.                                   |
| `description`   | Nu                                | Rezumat scurt al ceea ce face pluginul.                            |
| `minAppVersion` | Nu                                | Versiunea minimă de Theodia necesară.                                |
| `apiVersion`    | Nu                                | Versiunea de API de plugin vizată.                                  |
| `extensions`    | Obligatoriu pentru `ui` și `composite` | Array de declarații de suprafețe (vezi mai jos).                   |

### Suprafețe

Fiecare intrare `extensions` declară unde apare pluginul și ce face:

```json
{
  "surface": "home-screen",
  "config": {
    "title": "My Plugin",
    "icon": "📝",
    "screenType": "list",
    "dbTable": "Articles",
    "titleColumn": "Title"
  }
}
```

Suprafețe suportate:

- `bottom-toolbar` — intrare în fila de jos Pluginuri.
- `home-screen` — dala pe ecranul principal.
- `hamburger-menu` — element în meniul principal.
- `bible-verse-menu` — acțiune la apăsare lungă pe un verset în Cititorul biblic.
- `bible-chapter-toolbar` — acțiune în bara de unelte a capitolului în Cititorul biblic.
- `book-chapter-toolbar` — acțiune în bara de unelte a capitolului în Cititorul de cărți.
- `ai-verse-action` — acțiune IA pe un verset (necesită ca IA să fie activată).
- `ai-chapter-action` — acțiune IA pe un capitol (necesită ca IA să fie activată).
- `event` — handler de evenimente al ciclului de viață al aplicației.

### Tipuri de ecran

`screenType` în configurația unei suprafețe îi spune aplicației cum să redea ecranul pluginului:

- `list` — listă derulabilă de rânduri din baza de date.
- `data-list` — listă cu adăugare/editare/ștergere.
- `detail` — conținut de rând unic sau pasaj.
- `markdown` — fișier Markdown static redat ca HTML.
- `html` — fișier HTML static redat cu `react-native-render-html`.
- `template` — fișier HTML cu înlocuire de substituenți `{{key}}`.
- `flashcard` — UI flip-card folosind două coloane ale bazei de date.

## Distribuție

Odată ambalat ca fișier `.plugin.zip`, un plugin poate fi:

- Importat direct de un utilizator dintr-un fișier.
- Servit dintr-un depozit de catalog.

## Sfaturi

- Păstrează `plugin.json` ca JSON valid. Aplicația respinge manifestele invalide în timpul instalării.
- Folosește nume exacte de fișiere pentru toate resursele la care se face referire.
- ID-urile de plugin ar trebui să urmeze stilul domeniu inversat pentru a evita coliziunile.
- Testează conținutul pluginului offline, deoarece utilizatorii s-ar putea să nu aibă conexiune la rețea.
