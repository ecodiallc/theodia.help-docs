---
title: Activarea și configurarea pluginurilor
level: advanced
categories: plugins
summary: Cum activezi, dezactivezi și imporți pluginuri noi.
---

# Activarea și configurarea pluginurilor

Odată ce un plugin este instalat, îl poți activa, dezactiva și elimina. Acest ghid îți arată cum.

## Cum deschizi setările pluginului

1. Deschide **Setări**.
2. Atinge **Plugin-uri**.
3. Atinge **Gestionează pluginurile**.

## Cum activezi sau dezactivezi un plugin

În lista **Pluginuri instalate**, găsește pluginul dorit. Atinge comutatorul din dreapta.

- **On** — pluginul este activ.
- **Off** — pluginul este oprit.

Unele pluginuri au și un comutator on/off pe rândul **Pluginuri** de pe ecranul principal.

## Cum elimini un plugin

1. Găsește pluginul în lista **Pluginuri instalate**.
2. Atinge **Dezinstalează**.
3. Confirmă.

## Cum instalezi un plugin nou

1. Deschide setările pluginului (mai sus).
2. Atinge **Importă din fișier**.
3. Alege fișierul pluginului de pe dispozitivul tău.

Pluginul apare în lista **Pluginuri instalate**. Activează-l pentru a începe să îl folosești.

## Sfaturi

- Unele pluginuri au nevoie de internet pentru a funcționa. S-ar putea să nu funcționeze offline.
- Unele pluginuri necesită un cont sau o cheie. Pagina pluginului va explica.
- Dacă un plugin cauzează probleme, dezactivează-l. Poți folosi în continuare restul aplicației.
- Eliminarea unui plugin nu îți șterge notițele, evidențierile sau marcajele. Acestea rămân în siguranță.
