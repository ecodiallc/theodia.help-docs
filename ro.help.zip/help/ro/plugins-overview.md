---
title: Ce sunt pluginurile?
level: advanced
categories: plugins
summary: Un ghid simplu despre pluginuri și ce pot adăuga.
---

# Ce sunt pluginurile?

Un plugin este un mic add-on pentru Theodia. Pluginurile adaugă funcții noi, resurse noi sau instrumente noi. Sunt create de oameni din comunitatea Theodia.

## Ce poate face un plugin?

Pluginurile pot face multe lucruri. Câteva exemple:

- Adaugă o nouă traducere biblică.
- Adaugă un comentariu sau lexicon nou.
- Adaugă un buton în bara de unelte de jos.
- Adaugă o dală pe ecranul principal.
- Adaugă o intrare în meniul principal.
- Adaugă un instrument de studiu personalizat.

## Cum găsești pluginurile instalate

Pluginurile pot apărea în trei locuri:

- **Bara de unelte de jos** — o filă **Pluginuri** în partea de jos a ecranului.
- **Ecranul principal** — o grilă de pluginuri pe ecranul principal.
- **Meniul principal** — o intrare **Pluginuri** în meniul principal.

Unde apare un plugin depinde de ceea ce a declarat autorul în manifest. Atinge orice iconiță de plugin pentru a-l deschide.

## Formate de fișiere plugin

Theodia suportă două formate de fișiere plugin:

- **`.plugin.zip`** — o arhivă ZIP care conține `plugin.json`, baza de date a pluginului și orice resurse. Acesta este formatul recomandat. Numele fișierului arată precum `org.example.myplugin.plugin.zip`.
- **Resurse legacy de fișier unic** — fișiere mai vechi `.bible`, `.commentary`, `.lexicon`, `.book`, `.sqlite` sau `.db` care înglobează manifestul în interiorul bazei de date. Acestea încă funcționează, dar au mai puține funcții.

## Cum instalezi un plugin nou

Theodia nu are un magazin de pluginuri în interiorul aplicației. Pentru a instala un plugin:

1. Găsește un fișier plugin pe dispozitivul tău.
2. Deschide **Setări** → **Plugin-uri** → **Gestionează pluginurile**.
3. Atinge **Importă din fișier**.
4. Alege fișierul pluginului.

Pluginul apare în lista **Pluginuri instalate**. Activează-l pentru a începe să îl folosești.

## Cum activezi sau dezactivezi un plugin

În **Setări** → **Plugin-uri** → **Gestionează pluginurile**, găsește pluginul în lista **Pluginuri instalate**. Atinge comutatorul din dreapta.

- **On** — pluginul este activ.
- **Off** — pluginul este oprit.

Dezactivarea unui plugin îi ascunde funcțiile. Nu șterge pluginul.

## Cum elimini un plugin

1. Deschide **Setări** → **Plugin-uri** → **Gestionează pluginurile**.
2. Găsește pluginul în lista **Pluginuri instalate**.
3. Atinge **Dezinstalează**.
4. Confirmă.

## Ce conține un fișier `.plugin.zip`?

Un fișier `.plugin.zip` este o arhivă ZIP. Trebuie să conțină:

- `plugin.json` — manifestul pluginului.
- Baza de date a pluginului, denumită exact așa cum este declarată în manifest.

Poate conține și:

- Resurse HTML sau Markdown la care se face referire în manifest.

Manifestul declară `id`-ul, `numele`, `versiunea` pluginului și ceea ce oferă:

- `type`: `content`, `ui` sau `composite`.
- `content`: o bază de date SQLite și schema pentru conținut biblic, comentariu, lexicon, carte sau devoțional.
- `extensions`: suprafețe precum `bottom-toolbar`, `home-screen`, `hamburger-menu`, acțiuni pe verset, butoane în bara de unelte a capitolului sau handler-e de evenimente.

## Un cuvânt de precauție

Pluginurile sunt create de alte persoane, nu de echipa Theodia. Citește descrierea pluginului înainte de a-l instala. Unele pluginuri pot avea nevoie de internet sau pot colecta date.

## Dezvoltarea de pluginuri

Dacă vrei să creezi sau să editezi pluginuri în interiorul depozitului sursă Theodia, vezi ghidul [Dezvoltarea pluginurilor](theodia://help/plugin-development). Explică cum să ambalezi pluginurile cu `npm run package-plugins` și cum să le reimporți pentru editare cu `npm run import-plugin-dev`.

## Unde pot obține ajutor pentru un plugin?

Fiecare plugin are propria pagină în **Gestionează pluginurile**. Verifică acolo mai întâi. Dacă ai încă o întrebare, vezi ghidul [Unde să pui întrebări](theodia://help/getting-more-help).
