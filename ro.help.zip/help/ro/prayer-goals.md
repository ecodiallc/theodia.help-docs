---
title: Obiective de rugăciune
level: everyday
categories: [prayer]
summary: Urmărește-ți obiceiurile și obiectivele personale de rugăciune.
---

# Obiective de rugăciune

> **Mod:** Obiectivele de rugăciune sunt disponibile în modul **Standard** și **Savant**. Modul Focus ascunde instrumentele suplimentare pentru o citire fără distrageri. Poți schimba modul în **Setări** → **Mod utilizator aplicație**.

Obiectivele de rugăciune îți permit să urmărești obiceiurile care contează pentru tine — citirea unei rugăciuni fixe în fiecare dimineață, finalizarea a trei rutine de rugăciune pe zi, scrierea în jurnal înainte de culcare, petrecerea a zece minute în tăcere sau orice alt tipar alegi. Theodia îți înregistrează deja activitatea de rugăciune, așa că un obiectiv urmărește pur și simplu acea activitate și îți spune cum te descurci.

## Ce măsoară un obiectiv

Când creezi un obiectiv, alegi ce numără:

- **Rutine** — finalizează orice rutină, o rutină specifică sau o rutină care conține un anumit tip de pas, precum tăcerea sau lectio divina.
- **Intrări de jurnal** — scrie în jurnalul tău de rugăciune.
- **Minute temporizator** — petrece timp în temporizatorul de rugăciune.
- **Rugăciuni fixe** — citește o rugăciune fixă sau un crez.
- **Sesiuni ghidate** — finalizează o sesiune de rugăciune audio-ghidată.
- **Confirmare manuală** — atingi singur **Marchează făcut** când te-ai rugat.

Poți stabili și o țintă numerică și un program: zilnic, săptămânal, lunar, anumite zile ale săptămânii sau o singură dată.

## Creează un obiectiv

1. Mergi la fila **Rugăciune**.
2. Atinge **Obiective** (sau butonul **+** dacă vezi deja rândul Obiective).
3. Atinge butonul flotant **+** pentru a deschide constructorul de obiective.
4. Alege un șablon pentru a începe rapid, sau selectează **Începe de la zero**.
5. Completează detaliile: nume, icon, culoare, țintă, program și ora mementoului.
6. Atinge **Salvează obiectivul**.

Primul obiectiv creat este fixat automat pe ecranul principal al rugăciunii.

## Fixează un obiectiv pe ecranul principal

Obiectivele fixate apar în cardul **Obiectiv activ** în partea de sus a filei Rugăciune și în rândul **Obiective de rugăciune** de sub Statistici. Pentru a fixa sau defixa un obiectiv:

1. Deschide lista de obiective.
2. Găsește obiectivul dorit.
3. Atinge obiectivul, apoi atinge **Fixează pe ecranul principal**. Atinge din nou pentru **Defixează**.

Poți fixa până la două obiective. Doar obiectivele active pot fi fixate.

## Marchează un obiectiv ca făcut

Dacă un obiectiv este setat la **Confirmare manuală**, Theodia nu poate ști automat când te-ai rugat. În schimb, îl marchezi singur:

1. Deschide ecranul de detalii al obiectivului.
2. Atinge **Marchează făcut azi**.
3. Opțional adaugă o scurtă notă, apoi atinge din nou **Marchează făcut**.

Poți deschide și meniul overflow de pe cardul Obiectiv activ și atinge **Marchează făcut**.

## Citește-ți progresul

Atinge orice obiectiv pentru a deschide ecranul său de detalii. Vei vedea:

- **Progresul de azi** — cât de aproape ești de țintă chiar acum.
- **Serii** — seria actuală și cea mai lungă serie.
- **Rata de succes** — procentul de zile programate finalizate.
- **Mini calendar** — zilele verzi sunt finalizate, ziua conturată este azi.
- **Istoric recent** — ultimele două săptămâni de progres.

### Acțiuni pentru obiectiv

Din ecranul de detalii poți:

- **Fixa** sau **defixa** de pe ecranul principal.
- **Pune pe pauză** pentru a opri urmărirea o vreme (seriile îngheață).
- **Relua** pentru a începe din nou urmărirea.
- **Edita** pentru a schimba ținta, programul, mementoul sau stilul.
- **Șterge** pentru a elimina obiectivul și istoricul său.

## Insights

Ecranul **Insights** arată tendințe în toate obiectivele tale:

- Obiective îndeplinite azi, săptămâna aceasta și luna aceasta.
- Cea mai lungă serie curentă.
- Rate de finalizare săptămânale și lunare.
- Timp mediu de rugăciune (din obiectivele cu temporizator).
- Cel mai constant obiectiv.
- Distribuția tipurilor de obiective.

Deschide Insights din meniul overflow de pe lista Obiective de rugăciune.

## Scurtături de tastatură

Dacă folosești o tastatură externă:

- **Escape** — înapoi.
- **Cmd + S** (iOS) sau **Ctrl + S** (Android) — salvează un obiectiv în constructor.
- **Cmd + E** (iOS) sau **Ctrl + E** (Android) — copiază un rezumat în clipboard de pe ecranul de detalii al obiectivului sau de pe ecranul Insights.

## Memento-uri și zile de grație

Un obiectiv te poate reaminti în zilele selectate la o oră aleasă. Memento-urile folosesc notificările locale ale dispozitivului și respectă setarea principală de notificări din **Setări** → **Notificări**.

**Zilele de grație** protejează o serie când ratezi o zi. Dacă setezi zile de grație la 1 sau 2, seria ta nu se întrerupe până nu ratezi atâtea zile programate la rând.

## Sfaturi

- Începe cu un singur obiectiv. Este mai ușor să construiești un obicei când te concentrezi.
- Folosește șabloanele pentru tipare comune, apoi personalizează ținta sau programul.
- Pune obiectivul pe pauză când călătorești sau ești bolnav în loc să îl ștergi — seriile tale îngheață și se reiau când te întorci.
- Obiectivele cu confirmare manuală funcționează pentru orice Theodia nu măsoară automat, precum rugăciunea pentru o anumită persoană sau familie.
- Verifică Insights o dată pe săptămână pentru a vedea care obiective sunt cele mai ușoare și care au nevoie de atenție.
