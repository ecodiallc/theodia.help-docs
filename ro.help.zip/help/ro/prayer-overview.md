---
title: Prezentare generală a rugăciunii
level: beginner
categories: prayer
summary: O scurtă introducere a filei Rugăciune și a secțiunilor ei principale.
---

# Prezentare generală a rugăciunii

Fila **Rugăciune** este un spațiu dedicat rugăciunii. Aduce împreună liste, sesiuni ghidate, un jurnal, un temporizator, programe de lectură liturgică și rugăciuni fixe clasice.

## Secțiunile principale

- **Listă de rugăciune** — ține evidența oamenilor, situațiilor și subiectelor pentru care te rogi.
- **Jurnal** — notează reflecții, răspunsuri și gânduri de-a lungul timpului.
- **Generează rugăciune** — cere-i lui Theofil să scrie o rugăciune pornind de la o cerere sau o intrare de jurnal.
- **Crede și rugăciuni fixe** — rugăciuni clasice și crede din tradiția creștină.
- **Lectionar** — programe de citire a Scripturii pentru rugăciune zilnică sau sezonieră.
- **Rugăciune ghidată** — sesiuni de rugăciune audio-ghidate cu text-to-speech.
- **Temporizator** — sesiuni de rugăciune temporizate, cu clopote opționale.
