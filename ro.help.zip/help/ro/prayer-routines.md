---
title: Rutine
level: everyday
categories: [prayer]
summary: Construiește un obicei zilnic creând și finalizând rutine de rugăciune, citire biblică, citire devoțională, marcaje, evidențieri și multe altele.
---

# Rutine

O **rutină** este o listă ordonată de pași. Gândește-te la ea ca la un playlist pentru viața ta spirituală: poate include rugăciune, un pasaj biblic, un devoțional, o rugăciune fixă precum Rugăciunea Domnească, tăcere, reflecție, cererile tale de rugăciune, marcaje, evidențieri, imnuri și flashcarduri.

Rutinele trăiesc pe propria filă **Rutine**. Când funcția Rutine este activată, fila Rutine este vizibilă în partea de jos a aplicației.

## De ce contează rutinele

- **Obiceiuri:** O rutină transformă momentele risipite într-o singură sesiune coerentă.
- **Flexibilitate:** Poți construi rutine pentru rugăciunea de dimineață, citirea biblică de seară, închinarea în familie, jurnalul de recunoștință, recapitularea memorizării sau orice sezon.
- **Totul într-un singur loc:** Rugăciunea, Scriptura, marcajele, evidențierile și instrumentele de studiu pot curge împreună într-o singură rutină.

## Începe o rutină

1. Atinge fila **Rutine**.
2. Atinge rutina pe care vrei să o rulezi.
3. Atinge **Start** pentru a deschide executantul de rutine și a parcurge fiecare pas.

## Construiește o rutină

1. În lista **Rutine**, atinge butonul **+**.
2. Dă rutinei un nume și o descriere opțională.
3. Atinge **Adaugă pas** și alege un tip de pas:
   - **Pasaj** — citește un pasaj biblic.
   - **Rugăciune fixă** — un crez, o rugăciune sau o liturghie din bibliotecă.
   - **Cereri de rugăciune** — roagă-te pentru cererile tale active.
   - **Tăcere / Reflecție / Rugăciune liberă** — spațiu temporizat sau deschis.
   - **Sesiune ghidată** — o sesiune de rugăciune audio-ghidată.
   - **Imn** — citește sau cântă un imn.
   - **Flashcarduri** — recapitulează carduri de memorare.
   - **Devoțional** — citește o intrare devoțională.
   - **Recapitulare marcaje** — revizuiește marcajele salvate.
   - **Recapitulare evidențieri** — revizuiește versetele evidențiate.
4. Reordonează pașii atingând săgețile sus/jos de pe fiecare pas. Setează o durată sau o etichetă dacă vrei.
5. Atinge **Salvează**.

## Fixează o rutină

Rutinele fixate apar în partea de sus a listei de rutine.

1. Deschide lista **Rutine**.
2. Apasă lung pe o rutină.
3. Atinge **Fixează**.

## Adaugă ceva într-o rutină

Aproape orice în aplicație poate deveni un pas de rutină:

- **Cititorul biblic:** Atinge un verset, apoi atinge butonul **+** și alege o rutină.
- **Marcaje:** Apasă lung pe un marcaj biblic, sau atinge butonul **+**, și alege o rutină.
- **Rugăciuni fixe:** Atinge butonul **+** de pe orice rând de rugăciune fixă.
- **Cereri de rugăciune:** Atinge butonul **+** de pe un rând de cerere.
- **Evidențieri:** Alege un pas de recapitulare a evidențierilor pentru a revedea versetele marcate.

Poți insera elementul la început, la sfârșit sau după un anumit pas.

## Finalizează o rutină

Executantul de rutine te conduce prin fiecare pas. Unii pași avansează automat; alții așteaptă să atingi **Următorul**. La final vezi un ecran de sărbătoare cu opțiuni de a adăuga rutina la un playlist sau de a începe alta.

Un marcaj de bifă verde apare pe cardul rutinei pentru restul zilei pentru a arăta că a fost finalizată.

## Șterge sau editează o rutină

- **Editează:** Deschide lista de rutine, atinge o rutină, apoi atinge **Editează**.
- **Șterge:** Apasă lung pe o rutină și atinge **Șterge**. Rutinele încorporate nu pot fi șterse, dar le poți ascunde prin defixare.

## Notă de confidențialitate

Rutinele și datele lor rămân pe dispozitiv. Statisticile și insignele sunt opționale; pentru a le dezactiva, mergi la **Setări** → **Rugăciune** și opțiunile de urmărire.
