---
title: Statistici și serii de rugăciune
level: everyday
categories: prayer
summary: Cum funcționează seriile de rugăciune și cum dezactivezi statisticile și insignele.
---

# Statistici și serii de rugăciune

Ecranul **Statistici** de pe fila Rugăciune urmărește activitatea și seriile tale de rugăciune atunci când **Statistici de rugăciune** este activat în **Setări** → **Rugăciune**. Este conceput pentru a încuraja un obicei zilnic de rugăciune fără a fi intruziv.

## Ce se numără drept activitate

Următoarele sunt înregistrate ca activitate de rugăciune:

- Rutine de rugăciune finalizate
- Sesiuni ghidate finalizate
- Sesiuni cu temporizator finalizate
- Cereri de rugăciune pentru care s-a apăsat **M-am rugat**
- Rugăciuni fixe citite
- Intrări din lecționar citite
- Intrări adăugate în jurnal

Toate acestea apar în rezumatul activității tale.

## Doar rutinele extind seria

**Seria ta de rugăciune** este numărul de zile consecutive în care ai finalizat cel puțin o rutină de rugăciune.

- Finalizarea unei rutine extinde seria.
- Alte activități de rugăciune sunt urmărite, dar nu extind singure seria.
- Dacă ratezi o zi, seria se resetează la zero.
- Finalizarea mai multor rutine într-o singură zi se numără tot ca o zi de serie.

> **Sfat:** Dacă vrei să construiești sau să păstrezi o serie, fă din rutine centrul timpului tău zilnic de rugăciune.

## Ce arată ecranul Statistici

- **Seria curentă** — zile consecutive cu o rutină finalizată.
- **Cea mai lungă serie** — cea mai bună serie de până acum.
- **Rezumat activitate** — totaluri pentru săptămâna aceasta, luna aceasta și tot timpul.
- **Calendar** — o vizualizare lună cu lună a zilelor cu activitate de rugăciune.

## Insigne

Când **Arată insignele de rugăciune** este activat, poți câștiga realizări ascunse pentru reperele de rugăciune. Insignele sunt o funcție ușoară de tip ou de Paște, nu o obligație.

Insignele necesită ca Statistici de rugăciune să fie activate. Dacă statisticile sunt oprite, insignele sunt ascunse.

## Cum dezactivezi statisticile și insignele

Poți opri aceste funcții oricând:

1. Deschide **Setări** → **Rugăciune**.
2. Dezactivează comutatorul **Activează statisticile de rugăciune**.
3. Dezactivează comutatorul **Arată insignele de rugăciune**.

Când statisticile sunt dezactivate:

- Seriile nu mai sunt numărate.
- Secțiunea Statistici dispare de pe fila Rugăciune.
- Insignele sunt ascunse.
- Datele de rugăciune existente rămân pe dispozitiv; nu se șterge nimic.

Pentru a reactiva statisticile mai târziu, activează pur și simplu comutatorul din nou.
