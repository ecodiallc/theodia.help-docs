---
title: Cărțile încorporate
level: beginner
categories: [content, read]
summary: Cum citești clasicele creștine care vin cu aplicația.
---

# Cărțile încorporate

Theodia vine cu o mică bibliotecă de cărți creștine. Acestea sunt clasice pe care le poți citi pe dispozitiv.

## Cum deschizi biblioteca

Atinge fila **Cărți** din partea de jos a ecranului. Vezi o listă cu cărțile din biblioteca ta.

## Cum citești o carte

1. Atinge titlul cărții.
2. Cartea se deschide la primul capitol.
3. Folosește butoanele **Anterior** și **Următorul** din partea de sus pentru a te mișca între capitole.

## Cum sari la un capitol

Atinge numele capitolului din partea de sus a ecranului. Apare o listă de capitole. Alege un capitol pentru a sări la el.

## Cum schimbi mărimea fontului

Deschide **Setări** → **Aspect** și alege o dimensiune a fontului. Mărimea textului se schimbă în toată aplicația, inclusiv în cărți.

## Cum adaugi un marcaj într-o carte

Atinge pictograma **stea** din dreapta sus. Capitolul curent este salvat. Atinge fila **Marcaje** pentru a vedea paginile salvate.

## Cum asculți o carte

Atinge pictograma **Difuzor** din dreapta sus. Aplicația citește capitolul cu voce tare. Atinge-o din nou pentru a opri.

## Ce cărți sunt disponibile?

Biblioteca conține clasice precum:

- Pilgrim's Progress
- The Imitation of Christ
- Practice of the Presence of God
- The Hymn Book

Lista de cărți poate crește în timp. Actualizările aplicației pot adăuga mai multe.

## Sfaturi

- Cărțile sunt stocate pe dispozitiv. Nu este nevoie de internet.
- Cărțile nu se sincronizează în cloud.
