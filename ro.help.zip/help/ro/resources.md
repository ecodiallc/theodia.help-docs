---
title: Găsirea de resurse pe GitHub
level: everyday
categories: resources
summary: Caută dintr-o dată în toate repository-urile GitHub cunoscute de aplicație, apoi instalează ce găsești.
---

# Găsirea de resurse pe GitHub

Theodia păstrează o listă de repository-uri GitHub care publică resurse — Biblii, comentarii, cărți, devoționale, playlisturi, pachete de rugăciuni și multe altele. **Caută în repository-urile GitHub** le caută pe toate dintr-o dată, ca să nu trebuiască să deschizi fiecare filă și să răsfoiești separat.

> Secțiunea GitHub din Setări este disponibilă doar în **modul Savant**. Pentru a o activa, mergi la **Setări → Mod utilizator → Savant**.

## Cum cauți

1. Deschide **Setări**.
2. Atinge **Caută în repository-urile GitHub**.
3. Scrie un cuvânt în căsuța de căutare. Aplicația caută acel cuvânt în **numele** și în **descrierea** fiecărei resurse din fiecare repository.

Câteva lucruri de știut despre căutare:

- **Fiecare cuvânt trebuie să se potrivească.** Căutarea `morning evening` găsește doar resursele ale căror nume sau descriere conține *ambele* cuvinte.
- **Majusculele nu contează.** `Morning` și `morning` găsesc aceleași resurse.
- **Cea mai bună potrivire vine prima.** O resursă al cărei nume *începe* cu căutarea ta este arătată înaintea uneia care o menționează doar în descriere.

## Filtrarea

Atinge bara de filtre de deasupra rezultatelor pentru a restrânge și mai mult lista. Există două filtre și funcționează împreună:

- **Autor** — doar resursele acelui autor.
- **Tradiție** — doar resursele acelei tradiții.

Atinge din nou un filtru pentru a-l șterge, sau atinge **Golește filtrele** pentru a le reseta pe ambele.

## Instalarea dintr-un rezultat

Fiecare rezultat arată numele resursei, ce fel de resursă este, cine a făcut-o și din ce repository provine. În dreapta rândului este un singur buton:

- **Instalează** — resursa nu este încă pe dispozitivul tău.
- **Actualizează** — este disponibilă o versiune mai nouă. Aplicația îți cere mai întâi confirmarea, pentru că actualizarea șterge vechea copie împreună cu orice notițe, evidențieri sau marcaje care arată spre ea.
- **Deschide** — resursa este deja instalată; atingerea ei te duce pe ecranul unde o folosești.

Atinge **Reîmprospătează** sus pentru a aduce imediat lista cea mai recentă de pe GitHub. Aplicația reîmprospătează lista singură o dată pe zi, deci o reîmprospătare manuală e necesară doar când știi că a fost publicat ceva nou.

## Căutarea fără conexiune

Aplicația păstrează o copie a listei pe dispozitivul tău, deci căutarea funcționează chiar și când ești offline. Dacă aplicația nu poate ajunge la GitHub pentru a reîmprospăta lista, un banner sus îți spune că vezi rezultatele din cache.

## Dacă o căutare nu găsește nimic

- Încearcă un cuvânt singur, mai scurt.
- Verifică să nu fie încă aplicat un filtru **Autor** sau **Tradiție** — butonul **Golește filtrele** apare ori de câte ori unul este.
- Unele repository-uri își publică resursele într-o altă limbă decât numele resursei, deci căutarea unui cuvânt tradus poate să nu le găsească.
