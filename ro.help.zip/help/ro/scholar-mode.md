---
title: Modul Savant
level: advanced
categories: [layout, read, study]
summary: Cel mai profund mod de studiu din Theodia, care deblochează comentarii, lexicoane, referințe încrucișate, instrumente IA și Meniul rapid.
---

# Modul Savant

> **Mod:** Modul Savant este disponibil doar când modul tău de utilizator este setat la **Savant**. Schimbă modurile în **Setări** → **Mod utilizator aplicație**.

Modul Savant deblochează toate instrumentele de studiu din Theodia. Este construit pe baza Modului de studiu, deci ai în continuare meniul versetului, Biblia paralelă, marcajele, evidențierile și notele — plus instrumentele avansate listate mai jos.

## Cum deschizi Modul Savant

Modul Savant nu este un ecran separat. Este un set de instrumente suplimentare care apar în cititorul și navigarea existente când modul tău de utilizator este setat la Savant.

1. Deschide **Setări**.
2. Atinge **Mod utilizator aplicație**.
3. Alege **Savant**.

Schimbarea are efect imediat. Meniurile și butoanele care erau ascunse apar acum.

## Instrumente suplimentare în cititor

Când deschizi un capitol în [Modul de studiu](theodia://help/study-mode), Modul Savant adaugă aceste instrumente în meniul versetului:

- **Comentariu IA** (◈) — cere asistentului IA să scrie o notă de studiu pentru acest verset. (Nu este disponibil în toate regiunile.)
- **Informații cuvânt** (?) — deschide o intrare de lexicon pentru cuvântul original ebraic sau greacă din spatele versetului. Vezi ghidul [Comentarii și lexicoane](theodia://help/commentaries-and-lexicons).
- **Dicționar** (📖) — caută cuvinte biblice generale în resursele de dicționar pe care le-ai instalat. Vezi ghidul [Dicționarul biblic](theodia://help/dictionary).

Aceste instrumente au nevoie de resurse instalate (comentarii, lexicoane, fișiere de dicționar). Dacă un instrument este cenușiu sau arată „nu a fost găsit", deschide **Setări** → **Gestionează resursele** și adaugă resursa de care are nevoie.

## Navigare suplimentară

### Filă suplimentară în bara de jos

Bara de jos primește o filă în plus:

- 💻 **IA** — deschide asistentul IA (doar dacă ai activat IA în Setări). Această filă se află în dreapta Note biblice.

### Elemente suplimentare în meniul principal

Meniul principal include o intrare **Asistent IA** în aceleași condiții.

## Meniu rapid

Modul Savant activează **Meniu rapid**, o cale rapidă de a sări la versete recente, a rula comenzi și a comuta aspectele cititorului fără a părăsi ecranul curent. Vezi ghidul [Meniul rapid](theodia://help/launcher-menu) pentru cum să îl folosești.

## Când să folosești Modul Savant

- Vrei asistentul IA, comentariile sau căutările în limba originală în timp ce citești.
- Vrei Meniul rapid pentru navigare rapidă la versete și chat IA.
- Studiezi un pasaj în profunzime și ai nevoie de toate instrumentele la un atingere distanță.

## Trecerea la un mod mai ușor

Dacă vrei un cititor mai simplu fără instrumentele avansate, treci la modul **Standard** în **Setări** → **Mod utilizator aplicație**. Modul Standard păstrează marcajele, evidențierile, notele și Modul de studiu, dar ascunde IA, comentariile, lexicoanele și Meniul rapid.

Dacă vrei cea mai curată experiență de citire, deschide un capitol în [Mod focus](theodia://help/focus-mode).

Marcajele, evidențierile și notele tale nu sunt niciodată șterse când schimbi modul; sunt doar ascunse până când revii la un mod care le suportă.

## Ajutor și întrebări

Dacă un instrument lipsește sau arată o eroare, vezi ghidul [Probleme comune](theodia://help/common-problems). Dacă ești nou în Theodia, ghidul [Citești primul capitol](theodia://help/first-read) te însoțește pas cu pas prin elementele de bază.
