---
title: Căutarea în Biblie
level: everyday
categories: [study, read]
summary: Cum găsești versete după cuvânt, expresie sau referință.
---

# Căutarea în Biblie

Bara de căutare te ajută să găsești versete rapid. Poți căuta după un cuvânt, o expresie sau o referință biblică.

## Cum începi o căutare

1. Atinge fila **Caută** din partea de jos a ecranului.
2. Tastează ceea ce vrei să găsești.
3. Atinge **Caută** pe tastatură.

Rezultatele apar ca o listă de versete. Fiecare rezultat arată cartea, capitolul și versetul, plus textul versetului.

## Căutare prin combinații de cuvinte

Când tastezi mai mult de un cuvânt, cum ar fi `dragoste bucurie`, aplicația găsește versete care conțin **ambele** cuvinte. Aceasta este o căutare **ȘI** — toate cuvintele trebuie să apară în verset. Nu folosește logică **SAU** (versete cu un singur cuvânt).

Pentru a căuta versete care conțin oricare dintre cuvinte, folosește explicit cuvântul-cheie `OR`: `dragoste OR bucurie`.

## Căutare după cuvânt

Tastează un singur cuvânt, cum ar fi `dragoste` sau `îndurare`. Aplicația îți arată fiecare verset din Biblie care conține acel cuvânt.

## Căutare după expresie

Tastează două sau trei cuvinte între ghilimele, cum ar fi `"nu vă temeți"`. Aplicația îți arată versetele care conțin exact acea expresie.

## Filtrează rezultatele

După o căutare, rezultatele sunt filtrate la traducerile biblice pe care le ai instalate. Pentru a restrânge mai mult, deschide fila **Biblia** și uită-te la o traducere specifică — căutările rulează împotriva traducerilor pe care le ai.

## Sfaturi pentru căutări mai bune

- Folosește cuvinte scurte. Căutarea după `dragoste` găsește mai multe versete decât căutarea după `iubind`.
- Ghilimelele în jurul unei expresii fac căutarea exactă.
- Aplicația caută doar în traducerile biblice pe care le-ai instalat.
- Pentru a sări la un verset anume după referință (de exemplu, `Ioan 3:16`), folosește caseta **Comandă rapidă** de pe ecranul principal în locul filei Caută.

## Istoricul căutărilor

Aplicația își amintește căutările tale recente. Când deschizi fila **Caută**, lista arată căutările recente în partea de sus. Atinge una pentru a o rula din nou. Pentru a șterge lista, atinge **Șterge tot** în partea de sus a căutărilor recente.
