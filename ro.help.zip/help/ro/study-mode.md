---
title: Mod de studiu
level: everyday
categories: [layout, read]
summary: Cititorul biblic complet din Theodia, cu instrumente de studiu precum comentarii, referințe încrucișate, lexicon și note.
---

# Mod de studiu

> **Mod:** Modul de studiu este disponibil în modurile **Standard** și **Savant**. Modul Cititor deschide capitolele în Mod focus. Poți schimba modurile în **Setări** → **Mod utilizator aplicație**.

Modul de studiu este cititorul biblic principal din Theodia. Are toate instrumentele de studiu încorporate: comentarii, referințe încrucișate, căutări de cuvinte, traduceri paralele, note și multe altele.

Modul focus este un cititor mai simplu, fără instrumente de studiu. Vezi ghidul [Mod focus](theodia://help/focus-mode) dacă vrei doar text curat. Acest ghid este pentru Modul de studiu.

## Cum deschizi Modul de studiu

Sunt câteva căi de a deschide un capitol în Modul de studiu:

- Atinge fila **Biblia** din partea de jos a ecranului. Alege o traducere, o carte și un capitol.
- Atinge un verset în rezultatele **Căutare**.
- Atinge un marcaj din fila **Marcaje**.
- Din Modul focus, atinge butonul 📖 din partea de sus a ecranului pentru a trece în Modul de studiu.

## Citirea capitolului

Capitolul se deschide cu versetele listate în ordine. În partea de sus a ecranului sunt butoane pentru acțiunile cele mai comune. În partea de jos a ecranului este o bară de stare.

- **Glisează la stânga** pentru a merge la capitolul următor.
- **Glisează la dreapta** pentru a merge la capitolul anterior.
- **Atinge un verset** pentru a deschide meniul versetului cu instrumente de studiu (vezi mai jos).
- **Atinge un număr Strong într-un verset** (de exemplu, G1234 sau H1234) pentru a deschide o căutare rapidă în lexicon pentru acel cuvânt.

Dacă ai activată o traducere paralelă, o a doua copie a capitolului apare sub cea principală, în traducerea aleasă. Vezi **Citirea a două traduceri simultan** mai jos.

## Meniul versetului

Când atingi un verset, se deschide un meniu cu titlul „Carte Capitol:Verset". Instrumentele pe care le vezi depind de modul tău de utilizare.

### Instrumente în modurile Standard și Savant

- **Marcaj** (★) — salvează versetul pentru a-l găsi din nou. Atinge-l din nou pentru a elimina marcajul. Prima atingere îl adaugă. Vezi ghidul [Salvarea versetelor ca marcaje](theodia://help/bookmarks).
- **Evidențiază** (□) — colorează versetul ca să iasă în evidență. Atinge-l pentru a deschide selectorul de culori. Atinge aceeași culoare din nou pentru a elimina evidențierea. Vezi ghidul [Evidențierea versetelor](theodia://help/highlights).
- **Citește** (🔊) — citește versetul cu voce tare folosind vocea text-to-speech a dispozitivului. Nu este arătat pentru Biblia interlineară. Vezi ghidul [Citirea cu voce tare](theodia://help/tts) pentru cum să îl folosești și cum să alegi o voce.
- **Copiază** (⎘) — pune textul versetului în clipboard, ca să îl poți lipi oriunde.
- **Compară** (⇄) — deschide un panou care arată același verset în fiecare traducere pe care o ai instalată. Atinge o traducere în panou pentru a citi versetul în acea traducere. Vezi ghidul [Compararea traducerilor](theodia://help/compare-translations).
- **Referințe încrucișate** (↗) — deschide o listă de versete înrudite din baza de date de referințe încrucișate. Vezi ghidul [Referințe încrucișate](theodia://help/cross-references).
- **Adaugă/Editează notă biblică** (✎) — scrie propria ta notă privată atașată versetului. Vezi ghidul [Scrierea de note](theodia://help/notes).

### Instrumente doar în modul Savant

- **Comentariu IA** (◈) — cere asistentului IA să scrie o notă de studiu pentru acest verset. (Nu este disponibil în toate regiunile.)
- **Informații cuvânt** (?) — deschide o intrare de lexicon pentru cuvântul original ebraic sau greacă din spatele versetului. Vezi ghidul [Comentarii și lexicoane](theodia://help/commentaries-and-lexicons).
- **Dicționar** (📖) — caută cuvinte biblice generale în resursele de dicționar pe care le-ai instalat. Vezi ghidul [Dicționarul biblic](theodia://help/dictionary).

Unele instrumente necesită resurse suplimentare instalate. Dacă un instrument este cenușiu sau arată „nu a fost găsit", deschide **Setări** → **Gestionează resursele** și adaugă resursa de care are nevoie.

## Butoanele din partea de sus a ecranului

Deasupra textului capitolului este un rând de pictograme. Acestea sunt acțiunile rapide:

- **Versiunea biblică** — atinge numele traducerii (de exemplu, „KJV") pentru a trece la o altă traducere.
- **Carte** — atinge numele cărții pentru a sări la o altă carte.
- **Capitol** — atinge numărul capitolului pentru a sări la un alt capitol.
- **Deschide în IA** (🤖) — trimite capitolul curent asistentului IA cu întrebarea ta. (Doar modul Savant.)
- **Mod focus** (📖) — treci în Mod focus pentru citire curată.
- **Bibilii paralele** (🔵 / ⚪) — atinge pentru a activa sau dezactiva traducerile paralele. Când este activat, același capitol este arătat în traducerile paralele alese sub textul principal. Când este dezactivat, este arătată doar traducerea principală. Vezi **Citirea mai multor traduceri simultan** mai jos.
- **Ascultă** — citește întreg capitolul cu voce tare. Vezi ghidul [Citirea cu voce tare](theodia://help/tts).
- **Mai multe** — deschide acțiuni suplimentare pentru capitol (notă biblică de capitol, comentariu de capitol, partajează etc.).

## Citirea mai multor traduceri simultan

Poți arăta până la patru traduceri suplimentare alături de cea principală. Aceasta se numește **vizualizare paralelă**.

1. Deschide **Setări**.
2. Activează **Biblie paralelă**.
3. Atinge **Adaugă Biblie paralelă** și alege o traducere.
4. Repetă pentru a adăuga mai multe. Poți avea până la patru traduceri paralele.

Când vizualizarea paralelă este activată, fiecare verset din capitol arată mai întâi traducerea ta principală, urmată de același verset în fiecare traducere paralelă. Acest lucru face ușor să compari cum tratează diferiți traducători un verset dificil, fără să părăsești capitolul.

Poți salva configurația curentă de traduceri paralele ca **presetare**. Atinge butonul de salvare lângă traducerile selectate, dă-i un nume, iar ea devine o opțiune de comutare rapidă. Atinge orice presetare mai târziu pentru a încărca instantaneu acea combinație. Apasă lung pe o presetare pentru a o șterge.

Poți compara și un singur verset odată cu instrumentul **Compară** (⇄) din meniul versetului. Acesta deschide un panou care arată versetul în fiecare traducere instalată.

## Subtitlurile

Unele traduceri au subtitluri de secțiune încorporate (de exemplu, „Predica de pe munte"). Dacă traducerea ta le are, le poți arăta sau ascunde cu setarea **Arată subtitluri** în **Setări**. Subtitlurile apar ca titluri mici cenușii între versete.

## Nota capitolului

O notă de capitol este o singură notă atașată întregului capitol, nu unui singur verset. Este utilă pentru un gând mare despre capitol.

Pentru a deschide nota capitolului:

1. Atinge butonul **Mai multe** din partea de sus a ecranului.
2. Atinge **Notă capitol biblic**.
3. Scrie nota. Atinge **Salvează**.

Nota capitolului este salvată cu capitolul. Apare ori de câte ori deschizi acel capitol.

## Evidențierea căutărilor

Dacă ai ajuns la capitol dintr-o căutare, cuvintele tale de căutare sunt evidențiate în galben în textul versetului. Acest lucru face ușor să vezi de ce un verset s-a potrivit.

Poți rula din nou o căutare pe un capitol pe care îl citești. Deschide fila **Caută** și introdu un cuvânt. Rezultatele îți permit să atingi direct înapoi în capitol, cu potrivirile evidențiate.

Biblile interlineare (MIB — Marvel Interlinear Bible — și OHGB) se deschid întotdeauna în Modul de studiu, deoarece au nevoie de aranjarea la nivel de cuvânt.

## Trecerea în Mod focus pentru un singur capitol

Din orice capitol în Modul de studiu, atinge butonul 📖 din partea de sus. Același capitol se deschide în Mod focus, cu toate meniurile ascunse. Atinge butonul 📖 din bara de jos pentru a reveni la Modul de studiu.

## Când să folosești Modul de studiu

Modul de studiu este alegerea potrivită când vrei să:

- **Citești și studiezi în același timp.** Toate instrumentele sunt la un atingere distanță.
- **Cauți un cuvânt pe care nu îl știi.** Atinge un număr Strong în verset pentru o intrare rapidă în lexicon.
- **Compari traduceri.** Folosește instrumentul Compară din meniul versetului sau activează vizualizarea paralelă.
- **Vezi cum se leagă un verset de restul Bibliei.** Folosește Referințe încrucișate.
- **Iei notițe în timp ce citești.** Meniul versetului are o opțiune rapidă „Adaugă notă".

Pentru citire lungă și fără distrageri, treci în Mod focus.

## Trecerea în Mod focus

Din orice capitol în Modul de studiu, atinge butonul 📖 din partea de sus. Același capitol se deschide în [Mod focus](theodia://help/focus-mode), cu meniurile și instrumentele de studiu ascunse. Atinge butonul 📖 din bara de jos pentru a reveni la Modul de studiu. Pentru o descriere completă a ceea ce face Modul focus, vezi ghidul [Mod focus](theodia://help/focus-mode).

## Ajutor și întrebări

Dacă un instrument lipsește sau arată o eroare, vezi ghidul [Probleme comune](theodia://help/common-problems). Dacă ești nou în Theodia, ghidul [Citești primul capitol](theodia://help/first-read) te însoțește pas cu pas prin elementele de bază.
