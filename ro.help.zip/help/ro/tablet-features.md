---
title: Funcții pentru tabletă
level: everyday
categories: [layout, tablet]
summary: Cum se adaptează aspectul Theodia la tablete și ecrane mari, cu vizualizări divizate, panouri laterale și moduri de citire în două panouri.
---

# 📱 Funcții pentru tabletă

Theodia este concepută pentru a profita de ecranele mai mari ale tabletelor. Pe o tabletă (sau orice dispozitiv mai lat de aproximativ 700 de pixeli), aplicația comută automat la un aspect cu două coloane în multe locuri.

> **Mod:** Funcțiile descrise aici apar doar dacă modul tău de utilizator curent le suportă. De exemplu, panourile laterale de comentarii și chatul IA sunt disponibile doar în modul Savant. Vizualizările divizate pentru marcaje, evidențieri și note necesită modurile Standard sau Savant. Modul focus arată doar citire curată pe o singură coloană. Poți schimba modurile în **Setări** → **Mod utilizator aplicație**.

## Meniul versetului în cititor

Când atingi un număr de verset (sau apeși lung pe textul versetului), **meniul versetului** apare ca o **carte centrată** peste un fundal întunecat.

- Butoanele **Copiază** și **Partajează** sunt întotdeauna vizibile în partea de sus a meniului.
- **Marcajele** și **Evidențierile** sunt arătate cu starea lor curentă.
- **Comentariul**, **Dicționarul** și **Compară** se deschid din meniu. Pe tabletă, aceste instrumente pot apărea într-un panou lateral sau într-o carte largă odată selectate.
- Atinge fundalul sau săgeata de închidere pentru a respinge meniul.

## Panoul de comentariu pe verset

Instrumentul **Comentariu** deschide un **panou lateral dedicat** pe tabletă:

- Textul comentariului apare lângă textul biblic.
- Poți derula comentariul independent de Biblie.
- Atinge **X** sau glisează departe pentru a închide.
- O **pictogramă de carte** în partea de sus a panoului îți permite să comuți sursele de comentarii.
- O **pictogramă de capitol** îți permite să vezi comentariul la nivel de capitol.

Pe telefon, comentariul se deschide ca un modal pe tot ecranul.

## Comentariul de capitol

**Comentariul de capitol** este accesat din butonul **Mai multe** din partea de sus a ecranului, nu din meniul versetului. Pe tabletă se deschide ca un panou lateral, la fel ca și Comentariul pe verset, deci poți citi comentariul și textul biblic împreună.

## Fila Compară

Fila **Compară** (în meniul versetului) se deschide ca un **panou lateral** pe tabletă. Arată versetul selectat în fiecare versiune paralelă pe care ai activat-o. Poți atinge orice versiune pentru a sări la acel pasaj în cititor.

## Popup Dicționar / Strong

Instrumentul **Dicționar** (meniul versetului → Dicționar) se deschide ca o carte largă pe tabletă. Arată cuvântul grecesc sau ebraic, transliterarea lui, definiția și numărul Strong. Atinge butonul **Concordanță** pentru a vedea fiecare apariție a acelui cuvânt în Biblie.

## Atinge un cuvânt pentru a deschide lexiconul

În panoul lateral **Informații cuvânt** pe tabletă, fiecare card de cuvânt care are un număr Strong este atingibil. Atinge cardul pentru a deschide panoul **Lexicon** pentru acel cuvânt direct. Panoul Lexicon înlocuiește panoul Informații cuvânt, ca să poți continua să studiezi fără să închizi cititorul.

Pe telefon, cardurile Informații cuvânt nu sunt atingibile, deoarece ecranul este prea mic pentru două panouri.

## Biblia paralelă una lângă alta

În Setări, atinge **Biblia paralelă** și alege până la trei versiuni. Pe tabletă, versiunile apar ca **panouri verticale** una lângă alta:

- Fiecare panou derulează independent.
- Poți atinge un număr de verset pentru a deschide un panou cu instrumente.
- Fila **Compară** arată toate versetele selectate într-un singur loc.
- Atinge **X** pe orice panou pentru a-l închide și a reveni la vizualizarea pe o singură coloană.
- Atinge pictograma **Biblia paralelă** (🔵 / ⚪) din bara de pictograme de sus pentru a activa sau dezactiva vizualizarea paralelă fără a deschide Setări.

Pe telefon, versiunile paralele sunt arătate una sub alta (vertical) în loc de una lângă alta. Aceeași pictogramă de comutare funcționează și pe telefon.

## Vizualizare divizată pentru marcaje și evidențieri

Pe tabletă, filele **Marcaje** și **Repere** folosesc un aspect stăpân-detaliu:

- **Partea stângă** — lista de marcaje sau evidențieri.
- **Partea dreaptă** — atingerea unui element deschide un panou de previzualizare cu textul versetului sau pasajului.

Poți răsfoi elementele salvate și să le previzualizezi fără a părăsi fila. Pe telefon, atingerea unui element navighează la ecranul cititorului.

## Vizualizare divizată pentru note

Fila **Note biblice** pe tabletă arată lista de note în stânga și nota selectată în dreapta. Atingerea unei note o deschide într-un panou lateral, ca să poți răsfoi mai multe note la rând fără a părăsi lista. Crearea sau editarea unei note folosește și ea un panou lateral.

## Vizualizare divizată pentru căutare

Pe tabletă, fila **Caută** arată formularul de căutare în stânga și rezultatele în dreapta imediat ce rulezi o căutare. Poți rafina interogarea și vezi cum se actualizează rezultatele fără a schimba ecranele. Pe telefon, rezultatele căutării se deschid pe un ecran separat.

## Bară laterală de categorii în Setări

Ecranul **Setări** pe tabletă arată o listă de categorii în stânga (IA, Aspect, Backup, Biblii etc.). Atinge o categorie pentru a sări direct la setările ei în dreapta. Doar categoria selectată este extinsă, deci nu trebuie să derulezi prin întreaga listă de setări.

## Navigarea biblică pe tablete

Ecranele **Lista de Biblii**, **Cărțile Bibliei** și **Capitolele Bibliei** rămân pe o singură coloană pe tablete, dar folosesc ținte de atingere mai mari, grile mai late și padding mai generos, așa că conținutul este mai ușor de citit și atins. Nu folosesc aspect divizat, deoarece fiecare pas are nevoie de lățimea completă pentru a-și arăta lista sau grila clar.

## Peisaj și portret

Rotirea tabletei ajustează aspectul automat. În **peisaj**, panourile laterale au mult spațiu. În **portret**, panourile devin mai înguste, dar rămân lângă text.

## Chat IA pentru versetul selectat

**Chatul IA** se deschide în panoul lateral al meniului versetului. Afișează o interfață de conversație unde poți pune întrebări despre versetul selectat. Răspunsul IA apare în panou, iar tu poți continua conversația fără a părăsi cititorul.

## Bară laterală de conversație în ecranul IA

În fila **IA** pe tabletă, lista de conversații este întotdeauna vizibilă ca o bară laterală stângă persistentă. Poți comuta între chat-uri fără a deschide un meniu. Butonul **Chat nou** este de asemenea mereu vizibil. Pe telefon, lista de conversații este un sertar pop-up.

## Ce rămâne la fel

Nu fiecare ecran se împarte în două panouri. Următoarele ecrane rămân pe o singură coloană pe tablete:

- **Lista de Biblii** — lista de versiuni biblice (lățime completă)
- **Cărțile Bibliei** — grila de cărți și secțiuni (lățime completă)
- **Capitolele Bibliei** — grila de capitole (lățime completă)
- **Setări** — paginile individuale de setări (lățime completă)
- **Ajutor** — articolele de ajutor (lățime completă)

## Rezumat

Pe tabletă, ai:

- **Biblia paralelă** în panouri verticale una lângă alta
- **Comentariu** în panouri laterale persistente
- **Compară** și **Dicționar** în cărți largi
- **Lexicon** dintr-o atingere pe orice card Informații cuvânt
- **Marcaje, Repere, Note, Devoționale, Cărți, Setări** în vizualizări stăpân-detaliu
- **Caută** cu rezultate inline lângă formularul de căutare
- **Peisaj** și **portret** ambele suportate, cu schimbări automate de aspect

Pe telefon, totul folosește navigarea tradițională pe o singură coloană. Aplicația detectează lățimea ecranului la lansare și alege automat aspectul potrivit.
