---
title: Schimbarea temelor și fonturilor
level: everyday
categories: settings
summary: Cum schimbi aspectul aplicației.
---

# Schimbarea temelor și fonturilor

Theodia îți permite să schimbi modul în care arată aplicația. Poți alege o temă (deschisă sau întunecată) și o mărime a fontului.

## Cum deschizi setările de aspect

1. Deschide **Setări**.
2. Atinge **Aspect**.

## Cum schimbi tema

În secțiunea **Aspect** vezi două butoane de temă:

- **Implicită** — fundal deschis cu text închis. Bun pentru ziua.
- **Întunecată** — fundal închis cu text deschis. Bun pentru noapte și economisește baterie.

Atinge o temă pentru a o aplica. Schimbarea este instantanee.

## Cum schimbi mărimea fontului

În secțiunea **Aspect**, atinge unul dintre butoanele de mărime: **---**, **--**, **-**, **Normal**, **+**, **++**, **+++**. Textul devine mai mic sau mai mare în toată aplicația. Alege mărimea care este cea mai ușor de citit pentru tine.

## Sfaturi

- Tema întunecată economisește bateria pe telefoanele cu ecran OLED.
- Dacă textul este prea mic pentru a fi citit, mărește fontul în aplicație, nu pe dispozitiv. Setarea aplicației este mai fină.
- Pentru citire lungă, încearcă tema întunecată și un font mai mare.
- [Activează tema deșert](theodia://unlock-desert)
