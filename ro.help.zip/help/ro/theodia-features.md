---
title: Funcțiile Theodia
level: beginner
categories: welcome
summary: O prezentare rapidă a ceea ce face Theodia special și cum te ajută să studiezi Biblia.
---

# Funcțiile Theodia

Theodia este construită pentru a fi un însoțitor complet de studiu biblic. Iată ce o face remarcabilă.

## Offline mai întâi

Totul funcționează fără internet. Biblia, comentariile, lexicoanele, cărțile și devoționalele sunt stocate pe dispozitiv. Poți citi, căuta și studia oriunde — în avion, într-o zonă îndepărtată sau oriunde nu există semnal.

## Axată pe confidențialitate

Datele tale rămân la tine. Notițele, evidențierile, marcajele și istoricul de citire sunt stocate local pe dispozitiv. Nu este nevoie de cont, iar nimic nu este trimis către un server decât dacă alegi să folosești opțional asistentul IA.

## Suport pentru tabletă

Theodia este concepută atât pentru telefoane, cât și pentru tablete. Pe un ecran mai mare, ai mai mult spațiu pentru citire, vizualizări paralele ale Bibliei și un aspect care profită de spațiul suplimentar.

## Resurse instalabile

Nu ești limitat la ceea ce vine cu aplicația. Poți adăuga mai multe versiuni ale Bibliei, comentarii, lexicoane, cărți și devoționale. Resursele sunt disponibile pe pagina de GitHub a proiectului și pot fi instalate direct în aplicație.

## Asistent IA

Asistentul IA opțional te ajută să înțelegi versete, să explici contextul și să răspunzi la întrebări. Este activ doar dacă îl activezi. Implicit se conectează la un model la distanță pe care îl furnizezi printr-un endpoint și o cheie API pe care le configurezi. Prima dată când folosești IA, aplicația îți cere permisiunea și îți arată exact ce este trimis.

## Citire paralelă a Bibliei

Citește până la patru versiuni ale Bibliei simultan. Când deschizi un capitol, traducerea ta principală apare prima, iar fiecare verset este urmat de același verset în traducerile paralele alese. Compară formulările, studiază diferențele și obține o imagine mai completă a textului. Salvează combinațiile tale favorite ca presetări și comută rapid între ele.

## Căutare full-text

Caută în orice versiune a Bibliei. Caută cuvinte, expresii sau potriviri parțiale. Poți limita căutarea și la un interval de cărți.

## Referințe încrucișate

Atinge o referință de verset pentru a sări direct la acel pasaj. Referințele încrucișate sunt încorporate și funcționează în întreaga Biblie.

## Lexicon și numere Strong

Atinge un număr Strong pentru a vedea definiția originală în greacă sau ebraică. Intrările de lexicon sunt incluse pentru studii mai aprofundate ale cuvintelor.

## Marcaje și evidențieri

Salvează versete cu marcaje și marchează-le cu culori. Totul este stocat local și persistă între sesiuni.

## Note

Scrie-ți gândurile lângă orice verset. Notițele sunt legate de verset și ușor de găsit mai târziu.

## Devoțional zilnic

Începe-ți ziua cu o scurtă citire devoțională. Aplicația include devoționale care se deschid automat la intrarea de azi.

## Cărți creștine

Citește literatură creștină clasică în interiorul aplicației. Cărțile sunt formatate pentru citire ușoară și includ un cuprins pentru navigare rapidă.

## Citirea PDF-urilor

Importă propriile documente PDF și citește-le offline, organizate în categorii. Cititorul suportă căutare, cuprins, marcaje, zoom și citire cu voce tare. Poți de asemenea instala colecții de PDF-uri ambalate din repository-ul comunității.

## Mai multe limbi

Theodia suportă multe limbi atât pentru interfața aplicației, cât și pentru conținutul biblic. Schimbă limba în setări pentru a studia în limba preferată.

## Mod întunecat și teme

Alege între modul deschis sau întunecat, sau alege o temă care ți se potrivește. Confortul la citire contează, mai ales în lumină slabă.

## Backup de date

Fă backup notițelor, marcajelor și evidențierilor tale. Păstrează-ți datele în siguranță și mută-le pe un dispozitiv nou când este nevoie.

## Fără reclame, fără distrageri

Theodia este construită pentru focus. Nu există reclame, pop-up-uri sau întreruperi. Doar textul și instrumentele tale de studiu.
