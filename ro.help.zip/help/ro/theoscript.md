---
title: Theoscripturi
level: everyday
categories: theoscript
summary: Automatizează citirea Bibliei, vorbirea, marcajele și multe altele cu comenzi simple Theoscript.
---

# Theoscripturi

**Theoscripturile** sunt mici scripturi care automatizează lucruri în interiorul Theodia. Un script poate vorbi un pasaj, deschide un capitol, seta un marcaj, arăta un mesaj, rula o altă comandă și multe altele. Sunt o modalitate rapidă de a construi scurtături personale sau mici ajutoare devoționale fără a părăsi aplicația.

## Unde trăiesc Theoscripturile

Deschide **Theoscripturi** de pe ecranul principal sau din meniul principal. Ecranul apare doar când există cel puțin un theoscript.

Biblioteca arată:

- **Scripturi** — fiecare script pe care l-ai creat sau importat.
- **Categorii** — foldere opționale care grupează scripturile înrudite.

Atinge un script pentru a-l rula. Apasă lung pe un script pentru a-l edita, duplica sau șterge.

## Crearea unui script nou

1. Mergi la **Theoscripturi**.
2. Atinge **+ Adaugă script**.
3. Dă scriptului un nume.
4. Tastează comenzile în câmpul **Conținut script**.
5. Atinge **Salvează**.

Fiecare comandă merge pe propria linie. Indentezi liniile din interiorul unui bloc cu două spații.

## Comenzi comune

| Comandă                | Ce face                                 | Exemplu                                       |
| ---------------------- | ---------------------------------------- | --------------------------------------------- |
| `speak`                | Citește text sau un pasaj cu voce tare | `speak "Bună dimineața"` sau `speak Ioan 3:16` |
| `open`, `read`, `show` | Deschide un pasaj în Cititor            | `open Psalm 23`                               |
| `bookmark`             | Salvează pasajul curent în marcaje     | `bookmark`                                    |
| `highlight`            | Evidențiază versetul curent             | `highlight yellow`                            |
| `message`              | Arată un mesaj pop-up                   | `message "Citire finalizată"`                 |
| `set`                  | Schimbă o setare sau o valoare          | `set theme dark`                              |
| `return`               | Oprește scriptul devreme                  | `return`                                      |
| `with playlist`        | Adaugă piese într-un playlist            | `with playlist "Dimineață" track Ioan 3:16 end` |
| `start playlist`       | Redă un playlist                         | `start playlist "Dimineață"`                |
| `with note`            | Creează o notă                           | `with note "Ioan 3:16" "Gândurile mele" end`  |

## Controlul fluxului

Folosește `if` pentru a rula comenzi doar când o condiție este adevărată:

```text
if chapter == 1 {
  message "Începi o carte nouă!"
}
```

Folosește `repeat` pentru a repeta un bloc de comenzi:

```text
repeat 3 {
  speak "Pace ție"
}
```

Folosește `for` pentru a parcurge o listă:

```text
for $ref in ["Ioan 3:16", "Psalmii 23:1", "Romani 8:28"] {
  open $ref
  speak $ref
}
```

Folosește `function` și `call` pentru a reutiliza blocuri de cod:

```text
function greet $name {
  message "Salut, " + $name
}
call greet "prieten"
```

## Variabile

Stochează o valoare într-o variabilă cu `let`:

```text
let $name = "Theofil"
message "Bine ai venit, " + $name
```

Șirurile literale din partea dreaptă trebuie încadrate în ghilimele simple sau duble. Aceasta evită confuzia dintre o valoare literală și o comandă sau nume de variabilă. Numerele, variabilele și expresiile de comenzi nu au nevoie de ghilimele:

```text
let $count = 42
let $text = $last.passageText
let $words = count words in $text
let $greeting = "Salut, " + $name
```

Variabilele sunt utile în interiorul buclelor, funcțiilor și definițiilor de playlist.

## Exemple de scripturi

### Salut și un verset

```text
speak "Bună dimineața. Iată versetul tău pentru azi."
open Ioan 3:16
speak Ioan 3:16
```

### Marchează trei versete favorite

```text
open Ioan 3:16
bookmark
open Psalmii 23:1
bookmark
open Romani 8:28
bookmark
message "Favorite salvate."
```

### Construiește un playlist vorbit

```text
with playlist "Navetă" {
  track Ioan 3:16
  track Psalmii 23
  track Romani 8:28
}
start playlist "Navetă"
```

### Mesaj condiționat

```text
open Geneza 1:1
if book == "Geneza" {
  message "La început..."
}
```

## Organizarea scripturilor

Atinge **Gestionează categoriiile** pentru a crea categorii. Când editezi un script, alege categoria în care vrei să se afle. Categoriile ajută la separarea scripturilor personale, de exemplu și de cele de vorbire.

## Export și import

Atinge meniul din interiorul bibliotecii Theoscript pentru a:

- **Exportă theoscripturile** — salvează toate scripturile într-un fișier.
- **Exportă această categorie** — salvează doar categoria selectată.
- **Importă theoscripturi** — încarcă un fișier exportat anterior.

Fișierele exportate sunt text simplu și pot fi partajate cu alți utilizatori Theodia.

## Rularea scripturilor din Comandă rapidă

Theoscripturile pot fi rulate și după nume din **Meniul rapid** sau cerându-le prin Comanda rapidă. De exemplu, spunând sau tastând `rulează Scriptul meu de dimineață` va găsi și rula scriptul numit _Scriptul meu de dimineață_, dacă există.

## Depanare

- **Nu se întâmplă nimic când ating Rulare.** Verifică că conținutul scriptului nu este gol și că fiecare comandă este scrisă corect.
- **Speak nu citește nimic.** Asigură-te că este deschis un pasaj sau transmite text între ghilimele direct comenzii `speak`.
- **O comandă este evidențiată cu o eroare.** Theoscripturile arată erori când o comandă este necunoscută sau o referință este invalidă. Editează scriptul și încearcă din nou.
