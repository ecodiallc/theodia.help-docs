---
title: Citirea cu voce tare (text-to-speech)
level: everyday
categories: tts
summary: Cum face Theodia să citească Biblia sau un devoțional cu voce tare. Cum să folosești funcția, cum să alegi o voce și ce să faci când este tăcută.
---

# Citirea cu voce tare (text-to-speech)

> **Mod:** Citirea cu voce tare este disponibilă în modurile **Standard** și **Savant**. Modul focus este doar pentru citire curată, fără distrageri. Poți schimba modurile în **Setări** → **Mod utilizator aplicație**.

Theodia poate citi text cu voce tare folosind vocea text-to-speech (TTS) a dispozitivului. Poți asculta un singur verset, un capitol întreg sau un devoțional. Este util pentru citirea fără mâini, ascultarea în timp ce mergi sau călătorești, citirea însoțită de audio sau pur și simplu pentru a-ți odihni ochii.

## Unde este butonul de ascultare

Găsești un buton de ascultare în trei locuri.

### 1. În meniul versetului (un singur verset)

Aceasta este cea mai rapidă cale de a asculta câte un verset pe rând. Deschide un capitol în [Modul de studiu](theodia://help/study-mode), atinge un verset pentru a deschide meniul versetului, apoi atinge **Citește** (🔊). Citirea începe de la acel verset. O mică bară de control apare în partea de jos a ecranului cu redare, pauză, derulare înapoi, derulare înainte și selector de voce.

Opțiunea Citește nu este arătată pentru Biblile interlineare (MIB — Marvel Interlinear Bible — și OHGB), deoarece acestea afișează cuvintele într-un aranjament diferit care nu se citește natural.

### 2. În partea de sus a unui capitol (capitol întreg)

Când citești un capitol, uită-te la rândul de pictograme din partea de sus a ecranului. Atinge **Ascultă** (🔊) pentru a începe citirea capitolului de la început. Butonul se transformă în buton de oprire (⏹) cât timp redarea audio este activă. Atinge-l din nou pentru a opri. Aceeași bară de control apare în partea de jos.

Poți sări la un alt verset, iar butonul Ascultă de acolo va începe de la acel verset în schimb.

### 3. Într-un devoțional

Deschide orice zi devoțională, apoi atinge butonul **Ascultă** (🔊) din partea de sus a citirii. Tot textul devoționalului este citit cu voce tare, propoziție cu propoziție. O bară de control în partea de jos îți oferă redare, pauză, derulare înapoi și controale de voce.

## Folosirea barei de control

Cât timp redarea audio rulează, o mică bară rămâne vizibilă în partea de jos a ecranului. Are șase controale:

- ⏪ **Derulare înapoi** — mergi cu un verset înapoi (sau o propoziție înapoi într-un devoțional)
- ⏸ **Pauză / ▶ Continuare** — pauză fără să îți pierzi locul. Atinge din nou pentru a continua din același punct.
- ⏩ **Derulare înainte** — sare la versetul următor (sau propoziția următoare într-un devoțional)
- 🎙 **Voce** — deschide selectorul de voce fără a părăsi capitolul (vezi mai jos)
- ⚙ **Opțiuni** — deschide panoul de opțiuni extinse (vezi mai jos)
- **Oprește** — atinge butonul 🔊 din partea de sus a ecranului, sau ⏹ care îl înlocuiește cât timp rulează audio, pentru a opri și a închide bara.

Bara de control se închide când capitolul se termină sau când atingeți oprire.

### Opțiuni extinse

Atinge ⚙ pentru a extinde opțiunile suplimentare de redare. Aceste setări durează doar pentru capitolul curent și se resetează când comuți capitolele sau oprești ascultarea.

- ⏮ **Înapoi la început** — sare la primul verset din intervalul setat.
- **Început** — tastează un număr de verset pentru a seta de unde începe citirea.
- **Sfârșit** — tastează un număr de verset pentru a seta unde se oprește citirea.
- **Toate** — resetează intervalul la capitolul întreg.
- **()** — comută dacă textul din paranteze este citit cu voce tare.
- 🔁 **Repetă** — repornește automat la începutul intervalului când se ajunge la sfârșit, cu o scurtă pauză între. Dacă activezi acest lucru fără a seta un verset de început sau sfârșit, se repetă tot capitolul.

## Cum schimbi vocea

Poți alege ce voce folosește Theodia pentru citire. Este util dacă vrei un alt accent, altă limbă sau o voce mai rapidă sau mai lentă decât implicitul dispozitivului.

1. Deschide **Setări**.
2. Găsește secțiunea **Vorbire**.
3. Atinge **Selectează vocea**.
4. Apare o listă de voci. Primul rând, **Voce implicită**, folosește vocea preferată de dispozitivul tău. Alege orice alt rând pentru a o face noua implicită.
5. Alegerea ta este salvată și folosită data viitoare când atingi **Ascultă** sau **Citește**.

Poți atinge și pictograma 🎙 din bara de control a ascultării pentru a deschide același selector fără a părăsi capitolul.

Disponibilitatea vocilor depinde în totalitate de dispozitiv. iOS și Android vin cu un set de voci încorporate. Poți instala mai multe voci din setările dispozitivului **Accesibilitate** sau **Limbă și tastatură**. Theodia poate folosi orice voce instalată pe dispozitiv.

## Voci favorite

Dacă dispozitivul tău are multe voci, derularea prin lista completă de fiecare dată poate fi lentă. Poți crea o listă scurtă de **voci favorite**, iar selectoarele de voce vor arăta doar acele voci.

1. Deschide **Setări**.
2. Găsește secțiunea **Vorbire**.
3. Atinge **Voci favorite** (primul rând din partea de sus a secțiunii).
4. Atinge **Setează voci favorite** pentru a deschide ecranul de favorite.
5. Atinge butonul de redare lângă o voce pentru a o previzualiza. Atinge steaua pentru a o adăuga la favorite. Poți adăuga la favorite câte voci dorești.
6. Întoarce-te înapoi. Selectoarele de voce din Theodia arată acum doar vocirile tale favorite.

Dacă elimini toate favoritele, selectoarele revin la afișarea tuturor vocilor. Vocile favorite sunt incluse când faci backup și restaurezi setările Theodia.

## Setarea unei voci diferite pentru fiecare Biblie

Poți da fiecărei traduceri biblice propria voce. Este util când comuți între traduceri care citesc foarte diferit — de exemplu, o voce mai formală pentru King James Version și o voce mai conversațională pentru o traducere modernă precum NIV sau NLT. De asemenea, ajută dacă asculți versiuni biblice în limbi diferite și vrei ca fiecare să fie vorbită cu accentul potrivit.

1. Deschide **Setări**.
2. Găsește secțiunea **Vorbire**.
3. Caută **Voci pentru Biblie**.
4. Atinge orice Biblie din listă.
5. Alege vocea pe care o vrei pentru acea traducere. Primul rând, **Voce implicită**, folosește vocea ta TTS principală pentru acea Biblie.
6. Repetă pentru orice altă Biblie.

Antetul arată câte traduceri biblice au o voce personalizată setată. **Selectează vocea**, **Voce comentariu**, **Voce note biblice** și **Voce devoțional** arată și ele un număr când este setată o voce.

Data viitoare când asculți un capitol din acea Biblie, Theodia va folosi vocea aleasă de tine. Toate celelalte versiuni biblice continuă să folosească vocea implicită principală, decât dacă le schimbi și pe ele.

## Continuarea citirii în fundal

În mod implicit, Theodia oprește citirea când părăsești ecranul cititorului, comuți la altă aplicație sau încui telefonul. Acest lucru previne audio neașteptat când nu mai citești activ.

Pentru a lăsa citirea să continue în fundal:

1. Deschide **Setări**.
2. Găsește secțiunea **Vorbire**.
3. Activează **Continuă citirea în fundal**.

Când este activat, poți comuta file, deschide altă aplicație sau bloca ecranul, iar capitolul sau devoționalul vor continua să fie citite. Bara de control rămâne activă, ca să poți pune pauză sau sări din zona de notificare (dacă dispozitivul tău o suportă).

Dezactivarea acestui comutator **cât timp citirea rulează** o va opri imediat.

## Ce să faci dacă nu funcționează

Citirea cu voce tare depinde de dispozitivul tău. Theodia trimite textul către sistemul de operare, iar sistemul de operare îl citește cu voce tare folosind o voce. Dacă nu funcționează, încearcă acești pași în ordine.

### Theodia spune că TTS nu este disponibil

Unele dispozitive nu au TTS deloc. Deschide **Setări** și caută secțiunea **TTS**. Dacă secțiunea nu este acolo, dispozitivul tău nu suportă TTS în această versiune.

### Lista de voci este goală

Selectorul de voce poate arăta „nicio voce găsită". Acest lucru înseamnă de obicei că dispozitivul nu a terminat încă să încarce vocile.

1. Deschide **Setări → Vorbire → Selectează vocea**.
2. Dacă lista este goală, caută un buton **Reverifică** chiar sub meniul derulant. Atinge-l. Theodia interoghează din nou dispozitivul pentru voci.
3. Dacă este încă goală, verifică setările de sistem ale dispozitivului. Pe iOS, mergi la **Setări → Accesibilitate → Conținut vorbit → Voci** și descarcă o voce pentru limba ta. Pe Android, mergi la **Setări → Limbă și tastatură → Ieșire text-to-speech** și atinge **Instalează date voce**.
4. Închide și redeschide Theodia, ca să detecteze noua voce.

Dacă ai setat voci favorite și lista este goală, asigură-te că cel puțin una dintre favoritele tale se potrivește cu o voce instalată pe acest dispozitiv.

### Atingi Citește, dar nu se întâmplă nimic

- Verifică că dispozitivul nu este în modul silențios. Majoritatea dispozitivelor nu redau audio TTS când sunt în modul silențios.
- Asigură-te că volumul dispozitivului este ridicat.
- Încearcă butonul **Reverifică** în **Setări → Vorbire**.
- Deschide **Setări** și uită-te la secțiunea **Sistem** din partea de jos. Rândul **TTS** ar trebui să spună **Disponibil**. Dacă spune **Indisponibil**, TTS este oprit la nivelul sistemului de operare. Reactivează-l acolo, apoi redeschide Theodia.

### Audio rulează, dar este în limba greșită

Theodia trimite text în limba conținutului curent și cere vocea pe care ai selectat-o. Dacă vocea selectată este pentru o altă limbă, dispozitivul poate citi în continuare textul, dar va suna ciudat.

1. Deschide **Setări → Vorbire → Selectează vocea**.
2. Alege **Voce implicită** pentru a lăsa dispozitivul să aleagă una potrivită, sau alege o voce a cărei limbă se potrivește cu textul pe care îl citești.

Theodia nu citește în prezent cu voce tare Biblile interlineare în greacă sau ebraică. Butoanele Citește și Ascultă sunt ascunse pe acele traduceri.

### Audio rulează, dar se oprește devreme

Dacă un verset lipsește sau nu poate fi citit, capitolul sare la următorul. Dacă bara se închide singură după câteva versete, atinge butonul **Ascultă** (🔊) din partea de sus a ecranului pentru a o lua de la capăt.

### Citirea rulează, dar nu știu de unde a început

Dacă ai activat **Continuă citirea în fundal** și mai târziu auzi audio, dar nu găsești ecranul care a pornit-o, o poți opri de oriunde din aplicație.

1. Deschide **Setări**.
2. Găsește secțiunea **Vorbire**.
3. Atinge butonul roșu **Oprește citirea** din partea de jos a secțiunii.

Acest lucru oprește imediat orice text-to-speech în desfășurare în Theodia. Poți deschide și selectorul de aplicații al dispozitivului și poți închide Theodia pentru a opri forțat audio.

### Citește prea repede sau prea încet

Theodia nu controlează viteza de citire. Viteza este setată de vocea aleasă. Pentru a o schimba:

- Pe iOS: **Setări → Accesibilitate → Conținut vorbit → Viteza de vorbire**.
- Pe Android: **Setări → Limbă și tastatură → Ieșire text-to-speech → Viteza de vorbire**.

## Sfaturi

- Bara de control rămâne vizibilă când navighezi între capitole, deci poți pune pauză, sări sau schimba vocea fără să îți pierzi locul.
- Theodia citește numerele versetelor ca mici pauze. Poți opri bara, glisa la un alt verset, apoi atinge redare pentru a continua de acolo.
- Pentru ascultări lungi, activează **Nu deranja**, ca notificările să nu întrerupă audio.
- Butonul 🔊 folosește volumul curent al dispozitivului. Dacă bagi căști, volumul comută la nivelul căștilor.

## Citirea unui PDF cu voce tare

Theodia poate citi cu voce tare și paginile PDF-urilor. Deschide un PDF și atinge butonul **Ascultă** (difuzorul) din bara lui de unelte. Apare o bară de control cu Redă/Pauză, Derulează înapoi, Derulează înainte, Oprește, o bară de progres și selectori de viteză și voce. Când o pagină se termină, citirea continuă automat pe pagina următoare.

Citirea PDF-urilor folosește textul căutabil instalat al PDF-ului și aceleași voci și viteză ca la citirea Bibliei.

## Ghiduri înrudite

- Ghidul [Mod de studiu](theodia://help/study-mode) acoperă meniul versetului și butoanele din partea de sus a ecranului în mai multe detalii.
- Ghidul [Mod focus](theodia://help/focus-mode) este o vizualizare mai curată a citirii care suportă și TTS prin butonul 🔊 din bara de jos.
- Ghidul [Probleme comune](theodia://help/common-problems) conține soluții pentru alte probleme de audio, voce și limbă.
- Ghidul [Devoționale zilnice](theodia://help/daily-devotionals) acoperă citirea devoțională și locul butonului de ascultare pe acel ecran.
- Ghidul [PDF-uri](theodia://help/pdfs) acoperă cititorul de PDF-uri și butonul lui de ascultare.
