---
title: Bun venit la Theodia
level: beginner
categories: welcome
summary: O scurtă prezentare a aplicației și a ceea ce poate face pentru tine.
---

# Bun venit la Theodia

Theodia este o aplicație de studiu biblic. Funcționează pe telefon sau tabletă, chiar și fără internet. Tot ce citești, cauți și studiezi rămâne pe dispozitivul tău.

## Ce poți face

Theodia are trei moduri de utilizare. Fiecare arată un set diferit de funcții.

- **Cititor** — citește Biblia într-un ecran curat, fără distrageri.
- **Standard** — tot ce are Cititor, plus marcaje, evidențieri, note, citire cu voce, căutare și devoționale zilnice.
- **Savant** — tot ce are Standard, plus comentarii, lexicoane, Dicționarul biblic, asistentul IA și multe altele.

Poți schimba modul oricând în **Setări** → **Mod utilizator aplicație**.

### Funcțiile disponibile pentru tine

Indiferent de modul ales, poți întotdeauna:

- **Citi Biblia.** Alege din multe traduceri. Treci între ele oricând.
- **Căuta în Biblie.** Caută un cuvânt sau o expresie. Aplicația îți arată fiecare verset care se potrivește.
- **Citi cărți și devoționale.** Aplicația vine cu clasice creștine și un devoțional zilnic.

În funcție de mod, poți avea acces și la:

- **Ascultare.** Citește versete cu voce tare cu funcția de redare. (Standard și Savant.)
- **Luare de note.** Scrie-ți gândurile lângă un verset. (Standard și Savant.)
- **Evidențiere.** Marchează versetele favorite în culori. (Standard și Savant.)
- **Marcaje.** Salvează versete pentru a le găsi rapid. (Standard și Savant.)
- **Asistentul IA.** Primește ajutor pentru înțelegerea unui verset. (Doar Savant.)

## De unde să începi

1. Deschide fila **Biblia** din partea de jos a ecranului.
2. Alege o traducere.
3. Atinge orice carte pentru a începe citirea.

Dacă vrei să înveți mai multe, restul ghidurilor de ajutor sunt aici pentru tine. Alege un subiect din lista de pe pagina principală de ajutor.

## Câteva lucruri de știut

- Nu ai nevoie de cont.
- Notițele, evidențierile și marcajele rămân pe dispozitiv.
- Le poți face backup. Vezi ghidul [Salvarea datelor tale](theodia://help/backups) pentru detalii.

## Vrei mai multe resurse?

Aplicația vine cu mai multe versiuni ale Bibliei disponibile gratuit. Pentru Biblii suplimentare, comentarii, lexicoane, cărți și devoționale, vezi ghidul [Obținerea de resurse suplimentare de pe GitHub](theodia://help/getting-core-files). Acesta arată cum să găsești și să adaugi mai multe resurse de pe pagina de GitHub a proiectului.

Bun venit. Sperăm ca Theodia să te ajute să citești și să studiezi.
