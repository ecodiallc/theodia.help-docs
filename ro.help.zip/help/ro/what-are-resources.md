---
title: Ce sunt resursele?
level: beginner
categories: resources
summary: O prezentare generală a diferitelor tipuri de fișiere pe care le folosește Theodia — Biblii, comentarii, cărți și multe altele.
---

# Ce sunt resursele?

În Theodia, o „resursă" este orice fișier care adaugă material de citire sau de studiu în aplicație. Aplicația în sine este doar un cititor și un caiet de notițe. Biblia, comentariile, cărțile și celelalte materiale cu care studiezi sunt toate fișiere separate pe care le încarci.

Acest ghid explică diferitele tipuri de resurse și la ce folosește fiecare.

## De ce contează acest lucru?

Când deschizi Theodia pentru prima dată, are deja câteva lucruri de citit. Pe măsură ce explorezi, vei vedea butoane pentru a instala mai multe. A ști ce fel de resursă este fiecare te va ajuta să decizi ce să adaugi.

## Diferitele tipuri de resurse

Theodia recunoaște fișiere după extensie. Fiecare extensie este un tip diferit de resursă.

### `.bible` — o traducere biblică

O traducere biblică este o copie completă a Bibliei într-o anumită versiune, precum King James Version. Theodia vine cu câteva traduceri și îți permite să adaugi mai multe.

Vezi ghidul [Instalarea traducerilor biblice](theodia://help/installing-bibles) pentru detalii.

### `.commentary` — un comentariu

Un comentariu este o carte de note de studiu scrisă de un biblist. Pentru un verset dat, un comentariu îți spune contextul, înțelesul și cum se potrivește versetul în restul Bibliei.

Vezi ghidul [Comentarii și lexicoane](theodia://help/commentaries-and-lexicons) pentru detalii.

### `.lexicon` — un lexicon

Un lexicon este un dicționar al cuvintelor biblice. Îți spune cuvântul original în ebraică sau greacă, ce înseamnă și cum este folosit în Biblie.

Vezi ghidul [Comentarii și lexicoane](theodia://help/commentaries-and-lexicons) pentru detalii.

### `.book` — o carte creștină

O carte este o lucrare creștină mai lungă, precum un clasic din istoria bisericii. Citirea cărților în aplicație funcționează aproape la fel ca citirea Bibliei. Theodia vine cu o mică bibliotecă de clasice creștine disponibile gratuit.

Vezi ghidul [Cărțile încorporate](theodia://help/reading-books) pentru detalii.

### `.devotional` — un devoțional

Un devoțional este o scurtă citire zilnică. Fiecare intrare are de obicei un verset, o scurtă reflecție și o rugăciune sau o întrebare de meditat. Multe devoționale sunt concepute pentru a fi citite câte o intrare pe zi, timp de un an.

Vezi ghidul [Devoționale zilnice](theodia://help/daily-devotionals) pentru detalii.

### `.sqlite` — o bază de date de referință

O bază de date de referință este un fișier mare de căutare pe care aplicația îl folosește pentru a-ți oferi informații suplimentare pe măsură ce citești. Sunt două tipuri:

- **Referințe încrucișate** — liste de versete care se leagă de versetul pe care îl citești.
- **Morfologie** — informații despre cuvintele originale în ebraică sau greacă din verset.

Nu le deschizi direct. Funcționează în fundal și adaugă funcții cititorului biblic. Vezi ghidul [Referințe încrucișate](theodia://help/cross-references) pentru detalii.

### `.data` — date de cuvinte

Un fișier de date de cuvinte conține informații suplimentare despre cuvintele originale ale Bibliei. Este folosit de lexicon și de instrumentele de studiu. La fel ca bazele de date de referință, nu îl deschizi direct. Aplicația îl folosește în fundal.

## Cum adaugi o resursă

Ecranul **Gestionează resursele** al aplicației este calea ușoară de a adăuga o resursă.

1. Deschide **Setări**.
2. Atinge **Gestionează resursele**.
3. Atinge **Descarcă de pe GitHub**.
4. În modalul de descărcare, alege o filă — **Biblii**, **Comentarii**, **Cărți**, **Devoționale** sau **Bază** — apoi selectează ce vrei și atinge **Instalează selectate**.
5. Sau atinge **Importă fișier local** pentru a importa un fișier pe care l-ai descărcat deja.

Pentru un ghid pas cu pas despre obținerea fișierelor direct de pe GitHub, vezi ghidul [Obținerea de resurse suplimentare de pe GitHub](theodia://help/getting-core-files).

## Cum elimini o resursă

1. Deschide **Setări**.
2. Atinge **Gestionează resursele**.
3. Găsește resursa pe care vrei să o elimini.
4. Atinge pictograma de coș de gunoi lângă ea.
5. Confirmă că vrei să o elimini.

Eliminarea unei resurse nu îți șterge notițele, evidențierile sau marcajele. Acestea rămân în siguranță.

## Unde trăiesc resursele pe dispozitiv

Resursele sunt stocate pe dispozitiv, nu în cloud. Odată instalată o resursă, nu ai nevoie de internet pentru a o citi. Îți poți face backup dispozitivului, dar resursele în sine nu sunt făcute backup în cloud de către Theodia. Dacă dezinstalezi și reinstalezi aplicația, va trebui să re-adaugi orice resurse pe care le aveai instalate.

## Ajutor și întrebări

Dacă ai probleme, vezi ghidul [Unde să pui întrebări](theodia://help/getting-more-help). Echipa și comunitatea te pot ajuta.
