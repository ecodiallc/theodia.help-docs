---
title: Создание собственных ресурсов
level: advanced
categories: resources
summary: Как создавать собственные Библии, комментарии, книги, ежедневные чтения и лексиконы и импортировать их в Theodia.
---

# Создание собственных ресурсов

Theodia поддерживает пользовательские ресурсы в формате Unique Bible App. Каждый ресурс — это файл SQLite с определённой структурой таблиц. Вы можете создавать эти файлы на компьютере и импортировать их в приложение.

## Типы файлов и необходимые таблицы

### Библии (`.bible`)

Файл Библии — это база данных SQLite с хотя бы одной из этих таблиц:

- **`Verses`** — столбцы: `Book` (целое, 1–66), `Chapter` (целое), `Verse` (целое), `Scripture` (текст)
- **`Bible`** — столбцы: `Book` (целое), `Chapter` (целое), `Verse` (целое), `Scripture` (текст)

Можно также включить таблицу **`Details`** с метаданными, такими как `Description`, `Abbreviation` и `Version`.

Пример SQL:

```sql
-- Основная таблица текста
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- Дополнительная таблица метаданных
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### Комментарии (`.commentary`)

Комментарии бывают трёх типов: **книжный**, **главный** и **стиховый**. Тип определяется **первой буквой имени файла**.

#### Книжные комментарии — имя файла начинается с `b`

Книжный комментарий охватывает всю книгу Библии одной записью. Таблице `Commentary` нужны столбцы `Book` и `Scripture` (или `Content`). Столбцы `Chapter` и `Verse` не требуются.

- **`Commentary`** — столбцы: `Book` (целое), `Scripture` (текст) или `Content` (текст)

Пример SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

Пример имени файла: `bMyCommentary.commentary`

#### Главные комментарии — имя файла начинается с `c`

Главный комментарий охватывает каждую главу библейской книги.

- **`Commentary`** — столбцы: `Book` (целое), `Chapter` (целое), `Scripture` (текст) или `Content` (текст)

Пример SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

Пример имени файла: `cMyCommentary.commentary`

#### Стиховые комментарии — имя файла начинается с `v`

Стиховый комментарий охватывает отдельные стихи. Таблице `Commentary` нужны столбцы `Book`, `Chapter`, `Verse` и `Scripture` (или `Content`).

- **`Commentary`** — столбцы: `Book` (целое), `Chapter` (целое), `Verse` (целое), `Scripture` (текст) или `Content` (текст)

Пример SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

Пример имени файла: `vMyCommentary.commentary`

### Книги (`.book`)

Файл книги — это база данных SQLite с таблицей `Reference`.

- **`Reference`** — столбцы: `id` (целое), `Chapter` (текст), `Content` (текст)

Каждая строка — одна глава. Столбец `Chapter` — название главы. Столбец `Content` — тело главы, которое может включать HTML (`<b>`, `<i>`, `<br>` и т. д.).

Пример SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

Можно также создавать книги из файлов Markdown. Приложение может импортировать `.md` файлы, где `#` — название книги, а `##` отмечает главы. Markdown автоматически преобразуется в HTML.

### Ежедневные чтения (`.devotional`)

Файл ежедневных чтений — это база данных SQLite с таблицей `devotional`.

- **`devotional`** — столбцы: `month` (целое, 1–12), `day` (целое, 1–31), `devotion` (текст)

Каждая строка — чтение на один день. Приложение ищет запись по текущему месяцу и дню.

Пример SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### Лексиконы (`.lexicon`)

Файл лексикона — это база данных SQLite с таблицей `Lexicon`.

- **`Lexicon`** — столбцы: `Topic` (текст, номер Стронга), `Definition` (текст, статья лексикона)

Столбец `Topic` содержит номер Стронга (например, `G1161` или `H7225`). Столбец `Definition` содержит полный текст статьи, который может включать HTML.

Пример SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

Лексиконы обеспечивают работу инструмента Информация о слове. Когда вы нажимаете слово в интерлинейной Библии, приложение ищет номер Стронга в установленных лексиконах.

## Создание файла на компьютере

1. Установите редактор SQLite (DB Browser for SQLite, SQLiteStudio или инструмент командной строки `sqlite3`).
2. Создайте новый файл базы данных.
3. Создайте необходимую таблицу и вставьте данные.
4. Сохраните файл с правильным расширением (`.bible`, `.commentary`, `.book`, `.devotional` или `.lexicon`).

## Импорт в Theodia

1. Передайте файл на устройство (AirDrop, электронная почта, облако или USB).
2. Откройте **Theodia**.
3. Перейдите в **Настройки** → **Управление ресурсами**.
4. Нажмите **Импорт из файла**.
5. Выберите свой файл.

Приложение проверяет файл (проверяет наличие необходимой таблицы), копирует его в папку данных приложения и включает автоматически. Если файл неверен, появится сообщение об ошибке с пояснением.

## Ограничения

- Нельзя перезаписать встроенные ресурсы. Если вы попытаетесь импортировать файл с тем же именем, что и встроенная Библия, комментарий или книга, импорт завершится ошибкой.
- Файлы Библии нуждаются в таблице `Verses` или `Bible`. Если ни одной нет, импорт завершится ошибкой.
- Файлы комментариев нуждаются в таблице `Commentary`.
  - Книжные комментарии нуждаются в столбцах `Book` и `Scripture` (или `Content`).
  - Главные комментарии нуждаются в столбцах `Book`, `Chapter` и `Scripture` (или `Content`).
  - Стиховые комментарии нуждаются в столбцах `Book`, `Chapter`, `Verse` и `Scripture` (или `Content`).
- Файлы книг нуждаются в таблице `Reference`.
- Файлы лексиконов нуждаются в таблице `Lexicon`.
- Файлы ежедневных чтений нуждаются в таблице `devotional`.

## Советы

- Держите размеры файлов разумными. Очень большие файлы SQLite могут вызвать проблемы с памятью на старых устройствах.
- Сначала протестируйте файл на компьютере. Откройте его в браузере SQLite и выполните `SELECT * FROM` нужной таблицы, чтобы убедиться, что данные выглядят правильно.
- Для Библий убедитесь, что столбец `Book` использует числа (1 = Бытие, 66 = Откровение).
- Для комментариев можно использовать либо `Scripture`, либо `Content` в качестве текста комментария.
- Для книг HTML в столбце `Content` отображается при чтении. Держите его простым: `<b>`, `<i>`, `<br>` и `<hr>` безопасны.

## Где найти существующие ресурсы

Theodia может читать ресурсы из проекта [Unique Bible App](https://github.com/eliranwong/UniqueBible). Там доступно множество Библий, комментариев, книг и других ресурсов в правильном формате SQLite. Как найти и добавить их, см. в руководстве [Получение дополнительных ресурсов](theodia://help/getting-core-files).
