---
title: AI-grunderna
level: advanced
categories: ai
summary: Hur du använder AI-hjälpen för att förstå verser.
---

# AI-grunderna

> **Läge:** AI-assistenten kräver läget **Scholar**. Du kan byta läge i **Inställningar** → **Appanvändarläge**.

Theodia har en AI-assistent. Den kan hjälpa dig att förstå en vers, svara på en fråga eller prata igenom ett bibliskt ämne.

## Så slår du på AI:n

AI:n är av som standard. Så här slår du på den:

1. Öppna **Inställningar**.
2. Tryck på **AI-assistent**.
3. Tryck på reglaget för att slå på den.

## Så öppnar du AI:n

Tryck på fliken **AI** längst ner på skärmen. Ett chattfönster öppnas.

## Så ställer du en fråga

Tryck på rutan längst ner. Skriv din fråga. Tryck på **Skicka**.

Några saker du kan fråga:

- "Vad betyder Johannes 3:16?"
- "Berätta om Romarbrevet."
- "Vad är Andens frukt?"
- "Jämför bergspredikan i Matteus och Lukas."

## Så frågar du om en viss vers

1. Öppna ett kapitel.
2. Tryck på en vers för att visa versmenyn.
3. Tryck på **AI-kommentar**.

Versen skickas till AI:n. AI-panelen öppnas med versen förifylld. Du kan lägga till en fråga, till exempel "Vad betyder detta?" eller "Hur kan jag tillämpa detta?"

## Viktigt att veta

- AI:n är ett verktyg, inte en människa. Den kan göra misstag.
- Kontrollera alltid AI:ns svar mot Bibeln själv.
- AI:n kan behöva internet. Den fungerar inte offline.
- När du använder AI:n skickas dina frågor, verskontext och din API-nyckel till den slutpunkt du väljer. Första gången du gör detta ber appen om ditt tillstånd och visar exakt vad som skickas. Du kan ändra eller återkalla det tillståndet senare i **Inställningar → AI-assistent → Delning av AI-data på distans**.
- Vissa regioner, till exempel App Store-versionen för Kinas fastland, erbjuder inte AI-assistenten. I den versionen är bara offlinefunktionerna för Bibeln tillgängliga.

## Så hanterar du konversationer

AI-skärmen sparar en lista över tidigare konversationer. Från listan kan du öppna en gammal konversation, påbörja en ny eller ta bort en du inte längre behöver.

## Gå vidare med AI

Den här sidan täcker grunderna. Theodias AI kan göra mycket mer än att chatta. Här är nästa steg:

- **[AI-funktioner](theodia://help/ai-features)** — Upptäck allt Theophilus kan göra: versstudie i grekiska och hebreiska med ett tryck, korsreferenskedjor, predikoutkast, bönegenerering, morfologi på originalspråken, uppslag i ordböcker och appnavigering utan händer. Det här är guiden som visar hur du förvandlar AI:n från en chattbot till en fullvärdig studiepartner.
- **[Skriv bättre AI-prompter](theodia://help/ai-prompts)** — Lär dig konsten att ställa frågor som ger rikliga och träffsäkra svar. Några små justeringar i hur du formulerar din begäran kan ge AI:n möjlighet att svara betydligt djupare.
- **[Välja en AI-modell](theodia://help/choosing-a-model)** — Alla AI-modeller är inte lika. Ta reda på vilka modeller som stöder Theodias inbyggda verktyg (som att öppna verser och söka i Skriften) och vilka som gör AI:n till en äkta studieassistent utan händer.
- **[GitHub Models](theodia://help/github-models)** — Den rekommenderade gratisleverantören för Theodia. Skaffa en gratis API-nyckel med ett GitHub-konto och börja ställa frågor inom en generös dagliga kvot. Inget kreditkort, ingen prenumeration.
- **[API-nycklar och kostnader](theodia://help/ai-keys-and-costs)** — Förstå hur API-prissättning fungerar hos olika leverantörer och hur du håller kostnaderna nära noll.
