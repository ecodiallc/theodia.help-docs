---
title: AI-funktioner
categories: ai
level: advanced
summary: Upptäck allt Theodias AI kan göra — från vers-för-vers-studie till predikoförberedelse, originalspråk och navigering utan händer.
---

# AI-funktioner

> **Läge:** AI-assistenten kräver läget **Scholar**. Du kan byta läge i **Inställningar** → **Appanvändarläge**.

Theodias AI-assistent, Theophilus, är inte bara en chattbot. Den är en studiepartner som kan läsa Bibeln tillsammans med dig, slå upp kommentarer, söka i Skriften, hantera dina anteckningar och till och med navigera i appen — allt med röst eller text.

Innan Theophilus skickar data till en AI-slutpunkt för första gången visar appen en dialog om samtycke som förklarar vad som skickas och ber om ditt tillstånd. Du kan ändra eller återkalla det tillståndet när som helst i **Inställningar → AI-assistent → Delning av AI-data på distans**.

## AI-verschatt: Studera en vers på djupet

**AI-verschatten** är hjärtat i Theodias AI-upplevelse. Medan du läser ett kapitel trycker du på ett versnummer (eller håller nere versens text) och väljer **AI-kommentar**. En chattpanel öppnas med versen redan inläst. AI:n vet exakt vad du läser och är redo att utforska den tillsammans med dig.

### Startpunkter med ett tryck

Osäker på vad du ska fråga? Panelen visar åtta snabbstartare:

- **Förklara denna vers** — Få en tydlig och genomtänkt genomgång av betydelsen och dess vikt.
- **Originalspråk** — Se de grekiska eller hebreiska orden, translitterationer och lexikala definitioner bakom den engelska texten.
- **Historiskt sammanhang** — Lär dig om kulturen, politiken och händelserna kring versen.
- **Textsammanhang** — Se hur versen passar in i stycket, kapitlet och boken runt omkring.
- **Huvudteman** — Upptäck de stora tankar som versen bidrar med till den bibliska teologin.
- **Tillämpa i mitt liv** — Få praktiska, personliga tillämpningar du kan sätta i verk idag.
- **Generera en bön** — Gör om versen till en bön modellerad efter dess språk och sanningar.
- **Generera ett predikoutkast** — Få ett utkast med tre punkter, inledning och avslutning, redo att predika.

Tryck på en startpunkt så börjar AI:n omedelbart. Du kan följa upp med egna frågor, be om förtydliganden eller styra samtalet i en ny riktning.

### Följ upp som i en riktig konversation

AI:n minns de senaste meddelandena i chatten, så du kan gräva djupare naturligt:

- "Kan du säga det enklare?"
- "Vad säger den grekiska originaltexten här?"
- "Visa mig korsreferenser som hör till detta."
- "Jämför denna vers i tre olika översättningar."
- "Hur skulle det här se ut på en modern arbetsplats?"
- "Ge mig tre tillämpningar till för en förälder."

Samtalet hänger ihop med versen, så varje svar bygger på texten du läser.

### Tryck på valfri bibelreferens

När AI:n nämner en annan vers — till exempel "Detta speglar Romarbrevet 8:28" — visas referensen som en **tryckbar länk**. Tryck på den så hoppar appen till den passagen i Bibelläsaren. Du kan följa referenskedjan utan att lämna samtalet.

## Vad AI:n kan göra utöver verschatten

Theophilus har tillgång till hela innehållet i Theodia — Biblar, kommentarer, lexikon, ordböcker, böcker, andaktsböcker, dina anteckningar, bokmärken och färgmarkeringar. Så här ser det ut i praktiken.

### Läs och navigera i Skriften

- **Läs valfri vers eller kapitel** — "Läs Johannes 3:16 i WEB" eller "Läs Psalm 23 högt."
- **Öppna passager i läsaren** — "Ta mig till 1 Mosebok 1" eller "Öppna Romarbrevet 8:28."
- **Jämför versioner** — "Visa mig Johannes 3:16 i alla mina Biblar."
- **Sök i Bibeln** — "Hitta verser om förlåtelse" eller "Sök efter 'en fred som överskrider all förstånd'."
- **Få korsreferenser** — "Vilka andra verser hör till Jesaja 53:5?"
- **Läs mellanrubriker** — "Vilka mellanrubriker finns i Matteus 5?"

### Utforska originalspråken

- **Lexikonuppslag** — "Vad betyder det grekiska ordet 'agape' i Johannes 3:16?" eller "Slå upp Strong's G26."
- **Morfologi** — "Tolka de grekiska verben i Romarbrevet 8:28" eller "Vad betyder morfologikoden V-PAI-3S?"
- **Ordinfo** — AI:n ser samma ord-för-ord-genomgång som du ser i appen — translitteration, ordförklaring, grammatik och Strong's-nummer.

### Läs kommentarer och studieböcker

- **Verskommentar** — "Vad säger Matthew Henry om Efeserbrevet 2:8?"
- **Kapitelkommentar** — "Ge mig kapitelöversikten för Romarbrevet 8."
- **Bokkommentar** — "Sammanfatta kommentarerna på boknivå till Uppenbarelseboken."
- **Studieböcker** — "Läs ett kapitel ur Hymn Lyrics English" eller "Sök i mina böcker efter 'tålamod'."
- **Andakter** — "Läs dagens andakt" eller "Hitta en andakt om oro."

### Sök i ordböcker

- "Vem var Melkisedek?"
- "Vad säger bibelordboken om Gilgal?"
- "Slå upp 'försoning' i Easton's."

### Hantera ditt studieliv

AI:n kan agera på dina personliga data — alltid sparade lokalt på din enhet:

- **Bokmärken** — "Bokmärk denna vers i mappen Predikoförberedelse" eller "Lista mina bokmärken."
- **Färgmarkeringar** — "Markera Johannes 3:16 i gult" eller "Visa alla mina färgmarkeringar."
- **Anteckningar** — "Skapa en bibelanteckning för denna vers" eller "Läs mina anteckningar för 1 Mosebok 1."
- **Studieanteckningar** — "Spara den här konversationen som en studieanteckning" eller "Skapa ett nytt studiehäfte som heter Romarstudien."
- **Mappar** — "Skapa en mapp som heter Morgonandakt" eller "Flytta mitt bokmärke för Johannes 3:16 till mappen Bön."

### Ändra appinställningar

- "Byt till mörkt läge."
- "Gör BSB till min standardbibel."
- "Slå på parallellbiblar med NET."
- "Öka textstorleken."

### Läs upp

- "Läs Psalm 23 högt" — AI:n kan starta text-till-tal för valfri passage, bok eller anteckning.
- "Sluta läsa" — Pausa uppläsningen när som helst.

## Spara dina konversationer

Varje AI-verschatt kan sparas. Tryck på menyn i chattpanelen och välj:

- **Spara som bibelanteckning** — Lägger till hela konversationen i versanteckningen i Bibelläsaren.
- **Spara som studieanteckning** — Sparar konversationen i ditt studieanteckningshäfte för senare bruk.

Det gör en snabb AI-utforskning till permanent studiematerial som du kan återvända till, redigera eller bygga predikningar utifrån.

## Hela AI-fliken

Utöver panelen för verschatt har Theodia en egen **AI**-flik i den nedre navigeringen. Där är det fritt chattande där du kan fråga vad som helst — ingen vers är förvald. Använd den till:

- Temastudier i hela Bibeln
- Predikoresearch och utkast
- Jämförelser av teologiska teman mellan böcker
- Daglig andakt och böneimpulser
- Bibelquiz och läschemaer
- Hjälp om appen — "Hur fungerar parallellbiblar?"

Dina konversationer sparas automatiskt. Du kan återvända till tidigare chattar, påbörja nya och ta bort gamla trådar.

## Idéer för att komma igång

Här är några spännande sätt att använda AI:n. Välj en och prova idag.

**Personlig tillväxt**

- "Förklara Filipperbrevet 4:6–7 och ge mig en bön för stunder då jag känner oro."
- "Vad säger Bibeln om vila? Hitta fem verser och förklara var och en."

**Familj och föräldraskap**

- "Hur bör Efeserbrevet 6:4 vägleda modern föräldraskap? Ge mig tre praktiska regler."
- "Hitta verser om att fostra barn och läs dem högt för mig."

**Prediko- och undervisningsförberedelse**

- "Gör ett utkast till en 25-minuterspredikan om Romarbrevet 8:28 med inledning, tre punkter och avslutning."
- "Vad säger mina kommentarer om 'Guds vapenrustning' i Efeserbrevet 6?"
- "Jämför bergspredikan i Matteus med Lukas version. Vad skiljer?"

**Studium av originalspråken**

- "Visa mig morfologin för varje ord i Johannes 1:1."
- "Vad är skillnaden mellan 'agape' och 'philia' i Nya testamentet?"

**Djupare andakter**

- "Läs dagens andakt och koppla den till en vers i Psaltaren."
- "Ge mig ett andaktsutkast för sju dagar om Andens frukt."

**Korsreferenskedjor**

- "Börja med Jesaja 53:5 och spåra temat 'sår' och 'läkedom' genom Nya testamentet."
- "Var finns begreppet 'förbund' från 1 Mosebok till Hebreerbrevet?"

**Minne och repetition**

- "Fråga mig om Bibelns böcker i ordning."
- "Skapa en studieanteckning som sammanfattar huvudpoängen i varje kapitel i Romarbrevet."

## Några viktiga noteringar

- AI:n är ett **verktyg**, inte en ersättning för Bibeln eller pastoral vägledning. Jämför alltid dess svar med Skriften själv.
- När du använder AI:n färdas dina frågor över internet till leverantörens servrar. De flesta leverantörer tränar inte på dina data, men texten lämnar din enhet.
- AI:n kan göra misstag. Använd kommentarer, lexikon och själva bibeltexten som din slutgiltiga auktoritet.

## Sammanfattning

Theodias AI är byggd för att göra bibelstudiet snabbare, djupare och mer personligt. Oavsett om du vill ha en förklaring på en mening av en svårversådd vers, ett fullständigt predikoutkast, en studie av ett grekiskt ord eller en korsreferenskedja som spänner över hela Bibeln är Theophilus redo att hjälpa dig. Tryck på en vers, ställ en fråga och se vart samtalet leder.
