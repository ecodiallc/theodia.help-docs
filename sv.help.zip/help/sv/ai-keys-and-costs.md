---
title: API-nycklar och kostnader
level: advanced
categories: ai
summary: Varför du behöver en API-nyckel, hur du skaffar en och vad en AI-modell på distans vanligen kostar.
---

# API-nycklar och kostnader

> **Läge:** AI-assistenten kräver läget **Scholar**. Du kan byta läge i **Inställningar** → **Appanvändarläge**.

AI-assistenten ansluter till AI-modeller på distans. Vill du använda en behöver du en API-nyckel. Den här sidan förklarar varför, hur du skaffar en och vad det vanligen kostar.

## Varför du behöver en API-nyckel

En AI-modell på distans finns på en server på internet. API-nyckeln fungerar som ett lösenord som säger till servern: "Den här personen får ställa frågor." Utan den svarar servern inte.

Appen har ingen inbyggd nyckel. Du måste skapa ett eget konto hos en leverantör och klistra in din nyckel i appen.

## Så skaffar du en API-nyckel

1. Öppna **Inställningar** i Theodia.
2. Tryck på **AI-assistent**.
3. Välj **Modell på distans**.
4. Välj en leverantör ur listan, eller välj **Anpassad** och ange en bas-URL.
5. Tryck på länken till leverantörens nyckelsida. Skapa ett konto om du inte har ett.
6. Generera en ny API-nyckel på leverantörens webbplats.
7. Kopiera nyckeln och klistra in den i Theodia.
8. Tryck på **Testa anslutning** för att kontrollera att den fungerar.

## Leverantörer som stöds

Theodia kan ansluta till valfri leverantör som använder ett OpenAI-kompatibelt API. Här är de som har förinställda länkar i appen:

- **GitHub Models** — github.com/marketplace/models (gratis daglig kvot, rekommenderas)
- **OpenAI** — platform.openai.com
- **OpenRouter** — openrouter.ai
- **Anthropic** — console.anthropic.com
- **Groq** — console.groq.com
- **Mistral** — console.mistral.ai
- **Together AI** — api.together.xyz

Du kan också använda en **anpassad** bas-URL om du kör din egen server eller använder en annan tjänst.

## Hur mycket kostar det?

De flesta leverantörer debiterar per **token**. En token är ungefär ett ord eller en del av ett ord. Du betalar för de tokens du skickar (din fråga) plus de tokens AI:n skickar tillbaka (svaret).

### Typiska priser

Priserna ändras, men här är en grov bild i mitten av 2026:

- **Små, snabba modeller** (som billigare slutpunkter i GPT-3.5-klassen) kostar en bråkdel av ett öre per tusen tokens.
- **Modeller i mellanklassen** (som GPT-4o eller Claude Sonnet) kostar vanligen några ören per tusen tokens.
- **Stora resonemangsmodeller** (som GPT-4.5 eller Claude Opus) kan kosta tio till tjugo ören per tusen tokens.

En typisk bibelfråga i Theodia kan använda några hundra till ett par tusen tokens totalt. Det betyder att de flesta frågor kostar **under ett öre till några ören**.

### Tips för att hålla kostnaderna låga

- Börja med en billigare modell. De flesta bibelfrågor behöver inte den dyraste modellen.
- Använd Groq eller OpenRouter om du vill prova olika modeller och jämföra priser.
- Håll koll på din förbrukningssida på leverantörens webbplats.

## GitHub Models

[GitHub Models](https://github.com/marketplace/models) erbjuder en gratis kvot utan prenumeration. Allt du behöver är ett gratis GitHub-konto och en personlig åtkomsttoken med behörighet att läsa modeller.

**Så här gör du:**

1. Gå till [github.com/settings/tokens](https://github.com/settings/tokens) och skapa en **Personal access token (classic)**.
2. Ge den `models:read`-behörigheten (eller välj bara modellbehörigheten).
3. I Theodia väljer du **GitHub Models** som leverantör och klistar in din token.

**Modeller i den fria kvoten:**

- `openai/gpt-4.1-nano` — **15 anrop per minut, 150 anrop per dag**
- `openai/gpt-4.1-mini` — **15 anrop per minut, 150 anrop per dag**
- `openai/gpt-4.1` — **10 anrop per minut, 50 anrop per dag**
- `openai/gpt-4o` — **10 anrop per minut, 50 anrop per dag**

Dessa gränser nollställs dagligen och räcker gott till regelbunden bibelstudie.

En fullständig steg-för-steg-genomgång med skärmbilder finns i den separata guiden [GitHub Models](theodia://help/github-models).

## En notering om integritet

När du använder en AI-modell på distans visar appen först en dialog om samtycke som förklarar vad som skickas: dina meddelanden, vers- eller kapitelkontext, verktygsanrop och resultat, det konfigurerade modellnamnet samt din API-nyckel i begärans huvud. Begäran går direkt till den slutpunkt du har konfigurerat, inte via Theodia. De flesta leverantörer använder inte dina data för att träna sina modeller, men texten lämnar din enhet. Du kan ändra eller återkalla tillståndet när som helst i **Inställningar → AI-assistent → Delning av AI-data på distans**.

## Sammanfattning

- Du behöver en API-nyckel för att använda AI-assistenten.
- Skapa ett konto hos en leverantör, generera en nyckel och klistra in den i Theodia.
- De flesta frågor kostar några ören eller mindre.
