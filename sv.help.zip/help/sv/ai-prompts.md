---
title: Skriv bättre AI-prompter
level: advanced
categories: ai
summary: Hur du ställer frågor till AI-assistenten så att du får bra svar.
---

# Skriv bättre AI-prompter

> **Läge:** AI-assistenten kräver läget **Scholar**. Du kan byta läge i **Inställningar** → **Appanvändarläge**.

En "prompt" är den fråga eller instruktion du ger AI:n. Bättre prompter ger bättre svar. Den här guiden visar hur.

## Var specifik

Dåligt: "Berätta om kärlek."
Bättre: "Vilken sorts kärlek beskriver Paulus i 1 Korinthierbrevet 13, och hur skiljer den sig från romantisk kärlek?"

Ju mer detaljer du ger, desto mer användbart blir svaret.

## Ge sammanhang

Dåligt: "Vad betyder den här versen?"
Bättre: "Jag läser Romarbrevet 8 med en liten grupp. Vad betyder 'ingen dom' i det här kapitlet, och hur hänger det ihop med resten av kapitlet?"

Sammanhang hjälper AI:n att anpassa sitt svar till din situation.

## Fråga om en sak i taget

Dåligt: "Berätta om bön, tro och helande."
Bättre: "Berätta först om bön. Efter det frågar jag om tro."

Att fråga om en sak i taget håller svaren fokuserade.

## Be AI:n ta en roll

Du kan be AI:n att svara i en viss ton. Till exempel:

- "Svara som om du undervisade en ny kristen."
- "Svara som en bibelforskare."
- "Svara för en tioåring."

AI:n anpassar sitt svar till rollen.

## Använd uppföljningsfrågor

Om det första svaret inte riktigt stämmer, ställ en uppföljning:

- "Kan du säga det enklare?"
- "Kan du ge mig ett exempel?"
- "Vad säger originalgrekiskan?"
- "Var annat i Bibeln förekommer detta?"

En bra konversation är ett fram och tillbaka. AI:n minns de senaste meddelandena.

## Kontrollera AI:ns svar

AI:n kan göra misstag. Den är ett verktyg, inte en lärare.

- Jämför AI:ns svar med de verser den pekar på.
- Använd kommentarerna och lexikonen i appen för en andra åsikt.
- Handlar svaret om läran, fråga en pastor eller en betrodd vän.

## Vanliga promptmönster

Här är några som fungerar bra:

- "Förklara den här versen för mig som om jag var en ny kristen."
- "Vad är huvudpoängen i det här kapitlet, i en mening?"
- "Lista tre tillämpningar för mitt vardagsliv utifrån den här passagen."
- "Vilka frågor bör jag ställa om den här versen innan jag predikar den?"
