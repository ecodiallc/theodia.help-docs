---
title: Appanvändarläge
level: beginner
categories: [user-mode]
summary: Välj mellan Reader, Standard och Scholar för att styra vilka funktioner som finns i appen.
---

# Appanvändarläge

Theodia har tre användarlägen som styr vilka funktioner du ser. Välj det som passar hur du vill använda appen.

## Reader

Det enklaste läget. Reader-läget är för ostörd bibelläsning.

- Läs valfri bibelöversättning
- Använd Fokusläge för ren läsning i helskärm
- Navigera mellan böcker och kapitel
- Inga studieverktyg, ingen AI, inga bokmärken, inga färgmarkeringar

Reader-läget passar dig som vill att Theodia ska kännas som en ren digital Bibel utan extra.

## Standard

Standardläget lägger till vardagsfunktioner för personlig bibelstudie.

Allt i Reader, plus:

- Bokmärken, färgmarkeringar och anteckningar
- Text-till-tal
- Study Mode-läsaren med versmeny
- Parallellbiblar
- Kommandoinmatning
- Sök i Bibeln
- Dagliga andakter och inbyggda böcker

Standardläget är rätt val för de flesta som vill läsa, markera och söka i Bibeln utan avancerade studieverktyg.

## Scholar

Det fullständiga läget. Scholar-läget låser upp alla verktyg i Theodia för djup bibelstudie.

Allt i Standard, plus:

- Kommentarer och lexikon
- Korsreferenser
- Bibelordbok
- Ordinfo (Strong's-uppslag)
- AI-assistenten och AI-kommentar
- Launcher-menyn

Scholar-läget är byggt för pastorer, teologistuderande och alla som vill ha verktyg för originalspråken och AI-stöd i studiet.

## Så byter du läge

1. Öppna **Inställningar**.
2. Tryck på **Appanvändarläge**.
3. Välj **Reader**, **Standard** eller **Scholar**.

Ändringen gäller direkt. Menyer och knappar du inte har tillgång till i ditt nuvarande läge döljs.

## Att välja läge

- **Reader** — Du vill bara läsa Bibeln, inget annat.
- **Standard** — Du vill ha bokmärken, färgmarkeringar, anteckningar, sökning och andakter.
- **Scholar** — Du vill ha alla studieverktyg, inklusive AI, kommentarer och lexikon.

Du kan byta läge när som helst. Dina bokmärken, färgmarkeringar och anteckningar tas aldrig bort när du byter läge; de är bara dolda tills du återvänder till ett läge som stöder dem.
