---
title: Säkerhetskopiera dina data
level: everyday
categories: settings
summary: Hur du sparar och återställer dina anteckningar, färgmarkeringar, bokmärken och hemligheter.
---

# Säkerhetskopiera dina data

Dina anteckningar, färgmarkeringar, bokmärken och inställningar sparas på din enhet. Om du tappar bort telefonen, skaffar en ny eller avinstallerar appen kan data gå förlorad. Den här guiden visar hur du säkerhetskopierar den.

## Så öppnar du säkerhetskopieringsinställningarna

1. Öppna **Inställningar**.
2. Tryck på **Appsäkerhetskopia**.

## Så gör du en appsäkerhetskopia

1. Öppna **Inställningar**.
2. Tryck på **Appsäkerhetskopia**.
3. Tryck på **Skapa appsäkerhetskopia**.
4. Välj en mapp på din enhet där filen ska sparas. Du kan också välja en molnenhet.
5. Appen skapar en enda fil med alla dina data. Filen slutar på `.zip`.

## Hur ofta ska du säkerhetskopiera?

Gör en säkerhetskopia:

- När du har skrivit många anteckningar.
- Innan du uppdaterar enhetens operativsystem.
- Innan du avinstallerar appen eller byter telefon.

En bra vana är en säkerhetskopia i månaden. Vissa säkerhetskopierar varje vecka.

## Så återställer du från en appsäkerhetskopia

1. Öppna **Inställningar**.
2. Tryck på **Appsäkerhetskopia**.
3. Tryck på **Återställ från appsäkerhetskopia**.
4. Välj `.zip`-filen med säkerhetskopian.
5. För varje datatyp (anteckningar, färgmarkeringar, bokmärken och så vidare) väljer du om du vill behålla det som finns på enheten, ersätta det med säkerhetskopian eller hoppa över det.
6. Tryck på **Återställ**.

Appen ersätter dina data med data i säkerhetskopian. Det omfattar:

- Anteckningar
- Färgmarkeringar
- Bokmärken
- Bokmärkesmappar
- Inställningar (tema, textstorlek, språk)

## Säkerhetskopia av hemligheter

Din **Appsäkerhetskopia** omfattar **inte** känsliga hemligheter som din AI-API-nyckel eller GitHub-token. För att säkerhetskopiera dem separat använder du **Säkerhetskopia av hemligheter**.

### Spara en säkerhetskopia av hemligheter

1. Öppna **Inställningar**.
2. Tryck på **Appsäkerhetskopia**.
3. Under **Säkerhetskopia av hemligheter** trycker du på **Spara säkerhetskopia av hemligheter**.
4. Ange ett starkt lösenord och bekräfta det.
5. Appen krypterar dina hemligheter och delar den krypterade filen. Spara den på en säker plats.

### Återställ en säkerhetskopia av hemligheter

1. Öppna **Inställningar**.
2. Tryck på **Appsäkerhetskopia**.
3. Under **Säkerhetskopia av hemligheter** trycker du på **Återställ säkerhetskopia av hemligheter**.
4. Välj den krypterade filen med säkerhetskopian av hemligheter.
5. Ange samma lösenord som du använde när du sparade den.
6. Dina hemligheter återställs.

> **Viktigt:** Om du glömmer lösenordet kan hemligheterna inte återställas. Det finns ingen nollställning.

## Bra att veta

- En återställning **ersätter** de kategorier du valde. Allt du lagt till efter säkerhetskopian går förlorat för de kategorierna.
- En appsäkerhetskopia är en enda `.zip`-fil. Förvara den på en säker plats.
- Du kan kopiera filen, flytta den eller lagra den i valfri molntjänst.
- Appsäkerhetskopior omfattar inte själva bibelöversättningarna. De kan hämtas igen från **Inställningar** → **Hantera resurser**.
- Säkerhetskopior av hemligheter krypteras med ditt lösenord. Välj ett lösenord du kommer ihåg.

## Tips

Har du mer än en enhet kan du kopiera säkerhetskopian till varje enhet och återställa den där. Dina data blir desamma på båda.
