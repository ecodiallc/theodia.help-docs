---
title: Bokmärka verser
level: everyday
categories: [annotate, read]
summary: Hur du sparar verser så att du kan hitta dem igen.
---

# Bokmärka verser

> **Läge:** Bokmärken finns i lägena **Standard** och **Scholar**. Fokusläget är endast för ren, ostörd läsning. Du kan byta läge i **Inställningar** → **Appanvändarläge**.

Ett bokmärke sparar en vers eller ett bokkapitel så att du kan hitta det igen. Bokmärken är som lappar i en bok.

## Så bokmärker du en vers

1. Öppna versen.
2. Tryck på versen för att visa menyn.
3. Tryck på **Bokmärke** i menyn. En stjärnikon markerar versen som sparad.

En bock på ikonen betyder att versen nu är bokmärkt.

## Så bokmärker du ett bokkapitel

När du läser en bok (inte en Bibel) kan du bokmärka hela kapitlet:

1. Öppna kapitlet.
2. Tryck på **Bokmärke**-ikonen högst upp på skärmen.

## Så ser du dina bokmärken

Tryck på fliken **Bokmärken** längst ner. Du ser en lista över varje vers och bokkapitel du har sparat.

## Så tar du bort ett bokmärke

- **En vers:** Öppna versen. Tryck på versen och sedan på **Bokmärke**-ikonen igen. Bocken försvinner.
- **Från listan:** I fliken **Bokmärken** håller du nere ett bokmärke. En liten meny visas. Tryck på **Ta bort**. (Du kan också trycka på den lilla ×-knappen på raden.)

## Organisera med mappar

Du kan lägga bokmärken i mappar. Du kan till exempel ha en mapp som heter "Predikoförberedelse" och en annan som heter "Uppmuntran".

Så här skapar du en mapp:

1. Öppna fliken **Bokmärken**.
2. Tryck på **Hantera mappar** högst upp.
3. Tryck på **+ Skapa mapp** högst upp i mapplistan.
4. Skriv ett namn och tryck på **Spara**.

Du kan inte skapa två mappar med samma namn. Finns namnet redan visas ett felmeddelande i rutan för att skapa mapp, så att du kan ändra det och försöka igen.

Så här lägger du ett bokmärke i en mapp:

1. I fliken **Bokmärken** håller du nere ett bokmärke.
2. Tryck på **Spara i mapp**.
3. Välj mappen och tryck sedan på **Klar**.

## Importera bokmärken

Du kan föra in bokmärken i Theodia från andra appar och filer.

Gå till **Inställningar** → **Bokmärken** → **Importera bokmärken**. Välj **Importera från fil** eller klistra in från urklipp. Appen känner automatiskt av formatet.

### Format som stöds

**Inbyggd JSON-export** — Formatet som används av Theodias egen exportfunktion. Det bevarar mappar och skapandedatum.

**Netscape Bookmark HTML** — Formatet som Chrome, Firefox och Safari använder när du exporterar bokmärken. Mappar bevaras.

**CSV** — Ett kalkylblad med kolumner. Appen letar efter kolumnerna `url` och `folder` (eller `href` / `category`). Exempel:

```csv
url,folder
/bible/KJV/John/3,Favorites
/bible/KJV/Genesis/1,Sermon Prep
```

**Vanlig text** — Varje rad är antingen en bibelreferens, en app-URL eller ett mappanvisning. Exempel:

```
folder: Favorites
John 3:16
Genesis 1:1
folder: Sermon Prep
Matthew 5:1
```

- Rader som börjar med `folder: <namn>` ställer in den aktiva mappen för alla efterföljande bokmärken.
- Bibelreferenser som `John 3:16` omvandlas till bokmärken i din standardbibel.
- App-URL:er som `/bible/KJV/John/3#v3_16` eller `/book/MyBook/1` importeras direkt.
- Rader som börjar med `#` eller `//` behandlas som kommentarer och hoppas över.

### Tips för import

- Dubblettbokmärken hoppas över automatiskt.
- Externa URL:er (som länkar till BibleGateway) omvandlas till appbokmärken när det är möjligt.
- Finns en mapp från importfilen redan placeras bokmärkena i den befintliga mappen.

## Tips

- Du kan bokmärka samma vers i många översättningar. Alla visas i listan.
- Bokmärken stannar på din enhet. De synkas inte till molnet.
- Se guiden [Säkerhetskopiera dina data](theodia://help/backups) för att hålla dem säkra.

## Bokmärken i PDF-filer

PDF-filer har sina egna bokmärken, hållna åtskilda från dina bibelbokmärken. Medan du läser en PDF trycker du på **Bokmärke**-knappen i läsarens verktygsfält för att spara den aktuella sidan, ge den ett namn och senare hoppa tillbaka till den. Varje PDF har sin egen lista — se [PDF-filer](theodia://help/pdfs).
