---
title: Välja en AI-modell
level: advanced
categories: ai
summary: Så väljer du en modell som fungerar bra med Theodias inbyggda verktyg och förmågor.
---

# Välja en AI-modell

> **Läge:** AI-assistenten kräver läget **Scholar**. Du kan byta läge i **Inställningar** → **Appanvändarläge**.

Alla AI-modeller fungerar inte på samma sätt i Theodia. Bäst upplevelse får du med en modell som stöder **tool calling** — AI:ns förmåga att använda Theodias inbyggda funktioner som att slå upp bibelverser, söka, läsa kommentarer och navigera i appen.

## Vad är tool calling?

När du ställer en fråga till Theodias AI kan den göra mer än att bara prata. Den kan också **agera**. Till exempel:

- Du säger: "Visa mig Johannes 3:16 i ESV." AI:n anropar ett verktyg som öppnar versen i läsaren.
- Du säger: "Vad säger mina kommentarer om Romarbrevet 8:28?" AI:n anropar ett verktyg som hämtar kommentarinnehållet.
- Du säger: "Spara den här versen som bokmärke." AI:n anropar ett verktyg som skapar bokmärket.

Modeller som inte stöder tool calling kan bara ge dig textsvar. De kan inte slå upp saker, navigera eller ändra något i appen.

## Vilka modeller stöder verktyg?

### Modeller på distans

De flesta moderna modeller på distans från stora leverantörer stöder OpenAI-kompatibel tool calling. I allmänhet:

- **Stora modeller** (som GPT-4o, Claude Sonnet/Opus, Gemini Pro) hanterar verktyg tillförlitligt och kan kedja flera verktygsanrop i en konversation. Leverantörsnamn och modell-ID visas i appen för enkelhetens skull; den tjänst du faktiskt ansluter till är den vars slutpunkt och nyckel du konfigurerar.
- **Mindre eller billigare modeller** kan stöda verktyg men är kanske mindre tillförlitliga. De kan ignorera ett verktygsanrop eller formatera det fel.
- **Mycket gamla eller specialiserade modeller** stöder ofta inte verktyg alls.

Om du är osäker, testa modellen i Theodia. Be den "Visa mig 1 Mosebok 1:1" eller "Sök i Bibeln efter verser om kärlek." Öppnas versen eller visas sökresultaten fungerar tool calling.

## Rekommenderade modeller för Theodia

Det här är bra val som balanserar kostnad, kvalitet och verktygsstöd:

- **OpenAI GPT-4o** — utmärkt verktygsstöd, snabb, hanterar komplexa flerstegsfrågor bra.
- **Anthropic Claude Sonnet / Opus** — mycket tillförlitlig verktygsanvändning, utmärkt för långa passager och detaljerad studie.
- **Groq** (olika modeller) — snabb inferens, ofta gratis eller mycket billig, verktygsstödet varierar mellan modeller.
- **OpenRouter** — låter dig prova många modeller från ett konto. Leta efter modeller som anger "function calling" eller "tools" bland sina förmågor.
- **[GitHub Models](theodia://help/github-models)** — den rekommenderade gratisleverantören. Tillgång till OpenAI, Anthropic och andra modeller via ditt GitHub-konto med en generös daglig gratis kvot. Använder samma typ av modell-ID:n som `openai/gpt-4o`.

## Modeller att undvika

- **Rena textfortsättningsmodeller** (som GPT-3 base eller rå LLaMA utan instruktionsträning) stöder vanligen inte verktyg.
- **Bild- eller visionsmodeller** som fokuserar på bilder i stället för text saknar kanske verktygsstöd.
- **Extremt små modeller** under 1 miljard parametrar använder sannolikt inte verktyg rätt, även om API:et hävdar att de stöder dem.

## Så testar du verktygsstödet

Theodia kontrollerar verktygsstöd automatiskt. När du har konfigurerat en modell i **Inställningar → AI-assistent** trycker du på **Testa anslutning**. När anslutningen lyckats skickar appen en andra begäran med en exempelverktygsdefinition. Du ser ett av två resultat:

- **✓ Verktyg stöds** — Modellen tar emot verktygsanrop och kan använda Theodias inbyggda funktioner.
- **✗ Verktyg stöds inte** — Modellen avvisar verktygsbegäran. Den svarar bara i text och kan inte öppna verser, söka eller hantera bokmärken åt dig.

Ser du "Verktyg stöds inte" kan modellen ändå fungera som en enkel textchattassistent, men du får inte den integrerade upplevelsen utan händer.

Du kan också kontrollera manuellt genom att be AI:n göra något:

- "Visa mig Matteus 5:3 i KJV." — Ska öppna versen i läsaren.
- "Vad säger lexikonet om ordet 'agape' i Johannes 3:16?" — Ska returnera lexikondata.
- "Sök i Bibeln efter verser om förlåtelse." — Ska returnera sökresultat.
- "Bokmärk Markus 12:30." — Ska skapa ett bokmärke.

Ger AI:n dig en textbeskrivning i stället för att faktiskt göra saken har modellen svårt att använda sina verktyg, även om appen rapporterade stöd.

## Vad gör jag om min modell inte stöder verktyg?

Du kan ändå använda den. AI:n svarar i text, och du kan själv slå upp verser, söka och navigera i appen. Men du missar den upplevelse utan händer som gör Theodia kraftfull.

## Sammanfattning

- Välj en modell med stöd för **tool calling / function calling** för bästa Theodia-upplevelse.
- **Stora modeller på distans** hanterar verktyg mest tillförlitligt.
- Testa valfri modell med enkla kommandon som "Visa mig 1 Mosebok 1:1" för att bekräfta verktygsstödet.
