---
title: Kommandon
level: everyday
categories: [layout, study]
summary: Kommandoinmatningen låter dig hoppa till valfri funktion genom att skriva ett kort kommando. Lär dig formaten och exemplen.
---

# Kommandon

**Kommando**-inmatningen låter dig hoppa till nästan vilken del av Theodia som helst genom att skriva en kort instruktion. Du kan använda den från Hem-fliken eller från **Launcher-menyn** (**▼**-ikonen i sidhuvudet).

## Så fungerar det

1. Tryck på kommandorutan.
2. Skriv ett kommando.
3. Tryck på kör-tangenten på ditt tangentbord.

Appen läser kommandot och tar dig direkt till rätt skärm.

## Inget snedstreck framför

Kommandon använder **inte** prefixet `/`. De skrivs in som vanlig text:

```
john 3:16
search love
backup
```

Skriver du `/settings` gör det inledande `/` kommandot oigenkännligt.

## Bibelreferenser

Skriv valfri bibelreferens för att öppna den i läsaren.

```
psalms 23
john 3:16
matthew 5:1
1 cor 15:10
```

Boknamn kan matchas med fullständigt namn eller förkortning. I gränssnittsspråk annat än engelska kan du också skriva boknamn på det aktiva språket.

## Sök

```
search abraham
search love
search faith not works
```

## Bokmärken, jämför, kommentar, korsreferenser och ordinfo

```
bookmark john 3:16
compare genesis 1:1
commentary john 1
aicommentary eph 2:8
xref 1 cor 15:10
word info john 1:1
```

Dessa kommandon öppnar det namngivna verktyget för den angivna passagen.

## Lexikon

Skriv ett Strong's-nummer för att öppna lexikonposten.

```
g1161
h7225
```

## Andakter

```
devotional
devotional smith
devotional daily
```

Utan namn öppnas andaktslistan.

## Navigeringsgenvägar

```
notes
highlights
bookmarks
flashcards
playlist
theoscript
resources
read john 3:16
```

Dessa hoppar direkt till den namngivna skärmen eller öppnar en passage i läsaren.

## Byte av översättning

Skriv en översättningsförkortning för att byta till den.

```
kjv
web
trlit
ohgb
```

På en läsarskärm byts översättningen på plats. Annanstans öppnas översättningen vid din senaste passage.

## Översatta kommandoverb

De offentliga kommandoverben kan skrivas på det aktiva gränssnittsspråket **eller** på engelska. Engelska fungerar alltid som reserv. Dolda kommandon (inställningsgenvägar, installationskommandon, påskägg) behåller endast engelsk syntax.

## Hjälp

Skriv `help` eller `commands` i kommandorutan för att öppna appens kommandoreferens när som helst.
