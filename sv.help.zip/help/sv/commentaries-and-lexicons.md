---
title: Kommentarer och lexikon
level: everyday
categories: study
summary: Hur du slår upp ordens betydelser och läser studieanteckningar.
---

# Kommentarer och lexikon

> **Läge:** Kommentarer och lexikon kräver läget **Scholar**. Du kan byta läge i **Inställningar** → **Appanvändarläge**.

Theodia har två studieverktyg: **kommentarer** och **lexikon**. De hjälper dig att förstå Bibeln på större djup.

## Vad är en kommentar?

En kommentar är en bok med studieanteckningar skrivna av en bibelforskare. För en viss vers berättar en kommentar om bakgrunden, betydelsen och hur versen passar in i resten av Bibeln.

## Vad är ett lexikon?

Ett lexikon är en ordbok för bibliska ord. Det berättar vilket hebreiskt eller grekiskt ord det ursprungligen var, vad det betyder och hur det används i Bibeln.

## Så öppnar du en kommentar

1. Öppna ett kapitel.
2. Tryck på en vers.
3. Tryck på **Kommentar**.

En panel öppnas. Den visar anteckningar från en bibelforskare om den versen.

## Så öppnar du ett lexikon

1. Öppna ett kapitel i en Bibel som innehåller Strong's-nummer.
2. Tryck på ett Strong's-nummer i versen (till exempel G1234 eller H1234).
3. En panel öppnas med det hebreiska eller grekiska originalordet, dess betydelse och andra verser där ordet används.

Strong's-numren har en annan färg i versens text så att de syns tydligt bland de vanliga orden.

## Välj en annan kommentar

Kommentaren väljs i en rullgardinsmeny högst upp i kommentarspanelen själv. Öppna panelen och tryck sedan på rullgardinsmenyn för att se de kommentarer du har installerat. Välj en annan.

## Välj ett annat lexikon

Lexikonet väljs i en rullgardinsmeny högst upp i lexikonpanelen. Öppna panelen och tryck sedan på rullgardinsmenyn för att se de lexikon du har installerat. Välj ett annat.

## Inbyggda resurser

Theodia levereras med en inbyggd uppsättning kommentarer och lexikon. De följer med appen och fungerar offline. Ytterligare kommentarer och lexikon kan inte installeras eller hämtas separat.

## När passar de?

- **Kommentarer** är bra när en vers är svår att förstå. Anteckningarna ger dig bakgrunden.
- **Lexikon** är bra för ordstudier. De ger dig ordets exakta betydelse i originalspråket.

## Tips

Har en vers en anteckning du vill spara kan du ta en skärmdump eller kopiera texten till en anteckning. (Se guiden [Skriva anteckningar](theodia://help/notes).)

## Bibelordbok i vardagligt språk

För förklaringar på engelska av bibliska ord och begrepp (förbund, försoning, fariséer och så vidare) har Theodia också ett verktyg som heter Bibelordbok. Öppna det från versmenyn genom att trycka på **Ordbok** (📖). Den skiljer sig från lexikonet: lexikon förklarar de hebreiska och grekiska originalorden, medan ordboken förklarar det engelska ordet i vardagligt språk. Se guiden [Bibelordboken](theodia://help/dictionary) för hur du använder den.
