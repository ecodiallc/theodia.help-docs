---
title: Vanliga problem
level: everyday
categories: trouble
summary: Snabba lösningar på problem du kan stöta på.
---

# Vanliga problem

Den här guiden tar upp de problem folk stöter på oftast. Finns inte ditt problem här, se guiden [Var ställer jag frågor](theodia://help/getting-more-help).

## Appen är långsam

1. Stäng andra appar som kör i bakgrunden.
2. Starta om appen.
3. Starta om din enhet.

## Jag hittar inte en bibelöversättning

1. Öppna **Inställningar** → **Hantera resurser** för att se vad som är installerat.
2. Finns översättningen inte där trycker du på **Installera från GitHub**.
3. I nedladdningsfönstret trycker du på fliken **Biblar** (eller **Globala biblar**) och väljer den översättning du vill ha.
4. Tryck på **Installera valda** och vänta tills nedladdningen är klar.
5. Du behöver internet för att hämta en ny översättning.

## Mina anteckningar eller bokmärken är borta

1. Kontrollera att du tittar på rätt flik. Anteckningar finns i fliken **Anteckningar**. Bokmärken finns i fliken **Bokmärken**.
2. Har du nyligen återställt en säkerhetskopia kan den ha ersatt dina data. Kontrollera säkerhetskopians datum.
3. Har du avinstallerat och installerat om appen är dina data borta. Nästa gång gör du först en säkerhetskopia.

## Sökningen hittar inte verser

1. Kontrollera att du stavat ordet rätt.
2. Prova ett kortare ord. "Love" hittar fler verser än "loving."
3. Kontrollera att du har rätt bibelöversättning installerad. Sökning fungerar bara i de översättningar du har.

## Uppläsning fungerar inte

1. Kontrollera att enhetens volym är uppslagen.
2. Kontrollera att appen får använda högtalaren.
3. Prova en annan översättning. Vissa översättningar fungerar bättre med uppläsning än andra.
4. En steg-för-steg-checklista finns i guiden [Läsa upp högt](theodia://help/tts).

## Appen kraschar hela tiden

1. Starta om appen.
2. Starta om din enhet.
3. Fortsätter problemet, rapportera det gärna. Se guiden [Var ställer jag frågor](theodia://help/getting-more-help).

## Jag vill avinstallera appen

Du kan avinstallera Theodia som vilken annan app som helst. Gör först en säkerhetskopia av dina data. Efter avinstalleringen är data på enheten borta.

## Fastnar du fortfarande?

Se guiden [Var ställer jag frågor](theodia://help/getting-more-help). Där hittar du länkar för att rapportera ett problem och fråga gemenskapen.

Du kan också söka i hjälpguiderna från huvudskärmen **Hjälp & guider**. Skriv ett ord som `notifications`, `search` eller `bookmarks` för att hitta rätt guide.
