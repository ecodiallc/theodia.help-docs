---
title: Jämföra översättningar
level: everyday
categories: [read, study]
summary: Hur du ser samma vers i varje översättning du har installerat.
---

# Jämföra översättningar

> **Läge:** Verktyget Jämför finns i lägena **Standard** och **Scholar**. Fokusläget är endast för ren, ostörd läsning. Du kan byta läge i **Inställningar** → **Appanvändarläge**.

Verktyget **Jämför** visar en enda vers i varje bibelöversättning du har installerad, allt i en panel. Det är praktiskt när du vill se hur olika översättare hanterar en svår vers, eller när du väljer översättning och vill se samma vers i var och en.

## Så öppnar du Jämför

1. Öppna ett kapitel i valfri översättning.
2. Tryck på en vers för att visa versmenyn.
3. Tryck på **Jämför** (⇄).

En panel öppnas. Rubrikraden visar referensen (till exempel "Johannes 3:16 — Jämför"). Panelen listar samma vers i varje installerad översättning. Din nuvarande översättning listas först; de övriga är sorterade i bokstavsordning.

## Så ser panelen ut

Panelen är en **vertikal lista**, inte kolumner sida vid sida. Varje rad är en översättning:

- **Översättningens namn** (till exempel "KJV") ligger överst på raden. Det går att trycka på.
- **Versens text** finns under namnet.

Rulla panelen för att se alla översättningar. Varje översättning som är installerad på din enhet visas här. Har en översättning inte den boken eller versen lämnas den bort.

## Så läser du versen i en annan översättning

Tryck på översättningens namn på raden. Panelen Jämför stängs och samma kapitel öppnas med den valda versen visad i den översättningen. Det är det snabbaste sättet att hoppa från en jämförelse rakt in i läsning av en bestämd översättning.

## Så stänger du Jämför

- **På en telefon:** tryck på X:et längst upp till höger på panelen.
- **På en surfplatta:** tryck på X:et i panelens sidhuvud, eller tryck utanför panelen.

Du är tillbaka i kapitelvyn i din ursprungliga översättning.

## När passar Jämför?

- **Att välja översättning.** Öppna en vers du känner väl i din nuvarande översättning och jämför sedan för att se den i andra. Skillnaderna syns tydligt.
- **Svåra verser.** En vers som är förvirrande i en översättning är ofta tydligare i en annan.
- **Ordstudier.** Se hur olika översättare hanterar ett nyckelord eller en nyckelfras.

För en överblick av ett helt kapitel i flera översättningar på en gång använder du i stället **parallelvyn**. Se guiden [Study Mode](theodia://help/study-mode) för hur du slår på den.
