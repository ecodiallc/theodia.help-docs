---
title: Skapa egna resurser
level: advanced
categories: resources
summary: Hur du skapar egna biblar, kommentarer, böcker, andakter och lexikon och importerar dem i Theodia.
---

# Skapa egna resurser

Theodia stöder egna resurser i Unique Bible App-formatet. Varje resurs är en SQLite-fil med en bestämd tabellstruktur. Du kan skapa dessa filer på en dator och importera dem i appen.

## Filtyper och obligatoriska tabeller

### Biblar (`.bible`)

En bibelfil är en SQLite-databas med minst en av dessa tabeller:

- **`Verses`** — kolumner: `Book` (heltal, 1-66), `Chapter` (heltal), `Verse` (heltal), `Scripture` (text)
- **`Bible`** — kolumner: `Book` (heltal), `Chapter` (heltal), `Verse` (heltal), `Scripture` (text)

Du kan också lägga till en **`Details`**-tabell med metadatakolumner som `Description`, `Abbreviation` och `Version`.

Exempel på SQL:

```sql
-- Main text table
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- Optional metadata table
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### Kommentarer (`.commentary`)

Kommentarer finns i tre typer: **bok**, **kapitel** och **vers**. Typen bestäms av den **första bokstaven i filnamnet**.

#### Bokkommentarer — filnamnet börjar med `b`

En bokkommentar täcker en hel bok i Bibeln i en enda post. Tabellen `Commentary` behöver kolumnerna `Book` och `Scripture` (eller `Content`). Inga kolumner `Chapter` eller `Verse` behövs.

- **`Commentary`** — kolumner: `Book` (heltal), `Scripture` (text) eller `Content` (text)

Exempel på SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

Exempel på filnamn: `bMyCommentary.commentary`

#### Kapitelkommentarer — filnamnet börjar med `c`

En kapitelkommentar täcker varje kapitel i en bibelbok.

- **`Commentary`** — kolumner: `Book` (heltal), `Chapter` (heltal), `Scripture` (text) eller `Content` (text)

Exempel på SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

Exempel på filnamn: `cMyCommentary.commentary`

#### Verskommentarer — filnamnet börjar med `v`

En verskommentar täcker enskilda verser. Tabellen `Commentary` behöver kolumnerna `Book`, `Chapter`, `Verse` och `Scripture` (eller `Content`).

- **`Commentary`** — kolumner: `Book` (heltal), `Chapter` (heltal), `Verse` (heltal), `Scripture` (text) eller `Content` (text)

Exempel på SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

Exempel på filnamn: `vMyCommentary.commentary`

### Böcker (`.book`)

En bokfil är en SQLite-databas med en `Reference`-tabell.

- **`Reference`** — kolumner: `id` (heltal), `Chapter` (text), `Content` (text)

Varje rad är ett kapitel. Kolumnen `Chapter` är kapitelrubriken. Kolumnen `Content` är kapiteltexten, som kan innehålla HTML (`<b>`, `<i>`, `<br>` och så vidare).

Exempel på SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

Du kan också skapa böcker från Markdown-filer. Appen kan importera `.md`-filer där `#` är boktiteln och `##` markerar kapitel. Markdownen konverteras automatiskt till HTML.

### Andakter (`.devotional`)

En andaktsfil är en SQLite-databas med en `devotional`-tabell.

- **`devotional`** — kolumner: `month` (heltal, 1-12), `day` (heltal, 1-31), `devotion` (text)

Varje rad är en dags läsning. Appen slår upp posten efter dagens månad och dag.

Exempel på SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### Lexikon (`.lexicon`)

En lexikonfil är en SQLite-databas med en `Lexicon`-tabell.

- **`Lexicon`** — kolumner: `Topic` (text, Strong's-numret), `Definition` (text, lexikonposten)

Kolumnen `Topic` innehåller Strong's-numret (till exempel `G1161` eller `H7225`). Kolumnen `Definition` innehåller hela postens text, som kan innehålla HTML.

Exempel på SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

Lexikon driver verktyget Ordinfo. När du trycker på ett ord i en interlinearbibel slår appen upp Strong's-numret i de installerade lexikonen.

## Skapa en fil på datorn

1. Installera en SQLite-redigerare (DB Browser for SQLite, SQLiteStudio eller kommandoradsverktyget `sqlite3`).
2. Skapa en ny databasfil.
3. Skapa den obligatoriska tabellen och lägg in dina data.
4. Spara filen med rätt filändelse (`.bible`, `.commentary`, `.book`, `.devotional` eller `.lexicon`).

## Importera i Theodia

1. Överför filen till din enhet (AirDrop, e-post, molnlagring eller USB).
2. Öppna **Theodia**.
3. Gå till **Inställningar** → **Hantera resurser**.
4. Tryck på **Importera från fil**.
5. Välj din fil.

Appen kontrollerar filen (letar efter den obligatoriska tabellen), kopierar den till appens datamapp och aktiverar den automatiskt. Är filen ogiltig får du ett felmeddelande som förklarar vad som är fel.

## Begränsningar

- Du kan inte skriva över inbyggda resurser. Försöker du importera en fil med samma namn som en inbyggd bibel, kommentar eller bok misslyckas importen.
- Bibelfiler behöver en `Verses`- eller `Bible`-tabell. Finns ingen av dem misslyckas importen.
- Kommentarfiler behöver en `Commentary`-tabell.
  - Bokkommentarer behöver kolumnerna `Book` och `Scripture` (eller `Content`).
  - Kapitelkommentarer behöver kolumnerna `Book`, `Chapter` och `Scripture` (eller `Content`).
  - Verskommentarer behöver kolumnerna `Book`, `Chapter`, `Verse` och `Scripture` (eller `Content`).
- Bokfiler behöver en `Reference`-tabell.
- Lexikonfiler behöver en `Lexicon`-tabell.
- Andaktsfiler behöver en `devotional`-tabell.

## Tips

- Håll filstorleken rimlig. Mycket stora SQLite-filer kan ge minnesproblem på äldre enheter.
- Testa din fil på en dator först. Öppna den i en SQLite-webbläsare och kör `SELECT * FROM` på den obligatoriska tabellen för att kontrollera att data ser rätt ut.
- För biblar, kontrollera att kolumnen `Book` använder nummer (1 = Genesis, 66 = Uppenbarelseboken).
- För kommentarer kan du använda antingen `Scripture` eller `Content` som textkolumn.
- För böcker renderas HTML i kolumnen `Content` vid läsning. Håll det enkelt: `<b>`, `<i>`, `<br>` och `<hr>` är säkra.

## Var hittar du befintliga resurser?

Theodia kan läsa resurser från projektet [Unique Bible App](https://github.com/eliranwong/UniqueBible). Många biblar, kommentarer, böcker och andra resurser finns där i rätt SQLite-format. Se guiden [Hämta extra resurser](theodia://help/getting-core-files) för hur du hittar och lägger till dem.
