---
title: Korsreferenser
level: everyday
categories: study
summary: Hur du hittar verser som hör ihop med den du läser.
---

# Korsreferenser

> **Läge:** Korsreferenser finns i lägena **Standard** och **Scholar**. Fokusläget är endast för ren, ostörd läsning. Du kan byta läge i **Inställningar** → **Appanvändarläge**.

En "korsreferens" är en annan vers som talar om samma sak som versen du läser. Korsreferenspanelen visar vilka verser i Bibeln som hör ihop med varandra.

## Så öppnar du korsreferenserna

1. Öppna ett kapitel.
2. Tryck på en vers för att visa versmenyn.
3. Tryck på **Korsreferenser**.

En panel öppnas. Den visar en lista över andra verser som hör ihop med den du tryckte på.

## Så läser du listan

Varje rad är en sammanhängande vers. Du ser:

- Boken, kapitlet och versen.
- En kort förhandsvisning av versens text.
- Ett poängvärde som visar hur stark kopplingen är.

## Så hoppar du till en sammanhängande vers

Tryck på valfri rad. Appen öppnar versen åt dig. När du är klar trycker du på tillbakaknappen för att återvända.

## Vad poängvärdet betyder

Poängvärdet talar om hur nära verserna hör ihop. Ett högt värde betyder en stark, direkt koppling. Ett lågt värde betyder en lösare koppling.

## Använd korsreferenser i studiet

Korsreferenser är användbara för:

- **Ordstudier.** Se hur Bibeln använder ett ord på olika ställen.
- **Temastudier.** Spåra ett tema, som "kärlek" eller "förbund", genom Skriften.
- **Predikoförberedelse.** Hitta stödverser snabbt.

## Tips

Korsreferenser fungerar bäst med en ord-för-ord-översättning som WEB.
