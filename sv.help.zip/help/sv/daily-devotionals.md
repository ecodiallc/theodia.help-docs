---
title: Dagliga andakter
level: everyday
categories: [content, read]
summary: Hur du läser en kort andakt varje dag.
---

# Dagliga andakter

En andakt är en kort läsning för en dag. Den har ofta en vers, en kort tanke och en fråga att fundera över. Theodia kommer med ett litet bibliotek av andakter.

## Så öppnar du en andakt

1. Tryck på fliken **Andakter** längst ner på skärmen.
2. Du ser en lista över de andakter som är installerade på din enhet.
3. Tryck på en för att öppna den.

## Så läser du en andakt

1. Öppna andakten.
2. Rulla för att läsa.
3. Använd knapparna överst för att:
   - Trycka på **datumet** för att hoppa till en annan dag.
   - Trycka på **stjärnan** för att bokmärka dagen.
   - Trycka på **högtalaren** för att läsa den högt (om din enhet stöder det). Se guiden [Läsa upp högt](theodia://help/tts) för hur du väljer röst.
   - Trycka på **Föregående** eller **Nästa** för att gå till dagen före eller efter.

## Så sparar du en vers från en andakt

1. Öppna andakten.
2. Tryck på en vers.
3. Tryck på **Bokmärke** eller **Färgmarkera**.

Versen sparas i dina bokmärken eller färgmarkeringar.

## Så skriver du en anteckning på en andakt

1. Öppna andakten.
2. Tryck på en vers.
3. Tryck på **Anteckning**. Skriv din reflektion eller bön. Tryck på **Spara**.

Anteckningen visas i fliken Anteckningar.

## Tips

- Andakter behöver inte internet. De fungerar offline.
- Vill du ha fler andakter, se guiden [Hämta extra resurser från GitHub](theodia://help/getting-core-files).
