---
title: Bibelordboken
level: everyday
categories: study
summary: Slå upp bibliska ord och begrepp i installerade ordboksresurser. Öppna den från versmenyn eller från en lexikonpost, och tryck på valfritt ord för att se samma ord i varje ordbok.
---

# Bibelordboken

> **Läge:** Bibelordboken kräver läget **Scholar**. Du kan byta läge i **Inställningar** → **Appanvändarläge**.

Verktyget Bibelordbok slår upp ett ord eller en fras i varje ordboksresurs du har installerad. Det är praktiskt när du vill ha en förklaring i vardagligt språk av ett bibliskt ord, en beskrivning av en person eller plats, eller en kort artikel om ett teologiskt begrepp.

Bibelordboken skiljer sig från verktyget **Ordinfo**, som slår upp det hebreiska eller grekiska ordet bakom en vers. Ordboken läser det **engelska** ord du trycker på och visar vad dina installerade ordböcker säger om det. För anteckningar i ord-för-ord-bibelöversättningar, se guiden [Kommentarer och lexikon](theodia://help/commentaries-and-lexicons).

## Så öppnar du ordboken

Det finns två sätt att öppna ordboken.

### Från versmenyn

1. Öppna ett kapitel i [Study Mode](theodia://help/study-mode).
2. Tryck på en vers för att öppna versmenyn.
3. Tryck på **Ordbok** (📖).

En panel öppnas med versreferensen som rubrik (till exempel "Johannes 3:16"). Versens text ligger överst med varje ord tryckbart. Under versen finns en rad med "chips" som visar varje installerad ordbok. Under den finns förklaringen, som är tom tills du trycker på ett ord.

### Från en lexikonpost

När du läser en lexikonpost i Ordinfo-panelen innehåller vissa poster blå länkar till relaterade ordboksartiklar. Tryck på valfri sådan länk. Lexikonet stängs och ordboken öppnas vid den artikeln. Det är det snabbaste sättet att hoppa från ett grekiskt eller hebreiskt ord till en förklaring i vardagligt språk av vad det betyder.

## Så fungerar versvyn

Öppnar du ordboken från en versmeny visas versen överst i panelen som en lista med tryckbara ord. Vanliga engelska ord som "the", "and", "of", "to" och "a" går inte att trycka på. Alla andra ord gör det. Varje tryckbart ord är färgat och fetstilt så att det syns mot resten av versen.

Tryck på valfritt ord i versen. Theodia söker i varje installerad ordbok efter en exakt träff på det ordet. Chipraden längst ner uppdateras för att visa vilka ordböcker som har en post: ordböcker som inte har en post för ordet tonas ned. Den första ordboken med en post väljs automatiskt, och dess förklaring visas under chipraden.

Ordet du tryckte på är markerat i versens text överst i panelen, så att du alltid vet vad du slår upp.

## Att växla mellan ordböcker

Varje installerad ordbok visas som en liten "chip" under versen. När du tryckt på ett ord:

- **Mättad färg** på chipet — den här ordboken har en post för ordet du tryckte på. Tryck på den för att växla till den ordbokens förklaring.
- **Tonat ned** chip — den här ordboken har ingen post för ordet. Det visas nedtonat så att du på en blick ser vilka ordböcker som täcker ordet, och chipet kan inte tryckas på.

Den valda ordboken är framhävd. Tryck på valfritt annat mättat chip för att läsa samma ord i den ordboken. Förklaringen under uppdateras omedelbart.

Finns ordet bara i en av dina installerade ordböcker är bara det chipet mättat och de övriga tonade ned.

## Vad panelen visar

Ordbokspanelen har tre delar, uppifrån och ned:

- **Versen** — versen du öppnade ordboken från. Orden är tryckbara, och ordet du senast tryckte på är markerat.
- **Chipraden** — varje installerad ordbok. Mättad färg betyder "har en post för det tryckta ordet". Tonad betyder "ingen post för det ordet".
- **Förklaringen** — artikeln från den valda ordboken. Vanlig text, formaterad med stycken och rubriker. Inre länkar till andra ordboksposter är tryckbara; trycker du på en av dem öppnas den posten i ordboken.

## Vad händer om ingen post hittas

Trycker du på ett ord som ingen av dina installerade ordböcker täcker visar panelen ett kort meddelande om att "inga poster hittades" i stället för en förklaring. Det är vanligt för mycket vanliga ord som "year" eller "come" som inte egentligen är ord inom bibeteologin, även om de förekommer överallt i Bibeln. Prova ett mer specifikt ord, eller använd lexikonets Ordinfo-verktyg i stället, som arbetar på den underliggande grekiska och hebreiska texten.

## Vad händer om ingen ordbok är installerad

Ordboken behöver minst en ordboksresursfil för att vara användbar. Theodia levereras med en. Har du tagit bort den eller kör en egen installation utan ordböcker visas versvyn fortfarande och orden är fortfarande tryckbara, men chipraden är tom och varje sökning returnerar "inga poster hittades".

Ytterligare ordböcker kan inte installeras separat.

## Tips

- Ordboken söker efter **exakta ordträffar**. Trycker du på "love" hittas poster med rubriken "love" men inte "loved" eller "loving". För att slå upp en relaterad form använder du lexikonets Ordinfo-verktyg på det grekiska eller hebreiska ordet.
- Chipraden är samma på telefoner och surfplattor. På en surfplatta öppnas ordboken som sidopanel bredvid kapitlet; på en telefon öppnas den som ett helskärmsfönster. Båda har samma tresparlayout.
- Trycker du på ett ord i en annan vers öppnas en ny vers i panelen. Ditt tidigare val rensas. Tryck på ett ord i den nya versen för att påbörja ett nytt uppslag.
- Vissa ordboksposter hänvisar till samma ord i en annan ordbok. Tryck på de inre länkarna för att följa spåret genom alla dina installerade ordböcker.

## Skillnader mellan Ordbok och Ordinfo

Båda verktygen öppnas från versmenyn, men de gör olika saker:

- **Ordbok** (📖) läser det engelska ord du trycker på och hittar det i dina installerade engelska ordböcker. Det är rätt verktyg för förklaringar i vardagligt språk av ord inom bibeteologin som "covenant", "atonement" eller "Pharisee".
- **Ordinfo** (?) läser det grekiska eller hebreiska ordet bakom versen och hittar det i dina installerade lexikon. Det är rätt verktyg för seriösa ordstudier, för att hitta alla ställen ett grekiskt ord används, och för att läsa definitionerna på originalspråket.

Tvekar du, börja med ordboken. Vill du gräva i originalspråket växlar du till Ordinfo. Se guiden [Kommentarer och lexikon](theodia://help/commentaries-and-lexicons) för en fullständig genomgång av Ordinfo.

## Relaterade guider

- Guiden [Study Mode](theodia://help/study-mode) förklarar versmenyn i detalj och var verktyget Ordbok (📖) finns bredvid Bokmärke, Färgmarkera, Läs upp, Jämför, Korsreferenser, AI-kommentar, Ordinfo och Anteckningar.
- Guiden [Kommentarer och lexikon](theodia://help/commentaries-and-lexicons) tar upp Ordinfo och originalspråkens lexikon.
- Guiden [Vad är resurser?](theodia://help/what-are-resources) förklarar de olika sorts filer Theodia använder, inklusive ordboksresurserna.
- Guiden [Vanliga problem](theodia://help/common-problems) har lösningar för tomma resultat och andra ordboksproblem.
