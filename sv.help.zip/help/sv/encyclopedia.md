---
title: Uppslagsverket
level: everyday
categories: study
summary: Hur du slår upp uppslagsverksartiklar och bläddrar i referensverk.
---

# Uppslagsverket

Theodia har ett inbyggt **uppslagsverk** för att slå upp bibelrelaterade artiklar, personer, platser och ämnen. Appen levereras med _Kitto's Illustrated Commentary_ (KIT) inbyggt, och du kan hämta fler uppslagsverk från arkivet.

## Vad är ett uppslagsverk i Theodia?

Ett uppslagsverk är ett referensverk bestående av korta artiklar. Varje artikel behandlar en person, plats, händelse eller ett bibliskt ämne. Till skillnad från en kommentar, som förklarar en bestämd vers, förklarar en uppslagsverksartikel ämnet i sig.

## Så öppnar du uppslagsverket

1. Tryck på **Uppslagsverk** i det nedre verktygsfältet.
2. Välj ett uppslagsverk i raden av förkortningar överst.
3. Skriv ett ämne, en person eller en plats i sökrutan.

Sökning kräver minst **3 tecken** innan resultat och förslag vid autoslutförande visas.

## Läsa en artikel

- På **telefon** trycker du på valfritt resultat för att öppna artikeln på en ny skärm.
- På **surfplatta** öppnas artikeln i panelen till höger medan listan stannar till vänster.

## Välja uppslagsverk

Tryck på en förkortningschip (som **KIT**) för att växla till det uppslagsverket. För att söka i mer än ett uppslagsverk åt gången använder du fliken **Sök** och väljer **Uppslagsverk** som sökläge.

## Få fler uppslagsverk

1. Öppna **Inställningar**.
2. Tryck på **Hantera resurser**.
3. Tryck på **Installera från GitHub**.
4. Välj fliken **Uppslagsverk**.
5. Tryck på hämtaknappen bredvid det uppslagsverk du vill ha.

Uppslagsverk hämtas från Theodias GitHub-arkiv för uppslagsverk och installeras automatiskt. Installerade uppslagsverk visas i uppslagsverksskärmen och i Sök.

Du kan också installera ett uppslagsverk från en lokal fil: i **Hantera resurser** trycker du på **Installera lokal fil** och väljer en `.encyclopedia`-fil. Filen kopieras till appens mapp för uppslagsverk och läggs till i det delade uppslagsindexet.

## Håll nere för hela titeln

På sökskärmen visar uppslagsverkschipsna korta förkortningar. Håll nere ett chip för att se uppslagsverkets fullständiga namn.

## När passar uppslagsverket?

- Slå upp en person, plats eller ett ämne före eller medan du läser en passage.
- Få bakgrund om ett bibliskt ord eller begrepp som spänner över många verser.
- Läs vid sidan av en kommentar för djupare studie.
