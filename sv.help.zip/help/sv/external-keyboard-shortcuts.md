---
title: Genvägar för externt tangentbord
level: everyday
categories: [tablet, settings]
summary: Fullständig referens för tangentbordsgenvägar på iPad med externt tangentbord anslutet.
---

# ⌨️ Genvägar för externt tangentbord

Använder du Theodia på iPad med externt tangentbord (Magic Keyboard, Bluetooth-tangentbord eller USB-tangentbord) kan du navigera i appen utan att röra skärmen.

> **Läge:** Vissa genvägar fungerar bara när motsvarande funktion finns i ditt aktuella användarläge. Till exempel gör `Cmd + Option + 6` (Bokmärken) och `Cmd + Option + 7` (Färgmarkeringar) ingenting i Reader-läget. Byt läge i **Inställningar** → **Appanvändarläge**.

Genvägarna fungerar på **iPad**.

## Globala genvägar (var som helst)

| Genväg            | Åtgärd                                         |
| ------------------ | ------------------------------------------- |
| `Cmd + /`          | Visa den här hjälpen om tangentbordsgenvägar |
| `Cmd + .`          | Stäng modalt fönster / panel (alternativ till Escape) |
| `Cmd + Option + 1` | Gå till fliken Hem                            |
| `Cmd + Option + 2` | Gå till fliken Biblar                         |
| `Cmd + Option + 3` | Gå till fliken Böcker                         |
| `Cmd + Option + 4` | Gå till fliken Andakter                       |
| `Cmd + Option + 5` | Gå till fliken Sök                            |
| `Cmd + Option + 6` | Gå till fliken Bokmärken (Standard och Scholar) |
| `Cmd + Option + 7` | Gå till fliken Färgmarkeringar (Standard och Scholar) |
| `Cmd + Option + 8` | Gå till fliken Anteckningar (Standard och Scholar) |
| `Cmd + Option + 9` | Gå till fliken AI (endast Scholar, om den är aktiverad) |
| `Cmd + Option + 0` | Gå till fliken Hjälp                          |
| `Cmd + Option + I` | Gå till fliken Om                             |
| `Cmd + [`          | Gå tillbaka                                   |
| `Cmd + F`          | Öppna Sök                                     |
| `Cmd + K`          | Öppna Launcher-menyn (Scholar)                |
| `Cmd + ,`          | Öppna Inställningar                           |
| `Cmd + Shift + M`  | Öppna huvudmenyn                              |
| `Cmd + Shift + T`  | Växla tema (standard / mörkt)                 |
| `Cmd + Shift + U`  | Öppna väljaren för användarläge               |
| `Escape`           | Stäng modalt fönster / stäng panel            |

## Genvägar i Bibelläsaren

Dessa fungerar i både **Study Reader** och **Focus Reader**.

| Genväg             | Åtgärd                                                       |
| ------------------ | ------------------------------------------------------------ |
| `← Vänsterpil`     | Föregående kapitel                                           |
| `→ Högerpil`       | Nästa kapitel                                                |
| `Cmd + R`          | Växla mellan Study- och Focus Reader (Standard och Scholar)  |
| `Cmd + Option + V` | Öppna versionsväljaren                                       |
| `Cmd + Option + B` | Öppna bokväljaren                                            |
| `Cmd + Option + C` | Öppna kapitelväljaren                                        |
| `Cmd + T`          | Växla TTS (stannar vid uppspelning/paus, startar vid vila)   |
| `Cmd + Option + T` | Spela / pausa TTS                                            |

## Endast Study Reader

| Genväg             | Åtgärd                                                                 |
| ------------------ | ---------------------------------------------------------------------- |
| `↑ Uppåtpil`       | Markera föregående vers                                                |
| `↓ Nedåtpil`       | Markera nästa vers                                                     |
| `Cmd + ↑`          | Markera första versen                                                  |
| `Cmd + ↓`          | Markera sista versen                                                   |
| `Cmd + ←`          | Hoppa till kapitel 1                                                   |
| `Cmd + →`          | Hoppa till sista kapitlet                                              |
| `Cmd + 0`–`9`      | Direkt vershopp (skriv siffror, t.ex. `Cmd + 1` `Cmd + 6` för vers 16) |
| `Cmd + P`          | Växla parallellbiblar (Standard och Scholar)                           |
| `Cmd + B`          | Bokmärk markerad vers (Standard och Scholar)                           |
| `Cmd + H`          | Färgmarkera markerad vers (Standard och Scholar)                       |
| `Cmd + N`          | Lägg till anteckning för markerad vers (Standard och Scholar)          |
| `Cmd + C`          | Jämför markerad versens översättningar (Standard och Scholar)          |
| `Cmd + X`          | Öppna korsreferenser för markerad vers (Standard och Scholar)          |
| `Cmd + I`          | Öppna ordinfo (Scholar)                                                |
| `Cmd + D`          | Öppna ordboken för markerad vers (Scholar)                             |
| `Cmd + A`          | Öppna AI-panelen för markerad vers (Scholar)                           |
| `Cmd + Option + S` | Växla mellanrubriker                                                   |
| `Cmd + Option + W` | Stäng alla öppna studiepaneler                                         |
| `Cmd + Option + M` | Öppna versens åtgärdsmeny                                              |

## Endast Focus Reader

| Genväg         | Åtgärd           |
| -------------- | ---------------- |
| `↑ Uppåtpil`   | Rulla upp        |
| `↓ Nedåtpil`   | Rulla ned        |
| `Cmd + ↑`      | Rulla överst     |
| `Cmd + ↓`      | Rulla underst    |
| `Cmd + =`      | Zooma in         |
| `Cmd + -`      | Zooma ut         |

## Sök

| Genväg             | Åtgärd                           |
| ------------------ | -------------------------------- |
| `Return`           | Utför sökning                    |
| `Cmd + Return`     | Rensa sökningen och fokusera inmatningen |
| `Cmd + ↑`          | Rulla resultaten uppåt           |
| `Cmd + ↓`          | Rulla resultaten nedåt           |
| `Cmd + Option + A` | Markera alla omfångsobjekt       |
| `Cmd + Option + C` | Avmarkera alla omfångsobjekt     |
| `Cmd + Option + B` | Sökläge Bibel                    |
| `Cmd + Option + O` | Sökläge Bok                      |
| `Cmd + Option + D` | Sökläge Ordbok (Scholar)         |
| `Cmd + Option + X` | Sökläge Lexikon (Scholar)        |

## Sökresultat

| Genväg    | Åtgärd              |
| --------- | ------------------- |
| `Cmd + S` | Öppna arket för att spara alla |
| `Cmd + ↑` | Rulla resultaten uppåt   |
| `Cmd + ↓` | Rulla resultaten nedåt   |

## Bokläsaren

| Genväg             | Åtgärd                   |
| ------------------ | ------------------------ |
| `← Vänsterpil`     | Föregående kapitel       |
| `→ Högerpil`       | Nästa kapitel            |
| `Cmd + ↑`          | Föregående kapitel       |
| `Cmd + ↓`          | Nästa kapitel            |
| `↑ Uppåtpil`       | Rulla upp                |
| `↓ Nedåtpil`       | Rulla ned                |
| `Cmd + B`          | Bokmärk aktuellt kapitel |
| `Cmd + J`          | Öppna kapitelväljaren    |
| `Cmd + L`          | Öppna röstväljaren       |
| `Cmd + T`          | Växla TTS                |
| `Cmd + Option + T` | Spela / pausa TTS        |

## Andaktsläsaren

| Genväg             | Åtgärd              |
| ------------------ | ------------------- |
| `← Vänsterpil`     | Föregående dag      |
| `→ Högerpil`       | Nästa dag           |
| `↑ Uppåtpil`       | Rulla upp           |
| `↓ Nedåtpil`       | Rulla ned           |
| `Cmd + ↑`          | Rulla upp (stort)   |
| `Cmd + ↓`          | Rulla ned (stort)   |
| `Cmd + D`          | Öppna datumväljaren |
| `Cmd + T`          | Växla TTS           |
| `Cmd + Option + T` | Spela / pausa TTS   |

## AI-chatten

| Genväg             | Åtgärd                     |
| ------------------ | -------------------------- |
| `Cmd + Return`     | Skicka meddelande          |
| `Cmd + N`          | Ny chatt                   |
| `Cmd + D`          | Växla konversationsrutan   |
| `Cmd + Option + C` | Rensa aktuell chatt        |
| `Cmd + S`          | Öppna sparamenyn           |
| `Escape`           | Stäng rutan / menyn        |

## Bokmärken

| Genväg                        | Åtgärd                             |
| ----------------------------- | ---------------------------------- |
| `↑ Uppåtpil` / `↓ Nedåtpil`   | Markera bokmärke                   |
| `Return`                      | Öppna bokmärket (surfplatta: markera) |
| `Cmd + R`                     | Läs bokmärket i sitt sammanhang    |
| `Cmd + M`                     | Flytta markerat bokmärke till mappar |
| `Cmd + N`                     | Hantera mappar                     |
| `Escape`                      | Stäng detaljpanel / mappväljare    |

I väljaren **Spara i mapp** flyttar `↑ Uppåtpil` / `↓ Nedåtpil` markeringen, `Return` växlar den valda mappen eller aktiverar den framhävda åtgärden, och `Escape` stänger väljaren. Raden **+ Skapa mapp** ligger överst i listan.

## Bibelanteckningar

| Genväg                        | Åtgärd                |
| ----------------------------- | --------------------- |
| `↑ Uppåtpil` / `↓ Nedåtpil`   | Markera anteckning    |
| `Return`                      | Öppna anteckningen    |
| `Cmd + Return`                | Fokusera filterinmatningen |
| `Escape`                      | Stäng detalj / redigerare |

## Färgmarkeringar

| Genväg                        | Åtgärd             |
| ----------------------------- | ------------------ |
| `↑ Uppåtpil` / `↓ Nedåtpil`   | Markera färgmarkering |
| `Return`                      | Öppna färgmarkeringen |
| `Cmd + Return`                | Fokusera filterinmatningen |
| `Escape`                      | Stäng detaljpanelen |

## Bibellistan

| Genväg                                   | Åtgärd                            |
| ---------------------------------------- | --------------------------------- |
| `Tab` / `→ Högerpil` / `↓ Nedåtpil`      | Nästa Bibel                       |
| `← Vänsterpil` / `↑ Uppåtpil`            | Föregående Bibel                  |
| `Return`                                 | Öppna den fokuserade Bibeln       |
| `Cmd + Shift + S`                        | Växla favorit för den fokuserade Bibeln |
| `Escape`                                 | Gå tillbaka                       |

## Bibelns bokskärm

| Genväg                  | Åtgärd                     |
| ----------------------- | -------------------------- |
| `Tab` / `→ Högerpil`    | Nästa bok                  |
| `← Vänsterpil`          | Föregående bok             |
| `↓ Nedåtpil`            | Boken under i rutnätet     |
| `↑ Uppåtpil`            | Boken över i rutnätet      |
| `Cmd + ↓`               | Nästa avdelning (GT / NT)  |
| `Cmd + ↑`               | Föregående avdelning (GT / NT) |
| `Return`                | Öppna den fokuserade boken |
| `Escape`                | Gå tillbaka                |

## Boklistan

| Genväg                                   | Åtgärd            |
| ---------------------------------------- | ----------------- |
| `Tab` / `→ Högerpil` / `↓ Nedåtpil`      | Nästa bok         |
| `← Vänsterpil` / `↑ Uppåtpil`            | Föregående bok    |
| `Return`                                 | Öppna den fokuserade boken |
| `Escape`                                 | Gå tillbaka       |

## Bibelns kapitelskärm

| Genväg                                   | Åtgärd               |
| ---------------------------------------- | -------------------- |
| `Tab` / `→ Högerpil` / `↓ Nedåtpil`      | Nästa kapitel        |
| `← Vänsterpil` / `↑ Uppåtpil`            | Föregående kapitel   |
| `Return`                                 | Öppna det fokuserade kapitlet |
| `Escape`                                 | Gå tillbaka          |

## Bokens kapitelskärm

| Genväg                 | Åtgärd                    |
| ---------------------- | ------------------------- |
| `Tab` / `↓ Nedåtpil`   | Nästa kapitel             |
| `↑ Uppåtpil`           | Föregående kapitel        |
| `Return`               | Öppna det fokuserade kapitlet |
| `Cmd + Return`         | Fokusera sök-/filterinmatningen |
| `Escape`               | Gå tillbaka               |

## Andaktslistan

| Genväg                                   | Åtgärd                  |
| ---------------------------------------- | ----------------------- |
| `Tab` / `→ Högerpil` / `↓ Nedåtpil`      | Nästa andakt            |
| `← Vänsterpil` / `↑ Uppåtpil`            | Föregående andakt       |
| `Return`                                 | Öppna den fokuserade andakten |
| `Escape`                                 | Gå tillbaka             |

## Diagram

På skärmarna Statistik, Mål och Konkordans.

| Genväg          | Åtgärd                                 |
| --------------- | -------------------------------------- |
| `← Vänsterpil`  | Markera föregående kategori i ett diagram |
| `→ Högerpil`    | Markera nästa kategori i ett diagram     |

Underrubriken under diagrammet följer markeringen, och det nya värdet läses upp.

## Huvudmenyn (när den är öppen)

| Genväg         | Åtgärd                  |
| -------------- | ----------------------- |
| `↑ Uppåtpil`   | Föregående menyval      |
| `↓ Nedåtpil`   | Nästa menyval           |
| `Return`       | Välj det framhävda valet |
| `Escape`       | Stäng menyn             |

## Inställningar

| Genväg   | Åtgärd                    |
| -------- | ------------------------- |
| `Escape` | Stäng öppet modalt fönster / väljare |

## Redigerarfönster

| Genväg    | Åtgärd         |
| --------- | -------------- |
| `Cmd + S` | Spara          |
| `Escape`  | Avbryt / stäng |

## Skrivskydd

När du är i ett textfält (sökruta, anteckningsredigerare, AI-inmatning) undertrycks genvägar utan Cmd, som piltangenter och `Space`, så att de inte av misstag startar navigering. Genvägar som använder `Cmd`-tangenten (t.ex. `Cmd + S`, `Cmd + B`) fungerar även medan du skriver.
