---
title: Vanliga frågor
level: everyday
categories: faq
summary: Svar på de vanligaste frågorna om att använda Theodia.
---

# Vanliga frågor

## Kostar Theodia något?

Theodia är ett engångsköp. Ingen prenumeration, ingen reklam, inga köp i appen och inga uppmaningar om donationer. Alla extra resurser i katalogen är gratis att hämta efter att du köpt appen.

## Behöver jag en internetanslutning?

Nej. När appen och dess datafiler är installerade fungerar allt offline. Du kan läsa, söka, färgmarkera, skriva anteckningar och använda de flesta studieverktyg utan täckning.

Den enda funktion som behöver internet är att hämta nya resurser.

## Var lagras mina data?

Alla dina bokmärken, färgmarkeringar, anteckningar och inställningar sparas på din enhet. De laddas inte upp till någon server.

Du kan säkerhetskopiera dem manuellt. Se guiden [Säkerhetskopiera dina data](theodia://help/backups) för hur.

## Kan jag lyssna på Bibeln?

Ja. Öppna valfritt kapitel, tryck på menyn och välj alternativet för uppläsning. Din enhet måste ha en text-till-tal-röst installerad. Se guiden [Läsa upp högt](theodia://help/tts) för mer.

## Hur söker jag efter en vers?

Du kan skriva en referens som `John 3:16` i kommandot på startskärmen, eller använda fliken **Sök** för att söka på ord eller fras.

## Hur rapporterar jag ett fel eller föreslår en funktion?

Tryck på **Skicka förslag / fel** på Om-skärmen, [rapportera det på GitHub](https://github.com/ecodiallc/theodia.app/issues/new) eller besök sidan [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions).

## Vilka enheter stöds?

Theodia kör på iPhone, iPad och Android-telefoner och -surfplattor. Det fungerar bäst på enheter med minst 2 GB ledigt lagringsutrymme för kärnddatafilerna.

## Kan jag använda ett externt tangentbord?

Ja. Theodia stöder Bluetooth- och USB-tangentbord på iPad. Navigering, sökning och många läsfunktioner har tangentbordsgenvägar. Se guiden [Genvägar för externt tangentbord](theodia://help/external-keyboard-shortcuts) för hela listan.

## Vilka språk stöds?

Appens gränssnitt finns på engelska, arabiska, kinesiska (förenklad och traditionell), tjeckiska, danska, nederländska, filippinska, franska, tyska, grekiska, hebreiska, hindi, indonesiska, italienska, japanska, koreanska, polska, portugisiska (Brasilien), rumänska, ryska, spanska, swahili, svenska, thai, turkiska, ukrainska och vietnamesiska.

Bibeltextens språk beror på vilka översättningar du har installerat.

## Hur ändrar jag språk?

Gå till **Inställningar** och leta efter språkalternativet.

## Min fråga finns inte här. Var får jag mer hjälp?

Bläddra bland resten av hjälpguiderna efter ämne, eller ställ en fråga i gemenskapen på [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions).

Tips: På huvudskärmen **Hjälp & guider** använder du sökrutan för att skriva ett ämne som `notifications` eller `search` och hitta rätt guide.
