---
title: Läsa ditt första kapitel
level: beginner
categories: [start, read]
summary: En steg-för-steg-genomgång av att öppna och läsa ett kapitel.
---

# Läsa ditt första kapitel

Den här guiden visar hur du öppnar ett kapitel för allra första gången.

## Steg 1: Öppna Bibel-fliken

Titta längst ner på skärmen. Du ser en rad flikar. Tryck på den som heter **Bible**.

## Steg 2: Välj en bok

Du ser en lista över Bibelns böcker. 1 Mosebok är först. Johannes finns nära mitten. Uppenbarelseboken är sist.

Tryck på namnet på boken du vill ha.

## Steg 3: Välj ett kapitel

Du ser talen 1 upp till så många kapitel boken har. Tryck på det kapitel du vill ha.

Kapitlet öppnas. Verserna finns på skärmen.

## Steg 4: Flytta dig

- Svep **åt vänster** för att gå till nästa kapitel.
- Svep **åt höger** för att gå tillbaka.

## Steg 5: Interagera med en vers

Vad du kan göra med en vers beror på ditt användarläge.

### Reader-läget

Reader-läget är rent och ostört.

- Tryck på en vers för att lyfta fram den kort.
- Det finns inga studieverktyg, bokmärken eller menyer.
- Vill du ha fler funktioner byter du till läget **Standard** eller **Scholar** i **Inställningar**.

### Standardläget

Standardläget lägger till vardagsfunktioner för personlig bibelstudie.

Tryck på en vers för att öppna en meny med dessa val:

- **Bokmärka** versen.
- **Färgmarkera** den i en färg.
- **Lägga till en anteckning** på den.
- **Kopiera** versens text.
- **Jämföra** versen i en annan översättning.
- **Slå upp korsreferenser** för versen.

### Scholar-läget

Scholar-läget låser upp alla verktyg för djup bibelstudie.

Tryck på en vers för att öppna en meny med allt i Standardläget, plus:

- **Kommentar** till versen.
- **Ordinfo** och uppslag i originalspråken.
- **Ordboks**-förklaringar.
- **AI-assistenten** för djupare studie.

Du kan byta läge när som helst i **Inställningar**.

## Behöver du hjälp med ett bestämt verktyg?

Varje verktyg har sin egen guide. Tryck på **Hjälp** på startsidan för att se dem alla. Guiden [Study Mode](theodia://help/study-mode) är en bra start — den går igenom varje verktyg i versmenyn.

Lär du dig fortfarande var sakerna finns, se guiden [Appens layout och navigering](theodia://help/navigating-the-app). Den förklarar startskärmen, huvudmenyn och det nedre verktygsfältet.

## Vill du ha fler resurser?

Appen kommer med flera fritt tillgängliga bibelversioner. Vill du lägga till fler, eller lägga till kommentarer, böcker eller andakter, se guiden [Hämta extra resurser från GitHub](theodia://help/getting-core-files). Den visar var du hittar dem och hur du lägger till dem.
