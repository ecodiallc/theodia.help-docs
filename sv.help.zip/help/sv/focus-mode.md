---
title: Fokusläget
level: beginner
categories: [layout, read]
summary: Ett rent, ostört sätt att läsa långa passager.
---

# Fokusläget

> **Läge:** Fokusläget är läsaren i läget **Reader**. Det finns också i lägena **Standard** och **Scholar** som ett alternativ till Study Mode. Du kan byta läge i **Inställningar** → **Appanvändarläge**.

Fokusläget är ett sätt att läsa ett bibelkapitel utan knappar eller menyer i vägen. Det passar långa läsningar.

## Så slår du på det

1. Öppna valfritt kapitel.
2. I raden av ikoner överst på skärmen trycker du på 📖-knappen. Den öppnar samma kapitel i Fokusläget.
3. Menyerna och knapparna döljs. Bara bibeltexten är kvar.

I läget **Reader** öppnas kapitlen automatiskt i Fokusläget. 📖-knappen är dold eftersom det inte finns någon Study Mode att växla till.

## Vad du kan göra i Fokusläget

- **Rulla** för att läsa.
- **Svepa** för att gå till nästa eller föregående kapitel.
- **Trycka på 📖-knappen** i det nedre fältet för att växla tillbaka till Study Mode. (Dold i Reader-läget.)
- **Trycka på 🔊-knappen** i det nedre fältet för att få kapitlet läst högt. En liten kontrollfält visas med spela, pausa, backa, spola framåt och röstväljare. (Dold i Reader-läget — TTS kräver Standard eller Scholar.)

## Bra tillfällen för Fokusläget

- Läsa igenom en hel bok, ett kapitel i taget.
- Läsa en lång passage för en andakt eller tyst stund.
- Läsa högt och följa med utan störningar.

## Växla till Study Mode

Fokusläget döljer alla studieverktyg, men de är alltid ett tryck bort. Tryck på 📖-knappen överst på skärmen för att öppna samma kapitel i [Study Mode](theodia://help/study-mode). Study Mode är den fullständiga läsaren, med kommentarer, korsreferenser, lexikonuppslag och anteckningar. För att lära dig vad Study Mode kan göra, se guiden [Study Mode](theodia://help/study-mode).

I läget **Reader** är 📖-knappen dold eftersom Study Mode inte är tillgänglig.
