---
title: Ta dig runt snabbt
level: beginner
categories: layout
summary: Alla snabba sätt att hoppa till en vers, ett kapitel eller en skärm i Theodia.
---

# Ta dig runt snabbt

Den här guiden är ett lathund för navigering. Den täcker alla snabba sätt att flytta dig från där du är till dit du vill.

## Hoppa rakt till en vers

Det snabbaste sättet att öppna en vers är **Kommandot** på startskärmen.

- Skriv `John 3:16` och tryck på Kör.
- Skriv `Psalms 23` och tryck på Kör.
- Skriv `Genesis 1` och tryck på Kör.

Appen öppnar det exakta kapitlet (och rullar till versen om du angav en).

## Svep mellan kapitel

När du läser ett kapitel:

- **Svep åt vänster** → nästa kapitel.
- **Svep åt höger** → föregående kapitel.

Detta fungerar mellan böcker. Efter Andra Mosebok 40 tar svep åt vänster dig till Tredje Mosebok 1.

## Använd det övre fältet

Medan du läser visar skärmens övre del den aktuella **översättningen**, **boken** och **kapitlet**.

- Tryck på översättningens namn för att byta Bibel.
- Tryck på bokens namn för att välja en annan bok.
- Tryck på kapitelnumret för att välja ett annat kapitel.

## Hoppa från ett bokmärke

Har du sparat en vers:

1. Öppna fliken **Bokmärken**.
2. Tryck på valfri post.
3. Du kommer rakt till den versen.

## Hoppa från sökningen

1. Öppna fliken **Sök**.
2. Skriv ett ord eller en fras.
3. Tryck på valfritt resultat.
4. Appen öppnar kapitlet med dina sökord framhävda i gult.

## Byta läslayout

Bibelläsaren har två layouter:

- **Study Mode** — visar kapitlet med alla studieverktyg ett tryck bort.
- **Fokusläget** — döljer alla verktyg och menyer och lämnar bara texten.

Så här byter du: tryck på **📖**-knappen överst på skärmen medan du läser. Tryck igen för att växla tillbaka. (Reader-läget stannar alltid i Fokusläget.)

## Använd de nedre flikarna

Raden av ikoner längst ner på skärmen är alltid synlig. Tryck på valfri flik för att växla till det området. De exakta flikarna beror på ditt användarläge:

**Alla lägen:**

- **Hem** — tillbaka till startskärmen.
- **Biblar** — lista över översättningar.
- **Sök** — sök i Bibeln, böcker, ordböcker, lexikon och PDF-filer.
- **Inställningar** — preferenser och resurser.

**Standard och Scholar ser också:**

- **Bokmärken** — sparade verser.
- **Färgmarkeringar** — färgmarkerade verser.
- **Anteckningar** — dina privata anteckningar.
- **PDF-filer** — dina importerade PDF-dokument.

**Scholar ser också:**

- **AI** — AI-assistenten (om den är påslagen i Inställningar).

### Komma ihåg var du slutade

Varje flik har sin egen navigeringshistorik. När du växlar tillbaka till en flik återvänder du till **där du slutade**, inte till det områdets startskärm.

- Du öppnar fliken **Biblar**, väljer en översättning, öppnar ett kapitel och växlar sedan till **Sök**. Senare trycker du på **Biblar** igen och är direkt tillbaka vid samma kapitel.
- Du öppnar fliken **Bokmärken**, trycker på en bokmärkt vers och växlar sedan till **Inställningar**. Trycker du på **Bokmärken** igen kommer du tillbaka till bokmärkeslistan.

Detta gäller varje flik. Var och en minns din plats tills du uttryckligen navigerar till en annan skärm inuti den fliken.

### Vad nollställer en flik

En flik återgår till sin rotskärm bara när:

- Du redan är på den fliken och trycker på samma flikikon igen. Det är ett snabbt sätt att nollställa den till starten.
- Appen tvingas avslutas och öppnas igen.

### Nedre flikar jämfört med huvudmenyn

- **Nedre flikar** — varje flik minns sin egen stack. Att trycka på en flik tar dig tillbaka till där du slutade.
- **Huvudmenyn** — att trycka på ett val navigerar till den skärmen. Det är en rullgardinslista, inte ett överlägg.

Exempel:

- Du läser Johannes 3. Tryck på fliken **Bokmärken** och sedan på **Biblar** igen. Du återvänder till Johannes 3.
- Du läser Johannes 3. Öppna menyn och tryck på **Anteckningar**. Granska dina anteckningar och tryck sedan på fliken **Biblar** för att återvända till Johannes 3.

## Tips

- Startskärmen minner vilka avdelningar som är utfällda eller infällda.
- Saknas en flik, kontrollera ditt **användarläge** i **Inställningar** → **Appanvändarläge**. Reader-läget döljer bokmärken, färgmarkeringar, anteckningar och AI. Standardläget döljer AI. Du kan också behöva aktivera en funktion i **Inställningar** eller installera en resurs.
