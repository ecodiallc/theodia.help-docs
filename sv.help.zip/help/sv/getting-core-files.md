---
title: Hämta extra resurser
level: everyday
categories: resources
summary: Hur du lägger till biblar, kommentarer, böcker och andra resurser i Theodia.
---

# Hämta extra resurser

Theodia har vissa resurser inbyggda, men du kan lägga till fler. Det enklaste sättet är via skärmen **Hantera resurser** i appen.

## Vad du kan lägga till

- **Biblar** — fler översättningar på olika språk
- **Kommentarer** — studieanteckningar som förklarar verserna
- **Böcker** — kristna klassiker och referensverk
- **Andakter** — dagliga andaktsläsningar
- **Kärnfiler** — större datafiler som morfologi, korsreferenser och Marvel Interlinear Bible (MIB)

## Så lägger du till resurser inifrån appen

1. Öppna **Inställningar**.
2. Tryck på **Hantera resurser**.
3. Välj en flik: **Core**, **Biblar**, **Kommentarer**, **Böcker** eller **Andakter**.
4. Bläddra i listan. Tryck på en resurs för att läsa mer om den.
5. Tryck i kryssrutan för att välja vad du vill ha.
6. Tryck på **Hämta** längst ner. Filerna hämtas och installeras automatiskt.

När resursen är installerad visas den i appen direkt. Du behöver inte starta om.

## Kärnfiler

Fliken **Core** har stora datafiler som driver djupare studiefunktioner. Dit hör:

- Morfologidata (ordformer i originalspråken)
- Korsreferensdatabaser
- Marvel Interlinear Bible (MIB)

Du behöver bara hämta kärnfilerna en gång. De stannar på din enhet och fungerar offline.

## Globala biblar

Fliken **Globala biblar** har bibelöversättningar från en bredare samling. Ser du inte den översättning du vill ha i huvudfliken **Biblar**, titta här.

## Hantera installerade resurser

På huvudskärmen **Hantera resurser** (inte nedladdningsfliken) kan du:

- **Aktivera eller inaktivera** en resurs utan att ta bort den. Inaktiverade resurser stannar på din enhet men döljs i menyerna.
- **Ta bort** en resurs för att frigöra utrymme. Du kan hämta den igen senare.

## Lägga till egna filer

Har du en resursfil från annat håll — en vän, ett annat projekt eller en webbplats — kan du importera den direkt:

1. I **Hantera resurser** trycker du på **Importera lokal fil**.
2. Välj filen från din enhet.
3. Appen läser filen och lägger till den i ditt bibliotek.

Appen tar emot dessa filtyper:

- `.bible` — bibelöversättningar
- `.commentary` — kommentarer
- `.lexicon` — lexikon
- `.book` — böcker
- `.devotional` — andakter

## Ansluta ett eget GitHub-arkiv

Underhåller någon ett GitHub-arkiv med Theodia-kompatibla resurser kan du lägga till det som egen källa:

1. Gå till **Inställningar → GitHub-arkiv**.
2. Tryck på **Lägg till arkiv**.
3. Ange GitHub-URL:en (till exempel `https://github.com/username/repo-name`).
4. Välj vilka typer av resurser arkivet innehåller (biblar, kommentarer eller böcker).
5. Spara.
6. Gå tillbaka till **Hantera resurser**. En ny flik visas med resurserna från det arkivet.

Är arkivet privat behöver du lägga till en **Personal Access Token** i **Inställningar → GitHub-arkiv** så att appen kan läsa det.

## En notering om filstorlekar

Resursfiler kan vara stora. Biblar är vanligen små (några megabyte). Kommentarer och kärnfiler kan vara mycket större (hundratals megabyte). Hämta över Wi-Fi när det är möjligt.

## Sammanfattning

- Använd **Inställningar → Hantera resurser** för att bläddra och installera resurser.
- Kärnfiler låser upp djupare studieverktyg som morfologi och korsreferenser.
- Importera lokala filer om du har egna.
- Lägg till egna GitHub-arkiv om du vill ha resurser från en annan källa.
