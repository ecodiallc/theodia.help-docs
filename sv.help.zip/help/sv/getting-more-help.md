---
title: Var ställer jag frågor
level: everyday
categories: trouble
summary: Hur du får hjälp från Theodia-teamet och gemenskapen, och hur du hittar hjälpämnen i appen.
---

# Var ställer jag frågor

Fastnar du finns det några ställen att be om hjälp.

## Hitta ett hjälpämne

Letar du efter information om en bestämd funktion, prova något av dessa spår:

- **Bläddra efter kategori.** Öppna **Hjälp & guider** och tryck på en kategori som **Inställningar & anpassning** eller **Felsökning**. Varje kort listar relaterade guider.
- **Sök på nyckelord.** På huvudskärmen **Hjälp & guider** skriver du ett ord i sökrutan överst. Att skriva `notifications` visar till exempel guiden [Påminnelser och notiser](theodia://help/notifications); att skriva `search` visar guiden [Söka i Bibeln](theodia://help/search-the-bible).
- **Kolla Inställningar först.** Många funktioner konfigureras i **Inställningar**. Vill du ställa in påminnelser öppnar du **Inställningar** → **Notiser**. Inställningsskärmen har också en **Hjälp**-länk för varje avdelning.

## Inuti appen

Öppna skärmen **Om**. Du ser två knappar:

- **Skicka förslag / fel** — öppnar ett formulär för att skicka teamet en fråga, en idé eller en felrapport.
- **Diskussion / återkoppling** — öppnar gemenskapens diskussionstavla.

## GitHub-sidan

Du kan se listan över kända fel och senaste ändringar på [GitHub](https://github.com/ecodiallc/theodia.app).

## Gemenskapsdiskussion

Andra som använder Theodia ställer frågor och delar tips på [gemenskapens diskussionstavla](https://github.com/ecodiallc/theodia.app/discussions). Du kan läsa gamla trådar och påbörja en ny.

## Innan du frågar

Några saker hjälper oss att svara dig snabbare:

- **Vilken enhet har du?** (t.ex. iPhone 13, Pixel 7)
- **Vilken version av appen?** (Öppna **Om** för att se.)
- **Vad gjorde du?** En kort beskrivning av stegen.
- **Vad hände?** Vad du såg på skärmen.
- **Vad förväntade du dig skulle hända?** Detta är ofta den mest användbara delen.

## Vad du kan vänta dig

- För felrapporter svarar teamet vanligen inom några dagar.
- För idéer läser teamet alla. Vi kan inte lova när en idé läggs till.
- För frågor i gemenskapen svarar ofta andra användare snabbare än teamet.

## En notering om integritet

När du skickar en fråga ska du inte inkludera privata uppgifter. Teamet kan se vad du skickar.
