---
title: GitHub Models
categories: ai
level: advanced
summary: Konfigurera GitHub Models — ett gratis sätt att börja utforska AI i Theodia utan befintlig API-prenumeration.
---

# GitHub Models

> **Läge:** AI-assistenten kräver läget **Scholar**. Du kan byta läge i **Inställningar** → **Appanvändarläge**.

Betalar du redan inte för en AI-tjänst är **GitHub Models** det enklaste sättet att börja utforska Theodias AI. Det ger en gratis väg att börja, och allt du behöver är ett gratis GitHub-konto.

## Vad är GitHub Models?

GitHub Models är en tjänst från GitHub som låter dig köra moderna AI-modeller via ett API. Den stöder samma format som OpenAI, så den fungerar sömlöst med Theodia.

## Varför välja GitHub Models?

- **Inget kreditkort krävs** — bara ett GitHub-konto.
- **Modeller av hög kvalitet** — du får tillgång till GPT-4o, GPT-4.1 och andra tillförlitliga modeller som stöder Theodias verktyg.
- **Enkel installation** — en token, en URL, så är det klart.

## Steg 1: Skapa ett GitHub-konto

Har du redan ett GitHub-konto hoppar du till steg 2.

1. Gå till [github.com](https://github.com).
2. Tryck på **Sign up** och följ anvisningarna för att skapa ett gratis konto.
3. Bekräfta din e-postadress när GitHub skickar bekräftelsen.

## Steg 2: Skapa en Personal Access Token

Denna token är din API-nyckel. Den talar om för GitHub vem du är när Theodia skickar frågor.

1. Gå till [github.com/settings/tokens](https://github.com/settings/tokens).
2. Tryck på **Generate new token** och välj **Generate new token (classic)**.
3. Ge tokenen ett namn som **Theodia AI**.
4. Under **Select scopes** kryssar du i rutan **`models:read`**.
   - Det är den enda behörighet Theodia behöver.
5. Rulla längst ned och tryck på **Generate token**.
6. **Kopiera tokenen omedelbart.** GitHub visar den bara en gång. Klistra in den på en säker plats (till exempel anteckningsappen på telefonen) tills du lägger till den i Theodia.

## Steg 3: Välj en modell

GitHub Models erbjuder flera modeller. För Theodia är dessa de bästa valen:

| Modell                | Daglig gratisgräns | Bäst för                                       |
| --------------------- | ------------------ | --------------------------------------------- |
| `openai/gpt-4.1-nano` | 150 anrop / dag    | Snabba frågor och enkla versförklaringar      |
| `openai/gpt-4.1-mini` | 150 anrop / dag    | Allmän studie med bra verktygsstöd            |
| `openai/gpt-4.1`      | 50 anrop / dag     | Djupare studie och komplexa flerstegsfrågor   |
| `openai/gpt-4o`       | 50 anrop / dag     | Mångsidig, utmärkt verktygsstöd               |

Börja med **`openai/gpt-4.1-mini`** — den är snabb, tillförlitlig och har en högre daglig anropsgräns.

## Steg 4: Konfigurera Theodia

1. Öppna **Theodia**.
2. Gå till **Inställningar** → **AI-assistent**.
3. Kontrollera att **Modell på distans** är vald.
4. Tryck på rullgardinsmenyn **Leverantör** och välj **GitHub Models**.
   - Saknas GitHub Models i listan trycker du på **Anpassad** och anger bas-URL:en manuellt: `https://models.github.ai`
5. Klistra in din GitHub Personal Access Token i fältet **API-nyckel**.
6. Ange ditt valda modell-ID i fältet **Modell** (till exempel: `openai/gpt-4.1-mini`).
7. Tryck på **Testa anslutning**.
8. Vänta tills kontrollen är klar. Du ska se:
   - **✓ Anslutningen lyckades**
   - **✓ Verktyg stöds**

Ser du **✗ Verktyg stöds inte** provar du ett annat modell-ID ur tabellen ovan.

## Steg 5: Börja chatta

1. Tryck på fliken **AI** längst ner på skärmen.
2. Skriv en fråga och tryck på **Skicka**.
3. Eller, medan du läser ett bibelkapitel, tryck på ett versnummer och välj **AI-kommentar** för att påbörja en versspecifik chatt.

## Felsökning

### "Anslutningen misslyckades" eller "HTTP 401"

- Kontrollera att du kopierade **hela** tokenen. Det är en lång sträng som börjar med `ghp_`.
- Tokener upphör om de inte används länge. Gå tillbaka till GitHub och generera en ny.
- Kontrollera att du valde **models:read** när du skapade tokenen.

### "Verktyg stöds inte"

- Vissa modeller på GitHub Models tar inte emot verktygsanrop. Prova i stället **`openai/gpt-4o`** eller **`openai/gpt-4.1-mini`**.
- Kontrollera att modell-ID:t är stavat exakt som visas, inklusive prefixet `openai/`.

### Fel om hastighetsgräns

- Når du den dagliga gränsen växlar du till en modell med högre tilldelning (som `openai/gpt-4.1-nano` med 150 anrop per dag).
- Gränserna nollställs var 24:e timme.

## Sammanfattning

- GitHub Models är det **rekommenderade sättet att börja utforska AI** i Theodia.
- Du behöver ett **gratis GitHub-konto** och en **Personal Access Token** med `models:read`.
- Den bästa startmodellen är **`openai/gpt-4.1-mini`**.
- Ange tokenen och modellen i **Inställningar → AI-assistent**, tryck på **Testa anslutning** och börja chatta.
