---
title: Färgmarkera verser
level: everyday
categories: [annotate, read]
summary: Hur du markerar verser i färg och hittar dem senare.
---

# Färgmarkera verser

> **Läge:** Färgmarkeringar finns i lägena **Standard** och **Scholar**. Fokusläget är endast för ren, ostörd läsning. Du kan byta läge i **Inställningar** → **Appanvändarläge**.

En färgmarkering märker ut en vers i en färg. Det fungerar som en gul overstrykningspenna på papper. Versen förblir markerad nästa gång du öppnar den.

## Så färgmarkerar du en vers

1. Öppna versen.
2. Tryck på versen för att visa menyn.
3. Tryck på **Färgmarkera**-ikonen.
4. Välj en färg.

Versen är nu markerad i den färgen.

## Så ändrar du markeringsfärgen

1. Öppna versen.
2. Tryck på versen och sedan på **Färgmarkera**-ikonen.
3. Välj en ny färg.

## Så tar du bort en färgmarkering

1. Öppna versen.
2. Tryck på versen och sedan på **Färgmarkera** i menyn.
3. Tryck på **Ta bort färgmarkering** längst ner i färgväljaren.

## Ett vanligt sätt att använda färgerna

Många läsare använder en liten uppsättning färger för en liten uppsättning syften:

- **Gul** för allmänna favoriter.
- **Grön** för verser om Gud.
- **Blå** för verser om bön.
- **Rosa** för verser om tröst.
- **Orange** för verser om varning eller tillrättavisning.
- **Lila** för verser om profetia eller de sista tiderna.

Välj ett system som passar dig.

## Så ser du alla dina färgmarkeringar

Tryck på fliken **Färgmarkeringar** längst ner. Du ser en lista över varje vers du har markerat, nyaste först. Överst finns en rad med färgchips — tryck på en färg för att visa bara markeringar i den färgen, eller tryck på **Alla** för att rensa filtret.

## Importera färgmarkeringar

Du kan föra in färgmarkeringar i Theodia från andra appar och filer.

Gå till **Inställningar** → **Bokmärken** → **Importera färgmarkeringar**. Välj **Importera från fil** eller klistra in från urklipp. Appen känner automatiskt av formatet.

### Format som stöds

**Inbyggd JSON-export** — Formatet som används av Theodias egen exportfunktion:

```json
{
  "/bible/KJV/John/3#v3_16": "yellow",
  "/bible/KJV/Genesis/1#v1_1": "green"
}
```

**CSV** — Ett kalkylblad med kolumnerna `url` och `color`. Exempel:

```csv
url,color
/bible/KJV/John/3#v3_16,yellow
/bible/KJV/Genesis/1#v1_1,green
```

**Vanlig text** — Varje rad är en bibelreferens eller URL, eventuellt följt av ett färgnamn. Exempel:

```
John 3:16 yellow
Genesis 1:1 green
Matthew 5:1
```

- Tillgängliga färger: `yellow`, `green`, `blue`, `pink`, `orange`, `purple`.
- Ingen färg anges blir markeringen gul som standard.
- Rader som börjar med `#` eller `//` behandlas som kommentarer och hoppas över.

## Tips

- Färgmarkeringar stannar på din enhet. De synkas inte till molnet.
- Du kan färgmarkera en vers i en översättning och få den att visas i dina andra översättningar av samma vers.
- Se guiden [Säkerhetskopiera dina data](theodia://help/backups) för att hålla dem säkra.
