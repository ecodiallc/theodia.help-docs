---
title: Installera bibelöversättningar
level: beginner
categories: start
summary: Så lägger du till en bibelöversättning i ditt bibliotek.
---

# Installera bibelöversättningar

Theodia kommer med några bibelöversättningar redo att läsas. Du kan lägga till fler när som helst. En "översättning" är en annan version av bibeltexten, till exempel King James Version.

## Så lägger du till en översättning

Fliken Bibel visar en lista över översättningar som redan är installerade. För att lägga till fler, öppna resurshanteraren:

1. Öppna **Inställningar**.
2. Tryck på **Hantera resurser**.
3. Tryck på **Installera från GitHub**.
4. I nedladdningsrutan, tryck på fliken **Biblar**.
5. Tryck i kryssrutan bredvid varje översättning du vill ha.
6. Tryck på **Installera valda** längst ner.
7. Vänta tills nedladdningen är klar.

Översättningen finns nu i ditt bibliotek. För att se den, öppna fliken **Bibel**.

## Så växlar du mellan översättningar

1. Öppna ett kapitel du vill läsa.
2. Tryck på översättningens namn högst upp på skärmen.
3. Välj den du vill ha från listan.

Appen sparar ditt val för nästa gång.

## Så tar du bort en översättning

1. Öppna **Inställningar**.
2. Tryck på **Hantera resurser**.
3. Hitta översättningen du vill ta bort.
4. Tryck på **X** bredvid den.
5. Bekräfta att du vill ta bort den.

Om du tar bort en översättning raderas inte dina anteckningar, markeringar eller bokmärken. De är kvar i säkert förvar.

## Hur mycket utrymme tar översättningar?

De flesta översättningar är mellan 2 och 10 MB. De lagras på din enhet, inte i molnet. Du kan behålla så många du vill, så länge din enhet har plats.

## Vad gör jag om en översättning inte finns i appen?

Vissa översättningar finns inte i listan i appen. Du kan ändå lägga till dem.

1. Öppna appen och gå till **Inställningar** → **Hantera resurser**.
2. Tryck på **Installera från GitHub**.
3. I nedladdningsrutan, titta på fliken **Biblar** och fliken **Globala biblar**. Finns din översättning där, markera den och tryck på **Installera valda**.
4. Finns den inte där, tryck på **Installera lokal fil** för att importera en `.bible`-fil. Filen finns på projektets GitHub-sida. Se guiden [Hämta extra resurser från GitHub](theodia://help/getting-core-files) för steg-för-steg-hjälp.
