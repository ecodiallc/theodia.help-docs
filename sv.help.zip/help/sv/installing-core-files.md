---
title: Lägg till kärnfilerna
level: beginner
categories: start
summary: Så laddar du ner de stora datafiler appen behöver för att studera Bibeln på djupet.
---

# Lägg till kärnfilerna

Theodia kommer med en bibel och några små tillägg redo att användas. För att få ut mest av appen behöver du också ladda ner **kärnfilerna**. Det är stora datafiler som lägger till studieverktyg som en kommentar, orduppslag och grammatikanteckningar. Utan dem fungerar appen, men studiefunktionerna är begränsade.

## Varför du behöver kärnfilerna

Kärnfilerna lägger till:

- **Orduppslag.** Tryck på ett ord i valfri vers för att se den hebreiska eller grekiska originaltexten och vad den betyder.
- **Kommentar.** AI-kommentar till varje vers.
- **Grammatik.** Information om varje ord i originalspråket.
- **Interlineär bibel.** Läs originalspråkets text med engelska under varje ord.

Du kan läsa Bibeln utan dem, men de flesta studieverktyg behöver dem.

## Så installerar du kärnfilerna

**[Installera kärnfilerna](theodia://manage/core)**

1. Öppna **Inställningar**.
2. Tryck på **Hantera resurser**.
3. Fliken **Kärna** öppnas. Du ser en lista över kärnfilerna. Var och en har ett namn, en storlek och en kryssruta.
4. Tryck på varje fil du vill installera. En bock visar att den är vald.
5. Tryck på **Installera valda**.
6. Vänta tills filerna har laddats ner och installerats. De är stora, så det kan ta några minuter på en långsam anslutning.

Filerna laddas ner till din enhet. Du behöver bara göra detta en gång. Appen använder filerna från och med nu, även när du är offline.

## Tips

- Använd Wi-Fi. Filerna är stora.
- Koppla in din telefon eller surfplatta. Stora nedladdningar drar batteri.
- Misslyckas en nedladdning, tryck på filen igen för att försöka på nytt.
- Du kan installera alla filer eller bara de du behöver.

## Vad gör jag om en fil saknas i listan?

Appen hämtar listan från projektets GitHub-sida. Är listan tom, kontrollera din internetanslutning och försök igen. Är den fortfarande tom, se guiden [Var du kan ställa frågor](theodia://help/getting-more-help).

För mer avancerade sätt att lägga till resurser, se guiden [Hämta extra resurser från GitHub](theodia://help/getting-core-files).
