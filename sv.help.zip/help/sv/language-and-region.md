---
title: Appspråk och region
level: everyday
categories: settings
summary: Så ändrar du appens språk.
---

# Appspråk och region

Theodia finns på många språk. Appen kan byta språk på menyer och knappar. Hjälpinnehållet finns också på många av dessa språk och är inbyggt i appen. Du kan också ladda ner eller uppdatera ett språks hjälppaket — öppna **Inställningar** → **Hjälp** eller **Hantera resurser** → **Installera från GitHub** → **Hjälpdokument**.

## Så öppnar du språkinställningarna

1. Öppna **Inställningar**.
2. Tryck på **Språk**.

## Så byter du appspråk

1. I listan **Språk**, tryck på språket du vill ha.
2. Appen tillämpar det nya språket direkt.

De val du ser beror på vilka språk appen stöder.

## Så väljs språket vid första installationen

När du installerar Theodia för första gången väljer appen ett språk utifrån enhetens inställningar. Du kan ändra det när som helst.

## Vad som översätts

- Menyer, knappar och etiketter.
- Inställningsskärmar.
- Felmeddelanden.
- Sök- och studieverktyg.

## Vad som bara finns på engelska

- En del bok- och andäktighetsinnehåll.

## Bibelöversättningar och appspråk

Appspråket och bibelöversättningens språk är två olika saker. Du kan ha appen på svenska och bibeln på engelska, eller tvärtom.

För att byta bibelöversättning, se guiden [Installera bibelöversättningar](theodia://help/installing-bibles).

## Tips

- Är en knapp eller etikett tom saknar appen en översättning. Den engelska versionen finns oftast kvar som reserv.
- Vill du hjälpa till att översätta appen, se guiden [Var du kan ställa frågor](theodia://help/getting-more-help).
