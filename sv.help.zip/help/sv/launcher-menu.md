---
title: Launchermenyn
level: everyday
categories: layout
summary: Ett snabbt sätt att hoppa till senaste verser, köra kommandon och byta bibellayout utan att lämna skärmen.
---

# Launchermenyn

> **Läge:** Launchermenyn kräver läget **Scholar**. Du byter läge i **Inställningar** → **Appanvändarläge**.

Launchermenyn är en snabbpanel som du kan öppna nästan var som helst i appen. Den samlar dina senaste verser, kommandon och sparade bibeluppsättningar på ett ställe.

## Så öppnar du den

Tryck på **expanderikonen (⌄)** uppe till höger i hemskärmens sidhuvud. En panel glider in uppifrån.

## Vad som finns i panelen

### 1. Kommandoruta

Högst upp i panelen finns en textruta med en tangentbordsikon. Skriv ett kommando och tryck på **Kör** på tangentbordet. Appen läser kommandot och tar dig direkt dit.

Exempel:

- `John 3:16` — öppnar den versen.
- `search love` — söker i Bibeln efter "love".
- `bookmark psalms 23` — bokmärker versen.
- `kjv` — byter till KJV-översättningen.

För hela kommandolistan, se guiden [Kommandon](theodia://help/commands).

### 2. parallelluppsättningar

Om du har sparat parallella bibelpreset visas de här som en utfällbar lista. Tryck på en för att direkt ladda den parallella uppsättningen.

Så skapar du ett parallellt preset:

1. Öppna **Inställningar** → **Parallell bibel**.
2. Lägg till översättningar och tryck på **Spara preset**.
3. Ge den ett namn. Den visas i launchermenyn.

Håll inne en parallelluppsättning i launchermenyn för att ta bort den.

### 3. Bibelsamlingar

Bibelsamlingar är genvägar med ett tryck som samtidigt byter både din översättning och din parallellvy. Om du har skapat några visas de här som en utfällbar lista.

Håll inne en samling för att ta bort den.

### 4. Funktionsikoner

Under kommandorutan kan du se en rad med runda emoji-knappar. De är genvägar med ett tryck till appens huvudfunktioner.

Tillgängliga ikoner är bland annat:

- **Om**, **Biblar**, **Bibelanteckningar**, **Bokmärken**, **Böcker**
- **Andakter**, **Flashcards**, **Hjälp**, **Markeringar**
- **Spellistor**, **Plugin**, **Sök**, **Inställningar**, **Theoscript**

Så väljer du vilka ikoner som visas och i vilken ordning:

1. Öppna **Inställningar** → **Launchermeny**.
2. Tryck på **Ikoner för launchermenyn**.
3. Använd reglagen för att visa eller dölja varje ikon.
4. Använd upp-/nerpilarna för att ordna om de ikoner du har aktiverat.

Ordningen i inställningarna är den ordning de visas i launchermenyn.

### 5. Senaste verser

Appen minns de sista kapitlen och verserna du öppnade. De visas som en lista längst ner i panelen. Tryck på en post för att hoppa direkt tillbaka.

- **Tryck** för att öppna.
- **Svep åt vänster** eller **håll inne** för att ta bort från listan.
- Tryck på **Rensa alla** för att ta bort alla poster på en gång.

## När du använder launchermenyn

Använd den när du vill:

- Hoppa tillbaka till en vers du just läste.
- Skriva ett kommando utan att gå till hemskärmen.
- Byta översättning eller parallell uppsättning med ett tryck.
- Öppna en huvudfunktion var som helst i appen.
- Kolla något snabbt utan att klicka dig genom menyer.

## Tips

- Launchermenyn finns på nästan varje skärm, så du kan öppna den medan du läser ett kapitel.
- Kommandorutan stöder samma kommandon som kommandorutan på hemskärmen.
- Funktionsikonerna och deras ordning sparas lokalt på din enhet. De finns kvar efter omstart av appen.
- Senaste verser sparas lokalt på din enhet. De finns kvar efter omstart av appen.
