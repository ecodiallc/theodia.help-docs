---
title: Navigera mellan böcker, kapitel och verser
level: everyday
categories: [layout, read]
summary: Så rör du dig i Bibeln och hoppar dit du vill.
---

# Navigera mellan böcker, kapitel och verser

Den här guiden visar alla sätt att röra sig i Bibeln.

## Det enkla sättet: svep

- Svep **åt vänster** i ett kapitel för att gå till nästa kapitel.
- Svep **åt höger** för att gå tillbaka.
- Det fungerar även mellan böcker. Efter sista kapitlet i till exempel Andra Mosebok tar svepet dig till första kapitlet i Tredje Mosebok.

## Menysättet

- Tryck på översättningens namn högst upp för att byta till en annan bibel.
- Tryck på boknamnet högst upp för att välja en annan bok.
- Tryck på kapitelnumret för att välja ett annat kapitel.

## Det snabba sättet: skriv

- På startsidan finns en ruta högst upp. Skriv en referens, som `John 3:16` eller `psalms 23`, och tryck på **Kör**-tangenten på tangentbordet.
- Appen öppnar versen.

## Bokmärkessättet

Har du sparat en vers, öppna fliken **Bokmärken**. Tryck på en post för att hoppa till den.

## Söksättet

Tryck på fliken **Sök**. Skriv ett ord. Appen visar alla verser som innehåller det. Tryck på en träff för att öppna den.

## Historiesättet

Appen minns de kapitel du har öppnat. För att hitta dem igen, titta i fliken **Bokmärken** (för verser du sparat) eller bläddra i boklistan på fliken **Bibel** för att hitta en bok du läst nyligen.

## Tips

- Fliken Bibel visar böckerna i ordning från Första Mosebok till Uppenbarelseboken.
- För Psaltaren, Ordspråksboken och andra långa böcker, tryck på boken och använd kapitellistan för att hoppa långt fram.
