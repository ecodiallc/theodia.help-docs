---
title: Applayout och navigering
level: beginner
categories: layout
summary: En rundtur på hemskärmen, huvudmenyn och nedre verktygsraden — var allt finns.
---

# Applayout och navigering

Theodia har tre huvudområden som du kan röra dig mellan: **hemskärmen**, **huvudmenyn** och **nedre verktygsraden**. Den här guiden går igenom var och en så att du alltid vet vart du ska gå.

## En snabb karta

- **Hemskärmen** är sidan du ser när du först öppnar appen. Den har en sökruta, stora knappar för varje del av appen och en lista över dina installerade biblar, böcker och andakter.
- **Nedre verktygsraden** (även kallad fliken) är raden med ikoner längst ner på skärmen. Tryck på någon av dem för att hoppa direkt till den delen av appen.
- **Huvudmenyn** är ikonen med tre streck (☰) uppe till höger på hemskärmen. Tryck på den för att öppna en lista över varje skärm i appen, även de som inte har en egen flik.

## Hemskärmen

När du först öppnar Theodia hamnar du på hemskärmen. Den är uppdelad i fyra delar, uppifrån och ner.

### Sidhuvudet

Allra högst upp finns en färgad rad. Till vänster finns appikonen och namnet "Theodia". Till höger finns huvudmenyknappen (☰). Är du inne i en bok eller ett kapitel visar vänstersidan en tillbaka-knapp (←) istället. Tryck på huvudmenyn för att öppna menyn (se nedan).

### Kommandot

Strax under sidhuvudet finns en sökruteliknande textruta märkt **Kommando**. Skriv en kort instruktion och tryck på kör-knappen på tangentbordet. Appen läser instruktionen och tar dig till rätt skärm. Exempel:

- `psalms 23` — öppnar Psaltaren kapitel 23
- `john 3:16` — öppnar Johannes 3:16
- `search love` — söker i Bibeln efter "love"
- `bookmark john 3:16` — sparar Johannes 3:16 som bokmärke
- `commentary romans 8:28` — öppnar kommentaren till den versen
- `xref` (följt av en referens) — öppnar korsreferenserna till den versen
- `help` — öppnar kommandolistan med exempel

Förstår inte appen vad du skrev visar den en liten varning med ett tips. Se guiden **Vanliga problem** om kommandona inte fungerar.

### Knapprutnätet

Under Kommandot finns ett rutnät av stora knappar, två per rad. Varje knapp tar dig till en annan del av appen. Knapparna är:

- 📖 **Biblar** — din lista över bibelöversättningar
- 🔍 **Sök** — sök i Bibeln efter ett ord eller en fras
- 📚 **Böcker** — ditt bibliotek av kristna klassiker
- 📅 **Andakter** — dagliga andakter
- 🔖 **Bokmärken** — dina sparade verser och kapitel
- 🖍 **Markeringar** — dina färgmarkerade verser
- 📝 **Anteckningar** — dina privata anteckningar om verser
- ⚙️ **Inställningar** — språk, tema, resurser med mera
- ❓ **Hjälp** — hjälpsystemet (den här sidan)
- ℹ️ **Om** — appversion och tack

### Resurslistorna

Under knapprutnätet finns utfällbara avdelningar: **Biblar**, **Böcker** och **Andakter**. Varje avdelning visar de poster du har installerat. Tryck på en avdelningsrubrik för att fälla ut eller ihop den. Tryck på en post i en avdelning för att öppna den.

Bibelavdelningen är det snabbaste sättet att hoppa in i en viss översättning — inga menyer, bara tryck.

## Nedre verktygsraden

Nedre verktygsraden (flikraden) är raden med ikoner längst ner på skärmen. Den är synlig nästan överallt i appen, så du kan alltid hoppa till en annan avdelning. Flikarna du ser beror på ditt användarläge.

**Alla lägen ser:**

- 🏠 **Hem** — öppnar hemskärmen
- 📖 **Biblar** — öppnar din lista över bibelöversättningar
- 📚 **Böcker** — öppnar ditt bokbibliotek
- 🔍 **Sök** — öppnar bibelsökning
- ⚙️ **Inställningar** — öppnar inställningarna

**Standard- och Scholar-läget ser även:**

- 🔖 **Bokmärken** — öppnar dina sparade verser
- 🖍 **Markeringar** — öppnar dina färgmarkerade verser
- 📝 **Anteckningar** — öppnar dina privata anteckningar

**Scholar-läget ser även:**

- 💻 **AI** — öppnar AI-assistenten (om du har slagit på den i Inställningar)

Den aktuella fliken är framhävd. Tryck på en annan flik för att byta.

### Så fungerar verktygsraden

Varje flik i verktygsraden har sin egen **stack** av skärmar. När du trycker på en flik kommer du tillbaka till **där du var** i den flikens stack, inte till startsidan. Till exempel:

- Tryck på **Biblar** → du ser listan över bibelöversättningar.
- Tryck på en översättning → du ser listan över böcker.
- Tryck på en bok → du ser listan över kapitel.
- Tryck på ett kapitel → du läser kapitlet.
- Byt till **Bokmärken** för att kolla något.
- Tryck på **Biblar** igen → du kommer tillbaka till kapitlet du läste.

Varje flik minns var du var. Appen behåller din navigeringshistorik i varje flik, så att byta flik inte tappar din plats.

### Vad återställer en flik

En flik återställs bara till sin rotskärm när:

- Du redan är på fliken och trycker på samma flikikon igen. Det är ett snabbt sätt att komma tillbaka till början.
- Appen tvingas stängas och öppnas igen.

### Nedre flikar jämfört med huvudmenyn

- **Nedre flikar** — varje flik minns sin egen stack. Att trycka på en flik tar dig tillbaka dit du var.
- **Huvudmenyn** — att trycka på en post navigerar till den skärmen med samma fiksystem. Den öppnas inte som ett överlägg.

Använd flikarna för att byta uppgift. Använd huvudmenyn när du vill ha en fullständig lista över varje skärm i appen.

### När du använder verktygsraden

Använd verktygsraden när du vill byta vad du gör:

- Du läser ett kapitel och vill söka efter något annat → tryck på **Sök**.
- Du söker och vill kolla dina bokmärken → tryck på **Bokmärken**.
- Du är var som helst i appen och vill hem → tryck på **Hem**.

## Huvudmenyn

Huvudmenyn är knappen med tre staplade streck (☰) uppe till höger på hemskärmen. Tryck på den och en panel glider in från höger sida. Panelen visar varje skärm som ditt aktuella läge stöder:

- 🏠 **Hem**
- 📖 **Biblar**
- 📚 **Böcker**
- 🙏 **Andakter**
- 🔍 **Sök**
- 🔖 **Bokmärken** (Standard och Scholar)
- 🖍 **Markeringar** (Standard och Scholar)
- 📝 **Anteckningar** (Standard och Scholar)
- 💻 **AI-assistent** (endast Scholar, och bara om AI är påslaget)
- ⚙️ **Inställningar**
- ❓ **Hjälp**
- ℹ️ **Om**

Posten som motsvarar skärmen du är på är framhävd och har en liten punkt bredvid sig. Tryck på en post för att gå direkt dit. Tryck utanför panelen, på X:et uppe till höger eller på enhetens tillbaka-knapp för att stänga den utan att byta skärm.

### Hur huvudmenyn skiljer sig

Huvudmenyn är en rullgardinspanel, inte ett separat navigeringslager. När du trycker på en post navigerar appen till den skärmen på samma sätt som om du hade använt den nedre fliken eller knapprutnätet. Din nuvarande fliks stack bevaras, så du kan komma tillbaka dit du var genom att trycka på originalfliken igen.

Till exempel:

- Du läser Johannes 3. Du trycker på fliken **Bokmärken**. Du kommer till dina bokmärken. När du trycker på **Biblar** igen återvänder du till Johannes 3 — precis där du var.
- Du läser Johannes 3. Du öppnar huvudmenyn och trycker på **Anteckningar**. Dina anteckningar öppnas. För att komma tillbaka till Johannes 3, tryck på fliken **Biblar** och du återvänder till kapitlet automatiskt.

Flikarna byter sammanhang och minns var du var. Huvudmenyn är bara ett annat sätt att nå samma skärmar.

### När du använder huvudmenyn

Använd huvudmenyn när:

- Du vill öppna **Markeringar**, **Anteckningar**, **Andakter**, **Hjälp** eller **Om** — skärmar som inte har en egen flik i verktygsraden.
- Du är djupt inne i ett kapitel eller en sökning och snabbt vill kolla något utan att tappa din plats.
- Du vill öppna **Inställningar** utan att lämna skärmen du är på.

## Scholar-läget

Är ditt användarläge satt till **Scholar** får layouten extra flikar, meny poster och läsarverktyg som Reader- och Standard-läget döljer. Se guiden [Scholar-läget](theodia://help/scholar-mode) för en full genomgång av varje funktion.

## Hur de tre områdena passar ihop

- **Byt till en annan huvudavdelning** (Biblar, Sök, Bokmärken med flera) → nedre verktygsraden
- **Hoppa till en viss vers eller ett kommando** → Kommandot på hemskärmen
- **Bläddra bland alla tillgängliga skärmar** → knapprutnätet på hemskärmen
- **Kolla Anteckningar, Markeringar eller Hjälp utan att lämna din plats** → huvudmenyn
- **Öppna Inställningar var som helst** → huvudmenyn eller verktygsraden

Du kommer att använda alla tre. Ingen av dem är "rätt sätt". Välj det som är enklast för det du gör.

### Verktygsrad jämfört med huvudmeny: ett snabbt exempel

Tänk dig att du läser Romarbrevet 8 och vill markera en vers du gillar.

**Med verktygsraden:**

1. Tryck på versen för att öppna versmenyn.
2. Tryck på **Markera** och välj en färg.
3. Klart. Du lämnade aldrig kapitlet.

**Med huvudmenyn (om du vill granska dina markeringar):**

1. Tryck på ☰ för att öppna menyn.
2. Tryck på **Markeringar**. Din lista över markeringar öppnas.
3. Granska dem och tryck sedan på fliken **Biblar** för att återvända till Romarbrevet 8.

**Med verktygsraden (om du vill byta uppgift):**

1. Tryck på **Hem** eller **Bokmärken** i verktygsraden.
2. Du lämnar Romarbrevet 8 och går till den nya skärmen.
3. För att komma tillbaka till Romarbrevet 8, tryck på **Biblar** igen — du återvänder till kapitlet automatiskt.

## Tips

- Hemskärmen minns vilka avdelningar som är utfällda eller ihopfällda. Du behöver bara ställa in det en gång.
- Ser du inte en flik du förväntar dig, kontrollera två saker:

1. **Ditt användarläge** — Reader-läget döljer bokmärken, markeringar, anteckningar och AI. Standard-läget döljer AI. Byt läge i **Inställningar** → **Appanvändarläge**.
2. **Funktionsinställningar** — vissa flikar behöver slås på i **Inställningar** (till exempel AI-assistenten).
