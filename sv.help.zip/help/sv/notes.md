---
title: Skriva anteckningar
level: everyday
categories: [annotate, read]
summary: Så skriver du dina egna tankar bredvid en vers.
---

# Skriva anteckningar

> **Läge:** Anteckningar finns i läget **Standard** och **Scholar**. Fokusläget är endast för ren, distraktionsfri läsning. Du byter läge i **Inställningar** → **Appanvändarläge**.

Anteckningar är där du skriver dina egna tankar, böner eller studieidéer bredvid en vers. Varje anteckning är knuten till en viss vers.

## Så lägger du till en anteckning

1. Öppna versen.
2. Tryck på versen så att menyn visas.
3. Tryck på **Anteckning** i menyn. Den har en pennikon.
4. Skriv din anteckning.
5. Tryck på **Spara**.

Anteckningen är nu sparad med versen.

## Så läser du en anteckning

1. Öppna versen.
2. Leta efter pennmärket bredvid versen. Det betyder att det finns en anteckning.
3. Tryck på versen. Anteckningen visas nedanför.

## Så redigerar du en anteckning

1. Öppna versen med anteckningen.
2. Tryck på versen.
3. Tryck på **Anteckning** i menyn.
4. Gör dina ändringar.
5. Tryck på **Spara**.

## Så raderar du en anteckning

1. Öppna versen med anteckningen.
2. Tryck på versen.
3. Tryck på **Anteckning** i menyn.
4. Tryck på **Ta bort**.

## Så ser du alla dina anteckningar

Tryck på fliken **Anteckningar** längst ner. Du ser en lista över varje anteckning du har skrivit, sorterad efter datum.

## Sök i dina anteckningar

På fliken **Anteckningar**, tryck i **Sök**-rutan. Skriv ett ord. Appen hittar varje anteckning som innehåller ordet.

## Tips

- Anteckningar passar bra för predikningar, andakter och studiefrågor.
- Anteckningar är privata. De stannar på din enhet.
- Se guiden [Säkerhetskopiera dina data](theodia://help/backups) för att hålla dem säkra.
