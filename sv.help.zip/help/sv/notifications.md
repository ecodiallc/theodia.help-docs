---
title: Aviseringar och påminnelser
level: everyday
categories: [settings]
summary: Så slår du på, anpassar och hanterar offlinepåminnelser för bön, andakter, bibelplaner med mera.
---

# Aviseringar och påminnelser

Theodia kan påminna dig om bön, andakter, bibelplaner, flashcards och andra aktiviteter — även när appen är offline. Alla påminnelser schemaläggs på din enhet; ingen internetanslutning eller push-server behövs.

## Så slår du på eller av påminnelser

1. Öppna **Inställningar**.
2. Tryck på **Aviseringar**.
3. Slå på eller av **Aktivera påminnelser**.

Första gången du aktiverar påminnelser frågar appen om tillstånd att skicka aviseringar. Tryck på **Tillåt** så att påminnelserna kan visas.

Har du tidigare nekat tillståndet kan iOS eller Android blockera förfrågan. Gå i så fall till enhetens app **Inställningar**, hitta **Theodia** och slå på aviseringar där.

## Typer av påminnelser

Aviseringsskärmen är uppdelad i kanaler. Varje kanal är en familj av påminnelser som du kan slå på eller av var för sig:

- **Bönepåminnelser** — allmänna bönpåminnelser.
- **Bönerutin** — påminnelser knutna till en viss bönerutin.
- **Andakt** — påminnelsen för dagens vers eller andakt.
- **Bibelplanpåminnelser** — påminnelser för en aktiv bibelplan.
- **Theoscript-påminnelser** — påminnelser att köra ett Theoscript.
- **AI-insiktpåminnelser** — AI-genererade påminnelser.
- **Flashcard-repetering** — påminnelser att repetera flashcards.
- **Läsvanepåminnelser** — dagliga påminnelser om läsvanan.
- **Liturgiska och säsongsbundna påminnelser** — påminnelser knutna till kyrkoåret.
- **Mina påminnelser** — påminnelser du skapat från bokmärken, markeringar, spellistor, bibelkapitel eller böcker.
- **Egna påminnelser** — helt egna påminnelser som du skapar själv.

Tryck på en kanal för att se dess påminnelser, ändra tiden, välja vilka dagar den ska komma eller stänga av den.

## Egna påminnelser

Egna påminnelser är påminnelser du bygger från grunden.

1. I **Inställningar** → **Aviseringar**, tryck på **Egna påminnelser**.
2. Tryck på knappen **+**.
3. Ange en **Titel** och ett **Meddelande**.
4. Välj en **Tid**.
5. Välj de **Dagar** du vill att den ska upprepas.
6. Välj vad påminnelsen öppnar när du trycker på den (valfritt).
7. Tryck på **Spara**.

Du kan redigera eller radera en egen påminnelse när som helst genom att trycka på den i listan.

## Vad som händer när du trycker på en påminnelse

De flesta påminnelser öppnar en viss skärm i appen. Till exempel öppnar en bönerutinpåminnelse den rutinen; en bibelplanpåminnelse öppnar nästa läsning.

Har en påminnelse ingen kopplad skärm öppnar den appen på hemskärmen.

## Tysta timmar

Tysta timmar tystar aviseringsljuden men låter visuella påminnelser fortfarande visas.

1. I **Inställningar** → **Aviseringar**, tryck på **Tysta timmar**.
2. Ställ in en **Start**- och en **Slut**-tid.

Påminnelser som schemalagts under tysta timmar visas på skärmen utan ljud.

## Kommande påminnelser och historik

- **Kommande påminnelser** visar allt som är schemalagt att komma härnäst.
- **Aviseringshistorik** visar nyligen levererade, schemalagda och avbrutna påminnelser.

Använd de här listorna för att bekräfta att en påminnelse är rätt inställd eller för att se varför en inte dök upp.

## Om påminnelser inte visas

- Kontrollera att **Aktivera påminnelser** är på.
- Kontrollera att aviseringar är tillåtna i enhetens systeminställningar.
- Kontrollera att påminnelsens kanal är aktiverad och att minst en dag är vald.
- Har du ställt in tysta timmar kan påminnelsen vara tyst.
- Vissa Android-tillverkare låter appar somna. Lägg till Theodia i listan över tillåtna appar om din enhet har inställningar för batterioptimering.
- Är en påminnelse knuten till innehåll du tagit bort (till exempel en raderad bibelplan eller rutin) utlöses den kanske inte förrän du väljer ett giltigt mål igen.

## Aviseringsljud

Du kan välja ljudet som spelas av påminnelser som stöder ljud. Tryck på **Ljud** inne i en påminnelse eller kanal för att välja bland de tillgängliga alternativen. Ljuden följer med appen, så de fungerar offline.

Använd knappen **Förhandslyssna** för att höra det valda ljudet innan du sparar.

## Märken

Vissa påminnelser kan lägga till ett märke på appikonen. Tryck på **Rensa märke** på aviseringsskärmen för att nollställa det.
