---
title: PDF-filer
level: everyday
categories: [read, resources]
summary: Importera, ordna och läs PDF-dokument i Theodia.
---

# PDF-filer

> **Läge:** PDF-filer finns i läget **Standard** och **Scholar**. Fokusläget är endast för ren, distraktionsfri läsning. Du byter läge i **Inställningar** → **Appanvändarläge**.

Theodia kan lagra och läsa PDF-filer. Importerade PDF-filer stannar på din enhet, så de fungerar offline.

## Öppna PDF-biblioteket

Tryck på fliken **PDF-filer** längst ner på skärmen, eller tryck på rutan **PDF-filer** på hemskärmen.

## Importera en PDF

1. Öppna fliken **PDF-filer**.
2. Tryck på knappen **+** nere till höger.
3. Välj en PDF från din enhet.
4. (Valfritt) Skriv eller välj en kategori för att ordna den.

## Ordna PDF-filer

Håll inne ett PDF-kort för att öppna en meny med de här valen:

- **Byt namn** — ändra titeln som visas i biblioteket.
- **Ändra kategori** — flytta PDF-filen till en kategori.
- **Ta bort** — ta bort PDF-filen från Theodia. Det raderar också den sparade läspositionen.

Kategorier är fritext. Skriv ett nytt namn eller välj ett befintligt när du importerar eller ändrar en kategori.

## Läs en PDF

Tryck på ett PDF-kort för att öppna den. Läsaren visar:

- Dokumentets titel i en rad högst upp.
- En rad med sidknappar: **Första sidan**, **Föregående**, den aktuella sidan ("3 / 120"), **Nästa** och **Sista sidan**.
- Ett verktygsfält med dokumentets verktyg: **Innehåll**, **Zooma ut**, **Zooma in**, **Nollställ zoom**, **Bokmärke**, **Sök**, **Lyssna** och **Textvy**.

Vissa verktyg är dämpade när de inte kan användas — till exempel är **Sök** och **Lyssna** dämpade tills PDF:ens sökbara text är installerad.

### Bläddra sidor

- Tryck på **vänster-** eller **högerpilen** för att gå bak eller fram en sida.
- Tryck på **Första sidan** eller **Sista sidan** för att hoppa till antingen änden av dokumentet.
- Tryck på sidnumret (till exempel "3 / 120") för att öppna ett sidrutnät, och tryck sedan på sidan du vill ha. Rutnätet öppnas nära sidan du är på.
- Använd **vänster- och högerpiltangenterna** på ett externt tangentbord.

### Zooma

- Tryck på **Zooma in** (+) eller **Zooma ut** (−) för att ändra sidstorleken.
- Tryck på **Nollställ zoom** för att återställa sidan till normal storlek.
- Zoomar du in, bläddrar sidan och sedan zoomar ut tar Theodia dig tillbaka till sidan du läste.

## Söka i en PDF

1. Öppna PDF-filen och tryck på knappen **Sök** (förstoringsglaset) i verktygsfältet.
2. Skriv vad du letar efter. Träffar visas medan du skriver, med sidnumret och ett stycke av den omgivande texten.
3. Tryck på en träff för att hoppa till den sidan.

Sökning kräver att PDF:ens sökbara text är installerad. Är den inte installerad än är Sök-knappen dämpad. PDF-filer installerade från communityns GitHub-arkiv innehåller sökbar text; PDF-filer du importerar själv har den inte förrän den lagts till.

## Innehåll

Har PDF-filen en inbyggd innehållsförteckning visar knappen **Innehåll** i verktygsfältet den som en disposition. Tryck på en rubrik för att hoppa till den sidan. Avdelningar kan fällas ut och ihop. Har PDF-filen ingen innehållsförteckning är knappen dämpad.

## Bokmärken i en PDF

1. Öppna PDF-filen och tryck på knappen **Bokmärke** i verktygsfältet.
2. Tryck på **Bokmärk sidan** för att spara den aktuella sidan. Namnet börjar som sidnumret — skriv gärna ett namn istället — och tryck sedan på **Spara**.
3. Tryck på ett bokmärke i listan för att hoppa till dess sida.
4. Tryck på **×** bredvid ett bokmärke för att ta bort det.

PDF-bokmärken är skilda från dina bibelbokmärken. Varje PDF har sin egen lista.

## Läs upp en PDF

Är PDF:ens sökbara text installerad kan Theodia läsa upp den aktuella sidan:

1. Öppna PDF-filen och tryck på knappen **Lyssna** (högtalaren) i verktygsfältet.
2. En kontrollrad visas med **Spela/Pausa**, **Spola tillbaka**, **Spola framåt**, **Stoppa**, en förloppsrad du kan trycka på för att hoppa inom sidan, uppläsningshastigheten och rösten.
3. När sidan är klar fortsätter uppläsningen automatiskt på nästa sida.

Röst och hastighet är desamma som används för bibelläsning — se [Läsa upp](theodia://help/tts) för hur du ändrar dem.

## Kopiera, dela eller spara sidtext

Tryck på knappen **Textvy** i verktygsfältet för att se den aktuella sidan som ren text. Därifrån kan du:

- **Kopiera** — kopiera sidtexten till urklipp.
- **Dela** — dela sidtexten via valfri app på din enhet.
- **Lägg till i studieanteckningar** — öppnar en anteckningsredigerare med sidtexten, en källhänvisning och en länk tillbaka till sidan ifylld för dig.

## Fortsätt läsa

Theodia minns den sista sidan du visade och öppnar PDF-filen där nästa gång.

## Ladda ner PDF-filer från GitHub

I läget **Scholar** visas en knapp **Ladda ner från GitHub** längst ner i biblioteket. Den ansluter till communityns PDF-arkiv så att du kan installera paketerade PDF-dokument på samma sätt som du installerar biblar eller böcker.

## Obs

- PDF-filer lagras i Theodias privata dokumentmapp. De ingår inte i säkerhetskopior, så om du byter till en ny enhet behöver du importera dem igen.
