---
title: Spellistor
level: everyday
categories: playlists
summary: Skapa och lyssna till upplästa spellistor med bibelavsnitt, ren text eller valfri vers du vill höra.
---

# Spellistor

En **spellista** är en lista med spår som Theodia kan läsa upp för dig. Varje spår är antingen ett bibelavsnitt eller en kort anteckning i ren text. Spellistor är praktiska för handsfree-lyssnande på pendlingen, på en promenad, vid andaktstid eller när du pluggar in verser.

Spellistor visas i appen så snart minst en spellista har skapats eller fyllts på.

## Var du hittar spellistorna

När spellistor finns kan du nå dem på två sätt:

- **Hemskärmen:** I avdelningen **Plugin med mera**, tryck på **Spellistor**.
- **Huvudmenyn:** Öppna menyn (☰) och tryck på **Spellistor**.

Finns det inga spellistor än är spellistans ruta och meny post dolda.

## Vad en spellista innehåller

Varje spellista har:

- Ett **namn** — till exempel "Morgonverser" eller "Plugga in Psaltaren 23".
- En valfri **kategori** — bra för att gruppera spellistor efter syfte.
- En lista med **spår** — posterna som ska läsas upp.

Varje spår innehåller:

- **Innehåll** — antingen en bibelreferens eller ren text.
- En **etikett** — visas på skärmen medan spåret spelas.
- En valfri **röst** — välj en annan röst för just det här spåret om du vill.

## Skapa en spellista

1. Öppna skärmen **Spellistor**.
2. Tryck på **Skapa spellista** (eller knappen **+**).
3. Ge spellistan ett namn.
4. (Valfritt) Välj eller skapa en kategori.
5. Börja lägga till spår.

### Lägga till ett spår från ett bibelavsnitt

1. Tryck på **Lägg till spår**.
2. Välj **Bibelavsnitt** som innehållstyp.
3. Ange en referens, som `John 3:16` eller `Psalm 23:1-6`.
4. Lägg till en etikett om du vill, eller lämna den tom för att använda referensen.
5. Spara spåret.

### Lägga till ett spår i ren text

1. Tryck på **Lägg till spår**.
2. Välj **Ren text**.
3. Skriv texten som du vill att Theodia ska läsa.
4. Lägg till en etikett.
5. Spara spåret.

### Lägga till spår i grupp

Har du en lista med referenser eller textrader, använd **Lägg till i grupp**:

1. Öppna en spellista.
2. Tryck på menyn och välj **Lägg till i grupp**.
3. Klistra in en referens eller textrad per rad.
4. Slå på **Identifiera bibelreferenser** om de flesta rader är versreferenser.
5. Tryck på **Lägg till**. Varje rad blir ett spår.

## Lyssna på en spellista

1. Öppna spellistan du vill höra.
2. Tryck på knappen **Spela** längst upp eller bredvid ett spår.
3. Theodia läser upp varje spår i ordning.

Medan en spellista spelas visas en kontrollrad med de här kontrollerna:

- **Spela / Pausa**
- **Nästa spår**
- **Föregående spår**
- **Stoppa**

Du kan också ställa in:

- **Hastighet** — hur snabbt rösten läser.
- **Upprepning** — upprepa hela spellistan, upprepa ett spår eller spela en gång.
- **Blanda** — spela spåren i slumpordning.
- **Ignorera parenteser** — hoppa över text inom parenteser.
- **Paus mellan spår** — lägg till en kort tystnad mellan spåren.
- **Insomningstimer** — stoppa uppspelningen efter en viss tid.

## Redigera en spellista

För att ändra en spellista, pausa först uppspelningen om den spelas just nu.

Du kan:

- **Byta namn** på spellistan.
- **Ordna om spår** — dra spåren i en ny ordning.
- **Redigera ett spår** — ändra referensen, texten, etiketten eller rösten.
- **Ta bort ett spår** — ta bort det från spellistan.
- **Ta bort hela spellistan** — det kan inte ångras.

## Exportera och importera spellistor

Spellistor exporteras som JSON-filer som innehåller alla spår, kategorier och inställningar. Du kan dela filen med en annan enhet, spara den som backup eller redigera den på en dator.

- **Exportera alla spellistor** — skapar en fil `playlists-YYYY-MM-DD.json`.
- **Exportera en kategori** — skapar en JSON-fil med bara spellistorna i en kategori.
- **Importera spellistor** — återställer spellistor från en JSON-backupfil.

## Snabba sätt att bygga en spellista

Du kan också skapa en hel spellista som JSON och importera den. Här är ett exempel:

```json
{
  "playlists": [
    {
      "name": "Morning Verses",
      "category": "Devotional",
      "tracks": [
        {
          "info": "John 3:16",
          "contentSource": "passage",
          "content": "For God so loved the world...",
          "rawContent": "John 3:16"
        },
        {
          "info": "Psalm 23",
          "contentSource": "passage",
          "content": "The Lord is my shepherd...",
          "rawContent": "Psalm 23:1-6"
        }
      ]
    }
  ]
}
```

Spara filen och använd sedan **Importera spellistor** för att läsa in den i Theodia.

## Tips

- Spellistor fungerar bäst med korta, avgränsade uppsättningar verser.
- Använd kategorier för att skilja andaktsspellistor från spellistor för inpluggning.
- Ställ in en insomningstimer om du lyssnar när du somnar.
- Använder ett spår fel röst, kontrollera att röstens språk stämmer med textens språk.
- Theodia läser ren text exakt som den är skriven; kontrollera stavningen för bästa resultat.
