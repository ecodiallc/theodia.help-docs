---
title: Överblick av bön
level: beginner
categories: prayer
summary: En snabb introduktion till fliken Bön och dess huvudavdelningar.
---

# Överblick av bön

Fliken **Bön** är en tillgängad plats för bön. Den samlar listor, ledda sessionsstillfällen, en journal, en timer, lektionarie-läsplaner och klassiska fasta böner.

## Huvudavdelningarna

- **Bönelista** — håll koll på människor, situationer och ämnen du ber för.
- **Journal** — skriv ned reflektioner, svar och tankar över tid.
- **Generera bön** — be Theophilus skriva en bön utifrån ett ärende eller en journalepost.
- **Trosbekännelser & fasta böner** — klassiska böner och trosbekännelser från den kristna traditionen.
- **Lektionarie** — läsplaner för daglig eller säsongsbunden bön.
- **Ledd bön** — audioledda bönetillfällen med text-till-tal.
- **Timer** — tidsinställda bönetillfällen med valfria klockringningar.
