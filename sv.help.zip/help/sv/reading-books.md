---
title: Läsa inbyggda böcker
level: beginner
categories: [content, read]
summary: Så läser du de kristna klassikerna som följer med appen.
---

# Läsa inbyggda böcker

Theodia kommer med ett litet bibliotek av kristna böcker. Det är klassiker som du kan läsa på din enhet.

## Så öppnar du biblioteket

Tryck på fliken **Böcker** längst ner på skärmen. Du ser en lista över böckerna i ditt bibliotek.

## Så läser du en bok

1. Tryck på bokens titel.
2. Boken öppnas på första kapitlet.
3. Använd knapparna **Föregående** och **Nästa** längst upp för att röra dig mellan kapitlen.

## Så hoppar du till ett kapitel

Tryck på kapitelnamnet högst upp på skärmen. En lista över kapitlen visas. Välj ett kapitel att hoppa till.

## Så ändrar du textstorleken

Öppna **Inställningar** → **Utseende** och välj en textstorlek. Textstorleken ändras i hela appen, även i böcker.

## Så lägger du till ett bokmärke i en bok

Tryck på **stjärnikonen** uppe till höger. Det aktuella kapitlet sparas. Tryck på fliken **Bokmärken** för att se dina sparade sidor.

## Så lyssnar du på en bok

Tryck på **högtalarikonen** uppe till höger. Appen läser upp kapitlet. Tryck igen för att stoppa.

## Vilka böcker finns?

Biblioteket har klassiker som:

- Pilgrimens utveckling
- Kristi efterföljelse
- Övningen i Guds närvaro
- Psalmboken

Boklistan kan växa med tiden. Appuppdateringar kan lägga till fler.

## Tips

- Böckerna lagras på din enhet. Inget internet behövs.
- Böckerna synkas inte till molnet.
