---
title: Hitta resurser på GitHub
level: everyday
categories: resources
summary: Sök i alla GitHub-arkiv appen känner till på en gång, och installera det du hittar.
---

# Hitta resurser på GitHub

Theodia har en lista över GitHub-arkiv som publicerar resurser — biblar, kommentarer, böcker, andakter, spellistor, bönepaket med mera. **Sök i GitHub-arkiv** söker i alla på en gång, så att du inte behöver öppna varje flik och bläddra separat.

> GitHub-avdelningen i Inställningar finns bara i **Scholar-läget**. För att slå på det, gå till **Inställningar → Användarläge → Scholar**.

## Så söker du

1. Öppna **Inställningar**.
2. Tryck på **Sök i GitHub-arkiv**.
3. Skriv ett ord i sökrutan. Appen letar efter ordet i **namnet** och **beskrivningen** av varje paket i varje arkiv.

Några saker att veta om sökningen:

- **Varje ord måste matcha.** Att söka `morning evening` hittar bara paket vars namn eller beskrivning innehåller *båda* orden.
- **Stor-/småbokstäver spelar ingen roll.** `Morning` och `morning` hittar samma paket.
- **Den bästa träffen kommer först.** Ett paket vars namn *börjar* med din sökning visas före ett som bara nämner det i beskrivningen.

## Filtrering

Tryck på filterraden ovanför träffarna för att snävra listan ytterligare. Det finns två filter, och de fungerar tillsammans:

- **Upphovsman** — bara paket av den upphovsmannen.
- **Tradition** — bara paket för den traditionen.

Tryck på ett filter igen för att rensa det, eller tryck på **Rensa filter** för att nollställa båda.

## Installera från en träff

Varje träff visar paketets namn, vilken sorts resurs det är, vem som gjort det och vilket arkiv det kommer från. Till höger om raden finns en knapp:

- **Installera** — paketet finns inte på din enhet ännu.
- **Uppdatera** — en nyare version finns. Appen ber dig först bekräfta, eftersom uppdateringen tar bort den gamla kopian tillsammans med anteckningar, markeringar eller bokmärken som pekar på den.
- **Öppna** — paketet är redan installerat; ett tryck tar dig till skärmen där du använder det.

Tryck på **Uppdatera** längst upp för att hämta den senaste listan från GitHub direkt. Appen uppdaterar listan själv en gång om dagen, så en manuell uppdatering behövs bara när du vet att något nytt har publicerats.

## Söka utan anslutning

Appen har en kopia av listan på din enhet, så sökning fungerar även när du är offline. Kan inte appen nå GitHub för att uppdatera listan, talar en banderoll högst upp om att du ser de cachade träffarna.

## Om en sökning inte hittar något

- Prova ett kortare, enstaka ord.
- Kontrollera att inget filter **Upphovsman** eller **Tradition** fortfarande är aktivt — knappen **Rensa filter** visas så länge som ett är det.
- Vissa arkiv publicerar sina paket på ett annat språk än paketnamnet, så att söka efter ett översatt ord kanske inte hittar dem.
