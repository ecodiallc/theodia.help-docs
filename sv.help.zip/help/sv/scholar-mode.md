---
title: Scholar-läget
level: advanced
categories: [layout, read, study]
summary: Det djupaste studieläget i Theodia, som öppnar kommentarer, lexikon, korsreferenser, AI-verktyg och launchermenyn.
---

# Scholar-läget

> **Läge:** Scholar-läget finns bara när ditt användarläge är satt till **Scholar**. Byt läge i **Inställningar** → **Appanvändarläge**.

Scholar-läget öppnar alla studieverktyg i Theodia. Det är byggt ovanpå studieläget, så du får fortfarande versmenyn, parallella biblar, bokmärken, markeringar och anteckningar — plus de avancerade verktyg som listas nedan.

## Så öppnar du Scholar-läget

Scholar-läget är inte en separat skärm. Det är en uppsättning extra verktyg som visas inne i den befintliga läsaren och navigeringen när ditt användarläge är satt till Scholar.

1. Öppna **Inställningar**.
2. Tryck på **Appanvändarläge**.
3. Välj **Scholar**.

Ändringen träder i kraft direkt. Menyer och knappar som var dolda visas nu.

## Extra läsverktyg

När du öppnar ett kapitel i [studieläget](theodia://help/study-mode) lägger Scholar-läget till de här verktygen i versmenyn:

- **AI-kommentar** (◈) — be AI-assistenten skriva en studieanteckning för versen. (Finns inte i alla regioner.)
- **Ordinfo** (?) — öppna en lexikonpost för det hebreiska eller grekiska ord som ligger bakom versen. Se guiden [Kommentarer och lexikon](theodia://help/commentaries-and-lexicons).
- **Ordbok** (📖) — slå upp allmänna bibelord i de ordboksresurser du har installerat. Se guiden [Bibelordboken](theodia://help/dictionary).

De här verktygen behöver resurser installerade (kommentarer, lexikon, ordboksfiler). Är ett verktyg gråtonat eller visar "hittades inte", öppna **Inställningar** → **Hantera resurser** och lägg till den resurs det behöver.

## Extra navigering

### Extra flik i verktygsraden

Nedre verktygsraden får en extra flik:

- 💻 **AI** — öppnar AI-assistenten (bara om du har slagit på AI i Inställningar). Fliken ligger till höger om Anteckningar.

### Extra poster i huvudmenyn

Huvudmenyn innehåller en post **AI-assistent** under samma villkor.

## Launchermenyn

Scholar-läget aktiverar **launchermenyn**, ett snabbt sätt att hoppa till senaste verser, köra kommandon och byta bibellayout utan att lämna din nuvarande skärm. Se guiden [Launchermenyn](theodia://help/launcher-menu) för hur du använder den.

## När du använder Scholar-läget

- Du vill ha AI-assistenten, kommentarer eller originalspråksuppslag medan du läser.
- Du vill ha launchermenyn för snabb versnavigering och AI-chatt.
- Du studerar ett avsnitt på djupet och behöver alla verktyg ett tryck bort.

## Byta till ett enklare läge

Vill du ha en enklare läsare utan de avancerade verktygen, byt till läget **Standard** i **Inställningar** → **Appanvändarläge**. Standard-läget behåller bokmärken, markeringar, anteckningar och studieläget men döljer AI, kommentarer, lexikon och launchermenyn.

Vill du ha den renaste möjliga läsupplevelsen, öppna ett kapitel i [fokusläget](theodia://help/focus-mode).

Dina bokmärken, markeringar och anteckningar raderas aldrig när du byter läge; de är bara dolda tills du återvänder till ett läge som stöder dem.

## Hjälp och frågor

Saknas ett verktyg eller visar det ett fel, se guiden [Vanliga problem](theodia://help/common-problems). Är du ny i Theodia går guiden [Läsa ditt första kapitel](theodia://help/first-read) igenom grunderna steg för steg.
