---
title: Söka i Bibeln
level: everyday
categories: [study, read]
summary: Så hittar du verser efter ord, fras eller referens.
---

# Söka i Bibeln

Sökrutan hjälper dig att snabbt hitta verser. Du kan söka på ett ord, en fras eller en bibelreferens.

## Så startar du en sökning

1. Tryck på fliken **Sök** längst ner på skärmen.
2. Skriv vad du vill hitta.
3. Tryck på **Sök** på tangentbordet.

Träffarna visas som en lista med verser. Varje träff visar bok, kapitel och vers, plus versens text.

## Söka på ordkombinationer

Skriver du mer än ett ord, som `love joy`, hittar appen verser som innehåller **båda** orden. Det är en **OCH**-sökning — alla orden måste finnas i versen. Den använder **inte** **ELLER**-logik (verser med något enstaka ord).

För att söka efter verser som innehåller något av orden måste du använda nyckelordet `OR` uttryckligen: `love OR joy`.

## Söka på ett ord

Skriv ett enstaka ord, som `love` eller `mercy`. Appen visar varje vers i Bibeln som har det ordet.

## Söka på en fras

Skriv två eller tre ord inom citattecken, som `"do not be afraid"`. Appen visar verser som har exakt den frasen.

## Filtrera träffarna

Efter en sökning filtreras träffarna till de bibelöversättningar du har installerat. För att snävra ytterligare, öppna fliken **Bibel** och titta på en viss översättning — sökningar körs mot de översättningar du har.

## Tips för bättre sökningar

- Använd korta ord. Sökningar på `love` hittar fler verser än sökningar på `loving`.
- Citattecken runt en fras gör sökningen exakt.
- Appen söker bara i de bibelöversättningar du har installerat.
- För att hoppa till en viss vers via referens (till exempel `John 3:16`), använd **Kommando**-rutan på hemskärmen istället för fliken Sök.

## Sökhistorik

Appen minns dina senaste sökningar. När du öppnar fliken **Sök** visas dina senaste sökningar högst upp i listan. Tryck på en för att köra den igen. För att rensa listan, tryck på **Rensa alla** högst upp över de senaste sökningarna.

## Söka i PDF-filer

Fliken Sök kan också söka i dina PDF-dokument:

1. Tryck på fliken **Sök** och sedan på läget **PDF-filer** högst upp.
2. Välj vilka PDF-filer som ska sökas. Tryck på en PDF för att inkludera eller utesluta den; använd **Alla** eller **Rensa** ovanför listan för att inkludera allt eller börja om. Bara PDF-filer vars sökbara text är installerad kan väljas.
3. Skriv vad du vill hitta och tryck på **Sök**.

Varje träff visar PDF:ens titel, sidnumret och ett stycke av den matchande texten. Tryck på en träff för att öppna den PDF:en på den sidan.

För att söka i en enda PDF medan du läser den, använd knappen **Sök** i PDF-läsaren istället — se [PDF-filer](theodia://help/pdfs).
