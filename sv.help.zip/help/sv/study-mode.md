---
title: Studieläget
level: everyday
categories: [layout, read]
summary: Den fullständiga bibelläsaren i Theodia, fullpackad med studieverktyg som kommentar, korsreferenser, lexikon och anteckningar.
---

# Studieläget

> **Läge:** Studieläget finns i läget **Standard** och **Scholar**. Reader-läget öppnar kapitel i fokusläget istället. Du byter läge i **Inställningar** → **Appanvändarläge**.

Studieläget är huvudbibelläsaren i Theodia. Det har alla studieverktyg inbyggda: kommentar, korsreferenser, orduppslag, parallella översättningar, anteckningar med mera.

Fokusläget är en enklare läsare utan studieverktyg. Se guiden [Fokusläget](theodia://help/focus-mode) om du bara vill ha ren text. Den här guiden handlar om studieläget.

## Så öppnar du studieläget

Det finns några sätt att öppna ett kapitel i studieläget:

- Tryck på fliken **Bibel** längst ner på skärmen. Välj en översättning, en bok och ett kapitel.
- Tryck på en vers i **sök**träffarna.
- Tryck på ett bokmärke från fliken **Bokmärken**.
- Från fokusläget, tryck på knappen 📖 högst upp på skärmen för att byta till studieläget.

## Läsa kapitlet

Kapitlet öppnas med verserna i ordning. Högst upp på skärmen finns knappar för de vanligaste åtgärderna. Längst ner på skärmen finns en statusrad.

- **Svep åt vänster** för att gå till nästa kapitel.
- **Svep åt höger** för att gå till föregående kapitel.
- **Tryck på en vers** för att öppna versmenyn med studieverktyg (se nedan).
- **Tryck på ett Strong's-nummer i en vers** (till exempel G1234 eller H1234) för att öppna ett snabbt lexikonuppslag för det ordet.

Har du en parallell översättning påslagen visas en andra kopia av kapitlet under den huvudsakliga, i den översättning du valde. Se **Läsa två översättningar samtidigt** nedan.

## Versmenyn

När du trycker på en vers öppnas en meny med titeln "Bok Kapitel:Vers". Verktygen du ser beror på ditt användarläge.

### Verktyg i Standard- och Scholar-läget

- **Bokmärke** (★) — spara versen så att du hittar den igen. Tryck igen för att ta bort bokmärket. Första trycket lägger till det. Se guiden [Bokmärka verser](theodia://help/bookmarks).
- **Markera** (□) — färga versen så att den syns. Tryck för att öppna en färgväljare. Tryck på samma färg igen för att ta bort markeringen. Se guiden [Markera verser](theodia://help/highlights).
- **Läs upp** (🔊) — låt versen läsas upp med enhetens text-till-tal-röst. Det visas inte för interlineära biblar. Se guiden [Läsa upp](theodia://help/tts) för hur du använder den och väljer en röst.
- **Kopiera** (⎘) — lägg versens text i urklipp så att du kan klistra in den var som helst.
- **Jämför** (⇄) — öppna en panel som visar samma vers i alla översättningar du har installerat. Tryck på en översättning i panelen för att läsa versen i den översättningen. Se guiden [Jämföra översättningar](theodia://help/compare-translations).
- **Korsreferenser** (↗) — öppna en lista över relaterade verser från korsreferensdatabasen. Se guiden [Korsreferenser](theodia://help/cross-references).
- **Lägg till/ändra bibelanteckning** (✎) — skriv din egen privata anteckning kopplad till versen. Se guiden [Skriva anteckningar](theodia://help/notes).

### Verktyg endast i Scholar-läget

- **AI-kommentar** (◈) — be AI-assistenten skriva en studieanteckning för versen. (Finns inte i alla regioner.)
- **Ordinfo** (?) — öppna en lexikonpost för det hebreiska eller grekiska ord som ligger bakom versen. Se guiden [Kommentarer och lexikon](theodia://help/commentaries-and-lexicons).
- **Ordbok** (📖) — slå upp allmänna bibelord i de ordboksresurser du har installerat. Se guiden [Bibelordboken](theodia://help/dictionary).

Vissa verktyg behöver extra resurser installerade. Är ett verktyg gråtonat eller visar "hittades inte", öppna **Inställningar** → **Hantera resurser** och lägg till den resurs det behöver.

## Knappar överst på skärmen

Ovanför kapiteltexten finns en rad med ikoner. Det här är snabbåtgärderna:

- **Bibelversion** — tryck på översättningens namn (till exempel "KJV") för att byta till en annan översättning.
- **Bok** — tryck på boknamnet för att hoppa till en annan bok.
- **Kapitel** — tryck på kapitelnumret för att hoppa till ett annat kapitel.
- **Öppna i AI** (🤖) — skicka det aktuella kapitlet till AI-assistenten med din fråga. (Endast Scholar-läget.)
- **Fokusläge** (📖) — byt till fokusläget för ren läsning.
- **Parallella biblar** (🔵 / ⚪) — tryck för att slå parallella översättningar på eller av. Påslaget visas samma kapitel i dina valda parallella översättningar under huvudtexten. Avslaget visas bara huvudöversättningen. Se **Läsa flera översättningar samtidigt** nedan.
- **Lyssna** — låt hela kapitlet läsas upp. Se guiden [Läsa upp](theodia://help/tts).
- **Mer** — öppna extra kapitelåtgärder (kapitelbibelanteckning, kapitelkommentar, dela med mera).

## Läsa flera översättningar samtidigt

Du kan visa upp till fyra extra översättningar bredvid din huvudsakliga. Det kallas **parallellvy**.

1. Öppna **Inställningar**.
2. Slå på **Parallell bibel**.
3. Tryck på **Lägg till parallell bibel** och välj en översättning.
4. Upprepa för att lägga till fler. Du kan ha upp till fyra parallella översättningar.

Är parallellvyn på visar varje vers i kapitlet din huvudöversättning först, följt av samma vers i varje parallell översättning. Det gör det lätt att jämföra hur olika översättare hanterar en svår vers utan att lämna kapitlet.

Du kan spara din nuvarande parallella uppsättning som ett **preset**. Tryck på sparaknappen bredvid dina valda översättningar, ge den ett namn, och den blir ett snabbbytesalternativ. Tryck på ett preset senare för att direkt ladda den kombinationen. Håll inne ett preset för att ta bort det.

Du kan också jämföra en enda vers i taget med verktyget **Jämför** (⇄) i versmenyn. Det öppnar en panel som visar versen i alla installerade översättningar.

## Underrubriker

Vissa översättningar har avdelningsrubriker inbyggda (till exempel "Bergspredikan"). Har din översättning dem kan du visa eller dölja dem med inställningen **Visa underrubriker** i **Inställningar**. Underrubriker visas som små grå titlar mellan verserna.

## Kapitelanteckningen

En kapitelanteckning är en enda anteckning knuten till hela kapitlet, inte till en enda vers. Den är bra för en stor tanke om kapitlet.

Så öppnar du kapitelanteckningen:

1. Tryck på knappen **Mer** högst upp på skärmen.
2. Tryck på **Kapitelanteckning**.
3. Skriv din anteckning. Tryck på **Spara**.

Kapitelanteckningen sparas med kapitlet. Den visas varje gång du öppnar kapitlet.

## Sökmarkeringar

Kom du till kapitlet från en sökning är dina sökord markerade i gult i versetexten. Det gör det lätt att se varför en vers matchade.

Du kan också köra en sökning igen på ett kapitel du läser. Öppna fliken **Sök** och skriv in ett ord. Träffarna låter dig trycka direkt tillbaka in i kapitlet med matchningarna markerade.

Interlineära biblar (MIB — Marvel Interlinear Bible — och OHGB) öppnas alltid i studieläget eftersom de behöver ordnivå-layouten.

## Byta till fokusläget för ett enskilt kapitel

Från vilket kapitel som helst i studieläget, tryck på knappen 📖 högst upp. Samma kapitel öppnas i fokusläget med alla menyer dolda. Tryck på knappen 📖 i nedre raden för att byta tillbaka till studieläget.

## När du använder studieläget

Studieläget är rätt val när du vill:

- **Läsa och studera samtidigt.** Alla verktyg är ett tryck bort.
- **Slå upp ett ord du inte känner till.** Tryck på ett Strong's-nummer i versen för en snabb lexikonpost.
- **Jämföra översättningar.** Använd versmenyns Jämför-verktyg eller slå på parallellvyn.
- **Se hur en vers hänger ihop med resten av Bibeln.** Använd korsreferenserna.
- **Ta anteckningar medan du läser.** Versmenyn har ett snabbt "Lägg till anteckning"-val.

För lång, distraktionsfri läsning, byt till fokusläget.

## Byta till fokusläget

Från vilket kapitel som helst i studieläget, tryck på knappen 📖 högst upp. Samma kapitel öppnas i [fokusläget](theodia://help/focus-mode) med menyerna och studieverktygen dolda. Tryck på knappen 📖 i nedre raden för att byta tillbaka till studieläget. För en fullständig beskrivning av vad fokusläget gör, se guiden [Fokusläget](theodia://help/focus-mode).

## Hjälp och frågor

Saknas ett verktyg eller visar det ett fel, se guiden [Vanliga problem](theodia://help/common-problems). Är du ny i Theodia går guiden [Läsa ditt första kapitel](theodia://help/first-read) igenom grunderna steg för steg.
