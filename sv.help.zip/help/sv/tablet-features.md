---
title: Surfplattefunktioner
level: everyday
categories: [layout, tablet]
summary: Så anpassar sig Theodias layout till surfplattor och större skärmar, med delade vyer, sidopaneler och tvåpanelsläsning.
---

# 📱 Surfplattefunktioner

Theodia är utformad för att dra nytta av större skärmar på surfplattor. På en surfplatta (eller någon enhet bredare än omkring 700 pixlar) byter appen automatiskt till en tvåkolumnslayout på många ställen.

> **Läge:** De funktioner som beskrivs här visas bara om ditt nuvarande användarläge stöder dem. Till exempel finns kommentarsidopaneler och AI-chatt bara i Scholar-läget. Delade vyer för bokmärken, markeringar och anteckningar kräver Standard- eller Scholar-läget. Fokusläget visar endast ren, en-kolumns-läsning. Du byter läge i **Inställningar** → **Appanvändarläge**.

## Versmenyn i läsaren

När du trycker på ett versnummer (eller håller inne versetext) visas **versmenyn** som ett **centrerat kort** över en mörk bakgrund.

- Knapparna **Kopiera** och **Dela** är alltid synliga högst upp i menyn.
- **Bokmärken** och **Markeringar** visas med sitt nuvarande tillstånd.
- **Kommentar**, **Ordbok** och **Jämför** öppnas från menyn. På en surfplatta kan de verktygen visas i en sidopanel eller ett brett kort när de valts.
- Tryck på bakgrunden eller på stängningspilen för att stänga menyn.

## Verskommentarspanelen

Verktyget **Kommentar** öppnar en **dedikerad sidopanel** på en surfplatta:

- Kommentartexten visas bredvid bibeltexten.
- Du kan rulla kommentaren oberoende av Bibeln.
- Tryck på **X** eller svep bort för att stänga.
- En **bokikon** högst upp i panelen låter dig byta kommentarskälla.
- En **kapitelikon** låter dig se kommentar på kapitelnivå.

På en telefon öppnas kommentaren som en helskärmsdialog.

## Kapitelkommentaren

**Kapitelkommentaren** nås via knappen **Mer** högst upp på skärmen, inte via versmenyn. På en surfplatta öppnas den som en sidopanel precis som verskommentaren, så att du kan läsa kommentaren och bibeltexten tillsammans.

## Fliken Jämför

Fliken **Jämför** (i versmenyn) öppnas som en **sidopanel** på en surfplatta. Den visar valda versen i varje parallell version du har påslagen. Du kan trycka på en version för att hoppa till det avsnittet i läsaren.

## Ordbok/Strong's-popup

Verktyget **Ordbok** (versmenyn → Ordbok) öppnas som ett brett kort på en surfplatta. Det visar det grekiska eller hebreiska ordet, dess translitteration, definition och Strong's-nummer. Tryck på knappen **Konkordans** för att se varje förekomst av ordet i Bibeln.

## Tryck på ett ord för att öppna dess lexikon

I sidopanelen **Ordinfo** på en surfplatta är varje ordkort med ett Strong's-nummer tryckbart. Tryck på kortet för att öppna **lexikonpanelen** för det ordet direkt. Lexikonpanelen ersätter ordinfopanelen så att du kan fortsätta studera utan att stänga läsaren.

På en telefon är ordinfokorten inte tryckbara eftersom skärmen är för liten för två paneler.

## Parallella biblar sida vid sida

I Inställningar, tryck på **Parallella biblar** och välj upp till tre versioner. På en surfplatta visas versionerna som **vertikala paneler** bredvid varandra:

- Varje panel rullar oberoende.
- Du kan trycka på ett versnummer för att öppna en sidopanel med verktyg.
- Fliken **Jämför** visar alla valda verser på ett ställe.
- Tryck på **X** på en panel för att stänga den och återgå till en en-kolumns-vy.
- Tryck på ikonen **Parallella biblar** (🔵 / ⚪) i övre ikonraden för att slå parallellvyn på eller av utan att öppna Inställningar.

På en telefon visas parallella versioner en efter en (vertikalt) istället för sida vid sida. Samma växelikon fungerar på telefoner också.

## Delad vy för bokmärken och markeringar

På en surfplatta använder flikarna **Bokmärken** och **Markeringar** en master-detalj-layout:

- **Vänster sida** — listan över bokmärken eller markeringar.
- **Höger sida** — att trycka på en post öppnar en förhandspanel med versen eller avsnittet.

Du kan överblicka dina sparade poster och förhandsgranska dem utan att lämna fliken. På en telefon navigerar ett tryck på en post till läsarskärmen.

## Delad vy för anteckningar

Fliken **Anteckningar** på en surfplatta visar din anteckningslista till vänster och vald anteckning till höger. Att trycka på en anteckning öppnar den i en sidopanel så att du kan bläddra igenom flera anteckningar i rad utan att lämna listan. Att skapa eller redigera en anteckning använder också en sidopanel.

## Delad vy för sökning

På en surfplatta visar fliken **Sök** sökformuläret till vänster och träffarna till höger så snart du kör en sökning. Du kan förbättra din fråga och se träffarna uppdateras utan att byta skärm. På en telefon öppnas sökträffar på en separat skärm.

## Sidopanel för inställningskategorier

Skärmen **Inställningar** på en surfplatta visar en kategorilista till vänster (AI, Utseende, Backup, Biblar med flera). Tryck på en kategori för att hoppa direkt till dess inställningar till höger. Bara vald kategori är utfälld, så du behöver aldrig rulla genom hela inställningslistan.

## Bibelnavigering på surfplattor

Skärmarna **Bibellista**, **Bibelböcker** och **Bibelkapitel** förblir en kolumn på surfplattor, men de använder större tryckytor, bredare rutnät och luftigare utfyllnad så att innehållet är lättare att läsa och trycka på. De använder inte en delad vy-layout eftersom varje steg behöver full bredd för att visa sin lista eller sitt rutnät tydligt.

## Landskap och porträtt

Att rotera surfplattan anpassar layouten automatiskt. I **landskap** har sidopanelerna gott om plats. I **porträtt** blir panelerna smalare men stannar ändå bredvid texten.

## AI-chatt för vald vers

**AI**-chatten öppnas i versmenyns sidopanel. Den visar ett samtalgränssnitt där du kan ställa frågor om valda versen. AI-svaret visas i panelen, och du kan fortsätta samtalet utan att lämna läsaren.

## Sidopanel för samtal på AI-skärmen

På fliken **AI** på en surfplatta är samtalslistan alltid synlig som en fast vänsterpanel. Du kan byta mellan chattar utan att öppna en meny. Knappen **Ny chatt** är också alltid synlig. På en telefon är samtalslistan en popup-låda.

## Vad som är oförändrat

Inte varje skärm delas i två paneler. Följande skärmar förblir enkolums på surfplattor:

- **Bibellista** — lista över bibelversioner (full bredd)
- **Bibelböcker** — bokrutnät och avdelningar (full bredd)
- **Bibelkapitel** — kapitelrutnät (full bredd)
- **PDF-filer** — PDF-biblioteket använder ett bredare kortrutnät (full bredd)
- **Inställningar** — enskilda inställningssidor (full bredd)
- **Hjälp** — hjälpartiklar (full bredd)

## Sammanfattning

På en surfplatta får du:

- **Parallella biblar** i vertikala paneler sida vid sida
- **Kommentar** i fasta sidopaneler
- **Jämför** och **Ordbok** i breda kort
- **Lexikon** från ett tryck på valfritt ordinfokort
- **Bokmärken, Markeringar, Anteckningar, Andakter, Böcker, Inställningar** i master-detalj-delade vyer
- **Sök** med träffar bredvid sökformuläret
- **Landskap** och **porträtt** stöds båda med automatiska layoutändringar

På en telefon använder allt den traditionella enkolumnsnavigeringen med nästlade nivåer. Appen upptäcker skärmbredden vid start och väljer rätt layout automatiskt.
