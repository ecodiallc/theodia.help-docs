---
title: Byta teman och typsnitt
level: everyday
categories: settings
summary: Så ändrar du appens utseende.
---

# Byta teman och typsnitt

Theodia låter dig ändra hur appen ser ut. Du kan välja ett tema (ljust eller mörkt) och en textstorlek.

## Så öppnar du utseendeinställningarna

1. Öppna **Inställningar**.
2. Tryck på **Utseende**.

## Så byter du tema

I avdelningen **Utseende** ser du två temaknappar:

- **Standard** — en ljus bakgrund med mörk text. Bra på dagen.
- **Mörkt** — en mörk bakgrund med ljus text. Bra på natten och sparar batteri.

Tryck på ett tema för att använda det. Ändringen sker direkt.

## Så ändrar du textstorleken

I avdelningen **Utseende**, tryck på en av storleksknapparna: **---**, **--**, **-**, **Normal**, **+**, **++**, **+++**. Texten blir mindre eller större i hela appen. Välj den storlek som är lättast för dig att läsa.

## Tips

- Mörkt tema sparar batteri på telefoner med OLED-skärm.
- Är texten för liten för att läsa, öka textstorleken i appen, inte på enheten. Appens inställning är finare.
- För lång läsning, prova mörkt tema och större text.
- [Aktivera ökentemat](theodia://unlock-desert)
