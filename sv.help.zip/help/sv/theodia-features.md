---
title: Theodias funktioner
level: beginner
categories: welcome
summary: En snabb överblick över vad som gör Theodia speciellt och hur det hjälper dig att studera Bibeln.
---

# Theodias funktioner

Theodia är byggd för att vara en komplett bibelstudiekamrat. Här är vad som gör det unikt.

## Offline först

Allt fungerar utan internet. Biblar, kommentarer, lexikon, böcker och andakter lagras på din enhet. Du kan läsa, söka och studera var som helst — på ett flygplan, i ett avlägset område eller var som helst utan täckning.

## Integritet i fokus

Dina data stannar hos dig. Anteckningar, markeringar, bokmärken och läshistorik lagras lokalt på din enhet. Inget konto behövs, och inget skickas till en server om du inte själv väljer att använda den valfria AI-assistenten.

## Stöd för surfplattor

Theodia är utformad för både telefoner och surfplattor. På en större skärm får du mer plats för läsning, parallella bibelvyer och en layout som drar nytta av det extra utrymmet.

## Installerbara resurser

Du är inte begränsad till vad som följer med appen. Du kan lägga till fler bibelversioner, kommentarer, lexikon, böcker och andakter. Resurser finns på projektets GitHub-sida och kan installeras direkt i appen.

## AI-assistent

Den valfria AI-assistenten hjälper dig att förstå verser, förklara sammanhang och besvara frågor. Den är bara aktiv om du slår på den. Som standard ansluter den till en fjärrmodell som du tillhandahåller via en slutpunkt och en API-nyckel du ställer in. Första gången du använder AI:et frågar appen om ditt tillstånd och visar exakt vad som skickas.

## Parallell bibelläsning

Läs upp till fyra bibelversioner samtidigt. När du öppnar ett kapitel visas din huvudöversättning först, och varje vers följs av samma vers i dina valda parallella översättningar. Jämför formuleringar, studera skillnader och få en mer fullständig bild av texten. Spara dina favoritkombinationer som presets och byt snabbt mellan dem.

## Fulltextsökning

Sök i valfri bibelversion. Leta efter ord, fraser eller delvis matchning. Du kan också begränsa sökningen till ett antal böcker.

## Korsreferenser

Tryck på en versreferens för att hoppa direkt till det avsnittet. Korsreferenser är inbyggda och fungerar i hela Bibeln.

## Lexikon och Strong's-nummer

Tryck på ett Strong's-nummer för att se den grekiska eller hebreiska definitionen. Lexikonposter ingår för djupare ordstudier.

## Bokmärken och markeringar

Spara verser med bokmärken och markera dem med färger. Allt lagras lokalt och finns kvar mellan sessioner.

## Anteckningar

Skriv dina egna tankar bredvid valfri vers. Anteckningarna är knutna till versen och lätta att hitta senare.

## Daglig andakt

Börja dagen med en kort andaktsläsning. Appen innehåller andakter som öppnas på dagens post automatiskt.

## Kristna böcker

Läs klassisk kristen litteratur inne i appen. Böckerna är formaterade för enkel läsning och innehåller en innehållsförteckning för snabb navigering.

## PDF-läsning

Importera dina egna PDF-dokument och läs dem offline, ordnade i kategorier. Läsaren stöder sökning, innehållsförteckning, bokmärken, zoom och uppläsning. Du kan också installera paketerade PDF-samlingar från communityns arkiv.

## Flera språk

Theodia stöder många språk för både appgränssnittet och bibelinnehållet. Byt språk i inställningarna för att studera på det språk du föredrar.

## Mörkt läge och teman

Välj mellan ljust eller mörkt läge, eller välj ett tema som passar dig. Läskomfort spelar roll, särskilt i svagt ljus.

## Databackup

Säkerhetskopiera dina anteckningar, bokmärken och markeringar. Håll dina data säkra och flytta dem till en ny enhet när det behövs.

## Ingen reklam, inga distraktioner

Theodia är byggd för fokus. Ingen reklam, inga popup-fönster, inga avbrott. Bara texten och dina studieverktyg.
