---
title: Läsa upp (text-till-tal)
level: everyday
categories: tts
summary: Låt Theodia läsa Bibeln eller en andakt högt. Så använder du det, väljer röst och gör när det är tyst.
---

# Läsa upp (text-till-tal)

> **Läge:** Text-till-tal finns i läget **Standard** och **Scholar**. Fokusläget är endast för ren, distraktionsfri läsning. Du byter läge i **Inställningar** → **Appanvändarläge**.

Theodia kan läsa text högt med enhetens text-till-tal-röst (TTS). Du kan lyssna på en enda vers, ett helt kapitel eller en andakt. Det är bra för handsfree-läsning, lyssnande medan du går eller pendlar, läsning med ljudet eller bara för att vila ögonen.

## Var lyssna-knappen finns

Du hittar en lyssna-knapp på tre ställen.

### 1. I versmenyn (en vers)

Det är det snabbaste sättet att lyssna på en vers i taget. Öppna ett kapitel i [studieläget](theodia://help/study-mode), tryck på en vers för att öppna versmenyn och tryck sedan på **Läs upp** (🔊). Uppläsningen börjar från den versen. En liten kontrollrad visas längst ner på skärmen med spela, pausa, spola tillbaka, spola framåt och en röstväljare.

Valet Läs upp visas inte för interlineära biblar (MIB — Marvel Interlinear Bible — och OHGB), eftersom de visar orden i en annan layout som inte läses naturligt.

### 2. Högst upp i ett kapitel (hela kapitlet)

När du läser ett kapitel, titta på raden med ikoner överst på skärmen. Tryck på **Lyssna** (🔊) för att börja läsa hela kapitlet från början. Knappen blir en stoppknapp (⏹) medan ljudet spelas. Tryck igen för att stoppa. Samma kontrollrad visas längst ner.

Du kan hoppa till en annan vers, och Lyssna-knappen där startar istället från den versen.

### 3. I en andakt

Öppna valfri andaktsdag och tryck sedan på knappen **Lyssna** (🔊) högst upp i läsningen. Hela andaktstexten läses upp, mening för mening. En kontrollrad längst ner ger dig spela, pausa, spola tillbaka och röstkontroller.

## Använda kontrollraden

Medan ljud spelas förblir en liten rad synlig längst ner på skärmen. Den har sex kontroller:

- ⏪ **Spola tillbaka** — gå bak en vers (eller en mening i en andakt)
- ⏸ **Pausa / ▶ Fortsätt** — pausa utan att tappa din plats. Tryck igen för att fortsätta från samma ställe.
- ⏩ **Spola framåt** — hoppa till nästa vers (eller nästa mening i en andakt)
- 🎙 **Röst** — öppna röstväljaren utan att lämna kapitlet (se nedan)
- ⚙ **Alternativ** — öppna den utökade alternativpanelen (se nedan)
- **Stoppa** — tryck på 🔊-knappen högst upp på skärmen, eller på ⏹ som ersätter den medan ljudet spelas, för att stoppa och stänga raden.

Kontrollraden stängs när kapitlet är klart eller när du trycker på stopp.

### Utökade alternativ

Tryck på ⚙ för att fälla ut extra uppspelningsalternativ. De inställningarna gäller bara det aktuella kapitlet och återställs när du byter kapitel eller slutar lyssna.

- ⏮ **Till början** — hoppa till första versen i det intervall du ställt in.
- **Början** — skriv ett versnummer för att ställa in var läsningen börjar.
- **Slutet** — skriv ett versnummer för att ställa in var läsningen stoppar.
- **Alla** — återställ intervallet till hela kapitlet.
- **()** — växla om parentestext (text inom parenteser) ska läsas upp.
- 🔁 **Upprepning** — starta automatiskt om från intervallets början när slutet nås, med en kort paus mellan. Slår du på det utan att ställa in begin- eller slutvers upprepas hela kapitlet.

### I böneskärmar

Trosbekännelser och fasta böner, genererade böner och bönerutiner har en egen uppsättning utökade alternativ. Tryck på ⚙ i kontrollraden för att fälla ut dem:

- **Hastighet** — tryck på hastigheten (till exempel `1x`) för att välja en läshastighet från 0,1x till 1,5x. Ditt val sparas och används nästa gång du läser något högt.
- **()** — växla om parentestext (text inom parenteser) ska läsas upp.
- 🔁 **Upprepning** — starta bönen automatiskt om från början när den är klar, med en kort paus mellan. Det är bra för att lära sig en trosbekännelse eller en fast bön utantill.

Att ändra hastigheten träder i kraft direkt, utan att du tappar din plats. Att slå på eller av parentesvalen startar bönen om från början så att ändringen hörs från starten.

## Så byter du röst

Du kan välja vilken röst Theodia använder vid uppläsning. Det är bra om du vill ha en annan accent, ett annat språk eller en snabbare eller långsammare röst än enhetens standard.

1. Öppna **Inställningar**.
2. Hitta avdelningen **Tal**.
3. Tryck på **Välj röst**.
4. En lista med röster visas. Första raden, **Systemstandard**, använder rösten din enhet föredrar. Välj valfri annan rad för att göra den till ny standard.
5. Ditt val sparas och används nästa gång du trycker på **Lyssna** eller **Läs upp**.

Du kan också trycka på 🎙-ikonen i lyssningskontrollraden för att öppna samma väljare utan att lämna kapitlet.

Rösttillgängligheten beror helt på din enhet. iOS och Android levereras var och en med en uppsättning inbyggda röster. Du kan installera fler röster från enhetens **Hjälpmedels-** eller **Språk och inmatning**-inställningar. Theodia kan använda vilken röst som helst som är installerad på din enhet.

## Favoritröster

Har din enhet många röster kan det vara långsamt att rulla igenom hela listan varje gång. Du kan skapa en kort lista med **favoritröster**, och röstväljarna visar bara de rösterna.

1. Öppna **Inställningar**.
2. Hitta avdelningen **Tal**.
3. Tryck på **Favoritröster** (första raden högst upp i avdelningen).
4. Tryck på **Ställ in favoritröster** för att öppna favoritskärmen.
5. Tryck på spela-knappen bredvid en röst för att förhandslyssna. Tryck på stjärnan för att lägga till den bland favoriterna. Du kan favoritmarkera hur många röster du vill.
6. Gå tillbaka. Röstväljarna i hela Theodia visar nu bara dina favoritröster.

Tar du bort alla favoriter går väljarna tillbaka till att visa alla röster. Favoritröster ingår när du säkerhetskopierar och återställer Theodia-inställningar.

## Ställa in olika röst per bibel

Du kan ge varje bibelöversättning sin egen röst. Det är användbart när du växlar mellan översättningar som låter väldigt olika — till exempel en mer formell röst för King James Version och en mer samtalston för en modern översättning som NIV eller NLT. Det hjälper också om du lyssnar på biblar på olika språk och vill att var och en talas med rätt accent.

1. Öppna **Inställningar**.
2. Hitta avdelningen **Tal**.
3. Leta efter **Bibelröster**.
4. Tryck på valfri bibel i listan.
5. Välj rösten du vill ha för den översättningen. Första raden, **Systemstandard**, använder din huvud-TTS-röst för den bibeln.
6. Upprepa för andra biblar.

Rubriken visar hur många bibelöversättningar som har en egen röst. **Välj röst**, **Kommentarröst**, **Bibelanteckningsröst** och **Andaktsröst** visar också en räkning när en röst är satt.

Nästa gång du lyssnar på ett kapitel från den bibeln använder Theodia rösten du valde. Alla andra biblar fortsätter använda huvudstandarden om du inte ändrar dem också.

## Fortsätta talet i bakgrunden

Som standard stoppar Theodia talet när du lämnar läsarskärmen, byter till en annan app eller låser telefonen. Det förhindrar oväntat ljud när du inte längre aktivt läser.

För att låta talet fortsätta spela i bakgrunden:

1. Öppna **Inställningar**.
2. Hitta avdelningen **Tal**.
3. Slå på **Fortsätt talet i bakgrunden**.

Är detta på kan du byta flik, öppna en annan app eller låsa skärmen så fortsätter kapitlet eller andakten att läsas. Kontrollraden är aktiv så att du kan pausa eller hoppa från aviseringsytan (om din enhet stöder det).

Att slå av reglaget **medan** talet redan spelas stoppar det direkt.

## Vad du gör om det inte fungerar

Text-till-tal beror på din enhet. Theodia skickar texten till operativsystemet, och operativsystemet läser den högt med en röst. Fungerar det inte, prova de här stegen i ordning.

### Theodia säger att TTS inte finns

Vissa enheter har ingen TTS alls. Öppna **Inställningar** och leta efter avdelningen **TTS**. Finns avdelningen inte stöder din enhet TTS i det här bygget.

### Röstlistan är tom

Röstväljaren kan visa "inga röster hittades". Det betyder oftast att enheten ännu inte har laddat klart sina röster.

1. Öppna **Inställningar → Tal → Välj röst**.
2. Är listan tom, leta efter knappen **Testa igen** strax under rullgardinsmenyn. Tryck på den. Theodia frågar enheten om röster på nytt.
3. Är den fortfarande tom, kontrollera enhetens systeminställningar. På iOS, gå till **Inställningar → Hjälpmedel → Uppläst innehåll → Röster** och ladda ner en röst för ditt språk. På Android, gå till **Inställningar → Språk och inmatning → Text-till-tal-utmatning** och tryck på **Installera röstdata**.
4. Stäng och öppna Theodia igen så att den hämtar den nya rösten.

Har du satt favoritröster och listan är tom, se till att minst en av dina favoriter matchar en röst installerad på den här enheten.

### Trycker på Läs upp men ingenting händer

- Kontrollera att enheten inte är i tyst läge. De flesta enheter spelar inte TTS-ljud i tyst läge.
- Se till att enhetens volym är på.
- Prova knappen **Testa igen** i **Inställningar → Tal**.
- Öppna **Inställningar** och titta på avdelningen **System** längst ner. Raden **TTS** ska säga **Tillgänglig**. Säger den **Otillgänglig** är TTS avstängt på operativsystemnivå. Slå på det där och öppna sedan Theodia igen.

### Ljudet spelas men i fel språk

Theodia skickar text på det aktuella innehållets språk och ber enheten om rösten du valt. Är valda rösten för ett annat språk kan enheten ändå läsa texten, men det låter konstigt.

1. Öppna **Inställningar → Tal → Välj röst**.
2. Välj **Systemstandard** för att låta enheten välja rätt, eller välj en röst vars språk stämmer med texten du läser.

Theodia läser för närvarande inte upp grekiska eller hebreiska interlineära biblar. Knapparna Läs upp och Lyssna är dolda på de översättningarna.

### Ljudet spelas men slutar tidigt

Saknas en vers eller är oläsbar hoppar kapitlet till nästa. Stänger raden sig själv efter några verser, tryck på knappen **Lyssna** (🔊) högst upp på skärmen för att börja om.

### Talet spelas men jag vet inte var det startade

Har du slagit på **Fortsätt talet i bakgrunden** och hör senare ljud men hittar inte skärmen som startade det, kan du stoppa det var som helst i appen.

1. Öppna **Inställningar**.
2. Hitta avdelningen **Tal**.
3. Tryck på den röda knappen **Stoppa talet** längst ner i avdelningen.

Det stoppar direkt all pågående text-till-tal i Theodia. Du kan också öppna appväxlaren på din enhet och svepa bort Theodia för att tvinga fram stopp av ljudet.

### Den läser för snabbt eller för långsamt

Theodia styr inte läshastigheten. Hastigheten sätts av vald röst. För att ändra den:

- På iOS: **Inställningar → Hjälpmedel → Uppläst innehåll → Talfart**.
- På Android: **Inställningar → Språk och inmatning → Text-till-tal-utmatning → Talhastighet**.

## Tips

- Kontrollraden förblir synlig medan du navigerar mellan kapitel, så du kan pausa, hoppa eller byta röst utan att tappa din plats.
- Theodia läser versnummer som små pauser. Du kan stoppa raden, svepa till en annan vers och sedan trycka på spela för att fortsätta därifrån.
- För långa lyssningar, slå på **Stör inte** så att aviseringar inte avbryter ljudet.
- 🔊-knappen använder enhetens nuvarande volym. Kopplar du in hörlurar byter volymen till hörlursnivån.

## Läsa upp en PDF

Theodia kan också läsa upp PDF-sidor. Öppna en PDF och tryck på knappen **Lyssna** (högtalaren) i dess verktygsfält. En kontrollrad visas med spela/pausa, spola tillbaka, spola framåt, stopp, en förloppsrad och väljarna för hastighet och röst. När en sida är klar fortsätter läsningen automatiskt på nästa sida.

PDF-uppläsning använder PDF:ens installerade sökbara text och samma röster och hastighet som bibelläsningen.

## Relaterade guider

- Guiden [Studieläget](theodia://help/study-mode) går igenom versmenyn och knapparna överst på skärmen mer i detalj.
- Guiden [Fokusläget](theodia://help/focus-mode) är en renare läsvy som också stöder TTS via 🔊-knappen i nedre raden.
- Guiden [Vanliga problem](theodia://help/common-problems) har lösningar för andra ljud-, röst- och språkproblem.
- Guiden [Dagliga andakter](theodia://help/daily-devotionals) går igenom andaktsläsning och var lyssna-knappen finns på den skärmen.
- Guiden [PDF-filer](theodia://help/pdfs) går igenom PDF-läsaren och dess lyssna-knapp.
