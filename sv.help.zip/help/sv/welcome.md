---
title: Välkommen till Theodia
level: beginner
categories: welcome
summary: En kort rundtur i appen och vad den kan göra för dig.
---

# Välkommen till Theodia

Theodia är en bibelstudieapp. Den körs på din telefon eller surfplatta, även när du saknar internet. Allt du läser, söker och studerar sparas på din enhet.

## Vad du kan göra

Theodia har tre användarlägen. Varje läge visar en olika uppsättning funktioner.

- **Reader** — läs Bibeln i en ren, distraktionsfri vy.
- **Standard** — allt i Reader, plus bokmärken, markeringar, anteckningar, text-till-tal, sökning och dagliga andakter.
- **Scholar** — allt i Standard, plus kommentarer, lexikon, Bibelordboken, AI-assistenten med mera.

Du kan byta läge när som helst i **Inställningar** → **Appanvändarläge**.

### Funktioner du har tillgång till

Oavsett vilket läge du väljer kan du alltid:

- **Läsa Bibeln.** Välj bland många översättningar. Byt mellan dem när som helst.
- **Söka i Bibeln.** Leta efter ett ord eller en fras. Appen visar varje vers som matchar.
- **Läsa böcker och andakter.** Appen kommer med kristna klassiker och en daglig andakt.

Beroende på ditt läge kan du också:

- **Lyssna.** Låta verser läsas upp med uppläsningsfunktionen. (Standard och Scholar.)
- **Ta anteckningar.** Skriva dina egna tankar bredvid en vers. (Standard och Scholar.)
- **Markera.** Märka dina favoritverser i färg. (Standard och Scholar.)
- **Bokmärka.** Spara verser så att du snabbt hittar dem igen. (Standard och Scholar.)
- **Fråga AI-assistenten.** Få hjälp att förstå en vers. (Endast Scholar.)

## Var du börjar

1. Öppna fliken **Bibel** längst ner på skärmen.
2. Välj en översättning.
3. Tryck på valfri bok för att börja läsa.

Vill du lära dig mer finns resten av hjälpguiderna här för dig. Välj ett ämne från listan på hjälphemsidan.

## Några saker att veta

- Du behöver inget konto.
- Dina anteckningar, markeringar och bokmärken stannar på din enhet.
- Du kan säkerhetskopiera dem. Se guiden [Säkerhetskopiera dina data](theodia://help/backups) för hur.

## Vill du ha fler resurser?

Appen kommer med flera fritt tillgängliga bibelversioner. För extra biblar, kommentarer, lexikon, böcker och andakter, se guiden [Hämta extra resurser från GitHub](theodia://help/getting-core-files). Den visar hur du hittar och lägger till fler resurser från projektets GitHub-sida.

Välkommen. Vi hoppas Theodia hjälper dig att läsa och studera.
