---
title: Vad är resurser?
level: beginner
categories: resources
summary: En överblick över de olika sorters filer Theodia använder — biblar, kommentarer, böcker med mera.
---

# Vad är resurser?

I Theodia är en "resurs" vilken fil som helst som lägger till läs- eller studiematerial i appen. Appen i sig är bara en läsare och ett anteckningsblock. Biblarna, kommentarerna, böckerna och annat material du studerar med är alla separata filer som du läser in.

Den här guiden förklarar de olika sorternas resurser och vad var och en är till för.

## Varför spelar det roll?

När du öppnar Theodia för första gången har den redan några saker att läsa. När du utforskar ser du knappar för att installera mer. Att veta vad varje sorts resurs är hjälper dig bestämma vad du ska lägga till.

## De olika sorternas resurser

Theodia känner igen filer efter deras ändelse. Varje ändelse är en annan sorts resurs.

### `.bible` — en bibelöversättning

En bibelöversättning är en fullständig kopia av Bibeln i en viss version, till exempel King James Version. Theodia kommer med några översättningar och låter dig lägga till fler.

Se guiden [Installera bibelöversättningar](theodia://help/installing-bibles) för detaljer.

### `.commentary` — en kommentar

En kommentar är en bok med studieanteckningar skrivna av en bibelforskare. För en given vers berättar en kommentar om bakgrunden, betydelsen och hur versen passar in i resten av Bibeln.

Se guiden [Kommentarer och lexikon](theodia://help/commentaries-and-lexicons) för detaljer.

### `.lexicon` — ett lexikon

Ett lexikon är en ordbok över bibelord. Det berättar det hebreiska eller grekiska originalordet, vad det betyder och hur det används i Bibeln.

Se guiden [Kommentarer och lexikon](theodia://help/commentaries-and-lexicons) för detaljer.

### `.book` — en kristen bok

En bok är ett längre kristet verk, till exempel en klassiker från kyrkohistorien. Att läsa böcker i appen fungerar ungefär som att läsa en bibel. Theodia kommer med ett litet bibliotek av fritt tillgängliga kristna klassiker.

Se guiden [Läsa inbyggda böcker](theodia://help/reading-books) för detaljer.

### `.devotional` — en andakt

En andakt är en kort daglig läsning. Varje post har oftast en vers, en kort reflektion och en bön eller en fråga att fundera på. Många andakter är gjorda för att läsas en post per dag under ett år.

Se guiden [Dagliga andakter](theodia://help/daily-devotionals) för detaljer.

### `.sqlite` — en referensdatabas

En referensdatabas är en stor uppslagsfil som appen använder för att ge dig extra information medan du läser. Det finns två sorter:

- **Korsreferenser** — listor över verser som hör ihop med versen du läser.
- **Morfologi** — information om de hebreiska eller grekiska orden i versen.

Du öppnar inte de här direkt. De fungerar i bakgrunden och lägger till funktioner i bibelläsaren. Se guiden [Korsreferenser](theodia://help/cross-references) för detaljer.

### `.data` — ordedata

En ordedatafil innehåller extra information om de hebreiska bibelorden. Den används av lexikonet och studieverktygen. Precis som referensdatabaserna öppnar du den inte direkt. Appen använder den i bakgrunden.

## Så lägger du till en resurs

Appens skärm **Hantera resurser** är det enkla sättet att lägga till en resurs.

1. Öppna **Inställningar**.
2. Tryck på **Hantera resurser**.
3. Tryck på **Installera från GitHub**.
4. I nedladdningsrutan, välj en flik — **Biblar**, **Kommentarer**, **Böcker**, **Andakter** eller **Kärna** — markera sedan vad du vill ha och tryck på **Installera valda**.
5. Eller tryck på **Installera lokal fil** för att importera en fil du redan har laddat ner.

För en steg-för-steg-genomgång av att hämta filer direkt från GitHub, se guiden [Hämta extra resurser från GitHub](theodia://help/getting-core-files).

## Så tar du bort en resurs

1. Öppna **Inställningar**.
2. Tryck på **Hantera resurser**.
3. Hitta resursen du vill ta bort.
4. Tryck på papperskorgsikonen bredvid den.
5. Bekräfta att du vill ta bort den.

Att ta bort en resurs raderar inte dina anteckningar, markeringar eller bokmärken. De är kvar i säkert förvar.

## Var resurserna finns på din enhet

Resurserna lagras på din enhet, inte i molnet. När en resurs är installerad behöver du inte internet för att läsa den. Du kan säkerhetskopiera din enhet, men resurserna själva säkerhetskopieras inte till molnet av Theodia. Avinstallerar du och installerar om appen behöver du lägga till de resurser du hade installerat igen.

## Hjälp och frågor

Har du problem, se guiden [Var du kan ställa frågor](theodia://help/getting-more-help). Teamet och communityt kan hjälpa till.
