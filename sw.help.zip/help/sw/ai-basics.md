---
title: Misingi ya AI
level: advanced
categories: ai
summary: Namna ya kutumia msaidizi wa AI kuelewa aya.
---

# Misingi ya AI

> **Hali:** Msaidizi wa AI unahitaji hali ya **Mtaalamu**. Unaweza kubadilisha hali katika **Mipangilio** → **Hali ya Mtumiaji wa Programu**.

Theodia ina msaidizi wa AI. Anaweza kukusaidia kuelewa aya, kujibu swali, au kuzungumza mada ya Biblia.

## Namna ya kuwasha AI

AI imezimwa kwa chaguomsingi. Kuiwasha:

1. Fungua **Mipangilio**.
2. Bonyeza **Msaidizi wa AI**.
3. Bonyeza swichi kuiwasha.

## Namna ya kufungua AI

Bonyeza kichupo cha **AI** chini ya skrini. Dirisha la mazungumzo linafunguka.

## Namna ya kuuliza swali

Bonyeza sanduku chini. Andika swali lako. Bonyeza **Tuma**.

Mambo unayoweza kuuliza:

- "John 3:16 inamaanisha nini?"
- "Nambie kuhusu kitabu cha Warumi."
- "Matunda ya Roho ni nini?"
- "Linganisha Mahubiri ya Mlimani katika Mathayo na Luka."

## Namna ya kuuliza kuhusu aya mahususi

1. Fungua sura.
2. Bonyeza aya kuleta menyu ya aya.
3. Bonyeza **Mafafani ya AI**.

Aya inatumwa kwa AI. Bao la AI linafunguka aya ikiwa imejazwa mapema. Unaweza kuongeza swali, kama "Hii inamaanisha nini?" au "Ninapaswa kuitumia namna gani?"

## Mambo muhimu ya kujua

- AI ni zana, sio mtu. Inaweza kukosea.
- Daima linganisha majibu ya AI na Biblia yenyewe.
- AI inaweza kuhitaji intaneti. Haifanyi kazi bila mtandao.
- Unapotumia AI, maswali yako, muktadha wa aya, na ufunguo wako wa API yanatumwa kwenye mwisho uliochagua. Mara ya kwanza unapofanya hivi, programu inaomba ruhusa yako na inaonyesha kinachotumwa kwa usahihi. Unaweza kubadilisha au kufuta ruhusa hiyo baadaye katika **Mipangilio → Msaidizi wa AI → Kushirikisha Takwimu za AI ya Mbali**.
- Baadhi ya maeneo, kama ujenzi wa Duka la Programu la bara la China, hautoi msaidizi wa AI. Katika ujenzi huo vipengele pekee vya Biblia vya nje ya mtandao vinapatikana.

## Namna ya kudhibiti mazungumzo

Skrini ya AI inahifadhi orodha ya mazungumzo ya zamani. Kutoka orodha unaweza kufungua mazungumzo ya zamani, kuanza mpya, au kufuta mazungumzo husiayahitaji tena.

## Nenda kwa undani zaidi na AI

Ukurasa huu unafunika misingi. AI ya Theodia inaweza kufanya mengi zaidi ya mazungumza. Hapa ni pa kwenda ijayo:

- **[Vipengele vya AI](theodia://help/ai-features)** — Gunda kila kitu Theophilus anachoweza: kujifunza aya kwa bonyeza-moja katika Kigiriki na Kiebrania, mnyororo wa marejeleo, mifumo ya hubiri, kutengeneza maombi, umbolelogia wa lugha asilia, utafutaji wa kamusi, na kutembea programu bila mikono. Hii ni mwongozo unaoonyesha namna ya kugeuza AI kutoka roboti-ya-mazungumzo kuwa mshirika kamili wa kujifunza.
- **[Kuandika Maombi Bora za AI](theodia://help/ai-prompts)** — Jifunze sanaa ya kuuliza maswali yanayopata majibu tajiri na sahihi. Kubadilika kidogo cha namna unavyoeleza ombi lako kunaweza kufungua majibu ya kina zaidi kwa njia ya kupindua kutoka AI.
- **[Kuchagua Mfano wa AI](theodia://help/choosing-a-model)** — Sio mifano yote ya AI ni sawa. Gunda mifano ipi inaunga mkono zana za Theodia zilizojengwa ndani (kama kufungua aya na kutafuta Maandiko) na ipi inageuza AI kuwa msaidizi halisi wa kujifunza Biblia bila mikono.
- **[Mifano ya GitHub](theodia://help/github-models)** — Mtoa huduma wa bure aliyeaguliwa wa Theodia. Pata ufunguo wa API wa bure kwa akaunti ya GitHub na uanze kuuliza maswali katika ngazi ya siku ya kina wazi. Hakuna kadi ya mkopo, hakuna usajili.
- **[Ufunguo wa API na Gharama](theodia://help/ai-keys-and-costs)** — Elewa bei ya API inavyofanya kazi katika watoa huduma na namna ya kushika gharama karibu na sifuri.
