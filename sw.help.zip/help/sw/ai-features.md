---
title: Vipengele vya AI
categories: ai
level: advanced
summary: Gunda kila kitu AI ya Theodia inachoweza — kutoka kujifunza aya kwa aya hadi maandalizi ya hubiri, kuchunguza lugha asilia, na kutembea bila mikono.
---

# Vipengele vya AI

> **Hali:** Msaidizi wa AI unahitaji hali ya **Mtaalamu**. Unaweza kubadilisha hali katika **Mipangilio** → **Hali ya Mtumiaji wa Programu**.

Msaidizi wa AI wa Theodia, Theophilus, sio roboti-ya-mazungumzo tu. Ni mshirika wa kujifunza anayeweza kusoma Biblia pamoja nawe, kutafuta mafafani, kutafuta Maandiko, kudhibiti maoni yako, na hata kutembea programu — kwa sauti au maandiko vyote.

Kabla Theophilus hajatuma takwimu kwenye mwisho wa AI mara ya kwanza, programu inaonyesha ombi la ridhaa linaeleza kinachotumwa na linaomba ruhusa yako. Unaweza kubadilisha au kufuta ruhusa hiyo wakati wowote katika **Mipangilio → Msaidizi wa AI → Kushirikisha Takwimu za AI ya Mbali**.

## Mazungumzo ya AI ya Aya: Jifunza Aya Moja kwa Kina

**Mazungumzo ya AI ya Aya** ni moyo wa uzoefu wa AI wa Theodia. Unaposoma sura yoyote, bonyeza namba ya aya (au kubonyeza kwa muda mrefu maandiko ya aya) na chague **Mafafani ya AI**. Bao la mazungumzo linafunguka aya hiyo ikiwa imepakuliwa tayari. AI anajua kwa usahihi unachosoma na yuko tayari kuchunguza pamoja nawe.

### Wazo-leo wa bonyeza-moja

Hujui cha kuuliza? Bao linaonyesha wazo-leo wanane ya papo hapo:

- **Eleza aya hii** — Pata mchanganuo safi, wa makini wa maana na umuhimu.
- **Lugha asilia** — Ona maneno ya Kigiriki au Kiebrania, uandishi kwa herufi za Kilatini, na maana za kamusi nyuma ya maandiko.
- **Muktadha wa kihistoria** — Jifunze utamaduni, siasa, na matukio yanayozunguka aya.
- **Muktadha wa maandiko** — Ona jinsi aya inavyoingia katika aya, sura, na kitabu vinachozunguka.
- **Mada kuu** — Gunda mawazo makubwa aya hii inayachangia theolojia ya Biblia.
- **Tumia kwenye maisha yangu** — Pata utekelezaji wa vitendo, wa binafsi unaweza kufanya leo.
- **Tengeneza maombi** — Geuza aya kuwa maombi yaliyotengenezwa kwa lugha na ukweli wake.
- **Tengeneza mfumo wa hubiri** — Pata mfumo wa pointi-tatu wenye utangulizi na hitimisho, tayari kuhubiri.

Bonyeza wazo-leo lolote na AI anaanza mara moja. Unaweza kufuata na maswali yako mwenyewe, kuomba ufafanuzi, au kuelekeza mazungumzo mwelekeo mpya.

### Fuata kama mazungumzo halisi

AI anakumbuka ujumbe wa mwisho mchache katika mazungumzo, hivyo unaweza kuchimba kwa asili:

- "Unaweza kusema hilo kwa urahisi zaidi?"
- "Kigiriki asilia kinasema nini hapa?"
- "Nionyeshe marejeleo yanayounganisha na hii."
- "Linganisha aya hii katika tafsiri tatu tofauti."
- "Hii ingekuwa ifanaje katika mahali pa kazi cha kisasa?"
- "Nipe utekelezaji tatu zaidi kwa mzazi."

Mazungumzo yanabaki yamefungamana na aya, hivyo kila jibo linaundwa kwenye maandiko unayosoma.

### Bonyeza marejeleo yoyote ya Biblia

AI anapotaja aya nyingine — kwa mfano, "Hii inaakisi Warumi 8:28" — marejeleo yanaonekana kama **kiungo chinatekelezekayo**. Bonyeza na programu inaruka kipande hicho katika msomaji wa Biblia. Unaweza kuchunguza mnyororo wa marejeleo bila kuondoka katika mazungumzo kamwe.

## AI Anaweza Nini Zaidi ya Mazungumzo ya Aya

Theophilus ana ufikiaji wa maudhui yote ya Theodia — Biblia, mafafani, kamusi za asili, kamusi, vitabu, ibada, maoni yako, alamisho, na rangi. Hapa ni kile hii inamaanisha katika vitendo.

### Soma na tembea Maandiko

- **Soma aya au sura yoyote** — "Soma Yohane 3:16 katika WEB" au "Soma Zaburi 23 kwa sauti."
- **Fungua vipande katika msomaji** — "Nipitishe Mwanzo 1" au "Fungua Warumi 8:28."
- **Linganisha matoleo** — "Nionyeshe Yohane 3:16 katika Biblia zangu zote."
- **Tafuta Biblia** — "Pata aya kuhusu kusamehe" au "Tafuta 'amani inayopita uelewa.'"
- **Pata marejeleo** — "Aya zipi nyingine zinahusiana na Isaya 53:5?"
- **Soma vichwa vya sehemu** — "Vichwa vidogo katika Mathayo 5 ni vipi?"

### Chunguza lugha asilia

- **Utafutaji wa kamusi ya asili** — "Neno la Kigiriki 'agape' lina maana nini katika Yohane 3:16?" au "Tafuta Strong's G26."
- **Umbolelogia** — "Changanua vitenzi vya Kigiriki katika Warumi 8:28" au "Kodi ya umbolelogia V-PAI-3S inamaanisha nini?"
- **Taarifa ya Neno** — AI anaweza kuona mchanganuo huo wa neno-kwa-neno unaouona katika programu — uandishi kwa herufi za Kilatini, tafsiri fupi, sarufi, na namba za Strong's.

### Soma mafafani na vitabu vya kujifunza

- **Mafafani ya aya** — "Matthew Henry anasema nini kuhusu Waefeso 2:8?"
- **Mafafani ya sura** — "Nipe muhtasari wa sura ya Warumi 8."
- **Mafafani ya kitabu** — "Fupisha mafafani ya ngazi-ya-kitabu ya Ufunuo."
- **Vitabu vya kujifunza** — "Soma sura kutoka Hymn Lyrics English" au "Tafuta vitabu vyangu kwa 'subira.'"
- **Ibada** — "Soma ibada ya leo" au "Tafuta ibada kuhusu wasiwasi."

### Tafuta kamusi

- "Melkizedeki alikuwa nani?"
- "Kamusi ya Biblia inasema nini kuhusu Gilgali?"
- "Tafuta 'propitiation' katika Easton."

## Dhibiti maisha yako ya kujifunza

AI anaweza kufanya kwenye takwimu zako za binafsi — daima zimewekwa ndani ya kifaa chako:

- **Alamisho** — "Weka alamisho kwenye aya hii katika folda yangu ya Maandalizi ya Hubiri" au "Orodhesha alamisho zangu."
- **Rangi** — "Weka rangi ya njano kwenye Yohane 3:16" au "Nionyeshe rangi zangu zote."
- **Maoni** — "Tengeneza maoni ya Biblia kwenye aya hii" au "Soma maoni yangu kwa Mwanzo 1."
- **Maoni ya kujifunza** — "Hifadhi mazungumzo haya kama maoni ya kujifunza" au "Tengeneza daftari jipya la kujifunza linaloitwa Romans Study."
- **Folda** — "Tengeneza folda iitwayo Ibada ya Asubuhi" au "Hamisha alamisho yangu ya Yohane 3:16 kwenda folda ya Maombi."

## Badilisha mipangilio ya programu

- "Badili kwenda hali ya giza."
- "Fanya BSB iwe Biblia yangu ya chaguomsingi."
- "Washa Biblia sambamba na NET."
- "Ongeza ukubwa wa herufi."

## Soma kwa sauti

- "Soma Zaburi 23 kwa sauti" — AI anaweza kuanzisha kusoma-kwa-sauti kwa kipande chochote, kitabu, au maoni.
- "Simamisha kusoma" — Pumzisha TTS wakati wowote.

## Hifadhi Mazungumzo Yako

Kila mazungumzo ya AI ya aya yanaweza kuhifadhiwa. Bonyeza menyu katika bao la mazungumzo na chague:

- **Hifadhi kama Maoni ya Biblia** — Yanaongeza mazungumzo kamili kwenye maoni ya aya katika msomaji wa Biblia.
- **Hifadhi kama Maoni ya Kujifunza** — Yanahifadhi mazungumzo katika kitabu chako cha Maoni ya Kujifunza kwa kurejelewa baadaye.

Hii hugeuza kuchunguza kwa haraka kwa AI kuwa nyenzo za kudumu za kujifunza unazoweza kurejea, kuhariri, au kutengeneza mahubiri kutia.

## Kichupo Kamili cha AI

Zaidi ya bao la mazungumzo ya aya, Theodia ina kichupo cha **AI** kipekee katika kutembea-chini. Hii ni mazungumzo huria unapoweza kuuliza kitu chochote — hakuna aya iliyoteuliwa mapema. Ikitumie kwa:

- Kujifunza mada katika Biblia nzima
- Utafiti wa hubiri na uwekaji-mpangilio
- Kulinganisha mada za theolojia kati ya vitabu
- Ibada ya kila siku na vikumbusho vya maombi
- Kusoma kutawanyika kwa Biblia na mipango ya kusoma
- Msaada wa programu — "Biblia sambamba hufanya kazi namna gani?"

Mazungumzo yako huhifadhiwa kwa njia yenyewe. Unaweza kurejea mazungumzo ya zamani, kuanza mapya, na kufuta mizungumzo ya zamani.

## Mawazo ya Kuanzisha

Hapa ni njia za kupendeza za kutumia AI. Chagua moja na uijaribu leo.

**Ukuaji wa Binafsi**

- "Eleza Wafilipi 4:6–7 unipe maombi ya wakati ninapohisi wasiwasi."
- "Biblia inasema nini kuhusu kupumzika? Nipate aya tano na unieleze kila moja."

**Familia na Uzazi**

- "Waefeso 6:4 unapaswa kuongoza uzazi wa kisasa namna gani? Nipe sheria tatu za vitendo."
- "Pata aya kuhusu kulea watoto na unisome kwa sauti."

**Maandalizi ya Hubiri na Kufundisha**

- "Panga hubiri ya dakika 25 ya Warumi 8:28 yenye utangulizi, pointi tatu, na hitimisho."
- "Mafafani yangu yanasema nini kuhusu 'zana za vita za Mungu' katika Waefeso 6?"
- "Linganisha Mahubiri ya Mlimani katika Mathayo na toleo la Luka. Tofauti zipi?"

**Kujifunza Lugha Asilia**

- "Nionyeshe umbolelogia wa kila neno katika Yohane 1:1."
- "Tofauti kati ya 'agape' na 'philia' katika Agano Jipya ni nini?"

**Undani wa Ibada**

- "Soma ibada ya leo uiiunganishe na aya katika Zaburi."
- "Nipe mfumo wa ibada ya siku-saba wa matunda ya Roho."

**Mnyororo wa Marejeleo**

- "Anza na Isaya 53:5 ufuatilie mada ya 'majeraha' na 'kupona' katika Agano Jipya."
- "Dhana ya 'ahadi' inaonekana wapi kutoka Mwanzo hadi Waebrania?"

**Kumbuka na Kukagua**

- "Nifanyie mtihani wa vitabu vya Biblia kwa mpangilio."
- "Tengeneza maoni ya kujifunza yanayofupisha kichwa kikuu cha kila sura katika Warumi."

## Mambo Machache Muhimu

- AI ni **zana**, sio mbadala wa Biblia au uongozi wa mchungaji. Daima linganisha majibu yake na Maandiko yenyewe.
- Unapotumia AI, maswali yako yasafiri juu ya intaneti kwenda kwenye seva za mtoa huduma. Watoa huduma wengi hawajifunzi kutoka takwimu zako, lakini maandiko yanaondoka kwenye kifaa chako.
- AI inaweza kukosea. Tumia mafafani, kamusi za asili, na maandiko ya Biblia yenyewe kama mamlaka yako ya mwisho.

## Muhtasari

AI ya Theodia imeundwa kufanya kujifunza Biblia kuwa cha haraka, cha kina zaidi, na cha binafsi zaidi. Ukitaka maelezo ya sentensi moja ya aya inayowakanusha, mfumo kamili wa hubiri, uchunguzi wa neno la Kigiriki, au mnyororo wa marejeleo unaojitanda Biblia nzima, Theophilus yuko tayari kusaidia. Bonyeza aya, uliza swali, na uone mazungumzo yanapeleka wapi.
