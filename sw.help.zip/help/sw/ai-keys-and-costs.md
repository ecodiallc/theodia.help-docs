---
title: Ufunguo wa API na Gharama
level: advanced
categories: ai
summary: Kwa nini unahitaji ufunguo wa API, namna ya kupata moja, na gharama ya kawaida ya kutumia mfano wa AI wa mbali.
---

# Ufunguo wa API na Gharama

> **Hali:** Msaidizi wa AI unahitaji hali ya **Mtaalamu**. Unaweza kubadilisha hali katika **Mipangilio** → **Hali ya Mtumiaji wa Programu**.

Msaidizi wa AI unajitahiri kwenye mifano ya AI ya mbali. Ukitaka kutumia moja, unahitaji ufunguo wa API. Ukurasa huu unaeleza kwa nini, namna ya kupata moja, na gharama yake ya kawaida.

## Kwa nini unahitaji ufunguo wa API

Mfano wa AI wa mbali anaishi kwenye seva ya intaneti. Ufunguo wa API ni kama neno la siri linalomwambia seva, "Mtu huu anaruhusiwa kuuliza maswali." Bila huo, seva haitajibu.

Programu haitoi ufunguo uliojengwa ndani. Lazima utengeneze akaunti yako na mtoa huduma na uweke ufunguo wako katika programu.

## Namna ya kupata ufunguo wa API

1. Fungua **Mipangilio** katika Theodia.
2. Bonyeza **Msaidizi wa AI**.
3. Chagua **Mfano wa mbali**.
4. Chagua mtoa huduma kutoka orodha, au chague **Kipekee (Custom)** na uingize URL ya msingi.
5. Bonyeza kiungo cha ukurasa wa ufunguo wa mtoa huduma. Tengeneza akaunti ukiwa huna.
6. Tengeneza ufunguo mpya wa API kwenye tovuti ya mtoa huduma.
7. Nakili ufunguo na uweke Theodiani.
8. Bonyeza **Pima uunganisho** kuhakikisha unafanya kazi.

## Watoa huduma wanaoungwa mkono

Theodia inaweza kujitahiri kwa mtoa huduma yoyote anayetumia API inayolingana na OpenAI. Hizi ni zenye viungo vya mapema katika programu:

- **Mifano ya GitHub** — github.com/marketplace/models (ngazi huru ya kila siku, imeaguliwa)
- **OpenAI** — platform.openai.com
- **OpenRouter** — openrouter.ai
- **Anthropic** — console.anthropic.com
- **Groq** — console.groq.com
- **Mistral** — console.mistral.ai
- **Together AI** — api.together.xyz

Unaweza pia kutumia URL ya msingi ya **Kipekee (Custom)** ukitendesha seva yako au kutumia huduma tofauti.

## Inagharimu kiasi gani?

Watoa huduma wengi hukamata kwa **tokeni**. Tokeni kwa kawaida ni neno au sehemu ya neno. Unalipa tokeni unazotuma (swali lako) pamoja na tokeni AI anayotuma kurudi (jibu).

### Bei za kawaida

Bei zinabadilika, lakini hii ni wazo la kimapinduzi kama ya katikati ya 2026:

- **Mifano midogo ya haraka** (kama mwisho wa daraja la GPT-3.5 la bei nafuu) hugharama sehemu ndogo ya senti kwa tokeni elfu.
- **Mifano ya katikati** (kama GPT-4o au Claude Sonnet) kwa kawaida hugharama senti chache kwa tokeni elfu.
- **Mifano mikubwa ya kufikiri** (kama GPT-4.5 au Claude Opus) inaweza kugharama senti kumi hadi ishirini kwa tokeni elfu.

Swali la kawaida la Biblia katika Theodia linaweza kutumia tokeni mia chache hadi elfu mbili jumla. Hii inamaanisha maswali mengi hugharama kutoka **chini ya senti hadi senti chache**.

## Vidokezo vya kushika gharama ndogo

- Anza na mfano wa nafuu zaidi. Maswali mengi ya Biblia hayahitaji mfano mkubwa wa gharama.
- Tumia Groq au OpenRouter ukitaka kujaribu mifano tofauti na kulinganisha bei.
- Angalia dashibodi yako ya matumizi kwenye tovuti ya mtoa huduma.

## Mifano ya GitHub

[Mifano ya GitHub](https://github.com/marketplace/models) inatoa ngazi huru bila usajili unaoitajika. Unachohitaji ni akaunti huru ya GitHub na tokeni ya ufikiaji-binafsi yenye ruhusa ya kusoma mifano.

**Namna ya kuiweka:**

1. Nenda [github.com/settings/tokens](https://github.com/settings/tokens) na tengeneza **Tokeni ya ufikiaji binafsi (kimapokeo)**.
2. Pa `models:read` wigo (au chague tu ruhusa ya mifano).
3. Katika Theodia, chagua **Mifano ya GitHub** kama mtoa huduma na uweke tokeni yako.

**Mifano ya ngazi-huru:**

- `openai/gpt-4.1-nano` — **maombi 15 kwa dakika, maombi 150 kwa siku**
- `openai/gpt-4.1-mini` — **maombi 15 kwa dakika, maombi 150 kwa siku**
- `openai/gpt-4.1` — **maombi 10 kwa dakika, maombi 50 kwa siku**
- `openai/gpt-4o` — **maombi 10 kwa dakika, maombi 50 kwa siku**

Vikomo hivi vinarejea kila siku na ni vya kutosha kwa kujifunza Biblia kwa kawaida.

Kwa ziara kamili ya hatua kwa hatua yenye picha za skrini, ona mwongozo wa [Mifano ya GitHub](theodia://help/github-models).

## Taarifa ya faragha

Unapotumia mfano wa AI wa mbali, programu kwanza inaonyesha ombi la ridhaa linaeleza kinachotumwa: ujumbe wako, muktadha wa aya au sura, mialiko ya zana na matokeo, jina la mfano uliolinda, na ufunguo wako wa API katika kichwa cha ombi. Ombi linaenda moja kwa moja kwenye mwisho ulioweka, sio kupitia Theodia. Watoa huduma wengi hawatumii takwimu zako kujifunza mifano yao, lakini maandiko yanaondoka kwenye kifaa chako. Unaweza kubadilisha au kufuta ruhusa wakati wowote katika **Mipangilio → Msaidizi wa AI → Kushirikisha Takwimu za AI ya Mbali**.

## Muhtasari

- Unahitaji ufunguo wa API kutumia msaidizi wa AI.
- Tengeneza akaunti na mtoa huduma, tengeneza ufunguo, na uweke Theodiani.
- Maswali mengi hugharama senti chache au chini.
