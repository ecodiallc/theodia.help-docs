---
title: Msaidizi wa AI
level: advanced
category: ai
summary: Namna ya kutumia msaidizi wa AI kuelewa aya.
---

# Msaidizi wa AI

Theodia ina msaidizi wa AI. Anaweza kukusaidia kuelewa aya, kujibu swali, au kuzungumza mada ya Biblia.

## Namna ya kuwasha AI

AI imezimwa kwa chaguomsingi. Kuiwasha:

1. Fungua **Mipangilio**.
2. Bonyeza **Msaidizi wa AI**.
3. Bonyeza swichi kuiwasha.

Huenda ukahitaji kuweka akaunti au ufunguo. Programu itakuongoza.

## Namna ya kufungua AI

Bonyeza kichupo cha **AI** chini ya skrini. Dirisha la mazungumzo linafunguka.

## Namna ya kuuliza swali

Bonyeza sanduku chini. Andika swali lako. Bonyeza **Tuma**.

Mambo unayoweza kuuliza:

- "John 3:16 inamaanisha nini?"
- "Nambie kuhusu kitabu cha Warumi."
- "Matunda ya Roho ni nini?"
- "Linganisha Mahubiri ya Mlimani katika Mathayo na Luka."

## Namna ya kuuliza kuhusu aya mahususi

1. Fungua sura.
2. Bonyeza aya kuleta menyu ya aya.
3. Bonyeza **Mafafani ya AI**.

Aya inatumwa kwa AI. Bao la AI linafunguka aya ikiwa imejazwa mapema. Unaweza kuongeza swali, kama "Hii inamaanisha nini?" au "Ninapaswa kuitumia namna gani?"

## Mambo muhimu ya kujua

- AI ni zana, sio mtu. Inaweza kukosea.
- Daima linganisha majibu ya AI na Biblia yenyewe.
- AI inaweza kuhitaji intaneti. Haifanyi kazi bila mtandao.
- Unapotumia AI, maswali yako, muktadha wa aya, na ufunguo wako wa API yanatumwa kwenye mwisho uliochagua. Mara ya kwanza unapofanya hivi, programu inaomba ruhusa yako na inaonyesha kinachotumwa kwa usahihi. Unaweza kubadilisha au kufuta ruhusa hiyo baadaye katika **Mipangilio → Msaidizi wa AI → Kushirikisha Takwimu za AI ya Mbali**.
- Baadhi ya maeneo, kama ujenzi wa Duka la Programu la bara la China, hautoi msaidizi wa AI. Katika ujenzi huo vipengele pekee vya Biblia vya nje ya mtandao vinapatikana.

## Namna ya kudhibiti mazungumzo

Skrini ya AI inahifadhi orodha ya mazungumzo ya zamani. Kutoka orodha unaweza kufungua mazungumzo ya zamani, kuanza mpya, au kufuta mazungumzo husiayahitaji tena.

Kwa vidokezo vya juu zaidi, ona mwongozo wa [Kuandika Maombi Bora za AI](theodia://help/ai-prompts).
