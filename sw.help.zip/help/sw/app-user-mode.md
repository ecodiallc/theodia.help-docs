---
title: Hali ya Mtumiaji wa Programu
level: beginner
categories: [user-mode]
summary: Chagua kati ya hali za Msomaji, Kawaida, na Mtaalamu kudhibiti vipengele vinavyopatikana katika programu.
---

# Hali ya Mtumiaji wa Programu

Theodia inatoa hali tatu za mtumiaji zinazodhibiti vipengele unaoviona. Chagua inayolingana na unavyotaka kutumia programu.

## Msomaji

Hali rahisi zaidi. Hali ya Msomaji ni kwa kusoma Biblia bila vitu vinavyovuruga.

- Soma tafsiri yoyote ya Biblia
- Tumia Hali ya Umakini kwa kusoma safi, skrini nzima
- Tembea vitabu na sura
- Hakuna zana za kujifunza, hakuna AI, hakuna alamisho, hakuna rangi

Hali ya Msomaji ni bora ukitaka Theodia ihisi kama Biblia ya kidijitali safi bila nyongeza yoyote.

## Kawaida

Hali ya Kawaida inaongeza vipengele vya kila siku kwa kujifunza Biblia binafsi.

Kila kitu katika Msomaji, pamoja na:

- Alamisho, rangi, na maoni
- Kusoma kwa sauti (TTS)
- Msomaji wa Hali ya Kujifunza yenye menyu ya aya
- Biblia Sambamba
- Uingizaji wa Amri
- Kutafuta Biblia
- Ibada za kila siku na vitabu vilivojengwa ndani

Hali ya Kawaida ni chaguo sahihi kwa watumiaji wengi wakitaka kusoma, kuashiria, na kutafuta Biblia bila zana za kujifunza za juu.

## Mtaalamu

Hali yenye vipengele vyote. Hali ya Mtaalamu inafungua kila zana katika Theodia kwa kujifunza Biblia kwa undani.

Kila kitu katika Kawaida, pamoja na:

- Mafafani na kamusi za asili
- Marejeleo
- Kamusi ya Biblia
- Taarifa ya Neno (utafutaji wa Strong's)
- Msaidizi wa AI na Mafafani ya AI
- Menyu ya Kuzindua

Hali ya Mtaalamu imeundwa kwa machungaji, wanafunzi wa seminari, na mtu yeyote anayetaka zana za lugha asilia na misaada ya kujifunza ya AI.

## Namna ya kubadilisha hali

1. Fungua **Mipangilio**.
2. Bonyeza **Hali ya Mtumiaji wa Programu**.
3. Chagua **Msomaji**, **Kawaida**, au **Mtaalamu**.

Mabadiliko yanatekelezwa mara moja. Menyu na vitufe usivyo na ufikiaji katika hali yako ya sasa vinafichwa.

## Kuichagua hali

- **Msomaji** — Unataka kusoma Biblia tu, hakuna kingine.
- **Kawaida** — Unataka alamisho, rangi, maoni, utafutaji, na ibada.
- **Mtaalamu** — Unataka kila zana ya kujifunza, pamoja na AI, mafafani, na kamusi za asili.

Unaweza kubadilisha hali wakati wowote. Alamisho, rangi, na maoni yako hayafutwi kamwe ukibadilisha hali; yanafichwa tu mpaka urudie kwenye hali inayoiunga mkono.
