---
title: Kuhifadhi Nakala za Takwimu Zako
level: everyday
categories: settings
summary: Namna ya kuhifadhi na kurejesha maoni, rangi, alamisho, na siri zako.
---

# Kuhifadhi Nakala za Takwimu Zako

Maoni, rangi, alamisho, na mipangilio yako yamehifadhiwa kwenye kifaa chako. Ukipoteza simu, ukipata mpya, au ukiondoa programu, takwimu hizo zinaweza kupotea. Mwongozo huu unaonyesha namna ya kuzihifadhi nakala.

## Namna ya kufungua mipangilio ya nakala

1. Fungua **Mipangilio**.
2. Bonyeza **Nakala ya Programu (App Backup)**.

## Namna ya kutengeneza nakala ya programu

1. Fungua **Mipangilio**.
2. Bonyeza **Nakala ya Programu (App Backup)**.
3. Bonyeza **Tengeneza Nakala ya Programu**.
4. Chagua folda kwenye kifaa chako kuhifadhi faili. Unaweza pia kuchagua eneo la wingu.
5. Programu inatengeneza faili moja lenye takwimu zako zote. Faili inaishia kwa `.zip`.

## Mara ngapi kutengeneza nakala

Tengeneza nakala:

- Baada ya kuandika maoni mengi.
- Kabla ya kusasisha mfumo wa uendeshaji wa kifaa chako.
- Kabla ya kuondoa programu au kubadilisha simu.

Adili zuri ni nakala moja kwa mwezi. Watu wengine wanahifadhi nakala kila wiki.

## Namna ya kurejesha kutoka nakala ya programu

1. Fungua **Mipangilio**.
2. Bonyeza **Nakala ya Programu (App Backup)**.
3. Bonyeza **Rejesha kutoka Nakala ya Programu**.
4. Chagua faili la nakala la `.zip`.
5. Kwa kila aina ya takwimu (maoni, rangi, alamisho, n.k.), chagua kuhifadhi kilicho kwenye kifaa, kuibadilisha kwa nakala, au kuiruka.
6. Bonyeza **Rejesha**.

Programu inabadilisha takwimu zako kwa takwimu katika nakala. Hii ni pamoja na:

- Maoni
- Rangi
- Alamisho
- Folda za alamisho
- Mipangilio (mandhari, ukubwa wa herufi, lugha)

## Nakala za Siri

**Nakala ya Programu** yako **haijumuishi** siri nyeti kama ufunguo wako wa API ya AI au tokeni ya GitHub. Kuzihifadhi kivyake, tumia **Nakala za Siri**.

### Hifadhi nakala ya siri

1. Fungua **Mipangilio**.
2. Bonyeza **Nakala ya Programu (App Backup)**.
3. Chini ya **Nakala za Siri**, bonyeza **Hifadhi Nakala za Siri**.
4. Ingiza neno la siri gumu na ulithibitishe.
5. Programu inasimba siri zako na kushirikisha faili iliyosimbwa. Ihifadhi mahali salama.

### Rejesha nakala ya siri

1. Fungua **Mipangilio**.
2. Bonyeza **Nakala ya Programu (App Backup)**.
3. Chini ya **Nakala za Siri**, bonyeza **Rejesha Nakala za Siri**.
4. Chagua faili la nakala la siri lililosimbwa.
5. Ingiza neno la siri lile lile ulilotumia ukihifadhi.
6. Siri zako zinarejeshwa.

> **Muhimu:** Ukiusahau neno la siri, siri haziwezi kupatikana tena. Hakuna kuweka upya.

## Mambo ya kujua

- Kurejesha **kubadilisha** makundi uliyochagua. Kilichoongezwa baada ya nakala kitapotea kwa makundi hayo.
- Nakala ya programu ni faili moja la `.zip`. Iihifadhi mahali salama.
- Unaweza kunakili faili, kuihamisha, au kuihifadhi katika huduma yoyote ya wingu.
- Nakala za programu hazijumuishi tafsiri za Biblia wenyewe. Zinaweza kupakuliwa tena kutoka **Mipangilio** → **Dhibiti Nyenzo**.
- Nakala za siri zimesimbwa kwa neno lako la siri. Chagua neno la siri utakalokumbuka.

## Kidokezo

Ukiwa na vifaa zaidi ya kimoja, unaweza kunakili faili la nakala kwenye kila kifaa na kulirejesha. Takwimu zako zitakuwa zile zile kwenye vyote.
