---
title: Kuweka Alamisho kwenye Aya
level: everyday
categories: [annotate, read]
summary: Namna ya kuhifadhi aya ili uzipate tena.
---

# Kuweka Alamisho kwenye Aya

> **Hali:** Alamisho zinapatikana katika hali za **Kawaida** na **Mtaalamu**. Hali ya Umakini ni kwa kusoma safi, bila vitu vinavyovuruga, pekee. Unaweza kubadilisha hali katika **Mipangilio** → **Hali ya Mtumiaji wa Programu**.

Alamisho huhifadhi aya au sura ya kitabu ili uipate tena. Alamisho ni kama vichupo katika kitabu.

## Namna ya kuweka alamisho kwenye aya

1. Fungua aya.
2. Bonyeza aya kuleta menyu.
3. Bonyeza **Alamisho** katika menyu. Ikoni ya nyota inaashiria aya imehifadhiwa.

Alama ya kuhakiki kwenye ikoni inamaanisha aya sasa imekuwa alamisho.

## Namna ya kuweka alamisho kwenye sura ya kitabu

Unaposoma kitabu (sio Biblia), unaweza kuweka alamisho kwenye sura nzima:

1. Fungua sura.
2. Bonyeza ikoni ya **Alamisho** juu ya skrini.

## Namna ya kuona alamisho zako

Bonyeza kichupo cha **Alamisho** chini. Unaona orodha ya kila aya na sura ya kitabu ulizohifadhi.

## Namna ya kuondoa alamisho

- **Aya moja:** Fungua aya. Bonyeza aya, kisha bonyeza ikoni ya **Alamisho** tena. Alama ya kuhakiki inaondoka.
- **Kutoka orodhani:** Katika kichupo cha **Alamisho**, bonyeza kwa muda mrefu alamisho. Menyu ndogo inaonekana. Bonyeza **Futa**. (Unaweza pia kubonyeza kitufe kidogo cha × kwenye mstari.)

## Panga kwa folda

Unaweza kuweka alamisho katika folda. Kwa mfano, unaweza kuwa na folda iitwayo "Maandalizi ya Hubiri" na nyingine iitwayo "Kufariji."

Kufungua folda:

1. Fungua kichupo cha **Alamisho**.
2. Bonyeza **Dhibiti Folda** juu.
3. Bonyeza **+ Fungua Folda** juu ya orodha ya folda.
4. Andika jina na bonyeza **Hifadhi**.

Huwezi kufungua folda mbili zenye jina moja. Jina likiwepo tayari, hitilafu inaonekana ndani ya sanduku la kufungua-folda ili ubadilishe na ujaribu tena.

Kuweka alamisho katika folda:

1. Katika kichupo cha **Alamisho**, bonyeza kwa muda mrefu alamisho.
2. Bonyeza **Hifadhi katika Folda**.
3. Chagua folda, kisha bonyeza **Imekamilika**.

## Kuingiza alamisho

Unaweza kuleta alamisho Theodiani kutoka programu na faili nyingine.

Nenda **Mipangilio** → **Alamisho** → **Ingiza Alamisho**. Chagua **Ingiza kutoka Faili** au weka nakala kutoka ubaoni. Programu inatambua umbiza kwa njia yenyewe.

### Umbiza zinazotumika

**Kutolewa kwa JSON asilia** — Umbiza unatumika na kipengele cha kutolewa cha Theodia yenyewe. Hii huhifadhi folda na tarehe za kutengenezwa.

**Netscape Bookmark HTML** — Umbiza unatumika na Chrome, Firefox, na Safari wanapotoa alamisho. Folda huhifadhiwa.

**CSV** — Karatasi ya kuhesabu yenye safu wima. Programu hutafuta safu wima za `url` na `folder` (au `href` / `category`). Mfano:

```csv
url,folder
/bible/KJV/John/3,Favorites
/bible/KJV/Genesis/1,Sermon Prep
```

**Maandiko wazi** — Kila mstari ni marejeleo ya Biblia, URL ya programu, au elekezi la folda. Mfano:

```
folder: Favorites
John 3:16
Genesis 1:1
folder: Sermon Prep
Matthew 5:1
```

- Mistari inayoanza kwa `folder: <jina>` inaweka folda inayotumika kwa alamisho zote zilizofuata.
- Marejeleo ya Biblia kama `John 3:16` yanageuzwa kuwa alamisho katika Biblia yako chaguomsingi.
- URL za programu kama `/bible/KJV/John/3#v3_16` au `/book/MyBook/1` zinaingizwa moja kwa moja.
- Mistari inayoanza kwa `#` au `//` inachukuliwa kama maoni na kurukwa.

### Vidokezo vya kuingiza

- Alamisho zinazofanana zinarukwa kwa njia yenyewe.
- URL za nje (kama viungo vya BibleGateway) zinageuzwa kuwa alamisho za programu inapowezekana.
- Folda kutoka faili la kuingiza ikiwepo tayari, alamisho huwekwa katika folda ile ile.

## Vidokezo

- Unaweza kuweka alamisho kwenye aya hiyo hiyo katika tafsiri nyingi. Zote zinaonekana katika orodha.
- Alamisho zinabaki kwenye kifaa chako. Hazitumiwi wingu.
- Ona mwongozo wa [Kuhifadhi Nakala za Takwimu Zako](theodia://help/backups) kuzihifadhi salama.

## Alamisho katika PDF

PDF zina alamisho zake, zinazotengwa na alamisho zako za Biblia. Unaposoma PDF, bonyeza kitufe cha **Alamisho** katika ukanda wa zana wa msomaji kuhifadhi ukurasa wa sasa, kipa jina, na kuruka huko baadaye. Kila PDF huhifadhi orodha yake — ona [PDF](theodia://help/pdfs).
