---
title: Kuchagua Mfano wa AI
level: advanced
categories: ai
summary: Namna ya kuchagua mfano unaoifanya vizuri na zana za Theodia zilizojengwa ndani na uwezo wake.
---

# Kuchagua Mfano wa AI

> **Hali:** Msaidizi wa AI unahitaji hali ya **Mtaalamu**. Unaweza kubadilisha hali katika **Mipangilio** → **Hali ya Mtumiaji wa Programu**.

Sio kila mfano wa AI unafanya kazi kwa njia ile ile katika Theodia. Uzoefu bora unatoka kwenye mfano unaounga mkono **kuita zana** — uwezo wa AI kutumia vipengele vya Theodia vilivojengwa ndani kama kutafuta aya za Biblia, kutafuta, kusoma mafafani, na kutembea programu.

## Kuita zana ni nini?

Ukimwuliza AI ya Theodia swali, AI anaweza zaidi ya kuzungumza tu. Anaweza pia **kufanya**. Kwa mfano:

- Unasema, "Nionyeshe Yohane 3:16 katika ESV." AI anaita zana kufungua aya hiyo katika msomaji.
- Unasema, "Mafafani yangu yanasema nini kuhusu Warumi 8:28?" AI anaita zana kupata maudhui ya mafafani.
- Unasema, "Hifadhi aya hii kama alamisho." AI anaita zana kutengeneza alamisho.

Mifano isiyounga mkono kuita zana inaweza kukupa majibu ya maandiko tu. Hawawezi kutafuta vitu, kutembea, au kubadilisha kitu chochote katika programu.

## Mifano ipi inaunga mkono zana?

### Mifano ya mbali

Mifano mingi ya kisasa ya mbali kutoka watoa huduma wakuu inaunga mkono kuita zana inayolingana na OpenAI. Kwa jumla:

- **Mifano mikubwa** (kama GPT-4o, Claude Sonnet/Opus, Gemini Pro) inashughulikia zana kwa kuaminika na inaweza kunganisha mialiko mingi ya zana katika mazungumzo moja. Majina ya watoa huduma na ID za mifano zimeonyeshwa katika programu kwa urahisi; huduma halisi unayounganisha nayo ni ile yenye mwisho na ufunguo ulioweka.
- **Mifano midogo au ya bei nafuu** inaweza kuunga mkono zana lakini inaweza kuwa ya kuaminika kidogo. Inaweza kupuuzwa mialiko ya zana au kuipangwa vibaya.
- **Mifano ya zamani sana au ya kipekee** mara nyingi haiunga mkono zana kabisa.

Ukiwa na shaka, jaribu mfano katika Theodia. Mwombe "Nionyeshe Mwanzo 1:1" au "Tafuta Biblia kwa aya kuhusu upendo." Aya ikifunguka au matokeo ya utafutaji yakionekana, kuita zana kunafanya kazi.

## Mifano iliyoaguliwa kwa Theodia

Hizi ni chaguo nzuri zinazolinganisha gharama, ubora, na msaada wa zana:

- **OpenAI GPT-4o** — msaada wa zana wa mkali, wa haraka, unashughulikia maswali ya hatua-nyingi ya vitendo vizuri.
- **Anthropic Claude Sonnet / Opus** — matumizi ya zana ya kuaminika sana, bora kwa vipande virefu na kujifunza kwa undani.
- **Groq** (mifano mbalimbali) — mahitimisho ya haraka, mara nyingi bure au nafuu sana, msaada wa zana unabadilika kwa mfano.
- **OpenRouter** — hukuruhusu kujaribu mifano mingi kutoka akaunti moja. Tafuta mifano inayoorodhesha "function calling" au "tools" katika uwezo wake.
- **[Mifano ya GitHub](theodia://help/github-models)** — mtoa huduma wa bure aliyeaguliwa. Ufikiaji wa OpenAI, Anthropic, na mifano nyingine kupitia akaunti yako ya GitHub yenye ngazi huru ya bure ya kila siku. Inatumia ID za mifano za mtindo huo wa `openai/gpt-4o`.

## Mifano ya kuepukana

- **Mifano ya kukamilisha-maandiko tu** (kama GPT-3 ya msingi au LLaMA isiyotunzwa kwa maagizo) kwa kawaida haiunga mkono zana.
- **Mifano ya picha-pekee au ya kuona** iliyolenga picha badala ya maandiko inaweza kukosa msaada wa zana.
- **Mifano midogo sana** chini ya vigezo bilioni moja haipaswi kutumia zana sahihi, hata API ikidai inaunga mkono.

## Namna ya kupima msaada wa zana

Theodia inakagua msaada wa zana kwa njia yenyewe. Ukiweka mfano katika **Mipangilio → Msaidizi wa AI**, bonyeza **Pima uunganisho**. Uunganisho ukifanikiwa, programu inatuma ombi la pili lenye mfano wa zana. Utaona moja ya matokeo mawili:

- **✓ Zana zinaunga mkono** — Mfano unakubali mialiko ya zana na unaweza kutumia vipengele vya Theodia vilivojengwa ndani.
- **✗ Zana hazinaunga mkono** — Mfano unakataa ombi la zana. Utajibu kwa maandiko tu na hawezi kufungua aya, kutafuta, au kudhibiti alamisho kwako.

Ukiona "Zana hazinaunga mkono," mfano unaweza bada kufanya kazi kama msaidizi wa mazungumzo wa maandiko wazi, lakini hautapata uzoefu wa kuunganishwa, bila mikono.

Unaweza pia kuthibitisha kwa mkono kwa kumwomba AI kufanya kitu:

- "Nionyeshe Mathayo 5:3 katika KJV." — Inapaswa kufungua aya katika msomaji.
- "Kamusi ya asili inasema nini kuhusu neno 'agape' katika Yohane 3:16?" — Inapaswa kurudisha takwimu za kamusi ya asili.
- "Tafuta Biblia kwa aya kuhusu kusamehe." — Inapaswa kurudisha matokeo ya utafutaji.
- "Weka alamisho kwenye Marko 12:30." — Inapaswa kutengeneza alamisho.

AI akikupa maelezo ya maandiko badala ya kufanya kitu hicho kwa kweli, mfano unashindwa kutumia zana zake hata programu ikiwa iliripoti msaada.

## Mfano wangu hauunga mkono zana?

Bado unaweza kuitumia. AI atajibu kwa maandiko, na unaweza kutafuta aya, kutafuta, na kutembea programu kwa mkono wewe mwenyewe. Lakini utakosa uzoefu wa bila-mikono, uliounganishwa, unaofanya Theodia yenye nguvu.

## Muhtasari

- Chagua mfano wenye **kuita zana / function calling** kwa uzoefu bora wa Theodia.
- **Mifano mikubwa ya mbali** inashughulikia zana kwa kuaminika zaidi.
- Pima mfano wowote na amri rahisi kama "Nionyeshe Mwanzo 1:1" kuthibitisha msaada wa zana.
