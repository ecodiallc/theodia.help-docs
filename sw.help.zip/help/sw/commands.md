---
title: Amri
level: everyday
categories: [layout, study]
summary: Uingizaji wa Amri hukuruhusu kuruka kipengele chochote kwa kuandika amri fupi. Jifunze umbiza zinazoungwa mkono na mifano.
---

# Amri

Uingizaji wa **Amri** hukuruhusu kuruka karibu sehemu yoyote ya Theodia kwa kuandika elekezo fupi. Unaweza kuitumia kutoka kichupo cha Nyumbani au kutoka **Menyu ya Kuzindua** (ikoni ya **▼** katika kichwa).

## Inavyofanya kazi

1. Bonyeza sanduku la Amri.
2. Andika amri.
3. Bonyeza kitufe cha go kwenye kibodi.

Programu inasoma amri na inakupeleka moja kwa moja kwenye skrini sahihi.

## Hakuna kiambishi cha alama ya mstari

Amri **hazitumii** kiambishi cha `/`. Zinaingizwa kama maandiko wazi:

```
john 3:16
search love
backup
```

Ukiandika `/settings`, `/` ya mwanzo inaifanya isitambuliwe.

## Marejeleo ya Biblia

Andika marejeleo yoyote ya Biblia kuifungua katika msomaji.

```
psalms 23
john 3:16
matthew 5:1
1 cor 15:10
```

Majina ya vitabu yanaweza kulinganishwa kwa jina kamili au mkato. Katika lugha za UI zisizo Kiingereza unaweza pia kuandika majina ya vitabu katika lugha inayotumika.

## Utafutaji

```
search abraham
search love
search faith not works
```

## Alamisho, ulinganifu, mafafani, marejeleo, na taarifa ya neno

```
bookmark john 3:16
compare genesis 1:1
commentary john 1
aicommentary eph 2:8
xref 1 cor 15:10
word info john 1:1
```

Amri hizi hufungua zana iliyoitwa kwa kipande kilichotajwa.

## Kamusi ya asili

Andika namba ya Strong's kufungua ingizo la kamusi ya asili.

```
g1161
h7225
```

## Ibada

```
devotional
devotional smith
devotional daily
```

Bila jina, hii inafungua orodha ya ibada.

## Njia za mkato za kutembea

```
notes
highlights
bookmarks
flashcards
playlist
theoscript
resources
read john 3:16
```

Hizi huruka moja kwa moja kwenye skrini iliyoitwa au kufungua kipande katika msomaji.

## Kubadilisha tafsiri

Andika mkato wa tafsiri kubadilisha kwenda huko.

```
kjv
web
trlit
ohgb
```

Kwenye skrini ya msomaji, tafsiri inabadilishana mahali popote. Mahali popote pengine, inafungua tafsiri katika kipande chako cha karibuni.

## Vitendo vya amri vilivyotafsiriwa

Vitendo vya amri vya umma vinaweza kuandikwa katika lugha ya UI inayotumika **au** kwa Kiingereza. Kiingereza daima kinafanya kazi kama akiba. Amri zilizofichwa (njia za mkato za mipangilio, amri za kusakinisha, mayai ya Paskani) zinabaki na lahaja ya Kiingereza tu.

## Msaada

Andika `help` au `commands` katika sanduku la Amri kufungua marejeleo ya amri ndani ya programu wakati wowote.
