---
title: Mafafani na Kamusi za Asili
level: everyday
categories: study
summary: Namna ya kutafuta maana ya maneno na kusoma maoni ya kujifunza.
---

# Mafafani na Kamusi za Asili

> **Hali:** Mafafani na kamusi za asili zinahitaji hali ya **Mtaalamu**. Unaweza kubadilisha hali katika **Mipangilio** → **Hali ya Mtumiaji wa Programu**.

Theodia ina zana mbili za kujifunza: **mafafani** na **kamusi za asili**. Zinakusaidia kuelewa Biblia kwa undani zaidi.

## Mafafani ni nini?

Mafafani ni kitabu cha maoni ya kujifunza yaliyoandikwa na mtaalamu wa Biblia. Kwa aya mahususi, mafafani yanakuambia mandhari, maana, na jinsi aya inavyoingia katika Biblia nzima.

## Kamusi ya asili ni nini?

Kamusi ya asili ni kamusi ya maneno ya Biblia. Inakuambia neno asilia la Kiebrania au Kigiriki, lina maana nini, na linatumiwaje Biblini.

## Namna ya kufungua mafafani

1. Fungua sura.
2. Bonyeza aya.
3. Bonyeza **Mafafani**.

Ubao unafunguka. Unaonyesha maoni kutoka kwa mtaalamu wa Biblia kuhusu aya hiyo.

## Namna ya kufungua kamusi ya asili

1. Fungua sura katika Biblia inayojumuisha namba za Strong's.
2. Bonyeza namba ya Strong's katika aya (kwa mfano, G1234 au H1234).
3. Ubao unafunguka ukionyesha neno asilia la Kiebrania au Kigiriki, maana yake, na aya nyingine zinazotumia neno hilo.

Namba za Strong's zinaonekana kwa rangi tofauti katika maandiko ya aya ili zistonewane na maneno ya kawaida.

## Chagua mafafani tofauti

Mafafani yanachaguliwa kutoka kidhibiti-sondli juu ya ubao wa mafafani wenyewe. Fungua ubao, kisha bonyeza kidhibiti-sondli kuona mafafani uliyosakinisha. Chagua tofauti.

## Chagua kamusi ya asili tofauti

Kamusi ya asili inachaguliwa kutoka kidhibiti-sondli juu ya ubao wa kamusi ya asili. Fungua ubao, kisha bonyeza kidhibiti-sondli kuona kamusi ulizosakinisha. Chagua tofauti.

## Nyenzo zilizojengwa ndani

Theodia inakuja na seti ya mafafani na kamusi za asili zilizoletewa. Hizi zimejumuishwa na programu na zinafanya kazi bila intaneti. Mafafani na kamusi za asili za nyongeza haziwezi kusakinishwa au kupakuliwa tofauti.

## Wakati wa kuzitumia

- **Mafafani** ni bora aya ikiwa ngumu kuelewa. Maoni yanakupa mandhari.
- **Kamusi za asili** ni bora kwa kujifunza maneno. Zinakuambia maana kamili ya neno katika lugha asilia.

## Kidokezo

Aya ikiwa ina maoni unayotaka kuhifadhi, piga picha ya skrini au nakili maandiko kwenye maoni. (Ona mwongozo wa [Kuandika Maoni](theodia://help/notes).)

## Kamusi ya Biblia ya lugha wazi

Kwa maana za maneno na dhana za Biblia katika lugha husika (ahadi, kufutwa-kwenda, Wafarisayo, na kadhalika), Theodia pia inajumuisha zana ya Kamusi ya Biblia. Ifungue kutoka menyu ya aya kwa kubonyeza **Kamusi** (📖). Tofauti na kamusi ya asili: kamusi za asili zinaeleza maneno asilia ya Kiebrania na Kigiriki, kamusi kwa nyingine inaeleza neno katika lugha wazi. Ona mwongozo wa [Kamusi ya Biblia](theodia://help/dictionary) kwa namna ya kuitumia.
