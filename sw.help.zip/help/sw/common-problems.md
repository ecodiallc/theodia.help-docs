---
title: Matatizo ya Kawaida
level: everyday
categories: trouble
summary: Marekebisho ya haraka ya matatizo unaweza kuyakutana nayo.
---

# Matatizo ya Kawaida

Mwongozo huu unafunika matatizo watu wanayokutana nayo mara nyingi zaidi. Tatizo lako halipo hapa, ona mwongozo wa [Maswali Yanaulizwa Wapi?](theodia://help/getting-more-help).

## Programu ni ya polepole

1. Funga programu nyingine zinazoendesha nyuma.
2. Anzisha programu upya.
3. Anzisha kifaa chako upya.

## Sipati tafsiri ya Biblia

1. Fungua **Mipangilio** → **Dhibiti Nyenzo** kuona kilichosakinishwa.
2. Tafsiri haipo, bonyeza **Sakinisha kutoka GitHub**.
3. Katika kidude cha kupakua, bonyeza kichupo cha **Biblia** (au **Biblia za Kimataifa**) na chague tafsiri unayotaka.
4. Bonyeza **Sakinisha Zilizochaguliwa** na subiri kupakua kukamilike.
5. Unahitaji intaneti kupakua tafsiri mpya.

## Maoni au alamisho zangu zimepotea

1. Hakikisha unaangalia kichupo sahihi. Maoni yako katika kichupo cha **Maoni**. Alamisho ziko katika kichupo cha **Alamisho**.
2. Uliwahi kurejesha nakala hivi karibuni, nakala inaweza kubadilisha takwimu zako. Angalia tarehe ya nakala.
3. Uliiondoa na kusakinisha programu upya, takwimu zako zilipotea. Wakati ujao, tengeneza nakala kwanza.

## Utafutaji haupati aya

1. Hakikisha ulitahajiri neno sahihi.
2. Jaribu neno fupi. "Love" hupata aya zaidi kuliko "loving."
3. Hakikisha una tafsiri sahihi ya Biblia iliyosakinishwa. Utafutaji hufanya kazi katika tafsiri unazo tu.

## Kusoma kwa sauti hakifanyi kazi

1. Hakikisha sauti ya kifaa chako imeongezwa.
2. Hakikisha programu imeruhusiwa kutumia spika.
3. Jaribu tafsiri tofauti. Baadhi ya tafsiri zinafanya kazi vizuri zaidi na kusoma-kwa-sauti kuliko nyingine.
4. Kwa orodha ya ukaguzi wa hatua kwa hatua, ona mwongozo wa [Kusoma kwa Sauti](theodia://help/tts).

## Programu inaanguka bila kuacha

1. Anzisha programu upya.
2. Anzisha kifaa chako upya.
3. Tatizo likiendelea, tafadhali iripoti. Ona mwongozo wa [Maswali Yanaulizwa Wapi?](theodia://help/getting-more-help).

## Nataka kuondoa programu

Unaweza kuondoa Theodia kama programu yoyote nyingine. Kabla ya kufanya, tengeneza nakala ya takwimu zako. Ukiondoa, takwimu kwenye kifaa zimepotea.

## Bado nimeshtuka?

Ona mwongozo wa [Maswali Yanaulizwa Wapi?](theodia://help/getting-more-help). Huko, unaweza kupata viungo vya kuripoti tatizo na kuuliza jumuiya.

Unaweza pia kutafuta miongozo ya msaada kutoka skrini kuu ya **Msaada＆Miongozo**. Andika neno kama `notifications`, `search`, au `bookmarks` kupata mwongozo unaolingana.
