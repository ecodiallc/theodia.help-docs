---
title: Kulinganisha Tafsiri
level: everyday
categories: [read, study]
summary: Namna ya kuona aya hiyo hiyo katika kila tafsiri uliyosakinisha.
---

# Kulinganisha Tafsiri

> **Hali:** Zana ya Linganisha inapatikana katika hali za **Kawaida** na **Mtaalamu**. Hali ya Umakini ni kwa kusoma safi, bila vitu vinavyovuruga, pekee. Unaweza kubadilisha hali katika **Mipangilio** → **Hali ya Mtumiaji wa Programu**.

Zana ya **Linganisha** inaonyesha aya moja katika kila tafsiri ya Biblia uliyosakinisha, yote katika ubao mmoja. Inajifaa ukitaka kuona jinsi watafsiri tofauti wanavyoshughulikia aya ngumu, au unapochagua tafsiri na kutaka kuangalia aya hiyo hiyo katika kila moja.

## Namna ya kufungua Linganisha

1. Fungua sura katika tafsiri yoyote.
2. Bonyeza aya kuleta menyu ya aya.
3. Bonyeza **Linganisha** (⇄).

Ubao unafunguka. Ukanda wa kichwa unaonyesha marejeleo (kwa mfano, "John 3:16 — Compare"). Ubao unaorodhesha aya hiyo hiyo katika kila tafsiri iliyosakinishwa. Tafsiri yako ya sasa inaorodheshwa kwanza; zingine zimepangwa kwa alfabeti.

## Ubao unaonekanaje

Ubao ni **orodha wima**, sio safu inayopishana. Kila mstari ni tafsiri moja:

- **Jina la tafsiri** (kwa mfano, "KJV") liko juu ya mstari. Linatekelezeka.
- **Maandiko ya aya** yako chini ya jina.

Sugua ubao kuona tafsiri zote. Kila tafsiri iliyosakinishwa kwenye kifaa chako itaonekana hapa. Tafsiri isiyo na kitabu au aya hiyo inarukwa.

## Namna ya kusoma aya katika tafsiri tofauti

Bonyeza jina la tafsiri katika mstari. Ubao wa Linganisha unafungwa na sura hiyo hiyo inafunguka na aya iliyochaguliwa ikionekana katika tafsiri hiyo. Hii ni njia ya haraka zaidi ya kuruka kutoka ulinganifu moja kwa moja kwenda kusoma tafsiri mahususi.

## Namna ya kufunga Linganisha

- **Kwenye simu:** bonyeza X juu-kulia wa ubao.
- **Kwenye kompyuta kubwa (tablet):** bonyeza X juu ya ubao, au bonyeza nje ya ubao.

Umerudishwa kwenye mtazamo wa sura katika tafsiri yako ya asili.

## Wakati wa kutumia Linganisha

- **Kuchagua tafsiri.** Fungua aya unayoijua vizuri katika tafsiri yako ya sasa, kisha Linganisha kuiona katika nyingine. Tofauti zinaonyeka.
- **Aya ngumu.** Aya inayowakanusha katika tafsiri moja mara nyingi iko wazi zaidi katika nyingine.
- **Kujifunza maneno.** Angalia jinsi watafsiri tofauti wanavyoshughulikia neno au msemo muhimu.

Kwa ulinganifu wa kuangaliwa-marafiki wa sura nzima katika tafsiri nyingi kwa wakati mmoja, tumia **mtazamo sambamba** badala yake. Ona mwongozo wa [Hali ya Kujifunza](theodia://help/study-mode) kwa namna ya kuuwasha.
