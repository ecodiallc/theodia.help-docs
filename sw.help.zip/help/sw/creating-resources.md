---
title: Kutengeneza Nyenzo Zako Mwenyewe
level: advanced
categories: resources
summary: Namna ya kutengeneza Biblia, mafafani, vitabu, ibada, na kamusi za asili za kawaida na kuziingiza Theodiani.
---

# Kutengeneza Nyenzo Zako Mwenyewe

Theodia inaunga mkono nyenzo za kawaida katika umbiza wa Unique Bible App. Kila nyenzo ni faili la SQLite lenye muundo maalum wa jedwali. Unaweza kutengeneza faili hizi kwenye kompyuta na kuziingiza programuni.

## Aina za faili na majedwali yanayohitajika

### Biblia (`.bible`)

Faili la Biblia ni hifadhidata ya SQLite yenye angalau moja ya majedwali haya:

- **`Verses`** — safu wima: `Book` (nambari, 1-66), `Chapter` (nambari), `Verse` (nambari), `Scripture` (maandiko)
- **`Bible`** — safu wima: `Book` (nambari), `Chapter` (nambari), `Verse` (nambari), `Scripture` (maandiko)

Unaweza pia kuongeza jedwali la **`Details`** lenye safu wima za metadata kama `Description`, `Abbreviation`, na `Version`.

Mfano wa SQL:

```sql
-- Jedwali kuu la maandiko
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- Jedwali la metadata (si lazima)
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### Mafafani (`.commentary`)

Mafafani huja katika aina tatu: **kitabu**, **sura**, na **aya**. Aina inatambuliwa kwa **herufi ya kwanza ya jina la faili**.

#### Mafafani ya kitabu — jina la faili linaanza kwa `b`

Mafafani ya kitabu yanashughulikia kitabu chote cha Biblia katika ingizo moja. Jedwali la `Commentary` linahitaji safu wima za `Book` na `Scripture` (au `Content`). Hakuna haja ya safu wima za `Chapter` au `Verse`.

- **`Commentary`** — safu wima: `Book` (nambari), `Scripture` (maandiko) au `Content` (maandiko)

Mfano wa SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

Mfano wa jina la faili: `bMyCommentary.commentary`

#### Mafafani ya sura — jina la faili linaanza kwa `c`

Mafafani ya sura yanashughulikia kila sura ya kitabu cha Biblia.

- **`Commentary`** — safu wima: `Book` (nambari), `Chapter` (nambari), `Scripture` (maandiko) au `Content` (maandiko)

Mfano wa SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

Mfano wa jina la faili: `cMyCommentary.commentary`

#### Mafafani ya aya — jina la faili linaanza kwa `v`

Mafafani ya aya yanashughulikia aya binafsi. Jedwali la `Commentary` linahitaji safu wima za `Book`, `Chapter`, `Verse`, na `Scripture` (au `Content`).

- **`Commentary`** — safu wima: `Book` (nambari), `Chapter` (nambari), `Verse` (nambari), `Scripture` (maandiko) au `Content` (maandiko)

Mfano wa SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

Mfano wa jina la faili: `vMyCommentary.commentary`

### Vitabu (`.book`)

Faili la kitabu ni hifadhidata ya SQLite yenye jedwali la `Reference`.

- **`Reference`** — safu wima: `id` (nambari), `Chapter` (maandiko), `Content` (maandiko)

Kila safu ni sura moja. Safu wima ya `Chapter` ni kichwa cha sura. Safu wima ya `Content` ni mwili wa sura, unaweza kujumuisha HTML (`<b>`, `<i>`, `<br>`, n.k.).

Mfano wa SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

Unaweza pia kutengeneza vitabu kutoka faili za Markdown. Programu inaweza kuingiza faili za `.md` ambapo `#` ni kichwa cha kitabu na `##` inaashiria sura. Markdown hubadilishwa kuwa HTML kiotomatiki.

### Ibada (`.devotional`)

Faili la ibada ni hifadhidata ya SQLite yenye jedwali la `devotional`.

- **`devotional`** — safu wima: `month` (nambari, 1-12), `day` (nambari, 1-31), `devotion` (maandiko)

Kila safu ni somo la siku moja. Programu inatafuta ingizo kwa mwezi na siku ya leo.

Mfano wa SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### Kamusi za asili (`.lexicon`)

Faili la kamusi ya asili ni hifadhidata ya SQLite yenye jedwali la `Lexicon`.

- **`Lexicon`** — safu wima: `Topic` (maandiko, namba ya Strong's), `Definition` (maandiko, ingizo la kamusi ya asili)

Safu wima ya `Topic` inashika namba ya Strong's (kwa mfano, `G1161` au `H7225`). Safu wima ya `Definition` inashika maandiko kamili ya ingizo, yanaweza kujumuisha HTML.

Mfano wa SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

Kamusi za asili huwasha zana ya Taarifa ya Neno. Ukipiga bonyeza neno katika Biblia ya kati-ya-mistari, programu inatafuta namba ya Strong's katika kamusi za asili zilizosakinishwa.

## Kutengeneza faili kwenye kompyuta yako

1. Sakinisha kihariri cha SQLite (DB Browser for SQLite, SQLiteStudio, au zana ya mstari-wa-amri ya `sqlite3`).
2. Tengeneza faili jipya la hifadhidata.
3. Tengeneza jedwali linalohitajika na uingize takwimu zako.
4. Hifadhi faili kwa kiambishi sahihi (`.bible`, `.commentary`, `.book`, `.devotional`, au `.lexicon`).

## Kuingiza Theodiani

1. Hamishia faili kifaa chako (AirDrop, barua pepe, hifadhi ya wingu, au USB).
2. Fungua **Theodia**.
3. Nenda **Mipangilio** → **Dhibiti Nyenzo**.
4. Bonyeza **Ingiza kutoka Faili**.
5. Chague faili lako.

Programu inathibitisha faili (inakagua jedwali linalohitajika), inanakili kwenye folda ya takwimu ya programu, na inawasha kiotomatiki. Faili likiwa batili, utaona ujumbe wa kosa unaoeleza kilichokosekana.

## Vikomo

- Huwezi kufuta nyenzo zilizojengwa ndani. Ukijaribu kuingiza faili lenye jina linalofanana na Biblia, mafafani, au kitabu kilichojengwa ndani, kuingiza kunashindwa.
- Faili za Biblia zinahitaji jedwali la `Verses` au `Bible`. Hakuna lililopo, kuingiza kunashindwa.
- Faili za mafafani zinahitaji jedwali la `Commentary`.
  - Mafafani ya kitabu yanahitaji safu wima za `Book` na `Scripture` (au `Content`).
  - Mafafani ya sura yanahitaji safu wima za `Book`, `Chapter`, na `Scripture` (au `Content`).
  - Mafafani ya aya yanahitaji safu wima za `Book`, `Chapter`, `Verse`, na `Scripture` (au `Content`).
- Faili za vitabu zinahitaji jedwali la `Reference`.
- Faili za kamusi za asili zinahitaji jedwali la `Lexicon`.
- Faili za ibada zinahitaji jedwali la `devotional`.

## Vidokezo

- Weka ukubwa wa faili kuwa wa kawaida. Faili kubwa mno za SQLite zinaweza kusababisha matatizo ya kumbukumbu kwenye vifaa vya zamani.
- Jaribu faili lako kwenye kompyuta kwanza. Iufungue kwenye kivinjari cha SQLite na uendeshe `SELECT * FROM` jedwali linalohitajika kuthibitisha takwimu zinaonekana sahihi.
- Kwa Biblia, hakikisha safu wima ya `Book` inatumia namba (1 = Mwanzo, 66 = Ufunuo).
- Kwa mafafani, unaweza kutumia `Scripture` au `Content` kama safu wima ya maandiko ya mafafani.
- Kwa vitabu, HTML katika safu wima ya `Content` inachorwa unaposoma. Iweke rahisi: `<b>`, `<i>`, `<br>`, na `<hr>` ni salama.

## Mahali pa kupata nyenzo zilizopo

Theodia inaweza kusoma nyenzo kutoka mradi wa [Unique Bible App](https://github.com/eliranwong/UniqueBible). Biblia nyingi, mafafani, vitabu, na nyenzo nyingine zipo hapo katika umbiza sahihi wa SQLite. Ona mwongozo wa [Kupata Nyenzo za Ziada](theodia://help/getting-core-files) kwa namna ya kuzipata na kuongeza.
