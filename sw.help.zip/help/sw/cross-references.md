---
title: Marejeleo
level: everyday
categories: study
summary: Namna ya kupata aya zinazounganishwa na unayosoma.
---

# Marejeleo

> **Hali:** Marejeleo yanapatikana katika hali za **Kawaida** na **Mtaalamu**. Hali ya Umakini ni kwa kusoma safi, bila vitu vinavyovuruga, pekee. Unaweza kubadilisha hali katika **Mipangilio** → **Hali ya Mtumiaji wa Programu**.

"Marejeleo" ni aya nyingine inayozungumza juu ya kitu kilekile na aya unayosoma. Ubao wa marejeleo unaonyesha aya zipi katika Biblia zinazounganishwa mmoja na mmoja.

## Namna ya kufungua marejeleo

1. Fungua sura.
2. Bonyeza aya kuleta menyu ya aya.
3. Bonyeza **Marejeleo**.

Ubao unafunguka. Unaonyesha orodha ya aya nyingine zinazounganishwa na uliyobonyeza.

## Namna ya kusoma orodha

Kila mstari ni aya moja inayounganisha. Unaona:

- Kitabu, sura, na aya.
- Muhtasari mfupi wa maandiko ya aya.
- Alama inayoonyesha nguvu ya uunganisho.

## Namna ya kuruka aya inayounganisha

Bonyeza mstari wowote. Programu inafungua aya hiyo kwako. Ukimaliza, bonyeza kitufe cha nyuma kurudi.

## Alama inamaanisha nini

Alama inakuambia aya zimeunganishwa kwa karibu vipi. Alama ya juu inamaanisha uunganisho wa nguvu, wa moja kwa moja. Alama ya chini inamaanisha wa tasa zaidi.

## Tumia marejeleo kwa kujifunza

Marejeleo yanajifaa kwa:

- **Kujifunza maneno.** Ona jinsi Biblia inavyotumia neno katika maeneo tofauti.
- **Kujifunza mada.** Fuata mada, kama "upendo" au "ahadi," kupitia Maandiko.
- **Maandalizi ya hubiri.** Pata aya za kuunga mkono haraka.

## Kidokezo

Marejeleo yanafanya kazi bora zaidi na tafsiri ya neno-kwa-neno kama WEB.
