---
title: Ibada za Kila Siku
level: everyday
categories: [content, read]
summary: Namna ya kusoma ibada fupi kila siku.
---

# Ibada za Kila Siku

Ibada ni kusoma fupi cha siku moja. Mara nyingi kina aya, wazo fupi, na swali la kufikiri. Theodia inakuja na maktaba ndogo ya ibada.

## Namna ya kufungua ibada

1. Bonyeza kichupo cha **Ibada** chini ya skrini.
2. Unaona orodha ya ibada zilizosakinishwa kwenye kifaa chako.
3. Bonyeza moja kuifungua.

## Namna ya kusoma ibada

1. Fungua ibada.
2. Sugua kusoma.
3. Tumia vitufe juu:
   - Bonyeza **tarehe** kuruka siku tofauti.
   - Bonyeza **nyota** kuweka alamisho kwenye siku.
   - Bonyeza **spika** kuisoma kwa sauti (kifaa chako kikiunga mkono). Ona mwongozo wa [Kusoma kwa Sauti](theodia://help/tts) kwa namna ya kuchagua sauti.
   - Bonyeza **Iliyotangulia** au **Ifuatayo** kutembea siku iliyopita au inayofuata.

## Namna ya kuhifadhi aya kutoka ibada

1. Fungua ibada.
2. Bonyeza aya.
3. Bonyeza **Alamisho** au **Rangi**.

Aya imehifadhiwa katika Alamisho au Rangi zako.

## Namna ya kuandika maoni juu ya ibada

1. Fungua ibada.
2. Bonyeza aya.
3. Bonyeza **Maoni**. Andika tafakari au maombi yako. Bonyeza **Hifadhi**.

Maoni yanaonekana katika kichupo chako cha Maoni.

## Vidokezo

- Ibada hazihitaji intaneti. Zinafanya kazi bila mtandao.
- Ukitaka ibada zaidi, ona mwongozo wa [Kupata Nyenzo za Nyongeza kutoka GitHub](theodia://help/getting-core-files).
