---
title: Kamusi ya Biblia
level: everyday
categories: study
summary: Tafuta maneno na dhana za Biblia katika nyenzo za kamusi zilizosakinisha. Ifungue kutoka menyu ya aya au kutoka ingizo la kamusi ya asili, kisha ubonyeze neno lolote kuona neno hilo katika kila kamusi.
---

# Kamusi ya Biblia

> **Hali:** Kamusi ya Biblia inahitaji hali ya **Mtaalamu**. Unaweza kubadilisha hali katika **Mipangilio** → **Hali ya Mtumiaji wa Programu**.

Zana ya Kamusi ya Biblia hutafuta neno au msemo katika kila nyenzo ya kamusi ulizosakinisha. Inajifaa ukitaka maana ya lugha-wazi ya neno la Biblia, maelezo ya mtu au mahali, au makala fupi ya dhana ya theolojia.

Kamusi ya Biblia ni tofauti na zana ya **Taarifa ya Neno**, inayotafuta neno asilia la Kiebrania au Kigiriki nyuma ya aya. Kamusi inasoma **neno la lugha husika** ulilobonyeza na inakuonyesha kamusi zako zilizosakinisha zinasema nini kuhusu lile. Kwa maoni ya tafsiri ya Biblia ya neno-kwa-neno, ona mwongozo wa [Mafafani na Kamusi za Asili](theodia://help/commentaries-and-lexicons).

## Namna ya kufungua Kamusi

Kuna njia mbili za kufungua kamusi.

### Kutoka menyu ya aya

1. Fungua sura katika [Hali ya Kujifunza](theodia://help/study-mode).
2. Bonyeza aya kufungua menyu ya aya.
3. Bonyeza **Kamusi** (📖).

Ubao unafunguka ukitwa kwa marejeleo ya aya (kwa mfano, "John 3:16"). Maandiko ya aya yako juu na kila neno latekelezeka. Chini ya aya kuna utepe wa vipande unaonyesha kila kamusi iliyosakinisha. Chini ya hiyo kuna maana, isiyozidisha mpaka ubonyeze neno.

### Kutoka ingizo la kamusi ya asili

Unaposoma ingizo la kamusi ya asili katika bao la Taarifa ya Neno, baadhi ya ingizo zina viungo vya bluu vya makala za kamusi zinazohusiana. Bonyeza viungo hivyo. Kamusi ya asili inafunga na kamusi inafunguka katika makala hiyo. Hii ni njia ya haraka zaidi ya kuruka kutoka neno la Kigiriki au Kiebrania kwenda maelezo ya lugha-wazi ya maana yake.

## Mtazamo wa aya unavyofanya kazi

Ukifungua kamusi kutoka menyu ya aya, aya inaonekana juu ya ubao kama orodha ya maneno yantekelezekayo. Maneno ya kawaida ya lugha husika kama "the," "and," "of," "to," na "a" hayatekelezeki. Kila neno lingine latekelezeka. Kila neno latekelezeka limepangwa rangi na gumu ili litostane na aya nyingine.

Bonyeza neno lolote katika aya. Theodia hutekeleza utafutaji katika kila kamusi iliyosakinisha kwa ulinganifu kamili wa neno hilo. Utepe wa vipande chini hubadilika kuonyesha kamusi zipi zina ingizo: kamusi zisizo na ingizo la neno hilo zimewekwa kivuli. Kamusi ya kwanza yenye ingizo imeteuliwa kwa njia yenyewe, na maana yake inaonekana chini ya utepe wa vipande.

Neno ulilobonyeza limeangaziwa katika maandiko ya aya juu ya ubao, hivyo ujue daima unatafuta nini.

## Kubadilisha kati ya kamusi

Kila kamusi iliyosakinisha inaonekana kama kipande kidogo chini ya aya. Baada ya kubonyeza neno:

- Kipande cha **rangi kamili** — kamusi hii ina ingizo la neno ulilobonyeza. Bonyeza kubadili kwenda maana ya kamusi hiyo.
- Kipande **kilichowekwa kivuli** — kamusi hii haina ingizo la neno hilo. Imeonyeshwa kijivu ili uone kwa kuangalia mara moja kamusi zipi zinamfunika neno, na kipande hakiwezi kubonyezwa.

Kamusi iliyochagua imeangaziwa. Bonyeza kipande kamili kingine chochote kusoma neno hile hile katika kamusi hiyo. Maana chini hubadilika mara moja.

Neno likiwepo katika kamusi moja tu ya zilizosakinisha, kipande kimoja tu ni kamili na zingine zimewekwa kivuli.

## Ubao unaonyesha nini

Ubao wa kamusi una sehemu tatu, kutoka juu hadi chini:

- **Aya** — aya uliyofungua kamusi kutoka kwake. Maneno yantekelezekayo, na neno ulilobonyeza hivi karibuni limeangaziwa.
- **Utepe wa vipande** — kila kamusi iliyosakinisha. Kamili inamaanisha "ina ingizo la neno lililobonyezwa." Kivuli inamaanisha "hakuna ingizo la neno hile."
- **Maana** — makala kutoka kamusi iliyochagua. Maandiko wazi, yaliyopangwa kwa aya na vichwa. Viungo vya ndani kwa ingizo nyingine za kamusi vinatekelezeka; kubonyeza kimoja kinaufungua ingizo huo katika kamusi.

## Kinachotokea ingizo haipatikani

Ukibonyeza neno kamusi zako zilizosakinisha hazilifuniki, ubao unaonyesha ujumbe mfupi wa "hakuna ingizo zilizopatikana" badala ya maana. Hii ni ya kawaida kwa maneno ya kawaida sana kama "mwaka" au "kuja" yasiyo maneno ya theolojia ya Biblia, ingawa yanaonekana kote Biblini. Jaribu neno la kipekee zaidi, au tumia zana ya Taarifa ya Neno ya kamusi ya asili badala yake, inayofanya kazi kwenye maandiko asilia ya Kigiriki na Kiebrania.

## Kinachotokea kamusi haiposakinishwa

Kamusi inahitaji angalau faili moja la nyenzo ya kamusi ili iweze kufaa. Theodia inakuja na moja. Uliiondoa au unatendesha usakinishi wa kipekee usio na kamusi, mtazamo wa aya unaendelea kuonekana na maneno yanaendelea kutekelezeka, lakini utepe wa vipande ni wazi na kila utafutaji unarudisha "hakuna ingizo zilizopatikana."

Kamusi za nyongeza haziwezi kusakinishwa tofauti.

## Vidokezo

- Kamusi hutekeleza utafutaji wa **ulinganifu kamili wa neno**. Kubonyeza "love" hunipata ingizo zenye kichwa "love" sio "loved" au "loving." Kutafuta fomu inayohusiana, tumia zana ya Taarifa ya Neno ya kamusi ya asili kwenye neno la Kigiriki au Kiebrania.
- Utepe wa vipande ule ule kwenye simu na tablet. Kwenye tablet kamusi inafunguka kama bao la pembeni pembeni ya sura; kwenye simu inafunguka kama kidude cha skrini-nzima. Vyote vina mpangilio huo wa sehemu-tatu.
- Kubonyeza neno katika aya tofauti kunaufungua aya mpya katika ubao. Uchaguzi wako wa awali unaondolewa. Bonyeza neno katika aya mpya kuanza utafutaji mpya.
- Baadhi ya ingizo za kamusi zinarejea neno hile hile katika kamusi nyingine. Bonyeza viungo hivyo vya ndani kufuatilia njia katika kila kamusi zako zilizosakinisha.

## Tofauti kati ya Kamusi na Taarifa ya Neno

Zana zote mbili zinafunguka kutoka menyu ya aya, lakini zinafanya vitu tofauti:

- **Kamusi** (📖) inasoma neno la lugha husika ulilobonyeza na hulipata katika kamusi zako zilizosakinisha za lugha husika. Ni zana sahihi kwa maana ya lugha-wazi ya maneno ya theolojia ya Biblia kama "ahadi," "kufutwa-kwenda," au "Mfarisayo."
- **Taarifa ya Neno** (?) inasoma neno asilia la Kigiriki au Kiebrania nyuma ya aya na hulipata katika kamusi zako za asili. Ni zana sahihi kwa kujifunza maneno kwa uzito, kupata kila mahali neno la Kigiriki linatumika, na kusoma maana za lugha asilia.

Ukiwa na shaka, anza na kamusi. Ukitaka kuchimba lugha asilia, badili kwenda Taarifa ya Neno. Ona mwongozo wa [Mafafani na Kamusi za Asili](theodia://help/commentaries-and-lexicons) kwa ziara kamili ya Taarifa ya Neno.

## Miongozo inayohusiana

- Mwongozo wa [Hali ya Kujifunza](theodia://help/study-mode) unaeleza menyu ya aya kwa undani na zana ya Kamusi (📖) iko wapi kando ya Alamisho, Rangi, Soma, Linganisha, Marejeleo, Mafafani ya AI, Taarifa ya Neno, na Maoni.
- Mwongozo wa [Mafafani na Kamusi za Asili](theodia://help/commentaries-and-lexicons) unashughulikia Taarifa ya Neno na kamusi za asili za lugha asilia.
- Mwongozo wa [Nyenzo ni nini?](theodia://help/what-are-resources) unaeleza aina tofauti za faili Theodia inazitumia, pamoja na nyenzo za kamusi.
- Mwongozo wa [Matatizo ya Kawaida](theodia://help/common-problems) una marekebisho ya matokeo wazi na matatizo mengine ya kamusi.
