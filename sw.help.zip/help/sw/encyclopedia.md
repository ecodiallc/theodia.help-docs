---
title: KamusiElezo
level: everyday
categories: study
summary: Namna ya kutafuta makala za kamusiElezo na kutembea vitabu vya marejeleo.
---

# KamusiElezo

Theodia inajumuisha **KamusiElezo** iliyojengwa ndani kwa kutafuta makala zinazohusiana na Biblia, watu, maeneo, na mada. Programu inakuja na _Kitto's Illustrated Commentary_ (KIT) iliojengwa ndani, na unaweza kupakua kamusiElezo za nyongeza kutoka hazina.

## KamusiElezo katika Theodia ni nini?

KamusiElezo ni kitabu cha marejeleo kilichotengenezwa na makala fupi. Kila makala inafunika mtu, mahali, tukio, au mada ya Biblia. Tofauti na mafafani, yanayoeleza aya mahususi, makala ya kamusiElezo inaeleza mada yenyewe.

## Namna ya kufungua KamusiElezo

1. Bonyeza **KamusiElezo** katika ukanda wa chini.
2. Chagua kamusiElezo kutoka mstari wa viakrifu juu.
3. Andika mada, mtu, au mahali katika sanduku la utafutaji.

Utafutaji unahitaji angalau **herufi 3** kabla matokeo na mapendekezo ya kujikamilisha yaonekane.

## Kusoma makala

- Kwenye **simu**, bonyeza matokeo yoyote kufungua makala kwenye skrini mpya.
- Kwenye **tablet**, makala inafunguka katika ubao kulia orodha ikibaki kushoto.

## Kuchagua kamusiElezo

Bonyeza kipande cha kiakrifi (kama **KIT**) kubadilisha kwenda kamusiElezo hiyo. Kutafuta kamusiElezo zaidi ya moja kwa wakati mmoja, tumia kichupo cha **Utafutaji** na chague **KamusiElezo** kama hali ya utafutaji.

## Kupata kamusiElezo zaidi

1. Fungua **Mipangilio**.
2. Bonyeza **Dhibiti Nyenzo**.
3. Bonyeza **Sakinisha kutoka GitHub**.
4. Chagua kichupo cha **KamusiElezo**.
5. Bonyeza kitufe cha kupakua pembeni ya kamusiElezo unayotaka.

KamusiElezo zinapakuliwa kutoka hazina ya kamusiElezo ya GitHub ya Theodia na kusakinishwa kwa njia yenyewe. KamusiElezo zilizosakinishwa zinaonekana katika skrini ya KamusiElezo na katika Utafutaji.

Unaweza pia kusakinisha kamusiElezo kutoka faili la ndani: katika **Dhibiti Nyenzo**, bonyeza **Sakinisha Faili la Ndani** na uchague faili la `.encyclopedia`. Faili hunakiliwa katika folda ya kamusiElezo ya programu na kuongezwa kwenye kielezo cha pamoja cha utafutaji.

## Bonyeza kwa muda mrefu kwa kichwa kamili

Kwenye skrini ya Utafutaji, vipande vya kamusiElezo vinaonyesha viakrifi fupi. Bonyeza kwa muda mrefu kipande kuona jina kamili la kamusiElezo.

## Wakati wa kutumia KamusiElezo

- Tafuta mtu, mahali, au mada kabla au unaposoma kipande.
- Pata mandhari ya neno au dhana ya Biblia inayojitanda katika aya nyingi.
- Soma pamoja na mafafani kwa kujifunza kwa undani zaidi.
