---
title: Njia za Mkato za Kibodi ya Nje
level: everyday
categories: [tablet, settings]
summary: Marejeleo kamili ya njia za mkato za kibodi kwa iPad zenye kibodi cha nje kilichounganishwa.
---

# ⌨️ Njia za Mkato za Kibodi ya Nje

Ukitumia Theodia kwenye iPad yenye kibodi cha nje (Magic Keyboard, kibodi ya Bluetooth, au kibodi ya USB), unaweza kutembea programu bila kugusa skrini.

> **Hali:** Baadhi ya njia za mkato zinafanya kazi tu kipengele kinacholingana kikiwa kipatikani katika hali yako ya mtumiaji ya sasa. Kwa mfano, `Cmd + Option + 6` (Alamisho) na `Cmd + Option + 7` (Rangi) hazifanyi kitu katika hali ya Msomaji. Badilisha hali katika **Mipangilio** → **Hali ya Mtumiaji wa Programu**.

Njia za mkato zinafanya kazi kwenye **iPad**.

## Njia za mkato za jumla (popote)

| Njia ya Mkato      | Kitendo                                          |
| ------------------ | ------------------------------------------------ |
| `Cmd + /`          | Onyesha msaada huu wa njia za mkato za kibodi    |
| `Cmd + .`          | Funga kidude / boksi (mbadala wa Escape)         |
| `Cmd + Option + 1` | Nenda kichupo cha Ukurasa wa nyumbani            |
| `Cmd + Option + 2` | Nenda kichupo cha Biblia                         |
| `Cmd + Option + 3` | Nenda kichupo cha Vitabu                         |
| `Cmd + Option + 4` | Nenda kichupo cha Ibada                          |
| `Cmd + Option + 5` | Nenda kichupo cha Utafutaji                      |
| `Cmd + Option + 6` | Nenda kichupo cha Alamisho (Kawaida na Mtaalamu) |
| `Cmd + Option + 7` | Nenda kichupo cha Rangi (Kawaida na Mtaalamu)    |
| `Cmd + Option + 8` | Nenda kichupo cha Maoni (Kawaida na Mtaalamu)    |
| `Cmd + Option + 9` | Nenda kichupo cha AI (Mtaalamu tu, ikiwa imewashwa) |
| `Cmd + Option + 0` | Nenda kichupo cha Msaada                         |
| `Cmd + Option + I` | Nenda kichupo cha Kuhusu                         |
| `Cmd + [`          | Rudi nyuma                                       |
| `Cmd + F`          | Fungua Utafutaji                                 |
| `Cmd + K`          | Fungua Menyu ya Kuzindua (Mtaalamu)              |
| `Cmd + ,`          | Fungua Mipangilio                                |
| `Cmd + Shift + M`  | Fungua menyu kuu                                 |
| `Cmd + Shift + T`  | Zunguka mandhari (chaguomsingi / giza)           |
| `Cmd + Shift + U`  | Fungua mchague hali ya mtumiaji                  |
| `Escape`           | Ondoa kidude / funga boksi                       |

## Njia za mkato za Msomaji wa Biblia

Hizi zinafanya kazi katika **Msomaji wa Kujifunza** na **Msomaji wa Umakini** zote mbili.

| Njia ya Mkato      | Kitodo                                                          |
| ------------------ | --------------------------------------------------------------- |
| `← Mshale Kushoto`  | Sura iliyopita                                                  |
| `→ Mshale Kulia`    | Sura inayofuata                                                 |
| `Cmd + R`          | Badili kati ya Msomaji wa Kujifunza na Umakini (Kawaida na Mtaalamu) |
| `Cmd + Option + V` | Fungua mchague toleo                                            |
| `Cmd + Option + B` | Fungua mchague kitabu                                           |
| `Cmd + Option + C` | Fungua mchague sura                                             |
| `Cmd + T`          | Badili TTS (simama ikiwa inacheza/imesimama, anza ikiwa tulivu) |
| `Cmd + Option + T` | Cheza / Sitisha TTS                                             |

## Msomaji wa Kujifunza pekee

| Njia ya Mkato      | Kitendo                                                                 |
| ------------------ | ----------------------------------------------------------------------- |
| `↑ Mshale Juu`     | Chagua aya iliyotangulia                                                |
| `↓ Mshale Chini`   | Chagua aya inayofuata                                                   |
| `Cmd + ↑`          | Chagua aya ya kwanza                                                    |
| `Cmd + ↓`          | Chagua aya ya mwisho                                                    |
| `Cmd + ←`          | Ruka sura ya 1                                                          |
| `Cmd + →`          | Ruka sura ya mwisho                                                     |
| `Cmd + 0`–`9`      | Ruka aya moja kwa moja (andika tarakimu, kwa mfano `Cmd + 1` `Cmd + 6` kwa aya 16) |
| `Cmd + P`          | Badili Biblia Sambamba (Kawaida na Mtaalamu)                            |
| `Cmd + B`          | Weka alamisho kwenye aya iliyochaguliwa (Kawaida na Mtaalamu)           |
| `Cmd + H`          | Weka rangi kwenye aya iliyochaguliwa (Kawaida na Mtaalamu)              |
| `Cmd + N`          | Ongeza maoni kwa aya iliyochaguliwa (Kawaida na Mtaalamu)               |
| `Cmd + C`          | Linganisha tafsiri za aya iliyochaguliwa (Kawaida na Mtaalamu)          |
| `Cmd + X`          | Fungua marejeleo ya aya iliyochaguliwa (Kawaida na Mtaalamu)            |
| `Cmd + I`          | Fungua taarifa ya neno (Mtaalamu)                                       |
| `Cmd + D`          | Fungua kamusi kwa aya iliyochaguliwa (Mtaalamu)                         |
| `Cmd + A`          | Fungua boksi la AI kwa aya iliyochaguliwa (Mtaalamu)                    |
| `Cmd + Option + S` | Badili vichwa-ndogo                                                     |
| `Cmd + Option + W` | Funga maboksi yote ya kujifunza yaliyofunguliwa                         |
| `Cmd + Option + M` | Fungua menyu ya vitendo ya aya                                          |

## Msomaji wa Umakini pekee

| Njia ya Mkato   | Kitendo         |
| --------------- | --------------- |
| `↑ Mshale Juu`   | Sugua juu       |
| `↓ Mshale Chini` | Sugua chini     |
| `Cmd + ↑`       | Sugua hadi juu  |
| `Cmd + ↓`       | Sugua hadi chini |
| `Cmd + =`       | Kuza ndani      |
| `Cmd + -`       | Kuza nje        |

## Utafutaji

| Njia ya Mkato      | Kitendo                                  |
| ------------------ | ---------------------------------------- |
| `Return`           | Tekeleza utafutaji                       |
| `Cmd + Return`     | Futa utafutaji na uweke mkazo kwenye ingizo |
| `Cmd + ↑`          | Sugua matokeo juu                        |
| `Cmd + ↓`          | Sugua matokeo chini                      |
| `Cmd + Option + A` | Chagua vipengele vyote vya wigo          |
| `Cmd + Option + C` | Ondoa uteuzi wa vipengele vyote vya wigo |
| `Cmd + Option + B` | Hali ya utafutaji wa Biblia              |
| `Cmd + Option + O` | Hali ya utafutaji wa kitabu              |
| `Cmd + Option + D` | Hali ya utafutaji wa kamusi (Mtaalamu)   |
| `Cmd + Option + X` | Hali ya utafutaji wa kamusi ya asili (Mtaalamu) |

## Matokeo ya Utafutaji

| Njia ya Mkato | Kitendo                    |
| ------------- | -------------------------- |
| `Cmd + S`     | Fungua laha la kuhifadhi-yote |
| `Cmd + ↑`     | Sugua matokeo juu          |
| `Cmd + ↓`     | Sugua matokeo chini        |

## Msomaji wa Vitabu

| Njia ya Mkato      | Kitendo                  |
| ------------------ | ------------------------ |
| `← Mshale Kushoto`  | Sura iliyopita           |
| `→ Mshale Kulia`    | Sura inayofuata          |
| `Cmd + ↑`          | Sura iliyopita           |
| `Cmd + ↓`          | Sura inayofuata          |
| `↑ Mshale Juu`     | Sugua juu                |
| `↓ Mshale Chini`   | Sugua chini              |
| `Cmd + B`          | Weka alamisho kwenye sura ya sasa |
| `Cmd + J`          | Fungua mchague sura      |
| `Cmd + L`          | Fungua mchague sauti     |
| `Cmd + T`          | Badili TTS               |
| `Cmd + Option + T` | Cheza / Sitisha TTS      |

## Msomaji wa Ibada

| Njia ya Mkato      | Kitendo             |
| ------------------ | ------------------- |
| `← Mshale Kushoto`  | Siku iliyopita      |
| `→ Mshale Kulia`    | Siku inayofuata     |
| `↑ Mshale Juu`     | Sugua juu           |
| `↓ Mshale Chini`   | Sugua chini         |
| `Cmd + ↑`          | Sugua juu (kwa wingi) |
| `Cmd + ↓`          | Sugua chini (kwa wingi) |
| `Cmd + D`          | Fungua mchague tarehe |
| `Cmd + T`          | Badili TTS          |
| `Cmd + Option + T` | Cheza / Sitisha TTS |

## Mazungumzo ya AI

| Njia ya Mkato      | Kitendo                          |
| ------------------ | -------------------------------- |
| `Cmd + Return`     | Tuma ujumbe                      |
| `Cmd + N`          | Mazungumzo mapya                 |
| `Cmd + D`          | Badili droo ya mazungumzo        |
| `Cmd + Option + C` | Futa mazungumzo ya sasa          |
| `Cmd + S`          | Fungua menyu ya kuhifadhi        |
| `Escape`           | Funga droo / menyu               |

## Alamisho

| Njia ya Mkato                  | Kitendo                                    |
| ------------------------------ | ------------------------------------------ |
| `↑ Mshale Juu` / `↓ Mshale Chini` | Chagua alamisho                          |
| `Return`                       | Fungua alamisho (baobabu: chagua)          |
| `Cmd + R`                      | Soma alamisho katika muktadha wake         |
| `Cmd + M`                      | Hamishia alamisho iliyochaguliwa kwenye folda |
| `Cmd + N`                      | Dhibiti folda                              |
| `Escape`                       | Funga boksi la maelezo / mchague folda     |

Katika mchague wa **Hifadhi kwenye Folda**, `↑ Mshale Juu` / `↓ Mshale Chini` husogeza uteuzi, `Return` hubadili folda iliyochaguliwa au huwasha kitendo kilichoashirwa, na `Escape` hunifunga mchague. Safu ya **+ Tengeneza Folda** iko juu ya orodha.

## Maoni ya Biblia

| Njia ya Mkato                  | Kitendo                |
| ------------------------------ | ---------------------- |
| `↑ Mshale Juu` / `↓ Mshale Chini` | Chagua maoni        |
| `Return`                       | Fungua maoni           |
| `Cmd + Return`                 | Weka mkazo kwenye ingizo la kichujio |
| `Escape`                       | Funga maelezo / kihariri |

## Rangi

| Njia ya Mkato                  | Kitendo            |
| ------------------------------ | ------------------ |
| `↑ Mshale Juu` / `↓ Mshale Chini` | Chagua rangi     |
| `Return`                       | Fungua rangi       |
| `Cmd + Return`                 | Weka mkazo kwenye ingizo la kichujio |
| `Escape`                       | Funga boksi la maelezo |

## Orodha ya Biblia

| Njia ya Mkato                            | Kitendo                              |
| ---------------------------------------- | ------------------------------------ |
| `Tab` / `→ Mshale Kulia` / `↓ Mshale Chini` | Biblia inayofuata                 |
| `← Mshale Kushoto` / `↑ Mshale Juu`      | Biblia iliyotangulia                 |
| `Return`                                 | Fungua Biblia yenye mkazo            |
| `Cmd + Shift + S`                        | Badili kipendwa kwa Biblia yenye mkazo |
| `Escape`                                 | Rudi nyuma                           |

## Skrini ya Vitabu vya Biblia

| Njia ya Mkato           | Kitendo                       |
| ----------------------- | ----------------------------- |
| `Tab` / `→ Mshale Kulia` | Kitabu inayofuata            |
| `← Mshale Kushoto`      | Kitabu kilichotangulia        |
| `↓ Mshale Chini`        | Kitabu chini katika gridi     |
| `↑ Mshale Juu`          | Kitabu juu katika gridi       |
| `Cmd + ↓`               | Sehemu inayofuata (AT / NT)   |
| `Cmd + ↑`               | Sehemu iliyotangulia (AT / NT) |
| `Return`                | Fungua kitabu chenye mkazo    |
| `Escape`                | Rudi nyuma                    |

## Orodha ya Vitabu

| Njia ya Mkato                            | Kitendo            |
| ---------------------------------------- | ------------------- |
| `Tab` / `→ Mshale Kulia` / `↓ Mshale Chini` | Kitabu inayofuata |
| `← Mshale Kushoto` / `↑ Mshale Juu`      | Kitabu kilichotangulia |
| `Return`                                 | Fungua kitabu chenye mkazo |
| `Escape`                                 | Rudi nyuma          |

## Skrini ya Sura za Biblia

| Njia ya Mkato                            | Kitendo               |
| ---------------------------------------- | --------------------- |
| `Tab` / `→ Mshale Kulia` / `↓ Mshale Chini` | Sura inayofuata    |
| `← Mshale Kushoto` / `↑ Mshale Juu`      | Sura iliyotangulia    |
| `Return`                                 | Fungua sura yenye mkazo |
| `Escape`                                 | Rudi nyuma            |

## Skrini ya Sura za Kitabu

| Njia ya Mkato          | Kitendo                       |
| ---------------------- | ----------------------------- |
| `Tab` / `↓ Mshale Chini` | Sura inayofuata             |
| `↑ Mshale Juu`         | Sura iliyotangulia            |
| `Return`               | Fungua sura yenye mkazo       |
| `Cmd + Return`         | Weka mkazo kwenye ingizo la utafutaji/kichujio |
| `Escape`               | Rudi nyuma                    |

## Orodha ya Ibada

| Njia ya Mkato                            | Kitendo                  |
| ---------------------------------------- | ------------------------ |
| `Tab` / `→ Mshale Kulia` / `↓ Mshale Chini` | Ibada inayofuata      |
| `← Mshale Kushoto` / `↑ Mshale Juu`      | Ibada iliyotangulia      |
| `Return`                                 | Fungua ibada yenye mkazo |
| `Escape`                                 | Rudi nyuma               |

## Menyu kuu (ikiwa wazi)

| Njia ya Mkato  | Kitendo                       |
| -------------- | ----------------------------- |
| `↑ Mshale Juu` | Kipengele cha menyu kilichotangulia |
| `↓ Mshale Chini` | Kipengele cha menyu kinachofuata |
| `Return`       | Chague kipengele kilichoashirwa |
| `Escape`       | Funga menyu                   |

## Mipangilio

| Njia ya Mkato | Kitendo                     |
| ------------- | --------------------------- |
| `Escape`      | Funga kidude / mchague uliofunguliwa |

## Madude ya Kihariri

| Njia ya Mkato | Kitendo           |
| ------------- | ----------------- |
| `Cmd + S`     | Hifadhi           |
| `Escape`      | Ghairi / funga    |

## Kizuizi cha kuandika

Ukiwa na mkazo kwenye uga wa maandiko (sanduku la utafutaji, kihariri cha maoni, ingizo la AI), njia za mkato zisizo-na-Cmd kama mishale na `Space` zinazuiwa isizoanze kutembea kwa bahati mbaya. Njia za mkato zinazotumia kitufe cha `Cmd` (kama `Cmd + S`, `Cmd + B`) bado zinafanya kazi unapoandika.
