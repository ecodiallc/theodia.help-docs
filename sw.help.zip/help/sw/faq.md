---
title: Maswali Yanayoulizwa Mara Nyingi
level: everyday
categories: faq
summary: Majibu ya maswali ya kawaida zaidi kuhusu kutumia Theodia.
---

# Maswali Yanayoulizwa Mara Nyingi

## Theodia inagharimu nini?

Theodia ni ununuzi wa mara moja. Hakuna usajili, hakuna matangazo, hakuna ununuzi ndani ya programu, na hakuna maombi ya michango. Nyenzo zote za nyongeza zinazopatikana katika katalogi ni bure kupakua baada ya kununua programu.

## Nahitaji uunganisho wa intaneti?

Hapana. Programu na faili zake za takwimu zikisakinishwa, kila kitu kinafanya kazi bila mtandao. Unaweza kusoma, kutafuta, kuweka rangi, kuandika maoni, na kutumia zana nyingi za kujifunza bila ishara.

Kipengele pekee kinachohitaji intaneti ni kupakua nyenzo mpya.

## Takwimu zangu zimehifadhiwa wapi?

Alamisho, rangi, maoni, na mipangilio yako yote yamehifadhiwa kwenye kifaa chako. Hayapakiwa kwenye seva yoyote.

Unaweza kuzihifadhi nakala kwa mkono. Ona mwongozo wa [Kuhifadhi Nakala za Takwimu Zako](theodia://help/backups) kwa namna.

## Naweza kusikiliza Biblia kwa sauti?

Ndiyo. Fungua sura yoyote, bonyeza menyu, na chague chaguo la kusoma-kwa-sauti. Kifaa chako lazima kiwe na sauti ya kusoma maandiko (TTS) iliyosakinishwa. Ona mwongozo wa [Kusoma kwa Sauti](theodia://help/tts) kwa zaidi.

## Namna gani natagaza aya?

Unaweza kuandika marejeleo kama `John 3:16` katika Amri ya ukurasa wa nyumbani, au kutumia kichupo cha **Utafutaji** kutafuta kwa neno au msemo.

## Namna gani naripoti hitilafu au napendekeza kipengele?

Bonyeza **Tuma Pendekezo / Suala** kwenye skrini ya Kuhusu, [iripoti kwenye GitHub](https://github.com/ecodiallc/theodia.app/issues/new), au tembelea ukurasa wa [Mijadala ya GitHub](https://github.com/ecodiallc/theodia.app/discussions).

## Vifaa gani vinaungwa mkono?

Theodia inafanya kazi kwenye iPhone, iPad, na simu na tablet za Android. Inafanya kazi vizuri zaidi kwenye vifaa vyenye nafasi ya bure ya angalau 2 GB kwa faili za msingi za takwimu.

## Naweza kutumia kibodi ya nje?

Ndiyo. Theodia inaunga mkono kibodi za Bluetooth na USB kwenye iPad. Kutembea, utafutaji, na vipengele vingi vya kusoma vina njia za mkato za kibodi. Ona mwongozo wa [Njia za Mkato za Kibodi ya Nje](theodia://help/external-keyboard-shortcuts) kwa orodha kamili.

## Lugha gani zinaungwa mkono?

Kiolesura cha programu kinapatikana katika Kiingereza, Kiarabu, Kichina (Rahisi na cha Mapokeo), Kicheki, Kideni, Kiholanzi, Kifilipino, Kifaransa, Kijerumani, Kigiriki, Kiebrania, Kihindi, Kiindonesia, Kiitaliano, Kijapani, Kikorea, Kipolandi, Kireno (Brazil), Kiromania, Kirusi, Kihispania, Kiswahili, Kiswidi, Kithai, Kituruki, Kiukraini, na Kivietinamu.

Lugha ya maandiko ya Biblia inategemea tafsiri ulizosakinisha.

## Namna gani nabadilisha lugha?

Nenda **Mipangilio** na utafute chaguo la lugha.

## Swali langu halipo hapa. Nawezaje kupata msaada zaidi?

Tembelea miongozo mingine ya msaada kwa mada, au uliza swali katika jumuiya ya [Mijadala ya GitHub](https://github.com/ecodiallc/theodia.app/discussions).

Kidokezo: Kwenye skrini kuu ya **Msaada＆Miongozo**, tumia sanduku la utafutaji kuandika mada kama `notifications` au `search` kupata mwongozo unaolingana.
