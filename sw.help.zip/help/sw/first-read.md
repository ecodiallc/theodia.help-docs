---
title: Kusoma Sura Yako ya Kwanza
level: beginner
categories: [start, read]
summary: Maelezo ya hatua kwa hatua ya kufungua na kusoma sura.
---

# Kusoma Sura Yako ya Kwanza

Mwongozo huu unakupeleka hatua kwa hatua katika kufungua sura kwa mara ya kwanza kabisa.

## Hatua ya 1: Fungua kichupo cha Biblia

Angalia chini ya skrini. Utaona mstari wa vichupo. Bonyeza kile kinachosema **Biblia**.

## Hatua ya 2: Chagua kitabu

Utaona orodha ya vitabu vya Biblia. Mwanzo ni cha kwanza. Yohane iko karibu na katikati. Ufunuo ni cha mwisho.

Bonyeza jina la kitabu unachotaka.

## Hatua ya 3: Chagua sura

Utaona namba 1 hadi idadi ya sura za kitabu hicho. Bonyeza sura unayotaka.

Sura inafunguka. Aya ziko kwenye skrini.

## Hatua ya 4: Tembea

- Vuta kidole **kushoto** kwenda sura inayofuata.
- Vuta kidole **kulia** kurudi nyuma.

## Hatua ya 5: Tumia aya

Uliceza na aya kutegemea hali yako ya mtumiaji.

### Hali ya Msomaji

Hali ya Msomaji ni safi na bila vitu vinavyovuruga.

- Bonyeza aya kuionyeka kwa muda mfupi.
- Hakuna zana za kujifunza, alamisho, au menyu.
- Ukitaka vipengele zaidi, badili kwenda **Kawaida** au **Mtaalamu** katika **Mipangilio**.

### Hali ya Kawaida

Hali ya Kawaida inaongeza vipengele vya kila siku kwa kujifunza Biblia binafsi.

Bonyeza aya kufungua menyu yenye chaguzi hizi:

- **Weka alamisho** kwenye aya.
- **Weka rangi** kwenye aya.
- **Ongeza maoni** kwenye aya.
- **Nakili** maandiko ya aya.
- **Linganisha** aya katika tafsiri nyingine.
- **Tafuta marejeleo** ya aya.

### Hali ya Mtaalamu

Hali ya Mtaalamu inafungua kila zana ya kujifunza Biblia kwa undani.

Bonyeza aya kufungua menyu yenye kila kitu cha Hali ya Kawaida, pamoja na:

- **Mafafani** ya aya.
- **Taarifa ya Neno** na utafutaji wa lugha asilia.
- **Kamusi** ya maana.
- **Msaidizi wa AI** kwa kujifunza zaidi.

Unaweza kubadilisha hali wakati wowote katika **Mipangilio**.

## Unahitaji msaada na zana mahususi?

Kila zana ina mwongozo wake. Bonyeza **Msaada** kwenye ukurasa wa nyumbani kuona vyote. Mwongozo wa [Hali ya Kujifunza](theodia://help/study-mode) ni pa kuanzia zuri — unapita katika kila zana ya menyu ya aya.

Ukiwa unajifunza bado kuhusu mahali vitu vilipo, ona mwongozo wa [Mpangilio wa Programu na Kutembea](theodia://help/navigating-the-app). Unaonyesha ukurasa wa nyumbani, menyu kuu, na ukanda wa chini.

## Unataka nyenzo zaidi?

Programu inakuja na tafsiri kadhaa za Biblia zinazopatikana bure. Ukitaka kuongeza zaidi, au kuongeza mafafani, vitabu, au ibada, ona mwongozo wa [Kupata Nyenzo za Nyongeza kutoka GitHub](theodia://help/getting-core-files). Unaonyesha wapi kupata na namna ya kuongeza.
