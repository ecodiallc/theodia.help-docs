---
title: Hali ya Umakini
level: beginner
categories: [layout, read]
summary: Njia safi, bila vitu vinavyovuruga, ya kusoma vipande virefu.
---

# Hali ya Umakini

> **Hali:** Hali ya Umakini ndiyo msomaji katika hali ya **Msomaji**. Pia inapatikana katika hali za **Kawaida** na **Mtaalamu** kama badala ya Hali ya Kujifunza. Unaweza kubadilisha hali katika **Mipangilio** → **Hali ya Mtumiaji wa Programu**.

Hali ya Umakini ni njia ya kusoma sura ya Biblia bila vitufe au menyu njiani. Ni nzuri kwa vipindi virefu vya kusoma.

## Namna ya kuiwasha

1. Fungua sura yoyote.
2. Katika mstari wa ikoni juu ya skrini, bonyeza kitufe cha 📖. Kinafungua sura hiyo hiyo katika Hali ya Umakini.
3. Menyu na vitufe hufichwa. Maandiko ya Biblia pekee yanabaki.

Katika hali ya **Msomaji**, sura hufunguka katika Hali ya Umakini yenyewe. Kitufe cha 📖 kimefichwa kwa sababu hakuna Hali ya Kujifunza ya kubadilisha kwenda.

## Unachoweza kufanya katika Hali ya Umakini

- **Sugua** kusoma.
- **Vuta kidole** kwenda sura inayofuata au iliyopita.
- **Bonyeza kitufe cha 📖** katika ukanda wa chini kubadili kurudi Hali ya Kujifunza. (Kimefichwa katika hali ya Msomaji.)
- **Bonyeza kitufe cha 🔊** katika ukanda wa chini kusoma sura kwa sauti. Ukanda mdogo wa udhibiti unaonekana wenye kucheza, kupumzisha, kurudisha, kuharakisha, na kichagua sauti. (Kimefichwa katika hali ya Msomaji — TTS inahitaji Kawaida au Mtaalamu.)

## Matumizi mazuri ya Hali ya Umakini

- Kusoma kitabu chote, sura moja kwa wakati mmoja.
- Kusoma kipande kirefu kwa ibada au wakati wa utulivu.
- Kusoma kwa sauti na kufuatilia bila vitu vinavyovuruga.

## Kubadili kwenda Hali ya Kujifunza

Hali ya Umakini inaficha kila zana ya kujifunza, lakini bado ni mbali ya bonyeza moja. Bonyeza kitufe cha 📖 juu ya skrini kufungua sura hiyo hiyo katika [Hali ya Kujifunza](theodia://help/study-mode). Hali ya Kujifunza ni msomaji kamili, wenye mafafani, marejeleo, utafutaji wa kamusi ya asili, na maoni. Kujifunza kile Hali ya Kujifunza inachoweza, ona mwongozo wa [Hali ya Kujifunza](theodia://help/study-mode).

Katika hali ya **Msomaji**, kitufe cha 📖 kimefichwa kwa sababu Hali ya Kujifunza haipatikani.
