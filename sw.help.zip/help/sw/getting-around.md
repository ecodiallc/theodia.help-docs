---
title: Kutembea Haraka
level: beginner
categories: layout
summary: Njia zote za haraka za kuruka aya, sura, au skrini katika Theodia.
---

# Kutembea Haraka

Mwongozo huu ni karatasi ya marejeleo ya kutembea. Inashughulikia njia zote za haraka za kwenda mahali ulipo kwenda mahali unapotaka.

## Ruka moja kwa moja kwenye aya

Njia ya haraka zaidi ya kufungua aya yoyote ni **Amri** kwenye ukurasa wa nyumbani.

- Andika `John 3:16` kisha bonyeza Go.
- Andika `Psalms 23` kisha bonyeza Go.
- Andika `Genesis 1` kisha bonyeza Go.

Programu inafungua sura kamili (na kusogeza kwenye aya ukiweka moja).

## Vuta kidole kati ya sura

Unaposoma sura:

- **Vuta kidole kushoto** → sura inayofuata.
- **Vuta kidole kulia** → sura iliyopita.

Hii inafanya kazi kote vitabuni. Baada ya Kitabu cha Kutoka sura ya 40, kuvuta kidole kushoto kunakupeleka Mambo ya Walivu 1.

## Tumia ukanda wa juu

Unaposoma, juu ya skrini inaonyesha **tafsiri**, **kitabu**, na **sura** ya sasa.

- Bonyeza jina la tafsiri kubadilisha Biblia.
- Bonyeza jina la kitabu kuchagua kitabu kingine.
- Bonyeza namba ya sura kuchagua sura nyingine.

## Ruka kutoka kwenye alamisho

Ukiwahi kuhifadhi aya:

1. Fungua kichupo cha **Alamisho**.
2. Bonyeza ingizo lolote.
3. Unakwenda moja kwa moja kwenye aya hiyo.

## Ruka kutoka kwenye utafutaji

1. Fungua kichupo cha **Utafutaji**.
2. Andika neno au msemo.
3. Bonyeza matokeo yoyote.
4. Programu inafungua sura na maneno yako ya utafutaji yakiwa yamewekwa rangi ya njano.

## Badilisha mpangilio wa kusoma

Msomaji wa Biblia una mpangilio mbili:

- **Hali ya Kujifunza (Study Mode)** — inaonyesha sura na zana zote za kujifunza mbali ya bonyeza moja.
- **Hali ya Umakini (Focus Mode)** — inaficha zana zote na menyu, yakibaki maandiko pekee.

Kubadilisha: bonyeza kitufe cha **📖** juu ya skrini unaposoma. Bonyeza tena kurudi. (Hali ya Msomaji inabaki katika Hali ya Umakini daima.)

## Tumia vichupo vya chini

Mstari wa ikoni chini ya skrini unaonekana daima. Bonyeza kichupo chochote kubadilisha sehemu hiyo. Vichupo kamili vinategemea hali yako ya mtumiaji:

**Hali zote:**

- **Nyumbani (Home)** — kurudi kwenye ukurasa wa nyumbani.
- **Biblia (Bibles)** — orodha ya tafsiri.
- **Utafutaji (Search)** — tafuta Biblia, vitabu, kamusi, kamusi za asili, na PDF.
- **Mipangilio (Settings)** — mapendeleo na nyenzo.

**Kawaida na Mtaalamu huona pia:**

- **Alamisho (Bookmarks)** — aya zilizohifadhiwa.
- **Rangi (Highlights)** — aya zilizowekwa rangi.
- **Maoni (Notes)** — maoni yako ya kibinafsi.
- **PDF** — hati zako za PDF zilizoagizwa.

**Mtaalamu huona pia:**

- **AI** — msaidizi wa AI (ikiwa umewashwa katika Mipangilio).

### Kumbuka ulikofika

Kila kichupo kinahifadhi historia yake ya kutembea. Ukirudi kwenye kichupo, unarudi **ulikofika**, sio skrini ya kuanza ya sehemu hiyo.

- Unafungua kichupo cha **Biblia**, unachagua tafsiri, unafungua sura, kisha unabadili kwenda **Utafutaji**. Baadaye unabonyeza **Biblia** tena na uko katika sura hiyo hiyo.
- Unafungua kichupo cha **Alamisho**, unabonyeza aya iliyowekwa alamisho, kisha unabadili kwenda **Mipangilio**. Kubonyeza **Alamisho** tena kunakurudisha kwenye orodha ya alamisho.

Hii inatumiwa na kila kichupo. Kila kimoja kinakumbuka mahali ulipo mpaka ujieleke wewe mwenyewe kwenda skrini tofauti ndani ya kichupo hicho.

### Kinachorejesha kichupo

Kichupo kinarejea skrini yake ya mzizi tu ikiwa:

- Uko katika kichupo hicho tayari na unabonyeza ikoni ya kichupo hicho hicho tena. Hii ni njia ya haraka ya kuirejesha mwanzoni.
- Programu imelazimishwa kufungwa na kufunguliwa tena.

### Vichupo vya chini dhidi ya menyu kuu

- **Vichupo vya chini** — kila kichupo kinahifadhi mkondo wake. Kubonyeza kichupo kunakurudisha ulikofika.
- **Menyu kuu** — kubonyeza kipengele kunakupeleka kwenye skrini hiyo. Ni orodha inayoshuka, sio sahiri juu ya skrini.

Mfano:

- Unasoma Yohane 3. Bonyeza kichupo cha **Alamisho**, kisha bonyeza **Biblia** tena. Unarudi Yohane 3.
- Unasoma Yohane 3. Fungua menyu na bonyeza **Maoni**. Kagua maoni yako, kisha bonyeza kichupo cha **Biblia** kurudi Yohane 3.

## Vidokezo

- Ukurasa wa nyumbani unakumbuka sehemu zipu zilizofunguliwa au kufungwa.
- Kichupo hakipatikani, angalia **hali yako ya mtumiaji** katika **Mipangilio** → **Hali ya Mtumiaji wa Programu**. Hali ya Msomaji inaficha alamisho, rangi, maoni, na AI. Hali ya Kawaida inaficha AI. Huenda ukahitaji kuwasha kipengele katika **Mipangilio** au kusakinisha nyenzo.
