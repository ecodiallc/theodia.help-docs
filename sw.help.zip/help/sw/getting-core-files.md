---
title: Kupata Nyenzo za Nyongeza
level: everyday
categories: resources
summary: Namna ya kuongeza Biblia, mafafani, vitabu, na nyenzo nyingine kwenye Theodia.
---

# Kupata Nyenzo za Nyongeza

Theodia inakuja na baadhi ya nyenzo zilizojengwa ndani, lakini unaweza kuongeza zaidi. Njia rahisi zaidi ni kupitia skrini ya **Dhibiti Nyenzo** ndani ya programu.

## Unachoweza kuongeza

- **Biblia** — tafsiri zaidi katika lugha tofauti
- **Mafafani** — maoni ya kujifunza yanayoeleza aya
- **Vitabu** — vitabu vya kifalsafa ya Kikristo vya kale na vitabu vya marejeleo
- **Ibada** — kusoma kwa ibada ya kila siku
- **Faili za msingi** — faili kubwa za takwimu kama umbolelogia, marejeleo, na Marvel Interlinear Bible (MIB)

## Namna ya kuongeza nyenzo kutoka ndani ya programu

1. Fungua **Mipangilio**.
2. Bonyeza **Dhibiti Nyenzo**.
3. Chagua kichupo: **Msingi (Core)**, **Biblia**, **Mafafani**, **Vitabu**, au **Ibada**.
4. Tembea orodha. Bonyeza nyenzo kusoma zaidi kuhusu yake.
5. Bonyeza sanduku la kuhakiki kuchagua unachotaka.
6. Bonyeza **Pakua** chini. Faili hupakuliwa na kusakinishwa kwa njia yenyewe.

Ikiwasilishwa, nyenzo inaonekana katika programu mara moja. Hauitaji kuanza upya.

## Faili za msingi

Kichupo cha **Msingi (Core)** kina faili kubwa za takwimu zinazowezesha vipengele vya kujifunza vya kina. Hivi ni pamoja na:

- Takwimu za umbolelogia (maumbo ya maneno ya lugha asilia)
- Hifadhidata za marejeleo
- Marvel Interlinear Bible (MIB)

Unahitaji kupakua faili za msingi mara moja tu. Zinabaki kwenye kifaa chako na kufanya kazi bila intaneti.

## Biblia za Kimataifa

Kichupo cha **Biblia za Kimataifa** kina tafsiri za Biblia kutoka makusanyo pana zaidi. Usiponi tafsiri unayotaka katika kichupo kuu cha **Biblia**, angalia hapa.

## Kudhibiti nyenzo zilizosakinishwa

Kwenye skrini kuu ya **Dhibiti Nyenzo** (sio kichupo cha kupakua), unaweza:

- **Kuwasha au kuzima** nyenzo bila kuifuta. Nyenzo zilizozimwa zinabaki kwenye kifaa chako lakini zimefichwa kutoka menyu.
- **Kufuta** nyenzo kupata nafasi. Unaweza kuipakua tena baadaye.

## Kuongeza faili zako mwenyewe

Ukiwa na faili la nyenzo kutoka mahali pengine — rafiki, mradi mwingine, au tovuti — unaweza kuliingiza moja kwa moja:

1. Katika **Dhibiti Nyenzo**, bonyeza **Ingiza Faili la Ndani**.
2. Chagua faili kutoka kwenye kifaa chako.
3. Programu inasoma faili na linaongeza kwenye maktaba yako.

Programu inakubali aina hizi za faili:

- `.bible` — tafsiri za Biblia
- `.commentary` — mafafani
- `.lexicon` — kamusi za asili
- `.book` — vitabu
- `.devotional` — ibada

## Kuunganisha hazina yako ya GitHub

Mtu akipanga hazina ya GitHub yenye nyenzo zinazolingana na Theodia, unaweza kuiongeza kama chanzo cha kipekee:

1. Nenda **Mipangilio → Hazina za GitHub**.
2. Bonyeza **Ongeza Hazina**.
3. Ingiza URL ya GitHub (kwa mfano, `https://github.com/username/repo-name`).
4. Chagua aina zipi za nyenzo hazina ina (Biblia, mafafani, au vitabu).
5. Ihifadhi.
6. Rudi **Dhibiti Nyenzo**. Kichupo kipya kinaonekana chenye nyenzo kutoka hazina hiyo.

Hazina ikiwa ya siri, utahitaji kuongeza **Tokeni ya Ufikiaji ya Binafsi** katika **Mipangilio → Hazina za GitHub** ili programu iisome.

## Taarifa kuhusu ukubwa wa faili

Faili za nyenzo zinaweza kuwa kubwa. Biblia kwa kawaida ni ndogo (megabaiti chache). Mafafani na faili za msingi zinaweza kuwa kubwa zaidi (megabaiti mia moja). Pakua juu ya Wi-Fi inapowezekana.

## Muhtasari

- Tumia **Mipangilio → Dhibiti Nyenzo** kutembea na kusakinisha nyenzo.
- Faili za msingi hufungua zana za kujifunza za kina kama umbolelogia na marejeleo.
- Ingiza faili za ndani ukiwa na zako mwenyewe.
- Ongeza hazina za GitHub za kipekee ukitaka nyenzo kutoka chanzo kingine.
