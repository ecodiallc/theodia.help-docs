---
title: Maswali Yanaulizwa Wapi?
level: everyday
categories: trouble
summary: Namna ya kupata msaada kutoka timu na jumuiya ya Theodia, na namna ya kupata mada za msaada ndani ya programu.
---

# Maswali Yanaulizwa Wapi?

Ukiwa umeshindwa, kuna maeneo machache ya kuomba msaada.

## Kutafuta mada ya msaada

Ukitafuta taarifa kuhusu kipengele mahususi, jaribu moja ya njia hizi:

- **Tembea kwa kundi.** Fungua **Msaada＆Miongozo** na bonyeza kundi kama **Mipangilio＆Ubadilishaji** au **Kutatua Matatizo**. Kila kadi inaorodhesha miongozo inayohusiana.
- **Tafuta kwa neno msingi.** Kwenye skrini kuu ya **Msaada＆Miongozo**, andika neno katika sanduku la utafutaji juu. Kwa mfano, kuandika `notifications` kunaonyesha mwongozo wa [Taarifa na Vikumbusho](theodia://help/notifications); kuandika `search` kunaonyesha mwongozo wa [Kutafuta Biblia](theodia://help/search-the-bible).
- **Angalia Mipangilio kwanza.** Vipengele vingi vimepangwa katika **Mipangilio**. Ukitaka kuweka vikumbusho, fungua **Mipangilio** → **Taarifa**. Skrini ya mipangilio pia ina kiungo cha **Msaada** kwa kila sehemu.

## Ndani ya programu

Fungua skrini ya **Kuhusu**. Utaona vitufe viwili:

- **Tuma Pendekezo / Suala** — hufungua fomu ya kutuma timu swali, wazo, au ripoti ya hitilafu.
- **Mijadala / Maoni** — hufungua ubao wa mijadala ya jumuiya.

## Ukurasa wa GitHub

Unaweza kuona orodha ya masuala yanayojulikana na mabadiliko ya karibuni kwenye [GitHub](https://github.com/ecodiallc/theodia.app).

## Mijadala ya jumuiya

Watu wengine wanaotumia Theodia huuliza maswali na kushiriki vidokezo katika [ubao wa mijadala ya jumuiya](https://github.com/ecodiallc/theodia.app/discussions). Unaweza kusoma mizungumzo ya zamani na kuanzisha mpya.

## Kabla ya kuuliza

Mambo machache hufanya tujibu haraka:

- **Kifaa chako ni nini?** (k.m. iPhone 13, Pixel 7)
- **Toleo gani la programu?** (Fungua **Kuhusu** kuona.)
- **Ulifanya nini?** Maelezo mafupi ya hatua.
- **Kilitokea nini?** Uliona nini kwenye skrini.
- **Uliatarajia kitendo nini?** Hii mara nyingi ni sehemu yenye manufaa zaidi.

## Cha kutarajia

- Kwa ripoti za hitilafu, timu kwa kawaida hujibu ndani ya siku chache.
- Kwa mawazo, timu hujisoma yote. Hatuwezi kuahini lini wazo litajumuishwa.
- Kwa maswali ya jumuiya, watumiaji wengine mara nyingi hujibu haraka kuliko timu.

## Taarifa kuhusu faragha

Ukituma swali, tafadhali usijumuishe taarifa za faragha. Timu inaweza kuona unachotuma.
