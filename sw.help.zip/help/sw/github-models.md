---
title: Mifano ya GitHub
categories: ai
level: advanced
summary: Weka Mifano ya GitHub — njia huru ya kuanza kuchunguza AI katika Theodia bila usajili wa API uliopo.
---

# Mifano ya GitHub

> **Hali:** Msaidizi wa AI unahitaji hali ya **Mtaalamu**. Unaweza kubadilisha hali katika **Mipangilio** → **Hali ya Mtumiaji wa Programu**.

Hujali gharama ya huduma ya AI, **Mifano ya GitHub** ni njia rahisi zaidi ya kuanza kuchunguza AI ya Theodia. Inaruhusu njia huru ya kuanza, na unachohitaji ni akaunti huru ya GitHub tu.

## Mifano ya GitHub ni nini?

Mifano ya GitHub ni huduma kutoka GitHub inayokuruhusu kuendesha mifano ya kisasa ya AI kupitia API. Inaunga mkono umbiza huo huo wa OpenAI, hivyo inafanya kazi kwa undani na Theodia.

## Kwa nini kuchagua Mifano ya GitHub?

- **Hakuna kadi ya mkopo inayohitajika** — Akaunti ya GitHub tu.
- **Mifano ya ubora wa juu** — Unapata ufikiaji wa GPT-4o, GPT-4.1, na mifano nyingine ya kuaminika inayounga mkono zana za Theodia.
- **Kuweka kwa urahisi** — Tokeni moja, URL moja, na umemaliza.

## Hatua ya 1: Tengeneza akaunti ya GitHub

Ukiwa na akaunti ya GitHub tayari, ruka mpaka Hatua ya 2.

1. Nenda [github.com](https://github.com).
2. Bonyeza **Jiandikishe (Sign up)** na ufuate maombi kutengeneza akaunti huru.
3. Thibitisha barua pepe yako GitHub akituma uthibitisho.

## Hatua ya 2: Tengeneza Tokeni ya Ufikiaji ya Binafsi

Tokeni hii ni ufunguo wako wa API. Inamwambia GitHub ni nani wewe Theodia ikituma maswali.

1. Nenda [github.com/settings/tokens](https://github.com/settings/tokens).
2. Bonyeza **Tengeneza tokeni mpya (Generate new token)** na uchague **Tengeneza tokeni mpya (kimapokeo)**.
3. Pa tokeni jina kama **Theodia AI**.
4. Chini ya **Chagua wigo (Select scopes)**, hakiki sanduku la **`models:read`**.
   - Hii ndiyo ruhusa pekee Theodia inayohitaji.
5. Sugua hadi chini na ubonyeze **Tengeneza tokeni (Generate token)**.
6. **Nakili tokeni mara moja.** GitHub itaonyesha mara moja tu. Iweke mahali salama (kama programu ya madokezo ya simu yako) mpaka uiweke Theodiani.

## Hatua ya 3: Chagua mfano

Mifano ya GitHub inatoa mifano kadhaa. Kwa Theodia, hizi ni chaguo bora:

| Mfano                  | Kikomo huru cha Siku | Bora Kwa                                          |
| ---------------------- | -------------------- | ------------------------------------------------- |
| `openai/gpt-4.1-nano`  | 150 maombi / siku    | Maswali ya haraka na maelezo rahisi ya aya        |
| `openai/gpt-4.1-mini`  | 150 maombi / siku    | Kujifunza kwa jumla yenye msaada mzuri wa zana    |
| `openai/gpt-4.1`       | 50 maombi / siku     | Kujifunza kwa kina na maswali ya hatua-nyingi     |
| `openai/gpt-4o`        | 50 maombi / siku     | Cha matumizi mengi, msaada mkali wa zana          |

Anza na **`openai/gpt-4.1-mini`** — ni wa haraka, wa kuaminika, na hutoa kikomo cha juu cha maombi ya kila siku.

## Hatua ya 4: Pangusa Theodia

1. Fungua **Theodia**.
2. Nenda **Mipangilio** → **Msaidizi wa AI**.
3. Hakikisha **Mfano wa mbali** umeteuliwa.
4. Bonyeza kidhibiti-sondli cha **Mtoa Huduma** na uchague **Mifano ya GitHub**.
   - Mifano ya GitHub haipo katika orodha, bonyeza **Kipekee (Custom)** na uingize URL ya msingi kwa mkono: `https://models.github.ai`
5. Weka tokeni yako ya Ufikiaji ya Binafsi ya GitHub katika uga wa **Ufunguo wa API**.
6. Ingiza ID ya mfano uliochagua katika uga wa **Mfano (Model)** (kwa mfano: `openai/gpt-4.1-mini`).
7. Bonyeza **Pima uunganisho**.
8. Subiri ukaguzi kukamilika. Unapaswa kuona:
   - **✓ Uunganisho umefanikiwa**
   - **✓ Zana zinaunga mkono**

Ukiona **✗ Zana hazinaunga mkono**, jaribu ID tofauti ya mfano kutoka jedwali hapo juu.

## Hatua ya 5: Anza mazungumza

1. Bonyeza kichupo cha **AI** chini ya skrini.
2. Andika swali na ubonyeze **Tuma**.
3. Au, unaposoma sura yoyote ya Biblia, bonyeza namba ya aya na chague **Mafafani ya AI** kuanza mazungumzo maalum ya aya.

## Kutatua matatizo

### "Uunganisho umeshindikana" au "HTTP 401"

- Hakikisha ulinakili tokeni **nzima**. Ni mnyororo mrefu unaoanza kwa `ghp_`.
- Tokeni zinaisha kama hazikutumiwa muda mrefu. Rudi GitHub na utengeneze mpya.
- Hakikisha uliteua **models:read** ukitengeneza tokeni.

### "Zana hazinaunga mkono"

- Baadhi ya mifano katika Mifano ya GitHub haikubali mialiko ya zana. Jaribu **`openai/gpt-4o`** au **`openai/gpt-4.1-mini`** badala yake.
- Hakikisha ID ya mfano imetahajiriwa kama imesekwa, ikiwemo kiambishi cha `openai/`.

### Makosa ya kikomo cha kasi

- Ukifika kikomoni cha kila siku, badili kwenda mfano yenye kibali kikubwa (kama `openai/gpt-4.1-nano` kwenye maombi 150 kwa siku).
- Vikomo vinarejea kila saa 24.

## Muhtasari

- Mifano ya GitHub ni **njia iliyoaguliwa ya kuanza kuchunguza AI** katika Theodia.
- Unahitaji **akaunti huru ya GitHub** na **Tokeni ya Ufikiaji ya Binafsi** yenye `models:read`.
- Mfano bora wa kuanzia ni **`openai/gpt-4.1-mini`**.
- Ingiza tokeni na mfano katika **Mipangilio → Msaidizi wa AI**, bonyeza **Pima uunganisho**, na uanze mazungumza.
