---
title: Kuweka Rangi kwenye Aya
level: everyday
categories: [annotate, read]
summary: Namna ya kuweka rangi kwenye aya na kuzipata baadaye.
---

# Kuweka Rangi kwenye Aya

> **Hali:** Rangi zinapatikana katika hali za **Kawaida** na **Mtaalamu**. Hali ya Umakini ni kwa kusoma safi, bila vitu vinavyovuruga, pekee. Unaweza kubadilisha hali katika **Mipangilio** → **Hali ya Mtumiaji wa Programu**.

Kuweka rangi kunaashiria aya kwa rangi. Inafanya kama penya la rangi ya njano juu ya karatasi. Aya inabaki ikiwa imewekwa rangi ukifungua tena.

## Namna ya kuweka rangi kwenye aya

1. Fungua aya.
2. Bonyeza aya kuleta menyu.
3. Bonyeza ikoni ya **Rangi**.
4. Chagua rangi.

Aya sasa imewekwa rangi hiyo.

## Namna ya kubadilisha rangi ya aya

1. Fungua aya.
2. Bonyeza aya, kisha bonyeza ikoni ya **Rangi**.
3. Chagua rangi mpya.

## Namna ya kuondoa rangi

1. Fungua aya.
2. Bonyeza aya, kisha bonyeza **Rangi** katika menyu.
3. Bonyeza **Ondoa Rangi** chini ya kichagua rangi.

## Njia ya kawaida ya kutumia rangi

Wasomaji wengi hutumia seti ndogo ya rangi kwa malengo machache:

- **Njano** kwa vipendwa vya kawaida.
- **Kijani** kwa aya zinazohusu Mungu.
- **Bluu** kwa aya zinazohusu maombi.
- **Waridi** kwa aya zinazohusu faraja.
- **Rangi ya machungwa** kwa aya zinazohusu onyo au usahihishi.
- **Zambarau** kwa aya zinazohusu unabii au siku za mwisho.

Chagua mfumo unaojifaa wewe.

## Namna ya kuona rangi zako zote

Bonyeza kichupo cha **Rangi** chini. Unaona orodha ya kila aya uliyoweka rangi, mpya zaidi kwanza. Kuna mstari wa vipande vya rangi juu — bonyeza rangi kuonyesha rangi za aya wa rangi hiyo tu, au bonyeza **Zote** kuondoa chujio.

## Kuingiza rangi

Unaweza kuleta rangi Theodiani kutoka programu na faili nyingine.

Nenda **Mipangilio** → **Alamisho** → **Ingiza Rangi**. Chagua **Ingiza kutoka Faili** au weka nakala kutoka ubaoni. Programu inatambua umbiza kwa njia yenyewe.

### Umbiza zinazotumika

**Kutolewa kwa JSON asilia** — Umbiza unatumika na kipengele cha kutolewa cha Theodia yenyewe:

```json
{
  "/bible/KJV/John/3#v3_16": "yellow",
  "/bible/KJV/Genesis/1#v1_1": "green"
}
```

**CSV** — Karatasi ya kuhesabu yenye safu wima za `url` na `color`. Mfano:

```csv
url,color
/bible/KJV/John/3#v3_16,yellow
/bible/KJV/Genesis/1#v1_1,green
```

**Maandiko wazi** — Kila mstari ni marejeleo ya Biblia au URL, ikifuatiwa kwa hiari na jina la rangi. Mfano:

```
John 3:16 yellow
Genesis 1:1 green
Matthew 5:1
```

- Rangi zinazopatikana: `yellow`, `green`, `blue`, `pink`, `orange`, `purple`.
- Rangi haipewi, rangi ya aya huwa njano kwa chaguomsingi.
- Mistari inayoanza kwa `#` au `//` inachukuliwa kama maoni na kurukwa.

## Vidokezo

- Rangi zinabaki kwenye kifaa chako. Hazitumiwi wingu.
- Unaweza kuweka rangi kwenye aya katika tafsiri moja na ionekane katika tafsiri zako nyingine za aya hiyo hiyo.
- Ona mwongozo wa [Kuhifadhi Nakala za Takwimu Zako](theodia://help/backups) kuzihifadhi salama.
