---
title: Kusakinisha Tafsiri za Biblia
level: beginner
categories: start
summary: Namna ya kuongeza tafsiri ya Biblia kwenye maktaba yako.
---

# Kusakinisha Tafsiri za Biblia

Theodia inakuja na tafsiri chache za Biblia tayari kusoma. Unaweza kuongeza zaidi wakati wowote. "Tafsiri" ni toleo tofauti la maandiko ya Biblia, kama King James Version.

## Namna ya kuongeza tafsiri

Kichupo cha Biblia kinaonyesha orodha ya tafsiri zilizosakinishwa tayari. Kuongeza zaidi, fungua mdhibiti wa nyenzo:

1. Fungua **Mipangilio**.
2. Bonyeza **Dhibiti Nyenzo**.
3. Bonyeza **Sakinisha kutoka GitHub**.
4. Katika kidude cha kupakua, bonyeza kichupo cha **Biblia**.
5. Bonyeza sanduku la kuhakiki pembeni ya kila tafsiri unayotaka.
6. Bonyeza **Sakinisha Zilizochaguliwa** chini.
7. Subiri kupakua kukamilike.

Tafsiri sasa iko katika maktaba yako. Kuiona, fungua kichupo cha **Biblia**.

## Namna ya kubadilisha kati ya tafsiri

1. Fungua sura unayotaka kusoma.
2. Bonyeza jina la tafsiri juu ya skrini.
3. Chagua unayotaka kutoka orodha.

Programu inahifadhi uchaguzi wako kwa wakati ujao.

## Namna ya kuondoa tafsiri

1. Fungua **Mipangilio**.
2. Bonyeza **Dhibiti Nyenzo**.
3. Tafuta tafsiri unayotaka kuondoa.
4. Bonyeza **X** pembeni yake.
5. Thibitisha unataka kuiondoa.

Kuondoa tafsiri hakufuti maoni, rangi, au alamisho zako. Yazo yanabaki salama.

## Tafsiri zinatumia nafasi kiasi gani?

Tafsiri nyingi ni kati ya 2 na 10 MB. Zimehifadhiwa kwenye kifaa chako, sio wingu. Unaweza kuhifadhi nyingi unavyotaka, mradi kifaa chako kina nafasi.

## Tafsiri haipo katika programu?

Baadhi ya tafsiri hazipo katika orodha ya ndani ya programu. Bado unaweza kuziongeza.

1. Fungua programu na nenda **Mipangilio** → **Dhibiti Nyenzo**.
2. Bonyeza **Sakinisha kutoka GitHub**.
3. Katika kidude cha kupakua, angalia kichupo cha **Biblia** na kichupo cha **Biblia za Kimataifa**. Tafsiri yako ikiwepo, ichague na ubonyeze **Sakinisha Zilizochaguliwa**.
4. Isipo, bonyeza **Sakinisha Faili la Ndani** kuingiza faili la `.bible`. Pata faili kutoka ukurasa wa GitHub wa mradi. Ona mwongozo wa [Kupata Nyenzo za Nyongeza kutoka GitHub](theodia://help/getting-core-files) kwa msaada wa hatua kwa hatua.
