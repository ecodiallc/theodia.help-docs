---
title: Kuongeza Faili za Msingi
level: beginner
categories: start
summary: Namna ya kupakua faili kubwa za takwimu programu inazohitaji kujifunza Biblia kwa undani.
---

# Kuongeza Faili za Msingi

Theodia inakuja na Biblia na vingine vichache vya nyongeza tayari vitumike. Kupata mengi zaidi kutoka programu, unahitaji pia kupakua **faili za msingi**. Hizi ni faili kubwa za takwimu zinaoongeza zana za kujifunza kama mafafani, utafutaji wa maneno, na maoni ya sarufi. Bila hizo, programu inafanya kazi, lakini vipengele vya kujifunza ni vya kikomo.

## Kwa nini unahitaji faili za msingi

Faili za msingi zinaongeza:

- **Utafutaji wa maneno.** Bonyeza neno katika aya yoyote kuona Kiebrania au Kigiriki asilia na maana yake.
- **Mafafani.** Mafafani ya AI kwa kila aya.
- **Sarufi.** Taarifa kuhusu kila neno katika lugha asilia.
- **Biblia ya mstari-ku-mstari.** Soma maandiko ya lugha asilia yenye Kiingereza chini ya kila neno.

Unaweza kusoma Biblia bila hizo, lakini zana nyingi za kujifunza zinazihitaji.

## Namna ya kusakinisha faili za msingi

**[Sakinisha Faili za Msingi](theodia://manage/core)**

1. Fungua **Mipangilio**.
2. Bonyeza **Dhibiti Nyenzo**.
3. Kichupo cha **Msingi (Core)** kinafunguka. Unaona orodha ya faili za msingi. Kila moja ina jina, ukubwa, na sanduku la kuhakiki.
4. Bonyeza kila faili unayotaka kusakinisha. Alama ya kuhakiki inaonyesha imechaguliwa.
5. Bonyeza **Sakinisha Zilizochaguliwa**.
6. Subiri faili kupakuliwa na kusakinishwa. Ni kubwa, hivyo hii inaweza kuchukua dakika chache kwenye uunganisho wa polepole.

Faili hupakuliwa kwenye kifaa chako. Unahitaji kufanya hii mara moja tu. Programu inatumia faili kutoka wakati huo, hata ukiwa nje ya mtandao.

## Vidokezo

- Tumia Wi-Fi. Faili ni kubwa.
- Ingiza simu au tablet kwenye betri. Vipakuzi vikubwa vinatumia betri.
- Upakuzi ukikataliwa, bonyeza faili tena kujaribu tena.
- Unaweza kusakinisha zote au zile unazohitaji tu.

## Faili haipo katika orodha?

Programu inavuta orodha kutoka ukurasa wa GitHub wa mradi. Orodha ikiwa wazi, hakikisha uunganisho wako wa intaneti na ujaribu tena. Bado ikiwa wazi, ona mwongozo wa [Maswali Yanaulizwa Wapi?](theodia://help/getting-more-help).

Kwa njia za juu za kuongeza nyenzo, ona mwongozo wa [Kupata Nyenzo za Nyongeza kutoka GitHub](theodia://help/getting-core-files).
