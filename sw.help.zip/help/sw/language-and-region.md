---
title: Lugha ya Programu na Eneo
level: everyday
categories: settings
summary: Namna ya kubadilisha lugha ya programu.
---

# Lugha ya Programu na Eneo

Theodia inapatikana katika lugha nyingi. Programu inaweza kubadilisha lugha ya menyu na vitufe. Maudhui ya msaada pia yanapatikana katika lugha nyingi kutoka kati ya hizi na yamejengwa ndani ya programu. Unaweza pia kupakua au kusasisha kifurushi cha msaada cha lugha — fungua **Mipangilio** → **Msaada** au **Dhibiti Nyenzo** → **Sakinisha kutoka GitHub** → **Hati za msaada**.

## Namna ya kufungua mipangilio ya lugha

1. Fungua **Mipangilio**.
2. Bonyeza **Lugha**.

## Namna ya kubadilisha lugha ya programu

1. Katika orodha ya **Lugha**, bonyeza lugha unayotaka.
2. Programu inatumika lugha mpya mara moja.

Chaguo unaizona zinategemea lugha programu inaziunga mkono.

## Lugha inavyochaguliwa wakati wa kusakinisha kwanza

Ukisakinisha Theodia kwa mara ya kwanza, programu inachagua lugha kwa kuzingatia mipangilio ya kifaa chako. Unaweza kuibadilisha wakati wowote.

## Kinachotafsiriwa

- Menyu, vitufe, na mabango.
- Skrini za mipangilio.
- Ujumbe wa makosa.
- Utafutaji na zana za kujifunza.

## Kilicho katika Kiingereza pekee

- Baadhi ya maudhui ya vitabu na ibada.

## Tafsiri za Biblia na lugha ya programu

Lugha ya programu na lugha ya tafsiri ya Biblia ni vitu tofauti. Unaweza kuwa na programu katika Kihispania na Biblia katika Kiingereza, au kinyume chake.

Kubadilisha tafsiri ya Biblia, ona mwongozo wa [Kusakinisha Tafsiri za Biblia](theodia://help/installing-bibles).

## Vidokezo

- Kitufe au bango likiwa wazi, programu inakosa tafsiri. Toleo la Kiingereza kwa kawaida liko huko kama akiba.
- Ukitaka kusaidia kutafsiri programu, ona mwongozo wa [Maswali Yanaulizwa Wapi?](theodia://help/getting-more-help).
