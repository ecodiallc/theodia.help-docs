---
title: Menyu ya Kuzindua
level: everyday
categories: layout
summary: Njia ya haraka ya kuruka aya za karibuni, kuendesha amri, na kubadilisha mpangilio wa Biblia bila kuondoka kwenye skrini yako ya sasa.
---

# Menyu ya Kuzindua

> **Hali:** Menyu ya Kuzindua inahitaji hali ya **Mtaalamu**. Unaweza kubadilisha hali katika **Mipangilio** → **Hali ya Mtumiaji wa Programu**.

Menyu ya Kuzindua ni ubao wa kufikia-haraka unaoweza kufungua kutoka karibu kila mahali katika programu. Unaweka aya zako za karibuni, amri, na mipangilio ya Biblia iliyohifadhiwa katika mahali pamoja.

## Namna ya kuifungua

Bonyeza **ikoni ya kupanua (⌄)** katika kona ya juu-kulia wa kichwa cha ukurasa wa nyumbani. Ubao unaingia kutoka juu.

## Kilicho ndani

### 1. Sanduku la Amri

Juu ya ubao kuna sanduku la maandiko lenye ikoni ya kibodi. Andika amri na bonyeza **Go** kwenye kibodi. Programu inasoma amri na inakupeleka moja kwa moja.

Mifano:

- `John 3:16` — hufungua aya hiyo.
- `search love` — hutekeleza utafutaji wa Biblia wa "love".
- `bookmark psalms 23` — huweka alamisho kwenye aya.
- `kjv` — hubadili kwenda tafsiri ya KJV.

Kwa orodha kamili ya amri, ona mwongozo wa [Amri](theodia://help/commands).

### 2. Seti Sambamba

Ukiwa umehifadhi presets za Biblia sambamba, zinaonekana hapa kama orodha inayopanuka. Bonyeza moja kupakia mpangilio huo sambamba mara moja.

Kutengeneza preset sambamba:

1. Fungua **Mipangilio** → **Biblia Sambamba**.
2. Ongeza tafsiri na bonyeza **Hifadhi Preset**.
3. Kipa jina. Itaonekana katika Menyu ya Kuzindua.

Bonyeza kwa muda mrefu seti sambamba katika Menyu ya Kuzindua kuiondoa.

### 3. Makusanyo ya Biblia

Makusanyo ya Biblia ni njia za mkato za bonyeza-moja zinazobadilisha tafsiri yako na mtazamo sambamba kwa wakati mmoja. Ukiwa umetengeneza yoyote, yanaonekana hapa kama orodha inayopanuka.

Bonyeza kwa muda mrefu makusanyo kuiondoa.

### 4. Ikoni za Vipengele

Chini ya sanduku la amri unaweza kuona mstari wa vitufe vya emoji vimetungwa duara. Hivi ni njia za mkato za bonyeza-moja kwa vipengele vikuu vya programu.

Ikoni zinazopatikana ni pamoja na:

- **Kuhusu**, **Biblia**, **Maoni ya Biblia**, **Alamisho**, **Vitabu**
- **Ibada**, **Kadi za Kukariri**, **Msaada**, **Rangi**
- **Orodha za Kucheza**, **Viendelezi**, **Utafutaji**, **Mipangilio**, **Theoscript**

Kuchagua ikoni zipi zinaonekana na kwa mpangilio gani:

1. Fungua **Mipangilio** → **Menyu ya Kuzindua**.
2. Bonyeza **Ikoni za Menyu ya Kuzindua**.
3. Tumia swichi kuonyesha au kuficha kila ikoni.
4. Tumia mishale ya juu/chini kupanga upya ulizowasha.

Mpangilio katika mipangilio ni mpangilio vinaonekana katika Menyu ya Kuzindua.

### 5. Aya za Karibuni

Programu inakumbuka sura na aya za mwisho ulizofungua. Zinaonekana kama orodha chini ya ubao. Bonyeza ingizo lolote kuruka moja kwa moja huko.

- **Bonyeza** kufungua.
- **Vuta kidole kushoto** au **bonyeza kwa muda mrefu** kuondoa kutoka orodha.
- Bonyeza **Ondoa zote** kuondoa kila ingizo kwa wakati mmoja.

## Wakati wa kutumia Menyu ya Kuzindua

Iitumie unapotaka:

- Kuruka aya uliyosoma hivi punde.
- Kuandika amri bila kwenda kwenye ukurasa wa nyumbani.
- Kubadilisha tafsiri au mpangilio sambamba kwa bonyeza moja.
- Kufungua kipengele kikuu kutoka popote katika programu.
- Kuhakiki kitu haraka bila kupitia menyu.

## Vidokezo

- Menyu ya Kuzindua inapatikana kwenye karibu kila skrini, hivyo unaweza kuifungua unaposoma sura.
- Sanduku la amri linaunga mkono amri zile zile na sanduku la amri la ukurasa wa nyumbani.
- Ikoni za vipengele na mpangilio wao huhifadhiwa ndani ya kifaa chako. Zinapona upya wa programu.
- Aya za karibuni huhifadhiwa ndani ya kifaa chako. Zinapona upya wa programu.
