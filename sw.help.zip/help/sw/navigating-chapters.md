---
title: Kutembea Kati ya Vitabu, Sura, na Aya
level: everyday
categories: [layout, read]
summary: Namna ya kutembea Biblini na kuruka mahali unapotaka kwenda.
---

# Kutembea Kati ya Vitabu, Sura, na Aya

Mwongozo huu unaonyesha njia zote za kutembea Biblini.

## Njia rahisi: vuta kidole

- Vuta kidole **kushoto** kwenye sura kwenda sura inayofuata.
- Vuta kidole **kulia** kurudi nyuma.
- Hii inafanya kazi kwa kitabu kinachofuata pia. Baada ya sura ya mwisho ya, sembuse, Kutoka, kuvuta kunakupeleka sura ya kwanza ya Mambo ya Walivu.

## Njia ya menyu

- Bonyeza jina la tafsiri juu kubadilisha kwenda Biblia nyingine.
- Bonyeza jina la kitabu juu kuchagua kitabu tofauti.
- Bonyeza namba ya sura kuchagua sura tofauti.

## Njia ya haraka: andika

- Kwenye ukurasa wa nyumbani, kuna sanduku juu. Andika marejeleo, kama `John 3:16` au `psalms 23`, kisha bonyeza kitufe cha **Go** kwenye kibodi.
- Programu inafungua aya.

## Njia ya alamisho

Ukiwahi kuhifadhi aya, fungua kichupo cha **Alamisho**. Bonyeza ingizo lolote kuruka huko.

## Njia ya utafutaji

Bonyeza kichupo cha **Utafutaji**. Andika neno. Programu inakuonyesha kila aya yenye neno hilo. Bonyeza matokeo yoyote kuifungua.

## Njia ya historia

Programu inakumbuka sura ulizofungua. Kuzipata tena, angalia kichupo cha **Alamisho** (kwa aya ulizohifadhi) au sugua orodha ya vitabu katika kichupo cha **Biblia** kupata kitabu ulichosoma hivi karibuni.

## Vidokezo

- Kichupo cha Biblia kinaonyesha vitabu kwa mpangilio kutoka Mwanzo hadi Ufunuo.
- Kwa Zaburi, Methali, na vitabu vingine virefu, bonyeza kitabu na tumia orodha ya sura kuruka mbali.
