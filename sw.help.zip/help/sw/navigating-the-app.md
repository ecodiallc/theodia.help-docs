---
title: Mpangilio wa Programu na Kutembea
level: beginner
categories: layout
summary: Ziara ya ukurasa wa nyumbani, menyu kuu, na ukanda wa chini — kila kitu kiko wapi.
---

# Mpangilio wa Programu na Kutembea

Theodia ina maeneo matatu makuu unayoweza kutembea kati yake: **ukurasa wa nyumbani**, **menyu kuu**, na **ukanda wa chini**. Mwongozo huu unapita kimoja kimoja ili ujue daima pa kwenda.

## Ramani ya haraka

- **Ukurasa wa nyumbani** ni ukurasa unaouona ukifungua programu kwa mara ya kwanza. Una sanduku la utafutaji, vitufe vikubwa kwa kila sehemu ya programu, na orodha ya Biblia, vitabu, na ibada ulizosakinisha.
- **Ukanda wa chini** (pia huitwa ukanda wa vichupo) ni mstari wa ikoni chini ya skrini. Bonyeza wowote kuruka moja kwa moja kwenye sehemu hiyo ya programu.
- **Menyu kuu** ni ikoni yenye mistari mitatu (☰) katika kona ya juu-kulia wa ukurasa wa nyumbani. Bonyeza kufungua orodha ya kila skrini katika programu, pamoja na zisizo na kichupo chake.

## Ukurasa wa nyumbani

Ukifungua Theodia kwa mara ya kwanza, unaishia ukurasa wa nyumbani. Umegawanywa katika sehemu nne, kutoka juu hadi chini.

### Kichwa

Kabisa juu kuna ukanda wa rangi. Kushoto kuna ikoni ya programu na jina "Theodia." Kulia kuna kitufe cha menyu kuu (☰). Ukiwa ndani ya kitabu au sura, upande wa kushoto unaonyesha kitufe cha nyuma (←) badala yake. Bonyeza menyu kuu kufungua menyu (ona chini).

### Amri

Chini kidogo ya kichwa kuna sanduku la maandiko lenye mtindo wa utafutaji lenye jina **Amri**. Andika elekezo fupi na bonyeza kitufe cha go kwenye kibodi. Programu inasoma elekezo na inakupeleka kwenye skrini sahihi. Mifano:

- `psalms 23` — hufungua Zaburi sura ya 23
- `john 3:16` — hufungua Yohane 3:16
- `search love` — hutekeleza utafutaji wa Biblia wa "love"
- `bookmark john 3:16` — huhifadhi Yohane 3:16 kama alamisho
- `commentary romans 8:28` — hufungua mafafani ya aya hiyo
- `xref` (ikifuatiwa na marejeleo) — hufungua marejeleo ya aya hiyo
- `help` — hufungua orodha ya amri na mifano

Programu isipoelewa ulichoandika, inaonyesha taarifa ndogo yenye kidokezo. Ona mwongozo wa **Matatizo ya Kawaida** amri zikifanya kazi.

## Gridi ya vitufe

Chini ya Amri kuna gridi ya vitufe vikubwa, viwili kwa mstari. Kila kitufe kinakupeleka sehemu tofauti ya programu. Vitufe ni:

- 📖 **Biblia (Bibles)** — orodha yako ya tafsiri za Biblia
- 🔍 **Utafutaji (Search)** — tafuta Biblia kwa neno au msemo
- 📚 **Vitabu (Books)** — maktaba yako ya vitabu vya kifalsafa ya Kikristo vya kale
- 📅 **Ibada (Devotionals)** — ibada za kila siku
- 🔖 **Alamisho (Bookmarks)** — aya na sura zako zilizohifadhiwa
- 🖍 **Rangi (Highlights)** — aya zako zilizowekwa rangi
- 📝 **Maoni (Notes)** — maoni yako ya kibinafsi kwenye aya
- ⚙️ **Mipangilio (Settings)** — lugha, mandhari, nyenzo, na mengine
- ❓ **Msaada (Help)** — mfumo wa msaada (ukurasa huu)
- ℹ️ **Kuhusu (About)** — toleo la programu na shukrani

### Orodha za nyenzo

Chini ya gridi ya vitufe kuna sehemu zinazopanuka: **Biblia**, **Vitabu**, na **Ibada**. Kila sehemu inaonyesha vitu ulivyosakinisha. Bonyeza kichwa cha sehemu kuipanua au kuifunga. Bonyeza kitu chochote katika sehemu kuikifungua.

Sehemu ya Biblia ni njia ya haraka zaidi ya kuruka tafsiri mahususi — hakuna menyu, bonyeza tu.

## Ukanda wa chini

Ukanda wa chini (ukanda wa vichupo) ni mstari wa ikoni chini ya skrini. Unabaki wazi karibu kila mahali katika programu, ili uweze kuruka sehemu nyingine wakati wowote. Vichupo unavyoona vinategemea hali yako ya mtumiaji.

**Hali zote zinaona:**

- 🏠 **Nyumbani (Home)** — hufungua ukurasa wa nyumbani
- 📖 **Biblia (Bibles)** — hufungua orodha yako ya tafsiri za Biblia
- 📚 **Vitabu (Books)** — hufungua maktaba yako ya vitabu
- 🔍 **Utafutaji (Search)** — hufungua utafutaji wa Biblia
- ⚙️ **Mipangilio (Settings)** — hufungua mipangilio

**Kawaida na Mtaalamu huona pia:**

- 🔖 **Alamisho (Bookmarks)** — hufungua aya zako zilizohifadhiwa
- 🖍 **Rangi (Highlights)** — hufungua aya zako zilizowekwa rangi
- 📝 **Maoni (Notes)** — hufungua maoni yako ya kibinafsi

**Mtaalamu huona pia:**

- 💻 **AI** — hufungua msaidizi wa AI (ikiwa umewasha katika Mipangilio)

Kichupo cha sasa kimewekwa alama. Bonyeza kichupo chochote kingine kubadilisha.

### Ukanda unavyotenda

Kila kichupo katika ukanda una **mkondo** wake wa skrini. Ukibonyeza kichupo, unarudi **ulikofika** katika mkondo wa kichupo hicho, sio skrini ya kuanzia. Kwa mfano:

- Bonyeza **Biblia** → unaona orodha ya tafsiri za Biblia.
- Bonyeza tafsiri → unaona orodha ya vitabu.
- Bonyeza kitabu → unaona orodha ya sura.
- Bonyeza sura → unasoma sura.
- Badili kwenda **Alamisho** kuhakiki kitu.
- Bonyeza **Biblia** tena → unarudi kwenye sura uliyosoma.

Kila kichupo kinakumbuka mahali ulipo. Programu inahifadhi historia yako ya kutembea ndani ya kila kichupo, hivyo kubadilisha kati ya vichupo hakupotezi maendeleo yako.

### Kinachorejesha kichupo

Kichupo kinarejea skrini yake ya mzizi tu ikiwa:

- Uko katika kichupo hicho tayari na unabonyeza ikoni ya kichupo hicho hicho tena. Hii ni njia ya haraka ya kurudi mwanzoni.
- Programu imelazimishwa kufungwa na kufunguliwa tena.

### Vichupo vya chini dhidi ya menyu kuu

- **Vichupo vya chini** — kila kichupo kinahifadhi mkondo wake. Kubonyeza kichupo kunakurudisha ulikofika.
- **Menyu kuu** — kubonyeza kipengele kunakupeleka kwenye skrini hiyo kwa mfumo huo wa vichupo. Haifunguki kama sahiri.

Tumia vichupo kubadilisha kazi. Tumia menyu kuu ukitaka orodha kamili ya kila skrini katika programu.

### Wakati wa kutumia ukanda

Tumia ukanda unapotaka kubadilisha unachofanya:

- Unasoma sura na unataka kutafuta kitu kingine → bonyeza **Utafutaji**.
- Unatafuta na unataka kuhakiki alamisho zako → bonyeza **Alamisho**.
- Uko mahali popote katika programu na unataka kwenda nyumbani → bonyeza **Nyumbani**.

## Menyu kuu

Menyu kuu ni kitufe chenye mistari mitatu iliyounganishwa (☰) katika kona ya juu-kulia wa ukurasa wa nyumbani. Ukibonyeza, ubao unaingia kutoka upande wa kulia. Ubao unaonyesha kila skrini hali yako ya sasa inayoiunga mkono:

- 🏠 **Nyumbani (Home)**
- 📖 **Biblia (Bibles)**
- 📚 **Vitabu (Books)**
- 🙏 **Ibada (Devotionals)**
- 🔍 **Utafutaji (Search)**
- 🔖 **Alamisho (Bookmarks)** (Kawaida na Mtaalamu)
- 🖍 **Rangi (Highlights)** (Kawaida na Mtaalamu)
- 📝 **Maoni (Notes)** (Kawaida na Mtaalamu)
- 💻 **Msaidizi wa AI** (Mtaalamu pekee, na AI ikiwa imewashwa tu)
- ⚙️ **Mipangilio (Settings)**
- ❓ **Msaada (Help)**
- ℹ️ **Kuhusu (About)**

Kipengele kinacholingana na skrini ulipo sasa kimewekwa alama na kina nukta ndogo pembeni yake. Bonyeza kipengele chochote kwenda moja kwa moja. Bonyeza nje ya ubao, X juu, au kitufe cha nyuma cha kifaa chako kuifunga bila kubadilisha skrini.

### Menyu kuu inatofautianaje

Menyu kuu ni ubao unaoshuka, sio ngazi tofauti ya kutembea. Ukibonyeza kipengele, programu inakwenda kwenye skrini hiyo kwa njia ile ile kama ulingetumia kichupo cha chini au gridi ya vitufe. Mkondo wa kichupo chako cha sasa unahifadhiwa, hivyo unaweza kurudi ulikofika kwa kubonyeza kichupo cha asili tena.

Kwa mfano:

- Unasoma Yohane 3. Unabonyeza kichupo cha **Alamisho**. Unakwenda kwenye alamisho zako. Ukibonyeza **Biblia** tena, unarudi Yohane 3 — ulikofika kabisa.
- Unasoma Yohane 3. Unafungua menyu kuu na kubonyeza **Maoni**. Maoni yako yanafunguka. Kurudi Yohane 3, bonyeza kichupo cha **Biblia** na unarudi kwenye sura kwa njia yenyewe.

Vichupo vinabadilisha muktadha wako na vinakumbuka mahali ulipo. Menyu kuu ni njia nyingine tu ya kufika skrini zile zile.

### Wakati wa kutumia menyu kuu

Tumia menyu kuu ikiwa:

- Unataka kufungua **Rangi**, **Maoni**, **Ibada**, **Msaada**, au **Kuhusu** — skrini zisizo na kichupo chake katika ukanda.
- Umeingia ndani katika sura au utafutaji na unataka kuhakiki kitu haraka bila kupoteza mahali ulipo.
- Unataka kufungua **Mipangilio** bila kuondoka kwenye skrini ulipo.

## Hali ya Mtaalamu

Hali yako ya mtumiaji ikiwa imewekwa **Mtaalamu**, mpangilio unapata vichupo, vipengele vya menyu, na zana za msomaji vya nyongeza ambazo hali za Msomaji na Kawaida huficha. Ona mwongozo wa [Hali ya Mtaalamu](theodia://help/scholar-mode) kwa ziara kamili ya kila kipengele.

## Maeneo matatu yanavyoungana

- **Kubadili kwenda sehemu kuu tofauti** (Biblia, Utafutaji, Alamisho, n.k.) → ukanda wa chini
- **Kuruka aya au amri mahususi** → Amri ya ukurasa wa nyumbani
- **Kutembea kila skrini zinazopatikana** → gridi ya vitufe ya ukurasa wa nyumbani
- **Kuhakiki Maoni, Rangi, au Msaada bila kuondoka mahali ulipo** → menyu kuu
- **Kufungua Mipangilio kutoka popote** → menyu kuu au ukanda

Uzitumia zote tatu. Hakuna "njia sahihi." Chagua iliyorahisi zaidi kwa unachofanya.

### Ukanda dhidi ya menyu kuu: mfano wa haraka

Fikiria unasoma Warumi 8 na unataka kuweka rangi kwenye aya unayoipenda.

**Kutumia ukanda:**

1. Bonyeza aya kufungua menyu ya aya.
2. Bonyeza **Rangi** na uchague rangi.
3. Imekamilika. Hukuondoki kwenye sura kamwe.

**Kutumia menyu kuu (ukitaka kukagua rangi zako):**

1. Bonyeza ☰ kufungua menyu.
2. Bonyeza **Rangi**. Orodha yako ya rangi inafunguka.
3. Kagua, kisha bonyeza kichupo cha **Biblia** kurudi Warumi 8.

**Kutumia ukanda (ukitaka kubadilisha kazi):**

1. Bonyeza **Nyumbani** au **Alamisho** katika ukanda.
2. Unaondoka Warumi 8 na kwenda kwenye skrini mpya.
3. Kurudi Warumi 8, bonyeza **Biblia** tena — unarudi kwenye sura kwa njia yenyewe.

## Vidokezo

- Ukurasa wa nyumbani unakumbuka sehemu zipu zilizopanuliwa au kufungwa. Unapaswa kuipanga mara moja tu.
- Usiponi kichupo unachotarajia, hakiki mambo mawili:

1. **Hali yako ya mtumiaji** — hali ya Msomaji inaficha alamisho, rangi, maoni, na AI. Hali ya Kawaida inaficha AI. Badilisha hali katika **Mipangilio** → **Hali ya Mtumiaji wa Programu**.
2. **Mipangilio ya vipengele** — vichupo vingine vinahitaji kuwashwa katika **Mipangilio** (kwa mfano, msaidizi wa AI).
