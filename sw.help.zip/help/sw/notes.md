---
title: Kuandika Maoni
level: everyday
categories: [annotate, read]
summary: Namna ya kuandika mawazo yako pembeni ya aya.
---

# Kuandika Maoni

> **Hali:** Maoni yanapatikana katika hali za **Kawaida** na **Mtaalamu**. Hali ya Umakini ni kwa kusoma safi, bila vitu vinavyovuruga, pekee. Unaweza kubadilisha hali katika **Mipangilio** → **Hali ya Mtumiaji wa Programu**.

Maoni ni mahali unaandika mawazo, maombi, au mawazo ya kujifunza pembeni ya aya. Kila maoni yamefungamana na aya mahususi.

## Namna ya kuongeza maoni

1. Fungua aya.
2. Bonyeza aya kuleta menyu.
3. Bonyeza **Maoni** katika menyu. Ina ikoni ya kalamu.
4. Andika maoni yako.
5. Bonyeza **Hifadhi**.

Maoni sasa yamehifadhiwa pamoja na aya.

## Namna ya kusoma maoni

1. Fungua aya.
2. Tafuta alama ya kalamu pembeni ya aya. Inamaanisha kuna maoni.
3. Bonyeza aya. Maoni yanaonekana chini.

## Namna ya kuhariri maoni

1. Fungua aya yenye maoni.
2. Bonyeza aya.
3. Bonyeza **Maoni** katika menyu.
4. Fanya mabadiliko yako.
5. Bonyeza **Hifadhi**.

## Namna ya kufuta maoni

1. Fungua aya yenye maoni.
2. Bonyeza aya.
3. Bonyeza **Maoni** katika menyu.
4. Bonyeza **Futa**.

## Namna ya kuona maoni yako yote

Bonyeza kichupo cha **Maoni** chini. Unaona orodha ya kila maoni uliyoandika, yaliyopangwa kwa tarehe.

## Tafuta maoni yako

Katika kichupo cha **Maoni**, bonyeza sanduku la **Utafutaji**. Andika neno. Programu inapata kila maoni yenye neno hilo.

## Vidokezo

- Maoni ni bora kwa mahubiri, ibada, na maswali ya kujifunza.
- Maoni ni ya siri. Yanabaki kwenye kifaa chako.
- Ona mwongozo wa [Kuhifadhi Nakala za Takwimu Zako](theodia://help/backups) kuyahifadhi salama.
