---
title: Taarifa na Vikumbusho
level: everyday
categories: [settings]
summary: Namna ya kuwasha, kubadilisha, na kudhibiti vikumbusho bila mtandao kwa maombi, ibada, mipango ya Biblia, na mengine.
---

# Taarifa na Vikumbusho

Theodia inaweza kukumbusha kuhusu maombi, ibada, mipango ya Biblia, kadi za kukariri, na shughuli nyingine — hata programu ikiwa nje ya mtandao. Vikumbusho vyote vimepangwa kwenye kifaa chako; hakuna uunganisho wa intaneti au seva ya taarifa-za-kusukuma unazohitajika.

## Namna ya kuwasha au kuzima vikumbusho

1. Fungua **Mipangilio**.
2. Bonyeza **Taarifa**.
3. Washa au zima **Washa vikumbusho**.

Mara ya kwanza unapowasha vikumbusho, programu inaomba ruhusa ya kutuma taarifa. Bonyeza **Ruhusu** ili vikumbusho viweze kuonekana.

Uliwahi kukataa ruhusa, iOS au Android inaweza kuzuia ombi. Katika hali hiyo, nenda programu ya **Mipangilio** ya kifaa chako, tafuta **Theodia**, na uwashwe taarifa huko.

## Aina za vikumbusho

Skrini ya taarifa imegawanywa katika vipindi. Kila kipindi ni familia ya vikumbusho unayoweza kuwasha au kuzima kivyake:

- **Vikumbusho vya maombi** — vikumbusho vya maombi vya jumla.
- **Routini ya maombi** — vikumbusho vimefungamana na routini mahususi ya maombi.
- **Ibada** — kikumbusho cha aya au ibada ya kila siku.
- **Vikumbusho vya mpango wa Biblia** — vikumbusho vya mpango hai wa Biblia.
- **Vikumbusho vya Theoscript** — vikumbusho vya kuendesha Theoscript.
- **Vikumbusho vya ufahamu wa AI** — vikumbusho vitengenezwa na AI.
- **Vikumbusho vya kukagua kadi za kukariri** — vikumbusho vya kukagua kadi za kukariri.
- **Vikumbusho vya tabia ya kusoma** — vikumbusho vya kila siku vya tabia ya kusoma.
- **Vikumbusho vya ibada-ya-kanisa na vipindi** — vikumbusho vimefungamana na kalenda ya kanisa.
- **Vikumbusho vyangu** — vikumbusho uliyotengeneza kutoka alamisho, rangi, orodha za kucheza, sura za Biblia, au vitabu.
- **Vikumbusho vya kipekee** — vikumbusho vya kipekee kabisa ulivyotengeneza wewe mwenyewe.

Bonyeza kipindi chochote kuona vikumbusho vyake, kubadilisha wakati, kuchagua siku zipi inatokea, au kuikizima.

## Vikumbusho vya kipekee

Vikumbusho vya kipekee ni vikumbusho unavyotengeneza kutoka mwanzoni.

1. Katika **Mipangilio** → **Taarifa**, bonyeza **Vikumbusho vya kipekee**.
2. Bonyeza kitufe cha **+**.
3. Ingiza **Kichwa** na **Ujumbe**.
4. Chagua **Wakati**.
5. Chagua **Siku** unazotaka irudie.
6. Chagua kikumbusho kinafungua nini kikibonyezwa (hiari).
7. Bonyeza **Hifadhi**.

Unaweza kuhariri au kufuta kikumbusho cha kipekee wakati wowote kwa kubonyeza katika orodha.

## Kinachotokea unapobonyeza kikumbusho

Vikumbusho vingi vinafungua skrini mahususi katika programu. Kwa mfano, kikumbusho cha routini ya maombi kinafungua routini hiyo; kikumbusho cha mpango wa Biblia kinafungua kusoma kinachofuata.

Kikumbusho hakina skrini iliyofungamana, kinafungua programu kwenye ukurasa wa Nyumbani.

## Saa za utulivu

Saa za utulivu hunyamaza sauti za taarifa bado zikiruhusu vikumbusho vya macho vionekane.

1. Katika **Mipangilio** → **Taarifa**, bonyeza **Saa za utulivu**.
2. Weka **Mwanzo** na **Mwisho** wa wakati.

Vikumbusho vilivyopangwa katika saa za utulivu vitaonekana kwenye skrini bila sauti.

## Vikumbusho vijavyo na historia

- **Vikumbusho vijavyo** vinaonyesha kila kitu kimepangwa kutokea hivi punde.
- **Historia ya taarifa** inaonyesha vikumbusho vilivyotumwa hivi karibuni, vilivyopangwa, na vilivyofutwa.

Tumia orodha hizi kuthibitisha kikumbusho kimewekwa sahihi au kuona kwa nini hakijaonekana.

## Vikumbusho havijaonekana

- Hakikisha **Washa vikumbusho** kiko wali.
- Hakikisha taarifa zinaruhusiwa katika mipangilio ya mfumo ya kifaa chako.
- Hakikisha kipindi cha kikumbusho kimewashwa na angalau siku moja imeteuliwa.
- Ulioweka saa za utulivu, kikumbusho kinaweza kimya.
- Watengenezaji wengine wa Android huwalaza programu. Ongeza Theodia kwenye orodha ya kuruhusiwa kifaa chako kikitoa mipangilio ya kupunguza matumizi ya betri.
- Kikumbusho kimefungamana na maudhui uliyoyondoa (kwa mfano, mpango wa Biblia uliofutwa au routini), kikumbusho kinaweza kutotokea mpaka uteulishe tena lengo halali.

## Sauti za taarifa

Unaweza kuchagua sauti inachezwa na vikumbusho vinavyounga mkono sauti. Bonyeza **Sauti** ndani ya kikumbusho au kipindi kuchagua kutoka chaguo zilizopo. Sauti zimepakiwa pamoja na programu, hivyo zinafanya kazi bila mtandao.

Tumia kitufe cha **Angalia sauti kwanza** kusikiliza sauti iliyochagua kabla ya kuhifadhi.

## Beji

Baadhi ya vikumbusho vinaweza kuongeza beji kwenye ikoni ya programu. Bonyeza **Ondoa beji** kwenye skrini ya taarifa kuirejesha.
