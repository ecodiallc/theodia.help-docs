---
title: PDF
level: everyday
categories: [read, resources]
summary: Ingiza, panga, na usoma hati za PDF Theodiani.
---

# PDF

> **Hali:** PDF zipo katika hali za **Kawaida** na **Mtaalamu**. Hali ya Umakini ni kwa kusoma safi, bila kuvuruga, tu. Unaweza kubadilisha hali katika **Mipangilio** → **Hali ya Mtumiaji wa Programu**.

Theodia inaweza kuhifadhi na kusoma faili za PDF. PDF zilizoingizwa zinabaki kwenye kifaa chako, hivyo zinafanya kazi bila intaneti.

## Fungua maktaba ya PDF

Bonyeza kichupo cha **PDF** chini ya skrini, au bonyeza kigae cha **PDF** kwenye Ukurasa wa nyumbani.

## Ingiza PDF

1. Fungua kichupo cha **PDF**.
2. Bonyeza kitufe cha **+** kwenye kona ya chini-kulia.
3. Chague PDF kutoka kifaa chako.
4. (Si lazima) Andika au chague aina kuipanga.

## Panga PDF

Bonyeza kwa muda mrefu kadi yoyote ya PDF kufungua menyu yenye chaguzi hizi:

- **Badilisha jina** — badilisha kichwa kinachoonyeshwa katika maktaba.
- **Badilisha aina** — hamishia PDF katika aina.
- **Futa** — ondoa PDF Theodiani. Hii pia hufuta nafasi yake ya kusoma iliyohifadhiwa.

Aina ni maandiko huru. Andika jina jipya au chague moja iliyopo unapoingiza au kubadilisha aina.

## Soma PDF

Bonyeza kadi ya PDF kuifungua. Msomaji huonyesha:

- Kichwa cha hati katika ukanda juu.
- Safu ya vitufe vya kurasa: **Ukurasa wa kwanza**, **Iliyotangulia**, ukurasa wa sasa ("3 / 120"), **Inayofuata**, na **Ukurasa wa mwisho**.
- Ukanda wa zana za hati: **Maudhui**, **Kuza nje**, **Kuza ndani**, **Rejesha kuvu**, **Alamisho**, **Utafutaji**, **Sikiliza**, na **Mtazamo wa maandiko**.

Baadhi ya zana zinadhomeka hazipozepatikana — kwa mfano, **Utafutaji** na **Sikiliza** zinadhomeka mpaka maandiko yanayotafutika ya PDF yanasakinishwa.

### Zunguka kurasa

- Bonyeza **mshale wa kushoto** au **wa kulia** kurudi au kwenda ukurasa mmoja.
- Bonyeza **Ukurasa wa kwanza** au **Ukurasa wa mwisho** kuruka mwisho wowote wa hati.
- Bonyeza namba ya ukurasa (kwa mfano "3 / 120") kufungua gridi ya kurasa, kisha bonyeza ukurasa unautaka. Gridi inafungua karibu na ukurasa ulipo.
- Tumia **vitufe vya mishale vya Kushoto na Kulia** kwenye kibodi cha nje.

### Kuvu

- Bonyeza **Kuza ndani** (+) au **Kuza nje** (−) kubadilisha ukubwa wa ukurasa.
- Bonyeza **Rejesha kuvu** kurudisha ukurasa kwa ukubwa wake wa kawaida.
- Ukiinua kuvu, ukizunge ukurasa, kisha ukipunguza kuvu, Theodia inakurejesha ukurasa uliousoma.

## Tafuta ndani ya PDF

1. Fungua PDF na ubonyeze kitufe cha **Utafutaji** (kioo cha kukaza) katika ukanda.
2. Andika unachotafuta. Matokeo huonekana unapoandika, pamoja na namba ya ukurasa na kipande cha maandiko ya karibu.
3. Bonyeza matokeo kuruka ukurasa huo.

Kutafuta kunahitaji maandiko yanayotafutika ya PDF yaliyosakinishwa. Hayajawekwa bado, kitufe cha Utafutaji kinadhomeka. PDF zilizosakinishwa kutoka hazina ya GitHub ya jumla zina maandiko yanayotafutika; PDF unazoingiza wewe mwenyewe hazina mpaka ziwezewwe.

## Maudhui

PDF ikiwa na jedwali la maudhui lililojengwa ndani, kitufe cha **Maudhui** katika ukanda huonyesha kama mfumo. Bonyeza kichwa cha sehemu kuruka ukurasa huo. Sehemu zinaweza kupanuliwa na kukunjwa. PDF isipokuwa na jedwali la maudhui, kitufe kinadhomeka.

## Alamisho ndani ya PDF

1. Fungua PDF na ubonyeze kitufe cha **Alamisho** katika ukanda.
2. Bonyeza **Weka alamisho kwenye ukurasa** kuhifadhi ukurasa wa sasa. Jina linaanza kama namba ya ukurasa — andika jina ukipenda — kisha bonyeza **Hifadhi**.
3. Bonyeza alamisho yoyote katika orodha kuruka ukurasa wake.
4. Bonyeza **×** karibu na alamisho kuifuta.

Alamisho za PDF ni tofauti na alamisho zako za Biblia. Kila PDF ina orodha yake.

## Soma PDF kwa sauti

Maandiko yanayotafutika ya PDF yakiwa yamesakinishwa, Theodia inaweza kusoma ukurasa wa sasa kwa sauti:

1. Fungua PDF na ubonyeze kitufe cha **Sikiliza** (kipaza sauti) katika ukanda.
2. Ukanda wa kidhibiti huonekana wenye **Cheza/Sitisha**, **Rudisha nyuma**, **Sogeza mbele**, **Simamisha**, ukanda wa maendeleo unaweza kubonyeza kuruka ndani ya ukurasa, kasi ya kusoma, na sauti.
3. Ukurasa ukimaliza, kusoma kunaendelea ukurasa unaofuata kiotomatiki.

Sauti na kasi ni zile zile zinazotumika kusoma Biblia — ona [Kusoma kwa Sauti](theodia://help/tts) kwa namna ya kuzibadilisha.

## Nakili, shiriki, au hifadhi maandiko ya ukurasa

Bonyeza kitufe cha **Mtazamo wa maandiko** katika ukanda kuona ukurasa wa sasa kama maandiko wazi. Kutoka hapo unaweza:

- **Nakili** — nakili maandiko ya ukurasa kwenye ubao wa kunakili.
- **Shiriki** — shiriki maandiko ya ukurasa kupitia programu yoyote kwenye kifaa chako.
- **Ongeza kwenye maoni ya kujifunza** — hufungua kihariri cha maoni chenye maandiko ya ukurasa, rejea, na kiungo kurudi ukurasa huu, vyote vimewekwa kwako.

## Endelea kusoma

Theodia inakumbuka ukurasa wa mwisho uliouangalia na hufungua PDF hapo muda mwingine ujao.

## Pakua PDF kutoka GitHub

Katika hali ya **Mtaalamu**, kitufe cha **Pakua kutoka GitHub** kinaonekana chini ya maktaba. Hii inaungana na hazina ya PDF ya jumla ili usakinishe hati za PDF zilizofungashwa kwa njia ile ile unayosakinisha Biblia au vitabu.

## Vidokezo

- PDF huhifadhiwa katika folda ya hati za kibinafsi ya Theodia. Hazijumuishwi katika nakala za dharura, hivyo ukihamia kifaa kipya utahitaji kuziingiza tena.
