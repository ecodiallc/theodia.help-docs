---
title: Orodha za Kucheza
level: everyday
categories: playlists
summary: Tengeneza na usikilize orodha za kucheza zinazosomwa kwa sauti za vipande vya Biblia, maandiko wazi, au aya yoyote unayotaka kusikia.
---

# Orodha za Kucheza

**Orodha ya kucheza** ni orodha ya nyimbo Theodia inazoweza kusoma kwa sauti kwako. Kila wimbo ni either kipande cha Biblia au taarifa fupi ya maandiko wazi. Orodha za kucheza ni za manufaa kwa kusikiliza bila-mikono ukiwa njiani, ukitembea, katika muda wa ibada, au unapojifunza kwa akili.

Orodha za kucheza huonekana programuni mara angalau orodha moja imetengenezwa au imejaa.

## Mahali pa kupata Orodha za Kucheza

Orodha za kucheza zikiwa zipo, unaweza kuzifikia kwa njia mbili:

- **Ukurasa wa nyumbani:** Katika sehemu ya **Viendelezi na Zaidi**, bonyeza **Orodha za Kucheza**.
- **Menyu kuu:** Fungua menyu (☰) na ubonyeze **Orodha za Kucheza**.

Hakuna orodha za kucheza zilizopo bado, kigae cha Orodha za Kucheza na kipengele cha menyu vinafichwa.

## Orodha ya kucheza ina nini

Kila orodha ya kucheza ina:

- **Jina** — kwa mfano, "Aya za Asubuhi" au "Jifunze Zaburi 23".
- **Aina** ya hiari — inasaidia kupanga orodha za kucheza kwa lengo.
- Orodha ya **nyimbo** — vitu vya kusomwa kwa sauti.

Kila wimbo una:

- **Maudhui** — either rejea ya kipande cha Biblia au maandiko wazi.
- **Lebo** — inaonyeshwa kwenye skrini wimbo unapokeza.
- **Sauti** ya hiari — chague sauti tofauti kwa wimbo huu ukipenda.

## Kutengeneza orodha ya kucheza

1. Fungua skrini ya **Orodha za Kucheza**.
2. Bonyeza **Tengeneza orodha ya kucheza** (au kitufe cha **+**).
3. Pa orodha ya kucheza jina.
4. (Si lazima) Chague au tengeneza aina.
5. Anza kuongeza nyimbo.

### Kuongeza wimbo kutoka kipande cha Biblia

1. Bonyeza **Ongeza wimbo**.
2. Chague **Kipande cha Biblia** kama aina ya maudhui.
3. Ingiza rejea, kama `John 3:16` au `Psalm 23:1-6`.
4. Ongeza lebo ukipenda, au uiache wazi kutumia rejea.
5. Hifadhi wimbo.

### Kuongeza wimbo wa maandiko wazi

1. Bonyeza **Ongeza wimbo**.
2. Chague **Maandiko wazi**.
3. Andika maandiko unayotaka Theodia isome.
4. Ongeza lebo.
5. Hifadhi wimbo.

### Kuongeza nyimbo kwa kundi

Ukiwa na orodha ya marejea au mistari ya maandiko, tumia **Ongeza kwa kundi**:

1. Fungua orodha ya kucheza.
2. Bonyeza menyu na uchague **Ongeza kwa kundi**.
3. Weka rejea moja au mstari mmoja wa maandiko kwa kila mstari.
4. Washa **Gundua marejea ya Biblia** ikiwa mistari mingi ni marejea ya aya.
5. Bonyeza **Ongeza**. Kila mstari unakuwa wimbo.

## Kusikiliza orodha ya kucheza

1. Fungua orodha ya kucheza unayotaka kusikia.
2. Bonyeza kitufe cha **Cheza** juu au kando ya wimbo.
3. Theodia inasoma kila wimbo kwa mpangilio.

Orodha ya kucheza ikiwa inacheza, ukanda wa kidhibiti huonekana wenye vidhibiti hivi:

- **Cheza / Sitisha**
- **Wimbo unaofuata**
- **Wimbo uliotangulia**
- **Simamisha**

Unaweza pia kuweka:

- **Kasi** — sauti inasoma kwa haraka kiasi gani.
- **Rudia** — rudia orodha yote, rudia wimbo mmoja, au cheza mara moja.
- **Changanya** — cheza nyimbo kwa mpangilio wa nasibu.
- **Puuzia mabano** — ruka maandiko ndani ya mabano.
- **Sitisha kati ya nyimbo** — ongeza tulivu fupi kati ya nyimbo.
- **Kipima muda cha usingizi** — simamisha kucheza baada ya muda uliowekwa.

## Kuhariri orodha ya kucheza

Kubadilisha orodha ya kucheza, kwanza sitisha kucheza ikiwa inacheza sasa.

Unaweza:

- **Kubadilisha jina** la orodha ya kucheza.
- **Kupanga upya nyimbo** — vuta nyimbo kwenye mpangilio mpya.
- **Kuhariri wimbo** — badilisha rejea yake, maandiko, lebo, au sauti.
- **Kufuta wimbo** — uondoe kwenye orodha ya kucheza.
- **Kufuta orodha yote ya kucheza** — hii haiwezi kurejelewa.

## Kutoa na kuingiza orodha za kucheza

Orodha za kucheza zinatolewa kama faili za JSON zinazojumuisha nyimbo zote, aina, na mipangilio. Unaweza kushiriki faili na kifaa kingine, kuihifadhi kama nakala, au kuihariri kwenye kompyuta.

- **Toa orodha zote za kucheza** — hutengeneza faili la `playlists-YYYY-MM-DD.json`.
- **Toa aina** — hutengeneza faili la JSON lenye orodha za kucheza za aina moja tu.
- **Ingiza orodha za kucheza** — huweka upya orodha za kucheza kutoka faili la nakala la JSON.

## Njia za haraka za kujenga orodha ya kucheza

Unaweza pia kutengeneza orodha kamili ya kucheza kama JSON na kuiingiza. Hii ni mfano:

```json
{
  "playlists": [
    {
      "name": "Morning Verses",
      "category": "Devotional",
      "tracks": [
        {
          "info": "John 3:16",
          "contentSource": "passage",
          "content": "For God so loved the world...",
          "rawContent": "John 3:16"
        },
        {
          "info": "Psalm 23",
          "contentSource": "passage",
          "content": "The Lord is my shepherd...",
          "rawContent": "Psalm 23:1-6"
        }
      ]
    }
  ]
}
```

Hifadhi faili, kisha tumia **Ingiza orodha za kucheza** kuiweka Theodiani.

## Vidokezo

- Orodha za kucheza hufanya kazi vizuri zaidi na seti fupi, zilizolenga, za aya.
- Tumia aina kutenganisha orodha za ibada na orodha za kujifunza kwa akili.
- Weka kipima muda cha usingizi ukisikiliza ukiwa unalala.
- Wimbo ukitumia sauti isiyo sahihi, kague kwamba lugha ya sauti inalingana na lugha ya maandiko.
- Theodia inasoma maandiko wazi kama yalivyoandikwa; kague tahajiri kwa matokeo mazuri.
