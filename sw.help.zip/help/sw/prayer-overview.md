---
title: Muhtasari wa Maombi
level: beginner
categories: prayer
summary: Utangulizi wa haraka wa kichupo cha Maombi na sehemu zake kuu.
---

# Muhtasari wa Maombi

Kichupo cha **Maombi** ni nafasi maalum ya maombi. Kinakusanya orodha, vipindi vya kuongozwa, jarida, kipima muda, ratiba za kusoma lektionari, na maombi ya kimapokeo yaliyowekwa.

## Sehemu kuu

- **Orodha ya Maombi** — fuatilia watu, mihali, na mada unapomba.
- **Jarida** — andika mawazo, majibu, na mawazo kwa muda.
- **Tengeneza Maombi** — mwombe Theophilus aandike maombi kutoka ombi au ingizo la jarida.
- **Dini za Imani na Maombi Yaliyowekwa** — maombi ya kimapokeo na dini za imani kutoka jadi ya Kikristo.
- **Lektionari** — ratiba za kusoma Maandiko kwa maombi ya kila siku au ya msimu.
- **Maombi Yaliyoongozwa** — vipindi vya maombi vinavyoongozwa kwa sauti kwa kutumia sauti-kuwa-maandiko.
- **Kipima Muda** — vipindi vya maombi vya muda uliopangwa, wenye gari za hiari.
