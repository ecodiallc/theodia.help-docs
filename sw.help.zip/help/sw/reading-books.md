---
title: Kusoma Vitabu Vilivojengwa Ndani
level: beginner
categories: [content, read]
summary: Namna ya kusoma vitabu vya kifalsafa cha Kikristo vinavyokuja na programu.
---

# Kusoma Vitabu Vilivojengwa Ndani

Theodia inakuja na maktaba ndogo ya vitabu vya Kikristo. Hivi ni kifalsafa unachoweza kusoma kwenye kifaa chako.

## Namna ya kufungua maktaba

Bonyeza kichupo cha **Vitabu** chini ya skrini. Unaona orodha ya vitabu katika maktaba yako.

## Namna ya kusoma kitabu

1. Bonyeza kichwa cha kitabu.
2. Kitabu kinajitokeza kwenye sura ya kwanza.
3. Tumia vitufe vya **Iliyotangulia** na **Ifuatayo** juu kutembea kati ya sura.

## Namna ya kuruka sura

Bonyeza jina la sura juu ya skrini. Orodha ya sura inaonekana. Chagua sura kuruka huko.

## Namna ya kubadilisha ukubwa wa herufi

Fungua **Mipangilio** → **Muonekano (Appearance)** na chagua ukubwa wa herufi. Ukubwa wa maandiko unabadilika katika programu nzima, pamoja na vitabu.

## Namna ya kuweka alamisho katika kitabu

Bonyeza ikoni ya **nyota** juu-kulia. Sura ya sasa inahifadhiwa. Bonyeza kichupo cha **Alamisho** kuona kurasa zako zilizohifadhiwa.

## Namna ya kusikiliza kitabu

Bonyeza ikoni ya **Spika** juu-kulia. Programu inasoma sura kwa sauti. Bonyeza tena kusimamisha.

## Vitabu gani vinapatikana?

Maktaba ina kifalafa kama:

- Pilgrim's Progress
- The Imitation of Christ
- Practice of the Presence of God
- The Hymn Book

Orodha ya vitabu inaweza kukua kadiri inavyopita. Sasisho za programu zinaweza kuongeza zaidi.

## Vidokezo

- Vitabu vimewekwa kwenye kifaa chako. Intaneti haihitajiki.
- Vitabu havisawazishiwi kwenye wingu.
