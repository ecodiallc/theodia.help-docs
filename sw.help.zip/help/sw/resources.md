---
title: Kutafuta Nyenzo kwenye GitHub
level: everyday
categories: resources
summary: Tafuta kila hazina ya GitHub programu inayojua kwa wakati mmoja, kisha usakinishe ulichopata.
---

# Kutafuta Nyenzo kwenye GitHub

Theodia inahifadhi orodha ya hazina za GitHub zinazochapisha nyenzo — Biblia, mafafani, vitabu, ibada, orodha za kucheza, vifurushi vya maombi, na mengine. **Tafuta Hazina za GitHub** hutafuta zote kwa wakati mmoja, hivyo hauitaji kufungua kila kichupo na kutembea kivyake.

> Sehemu ya GitHub ya Mipangilio inapatikana katika hali ya **Mtaalamu** pekee. Kuiwasha, nenda **Mipangilio → Hali ya Mtumiaji → Mtaalamu**.

## Namna ya kutafuta

1. Fungua **Mipangilio**.
2. Bonyeza **Tafuta Hazina za GitHub**.
3. Andika neno katika sanduku la utafutaji. Programu hutafuta neno hilo katika **jina** na **maelezo** ya kila vifurushi katika kila hazina.

Mambo machache ya kujua kuhusu utafutaji:

- **Kila neno lazima lilingane.** Kutafuta `morning evening` hunipata tu vifurushi ambavyo jina au maelezo yake yana maneno **yote mawili**.
- **Herufi kubwa/ndogo haileti tofauti.** `Morning` na `morning` vinapata vifurushi vile vile.
- **Linganizo bora linakuja kwanza.** Kifurushi chenye jina kina **anza** na utafutaji wako kinaonyeshwa kabla ya kile kinachotaja tu katika maelezo.

## Kuchuja

Bonyeza ukanda wa kuchuja juu ya matokeo kupunguza orodha zaidi. Kuna vichujio viwili, na vinafanya kazi pamoja:

- **Mwandishi** — vifurushi vya mwandishi huyo pekee.
- **Mila** — vifurushi vya mila hiyo pekee.

Bonyeza kichujio tena kuondoa, au bonyeza **Ondoa vichujio** kuweka upya vyote viwili.

## Kusakinisha kutoka matokeoni

Kila matokeo yanaonyesha jina la kifurushi, aina gani ya nyenzo, kilichotengenezwa na nani, na hazina inayotoka. Kulia wa mstari kuna kitufe kimoja:

- **Sakinisha** — kifurushi hakija kwenye kifaa chako bado.
- **Sasisha** — toleo jipya zaidi lipatikana. Programu inakuomba kuthibitisha kwanza, kwa sababu kusasisha huondoa nakala ya zamani pamoja na maoni, rangi, au alamisho zozote zinazoelekeza kwake.
- **Fungua** — kifurushi kimesakinishwa tayari; kubonyeza kunakupeleka kwenye skrini unakoiitumia.

Bonyeza **Onyesha upya (Refresh)** juu kupata orodha ya karibuni kutoka GitHub mara moja. Programu inaonyesha upya orodha yenyewe mara moja kwa siku, hivyo kuonyesha upya kwa mkono kunahitajika tu ukijua kitu kipya kimechapishwa.

## Kutafuta bila uunganisho

Programu inahifadhi nakala ya orodha kwenye kifaa chako, hivyo kutafuta kunafanya kazi hata ukiwa nje ya mtandao. Programu isipofikia GitHub kuonyesha upya orodha, leba juu inakuambia unaona matokeo yaliyohifadhiwa.

## Utafutaji haupati chochote

- Jaribu neno fupi, moja.
- Hakikisha hakuna kichujio cha **Mwandishi** au **Mila** kikibaki kimetumika — kitufe cha **Ondoa vichujio** kinaonekana wakati wowote kimo kimeketwa.
- Baadhi ya hazina huchapisha vifurushi vyake katika lugha tofauti na jina la kifurushi, hivyo kutafuta neno lililotafsiriwa huenda lisikipate.
