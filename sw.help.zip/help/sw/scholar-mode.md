---
title: Hali ya Mtaalamu
level: advanced
categories: [layout, read, study]
summary: Hali ya kujifunza ya kina zaidi katika Theodia, inayofungua mafafani, kamusi za asili, marejeleo, zana za AI, na Menyu ya Kuzindua.
---

# Hali ya Mtaalamu

> **Hali:** Hali ya Mtaalamu inapatikana tu hali yako ya mtumiaji ikiwa imewekwa **Mtaalamu**. Badilisha hali katika **Mipangilio** → **Hali ya Mtumiaji wa Programu**.

Hali ya Mtaalamu inafungua kila zana ya kujifunza katika Theodia. Imejengwa juu ya Hali ya Kujifunza, hivyo unapata bado menyu ya aya, Biblia sambamba, alamisho, rangi, na maoni — pamoja na zana za juu zilizoconfu hapa chini.

## Namna ya kufungua Hali ya Mtaalamu

Hali ya Mtaalamu sio skrini tofauti. Ni seti ya zana za nyongeza zinaoonekana ndani ya msomaji aliopo na kutembea hali yako ya mtumiaji ikiwa Mtaalamu.

1. Fungua **Mipangilio**.
2. Bonyeza **Hali ya Mtumiaji wa Programu**.
3. Chagua **Mtaalamu**.

Mabadiliko yanatekelezwa mara moja. Menyu na vitufe vilikuwa vimefichwa sasa vinaonekana.

## Zana za nyongeza za msomaji

Ukifungua sura katika [Hali ya Kujifunza](theodia://help/study-mode), hali ya Mtaalamu inaongeza zana hizi kwenye menyu ya aya:

- **Mafafani ya AI** (◈) — mwombe msaidizi wa AI kuandika maoni ya kujifunza ya aya hii. (Haipatikani katika maeneo yote.)
- **Taarifa ya Neno** (?) — fungua ingizo la kamusi ya asili la neno la Kiebrania au Kigiriki nyuma ya aya. Ona mwongozo wa [Mafafani na Kamusi za Asili](theodia://help/commentaries-and-lexicons).
- **Kamusi** (📖) — tafuta maneno makuu ya Biblia katika nyenzo za kamusi ulizosakinisha. Ona mwongozo wa [Kamusi ya Biblia](theodia://help/dictionary).

Zana hizi zinahitaji nyenzo kusakinishwa (mafafani, kamusi za asili, faili za kamusi). Zana ikiwa imepauzwa au inaonyesha "haipatikani", fungua **Mipangilio** → **Dhibiti Nyenzo** na uongeze nyenzo inazohitaji.

## Kutembea kwa nyongeza

### Kichupo cha nyongeza cha ukanda

Ukanda wa chini unapata kichupo kimoja cha nyongeza:

- 💻 **AI** — hufungua msaidizi wa AI (ikiwa umewasha AI katika Mipangilio tu). Kichupo hiki kiko kulia wa Maoni.

### Vipengele vya nyongeza vya menyu kuu

Menyu kuu inajumuisha ingizo la **Msaidizi wa AI** chini ya masharti yale yale.

## Menyu ya Kuzindua

Hali ya Mtaalamu inawasha **Menyu ya Kuzindua**, njia ya haraka ya kuruka aya za karibuni, kuendesha amri, na kubadilisha mpangilio wa Biblia bila kuondoka kwenye skrini yako ya sasa. Ona mwongozo wa [Menyu ya Kuzindua](theodia://help/launcher-menu) kwa namna ya kuitumia.

## Wakati wa kutumia hali ya Mtaalamu

- Unataka msaidizi wa AI, mafafani, au utafutaji wa lugha asilia unaposoma.
- Unataka Menyu ya Kuzindua kwa kutembea aya haraka na mazungumzo ya AI.
- Unajifunza kipande kwa undani na unahitaji kila zana mbali ya bonyeza moja.

## Kubadili kwenda hali nyepesi

Ukitaka msomaji rahisi zaidi bila zana za juu, badili kwenda hali ya **Kawaida** katika **Mipangilio** → **Hali ya Mtumiaji wa Programu**. Hali ya Kawaida inabaki na alamisho, rangi, maoni, na Hali ya Kujifunza lakini inaficha AI, mafafani, kamusi za asili, na Menyu ya Kuzindua.

Ukitaka uzoefu wa kusoma safi kabisa, fungua sura katika [Hali ya Umakini](theodia://help/focus-mode).

Alamisho, rangi, na maoni yako hayafutwi kamwe ukibadilisha hali; yanafichwa tu mpaka urudie kwenye hali inayoiunga mkono.

## Msaada na maswali

Zana haipo au inaonyesha hitilafu, ona mwongozo wa [Matatizo ya Kawaida](theodia://help/common-problems). Ukiwa mgeni wa Theodia, mwongozo wa [Kusoma Sura Yako ya Kwanza](theodia://help/first-read) unakupeleka kwenye misingi hatua kwa hatua.
