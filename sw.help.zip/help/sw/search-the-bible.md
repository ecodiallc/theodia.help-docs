---
title: Kutafuta Biblia
level: everyday
categories: [study, read]
summary: Namna ya kupata aya kwa neno, msemo, au marejeleo.
---

# Kutafuta Biblia

Ukanda wa utafutaji hukusaidia kupata aya haraka. Unaweza kutafuta kwa neno, msemo, au marejeleo ya Biblia.

## Namna ya kuanza utafutaji

1. Bonyeza kichupo cha **Utafutaji** chini ya skrini.
2. Andika unachotafuta.
3. Bonyeza **Utafutaji** kwenye kibodi.

Matokeo yanaonekana kama orodha ya aya. Kila matokeo yanaonyesha kitabu, sura, na aya, pamoja na maandiko ya aya.

## Tafuta kwa mchanganyiko wa maneno

Ukiandika maneno zaidi ya moja, kama `love joy`, programu inapata aya zenye maneno **mawili**. Hii ni utafutaji wa **AND** — maneno yote yanapaswa kuonekana katika aya. Haitumii mantiki ya **OR** (aya zenye neno moja lolote).

Kutafuta aya zenye neno lolote kati ya mawili, ni lazima utumie neno msingi la `OR` waziwazi: `love OR joy`.

## Tafuta kwa neno

Andika neno moja, kama `love` au `mercy`. Programu inaonyesha kila aya katika Biblia yenye neno hilo.

## Tafuta kwa msemo

Andika maneno mawili au matatu katika alama za nukuu, kama `"do not be afraid"`. Programu inaonyesha aya zenye msemo huo kamili.

## Chuja matokeo

Baada ya utafutaji, matokeo yanachujwa kwa tafsiri za Biblia ulizosakinisha. Kupunguza zaidi, fungua kichupo cha **Biblia** na uangalie tafsiri mahususi — utafutaji hufanyika dhidi ya tafsiri unazo.

## Vidokezo vya utafutaji bora

- Tumia maneno mafupi. Utafutaji wa `love` hupata aya zaidi kuliko utafutaji wa `loving`.
- Alama za nukuu kwenye msemo hufanya utafutaji kuwa kamili.
- Programu inatafuta tafsiri za Biblia ulizosakinisha tu.
- Kuruka aya mahususi kwa marejeleo (kwa mfano, `John 3:16`), tumia sanduku la **Amri** kwenye ukurasa wa nyumbani badala ya kichupo cha Utafutaji.

## Historia ya utafutaji

Programu inakumbuka utafutaji wako wa karibuni. Ukifungua kichupo cha **Utafutaji**, orodha inaonyesha utafutaji wako wa karibuni juu. Bonyeza mmoja kuufanya tena. Kuondoa orodha, bonyeza **Ondoa Zote** juu ya utafutaji wa karibuni.

## Tafuta PDF

Kichupo cha Utafutaji kinaweza pia kutafuta ndani ya hati zako za PDF:

1. Bonyeza kichupo cha **Utafutaji**, kisha bonyeza hali ya **PDF** juu.
2. Chagua PDF zipi kutafutwa. Bonyeza PDF kuipamoja au kuiondoa; tumia **Zote** au **Ondoa** juu ya orodha kupamoja kila kitu au kuanza upya. PDF zenye maandiko yanayotafutika yakiwasilishwa ndizo zinazochaguliwa tu.
3. Andika unachotafuta na bonyeza **Utafutaji**.

Kila matokeo yanaonyesha kichwa cha PDF, namba ya ukurasa, na kipande cha maandiko yanayolingana. Bonyeza matokeo kufungua PDF hiyo katika ukurasa huo.

Kutafuta ndani ya PDF moja unaposoma, tumia kitufe cha **Utafutaji** katika msomaji wa PDF badala yake — ona [PDF](theodia://help/pdfs).
