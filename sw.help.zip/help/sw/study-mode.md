---
title: Hali ya Kujifunza
level: everyday
categories: [layout, read]
summary: Msomaji kamili wa Biblia katika Theodia, umepakiwa zana za kujifunza kama mafafani, marejeleo, kamusi ya asili, na maoni.
---

# Hali ya Kujifunza

> **Hali:** Hali ya Kujifunza inapatikana katika hali za **Kawaida** na **Mtaalamu**. Hali ya Msomaji hufungua sura katika Hali ya Umakini badala yake. Unaweza kubadilisha hali katika **Mipangilio** → **Hali ya Mtumiaji wa Programu**.

Hali ya Kujifunza ni msomaji mkuu wa Biblia katika Theodia. Una zana zote za kujifunza zilizojengwa ndani: mafafani, marejeleo, utafutaji wa maneno, tafsiri sambamba, maoni, na mengine.

Hali ya Umakini ni msomaji rahisi zaidi bila zana za kujifunza. Ona mwongozo wa [Hali ya Umakini](theodia://help/focus-mode) ukitaka maandiko safi pekee. Mwongozo huu ni wa Hali ya Kujifunza.

## Namna ya kufungua Hali ya Kujifunza

Kuna njia chache za kufungua sura katika Hali ya Kujifunza:

- Bonyeza kichupo cha **Biblia** chini ya skrini. Chagua tafsiri, kitabu, na sura.
- Bonyeza aya katika matokeo ya **Utafutaji**.
- Bonyeza alamisho kutoka kichupo cha **Alamisho**.
- Kutoka Hali ya Umakini, bonyeza kitufe cha 📖 juu ya skrini kubadilisha kwenda Hali ya Kujifunza.

## Kusoma sura

Sura inafunguka na aya zikiwa zimetengwa kwa mpangilio. Juu ya skrini kuna vitufe vya vitendo vinavyotumika zaidi. Chini ya skrini kuna ukanda wa hali.

- **Vuta kidole kushoto** kwenda sura inayofuata.
- **Vuta kidole kulia** kwenda sura iliyopita.
- **Bonyeza aya** kufungua menyu ya aya yenye zana za kujifunza (ona chini).
- **Bonyeza namba ya Strong's ndani ya aya** (kwa mfano, G1234 au H1234) kufungua utafutaji wa haraka wa kamusi ya asili kwa neno hilo.

Ukiwa na tafsiri sambamba imewashwa, nakala ya pili ya sura inaonekana chini ya kuu, katika tafsiri uliyochagua. Ona **Kusoma tafsiri mbili kwa wakati mmoja** chini.

## Menyu ya aya

Ukibonyeza aya, menyu inafunguka yenye kichwa "Kitabu Sura:Aya". Zana unazoiona zinategemea hali yako ya mtumiaji.

### Zana katika hali za Kawaida na Mtaalamu

- **Alamisho** (★) — hifadhi aya ili uipate tena. Bonyeza tena kuondoa alamisho. Bonyeza la kwanza linaiongeza. Ona mwongozo wa [Kuweka Alamisho kwenye Aya](theodia://help/bookmarks).
- **Rangi** (□) — weka rangi kwenye aya ili ionekane. Bonyeza kufungua kichagua rangi. Bonyeza rangi hiyo hiyo tena kuondoa rangi. Ona mwongozo wa [Kuweka Rangi kwenye Aya](theodia://help/highlights).
- **Soma** (🔊) — aya kusomwa kwa sauti kwa sauti ya kusoma maandiko ya kifaa chako. Hii haionyeshwi kwa Biblia za mstari-ku-mstari. Ona mwongozo wa [Kusoma kwa Sauti](theodia://help/tts) kwa namna ya kuitumia na kuchagua sauti.
- **Nakili** (⎘) — weka maandiko ya aya kwenye ubao wa kunakili ili uyaweke mahali popote.
- **Linganisha** (⇄) — fungua ubao unaoonyesha aya hiyo hiyo katika kila tafsiri uliyosakinisha. Bonyeza tafsiri kwenye ubao kusoma aya katika tafsiri hiyo. Ona mwongozo wa [Kulinganisha Tafsiri](theodia://help/compare-translations).
- **Marejeleo** (↗) — fungua orodha ya aya zinazohusiana kutoka kwenye hifadhi ya marejeleo. Ona mwongozo wa [Marejeleo](theodia://help/cross-references).
- **Ongeza/Hariri Maoni ya Biblia** (✎) — andika maoni yako ya kibinafsi yaliyofungamana na aya. Ona mwongozo wa [Kuandika Maoni](theodia://help/notes).

### Zana katika hali ya Mtaalamu pekee

- **Mafafani ya AI** (◈) — mwombe msaidizi wa AI kuandika maoni ya kujifunza ya aya hii. (Haipatikani katika maeneo yote.)
- **Taarifa ya Neno** (?) — fungua ingizo la kamusi ya asili la neno la Kiebrania au Kigiriki nyuma ya aya. Ona mwongozo wa [Mafafani na Kamusi za Asili](theodia://help/commentaries-and-lexicons).
- **Kamusi** (📖) — tafuta maneno makuu ya Biblia katika nyenzo za kamusi ulizosakinisha. Ona mwongozo wa [Kamusi ya Biblia](theodia://help/dictionary).

Baadhi ya zana zinahitaji nyenzo za nyongeza kusakinishwa. Zana ikiwa imepauzwa au inaonyesha "haipatikani", fungua **Mipangilio** → **Dhibiti Nyenzo** na uongeze nyenzo inazohitaji.

## Vitufe vya juu ya skrini

Juu ya maandiko ya sura kuna mstari wa ikoni. Hivi ni vitendo vya haraka:

- **Toleo la Biblia** — bonyeza jina la tafsiri (kwa mfano, "KJV") kubadilisha kwenda tafsiri nyingine.
- **Kitabu** — bonyeza jina la kitabu kuruka kitabu tofauti.
- **Sura** — bonyeza namba ya sura kuruka sura tofauti.
- **Fungua katika AI** (🤖) — tuma sura ya sasa kwa msaidizi wa AI pamoja na swali lako. (Hali ya Mtaalamu pekee.)
- **Hali ya Umakini** (📖) — badili kwenda Hali ya Umakini kwa kusoma safi.
- **Biblia Sambamba** (🔵 / ⚪) — bonyeza kuwasha au kuzima tafsiri sambamba. Ikiwa imewashwa, sura hiyo hiyo inaonyeshwa katika tafsiri sambamba ulizochagua chini ya maandiko makuu. Ikiwa imezimwa, tafsiri kuu pekee inaonyeshwa. Ona **Kusoma tafsiri nyingi kwa wakati mmoja** chini.
- **Sikiliza** — sura nzima kusomwa kwa sauti. Ona mwongozo wa [Kusoma kwa Sauti](theodia://help/tts).
- **Zaidi** — fungua vitendo vya sura vya nyongeza (maoni ya Biblia ya sura, mafafani ya sura, kushiriki, na kadhalika).

## Kusoma tafsiri nyingi kwa wakati mmoja

Unaweza kuonyesha hadi tafsiri nne za nyongeza pamoja na kuu. Hii huitwa **mtazamo sambamba**.

1. Fungua **Mipangilio**.
2. Washa **Biblia Sambamba**.
3. Bonyeza **Ongeza Biblia Sambamba** na uchague tafsiri.
4. Rudia kuongeza zaidi. Unaweza kuwa na hadi tafsiri nne sambamba.

Mtazamo sambamba ukiwashwa, kila aya katika sura inaonyesha tafsiri yako kuu kwanza, ikifuatwa na aya hiyo hiyo katika kila tafsiri sambamba. Hii hurahisisha kulinganisha jinsi watafsiri tofauti wanavyoshughulikia aya ngumu bila kutoka kwenye sura.

Unaweza kuhifadhi mpangilio wako wa sasa wa sambamba kama **preset**. Bonyeza kitufe cha kuhifadhi karibu na tafsiri ulizochagua, kipa jina, na inakuwa chaguo la kubadili-haraka. Bonyeza preset yoyote baadaye kupakia mchanganyiko huo mara moja. Bonyeza kwa muda mrefu preset kuiondoa.

Unaweza pia kulinganisha aya moja tu kwa wakati mmoja na zana ya **Linganisha** (⇄) katika menyu ya aya. Inafungua ubao unaoonyesha aya katika kila tafsiri iliyosakinishwa.

## Vichwa vidogo vya sehemu

Baadhi ya tafsiri vina vichwa vya sehemu vilivojengwa ndani (kwa mfano, "Mahubiri ya Mlimani"). Tafsiri yako ikiwa inayo, unaweza kuonyesha au kuficha kwa mpangilio wa **Onyesha Vichwa Vidogo** katika **Mipangilio**. Vichwa vidogo vinaonekana kama vichwa vijivi vya kijivu kati ya aya.

## Maoni ya sura

Maoni ya sura ni maoni moja yaliyofungamana na sura nzima, sio aya moja. Yanafaa kwa wazo moja kubwa kuhusu sura.

Kufungua maoni ya sura:

1. Bonyeza kitufe cha **Zaidi** juu ya skrini.
2. Bonyeza **Maoni ya Sura**.
3. Andika maoni yako. Bonyeza **Hifadhi**.

Maoni ya sura huhifadhiwa pamoja na sura. Yanaonekana wakati wowote unapofungua sura hiyo.

## Alama za utafutaji

Ukiwa umefika kwenye sura kutoka utafutaji, maneno yako ya utafutaji yamewekwa rangi ya njano katika maandiko ya aya. Hii hurahisisha kuona kwa nini aya ililingana.

Unaweza pia kufanya utafutaji tena katika sura unayosoma. Fungua kichupo cha **Utafutaji** na uingize neno. Matokeo hukuruhusu kubonyeza moja kwa moja kurudi kwenye sura na ulinganifu ukionekana.

Biblia za mstari-ku-mstari (MIB — Marvel Interlinear Bible — na OHGB) hufunguka katika Hali ya Kujifunza daima kwa sababu zinahitaji mpangilio wa ngazi ya neno.

## Kubadili kwenda Hali ya Umakini kwa sura moja

Kutoka sura yoyote katika Hali ya Kujifunza, bonyeza kitufe cha 📖 juu. Sura hiyo hiyo inafunguka katika Hali ya Umakini na menyu zote zimefichwa. Bonyeza kitufe cha 📖 katika ukanda wa chini kubadili kurudi Hali ya Kujifunza.

## Wakati wa kutumia Hali ya Kujifunza

Hali ya Kujifunza ni chaguo sahihi ukitaka:

- **Kusoma na kujifunza kwa wakati mmoja.** Zana zote ni mbali ya bonyeza moja.
- **Kutafuta neno usilijui.** Bonyeza namba ya Strong's ndani ya aya kwa ingizo la haraka la kamusi ya asili.
- **Kulinganisha tafsiri.** Tumia zana ya Linganisha ya menyu ya aya au washa mtazamo sambamba.
- **Kuona jinsi aya inavyounganishwa na Biblia nzima.** Tumia Marejeleo.
- **Kuandika maoni unaposoma.** Menyu ya aya ina chaguo la haraka la "Ongeza maoni".

Kwa kusoma muda mrefu, bila vitu vinavyovuruga, badili kwenda Hali ya Umakini.

## Kubadili kwenda Hali ya Umakini

Kutoka sura yoyote katika Hali ya Kujifunza, bonyeza kitufe cha 📖 juu. Sura hiyo hiyo inafunguka katika [Hali ya Umakini](theodia://help/focus-mode) na menyu na zana za kujifunza zimefichwa. Bonyeza kitufe cha 📖 katika ukanda wa chini kubadili kurudi Hali ya Kujifunza. Kwa maelezo kamili ya kile Hali ya Umakini inachofanya, ona mwongozo wa [Hali ya Umakini](theodia://help/focus-mode).

## Msaada na maswali

Zana haipo au inaonyesha hitilafu, ona mwongozo wa [Matatizo ya Kawaida](theodia://help/common-problems). Ukiwa mgeni wa Theodia, mwongozo wa [Kusoma Sura Yako ya Kwanza](theodia://help/first-read) unakupeleka kwenye misingi hatua kwa hatua.
