---
title: Vipengele vya Tablet
level: everyday
categories: [layout, tablet]
summary: Mpangilio wa Theodia unavyojichukua kwa tablet na skrini kubwa, yenye mtazamo wa kupasuliwa, ubao wa pembeni, na hali za kusoma safu-mbili.
---

# 📱 Vipengele vya Tablet

Theodia imeundwa kutumia skrini kubwa za tablet. Kwenye tablet (au kifaa chochote kipana zaidi ya pikseli 700 hivi), programu inabadilika kwa njia yenyewe kwenda mpangilio wa safu-mbili katika maeneo mengi.

> **Hali:** Vipengele vilivyoelezwa hapa vinaonekana tu hali yako ya mtumiaji ikiyavunga mkono. Kwa mfano, ubao wa pembeni wa mafafani na mazungumzo ya AI yanapatikana katika hali ya Mtaalamu pekee. Mtazamo wa kupasuliwa wa alamisho, rangi, na maoni unahitaji Kawaida au Mtaalamu. Hali ya Umakini inaonyesha kusoma safi, safu-moja, pekee. Unaweza kubadilisha hali katika **Mipangilio** → **Hali ya Mtumiaji wa Programu**.

## Menyu ya aya ya msomaji

Ukibonyeza namba ya aya (au kubonyeza kwa muda mrefu maandiko ya aya), **menyu ya aya** inaonekana kama **kadi iliyo katikati** juu ya mandhari ya giza.

- Vitufe vya **Nakili** na **Shiriki** vinaonekana daima juu ya menyu.
- **Alamisho** na **Rangi** zinaonyeshwa na hali zao za sasa.
- **Mafafani**, **Kamusi**, na **Linganisha** vinafunguka kutoka menyu. Kwenye tablet zana hizi zinaweza kuonekana katika ubao wa pembeni au kadi pana zikichaguliwa.
- Bonyeza mandhari ya nyuma au mshale wa kufunga kuifunga menyu.

## Bao wa Mafafani ya Aya

Zana ya **Mafafani** inafungua **bao la pembeni la kipekee** kwenye tablet:

- Maandiko ya mafafani yanaonekana pembeni ya maandiko ya Biblia.
- Unaweza kusugua mafafani kivyake bila Biblia.
- Bonyeza **X** au vuta kidole kuifunga.
- **Ikoni ya kitabu** juu ya ubao hukuruhusu kubadilisha vyanzo vya mafafani.
- **Ikoni ya sura** hukuruhusu kuona mafafani ya ngazi ya sura.

Kwenye simu, mafafani yanafunguka kama kidude cha skrini-nzima.

## Mafafani ya Sura

**Mafafani ya Sura** yanafikiwa kutoka kitufe cha **Zaidi** juu ya skrini, sio menyu ya aya. Kwenye tablet yanafunguka kama bao la pembeni kama Mafafani ya Aya, hivyo unasoma mafafani na maandiko ya Biblia pamoja.

## Kichupo cha Linganisha

Kichupo cha **Linganisha** (katika menyu ya aya) kinafunguka kama **bao la pembeni** kwenye tablet. Kinaonyesha aya iliyochagua katika kila toleo sambamba ulilowasha. Unaweza kubonyeza toleo lolote kuruka kipande hicho katika msomaji.

## Kidude cha Kamusi / Strong's

Zana ya **Kamusi** (menyu ya aya → Kamusi) inafunguka kama kadi pana kwenye tablet. Inaonyesha neno la Kigiriki au Kiebrania, uandishi wake kwa herufi za Kilatini, maana yake, na namba ya Strong's. Bonyeza kitufe cha **Concordance** kuona kila mahali neno hilo linaonekana Biblini.

## Bonyeza neno kufungua kamusi yake ya asili

Katika **bao la Taarifa ya Neno** kwenye tablet, kila kadi ya neno yenye namba ya Strong's inatekelezeka. Bonyeza kadi kufungua **bao la Kamusi ya Asili** la neno hilo moja kwa moja. Bao la Kamusi ya Asili linabadilisha bao la Taarifa ya Neno ili uendelee kujifunza bila kufunga msomaji.

Kwenye simu, kadi za Taarifa ya Neno hazitekelezeki kwa sababu skrini ni ndogo mno kwa ubao mbili.

## Biblia Sambamba kando-kando

Katika Mipangilio, bonyeza **Biblia Sambamba** na uchague hadi matoleo matatu. Kwenye tablet, matoleo yanaonekana kama **safu wima** pembeni ya mmoja wa mwingine:

- Kila safu inasugua kivyake.
- Unaweza kubonyeza namba ya aya kufungua bao la pembeni lenye zana.
- Kichupo cha **Linganisha** kinaonyesha aya zote zilizochagua mahali pamoja.
- Bonyeza **X** kwenye safu yoyote kuifunga na kurudi mtazamo wa safu-moja.
- Bonyeza ikoni ya **Biblia Sambamba** (🔵 / ⚪) katika ukanda wa ikoni wa juu kuwasha au kuzima mtazamo sambamba bila kufungua Mipangilio.

Kwenye simu, matoleo sambamba yanaonyeshwa mmoja baada ya mwingine (wima) badala ya kando-kando. Ikoni ile ile ya kubadilishana inafanya kazi kwenye simu pia.

## Mtazamo wa kupasuliwa wa Alamisho na Rangi

Kwenye tablet, vichupo vya **Alamisho** na **Rangi** vinatumia mpangilio wa mkuu-maelezo:

- **Upande wa kushoto** — orodha ya alamisho au rangi.
- **Upande wa kulia** — kubonyeza kitu kunaufungua bao la muhtasari wenye maandiko ya aya au kipande.

Unaweza kupita vitu vyako vilivyohifadhiwa na kuviahitaji bila kuondoka kwenye kichupo. Kwenye simu, kubonyeza kitu kunakwenda kwenye skrini ya msomaji.

## Mtazamo wa kupasuliwa wa Maoni

Kichupo cha **Maoni** kwenye tablet kinaonyesha orodha yako ya maoni kushoto na maoni yaliyochagua kulia. Kubonyeza maoni kunakifungua katika bao la pembeni ili upitate maoni kadhaa mfululizo bila kuondoka kwenye orodha. Kutengeneza au kuhariri maoni pia kunatumia bao la pembeni.

## Mtazamo wa kupasuliwa wa Utafutaji

Kwenye tablet, kichupo cha **Utafutaji** kinaonyesha fomu ya utafutaji kushoto na matokeo kulia mara moja unapoendesha utafutaji. Unaweza kuboresha swali lako na kuona matokeo yakibadilika bila kubadilisha skrini. Kwenye simu, matokeo ya utafutaji yanafunguka kwenye skrini tofauti.

## Ukanda wa pembeni wa makundi ya Mipangilio

Skrini ya **Mipangilio** kwenye tablet inaonyesha orodha ya makundi kushoto (AI, Muonekano, Nakala, Biblia, n.k.). Bonyeza kundi kuruka moja kwa moja kwenye mipangilio yake kulia. Kundi lililochagua pekee limepanuliwa, hivyo hauitaji kusugua orodha nzima ya mipangilio.

## Kutembea Biblia kwenye tablet

Skrini za **Orodha ya Biblia**, **Vitabu vya Biblia**, na **Sura za Biblia** zinabaki safu-moja kwenye tablet, lakini zinatumia malengo ya kugusa makubwa, gridi pana, na nafasi nyingi ya kupumzisha ili maudhui yasomike na yagusiwe kwa urahisi. Hazitumii mpangilio wa mtazamo-kupasuliwa kwa sababu kila hatua inahitaji upana wote kuonyesha orodha au gridi yake kwa wazi.

## Mwambatano na wima

Kuzungusha tablet kunapanga upya mpangilio kwa njia yenyewe. Katika **mwambatano**, ubao wa pembeni una nafasi nyingi. Katika **wima**, ubao unakuwa mwembamba zaidi lakini unabaki pembeni ya maandiko.

## Mazungumzo ya AI ya aya iliyochagua

**Mazungumzo ya AI** yanafunguka katika bao la pembeni la menyu ya aya. Yanaonyesha kiolesura cha mazungumza unapoweza kuuliza maswali kuhusu aya iliyochagua. Jibu la AI linaonekana katika ubao, na unaweza kuendelea mazungumzo bila kuondoka kwenye msomaji.

## Ukanda wa pembeni wa mazungumzo katika skrini ya AI

Katika kichupo cha **AI** kwenye tablet, orodha ya mazungumzo inaonekana daima kama ukanda wa kushoto unaoendelea kubaki. Unaweza kubadilisha kati ya mazungumzo bila kufungua menyu. Kitufe cha **Mazungumzo Mapya** pia kinaonekana daima. Kwenye simu, orodha ya mazungumzo ni deri inayojitokeza.

## Kinachobaki kama kiko

Sio kila skrini inayogawanyika safu mbili. Skrini zifuatazo zinabaki safu-moja kwenye tablet:

- **Orodha ya Biblia** — orodha ya matoleo ya Biblia (upana wote)
- **Vitabu vya Biblia** — gridi ya vitabu na sehemu (upana wote)
- **Sura za Biblia** — gridi ya sura (upana wote)
- **PDF** — maktaba ya PDF inatumia gridi pana ya kadi (upana wote)
- **Mipangilio** — kurasa za mipangilio binafsi (upana wote)
- **Msaada** — makala za msaada (upana wote)

## Muhtasari

Kwenye tablet, unapata:

- **Biblia Sambamba** katika safu wima kando-kando
- **Mafafani** katika ubao wa pembeni unaoendelea kubaki
- **Linganisha** na **Kamusi** katika kadi pana
- **Kamusi ya Asili** kutoka kwa kubonyeza kadi yoyote ya Taarifa ya Neno
- **Alamisho, Rangi, Maoni, Ibada, Vitabu, Mipangilio** katika mtazamo wa kupasuliwa wa mkuu-maelezo
- **Utafutaji** wenye matokeo ya moja kwa moja pembeni ya fomu ya utafutaji
- **Mwambatano** na **wima** vyote viungwa mkono na mabadiliko ya mpangilio ya njia yenyewe

Kwenye simu, kila kitu kinatumia kutembea-kwa-ndani wa safu-moja wa kimapokeo. Programu inagundua upana wa skrini kwa kuanzishwa na inachagua mpangilio sahihi kwa njia yenyewe.
