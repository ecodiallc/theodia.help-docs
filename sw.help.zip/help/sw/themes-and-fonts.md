---
title: Kubadilisha Mandhari na Herufi
level: everyday
categories: settings
summary: Namna ya kubadilisha mwonekano wa programu.
---

# Kubadilisha Mandhari na Herufi

Theodia hukuruhusu kubadilisha mwonekano wa programu. Unaweza kuchagua mandhari (mwanga au giza) na ukubwa wa herufi.

## Namna ya kufungua mipangilio ya muonekano

1. Fungua **Mipangilio**.
2. Bonyeza **Muonekano (Appearance)**.

## Namna ya kubadilisha mandhari

Katika sehemu ya **Muonekano**, unaona vitufe viwili vya mandhari:

- **Chaguomsingi (Default)** — mandhari ya mwanga yenye maandiko meusi. Nzuri kwa mchana.
- **Giza (Dark)** — mandhari ya giza yenye maandiko meupe. Nzuri kwa usiku na huhifadhi betri.

Bonyeza mandhari kuiitumia. Mabadiliko ni ya papo hapo.

## Namna ya kubadilisha ukubwa wa herufi

Katika sehemu ya **Muonekano**, bonyeza moja ya vitufe vya ukubwa: **---**, **--**, **-**, **Kawaida (Normal)**, **+**, **++**, **+++**. Maandiko yanapungua au kuongezeka katika programu nzima. Chagua ukubwa unaoisoma kwa urahisi zaidi.

## Vidokezo

- Mandhari ya giza huhifadhi betri kwenye simu zenye skrini za OLED.
- Maandiki yakiwa madogo kusoma, ongeza ukubwa wa herufi katika programu, sio kwenye kifaa. Mipangilio ya programu ni ya usahihi zaidi.
- Kwa kusoma muda mrefu, jaribu mandhari ya giza na herufi kubwa zaidi.
- [Washa mandhari ya jangwa](theodia://unlock-desert)
