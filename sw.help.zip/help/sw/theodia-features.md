---
title: Vipengele vya Theodia
level: beginner
categories: welcome
summary: Muhtasari wa haraka wa kile kinachofanya Theodia kuwa ya kipekee na namna inavyokusaidia kujifunza Biblia.
---

# Vipengele vya Theodia

Theodia imejengwa kuwa mwenzio kamili wa kujifunza Biblia. Hii hapa inayofanya kuonyeshe.

## Bila Intaneti Kwanza

Kila kitu hufanya kazi bila intaneti. Biblia, mafafani, kamusi za asili, vitabu, na ibada huhifadhiwa kwenye kifaa chako. Unaweza kusoma, kutafuta, na kujifunza popote — ndani ya ndege, maeneo ya mbali, au mahali popote pasipo mtandao.

## Faragha Kwanza

Takwimu zako zinabaki nawe. Maoni, rangi, alamisho, na historia ya kusoma huhifadhiwa ndani ya kifaa chako. Hakuna akaunti inayohitajika, na hakuna kinachotumwa kwenye seva usipochagua kutumia msaidizi wa AI ya hiari.

## Msaada wa Baobabu

Theodia imeundwa kwa simu na baobabu zote mbili. Kwenye skrini kubwa zaidi, unapata nafasi zaidi ya kusoma, mitazamo ya Biblia Sambamba, na mpangilio unaotumia nafasi ya ziada.

## Nyenzo Zinazosakinishwa

Huepewi kikomo kile kinachokuja na programu. Unaweza kuongeza matoleo zaidi ya Biblia, mafafani, kamusi za asili, vitabu, na ibada. Nyenzo zipo kutoka ukurasa wa GitHub wa mradi na zinaweza kusakinishwa moja kwa moja programuni.

## Msaidizi wa AI

Msaidizi wa AI ya hiari husaidia kuelewa aya, kueleza muktadha, na kujibu maswali. Huwaka ikiwa umewasha tu. Kwa chaguomsingi unganisha kwenye mfano wa mbali unautoa kupitia mwisho na ufunguo wa API ulioweka. Mara ya kwanza unatumia AI, programu inaomba ridhaa yako na inaonyesha hasa kinachotumwa.

## Kusoma Biblia Sambamba

Soma hadi matoleo manne ya Biblia kwa wakati mmoja. Ukifungua sura, tafsiri yako kuu huonekana kwanza, na kila aya inafuatiwa na aya ile ile katika tafsiri zako sambamba ulizochagua. Linganisha uandishi, jifunze tofauti, na upata picha kamili zaidi ya maandiko. Hifadhi mchanganyiko wako unaopenda kama mipangilio-ya-mapema na ubadili kati yake kwa haraka.

## Utafutaji wa Maandiko-Kamili

Tafuta kote katika toleo lolote la Biblia. Tafuta maneno, vifungu, au milinganisho ya sehemu. Unaweza pia kupunguza utafutaji kwenye wigo wa vitabu.

## Marejeleo

Bonyeza rejea ya aya kuruka moja kwa moja kwenye kipande hicho. Marejeleo yamejengwa ndani na hufanya kazi kote Biblini.

## Kamusi ya Asili na Namba za Strong's

Bonyeza namba ya Strong's kuona ufafanuzi wa Kigiriki au Kiebrania asilia. Ingizo za kamusi za asili zimejumuishwa kwa kujifunza maneno kwa undani zaidi.

## Alamisho na Rangi

Hifadhi aya kwa alamisho na uziweke rangi. Kila kitu huhifadhiwa ndani ya kifaa na kinadumu kati ya vipindi.

## Maoni

Andika mawazo yako mwenyewe kando ya aya yoyote. Maoni yamefungwa kwenye aya na ni rahisi kupatana nayo baadaye.

## Ibada ya Kila Siku

Anza siku yako na somo fupi la ibada. Programu inajumuisha ibada zinazofunguka kwa ingizo la leo kiotomatiki.

## Vitabu vya Kikristo

Soma fasihi ya kimapokeo ya Kikristo ndani ya programu. Vitabu vimepangwa kwa urahisi wa kusoma na vina jedwali la maudhui kwa kutembea kwa haraka.

## Kusoma PDF

Ingiza hati zako za PDF na uzisome bila intaneti, zimepangwa katika aina. Msomaji unaunga mkono utafutaji, jedwali la maudhui, alamisho, kuvu, na kusoma kwa sauti. Unaweza pia kusakinisha makusanyo ya PDF yaliyofungashwa kutoka hazina ya jumla.

## Lugha Nyingi

Theodia inaunga mkono lugha nyingi kwa kiolesura cha programu na maudhui ya Biblia. Badilisha lugha katika mipangilio kujifunza kwa lugha unayopendelea.

## Hali ya Giza na Mandhari

Chagua kutoka hali ya mwanga au giza, au chague mandhari inayokufaa. Faraja ya kusoma ni muhimu, hasa katika mwanga wa chini.

## Nakala ya Takwimu

Fanya nakala za maoni, alamisho, na rangi zako. Weka takwimu zako salama na uzihamishie kifaa kipya ukihitaji.

## Hakuna Matangazo, Hakuna Kuvuruga

Theodia imejengwa kwa umakini. Hakuna matangazo, hakuna dirisha zinazoruka, hakuna kuvuruga. Maandiko tu na zana zako za kujifunza.
