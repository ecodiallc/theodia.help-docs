---
title: Kusoma kwa Sauti (Text-to-Speech)
level: everyday
categories: tts
summary: Theodia kusoma Biblia au ibada kwa sauti. Namna ya kuitumia, kuchagua sauti, na cha kufanya ikiwa kimya.
---

# Kusoma kwa Sauti (Text-to-Speech)

> **Hali:** Kusoma kwa sauti (TTS) kinapatikana katika hali za **Kawaida** na **Mtaalamu**. Hali ya Umakini ni kwa kusoma safi, bila vitu vinavyovuruga, pekee. Unaweza kubadilisha hali katika **Mipangilio** → **Hali ya Mtumiaji wa Programu**.

Theodia inaweza kusoma maandiko kwa sauti kwa sauti ya kusoma maandiko (TTS) ya kifaa chako. Unaweza kusikiliza aya moja, sura nzima, au ibada. Hii inajifaa kwa kusoma bila mikono, kusikiliza unapotembea au kusafiri, kusoma ukifuatilia sauti, au kukupa mapumziko ya macho tu.

## Kitufe cha kusikiliza kiko wapi

Utapata kitufe cha kusikiliza katika maeneo matatu.

### 1. Katika menyu ya aya (aya moja)

Hii ni njia ya haraka zaidi ya kusikiliza aya moja kwa wakati mmoja. Fungua sura katika [Hali ya Kujifunza](theodia://help/study-mode), bonyeza aya kufungua menyu ya aya, kisha bonyeza **Soma** (🔊). Kusoma kunaanza kutoka aya hiyo. Ukanda mdogo wa udhibiti unaonekana chini ya skrini wenye kucheza, kupumzisha, kurudisha, kuharakisha, na kichagua sauti.

Chaguo la Soma haionyeshwi kwa Biblia za mstari-ku-mstari (MIB — Marvel Interlinear Bible — na OHGB), kwa sababu vinaonyesha maneno katika mpangilio tofauti usiosoma kwa asili.

### 2. Juu ya sura (sura nzima)

Unaposoma sura, angalia mstari wa ikoni juu ya skrini. Bonyeza **Sikiliza** (🔊) kuanza kusoma sura nzima kutoka mwanzoni. Kitufe kinageuka kuwa kitufe cha kusimamisha (⏹) sauti ikiwa inacheza. Bonyeza tena kusimamisha. Ukanda huo wa udhibiti unaonekana chini.

Unaweza kuruka aya tofauti, na kitufe cha Sikiliza huko kitaanza kutoka aya hiyo badala yake.

### 3. Katika ibada

Fungua siku yoyote ya ibada, kisha bonyeza kitufe cha **Sikiliza** (🔊) juu ya kusoma. Maandiko yote ya ibada yanasomwa kwa sauti, sentensi kwa sentensi. Ukanda wa udhibiti chini unakupa kucheza, kupumzisha, kurudisha, na udhibiti wa sauti.

## Kutumia ukanda wa udhibiti

Sauti ikiwa inacheza, ukanda mdogo unabaki uko wazi chini ya skrini. Una udhibiti sita:

- ⏪ **Rudisha nyuma** — rudi aya moja nyuma (au sentensi moja katika ibada)
- ⏸ **Pumzisha / ▶ Endelea** — pumzisha bila kupoteza mahali ulipo. Bonyeza tena kuendelea kutoka mahali palepale.
- ⏩ **Harakisha** — ruka aya inayofuata (au sentensi inayofuata katika ibada)
- 🎙 **Sauti** — fungua kichagua sauti bila kutoka kwenye sura (ona chini)
- ⚙ **Chaguo** — fungua ubao wa chaguo za nyongeza (ona chini)
- **Simamisha** — bonyeza kitufe cha 🔊 juu ya skrini, au ⏹ inayobadilishana nake sauti ikiwa inacheza, kusimamisha na kufunga ukanda.

Ukanda wa udhibiti unafunga sura ikimaliza au ukibonyeza simamisha.

### Chaguo za nyongeza

Bonyeza ⚙ kupanua chaguo za nyongeza za kucheza. Mipangilio hii inaishi kwa sura ya sasa pekee na kurejea ukibadilisha sura au kusimamisha kusikiliza.

- ⏮ **Rudi mwanzoni** — ruka aya ya kwanza ya kikundi ulichoweka.
- **Mwanzo** — andika namba ya aya kuweka mahali kusoma kunaanzia.
- **Mwisho** — andika namba ya aya kuweka mahali kusoma kunasimama.
- **Zote** — weka upya kikundi kuwa sura nzima.
- **()** — badilisha ikiwa maandiko ndani ya mabano yanasomwa kwa sauti.
- 🔁 **Rudia** — anza upya mwanzoni mwa kikundi kwa njia yenyewe mwisho ukifika, ikiwa na mapumziko mafupi kati yake. Ukiuwasha bila kuweka aya ya mwanzo au mwisho, sura nzima inarudia.

### Katika skrini za maombi

Nguvu za imani na maombi ya wima, maombi yaliyotengenezwa, na routini za maombi vina seti yake ya chaguo za nyongeza. Bonyeza ⚙ katika ukanda wa udhibiti kuipanua:

- **Kasi** — bonyeza kiwango (kwa mfano `1x`) kuchagua kasi ya kusoma kutoka 0.1x hadi 1.5x. Uchaguzi wako unakumbukwa na kutumika wakati mwingine mwinasoma kitu kwa sauti.
- **()** — badilisha ikiwa maandiko ndani ya mabano yanasomwa kwa sauti.
- 🔁 **Rudia** — anza upya maombi kutoka mwanzoni kwa njia yenyewe yakimaliza, ikiwa na mapumziko mafupi kati yake. Hii inajifaa kujifunza nguvu ya imani au maombi ya wima kwa moyo.

Kubadilisha kasi kunatekelezwa mara moja, bila kupoteza mahali ulipo. Kuwasha au kuzima chaguo la mabano kunaanza maombi upya kutoka mwanzoni ili mabadiliko yasikilizwe kutoka mwanzoni.

## Namna ya kubadilisha sauti

Unaweza kuchagua sauti Theodia inayotumia kusoma. Hii inajifaa ukitaka lafudhi tofauti, lugha tofauti, au sauti ya haraka au ya polepole kuliko chaguomsingi ya kifaa.

1. Fungua **Mipangilio**.
2. Tafuta sehemu ya **Usemajuzi (Speech)**.
3. Bonyeza **Chagua Sauti**.
4. Orodha ya sauti inaonekana. Mstari wa kwanza, **Chaguomsingi ya Mfumo**, unatumia sauti kifaa chako kinachopenda. Chagua mstari mwingine wowote kuifanya chaguomsingi mpya.
5. Uchaguzi wako unahifadhiwa na kutumika wakati mwingine unabonyeza **Sikiliza** au **Soma**.

Unaweza pia kubonyeza ikoni ya 🎙 katika ukanda wa udhibiti wa kusikiliza kufungua kichagua kilekile bila kutoka kwenye sura.

Upatikanaji wa sauti unategemea kifaa chako kabisa. iOS na Android kila moja inakuja na seti ya sauti zilizojengwa ndani. Unaweza kusakinisha sauti zaidi kutoka mipangilio ya **Ufikiaji** au **Lugha na Uingizaji** ya kifaa chako. Theodia inaweza kutumia sauti yoyote iliyosakinishwa kwenye kifaa chako.

## Sauti zinazopendwa

Kifaa chako ikiwa kina sauti nyingi, kusugua orodha nzima kila mara kunaweza kuwa taratibu. Unaweza kutengeneza orodha fupi ya **sauti zinazopendwa** na vichagua vya sauti vitakupa sauti hizo tu.

1. Fungua **Mipangilio**.
2. Tafuta sehemu ya **Usemajuzi (Speech)**.
3. Bonyeza **Sauti Zinazopendwa** (mstari wa kwanza juu ya sehemu).
4. Bonyeza **Weka Sauti Zinazopendwa** kufungua skrini ya vipendwa.
5. Bonyeza kitufe cha kucheza pembeni ya sauti kuiangalia kwanza. Bonyeza nyota kuiweka kwenye vipendwa vyako. Unaweza kuweka sauti nyingi kama unavyotaka.
6. Rudi nyuma. Vichagua vya saoti katika Theodia sasa vinaonyesha sauti zako zinazopendwa tu.

Ukiondoa vipendwa vyote, vichagua vinarejea kuonyesha kila sauti. Sauti zinazopendwa zinajumuishwa unapohifadhi nakala na kurejesha mipangilio ya Theodia.

## Kuweka sauti tofauti kwa kila Biblia

Unaweza kumpa kila tafsiri ya Biblia sauti yake. Hii inajifaa unapobadilisha kati ya tafsiri zinazosoma tofauti sana — kwa mfano, sauti rasmi zaidi kwa King James Version na sauti ya mazungumzo zaidi kwa tafsiri ya kisasa kama NIV au NLT. Pia inasaidia ukiwa unasikiliza Biblia za lugha tofauti na unataka kila moja isemwe kwa lafudhi sahihi.

1. Fungua **Mipangilio**.
2. Tafuta sehemu ya **Usemajuzi (Speech)**.
3. Tafuta **Sauti za Biblia**.
4. Bonyeza Biblia yoyote katika orodha.
5. Chagua sauti unayotaka kwa tafsiri hiyo. Mstari wa kwanza, **Chaguomsingi ya Mfumo**, unatumia sauti yako kuu ya TTS kwa Biblia hiyo.
6. Rudia kwa Biblia nyingine yoyote.

Kichwa kinaonyesha ni tafsiri ngapi za Biblia zina sauti ya kipekee iliyowekwa. **Chagua Sauti**, **Sauti ya Mafafani**, **Sauti ya Maoni ya Biblia**, na **Sauti ya Ibada** pia vinaonyesha hesabu sauti ikiwa imewekwa.

Wakati mwingine mwinasikiliza sura kutoka Biblia hiyo, Theodia itatumia sauti uliyochagua. Biblia zote nyingine zinaendelea kutumia sauti kuu ya chaguomsingi mpaka uzibadilishe wewe pia.

## Kuendelea na usemu nyuma

Kwa chaguomsingi, Theodia inasimamisha usemu ukiondoka kwenye skrini ya msomaji, ukibadili kwenda programu nyingine, au ukiwaya simu. Hii inazuia sauti isiyelekelewa ukiwa hutendi kusoma tena.

Kuruhusu usemu kuendelea kucheza nyuma:

1. Fungua **Mipangilio**.
2. Tafuta sehemu ya **Usemajuzi (Speech)**.
3. Washa **Endelea na usemu nyuma**.

Hii ikiwa imewashwa, unaweza kubadilisha vichupo, kufungua programu nyingine, au kuwaya skrini na sura au ibada itaendelea kusoma. Ukanda wa udhibiti unabaki hai ili upumzishe au ukaeue kutoka eneo la taarifa (ikiwa kifaa chako kinaunga mkono).

Kuzima swichi hii **ikiwa** usemu unacheza tayari huuusimamisha mara moja.

## Cha kufanya ikiwa hakifanyi kazi

Kusoma kwa sauti kunategemea kifaa chako. Theodia inatuma maandiko kwenye mfumo wa uendeshaji, na mfumo wa uendeshaji unasoma kwa sauti. Usipofanya kazi, jaribu hatua hizi kwa mpangilio.

### Theodia inasema TTS haipatikani

Vifaa vingine havina TTS kabisa. Fungua **Mipangilio** na utafute sehemu ya **TTS**. Sehemu haipo, kifaa chako hakiungi mkono TTS katika ujenzi huu.

### Orodha ya sauti ni wazi

Kichagua sauti kinaweza kuonyesha "sauti hazipatikani." Hii kwa kawaida inamaanisha kifaa hakijamaliza kupakia sauti zake bado.

1. Fungua **Mipangilio → Usemajuzi → Chagua Sauti**.
2. Orodha ikiwa wazi, tafuta kitufe cha **Jaribu Tena** chini ya kidhibiti-sondli kabisa. Bonyeza. Theodia inauliza tena kifaa kwa sauti.
3. Ikiwa bado wazi, angalia mipangilio ya mfumo ya kifaa chako. Katika iOS, nenda **Mipangilio → Ufikiaji → Maudhui Yanayosemwa → Sauti** na upakue sauti ya lugha yako. Katika Android, nenda **Mipangilio → Lugha na Uingizaji → Pato la Text-to-Speech** na ubonyeze **Sakinisha data ya sauti**.
4. Funga na ufungue Theodia tena ili ipate sauti mpya.

Ukiwa umeweka sauti zinazopendwa na orodha ni wazi, hakikisha angalau moja ya vipendwa vyako inalingana na sauti iliyosakinishwa kwenye kifaa hiki.

### Bonyeza Soma lakini hakuna kinachotokea

- Hakikisha kifaa hakiko katika hali ya kimya. Vifaa vingi havichezi sauti ya TTS ikiwa katika hali ya kimya.
- Hakikisha sauti ya kifaa imeongezwa.
- Jaribu kitufe cha **Jaribu Tena** katika **Mipangilio → Usemajuzi**.
- Fungua **Mipangilio** na uangalie sehemu ya **Mfumo** chini. Mstari wa **TTS** unapaswa kusema **Inapatikana**. Ukisema **Haipatikani**, TTS imezimwa katika ngazi ya mfumo wa uendeshaji. Iwashe tena huko, kisha ufungue Theodia tena.

### Sauti inacheza lakini ni lugha isiyo sahihi

Theodia inatuma maandiko katika lugha ya maudhui ya sasa na kuiomba kifaa sauti uliyochagua. Sauti iliyochagua ikiwa ya lugha tofauti, kifaa kinaweza bada kusoma maandiko, lakini kitasikika kizushi.

1. Fungua **Mipangilio → Usemajuzi → Chagua Sauti**.
2. Chagua **Chaguomsingi ya Mfumo** kuruhusu kifaa kuchagua sahihi, au chagua sauti yenye lugha inayolingana na unachosoma.

Theodia kwa sasa haisomi Biblia za mstari-ku-mstari za Kigiriki au Kiebrania kwa sauti. Vitufe vya Soma na Sikiliza vimefichwa katika tafsiri hizo.

### Sauti inacheza lakini inasimamisha mapema

Aya ikikosekana au isisomekane, sura inaruka ijayo. Ukanda ukifunga yenyewe baada ya aya chache, bonyeza kitufe cha **Sikiliza** (🔊) juu ya skrini kuanza upya.

### Sauti inacheza lakini sijui ilianza wapi

Ukiwa umewasha **Endelea na usemu nyuma** na baadaye ukipata sauti bila kupata skrini iliyoiwasha, unaweza kuisimamisha kutoka popote katika programu.

1. Fungua **Mipangilio**.
2. Tafuta sehemu ya **Usemajuzi (Speech)**.
3. Bonyeza kitufe cha kitamu cha **Simamisha Usemu** chini ya sehemu.

Hii inasimamisha mara moja kusoma kwa sauti kulikotembea katika Theodia. Unaweza pia kufungua kibadilisha programu kwenye kifaa chako na kusukuma Theodia mbali kusimamisha sauti kwa nguvu.

### Inasoma haraka sana au polepole sana

Theodia haidhibiti kasi ya kusoma. Kasi imewekwa na sauti iliyochagua. Kubadilisha:

- Katika iOS: **Mipangilio → Ufikiaji → Maudhui Yanayosemwa → Kasi ya Usemu**.
- Katika Android: **Mipangilio → Lugha na Uingizaji → Pato la Text-to-Speech → Kasi ya Usemu**.

## Vidokezo

- Ukanda wa udhibiti unabaki wazi unapotembea kati ya sura, ili upumzishe, ukaeue, au ubadilishe sauti bila kupoteza mahali ulipo.
- Theodia inasoma namba za aya kama mapumziko madogo. Unaweza kusimamisha ukanda, kuvuta kidole aya tofauti, kisha kubonyeza kucheza kuendelea kutoka huko.
- Kwa kusikiliza muda mrefu, washa **Usinisumbue** ili taarifa zisikatie sauti.
- Kitufe cha 🔊 kinatumia sauti ya sasa ya kifaa chako. Ukiingiza sikio-sauti, sauti inabadilika kwenda ngazi ya sikio-sauti.

## Kusoma PDF kwa sauti

Theodia inaweza pia kusoma kurasa za PDF kwa sauti. Fungua PDF na bonyeza kitufe cha **Sikiliza** (spika) katika ukanda wake wa zana. Ukanda wa udhibiti unaonekana wenye kucheza/kupumzisha, kurudisha, kuharakisha, kusimamisha, ukanda wa maendeleo, na vichagua vya kasi na sauti. Ukurasa ukimaliza, kusoma kunaendelea kwenye ukurasa ufuatao kwa njia yenyewe.

Kusoma PDF kinatumia maandiko yanayotafutika yaliyowasilishwa ya PDF na sauti na kasi zile zile za kusoma Biblia.

## Miongozo inayohusiana

- Mwongozo wa [Hali ya Kujifunza](theodia://help/study-mode) unashughulikia menyu ya aya na vitufe vya juu ya skrini kwa undani zaidi.
- Mwongozo wa [Hali ya Umakini](theodia://help/focus-mode) ni mtazamo safi wa kusoma unaounga mkono TTS pia kwa kitufe cha 🔊 katika ukanda wa chini.
- Mwongozo wa [Matatizo ya Kawaida](theodia://help/common-problems) una marekebisho ya matatizo mengine ya sauti, sauti, na lugha.
- Mwongozo wa [Ibada za Kila Siku](theodia://help/daily-devotionals) unashughulikia kusoma ibada na mahali kitufe cha kusikiliza kiko katika skrini hiyo.
- Mwongozo wa [PDF](theodia://help/pdfs) unashughulikia msomaji wa PDF na kitufe chake cha kusikiliza.
