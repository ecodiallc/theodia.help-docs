---
title: Karibu Theodia
level: beginner
categories: welcome
summary: Ziara fupi ya programu na yale inayoweza kufanya kwako.
---

# Karibu Theodia

Theodia ni programu ya kusoma na kujifunza Biblia. Inafanya kazi kwenye simu yako au kompyuta kubwa (tablet), hata usipopata intaneti. Kila kitu unachosoma, kutafuta, na kujifunza huhifadhiwa kwenye kifaa chako.

## Unachoweza kufanya

Theodia ina hali tatu za mtumiaji. Kila hali inaonyesha seti tofauti ya vipengele.

- **Msomaji (Reader)** — soma Biblia kwa mtazamo safi, bila vitu vinavyovuruga.
- **Kawaida (Standard)** — kila kitu kilicho katika Msomaji, pamoja na alamisho, rangi, maoni, kusoma kwa sauti, utafutaji, na ibada za kila siku.
- **Mtaalamu (Scholar)** — kila kitu kilicho katika Kawaida, pamoja na mafafani, kamusi ya asili, Kamusi ya Biblia, msaidizi wa AI, na mengi zaidi.

Unaweza kubadilisha hali wakati wowote katika **Mipangilio** → **Hali ya Mtumiaji wa Programu**.

### Vipengele vinavyopatikana kwako

Kuchagua hali yoyote, daima unaweza:

- **Kusoma Biblia.** Chagua kutoka kwa tafsiri nyingi. Badilisha wakati wowote.
- **Kutafuta Biblia.** Tafuta neno au msemo. Programu inakuonyesha kila aya inayolingana.
- **Kusoma vitabu na ibada.** Programu inakuja na vitabu vya kifalsafa ya Kikristo vya kale na ibada ya kila siku.

Kutegemea hali yako, unaweza pia:

- **Kusikiliza.** Aya kusomwa kwa sauti kwa kipengele cha kusoma kwa sauti. (Kawaida na Mtaalamu.)
- **Kuandika maoni.** Andika mawazo yako pembeni ya aya. (Kawaida na Mtaalamu.)
- **Kuweka rangi.** Weka alama za rangi kwenye aya unazozipenda. (Kawaida na Mtaalamu.)
- **Kuweka alamisho.** Hifadhi aya ili uziyepukane haraka. (Kawaida na Mtaalamu.)
- **Kuuliza msaidizi wa AI.** Pata msaada wa kuelewa aya. (Mtaalamu pekee.)

## Pa kuanzia

1. Fungua kichupo cha **Biblia** chini ya skrini.
2. Chagua tafsiri.
3. Bonyeza kitabu chochote kuanza kusoma.

Ukitaka kujifunza zaidi, miongozo mingine ya msaada ipo hapa kwa ajili yako. Chagua mada kutoka kwenye orodha ya ukurasa wa nyumbani wa msaada.

## Mambo machache ya kujua

- Hauitaji akaunti.
- Maoni, rangi, na alamisho vyako vinabaki kwenye kifaa chako.
- Unaweza kuhifadhi nakala yake. Ona miongozo ya [Kuhifadhi Nakala za Takwimu Zako](theodia://help/backups) kwa namna.

## Unataka nyenzo zaidi?

Programu inakuja na tafsiri kadhaa za Biblia zinazopatikana bure. Kwa Biblia za nyongeza, mafafani, kamusi za asili, vitabu, na ibada, ona miongozo ya [Kupata Nyenzo za Nyongeza kutoka GitHub](theodia://help/getting-core-files). Inaonyesha namna ya kupata na kuongeza nyenzo zaidi kutoka ukurasa wa GitHub wa mradi.

Karibu. Tunatumaini Theodia itakusaidia kusoma na kujifunza.
