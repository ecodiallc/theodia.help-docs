---
title: Nyenzo ni nini?
level: beginner
categories: resources
summary: Muhtasari wa aina tofauti za faili Theodia inazitumia — Biblia, mafafani, vitabu, na mengine.
---

# Nyenzo ni nini?

Katika Theodia, "nyenzo" ni faili lolote linaloongeza nyenzo za kusoma au kujifunza kwenye programu. Programu yenyewe ni msomaji na daftari tu. Biblia, mafafani, vitabu, na vifaa vingine unavyojifunza navyo ni faili tofauti unazopakia.

Mwongozo huu unaeleza aina tofauti za nyenzo na kila moja inalenga nini.

## Kwa nini hili ni muhimu?

Ukifungua Theodia kwa mara ya kwanza, tayari ina vitu vichache vya kusoma. Unapotembea, utaona vitufe vya kusakinisha zaidi. Kujua kila aina ya nyenzo ni nini kutakusaidia kuamua cha kuongeza.

## Aina tofauti za nyenzo

Theodia inatambua faili kwa kiambishi chake. Kila kiambishi ni aina tofauti ya nyenzo.

### `.bible` — tafsiri ya Biblia

Tafsiri ya Biblia ni nakala kamili ya Biblia katika toleo mahususi, kama King James Version. Theodia inakuja na tafsiri chache na hukuruhusu kuongeza zaidi.

Ona mwongozo wa [Kusakinisha Tafsiri za Biblia](theodia://help/installing-bibles) kwa maelezo.

### `.commentary` — mafafani

Mafafani ni kitabu cha maoni ya kujifunza yaliyoandikwa na mtaalamu wa Biblia. Kwa aya mahususi, mafafani yanakuambia mandhari, maana, na jinsi aya inavyoingia katika Biblia nzima.

Ona mwongozo wa [Mafafani na Kamusi za Asili](theodia://help/commentaries-and-lexicons) kwa maelezo.

### `.lexicon` — kamusi ya asili

Kamusi ya asili ni kamusi ya maneno ya Biblia. Inakuambia neno asilia la Kiebrania au Kigiriki, lina maana nini, na linatumiwaje Biblini.

Ona mwongozo wa [Mafafani na Kamusi za Asili](theodia://help/commentaries-and-lexicons) kwa maelezo.

### `.book` — kitabu cha Kikristo

Kitabu ni kazi ndefu ya Kikristo, kama kifalsafa cha kale kutoka historia ya kanisa. Kusoma vitabu katika programu kunafanya kama kusoma Biblia. Theodia inakuja na maktaba ndogo ya kifalsafa cha Kikristo cha bure.

Ona mwongozo wa [Kusoma Vitabu Vilivojengwa Ndani](theodia://help/reading-books) kwa maelezo.

### `.devotional` — ibada

Ibada ni kusoma fupi cha kila siku. Kila ingizo kwa kawaida kina aya, tafakari fupi, na maombi au swali la kufikiri. Ibada nyingi zimeundwa kusomwa ingizo moja kwa siku kwa mwaka.

Ona mwongozo wa [Ibada za Kila Siku](theodia://help/daily-devotionals) kwa maelezo.

### `.sqlite` — hifadhidata ya marejeleo

Hifadhidata ya marejeleo ni faili kubwa la utafutaji programu inalitumia kukupa taarifa za nyongeza unaposoma. Kuna aina mbili:

- **Marejeleo** — orodha za aya zinazounganishwa na aya unayosoma.
- **Umbolelogia** — taarifa kuhusu maneno asilia ya Kiebrania au Kigiriki katika aya.

Hauyafungui moja kwa moja. Zinafanya kazi nyuma na kuongeza vipengele kwenye msomaji wa Biblia. Ona mwongozo wa [Marejeleo](theodia://help/cross-references) kwa maelezo.

### `.data` — takwimu za maneno

Faili la takwimu za maneno lina taarifa za nyongeza kuhusu maneno asilia ya Biblia. Linalitumiwa na kamusi ya asili na zana za kujifunza. Kama hifadhidata za marejeleo, haulifungui moja kwa moja. Programu inalitumia nyuma.

## Namna ya kuongeza nyenzo

Skrini ya **Dhibiti Nyenzo** ya programu ni njia rahisi ya kuongeza nyenzo.

1. Fungua **Mipangilio**.
2. Bonyeza **Dhibiti Nyenzo**.
3. Bonyeza **Sakinisha kutoka GitHub**.
4. Katika kidude cha kupakua, chagua kichupo — **Biblia**, **Mafafani**, **Vitabu**, **Ibada**, au **Msingi (Core)** — kisha chague unachotaka na bonyeze **Sakinisha Zilizochaguliwa**.
5. Au bonyeza **Sakinisha Faili la Ndani** kuingiza faili ulilopakua tayari.

Kwa ziara ya hatua kwa hatua ya kupata faili moja kwa moja kutoka GitHub, ona mwongozo wa [Kupata Nyenzo za Nyongeza kutoka GitHub](theodia://help/getting-core-files).

## Namna ya kuondoa nyenzo

1. Fungua **Mipangilio**.
2. Bonyeza **Dhibiti Nyenzo**.
3. Tafuta nyenzo unayotaka kuondoa.
4. Bonyeza ikoni ya kipuuzi pembeni yake.
5. Thibitisha unataka kuiondoa.

Kuondoa nyenzo hakufuti maoni, rangi, au alamisho zako. Yazo yanabaki salama.

## Nyenzo zinaishi wapi kwenye kifaa chako

Nyenzo zimehifadhiwa kwenye kifaa chako, sio wingu. Nyenzo ikisakinishwa, hauitaji intaneti kuisoma. Unaweza kuhifadhi nakala ya kifaa chako, lakini nyenzo zenyewe hazihifadhiwi kwenye wingu na Theodia. Ukiondoa na kusakinisha programu upya, utahitaji kuongeza tena nyenzo zozote ulizosakinisha.

## Msaada na maswali

Ukikwama, ona mwongozo wa [Maswali Yanaulizwa Wapi?](theodia://help/getting-more-help). Timu na jumuiya wanaweza kusaidia.
