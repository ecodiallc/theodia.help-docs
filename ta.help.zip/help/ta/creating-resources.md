---
title: உங்கள் சொந்த வளங்களை உருவாக்குதல்
level: advanced
categories: resources
summary: தனிப்பயன் வேதாகமங்கள், விரிவுரைகள், புத்தகங்கள், தியானங்கள் மற்றும் அகராதிகளை உருவாக்கி Theodia இல் இறக்குமதி செய்வது எப்படி.
---

# உங்கள் சொந்த வளங்களை உருவாக்குதல்

Theodia Unique Bible App வடிவத்தில் தனிப்பயன் வளங்களை ஆதரிக்கிறது. ஒவ்வொரு வளமும் ஒரு குறிப்பிட்ட அட்டவணை அமைப்பு கொண்ட SQLite கோப்பாகும். இந்தக் கோப்புகளை கணினியில் உருவாக்கி செயலியில் இறக்குமதி செய்யலாம்.

## கோப்பு வகைகளும் தேவைப்படும் அட்டவணைகளும்

### வேதாகமங்கள் (`.bible`)

ஒரு வேதாகமக் கோப்பு குறைந்தபட்சம் பின்வரும் அட்டவணைகளில் ஒன்றைக் கொண்ட ஒரு SQLite தரவுத்தளம்:

- **`Verses`** — நெடுவரிசைகள்: `Book` (முழு எண், 1-66), `Chapter` (முழு எண்), `Verse` (முழு எண்), `Scripture` (உரை)
- **`Bible`** — நெடுவரிசைகள்: `Book` (முழு எண்), `Chapter` (முழு எண்), `Verse` (முழு எண்), `Scripture` (உரை)

மேட்டா தரவு நெடுவரிசைகளான `Description`, `Abbreviation`, `Version` ஆகியவற்றைக் கொண்ட **`Details`** அட்டவணையையும் சேர்க்கலாம்.

எடுத்துக்காட்டு SQL:

```sql
-- Main text table
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- Optional metadata table
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### விரிவுரைகள் (`.commentary`)

விரிவுரைகள் மூன்று வகைகளில் வருகின்றன: **புத்தகம்**, **அதிகாரம்**, மற்றும் **வசனம்**. வகை **கோப்பின் பெயரின் முதல் எழுத்தால்** தீர்மானிக்கப்படுகிறது.

#### புத்தக விரிவுரைகள் — பெயர் `b` எனத் தொடங்கும்

ஒரு புத்தக விரிவுரை ஒரு வேதாகமப் புத்தகத்தின் முழுவதையும் ஒரே உள்ளீட்டில் உள்ளடக்குகிறது. `Commentary` அட்டவணைக்கு `Book` மற்றும் `Scripture` (அல்லது `Content`) நெடுவரிசைகள் தேவை. `Chapter` அல்லது `Verse` நெடுவரிசைகள் தேவையில்லை.

- **`Commentary`** — நெடுவரிசைகள்: `Book` (முழு எண்), `Scripture` (உரை) அல்லது `Content` (உரை)

எடுத்துக்காட்டு SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

கோப்பு பெயர் எடுத்துக்காட்டு: `bMyCommentary.commentary`

#### அதிகார விரிவுரைகள் — பெயர் `c` எனத் தொடங்கும்

ஒரு அதிகார விரிவுரை ஒரு வேதாகமப் புத்தகத்தின் ஒவ்வொரு அதிகாரத்தையும் உள்ளடக்குகிறது.

- **`Commentary`** — நெடுவரிசைகள்: `Book` (முழு எண்), `Chapter` (முழு எண்), `Scripture` (உரை) அல்லது `Content` (உரை)

எடுத்துக்காட்டு SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

கோப்பு பெயர் எடுத்துக்காட்டு: `cMyCommentary.commentary`

#### வசன விரிவுரைகள் — பெயர் `v` எனத் தொடங்கும்

ஒரு வசன விரிவுரை தனிப்பட்ட வசனங்களை உள்ளடக்குகிறது. `Commentary` அட்டவணைக்கு `Book`, `Chapter`, `Verse`, மற்றும் `Scripture` (அல்லது `Content`) நெடுவரிசைகள் தேவை.

- **`Commentary`** — நெடுவரிசைகள்: `Book` (முழு எண்), `Chapter` (முழு எண்), `Verse` (முழு எண்), `Scripture` (உரை) அல்லது `Content` (உரை)

எடுத்துக்காட்டு SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

கோப்பு பெயர் எடுத்துக்காட்டு: `vMyCommentary.commentary`

### புத்தகங்கள் (`.book`)

ஒரு புத்தகக் கோப்பு `Reference` அட்டவணை கொண்ட ஒரு SQLite தரவுத்தளம்.

- **`Reference`** — நெடுவரிசைகள்: `id` (முழு எண்), `Chapter` (உரை), `Content` (உரை)

ஒவ்வொரு வரியும் ஒரு அதிகாரம். `Chapter` நெடுவரிசை அதிகாரத்தின் தலைப்பு. `Content` நெடுவரிசை அதிகாரத்தின் உடல், இது HTML (`<b>`, `<i>`, `<br>`, போன்றவை) உள்ளடக்கலாம்.

எடுத்துக்காட்டு SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

Markdown கோப்புகளிலிருந்தும் புத்தகங்களை உருவாக்கலாம். `#` புத்தகத் தலைப்பாகவும் `##` அதிகாரங்களைக் குறிக்கவும் பயன்படுத்தும் `.md` கோப்புகளைச் செயலி இறக்குமதி செய்யும். Markdown தானாக HTML ஆக மாற்றப்படும்.

### தியானங்கள் (`.devotional`)

ஒரு தியானக் கோப்பு `devotional` அட்டவணை கொண்ட ஒரு SQLite தரவுத்தளம்.

- **`devotional`** — நெடுவரிசைகள்: `month` (முழு எண், 1-12), `day` (முழு எண், 1-31), `devotion` (உரை)

ஒவ்வொரு வரியும் ஒரு நாளின் வாசிப்பு. செயலி இன்றைய மாதம் மற்றும் நாளின் அடிப்படையில் உள்ளீட்டைத் தேடுகிறது.

எடுத்துக்காட்டு SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### அகராதிகள் (`.lexicon`)

ஒரு அகராதிக் கோப்பு `Lexicon` அட்டவணை கொண்ட ஒரு SQLite தரவுத்தளம்.

- **`Lexicon`** — நெடுவரிசைகள்: `Topic` (உரை, Strong's எண்), `Definition` (உரை, அகராதி உள்ளீடு)

`Topic` நெடுவரிசை Strong's எண்ணை வைத்திருக்கும் (உதாரணமாக, `G1161` அல்லது `H7225`). `Definition` நெடுவரிசை முழு உள்ளீட்டு உரையை வைத்திருக்கும், இது HTML உள்ளடக்கலாம்.

எடுத்துக்காட்டு SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

அகராதிகள் Word Info கருவிக்கு ஆற்றல் அளிக்கின்றன. ஒரு இடைநிலை (interlinear) வேதாகமத்தில் நீங்கள் ஒரு சொல்லைத் தட்டும்போது, செயலி நிறுவப்பட்ட அகராதிகளில் Strong's எண்ணைத் தேடுகிறது.

## கணினியில் ஒரு கோப்பை உருவாக்குதல்

1. ஒரு SQLite திருத்தியை நிறுவவும் (DB Browser for SQLite, SQLiteStudio, அல்லது `sqlite3` கட்டளை-வரி கருவி).
2. ஒரு புதிய தரவுத்தளக் கோப்பை உருவாக்கவும்.
3. தேவைப்படும் அட்டவணையை உருவாக்கி உங்கள் தரவைச் செருகவும்.
4. சரியான நீட்டிப்புடன் கோப்பைச் சேமிக்கவும் (`.bible`, `.commentary`, `.book`, `.devotional`, அல்லது `.lexicon`).

## Theodia இல் இறக்குமதி செய்தல்

1. கோப்பை உங்கள் சாதனத்திற்கு மாற்றவும் (AirDrop, மின்னஞ்சல், மேக சேமிப்பு, அல்லது USB).
2. **Theodia** வைத் திறக்கவும்.
3. **Settings** → **Manage Resources** க்குச் செல்லவும்.
4. **Import from File** ஐத் தட்டவும்.
5. உங்கள் கோப்பைத் தேர்ந்தெடுக்கவும்.

செயலி கோப்பைச் சரிபார்க்கிறது (தேவையான அட்டவணை உள்ளதா எனச் சோதிக்கிறது), செயலியின் தரவுக் கோப்புறைக்கு நகலெடுத்து, தானாக இயக்குகிறது. கோப்பு தவறானதாக இருந்தால், தவறு என்ன என்பதை விளக்கும் ஓர் பிழைச் செய்தியைக் காண்பீர்கள்.

## வரம்புகள்

- உள்ளமைக்கப்பட்ட வளங்களை நீங்கள் மேலெழுத முடியாது. உள்ளமைக்கப்பட்ட வேதாகமம், விரிவுரை அல்லது புத்தகத்தின் பெயருடன் ஒத்த பெயரில் ஒரு கோப்பை இறக்குமதி செய்ய நீங்கள் முயற்சித்தால், இறக்குமதி தோல்வியடையும்.
- வேதாகமக் கோப்புகளுக்கு `Verses` அல்லது `Bible` அட்டவணை தேவை. இரண்டும் இல்லாவிட்டால், இறக்குமதி தோல்வியடையும்.
- விரிவுரைக் கோப்புகளுக்கு `Commentary` அட்டவணை தேவை.
  - புத்தக விரிவுரைகளுக்கு `Book` மற்றும் `Scripture` (அல்லது `Content`) நெடுவரிசைகள் தேவை.
  - அதிகார விரிவுரைகளுக்கு `Book`, `Chapter`, மற்றும் `Scripture` (அல்லது `Content`) நெடுவரிசைகள் தேவை.
  - வசன விரிவுரைகளுக்கு `Book`, `Chapter`, `Verse`, மற்றும் `Scripture` (அல்லது `Content`) நெடுவரிசைகள் தேவை.
- புத்தகக் கோப்புகளுக்கு `Reference` அட்டவணை தேவை.
- அகராதிக் கோப்புகளுக்கு `Lexicon` அட்டவணை தேவை.
- தியானக் கோப்புகளுக்கு `devotional` அட்டவணை தேவை.

## குறிப்புகள்

- கோப்பு அளவுகளை நியாயமான அளவில் வைக்கவும். மிகப் பெரிய SQLite கோப்புகள் பழைய சாதனங்களில் நினைவகச் சிக்கல்களை ஏற்படுத்தலாம்.
- முதலில் உங்கள் கோப்பை கணினியில் சோதிக்கவும். SQLite உலாவியில் திறந்து, தேவையான அட்டவணையிலிருந்து `SELECT * FROM` ஐ இயக்கி தரவு சரியாகத் தோன்றுகிறதா எனச் சரிபார்க்கவும்.
- வேதாகமங்களுக்கு, `Book` நெடுவரிசை எண்களைப் பயன்படுத்துகிறதா என உறுதிப்படுத்தவும் (1 = ஆதியாகமம், 66 = வெளிப்படுத்தல்).
- விரிவுரைகளுக்கு, `Scripture` அல்லது `Content` என்பதை விரிவுரை உரை நெடுவரிசையாகப் பயன்படுத்தலாம்.
- புத்தகங்களுக்கு, `Content` நெடுவரிசையில் உள்ள HTML படிக்கும்போது காட்டப்படும். அதை எளிமையாக வைக்கவும்: `<b>`, `<i>`, `<br>`, மற்றும் `<hr>` பாதுகாப்பானவை.

## ஏற்கனவே உள்ள வளங்களை எங்கே காணலாம்

Theodia [Unique Bible App](https://github.com/eliranwong/UniqueBible) திட்டத்தின் வளங்களைப் படிக்க முடியும். பல வேதாகமங்கள், விரிவுரைகள், புத்தகங்கள் மற்றும் பிற வளங்கள் சரியான SQLite வடிவத்தில் அங்கு கிடைக்கின்றன. அவற்றைக் கண்டுபிடித்துச் சேர்ப்பது எப்படி என்பதற்கு [Getting Extra Resources](theodia://help/getting-core-files) வழிகாட்டியைப் பார்க்கவும்.
