---
title: Launcher Menu
level: everyday
categories: layout
summary: தற்போதைய திரையை விட்டு வெளியேறாமல், recent verses க்கு jump செய்ய, commands இயக்க, மற்றும் Bible layouts மாற்ற விரைவான வழி.
---

# Launcher Menu

> **முறை:** Launcher Menu க்கு **Scholar** முறை தேவை. முறைகளை **Settings** → **App User Mode** இல் மாற்றலாம்.

Launcher Menu என்பது செயலியில் கிட்டத்தட்ட எங்கிருந்தும் திறக்கக்கூடிய விரைவான அணுகல் panel ஆகும். உங்கள் recent verses, commands, மற்றும் சேமிக்கப்பட்ட Bible setups அனைத்தையும் ஒரே இடத்தில் வைத்திருக்கிறது.

## அதை எவ்வாறு திறப்பது

home screen header இன் மேல் வலது மூலையில் உள்ள **expand icon (⌄)** ஐத் தட்டவும். ஒரு panel மேலிருந்து உருட்டிக் கொண்டு வரும்.

## இதில் என்ன இருக்கிறது

### 1. Command Box

panel இன் மேலே ஒரு keyboard icon உடன் கூடிய text box உள்ளது. ஒரு command ஐ தட்டச்சு செய்து உங்கள் keyboard இல் **Go** தட்டவும். செயலி command ஐ வாசித்து உங்களை நேரடியாக அங்கே அழைத்துச் செல்கிறது.

உதாரணங்கள்:

- `John 3:16` — அந்த வசனத்தைத் திறக்கிறது.
- `search love` — பைபிளில் "love" என்பதைத் தேடுகிறது.
- `bookmark psalms 23` — வசனத்தை bookmark ஆக்குகிறது.
- `kjv` — KJV மொழிபெயர்ப்புக்கு மாறுகிறது.

Commands இன் முழுப் பட்டியலுக்கு, [Commands](theodia://help/commands) வழிகாட்டியைப் பாருங்கள்.

### 2. Parallel Sets

நீங்கள் saved parallel Bible presets வைத்திருந்தால், அவை இங்கே collapsible list ஆகத் தோன்றும். ஒன்றைத் தட்டி அந்த parallel setup ஐ உடனே load செய்யவும்.

Parallel preset உருவாக்க:

1. **Settings** → **Parallel Bible** திறக்கவும்.
2. மொழிபெயர்ப்புகளைச் சேர்த்து **Save Preset** ஐத் தட்டவும்.
3. அதற்கு ஒரு பெயர் கொடுங்கள். அது Launcher Menu இல் தோன்றும்.

Launcher Menu இல் ஒரு parallel set ஐ நீண்ட தட்டி delete செய்யவும்.

### 3. Bible Collections

Bible Collections என்பவை தகுந்த நேரத்தில் translation மற்றும் parallel view ஐ ஒரே நேரத்தில் மாற்றும் one-tap shortcuts ஆகும். நீங்கள் உருவாக்கியவை இருந்தால், அவை இங்கே collapsible list ஆகத் தோன்றும்.

Collection ஐ நீண்ட தட்டி delete செய்யவும்.

### 4. Feature Icons

command box க்கு கீழே round emoji buttons இன் ஒரு row இை காணலாம். இவை செயலியின் major features க்கான one-tap shortcuts ஆகும்.

கிடைக்கும் icons:

- **About**, **Bibles**, **Bible Notes**, **Bookmarks**, **Books**
- **Devotionals**, **Flashcards**, **Help**, **Highlights**
- **Playlists**, **Plugins**, **Search**, **Settings**, **Theoscript**

எந்த icons தோன்ற வேண்டும் மற்றும் எந்த order இல் இருக்க வேண்டும் எனத் தேர்ந்தெடுக்க:

1. **Settings** → **Launcher Menu** திறக்கவும்.
2. **Launcher Menu Icons** ஐத் தட்டவும்.
3. ஒவ்வொரு icon ஐயும் show அல்லது hide செய்ய switches பயன்படுத்தவும்.
4. நீங்கள் enable செய்துள்ளவற்றை reorder செய்ய up/down arrows பயன்படுத்தவும்.

Settings இல் உள்ள order தான் Launcher Menu இல் தோன்றும் order.

### 5. Recent Verses

செயலி நீங்கள் திறந்த last chapters மற்றும் verses ஐ நினைவில் வைத்திருக்கிறது. அவை panel இன் கீழே list ஆகத் தோன்றும். எந்த entry ஐயும் தட்டி நேரடியாக அங்கே jump செய்யவும்.

- **Tap** திறக்க.
- List இலிருந்து நீக்க **Swipe left** அல்லது **long-press**.
- எல்லா entries ஐயும் ஒரே நேரத்தில் நீக்க **Clear all** ஐத் தட்டவும்.

## Launcher Menu ஐ எப்போது பயன்படுத்துவது

நீங்கள் விரும்பும்போது:

- நீங்கள் இப்போதே வாசித்த வசனத்துக்கு மீண்டும் jump செய்ய.
- Home screen க்குச் செல்லாமல் command ஐ தட்டச்சு செய்ய.
- Translation அல்லது parallel setup ஐ ஒரே tap இல் மாற்ற.
- செயலியில் எங்கிருந்தும் major feature ஒன்றைத் திறக்க.
- பட்டியல்கள் மூலம் navigate செய்யாமல் அவசரமாக ஏதேனும் சரிபார்க்க.

## குறிப்புகள்

- Launcher Menu கிட்டத்தட்ட ஒவ்வொரு screen இலும் கிடைக்கிறது — chapter வாசிக்கும்போதும் நீங்கள் அதைத் திறக்கலாம்.
- Command box அதே commands ஐ ஆதரிக்கிறது, home screen command box எது ஆதரிக்கிறதோ அதை.
- Feature icons மற்றும் அவற்றின் order உங்கள் சாதனத்திலேயே locally save ஆகின்றன. அவை app restart க்கும் தாங்கும்.
- Recent verses உங்கள் சாதனத்திலேயே locally save ஆகின்றன. அவை app restart க்கும் தாங்கும்.