---
title: அறிவிக்கைகள் மற்றும் நினைவூட்டல்கள்
level: everyday
categories: [settings]
summary: வேண்டுதல், devotionals, பைபிள் plans, மற்றும் மேலும் பலவற்றுக்கான offline நினைவூட்டல்களை on, customize, மற்றும் manage செய்வது எவ்வாறு.
---

# அறிவிக்கைகள் மற்றும் நினைவூட்டல்கள்

Theodia வேண்டுதல், devotionals, பைபிள் plans, flashcards, மற்றும் பிற செயல்பாடுகளை — app offline ஆக இருந்தாலும் கூட — நினைவூட்டலாம். அனைத்து நினைவூட்டல்களும் உங்கள் சாதனத்திலேயே schedule செய்யப்படுகின்றன; internet connection அல்லது push-notification server தேவையில்லை.

## நினைவூட்டல்களை on அல்லது off செய்வது எவ்வாறு

1. **Settings** திறக்கவும்.
2. **Notifications** தட்டவும்.
3. **Enable reminders** ஐ on அல்லது off செய்யவும்.

முதல் முறை reminders இயக்கும்போது, notification அனுப்ப permission கேட்டு app கேட்கும். Reminders தோன்றுவதற்காக **Allow** தட்டவும்.

நீங்கள் ஏற்கனவே permission denied செய்திருந்தால், iOS அல்லது Android request ஐ block செய்யலாம். அப்படியானால், உங்கள் சாதனத்தின் **Settings** app-க்குச் சென்று **Theodia** கண்டுபிடித்து அங்கே notifications enable செய்யவும்.

## நினைவூட்டல் வகைகள்

notifications screen channels ஆகப் பிரிக்கப்பட்டுள்ளது. ஒவ்வொரு channel உம் independently on அல்லது off செய்யக்கூடிய reminders குடும்பமாகும்:

- **Prayer reminders** — பொது prayer reminders.
- **Prayer routine** — ஒரு குறிப்பிட்ட prayer routine-உடன் தொடர்பான reminders.
- **Devotional** — தினசரி verse அல்லது devotional reminder.
- **Bible plan reminders** — ஒரு active பைபிள் plan-க்கான reminders.
- **Theoscript reminders** — ஒரு Theoscript run செய்ய நினைவூட்டல்கள்.
- **AI insight reminders** — AI-மூலம் உருவாக்கப்பட்ட reminders.
- **Flashcard review reminders** — flashcards review செய்ய prompt-கள்.
- **Reading habit reminders** — தினசரி reading-habit prompts.
- **Liturgical & seasonal reminders** — church calendar-உடன் தொடர்பான reminders.
- **My reminders** — bookmarks, highlights, playlists, பைபிள் chapters, அல்லது books-இலிருந்து நீங்கள் உருவாக்கிய reminders.
- **Custom reminders** — நீங்களே முழுமையாக உருவாக்கும் reminders.

ஒரு channel தட்டி அதன் reminders ஐ பார்க்கவும், time மாற்றவும், எந்த days இல் fires ஆகும் என்பதை தேர்ந்தெடுக்கவும், அல்லது off செய்யவும்.

## Custom reminders

Custom reminders என்பவை நீங்கள் scratch-இலிருந்து build செய்யும் reminders ஆகும்.

1. **Settings** → **Notifications**-ல், **Custom reminders** தட்டவும்.
2. **+** பொத்தான் தட்டவும்.
3. **Title** மற்றும் **Message** இடுகவும்.
4. ஒரு **Time** தேர்ந்தெடுக்கவும்.
5. எந்த **Days** இல் repeat ஆகும் என்பதை தேர்ந்தெடுக்கவும்.
6. Reminder தட்டும்போது எது open ஆகும் என்பதை தேர்ந்தெடுக்கவும் (optional).
7. **Save** தட்டவும்.

List-ல் அதைத் தட்டி எப்போதும் custom reminder ஐ edit அல்லது delete செய்யலாம்.

## ஒரு reminder தட்டும்போது என்ன நடக்கும்

பெரும்பாலான reminders app-ல் ஒரு குறிப்பிட்ட screen திறக்கின்றன. உதாரணமாக, ஒரு prayer routine reminder அந்த routine திறக்கிறது; ஒரு பைபிள் plan reminder அடுத்த reading திறக்கிறது.

Reminder-க்கு linked screen இல்லை என்றால், app Home screen-க்குத் திறக்கிறது.

## Quiet hours

Quiet hours notification sounds ஐ silence செய்தபடியும் visual reminders காட்சிப்படுத்த அனுமதிக்கிறது.

1. **Settings** → **Notifications**-ல், **Quiet hours** தட்டவும்.
2. ஒரு **Start** மற்றும் **End** time அமைக்கவும்.

Quiet hours-இல் schedule செய்யப்படும் reminders சத்தமில்லாமல் screen-இல் காட்டப்படும்.

## Upcoming reminders மற்றும் history

- **Upcoming reminders** என்பது அடுத்து fire ஆக இருக்கும் அனைத்தையும் காட்டுகிறது.
- **Notification history** என்பது சமீபத்தில் delivered, scheduled, மற்றும் cancelled reminders ஐக் காட்டுகிறது.

Reminder சரியாக set செய்யப்பட்டதா என்பதை உறுதிப்படுத்த அல்லது ஏன் ஒன்று தோன்றவில்லை என்பதைப் பார்க்க இந்த lists பயன்படுகின்றன.

## Reminders தோன்றவில்லை என்றால்

- **Enable reminders** on இருப்பதை உறுதிப்படுத்தவும்.
- Notifications உங்கள் சாதனத்தின் system settings-ல் allow செய்யப்பட்டுள்ளதா என்பதைச் சரிபார்க்கவும்.
- Reminder இன் channel enabled ஆக இருப்பதையும் குறைந்தபட்சம் ஒரு day select செய்யப்பட்டிருப்பதையும் உறுதிப்படுத்தவும்.
- Quiet hours அமைத்திருந்தால், reminder silent ஆகலாம்.
- சில Android manufacturers apps ஐ sleep செய்கின்றன. உங்கள் சாதனம் battery-optimization settings வழங்கினால் Theodia ஐ allowed list-இல் சேர்க்கவும்.
- Reminder removed content-உடன் இணைக்கப்பட்டிருந்தால் (உதாரணமாக, deleted பைபிள் plan அல்லது routine), valid target மீண்டும் தேர்ந்தெடுக்கும் வரை reminder fire ஆகாது.

## Notification sounds

Sounds support செய்யும் reminders இயக்கும் sound தேர்வு செய்யலாம். available options-லிருந்து தேர்வு செய்ய reminder அல்லது channel உள்ளே **Sound** தட்டவும். Sounds app-உடன் bundle செய்யப்பட்டுள்ளன, இதனால் offline ஆகவும் வேலை செய்யும்.

பயன்படுத்த **Preview sound** பொத்தானைத் தட்டி saving-க்கு முன் selected sound கேட்கவும்.

## Badges

சில reminders app icon-க்கு badge சேர்க்கலாம். Reset செய்ய notifications screen-ல் **Clear badge** தட்டவும்.