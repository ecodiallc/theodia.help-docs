---
title: Playlists
level: everyday
categories: playlists
summary: Bible வசனங்கள், plain text, அல்லது வேண்டிய எந்த வசனத்தையும் சத்தமாக வாசிக்க spoken playlists ஐ உருவாக்கவும், கேட்கவும்.
---

# Playlists

ஒரு **playlist** என்பது Theodia உங்களுக்காக சத்தமாக வாசிக்கும் tracks இன் பட்டியல். ஒவ்வொரு track உம் ஒரு Bible passage அல்லது குறுகிய plain-text note. Playlists commute, walk, devotional நேரம், அல்லது memorization practice காலத்தில் hands-free listening க்கு பயனுள்ளவை.

குறைந்தபட்சம் ஒரு playlist உருவாக்கப்பட்டு அல்லது populate செய்யப்பட்ட பிறகும் செயலியில் playlists தோன்றும்.

## Playlists ஐ எங்கே காணலாம்

Playlists கிடைக்கும்போது, இரண்டு வழிகளில் அவற்றை அடையலாம்:

- **Home திரை:** **Plugins & More** section இல், **Playlists** ஐத் தட்டவும்.
- **main menu:** menu (☰) ஐத் திறந்து, **Playlists** ஐத் தட்டவும்.

இன்னும் playlists இல்லை எனில், Playlists tile மற்றும் menu item மறைக்கப்படும்.

## ஒரு playlist எதைக் கொண்டிருக்கிறது

ஒவ்வொரு playlist உம்:

- ஒரு **பெயர்** — உதாரணத்திற்கு, "Morning Verses" அல்லது "Memorize Psalm 23".
- ஒரு விருப்பமான **category** — பொதுவான நோக்கத்தின் அடிப்படையில் playlists ஐக் குழுவாக்க பயனுள்ளது.
- **tracks** இன் பட்டியல் — சத்தமாக வாசிக்க வேண்டிய உருப்படிகள்.

ஒவ்வொரு track உம் கொண்டிருப்பது:

- **Content** — ஒரு Bible passage reference அல்லது plain text.
- ஒரு **label** — track play ஆகும்போது திரையில் காட்டப்படும்.
- ஒரு விருப்பமான **voice** — இந்த track க்கு வேறு voice வேண்டுமெனில் தேர்வு செய்யவும்.

## Playlist உருவாக்கவும்

1. **Playlists** திரையைத் திறக்கவும்.
2. **Create playlist** (அல்லது **+** பொத்தான்) ஐத் தட்டவும்.
3. Playlist க்கு ஒரு பெயர் கொடுக்கவும்.
4. (விருப்பம்) Category ஒன்றைத் தேர்வு செய்யுங்கள் அல்லது உருவாக்கவும்.
5. Tracks ஐ சேர்க்கத் தொடங்கவும்.

### Bible passage இலிருந்து track ஐ சேர்க்க

1. **Add track** ஐத் தட்டவும்.
2. Content type ஆக **Bible passage** ஐத் தேர்வு செய்யவும்.
3. `John 3:16` அல்லது `Psalm 23:1-6` போன்ற reference ஒன்றை உள்ளிடவும்.
4. வேண்டுமெனில் label சேர்க்கவும், அல்லது blank ஆக விட்டு விட்டு reference ஐ பயன்படுத்தவும்.
5. Track ஐ save செய்யவும்.

### Plain-text track ஐ சேர்க்க

1. **Add track** ஐத் தட்டவும்.
2. **Plain text** ஐத் தேர்வு செய்யவும்.
3. Theodia வாசிக்க வேண்டிய text ஐ உள்ளிடவும்.
4. ஒரு label சேர்க்கவும்.
5. Track ஐ save செய்யவும்.

### Tracks ஐ batch ஆகச் சேர்க்க

References அல்லது text lines இன் பட்டியல் உங்களிடம் இருந்தால், **Batch add** ஐப் பயன்படுத்தவும்:

1. ஒரு playlist ஐத் திறக்கவும்.
2. Menu ஐத் தட்டி **Batch add** ஐத் தேர்வு செய்யவும்.
3. ஒரு வரியில் ஒரு reference அல்லது text line வீதம் paste செய்யவும்.
4. பெரும்பாலான lines verse references எனில் **Detect Bible references** ஐ turn on செய்யவும்.
5. **Add** ஐத் தட்டவும். ஒவ்வொரு line உம் ஒரு track ஆக மாறும்.

## Playlist ஐ கேட்கவும்

1. நீங்கள் கேட்க விரும்பும் playlist ஐத் திறக்கவும்.
2. மேலே அல்லது ஒரு track பக்கத்தில் உள்ள **Play** பொத்தானைத் தட்டவும்.
3. Theodia ஒவ்வொரு track ஐயும் வரிசையாக வாசிக்கும்.

Playlist play ஆகும்போது, இந்த controls உடன் ஒரு control bar தோன்றும்:

- **Play / Pause**
- **Next track**
- **Previous track**
- **Stop**

அமைக்கவும்:

- **Speed** — voice எவ்வேகத்தில் வாசிக்கும்.
- **Repeat** — முழு playlist ஐ repeat, ஒரு track ஐ repeat, அல்லது ஒரு முறை மட்டும் play.
- **Shuffle** — tracks ஐ தற்போதமான வரிசையில் play.
- **Ignore parenthetical** — அடைப்புக்குறிகளுக்குள் உள்ள text ஐ skip.
- **Pause between tracks** — tracks இடையில் குறுகிய மௌனம் சேர்க்க.
- **Sleep timer** — ஒரு குறிப்பிட்ட நேரத்திற்குப் பிறகு playback ஐ நிறுத்த.

## Playlist ஐத் திருத்தவும்

தற்போது play ஆகும்போது முதலில் playback ஐ pause செய்யவும்.

நீங்கள் செய்யலாம்:

- Playlist ஐ **Rename** செய்யவும்.
- **Reorder tracks** — tracks ஐ drag செய்து புதிய வரிசையில் வைக்கவும்.
- **Edit a track** — அதன் reference, text, label, அல்லது voice ஐ மாற்றவும்.
- **Delete a track** — அதை playlist இலிருந்து நீக்கவும்.
- **Delete the whole playlist** — இது மீட்டெடுக்க முடியாதது.

## Playlists ஐ ஏற்றுமதி மற்றும் import செய்தல்

Playlists எல்லா tracks, categories, மற்றும் settings ஐயும் கொண்ட JSON கோப்புகளாக ஏற்றுமதி செய்யப்படுகின்றன. நீங்கள் அந்த கோப்பை மற்றொரு சாதனத்துடன் share, backup ஆக வைத்துக்கொள்ள அல்லது computer இல் edit செய்யலாம்.

- **Export all playlists** — ஒரு `playlists-YYYY-MM-DD.json` கோப்பை உருவாக்குகிறது.
- **Export a category** — ஒரு category இல் உள்ள playlists மட்டும் கொண்ட JSON கோப்பை உருவாக்குகிறது.
- **Import playlists** — JSON backup கோப்பிலிருந்து playlists ஐ மீட்டெடுக்கிறது.

## Playlists உருவாக்க quick வழிகள்

JSON ஆக செயலி முழு playlist ஐ உருவாக்கி import செய்யலாம். இங்கே ஒரு உதாரணம்:

```json
{
  "playlists": [
    {
      "name": "Morning Verses",
      "category": "Devotional",
      "tracks": [
        {
          "info": "John 3:16",
          "contentSource": "passage",
          "content": "For God so loved the world...",
          "rawContent": "John 3:16"
        },
        {
          "info": "Psalm 23",
          "contentSource": "passage",
          "content": "The Lord is my shepherd...",
          "rawContent": "Psalm 23:1-6"
        }
      ]
    }
  ]
}
```

கோப்பை save செய்து, பின்னர் Theodia இல் import செய்ய **Import playlists** ஐப் பயன்படுத்தவும்.

## குறிப்புகள்

- Playlists குறுகிய, கவனக் கூடிய verse தொகுப்புகளுடன் சிறப்பாக வேலை செய்கிறது.
- Devotional playlists ஐ மற்றும் memorization playlists ஐப் பிரிக்க categories ஐப் பயன்படுத்தவும்.
- தூங்கும்போது கேட்டால் sleep timer அமைக்கவும்.
- ஒரு track தவறான voice ஐப் பயன்படுத்தினால், voice language text language உடன் பொருத்தமாக இருக்கிறதா எனச் சரிபார்க்கவும்.
- Theodia plain text ஐ எழுத்துப்பிழைகள் போல் சரியே வாசிக்கும்; best results க்கு spelling ஐச் சரிபார்க்கவும்.