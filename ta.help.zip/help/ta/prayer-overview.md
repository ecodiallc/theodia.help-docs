---
title: Prayer Overview
level: beginner
categories: prayer
summary: Prayer தாவலுக்கும் அதன் முக்கிய பகுதிகளுக்கும் ஒரு விரைவான அறிமுகம்.
---

# Prayer Overview

**Prayer** தாவல் prayer க்கான ஒரு தனிப்பட்ட இடம். அது lists, guided sessions, ஒரு journal, ஒரு timer, lectionary reading schedules, மற்றும் classic fixed prayers ஐ ஒருங்கிணைக்கிறது.

## முக்கிய பகுதிகள்

- **Prayer List** — நீங்கள் பிரார்த்தனை செய்யும் நபர்கள், சூழ்நிலைகள், மற்றும் தலைப்புகளைக் கண்காணித்தல்.
- **Journal** — காலப்போக்கில் reflections, பதில்கள், மற்றும் எண்ணங்களை எழுதுங்கள்.
- **Generate Prayer** — ஒரு request அல்லது journal entry இலிருந்து Theophilus ஐக் கொண்டு prayer ஐ எழுதச் சொல்லவும்.
- **Creeds & Fixed Prayers** — Christian tradition இலிருந்து classic prayers மற்றும் creeds.
- **Lectionary** — தினசரி அல்லது பருவகால prayer க்கான scripture reading schedules.
- **Guided Prayer** — text-to-speech உடன் audio-guided prayer sessions.
- **Timer** — optional bells உடன் timed prayer sessions.