---
title: Study Mode
level: everyday
categories: [layout, read]
summary: Theodia இன் முழு Bible reader, commentary, cross-references, lexicon, notes போன்ற படன கருவிகளுடன்.
---

# Study Mode

> **Mode:** Study Mode **Standard** மற்றும் **Scholar** mode இல் கிடைக்கும். Reader mode அத்தியாயங்களை Focus Mode இல் திறக்கும். முறைகளை **Settings** → **App User Mode** இல் மாற்றலாம்.

Study Mode என்பது Theodia இன் முதன்மை Bible reader. Commentary, cross-references, word lookups, parallel மொழிபெயர்ப்புகள், notes மற்றும் மேலும் பல படன கருவிகள் அனைத்தும் கட்டமைக்கப்பட்டுள்ளன.

Focus Mode என்பது எளிய வாசிப்பாளர், படன கருவிகள் இல்லாமல். நீங்கள் சுத்த உரை வேண்டுமானால் [Focus Mode](theodia://help/focus-mode) வழிகாட்டியைப் பார்க்கவும். இந்த வழிகாட்டி Study Mode க்கானது.

## Study Mode ஐ எவ்வாறு திறப்பது

Chapter ஐ Study Mode இல் திறப்பதற்கான பல வழிகள்:

- திரையின் கீழே உள்ள **Bible** தாவலைத் தட்டவும். ஒரு மொழிபெயர்ப்பு, ஒரு புத்தகம், மற்றும் ஒரு அத்தியாயம் தேர்வு செய்யவும்.
- **Search** முடிவுகளில் ஒரு வசனத்தைத் தட்டவும்.
- **Bookmarks** தாவலிலிருந்து ஒரு bookmark ஐத் தட்டவும்.
- Focus Mode இலிருந்து, Study Mode க்கு மாற திரையின் மேலே உள்ள 📖 பொத்தானைத் தட்டவும்.

## அத்தியாயத்தை வாசித்தல்

அத்தியாயம் verses வரிசையில் பட்டியலிடப்பட்டு திறக்கும். திரையின் மேலே பிரபலமான செயல்களுக்கான பொத்தான்கள் உள்ளன. திரையின் கீழே ஒரு status bar உள்ளது.

- **Swipe left** — அடுத்த அத்தியாயத்திற்குச் செல்ல.
- **Swipe right** — முந்தைய அத்தியாயத்திற்குச் செல்ல.
- **வசனத்தைத் தட்டவும்** — படன கருவிகளுடன் verse menu ஐத் திறக்க (கீழே பார்க்கவும்).
- **ஒரு verse இல் உள்ள Strong's number ஐத் தட்டவும்** (எ.கா., G1234 அல்லது H1234) — அந்த சொல்லுக்கான quick lexicon lookup ஐத் திறக்க.

நீங்கள் ஒரு parallel மொழிபெயர்ப்பை இயக்கியிருந்தால், நீங்கள் தேர்வு செய்த மொழிபெயர்ப்பில் ஒரு பிரதி copy அத்தியாயத்திற்கு கீழே தோன்றும். கீழே **ஒரே நேரத்தில் இரண்டு மொழிபெயர்ப்புகளை வாசித்தல்** ஐப் பார்க்கவும்.

## Verse menu

ஒரு வசனத்தைத் தட்டும்போது, "Book Chapter:Verse" என்னும் title கொண்ட ஒரு menu திறக்கும். நீங்கள் காணும் கருவிகள் உங்கள் user mode-ஐச் சார்ந்தவை.

### Standard மற்றும் Scholar mode இல் உள்ள கருவிகள்

- **Bookmark** (★) — வசனத்தைச் சேமித்து, மீண்டும் கண்டுபிடிக்க. மீண்டும் தட்டி remove செய்யவும். முதல் தட்டல் add செய்கிறது. [Bookmarking Verses](theodia://help/bookmarks) வழிகாட்டியைப் பார்க்கவும்.
- **Highlight** (□) — வசனத்திற்கு நிறம் கொடுத்து கவனத்தை ஈர்க்க. நிறத் தேர்வியைத் திறக்க தட்டவும். அதே நிறத்தை மீண்டும் தட்டி remove செய்யவும். [Highlighting Verses](theodia://help/highlights) வழிகாட்டியைப் பார்க்கவும்.
- **Speak** (🔊) — உங்கள் சாதனத்தின் text-to-speech voice ஐப் பயன்படுத்தி வசனத்தை வாய்மொழியாக வாசிக்க. Interlinear Bibles-க்கு இது காட்டப்படுவதில்லை. எவ்வாறு பயன்படுத்துவது மற்றும் voice எவ்வாறு தேர்வு செய்வது பற்றிய [Reading Out Loud](theodia://help/tts) வழிகாட்டியைப் பார்க்கவும்.
- **Copy** (⎘) — verse உரையை clipboard-இல் வைத்து, எங்கு வேண்டுமானாலும் paste செய்ய.
- **Compare** (⇄) — நீங்கள் install செய்துள்ள ஒவ்வொரு மொழிபெயர்ப்பிலும் அதே வசனத்தை காட்டும் பேனல் திறக்க. பேனலில் ஒரு மொழிபெயர்ப்பைத் தட்டி, அந்த மொழிபெயர்ப்பில் வசனத்தை வாசிக்க. [Comparing Translations](theodia://help/compare-translations) வழிகாட்டியைப் பார்க்கவும்.
- **Cross-References** (↗) — cross-reference database இலிருந்து தொடர்புடைய verses-ன் பட்டியலைத் திறக்க. [Cross-References](theodia://help/cross-references) வழிகாட்டியைப் பார்க்கவும்.
- **Add/Edit Bible Note** (✎) — verse உடன் இணைக்கப்பட்ட உங்கள் தனிப்பட்ட note ஐ எழுத. [Writing Notes](theodia://help/notes) வழிகாட்டியைப் பார்க்கவும்.

### Scholar mode மட்டும்

- **AI Commentary** (◈) — இந்த verse க்கான study note ஐ எழுத AI assistant ஐக் கேட்க. (எல்லா பிராந்தியங்களிலும் கிடைக்காது.)
- **Word Info** (?) — verse க்குப் பின்னால் உள்ள original Hebrew அல்லது Greek சொல்லின் lexicon entry ஐத் திறக்க. [Commentaries and Lexicons](theodia://help/commentaries-and-lexicons) வழிகாட்டியைப் பார்க்கவும்.
- **Dictionary** (📖) — நீங்கள் install செய்துள்ள dictionary வளங்களில் பொது Bible சொற்களை தேட. [Bible Dictionary](theodia://help/dictionary) வழிகாட்டியைப் பார்க்கவும்.

சில கருவிகளுக்கு கூடுதல் resources install செய்ய வேண்டும். ஒரு கருவி greyed out ஆக இருந்தால் அல்லது "not found" என்று காட்டினால், **Settings** → **Manage Resources** ஐத் திறந்து அதற்குத் தேவையான resource ஐச் சேர்க்கவும்.

## Top-of-screen பொத்தான்கள்

Chapter text-க்கு மேலே icon களின் வரிசை. இவை quick actions:

- **Bible version** — மொழிபெயர்ப்பு பெயரை (எ.கா., "KJV") தட்டி வேறு மொழிபெயர்ப்பிற்கு மாற.
- **Book** — புத்தகப் பெயரைத் தட்டி வேறு புத்தகத்திற்கு jump.
- **Chapter** — அத்தியாய எண்ணைத் தட்டி வேறு அத்தியாயத்திற்கு jump.
- **Open in AI** (🤖) — உங்கள் கேள்வியுடன் தற்போதைய அத்தியாயத்தை AI assistant க்கு அனுப்ப. (Scholar mode மட்டும்.)
- **Focus Mode** (📖) — சுத்த வாசிப்புக்கு Focus Mode க்கு மாற.
- **Parallel Bibles** (🔵 / ⚪) — parallel மொழிபெயர்ப்புகளை on அல்லது off செய்ய தட்ட. Enabled ஆனால், தேர்வு செய்யப்பட்ட parallel மொழிபெயர்ப்புகளில் அதே அத்தியாயம் முதன்மை உரைக்கு கீழே காட்டப்படும். Disabled செய்தால், முதன்மை மொழிபெயர்ப்பு மட்டுமே காட்டப்படும். கீழே **ஒரே நேரத்தில் பல மொழிபெயர்ப்புகளை வாசித்தல்** ஐப் பார்க்கவும்.
- **Listen** — தலையாய அத்தியாயத்தை வாய்மொழியாக வாசிக்க. [Reading Out Loud](theodia://help/tts) வழிகாட்டியைப் பார்க்கவும்.
- **More** — கூடுதல் chapter actions (chapter Bible note, chapter commentary, share, மற்றும் பல) திறக்க.

## ஒரே நேரத்தில் பல மொழிபெயர்ப்புகளை வாசித்தல்

உங்கள் முதன்மை மொழிபெயர்ப்புக்கு கூடுதலாக நான்கு வரை extra மொழிபெயர்ப்புகளைக் காட்டலாம். இது **parallel view** என்று அழைக்கப்படுகிறது.

1. **Settings** ஐத் திறக்கவும்.
2. **Parallel Bible** ஐ on செய்யவும்.
3. **Add Parallel Bible** ஐத் தட்டி ஒரு மொழிபெயர்ப்பை தேர்வு செய்யவும்.
4. மேலும் சேர்க்க repeat செய்யவும். நான்கு வரை parallel மொழிபெயர்ப்புகள் வைத்துக்கொள்ளலாம்.

Parallel view on இருந்தால், அத்தியாயத்தில் ஒவ்வொரு verse முதலில் உங்கள் முதன்மை மொழிபெயர்ப்பைக் காட்டிவிட்டு, ஒவ்வொரு parallel மொழிபெயர்ப்பிலும் அதே verse ஐ காட்டும். சிரமமான verse ஐ வெவ்வேறு translators எவ்வாறு கையாள்கிறார்கள் என்பதை அத்தியாயத்தை விடாமல் ஒப்பிட எளிதாக்கும்.

நீங்கள் உங்கள் தற்போதைய parallel setup-ஐ **preset** ஆக சேமிக்கலாம். தேர்வு செய்த translations-க்கு அருகில் உள்ள save பொத்தானைத் தட்டி, ஒரு பெயர் கொடுங்கள், அது quick-switch option ஆக மாறும். ஒரு preset ஐ மீண்டும் தட்டி அந்த combination-ஐ instantly ஏற்றவும். Preset ஐ long-press செய்து delete செய்யலாம்.

Verse menu இல் உள்ள **Compare** (⇄) கருவியுடன் ஒரே நேரத்தில் ஒரு verse ஐ மட்டும் ஒப்பிடலாம். இது install செய்துள்ள ஒவ்வொரு மொழிபெயர்ப்பிலும் verse-ஐ காட்டும் பேனலைத் திறக்கும்.

## Subheadings

சில மொழிபெயர்ப்புகளில் section headings built in ஆக இருக்கும் (எ.கா., "The Sermon on the Mount"). உங்கள் மொழிபெயர்ப்பில் அவை இருந்தால், **Settings**-இல் **Show Subheadings** என்னும் setting-ஐக் கொண்டு அவற்றை show/hide செய்யலாம். Subheadings vertices இடையே சிறிய grey titles ஆகத் தோன்றும்.

## அத்தியாயத்தின் note

ஒரு chapter note என்பது முழு அத்தியாயத்துடன் இணைக்கப்பட்ட தனிப்பட்ட note, ஒரு தனி verse உடன் அல்ல. அத்தியாயத்தைப் பற்றிய ஒரு பெரிய எண்ணத்திற்கு இது பயனுள்ளது.

Chapter note ஐத் திறக்க:

1. திரையின் மேலே உள்ள **More** பொத்தானைத் தட்டவும்.
2. **Chapter Note** ஐத் தட்டவும்.
3. உங்கள் note ஐ எழுதவும். **Save** ஐத் தட்டவும்.

Chapter note அத்தியாயத்துடன் சேமிக்கப்படுகிறது. அந்த அத்தியாயத்தை திறக்கும்போதெல்லாம் அது தோன்றும்.

## Search highlights

நீங்கள் search இலிருந்து chapter-க்கு வந்திருந்தால், உங்கள் search words verse text-இல் மஞ்சள் நிறத்தில் highlight ஆகும். ஒரு verse ஏன் match ஆனது என்பதை எளிதாகப் பார்க்க இது உதவும்.

நீங்கள் வாசிக்கும் chapter-இல் search ஐ மீண்டும் இயக்கலாம். **Search** தாவலைத் திறந்து ஒரு சொல்லை உள்ளிடவும். முடிவுகள் matches highlight ஆக அந்த chapter-க்கு நேரடியாக திரும்ப தட்ட அனுமதிக்கும்.

Interlinear Bibles (MIB — Marvel Interlinear Bible — மற்றும் OHGB) word-level layout தேவைப்படுவதால், எப்போதும் Study Mode இல் திறக்கப்படுகின்றன.

## ஒரு அத்தியாயத்திற்காக Focus Mode க்கு மாற்றல்

Study Mode-இல் உள்ள எந்த chapter-இலிருந்தும், திரையின் மேலே உள்ள 📖 பொத்தானைத் தட்டவும். அதே chapter எல்லா menus மறைக்கப்பட்ட நிலையில் Focus Mode இல் திறக்கும். கீழே உள்ள bottom bar-இல் 📖 பொத்தானைத் தட்டி Study Mode க்கு மீண்டும் மாறவும்.

## எப்போது Study Mode பயன்படுத்த வேண்டும்

Study Mode என்பது நீங்கள் விரும்பும்போது சரியானது:

- **ஒரே நேரத்தில் வாசிக்க மற்றும் படன செய்ய.** எல்லா கருவிகளும் ஒரு தட்டால் கிடைக்கும்.
- **நீங்கள் தெரியாத ஒரு சொல்லை தேட.** வசனத்தில் உள்ள Strong's number ஐத் தட்டி விரைவான lexicon entry பெற.
- **மொழிபெயர்ப்புகளை ஒப்பிட.** Verse menu இன் Compare கருவியைப் பயன்படுத்த அல்லது parallel view ஐ on செய்ய.
- **ஒரு verse பைபிளின் மற்ற பகுதிகளுடன் எவ்வாறு இணைகிறது என்பதைப் பார்க்க.** Cross-References ஐப் பயன்படுத்த.
- **வாசித்துக் கொண்டிருக்கும்போது notes எடுக்க.** Verse menu இல் விரைவான "Add note" option உள்ளது.

நீண்ட, distraction-free வாசிப்புக்கு, Focus Mode க்கு மாறவும்.

## Focus Mode க்கு மாற்றல்

Study Mode-இல் உள்ள எந்த chapter-இலிருந்தும், திரையின் மேலே உள்ள 📖 பொத்தானைத் தட்டவும். அதே chapter menus மற்றும் study tools மறைக்கப்பட்ட நிலையில் [Focus Mode](theodia://help/focus-mode) இல் திறக்கும். கீழே உள்ள bottom bar-இல் 📖 பொத்தானைத் தட்டி Study Mode க்கு மீண்டும் மாறவும். Focus Mode என்ன செய்கிறது என்பதன் முழு விவரத்திற்கு, [Focus Mode](theodia://help/focus-mode) வழிகாட்டியைப் பார்க்கவும்.

## Help மற்றும் கேள்விகள்

ஒரு கருவி missing போல தெரிந்தால் அல்லது error காட்டினால், [Common Problems](theodia://help/common-problems) வழிகாட்டியைப் பார்க்கவும். நீங்கள் Theodia க்கு புதியவர் என்றால், [Reading Your First Chapter](theodia://help/first-read) வழிகாட்டி அடிப்படைகளை step by step ஆக விளக்குகிறது.
