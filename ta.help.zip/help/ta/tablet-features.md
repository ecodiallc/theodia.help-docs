---
title: Tablet Features
level: everyday
categories: [layout, tablet]
summary: Theodia இன் layout tablets மற்றும் பெரிய screens-க்கு எவ்வாறு adapt ஆகிறது, split views, side panels, மற்றும் two-pane வாசிப்பு முறைகளுடன்.
---

# 📱 Tablet Features

Tablet-களின் பெரிய screens-ஐப் பயன்படுத்திக் கொள்வதற்காக Theodia வடிவமைக்கப்பட்டுள்ளது. ஒரு tablet-இல் (அல்லது சுமார் 700 pixels-க்கும் அதிக அகலமுள்ள எந்த device-இலும்), app தானாக பல இடங்களில் two-column layout-க்கு மாறுகிறது.

> **Mode:** இங்கே விவரிக்கப்பட்ட அம்சங்கள் மட்டுமே தோன்றும் உங்கள் தற்போதைய user mode-க்கு support உள்ளதால். உதாரணமாக, commentary side panels மற்றும் AI chat ஆனது Scholar mode-இல் மட்டுமே கிடைக்கும். Bookmarks, highlights, மற்றும் notes split views-க்கு Standard அல்லது Scholar mode தேவை. Focus Mode என்பது சுத்தமான, single-column வாசிப்பு மட்டுமே. முறைகளை **Settings** → **App User Mode** இல் மாற்றலாம்.

## Reader verse menu

நீங்கள் ஒரு verse number-ஐத் தட்டினால் (அல்லது verse text-ஐ long-press செய்தால்), **verse menu** ஒரு dark backdrop-இன் மேல் **centered card** ஆகத் தோன்றுகிறது.

- **Copy** மற்றும் **Share** பொத்தான்கள் எப்போதும் menu-இன் மேலே visible ஆக இருக்கும்.
- **Bookmarks** மற்றும் **Highlights** அவற்றின் தற்போதைய state-இல் காட்டப்படுகின்றன.
- **Commentary**, **Dictionary**, மற்றும் **Compare** menu இலிருந்து திறக்கப்படுகின்றன. Tablet-களில் இந்த கருவிகள் selected செய்யப்பட்டவுடன் side panel அல்லது wide card-இல் தோன்றலாம்.
- Backdrop ஐ தட்டவும் அல்லது close arrow ஐ தட்டவும் menu ஐ dismiss செய்ய.

## Verse Commentary panel

**Commentary** கருவி tablet-இல் **dedicated side panel** திறக்கிறது:

- Commentary உரை Bible text-க்கு அருகில் தோன்றுகிறது.
- நீங்கள் Bible-ஐ விட Bible-ஐ சுயாதீனமாக scroll செய்யலாம்.
- Close செய்ய **X** ஐத் தட்டவும் அல்லது swipe செய்யவும்.
- Panel-இன் மேலே உள்ள **book icon** commentary sources-ஐ மாற்ற அனுமதிக்கும்.
- **Chapter icon** chapter-level commentary ஐக் காட்ட அனுமதிக்கும்.

Phone-இல், commentary full-screen modal ஆகத் திறக்கும்.

## Chapter Commentary

**Chapter Commentary** என்பது verse menu-இல் இல்லாமல் திரையின் மேலே உள்ள **More** பொத்தானிலிருந்து access செய்யப்படுகிறது. Tablet-இல், Verse Commentary-போலவே ஒரு side panel ஆகத் திறக்கும், இதனால் commentary மற்றும் Bible text-ஐ ஒன்றாக வாசிக்கலாம்.

## Compare tab

Verse menu-இல் உள்ள **Compare** tab tablet-இல் **side panel** ஆகத் திறக்கும். நீங்கள் enable செய்துள்ள ஒவ்வொரு parallel version-இலும் தேர்வு செய்த verse காட்டப்படுகிறது. படிப்பானில் அந்த passage க்கு jump செய்ய எந்த version-ஐயும் தட்டலாம்.

## Dictionary / Strong's popup

**Dictionary** கருவி (verse menu → Dictionary) tablet-இல் wide card ஆகத் திறக்கும். Greek அல்லது Hebrew சொல், அதன் transliteration, விளக்கம், மற்றும் Strong's number காட்டப்படும். அந்த சொல்லின் ஒவ்வொரு occurrence-ஐயும் பார்க்க **Concordance** பொத்தானைத் தட்டவும்.

## ஒரு சொல்லைத் தட்டி Lexicon திறத்தல்

Tablet-இல் **Word Info** side panel-இல், Strong's number உள்ள ஒவ்வொரு word card-ம் tappable ஆகும். அந்த word-க்கான **Lexicon** panel ஐ நேரடியாகத் திறக்க card ஐத் தட்டவும். Lexicon panel, Word Info panel-ஐ மாற்றிவிடும், இதனால் reader-ஐ close செய்யாமல் study தொடரலாம்.

Phone-இல், Word Info cards tappable இல்லை, ஏனெனில் screen இரண்டு panels-க்கு மிகவும் சிறியது.

## Parallel Bibles side by side

Settings-இல், **Parallel Bibles** ஐத் தட்டி மூன்று வரை versions தேர்வு செய்யவும். Tablet-இல், versions **vertical panes** ஆக ஒருவரின் அருகில் ஒருவர் தோன்றும்:

- ஒவ்வொரு pane-ம் சுயாதீனமாக scroll ஆகும்.
- Side panel-இல் tools-ஐத் திறக்க ஒரு verse number ஐத் தட்டலாம்.
- **Compare** tab தேர்வு செய்த அனைத்து verses-ஐயும் ஒரே இடத்தில் காட்டும்.
- Single-column view-க்கு திரும்ப ஒரு pane-இன் **X** ஐத் தட்டவும்.
- Settings ஐத் திறக்காமல் parallel view ஐ on அல்லது off செய்ய top icon bar-இல் உள்ள **Parallel Bibles** icon (🔵 / ⚪) ஐத் தட்டவும்.

Phone-இல், parallel versions ஒன்றன் பின் ஒன்றாக (vertically) காட்டப்படும், side by side இல்லை. அதே toggle icon phone-களிலும் வேலை செய்யும்.

## Bookmarks மற்றும் Highlights split view

Tablet-இல், **Bookmarks** மற்றும் **Highlights** தாவல்கள் master-detail layout பயன்படுத்துகின்றன:

- **இடது பக்கம்** — bookmarks அல்லது highlights-ன் பட்டியல்.
- **வலது பக்கம்** — ஒரு item ஐத் தட்டினால் verse அல்லது passage text-ஐடன் preview pane திறக்கும்.

நீங்கள் tab ஐ விடாமல் saved items-ஐ skim செய்யலாம் மற்றும் preview செய்யலாம். Phone-இல், ஒரு item ஐத் தட்டுவது reader screen-க்கு navigate செய்கிறது.

## Notes split view

**Notes** தாவல் tablet-இல் இடதுபக்கம் notes பட்டியலையும் வலதுபக்கம் தேர்வு செய்யப்பட்ட note-ஐயும் காட்டும். ஒரு note ஐத் தட்டினால் அது side panel-இல் திறக்கும், இதனால் list-ஐ விடாமல் பல notes ஐ ஒன்றன் பின் ஒன்றாக skim செய்யலாம். Note உருவாக்குதல் அல்லது edit செய்தலும் side panel பயன்படுத்தும்.

## Search split view

Tablet-இல், **Search** தாவல் search இயக்கினால் உடனே இடதுபக்கம் search form-ஐயும் வலதுபக்கம் results-ஐயும் காட்டும். Screen-ஐ மாற்றாமல் query-ஐ refine செய்து results update ஆவதை பார்க்கலாம். Phone-இல், search results தனி screen-இல் திறக்கும்.

## Settings category sidebar

**Settings** screen tablet-இல் இடதுபக்கம் category list (AI, Appearance, Backup, Bibles, மற்றும் பல) காட்டும். ஒரு category ஐத் தட்டி நேரடியாக வலதுபக்கம் அதன் settings க்கு jump செய்யலாம். தேர்வு செய்யப்பட்ட category மட்டும் expand ஆகும், இதனால் முழு settings list-ஐயும் scroll செய்ய வேண்டியதில்லை.

## Bible navigation on tablets

**Bible List**, **Bible Books**, மற்றும் **Bible Chapters** screens tablet-களில் single-column ஆகவே இருந்தினும், அவற்றின் content-ஐ வாசிக்கவும் tap செய்யவும் எளிதாக்க larger touch targets, wider grids, மற்றும் மிகுந்த spacious padding பயன்படுத்துகின்றன. ஒவ்வொரு step-உம் அதன் list அல்லது grid-ஐ தெளிவாகக் காட்ட full width தேவைப்படுவதால், இவை split-view layout பயன்படுத்துவதில்லை.

## Landscape and portrait

Tablet ஐ rotate செய்தால் layout தானாக adjust ஆகும். **Landscape**-இல், side panels-க்கு போதுமான இடம் உள்ளது. **Portrait**-இல், panels குறுகினாலும் உரைக்கு அருகிலேயே இருக்கும்.

## Selected verse AI chat

Verse menu side panel-இல் **AI** chat திறக்கும். நீங்கள் selected verse பற்றி கேள்விகள் கேட்கக்கூடிய conversation interface காட்டும். AI response panel-இல் தோன்றும், reader-ஐ விடாமல் conversation தொடரலாம்.

## Conversation sidebar in AI screen

Tablet-இல் **AI** tab-இல், conversation list எப்போதும் persistent left sidebar ஆக visible ஆகும். Menu ஐத் திறக்காமல் chats இடையே switch செய்யலாம். **New Chat** பொத்தானும் எப்போதும் visible. Phone-இல், conversation list popup drawer ஆகும்.

## எதுவும் மாறாதது

எல்லா screens-உம் இரண்டு panes ஆக split ஆவதில்லை. பின்வரும் screens tablet-களில் single-column ஆகவே இருக்கும்:

- **Bible List** — Bible versions-ன் பட்டியல் (full width)
- **Bible Books** — book grid மற்றும் sections (full width)
- **Bible Chapters** — chapter grid (full width)
- **PDFs** — PDF library wider card grid பயன்படுத்தும் (full width)
- **Settings** — தனிப்பட்ட settings pages (full width)
- **Help** — help articles (full width)

## Summary

Tablet-இல் நீங்கள் பெறுவது:

- **Parallel Bibles** side-by-side vertical panes-இல்
- **Commentary** persistent side panels-இல்
- **Compare** மற்றும் **Dictionary** wide cards-இல்
- எந்த Word Info card ஐத் தட்டியும் **Lexicon**
- **Bookmarks, Highlights, Notes, Devotionals, Books, Settings** master-detail split views-இல்
- search form-க்கு அருகில் inline results-ஐடன் **Search**
- automatic layout மாற்றங்களுடன் **Landscape** மற்றும் **portrait** இரண்டும் support

Phone-இல், எல்லாமே traditional single-column drill-down navigation பயன்படுத்தும். App launch-இல் screen width ஐக் கண்டறிந்து தானாக சரியான layout ஐ தேர்வு செய்யும்.
