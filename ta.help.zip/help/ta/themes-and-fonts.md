---
title: Changing Themes and Fonts
level: everyday
categories: settings
summary: App இன் தோற்றத்தை எவ்வாறு மாற்றுவது.
---

# Changing Themes and Fonts

Theodia app எவ்வாறு தோற்றமளிக்கிறது என்பதை நீங்கள் மாற்றலாம். ஒரு theme (light அல்லது dark) மற்றும் ஒரு font size தேர்வு செய்யலாம்.

## Appearance settings ஐ எவ்வாறு திறப்பது

1. **Settings** ஐத் திறக்கவும்.
2. **Appearance** ஐத் தட்டவும்.

## Theme ஐ எவ்வாறு மாற்றுவது

**Appearance** section-இல், இரண்டு theme பொத்தான்களைக் காண்பீர்கள்:

- **Default** — light background லட்சர dark text. பகல் நேர வாசிப்புக்கு நன்று.
- **Dark** — dark background லட்சர light text. இரவு நேரத்திற்கு நன்று, மற்றும் battery சேமிக்கும்.

Theme ஐ apply செய்ய தட்டவும். மாற்றம் உடனடியாக நடைபெறும்.

## Font size ஐ எவ்வாறு மாற்றுவது

**Appearance** section-இல், size பொத்தான்களில் ஒன்றைத் தட்டவும்: **---**, **--**, **-**, **Normal**, **+**, **++**, **+++**. App முழுவதும் text சிறியதாகவோ பெரியதாகவோ மாறும். உங்களுக்கு வாசிக்க எளிதான size தேர்வு செய்யவும்.

## Tips

- OLED screens கொண்ட phone-களில் Dark theme battery சேமிக்கும்.
- Text வாசிக்க மிகவும் சிறியதாக இருந்தால், device-இன் அமைப்பைப் பதிலாக app-இலேயே font size அதிகரிக்கவும். App-இன் setting மிகவும் finer.
- நீண்ட வாசிப்புக்கு, dark theme மற்றும் பெரிய font ஐ முயற்சிக்கவும்.
- [Activate the desert theme](theodia://unlock-desert)
