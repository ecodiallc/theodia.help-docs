---
title: మీ సొంత వనరులను తయారు చేయడం
level: advanced
categories: resources
summary: కస్టమ్ బైబిల్స్, వ్యాఖ్యానాలు, పుస్తకాలు, భక్తి పాఠాలు, మరియు పదకోశాలను తయారు చేసి Theodia లోకి ఇంపోర్ట్ చేయడం.
---

# మీ సొంత వనరులను తయారు చేయడం

Theodia Unique Bible App ఫార్మాట్‌లో కస్టమ్ వనరులను సపోర్ట్ చేస్తుంది. ప్రతి వనరు నిర్దిష్ట టేబుల్ స్ట్రక్చర్ కలిగిన SQLite ఫైల్. మీరు ఈ ఫైల్‌లను కంప్యూటర్‌లో తయారు చేసి యాప్‌లోకి ఇంపోర్ట్ చేయవచ్చు.

## ఫైల్ రకాలు మరియు అవసరమైన టేబుల్స్

### బైబిల్స్ (`.bible`)

బైబిల్ ఫైల్ కనీసం ఈ టేబుల్స్‌లో ఒకటి ఉన్న SQLite డేటాబేస్:

- **`Verses`** — కాలమ్‌లు: `Book` (integer, 1-66), `Chapter` (integer), `Verse` (integer), `Scripture` (text)
- **`Bible`** — కాలమ్‌లు: `Book` (integer), `Chapter` (integer), `Verse` (integer), `Scripture` (text)

మీరు `Description`, `Abbreviation`, మరియు `Version` వంటి మెటాడేటా కాలమ్‌లతో **`Details`** టేబుల్‌ను కూడా చేర్చవచ్చు.

SQL ఉదాహరణ:

```sql
-- Main text table
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- Optional metadata table
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### వ్యాఖ్యానాలు (`.commentary`)

వ్యాఖ్యానాలు మూడు రకాలు: **book**, **chapter**, మరియు **verse**. రకం ఫైల్‌నేమ్ యొక్క **మొదటి అక్షరం** ద్వారా నిర్ణయించబడుతుంది.

#### Book commentaries — ఫైల్‌నేమ్ `b` తో ప్రారంభమవుతుంది

Book commentary బైబిల్ పుస్తకానికి ఒక ఎంట్రీలో కవర్ చేస్తుంది. `Commentary` టేబుల్‌కు `Book` మరియు `Scripture` (లేదా `Content`) కాలమ్‌లు అవసరం. `Chapter` లేదా `Verse` కాలమ్‌లు అవసరం లేదు.

- **`Commentary`** — కాలమ్‌లు: `Book` (integer), `Scripture` (text) or `Content` (text)

SQL ఉదాహరణ:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

ఫైల్‌నేమ్ ఉదాహరణ: `bMyCommentary.commentary`

#### Chapter commentaries — ఫైల్‌నేమ్ `c` తో ప్రారంభమవుతుంది

Chapter commentary బైబిల్ పుస్తకంలోని ప్రతి అధ్యాయాన్ని కవర్ చేస్తుంది.

- **`Commentary`** — కాలమ్‌లు: `Book` (integer), `Chapter` (integer), `Scripture` (text) or `Content` (text)

SQL ఉదాహరణ:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

ఫైల్‌నేమ్ ఉదాహరణ: `cMyCommentary.commentary`

#### Verse commentaries — ఫైల్‌నేమ్ `v` తో ప్రారంభమవుతుంది

Verse commentary వ్యక్తిగత వచనాలను కవర్ చేస్తుంది. `Commentary` టేబుల్‌కు `Book`, `Chapter`, `Verse`, మరియు `Scripture` (లేదా `Content`) కాలమ్‌లు అవసరం.

- **`Commentary`** — కాలమ్‌లు: `Book` (integer), `Chapter` (integer), `Verse` (integer), `Scripture` (text) or `Content` (text)

SQL ఉదాహరణ:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

ఫైల్‌నేమ్ ఉదాహరణ: `vMyCommentary.commentary`

### పుస్తకాలు (`.book`)

Book ఫైల్ `Reference` టేబుల్ ఉన్న SQLite డేటాబేస్.

- **`Reference`** — కాలమ్‌లు: `id` (integer), `Chapter` (text), `Content` (text)

ప్రతి రో ఒక అధ్యాయం. `Chapter` కాలమ్ అధ్యాయ శీర్షిక. `Content` కాలమ్ అధ్యాయ బాడీ, అందులో HTML (`<b>`, `<i>`, `<br>`, etc.) ఉండవచ్చు.

SQL ఉదాహరణ:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

మీరు Markdown ఫైల్‌ల నుండి కూడా పుస్తకాలు తయారు చేయవచ్చు. యాప్ `.md` ఫైల్స్‌ను ఇంపోర్ట్ చేయగలదు, అందులో `#` పుస్తక శీర్షిక మరియు `##` అధ్యాయాలు. Markdown ఆటోమేటిక్‌గా HTML కి మార్చబడుతుంది.

### భక్తి పాఠాలు (`.devotional`)

Devotional ఫైల్ `devotional` టేబుల్ ఉన్న SQLite డేటాబేస్.

- **`devotional`** — కాలమ్‌లు: `month` (integer, 1-12), `day` (integer, 1-31), `devotion` (text)

ప్రతి రో ఒక రోజు చదవడం. యాప్ ఈరోజు నెల మరియు తేదీ ఆధారంగా ఎంట్రీని కనుగొంటుంది.

SQL ఉదాహరణ:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### పదకోశాలు (`.lexicon`)

Lexicon ఫైల్ `Lexicon` టేబుల్ ఉన్న SQLite డేటాబేస్.

- **`Lexicon`** — కాలమ్‌లు: `Topic` (text, Strong's నంబర్), `Definition` (text, lexicon entry)

`Topic` కాలమ్ Strong's నంబర్‌ను కలిగి ఉంటుంది (ఉదాహరణకు, `G1161` లేదా `H7225`). `Definition` కాలమ్ పూర్తి ఎంట్రీ టెక్స్ట్, HTML కలిగి ఉండవచ్చు.

SQL ఉదాహరణ:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

పదకోశాలు Word Info సాధనాన్ని శక్తివంతం చేస్తాయి. మీరు interlinear బైబిల్‌లో ఒక పదాన్ని నొక్కినప్పుడు, యాప్ ఇన్‌స్టాల్ చేయబడిన పదకోశాలలో Strong's నంబర్‌ను వెతుకుతుంది.

## కంప్యూటర్‌లో ఫైల్ తయారు చేయడం

1. SQLite ఎడిటర్ (DB Browser for SQLite, SQLiteStudio, లేదా `sqlite3` కమాండ్-లైన్ టూల్) ఇన్‌స్టాల్ చేయండి.
2. కొత్త డేటాబేస్ ఫైల్ తయారు చేయండి.
3. అవసరమైన టేబుల్ తయారు చేసి మీ డేటా ఇన్సర్ట్ చేయండి.
4. ఫైల్‌ను సరైన ఎక్స్టెన్షన్‌తో (`.bible`, `.commentary`, `.book`, `.devotional`, లేదా `.lexicon`) సేవ్ చేయండి.

## Theodia లోకి ఇంపోర్ట్ చేయడం

1. ఫైల్‌ను మీ పరికరానికి ట్రాన్స్‌ఫర్ చేయండి (AirDrop, ఇమెయిల్, క్లౌడ్ స్టోరేజ్, లేదా USB).
2. **Theodia** తెరవండి.
3. **సెట్టింగులు** → **Manage Resources** కు వెళ్లండి.
4. **Import from File**పై నొక్కండి.
5. మీ ఫైల్‌ను ఎంచుకోండి.

యాప్ ఫైల్‌ను వాలిడేట్ చేస్తుంది (అవసరమైన టేబుల్ తనిఖీ చేస్తుంది), దానిని యాప్ డేటా ఫోల్డర్‌లోకి కాపీ చేస్తుంది, మరియు ఆటోమేటిక్‌గా ఎనేబుల్ చేస్తుంది. ఫైల్ చెల్లనిదైతే, తప్పు ఏమిటో వివరించే ఎర్రర్ మెసేజ్ కనిపిస్తుంది.

## పరిమితులు

- మీరు బిల్ట్-ఇన్ వనరులను ఓవర్‌రైట్ చేయలేరు. బిల్ట్-ఇన్ బైబిల్, వ్యాఖ్యానం, లేదా పుస్తకంతో ఒకే పేరు ఉన్న ఫైల్‌ను ఇంపోర్ట్ చేయడానికి ప్రయత్నిస్తే, ఇంపోర్ట్ విఫలమవుతుంది.
- బైబిల్ ఫైల్స్‌కు `Verses` లేదా `Bible` టేబుల్ అవసరం. రెండూ లేకపోతే, ఇంపోర్ట్ విఫలమవుతుంది.
- వ్యాఖ్యాన ఫైల్స్‌కు `Commentary` టేబుల్ అవసరం.
  - Book commentariesకు `Book` మరియు `Scripture` (లేదా `Content`) కాలమ్‌లు అవసరం.
  - Chapter commentariesకు `Book`, `Chapter`, మరియు `Scripture` (లేదా `Content`) కాలమ్‌లు అవసరం.
  - Verse commentariesకు `Book`, `Chapter`, `Verse`, మరియు `Scripture` (లేదా `Content`) కాలమ్‌లు అవసరం.
- పుస్తకం ఫైల్స్‌కు `Reference` టేబుల్ అవసరం.
- పదకోశ ఫైల్స్‌కు `Lexicon` టేబుల్ అవసరం.
- భక్తి పాఠ ఫైల్స్‌కు `devotional` టేబుల్ అవసరం.

## చిట్కాలు

- ఫైల్ సైజులను నియంత్రించి ఉంచండి. చాలా పెద్ద SQLite ఫైల్స్ పాత పరికరాలలో మెమరీ సమస్యలు కలిగించవచ్చు.
- ముందుగా కంప్యూటర్‌లో మీ ఫైల్‌ను పరీక్షించండి. SQLite బ్రౌజర్‌లో తెరిచి, అవసరమైన టేబుల్ నుండి `SELECT * FROM` రన్ చేసి డేటా సరిగ్గా ఉందని ధృవీకరించండి.
- బైబిల్స్ కోసం, `Book` కాలమ్ నంబర్లు ఉపయోగించిందని నిర్ధారించుకోండి (1 = Genesis, 66 = Revelation).
- వ్యాఖ్యానాల కోసం, వ్యాఖ్యాన టెక్స్ట్ కాలమ్‌గా మీరు `Scripture` లేదా `Content` ను ఉపయోగించవచ్చు.
- పుస్తకాల కోసం, `Content` కాలమ్‌లో HTML ఫీడింగ్ చేయబడుతుంది. సింపుల్‌గా ఉంచండి: `<b>`, `<i>`, `<br>`, మరియు `<hr>` సురక్షితం.

## గట్టిగా ఇప్పటికే ఉన్న వనరులెక్కడ కనుగొనాలి

Theodia [Unique Bible App](https://github.com/eliranwong/UniqueBible) ప్రాజెక్ట్ నుండి వనరులను చదవగలదు. అక్కడ సరైన SQLite ఫార్మాట్‌లో చాలా బైబిల్స్, వ్యాఖ్యానాలు, పుస్తకాలు, మరియు ఇతర వనరులు ఉన్నాయి. వాటిని ఎలా కనుగొని జోడించాలో [Getting Extra Resources](theodia://help/getting-core-files) గైడ్ చూడండి.
