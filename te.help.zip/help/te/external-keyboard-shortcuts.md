---
title: బాహ్య కీబోర్డ్ షార్ట్‌కట్స్
level: everyday
categories: [tablet, settings]
summary: iPadతో బాహ్య కీబోర్డ్ జోడించినప్పుడు ఉపయోగించే సంపూర్ణ కీబోర్డ్ షార్ట్‌కట్స్ సూచిక.
---

# ⌨️ బాహ్య కీబోర్డ్ షార్ట్‌కట్స్

మీరు Theodiaను iPadలో బాహ్య కీబోర్డ్‌తో (మ్యాజిక్ కీబోర్డ్, బ్లూటూత్ లేదా USB కీబోర్డ్) ఉపయోగిస్తే, స్క్రీన్‌ను తాకకుండానే యాప్‌ను నావిగేట్ చేయవచ్చు.

> **మోడ్:** కొన్ని షార్ట్‌కట్స్ మీ ప్రస్తుత యూజర్ మోడ్‌లో ఆ ఫీచర్ అందుబాటులో ఉన్నప్పుడు మాత్రమే పనిచేస్తాయి. ఉదాహరణకు, `Cmd + Option + 6` (Bookmarks) మరియు `Cmd + Option + 7` (Highlights) Reader మోడ్‌లో ఏమీ చేయవు. **Settings** → **App User Mode**లో మోడ్‌లను మార్చండి.

షార్ట్‌కట్స్ **iPad**లో పనిచేస్తాయి.

## సాధారణ షార్ట్‌కట్స్ (ఎక్కడైనా)

| Shortcut | Action |
| --- | --- |
| `Cmd + /` | ఈ కీబోర్డ్ షార్ట్‌కట్స్ సహాయాన్ని చూపించు |
| `Cmd + .` | మోడల్ / ప్యానల్ మూసివేయి (Escape ప్రత్యామ్నాయం) |
| `Cmd + Option + 1` | Home ట్యాబ్‌కు వెళ్లు |
| `Cmd + Option + 2` | Bibles ట్యాబ్‌కు వెళ్లు |
| `Cmd + Option + 3` | Books ట్యాబ్‌కు వెళ్లు |
| `Cmd + Option + 4` | Devotionals ట్యాబ్‌కు వెళ్లు |
| `Cmd + Option + 5` | Search ట్యాబ్‌కు వెళ్లు |
| `Cmd + Option + 6` | Bookmarks ట్యాబ్‌కు వెళ్లు (Standard మరియు Scholar) |
| `Cmd + Option + 7` | Highlights ట్యాబ్‌కు వెళ్లు (Standard మరియు Scholar) |
| `Cmd + Option + 8` | Notes ట్యాబ్‌కు వెళ్లు (Standard మరియు Scholar) |
| `Cmd + Option + 9` | AI ట్యాబ్‌కు వెళ్లు (Scholar మాత్రమే, ప్రారంభించి ఉంటే) |
| `Cmd + Option + 0` | Help ట్యాబ్‌కు వెళ్లు |
| `Cmd + Option + I` | About ట్యాబ్‌కు వెళ్లు |
| `Cmd + [` | వెనక్కి వెళ్లు |
| `Cmd + F` | Search తెరవు |
| `Cmd + K` | Launcher Menu తెరవు (Scholar) |
| `Cmd + ,` | Settings తెరవు |
| `Cmd + Shift + M` | ప్రధాన మెనూ తెరవు |
| `Cmd + Shift + T` | థీమ్‌ను మార్చు (default / dark) |
| `Cmd + Shift + U` | యూజర్ మోడ్ పికర్ తెరవు |
| `Escape` | మోడల్ మూసివేయి / ప్యానల్ మూసివేయి |

## బైబిల్ రీడర్ షార్ట్‌కట్స్

ఇవి **Study Reader** మరియు **Focus Reader** రెండింటిలోనూ పనిచేస్తాయి.

| Shortcut | Action |
| --- | --- |
| `← Left Arrow` | మునుపటి అధ్యాయం |
| `→ Right Arrow` | తదుపరి అధ్యాయం |
| `Cmd + R` | Study మరియు Focus Readerల మధ్య మారు (Standard మరియు Scholar) |
| `Cmd + Option + V` | వర్షన్ పికర్ తెరవు |
| `Cmd + Option + B` | పుస్తకం పికర్ తెరవు |
| `Cmd + Option + C` | అధ్యాయం పికర్ తెరవు |
| `Cmd + T` | TTS మార్చు (ఆడుతున్నప్పుడు/పాజ్‌లో ఆపేయండి, నిశ్చలంగా ఉన్నప్పుడు ప్రారంభించండి) |
| `Cmd + Option + T` | TTS ప్లే / పాజ్ |

## Study Reader మాత్రమే

| Shortcut | Action |
| --- | --- |
| `↑ Up Arrow` | మునుపటి వచనాన్ని ఎంచుకోండి |
| `↓ Down Arrow` | తదుపరి వచనాన్ని ఎంచుకోండి |
| `Cmd + ↑` | మొదటి వచనాన్ని ఎంచుకోండి |
| `Cmd + ↓` | చివరి వచనాన్ని ఎంచుకోండి |
| `Cmd + ←` | అధ్యాయం 1కి వెళ్లు |
| `Cmd + →` | చివరి అధ్యాయానికి వెళ్లు |
| `Cmd + 0`–`9` | నేరుగా వచనాన్ని ఎంచుకోవడం (అంకెలు టైప్ చేయండి, ఉదా. `Cmd + 1` `Cmd + 6` వచనం 16 కోసం) |
| `Cmd + P` | సమాంతర బైబిళ్లను మార్చు (Standard మరియు Scholar) |
| `Cmd + B` | ఎంచుకున్న వచనాన్ని bookmark చేయు (Standard మరియు Scholar) |
| `Cmd + H` | ఎంచుకున్న వచనాన్ని highlight చేయు (Standard మరియు Scholar) |
| `Cmd + N` | ఎంచుకున్న వచనానికి నోట్ జోడించు (Standard మరియు Scholar) |
| `Cmd + C` | ఎంచుకున్న వచన అనువాదాలను పోల్చు (Standard మరియు Scholar) |
| `Cmd + X` | ఎంచుకున్న వచనానికి క్రాస్-రిఫరెన్సులు తెరవు (Standard మరియు Scholar) |
| `Cmd + I` | Word Info తెరవు (Scholar) |
| `Cmd + D` | ఎంచుకున్న వచనానికి నిఘంటువు తెరవు (Scholar) |
| `Cmd + A` | ఎంచుకున్న వచనానికి AI ప్యానల్ తెరవు (Scholar) |
| `Cmd + Option + S` | ఉపశీర్షికలను మార్చు |
| `Cmd + Option + W` | తెరిచి ఉన్న స్టడీ ప్యానల్స్ అన్నింటినీ మూసివేయు |
| `Cmd + Option + M` | వచన చర్య మెనూ తెరవు |

## Focus Reader మాత్రమే

| Shortcut | Action |
| --- | --- |
| `↑ Up Arrow` | పైకి స్క్రాల్ చేయు |
| `↓ Down Arrow` | క్రిందికి స్క్రాల్ చేయు |
| `Cmd + ↑` | అగ్రానికి స్క్రాల్ చేయు |
| `Cmd + ↓` | అంచుకు స్క్రాల్ చేయు |
| `Cmd + =` | జూమ్ ఇన్ |
| `Cmd + -` | జూమ్ అవుట్ |

## Search

| Shortcut | Action |
| --- | --- |
| `Return` | శోధన అమలు చేయు |
| `Cmd + Return` | శోధన క్లియర్ చేసి ఇన్‌పుట్‌పై ఫోకస్ పెట్టు |
| `Cmd + ↑` | ఫలితాలను పైకి స్క్రాల్ చేయు |
| `Cmd + ↓` | ఫలితాలను క్రిందికి స్క్రాల్ చేయు |
| `Cmd + Option + A` | అన్ని స్కోప్ అంశాలను ఎంచుకోండి |
| `Cmd + Option + C` | అన్ని స్కోప్ అంశాలను తీసివేయండి |
| `Cmd + Option + B` | Bible శోధన మోడ్ |
| `Cmd + Option + O` | Book శోధన మోడ్ |
| `Cmd + Option + D` | Dictionary శోధన మోడ్ (Scholar) |
| `Cmd + Option + X` | Lexicon శోధన మోడ్ (Scholar) |

## శోధన ఫలితాలు

| Shortcut | Action |
| --- | --- |
| `Cmd + S` | Save-all షీట్ తెరవు |
| `Cmd + ↑` | ఫలితాలను పైకి స్క్రాల్ చేయు |
| `Cmd + ↓` | ఫలితాలను క్రిందికి స్క్రాల్ చేయు |

## Book Reader

| Shortcut | Action |
| --- | --- |
| `← Left Arrow` | మునుపటి అధ్యాయం |
| `→ Right Arrow` | తదుపరి అధ్యాయం |
| `Cmd + ↑` | మునుపటి అధ్యాయం |
| `Cmd + ↓` | తదుపరి అధ్యాయం |
| `↑ Up Arrow` | పైకి స్క్రాల్ చేయు |
| `↓ Down Arrow` | క్రిందికి స్క్రాల్ చేయు |
| `Cmd + B` | ప్రస్తుత అధ్యాయానికి bookmark చేయు |
| `Cmd + J` | అధ్యాయం పికర్ తెరవు |
| `Cmd + L` | వాయిస్ పికర్ తెరవు |
| `Cmd + T` | TTS మార్చు |
| `Cmd + Option + T` | TTS ప్లే / పాజ్ |

## Devotional Reader

| Shortcut | Action |
| --- | --- |
| `← Left Arrow` | మునుపటి రోజు |
| `→ Right Arrow` | తదుపరి రోజు |
| `↑ Up Arrow` | పైకి స్క్రాల్ చేయు |
| `↓ Down Arrow` | క్రిందికి స్క్రాల్ చేయు |
| `Cmd + ↑` | పైకి స్క్రాల్ చేయు (పెద్ద మొత్తంలో) |
| `Cmd + ↓` | క్రిందికి స్క్రాల్ చేయు (పెద్ద మొత్తంలో) |
| `Cmd + D` | తేదీ పికర్ తెరవు |
| `Cmd + T` | TTS మార్చు |
| `Cmd + Option + T` | TTS ప్లే / పాజ్ |

## AI Chat

| Shortcut | Action |
| --- | --- |
| `Cmd + Return` | సందేశం పంపు |
| `Cmd + N` | కొత్త చాట్ |
| `Cmd + D` | సంభాషణ డ్రాయర్‌ను మార్చు |
| `Cmd + Option + C` | ప్రస్తుత చాట్ క్లియర్ చేయు |
| `Cmd + S` | సేవ్ మెనూ తెరవు |
| `Escape` | డ్రాయర్ / మెనూ మూసివేయు |

## Bookmarks

| Shortcut | Action |
| --- | --- |
| `↑ Up Arrow` / `↓ Down Arrow` | బుక్‌మార్క్ ఎంచుకోండి |
| `Return` | బుక్‌మార్క్ తెరవు (టాబ్లెట్: ఎంచుకోండి) |
| `Cmd + R` | సందర్భంలో బుక్‌మార్క్ చదవు |
| `Cmd + M` | ఎంచుకున్న బుక్‌మార్క్‌ను ఫోల్డర్లకు తరలించు |
| `Cmd + N` | ఫోల్డర్లను నిర్వహించు |
| `Escape` | వివర ప్యానల్ / ఫోల్డర్ పికర్ మూసివేయు |

**Save to Folder** పికర్‌లో, `↑ Up Arrow` / `↓ Down Arrow` ఎంపికను కదుపుతుంది, `Return` ఎంచుకున్న ఫోల్డర్‌ను టాగులు చేస్తుంది లేదా హైలైట్ చేసిన చర్యను క్రియాశీలం చేస్తుంది, మరియు `Escape` పికర్‌ను మూసేస్తుంది. **+ Create Folder** వరుస జాబితా పైభాగంలో ఉంటుంది.

## బైబిల్ నోట్స్

| Shortcut | Action |
| --- | --- |
| `↑ Up Arrow` / `↓ Down Arrow` | నోట్ ఎంచుకోండి |
| `Return` | నోట్ తెరవు |
| `Cmd + Return` | ఫిల్టర్ ఇన్‌పుట్‌పై ఫోకస్ పెట్టు |
| `Escape` | వివర / ఎడిటర్ మూసివేయు |

## Highlights

| Shortcut | Action |
| --- | --- |
| `↑ Up Arrow` / `↓ Down Arrow` | హైలైట్ ఎంచుకోండి |
| `Return` | హైలైట్ తెరవు |
| `Cmd + Return` | ఫిల్టర్ ఇన్‌పుట్‌పై ఫోకస్ పెట్టు |
| `Escape` | వివర ప్యానల్ మూసివేయు |

## Bible List

| Shortcut | Action |
| --- | --- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | తదుపరి బైబిల్ |
| `← Left Arrow` / `↑ Up Arrow` | మునుపటి బైబిల్ |
| `Return` | ఫోకస్‌లో ఉన్న బైబిల్ తెరవు |
| `Cmd + Shift + S` | ఫోకస్‌లో ఉన్న బైబిల్ కోసం favorite మార్చు |
| `Escape` | వెనక్కి వెళ్లు |

## Bible Books Screen

| Shortcut | Action |
| --- | --- |
| `Tab` / `→ Right Arrow` | తదుపరి పుస్తకం |
| `← Left Arrow` | మునుపటి పుస్తకం |
| `↓ Down Arrow` | గ్రిడ్‌లో దిగువన ఉన్న పుస్తకం |
| `↑ Up Arrow` | గ్రిడ్‌లో పైన ఉన్న పుస్తకం |
| `Cmd + ↓` | తదుపరి విభాగం (OT / NT) |
| `Cmd + ↑` | మునుపటి విభాగం (OT / NT) |
| `Return` | ఫోకస్‌లో ఉన్న పుస్తకాన్ని తెరవు |
| `Escape` | వెనక్కి వెళ్లు |

## Book List

| Shortcut | Action |
| --- | --- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | తదుపరి పుస్తకం |
| `← Left Arrow` / `↑ Up Arrow` | మునుపటి పుస్తకం |
| `Return` | ఫోకస్‌లో ఉన్న పుస్తకాన్ని తెరవు |
| `Escape` | వెనక్కి వెళ్లు |

## Bible Chapters Screen

| Shortcut | Action |
| --- | --- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | తదుపరి అధ్యాయం |
| `← Left Arrow` / `↑ Up Arrow` | మునుపటి అధ్యాయం |
| `Return` | ఫోకస్‌లో ఉన్న అధ్యాయాన్ని తెరవు |
| `Escape` | వెనక్కి వెళ్లు |

## Book Chapters Screen

| Shortcut | Action |
| --- | --- |
| `Tab` / `↓ Down Arrow` | తదుపరి అధ్యాయం |
| `↑ Up Arrow` | మునుపటి అధ్యాయం |
| `Return` | ఫోకస్‌లో ఉన్న అధ్యాయాన్ని తెరవు |
| `Cmd + Return` | శోధన/ఫిల్టర్ ఇన్‌పుట్‌పై ఫోకస్ పెట్టు |
| `Escape` | వెనక్కి వెళ్లు |

## Devotional List

| Shortcut | Action |
| --- | --- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | తదుపరి డెవోషనల్ |
| `← Left Arrow` / `↑ Up Arrow` | మునుపటి డెవోషనల్ |
| `Return` | ఫోకస్‌లో ఉన్న డెవోషనల్ తెరవు |
| `Escape` | వెనక్కి వెళ్లు |

## Charts

Statistics, Goals మరియు Concordance స్క్రీనులపై.

| Shortcut | Action |
| --- | --- |
| `← Left Arrow` | చార్ట్‌లో మునుపటి వర్గాన్ని ఎంచుకోండి |
| `→ Right Arrow` | చార్ట్‌లో తదుపరి వర్గాన్ని ఎంచుకోండి |

చార్ట్ క్రింద క్యాప్షన్ ఎంపికను అనుసరిస్తుంది మరియు కొత్త విలువ పలుకబడుతుంది.

## ప్రధాన మెనూ (তెరిచి ఉన్నప్పుడు)

| Shortcut | Action |
| --- | --- |
| `↑ Up Arrow` | మునుపటి మెనూ అంశం |
| `↓ Down Arrow` | తదుపరి మెనూ అంశం |
| `Return` | హైలైట్ చేసిన అంశాన్ని ఎంచుకోండి |
| `Escape` | మెనూ మూసివేయు |

## Settings

| Shortcut | Action |
| --- | --- |
| `Escape` | తెరిచి ఉన్న మోడల్ / పికర్ మూసివేయు |

## Editor Modals

| Shortcut | Action |
| --- | --- |
| `Cmd + S` | సేవ్ చేయు |
| `Escape` | రద్దు / మూసివేయు |

## టైపింగ్ గార్డ్

మీరు ఒక పాఠ్య క్షేత్రంలో (శోధన పెట్టె, నోట్ ఎడిటర్, AI ఇన్‌పుట్) ఫోకస్‌లో ఉన్నప్పుడు, అనుకోకుండా నావిగేషన్ జరగకుండా arrow keys మరియు `Space` వంటి Cmd లేని షార్ట్‌కట్స్ నిలిపివేయబడతాయి. `Cmd` ఉపయోగించే షార్ట్‌కట్స్ (ఉదా., `Cmd + S`, `Cmd + B`) టైప్ చేస్తున్నప్పటికీ పనిచేస్తాయి.
