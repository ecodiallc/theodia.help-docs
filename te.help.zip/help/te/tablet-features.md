---
title: ట్యాబ్లెట్ ఫీచర్లు
level: everyday
categories: [layout, tablet]
summary: Theodia ట్యాబ్లెట్లు మరియు పెద్ద స్క్రీన్లకు ఎలా అనుగుణంగా మారుతుంది, split views, side panels మరియు two-pane పఠన మోడ్లతో.
---

# 📱 ట్యాబ్లెట్ ఫీచర్లు

Theodia ట్యాబ్లెట్లలో పెద్ద స్క్రీన్లను సద్వినియోగం చేసుకోవడానికి రూపొందించబడింది. ట్యాబ్లెట్‌లో (లేదా సుమారు 700 పిక్సెల్స్ కంటే వెడల్పు ఉన్న ఏదైనా పరికరంలో), అనేక చోట్ల యాప్ స్వయంచాలకంగా two-column layoutకు మారుతుంది.

> **Mode:** ఇక్కడ వివరించిన ఫీచర్లు మీ ప్రస్తుత యూజర్ మోడ్ వాటికి మద్దతు ఇచ్చినప్పుడు మాత్రమే కనిపిస్తాయి. ఉదాహరణకు, commentary side panels మరియు AI chat కేవలం పండితుడు మోడ్‌లో మాత్రమే. Bookmarks, highlights మరియు notes split viewsకు సాధారణం లేదా పండితుడు మోడ్ అవసరం. Focus Mode స్వచ్ఛమైన single-column పఠనం మాత్రమే చూపిస్తుంది. మోడ్‌లను **సెట్టింగులు** → **App User Mode**లో మార్చండి.

## రీడర్ వచన మెనూ

మీరు ఒక వచన నంబర్ నొక్కినప్పుడు (లేదా వచన టెక్స్ట్ long-press చేసినప్పుడు), **వచన మెనూ** డార్క్ బ్యాక్‌డ్రాప్ మీద **centered card**గా కనిపిస్తుంది.

- **Copy** మరియు **Share** బటన్లు ఎల్లప్పుడూ మెనూ పైన కనిపిస్తాయి.
- **Bookmarks** మరియు **Highlights** ప్రస్తుత స్థితితో చూపబడతాయి.
- **Commentary**, **Dictionary** మరియు **Compare** మెనూ నుండి తెరవబడతాయి. ట్యాబ్లెట్‌లో ఎంచుకున్నప్పుడు ఈ టూల్స్ side panel లేదా wide cardలో కనిపించవచ్చు.
- మెనూ డిస్మిస్ చేయడానికి backdrop లేదా close arrow నొక్కండి.

## వచన Commentary ప్యానెల్

**Commentary** టూల్ ట్యాబ్లెట్‌లో **ప్రత్యేక side panel** తెరుస్తుంది:

- Commentary టెక్స్ట్ Bible టెక్స్ట్ పక్కన కనిపిస్తుంది.
- మీరు Bibleకు స్వతంత్రంగా commentary scroll చేయవచ్చు.
- మూసివేయడానికి **X** నొక్కండి లేదా swipe away చేయండి.
- ప్యానెల్ పైన ఉన్న **book icon** commentary source మార్చడానికి అనుమతిస్తుంది.
- **chapter icon** chapter-level commentary చూడటానికి అనుమతిస్తుంది.

ఫోన్‌లో, commentary full-screen modalగా తెరుచుకుంటుంది.

## అధ్యాయ Commentary

**Chapter Commentary** screens పైన ఉన్న **More** బటన్ నుండి తెరవబడుతుంది, వచన మెనూ నుండి కాదు. ట్యాబ్లెట్‌లో ఇది Verse Commentary లాగే side panelగా తెరుచుకుంటుంది, మీరు commentary మరియు Bible టెక్స్ట్ రెండూ కలిసి చదవవచ్చు.

## Compare tab

**Compare** tab (వచన మెనూలో) ట్యాబ్లెట్‌లో **side panel**గా తెరుచుకుంటుంది. ఇది మీరు ఎనేబుల్ చేసిన ప్రతి parallel versionలో ఎంచుకున్న వచనాన్ని చూపిస్తుంది. మీరు రీడర్‌లో ఆ పద్యానికి జంప్ చేయడానికి ఏ versionైనా నొక్కవచ్చు.

## Dictionary / Strong's popup

**Dictionary** టూల్ (వచన మెనూ → Dictionary) ట్యాబ్లెట్‌లో wide cardగా తెరుచుకుంటుంది. ఇది గ్రీక్ లేదా హీబ్రూ పదం, దాని transliteration, నిర్వచనం మరియు Strong's నంబర్ చూపిస్తుంది. ఆ పదం బైబిల్‌లో ప్రతి సంభవం చూడటానికి **Concordance** బటన్ నొక్కండి.

## పదం నొక్కి Lexicon తెరవడం

ట్యాబ్లెట్‌లో **Word Info** side panelలో, Strong's నంబర్ కలిగిన ప్రతి word card tappable గా ఉంటుంది. ఆ పదం కోసం నేరుగా **Lexicon** ప్యానెల్ తెరవడానికి card నొక్కండి. రీడర్‌ను మూసకుండా studying కొనసాగించడానికి Lexicon ప్యానెల్ Word Info ప్యానెల్‌ను replace చేస్తుంది.

ఫోన్‌లో, Word Info cards tappable కావు, ఎందుకంటే రెండు panels కోసం స్క్రీన్ చాలా చిన్నది.

## Parallel Bibles side by side

సెట్టింగులలో **Parallel Bibles** నొక్కి మూడు వరకు versions ఎంచుకోండి. ట్యాబ్లెట్‌లో, versions **vertical panes**గా పక్కపక్కన కనిపిస్తాయి:

- ప్రతి pane స్వతంత్రంగా scroll అవుతుంది.
- టూల్స్‌తో side panel తెరవడానికి వచన నంబర్ నొక్కవచ్చు.
- **Compare** tab ఎంచుకున్న వచనాలన్నీ ఒకే చోట చూపిస్తుంది.
- ఏ pane పైన **X** నొక్కి close చేసి single-column viewకు తిరిగి రండి.
- top icon barలో **Parallel Bibles** icon (🔵 / ⚪) నొక్కి Settings తెరవకుండానే parallel view ఆన్/ఆఫ్ చేయండి.

ఫోన్‌లో, parallel versions పక్కపక్కన (side by side) కాకుండా ఒకదాని తర్వాత ఒకటి (vertically) చూపబడతాయి. అదే toggle icon ఫోన్లలో కూడా పనిచేస్తుంది.

## బుక్‌మార్కులు మరియు హైలైట్లు split view

ట్యాబ్లెట్‌లో, **బుక్‌మార్కులు** మరియు **హైలైట్లు** ట్యాబ్లు master-detail layout వాడతాయి:

- **ఎడమ వైపు** — బుక్‌మార్కులు లేదా హైలైట్ల జాబితా.
- **కుడి వైపు** — ఒక అంశం నొక్కితే వచనం లేదా పద్య టెక్స్ట్‌తో preview pane తెరుచుకుంటుంది.

మీరు సేవ్ చేసిన అంశాలను స్కిమ్ చేసి ట్యాబ్ విడిచిపెట్టకుండా preview చేయవచ్చు. ఫోన్‌లో, ఒక అంశం నొక్కితే రీడర్ స్క్రీన్‌కు నావిగేట్ అవుతుంది.

## గమనికలు split view

ట్యాబ్లెట్‌లో **గమనికలు** ట్యాబ్ ఎడమవైపు మీ notes జాబితా మరియు కుడివైపు selected note చూపిస్తుంది. Note నొక్కితే side panelలో తెరుచుకుంటుంది, మీరు list వదలకుండా వరుసగా notes స్కిమ్ చేయవచ్చు. Note సృష్టించడం లేదా సవరించడం కూడా side panel వాడుతుంది.

## శోధన split view

ట్యాబ్లెట్‌లో, **Search** ట్యాబ్ శోధన ఫారం ఎడమవైపు మరియు ఫలితాలు కుడివైపు చూపిస్తుంది, మీరు శోధన నడిపిన వెంటనే. మీరు query సరిచేసి, screens మారకుండా results అప్‌డేట్ కావడం చూడవచ్చు. ఫోన్‌లో, search results వేరే screenలో తెరుచుకుంటాయి.

## సెట్టింగులు కేటగిరీ సైడ్‌బార్

ట్యాబ్లెట్‌లో **సెట్టింగులు** screen ఎడమవైపు కేటగిరీ జాబితా (AI, Appearance, Backup, Bibles, etc.) చూపిస్తుంది. భాగం నేరుగా jump చేయడానికి కేటగిరీ నొక్కండి. ఎంచుకున్న కేటగిరీ మాత్రమే expanded అవుతుంది, మొత్తం settings list scroll చేయాల్సిన అవసరం లేదు.

## ట్యాబ్లెట్లలో Bible నావిగేషన్

**Bible List**, **Bible Books** మరియు **Bible Chapters** screens ట్యాబ్లెట్లలో single-columnగానే ఉంటాయి, కానీ విషయం read మరియు tap చేయడం సులభం కావడానికి పెద్ద touch targets, వెడల్పు grids మరియు మరింత spacious padding వాడతాయి. ప్రతి మెట్టుకు full width అవసరమైనందున అవి split-view layout వాడవు.

## Landscape మరియు portrait

ట్యాబ్లెట్ rotate చేయడం ద్వారా layout స్వయంచాలకంగా adjust అవుతుంది. **Landscape**లో side panelsకు plenty of room ఉంటుంది. **Portrait**లో panels సన్నగా అవుతాయి కానీ టెక్స్ట్ పక్కనే ఉంటాయి.

## Selected verse AI chat

**AI** chat వచన మెనూ side panelలో తెరుచుకుంటుంది. ఇది conversation interface చూపిస్తుంది, మీరు selected verse గురించి ప్రశ్నలు అడగవచ్చు. AI response panelలో కనిపిస్తుంది, మరియు మీరు రీడర్‌ను విడిచిపెట్టకుండా conversation కొనసాగించవచ్చు.

## AI screenలో Conversation sidebar

ట్యాబ్లెట్‌లో **AI** ట్యాబ్‌లో conversation list always visible persistent left sidebarగా ఉంటుంది. మీరు menu తెరవకుండా chats మధ్య switch చేయవచ్చు. **New Chat** బటన్ కూడా always visible. ఫోన్‌లో, conversation list popup drawer.

## ఏమి ఒకేలా ఉంటుంది

ప్రతి screen రెండు panesగా split కాదు. ఈ �screens ట్యాబ్లెట్లపై single-columnగానే ఉంటాయి:

- **Bible List** — Bible versions జాబితా (full width)
- **Bible Books** — book grid మరియు sections (full width)
- **Bible Chapters** — chapter grid (full width)
- **PDFలు** — PDF లైబ్రరీ వెడల్పు card grid వాడుతుంది (full width)
- **సెట్టింగులు** — individual settings pages (full width)
- **Help** — help ఆర్టికల్స్ (full width)

## సారాంశం

ట్యాబ్లెట్‌లో, మీకు లభిస్తుంది:

- side-by-side vertical panesలో **Parallel Bibles**
- persistent side panelsలో **Commentary**
- wide cardsలో **Compare** మరియు **Dictionary**
- ఏ Word Info cardపై tap చేసి **Lexicon**
- master-detail split viewsలో **Bookmarks, Highlights, Notes, Devotionals, Books, సెట్టింగులు**
- search form పక్కన inline resultsతో **Search**
- automatic layout changesతో **Landscape** మరియు **portrait** రెండూ మద్దతు

ఫోన్‌లో, అన్నీ traditional single-column drill-down navigation వాడతాయి. యాప్ launch సమయంలో screen width detect చేసి సరైన layout స్వయంచాలకంగా ఎంచుకుంటుంది.
