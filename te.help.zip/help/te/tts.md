---
title: బిగ్గరగా చదవడం (Text-to-Speech)
level: everyday
categories: tts
summary: Theodiaను బైబిల్ లేదా భక్తిపాఠాన్ని బిగ్గరగా చదివించడం. ఎలా ఉపయోగించాలి, వాయిస్ ఎలా ఎంచుకోవాలి, మరియు నిశ్శబ్దంగా ఉంటే ఏమి చేయాలి.
---

# బిగ్గరగా చదవడం (Text-to-Speech)

> **Mode:** Text-to-speech **సాధారణం** మరియు **పండితుడు** మోడ్‌లలో అందుబాటులో ఉంది. ఫోకస్ బైబిల్ మాత్రం స్వచ్ఛమైన, గందరగోళములేని పఠనానికి మాత్రమే. మోడ్‌లను **సెట్టింగులు** → **App User Mode**లో మార్చండి.

Theodia మీ పరికరం యొక్క text-to-speech (TTS) వాయిస్ ఉపయోగించి టెక్స్ట్ బిగ్గరగా చదివించగలదు. మీరు ఒక వచనం, మొత్తం అధ్యాయం లేదా భక్తిపాఠం వినవచ్చు. ఇది hands-free పఠనం, నడుస్తూ లేదా ప్రయాణిస్తూ వినడం, ఆడియోతో పాటు చదవడం లేదా మీ కళ్లకు విశ్రాంతి ఇవ్వడం కోసం ఉపయోగపడుతుంది.

## Listen బటన్ ఎక్కడ ఉంది

మీరు మూడు చోట్ల listen బటన్ కనుగొంటారు.

### 1. వచన మెనూలో (ఒక వచనం)

ఒక వచనం వినడానికి ఇది వేగవంతమైన మార్గం. [Study Mode](theodia://help/study-mode)లో ఒక అధ్యాయం తెరిచి, వచనం నొక్కి వచన మెనూ తెరవండి, ఆపై **Speak** (🔊) నొక్కండి. చదవడం ఆ వచనం నుండి ప్రారంభమవుతుంది. స్క్రీన్ క్రింద play, pause, rewind, fast-forward మరియు వాయిస్ పికర్‌తో ఒక చిన్న కంట్రోల్ బార్ కనిపిస్తుంది.

Speak option interlinear Bibles (MIB — Marvel Interlinear Bible — మరియు OHGB)కు చూపబడదు, ఎందుకంటే అవి సహజంగా చదవని వేరే layoutలో పదాలు చూపిస్తాయి.

### 2. అధ్యాయం పైన (మొత్తం అధ్యాయం)

మీరు అధ్యాయం చదువుతున్నప్పుడు, స్క్రీన్ పైన icons వరుస చూడండి. **Listen** (🔊) నొక్కి మొదటి నుండి మొత్తం అధ్యాయాన్ని చదివించండి. ఆడియో ప్లే అవుతున్నప్పుడు బటన్ stop button (⏹)గా మారుతుంది. ఆపడానికి మళ్లీ నొక్కండి. అదే కంట్రోల్ బార్ క్రింద కనిపిస్తుంది.

మీరు వేరే వచనానికి జంప్ చేయవచ్చు, మరియు అక్కడ Listen బటన్ ఆ వచనం నుండి ప్రారంభమవుతుంది.

### 3. భక్తిపాఠంలో

ఏదైనా భక్తి రోజు తెరిచి, పఠనం పైన **Listen** (🔊) బటన్ నొక్కండి. మొత్తం భక్తి టెక్స్ట్ sentence by sentence బిగ్గరగా చదవబడుతుంది. క్రింద ఉన్న కంట్రోల్ బార్ play, pause, rewind మరియు voice controls ఇస్తుంది.

## కంట్రోల్ బార్ ఉపయోగించడం

ఆడియో ప్లే అవుతున్నప్పుడు, స్క్రీన్ క్రింద చిన్న బార్ కనిపిస్తూ ఉంటుంది. ఇందులో ఆరు controls ఉన్నాయి:

- ⏪ **Rewind** — ఒక వచనం వెనక్కి (లేదా భక్తిపాఠంలో ఒక sentence)
- ⏸ **Pause / ▶ Resume** — స్థానం కోల్పోకుండా pause. పునఃప్రారంభించడానికి మళ్లీ నొక్కండి.
- ⏩ **Fast forward** — తదుపరి వచనానికి (లేదా భక్తిపాఠంలో తదుపరి sentence) skip
- 🎙 **Voice** — అధ్యాయం విడిచిపెట్టకుండా voice picker తెరవండి (క్రింద చూడండి)
- ⚙ **Options** — extended options panel తెరవండి (క్రింద చూడండి)
- **Stop** — స్క్రీన్ పైన 🔊 బటన్, లేదా ఆడియో ప్లే అవుతున్నప్పుడు దాని స్థానంలో వచ్చే ⏹ నొక్కి bar ఆపి మూసేయండి.

అధ్యాయం ముగిసినప్పుడు లేదా stop నొక్కినప్పుడు కంట్రోల్ బార్ మూసుకుంటుంది.

### Extended options

Extra playback options తెరవడానికి ⚙ నొక్కండి. ఈ సెట్టింగులు ప్రస్తుత అధ్యాయానికి మాత్రమే ఉంటాయి మరియు మీరు అధ్యాయం మార్చినప్పుడు లేదా listening ఆపినప్పుడు reset అవుతాయి.

- ⏮ **Back to begin** — మీరు సెట్ చేసిన range యొక్క మొదటి వచనానికి jump.
- **Begin** — చదవడం ప్రారంభమయ్యే వచన నంబర్ టైప్ చేయండి.
- **End** — చదవడం ఆగే వచన నంబర్ టైప్ చేయండి.
- **All** — rangeను మొత్తం అధ్యాయానికి reset చేయండి.
- **()** — parenthetical text (parenthesesలోని టెక్స్ట్) బిగ్గరగా చదవాలా వద్దా టాగిల్.
- 🔁 **Repeat** — end చేరుకున్నప్పుడు చిన్న pauseతో range ప్రారంభం నుండి స్వయంచాలకంగా పునఃప్రారంభం. మీరు begin లేదా end verse సెట్ చేయకుండా దీన్ని ఆన్ చేస్తే, మొత్తం అధ్యాయం repeat అవుతుంది.

### ప్రార్థన స్క్రీన్లలో

Creeds మరియు fixed prayers, generated prayers, మరియు prayer routinesకు వాటి స్వంత extended options ఉంటాయి. కంట్రోల్ బార్‌లో ⚙ నొక్కి expand చేయండి:

- **Speed** — రేటు (ఉదాహరణకు `1x`) నొక్కి 0.1x నుండి 1.5x వరకు రీడింగ్ స్పీడ్ ఎంచుకోండి. మీ ఎంపిక గుర్తుంచుకోబడుతుంది మరియు తర్వాత మీరు ఏదైనా బిగ్గరగా చదివించినప్పుడు ఉపయోగించబడుతుంది.
- **()** — parenthetical text బిగ్గరగా చదవాలా వద్దా టాగిల్.
- 🔁 **Repeat** — ముగిసినప్పుడు చిన్న pauseతో ప్రార్థన ప్రారంభం నుండి స్వయంచాలకంగా పునఃప్రారంభం. ఒక creed లేదా fixed prayer కంఠస్థం చేయడానికి ఇది ఉపయోగపడుతుంది.

Speed మార్చడం వెంటనే అమలవుతుంది, స్థానం కోల్పోకుండా. Parenthetical option ఆన్ లేదా ఆఫ్ చేయడం ప్రారంభం నుండి ప్రార్థన మళ్లీ ప్రారంభమయ్యేలా చేస్తుంది, మార్పు మొదటి నుండి వినిపించడానికి.

## వాయిస్ ఎలా మార్చాలి

Theodia పఠనం కోసం ఏ వాయిస్ ఉపయోగించాలో మీరు ఎంచుకోవచ్చు. వేరే యాక్సెంట్, వేరే భాష లేదా device default కంటే వేగవంతమైన/నెమ్మదైన వాయిస్ కావాలంటే ఇది ఉపయోగపడుతుంది.

1. **సెట్టింగులు** తెరవండి.
2. **Speech** విభాగం కనుగొనండి.
3. **Select Voice** నొక్కండి.
4. వాయిస్‌ల జాబితా కనిపిస్తుంది. మొదటి row **System Default**, device ఇష్టపడే వాయిస్ వాడుతుంది. కొత్త defaultగా చేయడానికి వేరే row నొక్కండి.
5. మీ ఎంపిక సేవ్ చేయబడుతుంది మరియు తర్వాత మీరు **Listen** లేదా **Speak** నొక్కినప్పుడు ఉపయోగించబడుతుంది.

అధ్యాయం విడిచిపెట్టకుండా same picker తెరవడానికి listening control barలో 🎙 చిహ్నం కూడా నొక్కవచ్చు.

Voice availability పూర్తిగా మీ పరికరంపై ఆధారపడి ఉంటుంది. iOS మరియు Android ప్రతిదీ built-in voices సెట్‌తో వస్తాయి. మీ పరికరంలోని **Accessibility** లేదా **Language & Input** సెట్టింగుల నుండి మీరు మరిన్ని voices ఇన్‌స్టాల్ చేయవచ్చు. Theodia మీ పరికరంలో ఇన్‌స్టాల్ చేయబడిన any voiceను ఉపయోగించగలదు.

## Favorite voices

మీ పరికరంలో చాలా voices ఉంటే, ప్రతిసారి full list scroll చేయడం slow అవుతుంది. మీరు **favorite voices** యొక్క చిన్న జాబితా సృష్టించవచ్చు మరియు voice pickers ఆ voices మాత్రమే చూపిస్తాయి.

1. **సెట్టింగులు** తెరవండి.
2. **Speech** విభాగం కనుగొనండి.
3. **Favorite Voices** (విభాగంలో పైన మొదటి row) నొక్కండి.
4. Favorites స్క్రీన్ తెరవడానికి **Set Favorite Voices** నొక్కండి.
5. Preview చేయడానికి వాయిస్ పక్కన play బటన్ నొక్కండి. Favoritesకు జోడించడానికి స్టార్ నొక్కండి. మీరు ఇష్టమైనన్ని voices favorite చేయవచ్చు.
6. వెనక్కి వెళ్లండి. Theodiaలోని voice pickers ఇప్పుడు your favorites మాత్రమే చూపిస్తాయి.

మీరు అన్ని favorites తొలగిస్తే, pickers తిరిగి ప్రతి voice చూపిస్తాయి. Favorite voices Theodia సెట్టింగులు backup మరియు restoreలో చేర్చబడతాయి.

## ప్రతి Bibleకు వేరే వాయిస్ సెట్ చేయడం

మీరు ప్రతి Bible translationకు దాని స్వంత voice ఇవ్వవచ్చు. చాలా వేరుగా చదివే translations మధ్య switch చేసినప్పుడు ఇది ఉపయోగపడుతుంది — ఉదాహరణకు, KJVకు మరింత formal voice మరియు NIV లేదా NLT వంటి modern translationకు more conversational voice. వేర్వేరు భాషలలో Bibles వింటే, ప్రతి ఒక్కటి right accentలో బిగ్గరగా చదివించడానికి ఇది సహాయపడుతుంది.

1. **సెట్టింగులు** తెరవండి.
2. **Speech** విభాగం కనుగొనండి.
3. **Bible Voices** కోసం చూడండి.
4. జాబితాలో ఏదైనా Bible నొక్కండి.
5. ఆ అనువాదం కోసం మీరు కోరుకున్న voice ఎంచుకోండి. మొదటి row **System Default**, ఆ Bible కోసం main TTS voice వాడుతుంది.
6. ఏ ఇతర Bibleకైనా repeat చేయండి.

Header custom voice సెట్ చేసిన Bible translations ఎన్ని ఉన్నాయో చూపిస్తుంది. voice సెట్ చేసినప్పుడు **Select Voice**, **Commentary Voice**, **Bible Notes Voice** మరియు **Devotional Voice** కూడా count చూపిస్తాయి.

తర్వాత మీరు ఆ Bible నుండి అధ్యాయం వింటే, Theodia మీరు ఎంచుకున్న voice వాడుతుంది. మీరు మార్చని ఇతర Bibles అన్నీ మీరు మార్చేంత వరకు main default voice వాడుకుంటాయి.

## బ్యాక్‌గ్రౌండ్‌లో పఠనం కొనసాగించడం

డిఫాల్ట్‌గా, మీరు reader screen విడిచినప్పుడు, మరొక యాప్‌కు switch చేసినప్పుడు లేదా phone lock చేసినప్పుడు Theodia speech ఆపుతుంది. మీరు ఇక సక్రియంగా చదవడం లేనప్పుడు unexpected audio రాకుండా ఇది నిరోధిస్తుంది.

Speech బ్యాక్‌గ్రౌండ్‌లో కొనసాగించడానికి:

1. **సెట్టింగులు** తెరవండి.
2. **Speech** విభాగం కనుగొనండి.
3. **Continue speech in background** ఆన్ చేయండి.

ఇది ఆన్‌లో ఉన్నప్పుడు, మీరు tabs switch చేయవచ్చు, మరొక యాప్ తెరవవచ్చు లేదా స్క్రీన్ lock చేయవచ్చు, అప్పుడు chapter లేదా devotional చదవడం కొనసాగుతుంది. మీరు notification area నుండి (మీ పరికరం support చేస్తే) pause చేయవచ్చు లేదా skip చేయవచ్చు కాబట్టి control bar activeగా ఉంటుంది.

Speech ఇప్పటికే ప్లే అవుతున్నప్పుడు ఈ toggle **off** చేస్తే, అది వెంటనే ఆగిపోతుంది.

## ఇది పనిచేయకపోతే ఏమి చేయాలి

Text-to-speech మీ పరికరంపై ఆధారపడి ఉంటుంది. Theodia టెక్స్ట్ operating systemకు పంపుతుంది, OS దానిని installed voice ద్వారా బిగ్గరగా చదువుతుంది. ఇది పనిచేయకపోతే, ఈ steps orderలో ప్రయత్నించండి.

### Theodia TTS unavailable అని చెబితే

కొన్ని పరికరాలలో TTS లేదు. **సెట్టింగులు** తెరిచి **TTS** విభాగం చూడండి. ఆ section లేకపోతే, ఈ buildలో మీ పరికరం TTS సపోర్ట్ చేయదు.

### Voice జాబితా empty అయితే

Voice picker "no voices found." చూపించవచ్చు. ఇది సాధారణంగా device voices ఇంకా లోడ్ కాలేదని అర్థం.

1. **సెట్టింగులు → Speech → Select Voice** తెరవండి.
2. జాబితా empty అయితే, dropdown కింద **Retest** బటన్ కోసం చూడండి. నొక్కండి. Theodia device నుండి మళ్లీ voices query చేస్తుంది.
3. ఇంకా empty అయితే, మీ device system settings తనిఖీ చేయండి. iOSలో, **Settings → Accessibility → Spoken Content → Voices** కు వెళ్లి మీ భాషకు voice download చేయండి. Androidలో, **Settings → Language & Input → Text-to-Speech Output**కు వెళ్లి **Install voice data** నొక్కండి.
4. కొత్త voice pick up చేయడానికి Theodia close చేసి reopen చేయండి.

మీరు favorite voices సెట్ చేసి జాబితా empty అయితే, కనీసం ఒక favorite ఈ పరికరంలో installed voiceకు match అవుతుందని నిర్ధారించండి.

### Speak నొక్కినప్పుడు ఏమీ జరగకపోతే

- Device silent modeలో లేదని తనిఖీ చేయండి. చాలా పరికరాలు silent modeలో TTS audio ప్లే చేయవu.
- Device volume up ఉండాలి.
- **సెట్టింగులు → Speech**లో **Retest** బటన్ ప్రయత్నించండి.
- **సెట్టింగులు** తెరిచి bottom లోని **System** విభాగం చూడండి. **TTS** row **Available** చెప్పాలి. **Unavailable** చెబితే, TTS operating-system levelలో off చేయబడింది. అక్కడ re-enable చేసి, తర్వాత Theodia reopen చేయండి.

### Audio ప్లే అవుతుంది కానీ తప్పు భాష

Theodia current content యొక్క భాషలో text పంపుతుంది మరియు మీరు ఎంచుకున్న voice కోరుతుంది. ఎంచుకున్న voice వేరే భాష కోసమైతే, device ఇంకా text చదవవచ్చు కానీ వింతగా అనిపిస్తుంది.

1. **సెట్టింగులు → Speech → Select Voice** తెరవండి.
2. తగిన వాయిస్ pick చేయడానికి deviceకు వదిలేయడానికి **System Default** ఎంచుకోండి, లేదా మీరు చదువుతున్న text భాషకు matching language కలిగిన voice ఎంచుకోండి.

Theodia ప్రస్తుతం Greek లేదా Hebrew interlinear Biblesను బిగ్గరగా చదవదు. ఆ అనువాదాలలో Speak మరియు Listen బటన్లు hidden.

### Audio ప్లే అవుతుంది కానీ early ఆగిపోతుంది

Verse missing లేదా unreadable అయితే, chapter తదుపరిదానికి skip అవుతుంది. కొన్ని verses తర్వాత bar by itself close అయితే, మళ్లీ ప్రారంభించడానికి స్క్రీన్ పైన **Listen** (🔊) బటన్ నొక్కండి.

### Speech ప్లే అవుతోంది కానీ ఎక్కడ ప్రారంభమైందో తెలియదు

మీరు **Continue speech in background** ఆన్ చేసి తర్వాత audio వింటున్నారు కానీ ఏ screen start చేసిందో కనుగొనలేకపోతే, యాప్‌లో ఎక్కడైనా దాన్ని ఆపవచ్చు.

1. **సెట్టింగులు** తెరవండి.
2. **Speech** విభాగం కనుగొనండి.
3. విభాగం bottom లోని red **Stop Speech** బటన్ నొక్కండి.

ఇది Theodiaలో ఏదైనా running text-to-speech వెంటనే ఆపుతుంది. మీరు device app switcher తెరిచి Theodia swipe away చేసి audio force-stop చేయవచ్చు.

### చాలా వేగంగా లేదా నెమ్మదిగా చదువుతుంది

Theodia reading speed కంట్రోల్ చేయదు. Speed chosen voice ద్వారా set చేయబడుతుంది. మార్చడానికి:

- iOSలో: **Settings → Accessibility → Spoken Content → Speaking Rate**.
- Androidలో: **Settings → Language & Input → Text-to-Speech Output → Speech Rate**.

## చిట్కాలు

- అధ్యాయాల మధ్య navigate చేస్తున్నప్పుడు కంట్రోల్ బార్ కనిపిస్తూ ఉంటుంది, కాబట్టి స్థానం కోల్పోకుండా pause, skip లేదా voice మార్చవచ్చు.
- Theodia వచన నంబర్లను చిన్న pausesగా చదువుతుంది. Bar stop చేయవచ్చు, వేరే వచనానికి swipe చేయవచ్చు, ఆపై continue చేయడానికి play నొక్కవచ్చు.
- దీర్ఘ listen-throughs కోసం **Do Not Disturb** ఆన్ చేయండి, notifications audio interrupt చేయకుండా.
- 🔊 బటన్ మీ device యొక్క current volume ఉపయోగిస్తుంది. Headphones plug చేస్తే, volume headphone levelకు switch అవుతుంది.

## PDF బిగ్గరగా చదవడం

Theodia PDF pagesను కూడా బిగ్గరగా చదవగలదు. PDF తెరిచి toolbarలో **Listen** (speaker) బటన్ నొక్కండి. Play/pause, rewind, fast forward, stop, progress bar మరియు speed మరియు voice pickersతో control bar కనిపిస్తుంది. ఒక page ముగిసినప్పుడు, reading స్వయంచాలకంగా తదుపరి pageకు continues.

PDF reading PDF యొక్క installed searchable text మరియు Bible reading కోసం ఉపయోగించిన same voices మరియు speed వాడుతుంది.

## సంబంధిత గైడ్‌లు

- [Study Mode](theodia://help/study-mode) గైడ్ verse menu మరియు top-of-screen buttons గురించి మరింత detailలో వివరిస్తుంది.
- [Focus Mode](theodia://help/focus-mode) గైడ్ bottom barలోని 🔊 బటన్ ద్వారా TTS support చేసే cleaner reading view.
- [Common Problems](theodia://help/common-problems) గైడ్ ఇతర audio, voice మరియు language issuesకు fixes కలిగి ఉంది.
- [Daily Devotionals](theodia://help/daily-devotionals) గైడ్ devotional పఠనం మరియు listen బటన్ ఎక్కడ ఉందో వివరిస్తుంది.
- [PDFలు](theodia://help/pdfs) గైడ్ PDF రీడర్ మరియు దాని listen బటన్ కవర్ చేస్తుంది.
