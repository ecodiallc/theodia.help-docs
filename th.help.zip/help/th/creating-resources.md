---
title: การสร้างแหล่งข้อมูลของคุณเอง
level: advanced
categories: resources
summary: วิธีสร้างพระคัมภีร์ คำอธิบายพระคัมภีร์ หนังสือ บทพระวินิจฉัยประจำวัน และพจนานุกรมศัพท์แบบกำหนดเอง แล้วนำเข้าสู่ Theodia
---

# การสร้างแหล่งข้อมูลของคุณเอง

Theodia รองรับแหล่งข้อมูลแบบกำหนดเองในรูปแบบของ Unique Bible App แต่ละแหล่งข้อมูลเป็นไฟล์ SQLite ที่มีโครงสร้างตารางตามที่กำหนด คุณสร้างไฟล์เหล่านี้บนคอมพิวเตอร์แล้วนำเข้าสู่แอปได้

## ชนิดไฟล์และตารางที่ต้องมี

### พระคัมภีร์ (`.bible`)

ไฟล์พระคัมภีร์เป็นฐานข้อมูล SQLite ที่มีตารางใดตารางหนึ่งจากรายการนี้อย่างน้อยหนึ่งตาราง:

- **`Verses`** — คอลัมน์: `Book` (จำนวนเต็ม, 1-66), `Chapter` (จำนวนเต็ม), `Verse` (จำนวนเต็ม), `Scripture` (ข้อความ)
- **`Bible`** — คอลัมน์: `Book` (จำนวนเต็ม), `Chapter` (จำนวนเต็ม), `Verse` (จำนวนเต็ม), `Scripture` (ข้อความ)

คุณใส่ตาราง **`Details`** ที่มีคอลัมน์ข้อมูลอธิบาย เช่น `Description`, `Abbreviation` และ `Version` ได้ด้วย

ตัวอย่าง SQL:

```sql
-- Main text table
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- Optional metadata table
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### คำอธิบายพระคัมภีร์ (`.commentary`)

คำอธิบายพระคัมภีร์มีสามแบบ: **รายเล่ม** **รายบท** และ **รายพระวรสาร** แบบถูกกำหนดโดย **ตัวอักษรแรกของชื่อไฟล์**

#### คำอธิบายรายเล่ม — ชื่อไฟล์ขึ้นต้นด้วย `b`

คำอธิบายรายเล่มครอบคลุมทั้งเล่มของพระคัมภีร์ในหนึ่งรายการ ตาราง `Commentary` ต้องมีคอลัมน์ `Book` และ `Scripture` (หรือ `Content`) ไม่ต้องมีคอลัมน์ `Chapter` หรือ `Verse`

- **`Commentary`** — คอลัมน์: `Book` (จำนวนเต็ม), `Scripture` (ข้อความ) หรือ `Content` (ข้อความ)

ตัวอย่าง SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

ตัวอย่างชื่อไฟล์: `bMyCommentary.commentary`

#### คำอธิบายรายบท — ชื่อไฟล์ขึ้นต้นด้วย `c`

คำอธิบายรายบทครอบคลุมแต่ละบทของเล่มหนึ่งในพระคัมภีร์

- **`Commentary`** — คอลัมน์: `Book` (จำนวนเต็ม), `Chapter` (จำนวนเต็ม), `Scripture` (ข้อความ) หรือ `Content` (ข้อความ)

ตัวอย่าง SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

ตัวอย่างชื่อไฟล์: `cMyCommentary.commentary`

#### คำอธิบายรายพระวรสาร — ชื่อไฟล์ขึ้นต้นด้วย `v`

คำอธิบายรายพระวรสารครอบคลุมพระวรสารทีละข้อ ตาราง `Commentary` ต้องมีคอลัมน์ `Book`, `Chapter`, `Verse` และ `Scripture` (หรือ `Content`)

- **`Commentary`** — คอลัมน์: `Book` (จำนวนเต็ม), `Chapter` (จำนวนเต็ม), `Verse` (จำนวนเต็ม), `Scripture` (ข้อความ) หรือ `Content` (ข้อความ)

ตัวอย่าง SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

ตัวอย่างชื่อไฟล์: `vMyCommentary.commentary`

### หนังสือ (`.book`)

ไฟล์หนังสือเป็นฐานข้อมูล SQLite ที่มีตาราง `Reference`

- **`Reference`** — คอลัมน์: `id` (จำนวนเต็ม), `Chapter` (ข้อความ), `Content` (ข้อความ)

แต่ละแถวคือหนึ่งบท คอลัมน์ `Chapter` เป็นหัวข้อบท คอลัมน์ `Content` เป็นเนื้อหาบท ซึ่งใส่ HTML ได้ (`<b>`, `<i>`, `<br>` ฯลฯ)

ตัวอย่าง SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

คุณสร้างหนังสือจากไฟล์ Markdown ได้ด้วย แอปนำเข้าไฟล์ `.md` ที่ `#` เป็นชื่อหนังสือและ `##` ทำเครื่องหมายบทได้ Markdown จะถูกเปลี่ยนเป็น HTML โดยอัตโนมัติ

### บทพระวินิจฉัยประจำวัน (`.devotional`)

ไฟล์บทพระวินิจฉัยประจำวันเป็นฐานข้อมูล SQLite ที่มีตาราง `devotional`

- **`devotional`** — คอลัมน์: `month` (จำนวนเต็ม, 1-12), `day` (จำนวนเต็ม, 1-31), `devotion` (ข้อความ)

แต่ละแถวคือการอ่านหนึ่งวัน แอปจะค้นรายการตามเดือนและวันของวันนี้

ตัวอย่าง SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### พจนานุกรมศัพท์ (`.lexicon`)

ไฟล์พจนานุกรมศัพท์เป็นฐานข้อมูล SQLite ที่มีตาราง `Lexicon`

- **`Lexicon`** — คอลัมน์: `Topic` (ข้อความ, เลข Strong's), `Definition` (ข้อความ, รายการในพจนานุกรมศัพท์)

คอลัมน์ `Topic` เก็บเลข Strong's (เช่น `G1161` หรือ `H7225`) คอลัมน์ `Definition` เก็บข้อความรายการเต็ม ซึ่งใส่ HTML ได้

ตัวอย่าง SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

พจนานุกรมศัพท์เป็นแกนหลักของเครื่องมือข้อมูลคำ เมื่อคุณแตะคำในพระคัมภีร์แบบสอดแทรก แอปจะค้นเลข Strong's ในพจนานุกรมศัพท์ที่ติดตั้งไว้

## การสร้างไฟล์บนคอมพิวเตอร์

1. ติดตั้งโปรแกรมแก้ไข SQLite (DB Browser for SQLite, SQLiteStudio หรือเครื่องมือบรรทัดคำสั่ง `sqlite3`)
2. สร้างไฟล์ฐานข้อมูลใหม่
3. สร้างตารางที่ต้องมีและใส่ข้อมูลของคุณ
4. บันทึกไฟล์ด้วยนามสกุลที่ถูกต้อง (`.bible`, `.commentary`, `.book`, `.devotional` หรือ `.lexicon`)

## การนำเข้าสู่ Theodia

1. โอนไฟล์ไปยังเครื่องของคุณ (AirDrop, อีเมล, คลาวด์ หรือ USB)
2. เปิด **Theodia**
3. ไปที่ **การตั้งค่า** → **จัดการแหล่งข้อมูล**
4. แตะ **นำเข้าจากไฟล์**
5. เลือกไฟล์ของคุณ

แอปจะตรวจสอบไฟล์ (ดูว่ามีตารางที่ต้องมีหรือไม่) คัดลอกไปยังโฟลเดอร์ข้อมูลของแอป แล้วเปิดใช้โดยอัตโนมัติ ถ้าไฟล์ไม่ถูกต้อง คุณจะเห็นข้อความแสดงข้อผิดพลาดที่อธิบายว่าอะไรผิด

## ข้อจำกัด

- คุณเขียนทับแหล่งข้อมูลในตัวไม่ได้ ถ้าพยายามนำเข้าไฟล์ที่ชื่อเหมือนพระคัมภีร์ คำอธิบายพระคัมภีร์ หรือหนังสือในตัว การนำเข้าจะล้มเหลว
- ไฟล์พระคัมภีร์ต้องมีตาราง `Verses` หรือ `Bible` ถ้าไม่มีทั้งสอง การนำเข้าจะล้มเหลว
- ไฟล์คำอธิบายพระคัมภีร์ต้องมีตาราง `Commentary`
  - คำอธิบายรายเล่มต้องมีคอลัมน์ `Book` และ `Scripture` (หรือ `Content`)
  - คำอธิบายรายบทต้องมีคอลัมน์ `Book`, `Chapter` และ `Scripture` (หรือ `Content`)
  - คำอธิบายรายพระวรสารต้องมีคอลัมน์ `Book`, `Chapter`, `Verse` และ `Scripture` (หรือ `Content`)
- ไฟล์หนังสือต้องมีตาราง `Reference`
- ไฟล์พจนานุกรมศัพท์ต้องมีตาราง `Lexicon`
- ไฟล์บทพระวินิจฉัยประจำวันต้องมีตาราง `devotional`

## เคล็ดลับ

- คุมขนาดไฟล์ให้พอเหมาะ ไฟล์ SQLite ที่ใหญ่มากอาจทำให้เกิดปัญหาหน่วยความจำบนเครื่องรุ่นเก่า
- ทดสอบไฟล์บนคอมพิวเตอร์ก่อน เปิดในโปรแกรมดู SQLite แล้วรัน `SELECT * FROM` ตารางที่ต้องมี เพื่อยืนยันว่าข้อมูลดูถูกต้อง
- สำหรับพระคัมภีร์ ตรวจว่าคอลัมน์ `Book` ใช้ตัวเลข (1 = เยเนซีเส, 66 = วิวรณ์)
- สำหรับคำอธิบายพระคัมภีร์ คุณใช้ `Scripture` หรือ `Content` เป็นคอลัมน์ข้อความคำอธิบายก็ได้
- สำหรับหนังสือ HTML ในคอลัมน์ `Content` จะถูกแสดงผลตอนอ่าน ใช้อย่างง่าย ๆ: `<b>`, `<i>`, `<br>` และ `<hr>` ปลอดภัย

## จะหาแหล่งข้อมูลที่มีอยู่แล้วที่ไหน

Theodia อ่านแหล่งข้อมูลจากโครงการ [Unique Bible App](https://github.com/eliranwong/UniqueBible) ได้ มีพระคัมภีร์ คำอธิบายพระคัมภีร์ หนังสือ และแหล่งข้อมูลอื่นจำนวนมากอยู่ที่นั่นในรูปแบบ SQLite ที่ถูกต้อง ดูคู่มือ [การหาแหล่งข้อมูลเพิ่มเติม](theodia://help/getting-core-files) สำหรับวิธีค้นหาและเพิ่ม
