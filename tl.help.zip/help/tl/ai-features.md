---
title: Mga Tampok ng AI
categories: ai
level: advanced
summary: Tuklasin ang lahat ng kayang gawin ng AI ng Theodia — mula sa pag-aaral ng bawat bersikulo hanggang sa sermon prep, orihinal na wika, at hands-free na pag-navigate.
---

# Mga Tampok ng AI

> **Mode:** Kailangan ng AI assistant ang **Scholar** mode. Maaari mong palitan ang mode sa **Settings** → **App User Mode**.

Ang AI assistant ng Theodia, si Theophilus, ay hindi lang isang chatbot. Ito ay isang study partner na maaaring magbasa ng Bibliya katabi mo, maghanap sa mga commentary, maghanap sa kasulatan, pamahalaan ang iyong mga note, at kahit i-navigate ang app — lahat gamit ang boses o teksto.

Bago unang magpadala si Theophilus ng data sa isang AI endpoint, nagpapakita ang app ng consent prompt na nagpapaliwanag kung ano ang ipinapadala at humihingi ng iyong pahintulot. Maaari mong palitan o bawiin ang pahintulot na iyon anumang oras sa **Settings → AI Assistant → Remote AI Data Sharing**.

## AI Verse Chat: Pag-aralan nang Malalim ang Isang Bersikulo

Ang **AI Verse Chat** ang puso ng karanasan sa AI ng Theodia. Habang nagbabasa ka ng anumang kabanata, i-tap ang numero ng bersikulo (o pindutin nang matagal ang teksto ng bersikulo) at piliin ang **AI Commentary**. Bubuksan ang isang chat panel na naka-load na ang bersikulong iyon. Eksaktrong alam ng AI ang binabasa mo at handa itong saliksikin ito kasama mo.

### Mga starter sa isang tap

Hindi sigurado kung ano ang itatanong? Nagpapakita ang panel ng walong instant na starter:

- **Ipaliwanag ang bersikulong ito** — Makakuha ng malinaw at maingat na paliwanag ng kahulugan at kahalagahan.
- **Orihinal na wika** — Makita ang mga salitang Griyego o Ebreo, transliterations, at mga leksikal na kahulugan sa likod ng teksto sa Ingles.
- **Pangkasaysyang konteksto** — Matutunan ang kultura, pulitika, at mga pangyayari sa paligid ng bersikulo.
- **Konteksto ng teksto** — Makita kung paano bumabagay ang bersikulo sa talata, kabanata, at aklat sa paligid nito.
- **Pangunahing mga tema** — Tuklasin ang malalaking ideya na iniambag ng bersikulong ito sa biblical theology.
- **Ilapat sa buhay ko** — Makakuha ng praktikal at personal na mga aplikasyon na magagawa mo ngayon.
- **Gumawa ng panalangin** — Gawing panalangin ang bersikulo na hinango sa wika at mga katotohanan nito.
- **Gumawa ng sermon outline** — Makakuha ng three-point outline na may introduction at conclusion, handa nang ipangaral.

I-tap ang anumang starter at magsisimula agad ang AI. Maaari kang magpatuloy sa sarili mong mga tanong, humingi ng linaw, o itulak ang pag-uusap sa bagong direksyon.

### Sumunod na tanong na parang tunay na pag-uusap

Naalala ng AI ang huling ilang mensahe sa chat, kaya maaari kang maghukay nang mas malalim nang natural:

- "Puwede mo bang gawing mas simple?"
- "Ano ang sinasabi ng orihinal na Griyego dito?"
- "Ipakita sa akin ang mga cross-reference na kaugnay nito."
- "Ihambing ang bersikulong ito sa tatlong magkakaibang pagsasalin."
- "Ano ang itsura nito sa modernong lugar ng trabaho?"
- "Bigyan mo ako ng tatlo pang aplikasyon para sa isang magulang."

Nanatiling nakakabit ang pag-uusap sa bersikulo, kaya ang bawat sagot ay nakabatay sa teksto na binabasa mo.

### I-tap ang anumang sanggunian sa Bibliya

Kapag binanggit ng AI ang ibang bersikulo — halimbawa, "Ito ay sumasalamin sa Roma 8:28" — lumalabas ang sanggunian bilang isang **tappable na link**. I-tap ito at tumatalon ang app sa talata na iyon sa Bible reader. Maaari mong saliksikin ang chain ng mga sanggunian nang hindi umaalis sa pag-uusap.

## Ano ang Kayang Gawin ng AI Bukod sa Verse Chat

May access si Theophilus sa buong nilalaman ng Theodia — mga Bibliya, commentaries, lexicons, dictionaries, mga aklat, devotionals, iyong mga note, bookmarks, at highlights. Narito ang kahulugan nito sa praktika.

### Basahin at i-navigate ang kasulatan

- **Basahin ang anumang bersikulo o kabanata** — "Basahin ang Juan 3:16 sa WEB" o "Basahin nang malakas ang Awit 23."
- **Buksan ang mga talata sa reader** — "Dalhin mo ako sa Genesis 1" o "Buksan ang Roma 8:28."
- **Ihambing ang mga bersyon** — "Ipakita sa akin ang Juan 3:16 sa lahat ng Bibliya ko."
- **Maghanap sa Bibliya** — "Hanapin ang mga bersikulo tungkol sa kapatawaran" o "Maghanap ng 'kapayapaang lumalagpas sa pag-unawa.'"
- **Makakuha ng cross-references** — "Anong ibang mga bersikulo ang may kaugnayan sa Isaias 53:5?"
- **Basahin ang mga section heading** — "Ano ang mga subheading sa Mateo 5?"

### Saliksikin ang mga orihinal na wika

- **Lexicon lookups** — "Ano ang kahulugan ng salitang Griyego na 'agape' sa Juan 3:16?" o "Hanapin ang Strong's G26."
- **Morphology** — "I-parse ang mga pandiwa sa Griyego sa Roma 8:28" o "Ano ang kahulugan ng morphology code na V-PAI-3S?"
- **Word Info** — Nakikita ng AI ang parehong word-by-word na breakdown na nakikita mo sa app — transliteration, gloss, grammar, at Strong's numbers.

### Basahin ang mga commentary at mga aklat sa pag-aaral

- **Verse commentary** — "Ano ang sinasabi ni Matthew Henry tungkol sa Efeso 2:8?"
- **Chapter commentary** — "Bigyan mo ako ng chapter overview para sa Roma 8."
- **Book commentary** — "I-buod ang book-level commentary sa Pahayag."
- **Mga aklat sa pag-aaral** — "Basahin mo sa akin ang isang kabanata mula sa Hymn Lyrics English" o "Maghanap sa mga aklat ko ng 'patience.'"
- **Mga devotional** — "Basahin ang devotional ngayong araw" o "Maghanap ng devotional tungkol sa pagkabalisa."

### Maghanap sa mga dictionary

- "Sino si Melquisedec?"
- "Ano ang sinasabi ng Bible dictionary tungkol sa Gilgal?"
- "Hanapin ang 'propitiation' sa Easton's."

### Pamahalaan ang iyong study life

Maaaring kumilos ang AI sa iyong personal na data — laging nakaimbak nang lokal sa iyong device:

- **Mga bookmark** — "I-bookmark ang bersikulong ito sa Sermon Prep folder ko" o "Ilista ang mga bookmark ko."
- **Mga highlight** — "I-highlight ang Juan 3:16 ng dilaw" o "Ipakita ang lahat ng highlights ko."
- **Mga note** — "Gumawa ng Bible note sa bersikulong ito" o "Basahin ang mga note ko para sa Genesis 1."
- **Mga study note** — "I-save ang pag-uusap na ito bilang study note" o "Gumawa ng bagong study notebook na pangalanang Roma Study."
- **Mga folder** — "Gumawa ng folder na pangalanang Morning Devotion" o "Ilipat ang bookmark ko ng Juan 3:16 sa Prayer folder."

### Palitan ang mga setting ng app

- "Lumipat sa dark mode."
- "Gawing default Bible ko ang BSB."
- "I-on ang parallel Bibles gamit ang NET."
- "Lakihan ang font size."

### Basahin nang malakas

- "Basahin nang malakas ang Awit 23" — Maaaring patakbuhin ng AI ang text-to-speech para sa anumang talata, aklat, o note.
- "Itigil ang pagbabasa" — I-pause ang TTS anumang oras.

## I-save ang Iyong mga Pag-uusap

Maaaring i-save ang bawat AI verse chat. I-tap ang menu sa chat panel at piliin ang:

- **I-save bilang Bible Note** — Idinaragdag ang buong pag-uusap sa verse note sa Bible reader.
- **I-save bilang Study Note** — Iniimbak ang pag-uusap sa Study Notes book mo para sa pagbabasa ulit.

Ginagawa nitong permanente na study material ang mabilis na pagsaliksik sa AI na maaari mong balikan, i-edit, o gawan ng sermon.

## Ang Buong AI Tab

Bukod sa verse chat panel, may nakalaang **AI** tab ang Theodia sa bottom navigation. Ito ay isang free-form chat kung saan maaari kang magtanong ng anuman — walang pre-selected na bersikulo. Gamitin ito para sa:

- Mga topical study sa buong Bibliya
- Sermon research at pag-o-outline
- Pagkukumpara ng mga theological theme sa pagitan ng mga aklat
- Mga daily devotion at prayer prompt
- Bible trivia at reading plans
- Tulong sa app — "Paano gumagana ang parallel Bibles?"

Awtomatikong nase-save ang iyong mga pag-uusap. Maaari kang bumalik sa mga nakaraang chat, magsimula ng mga bago, at burahin ang mga lumang thread.

## Mga Ideya para Magsimula Ka

Narito ang ilang kapana-panabong paraan ng paggamit ng AI. Pumili ng isa at subukan ito ngayon.

**Personal na Paglago**

- "Ipaliwanag ang Filipos 4:6–7 at bigyan mo ako ng panalangin para sa oras na nabalisa ako."
- "Ano ang sinasabi ng Bibliya tungkol sa pahinga? Maghanap ng limang bersikulo at ipaliwanag ang bawat isa."

**Pamilya at Pagpapalaki ng Anak**

- "Paano dapat gabayan ng Efeso 6:4 ang modernong pagpapalaki ng anak? Bigyan mo ako ng tatlong praktikal na tuntunin."
- "Maghanap ng mga bersikulo tungkol sa pagpapalaki ng mga bata at basahin mo ang mga ito nang malakas sa akin."

**Sermon at Pagtuturo Prep**

- "Gumawa ng outline ng 25-minutong sermon sa Roma 8:28 na may introduction, tatlong punto, at conclusion."
- "Ano ang sinasabi ng mga commentary ko tungkol sa 'armor of God' sa Efeso 6?"
- "Ihambing ang Sermon sa Bundok sa Mateo sa bersyon ni Lucas. Ano ang mga pagkakaiba?"

**Pag-aaral ng Orihinal na Wika**

- "Ipakita sa akin ang morphology ng bawat salita sa Juan 1:1."
- "Ano ang pagkakaiba ng 'agape' at 'philia' sa New Testament?"

**Lalim ng Devotional**

- "Basahin ang devotional ngayong araw at ikonekta ito sa isang bersikulo sa Mga Awit."
- "Bigyan mo ako ng seven-day devotional outline sa bunga ng Espiritu."

**Mga Cross-Reference Chain**

- "Magsimula sa Isaias 53:5 at sundan ang temang 'mga sugat' at 'paggaling' sa buong New Testament."
- "Saan lumilitaw ang konsepto ng 'tipan' mula Genesis hanggang mga Hebrew?"

**Memorya at Pagbabalik-tanaw**

- "Quiz-an mo ako sa mga aklat ng Bibliya ayon sa sunod-sunod na order."
- "Gumawa ng study note na nagbubuod sa pangunahing punto ng bawat kabanata sa Roma."

## Ilang Mahalagang Paalala

- Ang AI ay isang **tool**, hindi kapalit ng Bibliya o ng pastoral na gabay. Laging ihambing ang mga sagot nito sa mismong Kasulatan.
- Kapag ginamit mo ang AI, naglalakbay ang iyong mga tanong sa internet papunta sa mga server ng provider. Karamihan sa mga provider ay hindi nagsasanay sa iyong data, ngunit umaalis ang teksto sa iyong device.
- Maaaring magkamali ang AI. Gamitin ang mga commentary, lexicon, at ang mismong teksto ng Bibliya bilang iyong huling autoridad.

## Buod

Dinisenyo ang AI ng Theodia para gawing mas mabilis, mas malalim, at mas personal ang Bible study. Nais mo man ang isang-pangungusap na paliwanag ng isang malabo na bersikulo, isang buong sermon outline, isang Greek word study, o isang cross-reference chain na tumatawid sa buong Bibliya, handa siyang tumulong. I-tap ang isang bersikulo, magtanong, at makita kung saan dala ang pag-uusap.
