---
title: Mga API Key at Gastos
level: advanced
categories: ai
summary: Bakit kailangan mo ng API key, kung paano makakuha nito, at karaniwang gastos ng paggamit ng remote AI model.
---

# Mga API Key at Gastos

> **Mode:** Kailangan ng AI assistant ang **Scholar** mode. Maaari mong palitan ang mode sa **Settings** → **App User Mode**.

Kumokonekta ang AI assistant sa mga remote AI model. Kung gusto mong gumamit ng isa, kailangan mo ng API key. Ipapaliwanag ng pahinang ito kung bakit, kung paano makakuha nito, at ang karaniwang gastos nito.

## Bakit kailangan mo ng API key

Ang isang remote AI model ay nakatira sa isang server sa internet. Ang API key ay parang password na nagsasabi sa server, "Pinapayagang magtanong ang taong ito." Nang wala ito, hindi sasagot ang server.

Hindi nagbibigay ang app ng built-in na key. Kailangan kang gumawa ng sarili mong account sa isang provider at i-paste ang key mo sa app.

## Paano makakuha ng API key

1. Buksan ang **Settings** sa Theodia.
2. I-tap ang **AI Assistant**.
3. Piliin ang **Remote model**.
4. Pumili ng provider mula sa listahan, o piliin ang **Custom** at maglagay ng base URL.
5. I-tap ang link papunta sa key page ng provider. Gumawa ng account kung wala ka pa.
6. Gumawa ng bagong API key sa site ng provider.
7. Kopyahin ang key at i-paste ito sa Theodia.
8. I-tap ang **Test connection** para siguraduhing gumagana ito.

## Mga suportadong provider

Maaaring kumonekta ang Theodia sa anumang provider na gumagamit ng OpenAI-compatible na API. Narito ang mga may preset na link sa app:

- **GitHub Models** — github.com/marketplace/models (libreng daily tier, inirerekomenda)
- **OpenAI** — platform.openai.com
- **OpenRouter** — openrouter.ai
- **Anthropic** — console.anthropic.com
- **Groq** — console.groq.com
- **Mistral** — console.mistral.ai
- **Together AI** — api.together.xyz

Maaari mo ring gamitin ang **Custom** base URL kung may sarili kang server o gumagamit ng ibang serbisyo.

## Magkano ang gastos?

Karamihan sa mga provider ay naniningil sa **token**. Ang isang token ay humigit-kumulang isang salita o bahagi ng salita. Nagbabayad ka sa mga token na ipinapadala mo (ang tanong mo) pati na rin ang mga token na ipinapadala pabalik ng AI (ang sagot).

### Karaniwang presyo

Nagbabago ang mga presyo, ngunit narito ang magaspang na ideya sa gitna ng 2026:

- **Maliliit at mabilis na model** (tulad ng mas murang GPT-3.5-class na endpoints) ay nagkakahalaga ng pira-pirasong sentimo bawat libong token.
- **Mid-range na model** (tulad ng GPT-4o o Claude Sonnet) ay karaniwang nagkakahalaga ng ilang sentimo bawat libong token.
- **Malalaking reasoning model** (tulad ng GPT-4.5 o Claude Opus) ay maaaring magkahalaga ng sampu hanggang dalawampung sentimo bawat libong token.

Ang isang karaniwang tanong sa Bibliya sa Theodia ay maaaring gumamit ng ilang daan hanggang ilang libong token sa kabuuan. Nangangahulugan ito na karamihan sa mga tanong ay nagkakahalaga mula **mas mababa sa isang sentimo hanggang ilang sentimo**.

### Mga tip para panatilihing mababa ang gastos

- Magsimula sa mas murang model. Karamihan sa mga tanong sa Bibliya ay hindi nangangailangan ng pinakamahal na model.
- Gamitin ang Groq o OpenRouter kung gusto mong subukan ang iba't ibang model at ikumpara ang mga presyo.
- Bantayan ang usage dashboard mo sa site ng provider.

## GitHub Models

Nag-aalok ang [GitHub Models](https://github.com/marketplace/models) ng libreng tier na walang kinakailangang subscription. Ang kailangan mo lang ay isang libreng GitHub account at isang personal access token na may pahintulot na magbasa ng models.

**Paano i-set up:**

1. Pumunta sa [github.com/settings/tokens](https://github.com/settings/tokens) at gumawa ng **Personal access token (classic)**.
2. Bigyan ito ng `models:read` scope (o piliin lang ang models permission).
3. Sa Theodia, piliin ang **GitHub Models** bilang provider at i-paste ang token mo.

**Mga model sa free tier:**

- `openai/gpt-4.1-nano` — **15 request kada minuto, 150 request kada araw**
- `openai/gpt-4.1-mini` — **15 request kada minuto, 150 request kada araw**
- `openai/gpt-4.1` — **10 request kada minuto, 50 request kada araw**
- `openai/gpt-4o` — **10 request kada minuto, 50 request kada araw**

Na-reset ang mga limitasyong ito araw-araw at sapat na ito para sa regular na Bible study.

Para sa buong step-by-step na walkthrough na may mga screenshot, tingnan ang dedikadong gabay sa [GitHub Models](theodia://help/github-models).

## Paalala tungkol sa privacy

Kapag gumamit ka ng remote AI model, nagpapakita muna ang app ng consent prompt na nagpapaliwanag kung ano ang ipinapadala: ang iyong mga mensahe, konteksto ng bersikulo o kabanata, tool calls at mga resulta, ang naka-configure na model name, at ang API key mo sa request header. Direktang pupunta ang request sa endpoint na na-configure mo, hindi sa pamamagitan ng Theodia. Karamihan sa mga provider ay hindi ginagamit ang iyong data para i-train ang mga model nila, ngunit umaalis ang teksto sa iyong device. Maaari mong palitan o bawiin ang pahintulot anumang oras sa **Settings → AI Assistant → Remote AI Data Sharing**.

## Buod

- Kailangan mo ng API key para gamitin ang AI assistant.
- Gumawa ng account sa isang provider, gumawa ng key, at i-paste ito sa Theodia.
- Karamihan sa mga tanong ay nagkakahalaga ng ilang sentimo o mas mababa.
