---
title: Ang AI Assistant
level: advanced
category: ai
summary: Kung paano gamitin ang AI helper para maunawaan ang mga bersikulo.
---

# Ang AI Assistant

May AI assistant ang Theodia. Makakatulong ito sa iyo na maunawaan ang isang bersikulo, sagutin ang isang tanong, o pag-usapan ang isang paksa sa Bibliya.

## Paano i-on ang AI

Naka-off ang AI bilang default. Para i-on ito:

1. Buksan ang **Settings**.
2. I-tap ang **AI Assistant**.
3. I-tap ang switch para i-on ito.

Maaaring kailanganin mong mag-set up ng account o ng key. Gagabayan ka ng app.

## Paano buksan ang AI

I-tap ang **AI** tab sa ibaba ng screen. Magbubukas ang isang chat window.

## Paano magtanong

I-tap ang box sa ibaba. I-type ang tanong mo. I-tap ang **Send**.

Ilan sa mga puwede mong itanong:

- "Ano ang kahulugan ng Juan 3:16?"
- "Sabihin mo sa akin ang tungkol sa aklat ng mga Taga-Roma."
- "Ano ang bunga ng Espiritu?"
- "Ihambing ang Sermon sa Bundok sa Mateo at Lucas."

## Paano magtanong tungkol sa isang partikular na bersikulo

1. Buksan ang isang kabanata.
2. I-tap ang isang bersikulo para lumabas ang verse menu.
3. I-tap ang **AI Commentary**.

Ipinapadala ang bersikulo sa AI. Bubuksan ang AI panel na naka-pre-fill ang bersikulo. Maaari kang magdagdag ng tanong, tulad ng "Ano ang ibig sabihin nito?" o "Paano ko ito ilalapat sa buhay ko?"

## Mahahalagang dapat malaman

- Ang AI ay isang tool, hindi isang tao. Maaari itong magkamali.
- Laging i-check ang mga sagot ng AI laban sa mismong Bibliya.
- Maaaring kailanganin ng AI ang internet. Hindi ito gumagana nang offline.
- Kapag ginamit mo ang AI, ipinapadala ang iyong mga tanong, konteksto ng bersikulo, at API key sa endpoint na pinili mo. Sa unang beses na gawin mo ito, hihingi ng pahintulot ang app at ipapakita nang eksakto kung ano ang ipinapadala. Maaari mong palitan o bawiin ang pahintulot na iyon sa **Settings → AI Assistant → Remote AI Data Sharing**.
- Ang ilang rehiyon, tulad ng China mainland App Store build, ay hindi nag-aalok ng AI assistant. Sa build na iyon, mga offline na feature lamang ng Bibliya ang makukuha.

## Paano pamahalaan ang mga pag-uusap

Nagtatabi ang AI screen ng listahan ng mga nakaraang pag-uusap. Mula sa listahan, maaari mong buksan ang isang lumang pag-uusap, magsimula ng bago, o burahin ang isa na hindi mo na kailangan.

Para sa mga mas advanced na tip, tingnan ang gabay na [Pagsusulat ng Mas Magandang AI Prompts](theodia://help/ai-prompts).
