---
title: Pagsusulat ng Mas Magandang AI Prompts
level: advanced
categories: ai
summary: Kung paano magtanong sa AI assistant sa paraang makakakuha ng magagandang sagot.
---

# Pagsusulat ng Mas Magandang AI Prompts

> **Mode:** Kailangan ng AI assistant ang **Scholar** mode. Maaari mong palitan ang mode sa **Settings** → **App User Mode**.

Ang "prompt" ay ang tanong o instruksyon na ibinibigay mo sa AI. Mas magagandang prompts ay nagreresulta sa mas magagandang sagot. Ipapakita ng gabay na ito kung paano.

## Maging tiyak

Masama: "Sabihin mo sa akin ang tungkol sa pag-ibig."
Mas maganda: "Sa 1 Corinto 13, anong uri ng pag-ibig ang inilarawan ni Pablo, at paano ito naiiba sa romantic na pag-ibig?"

Ang mas maraming detalye na ibibigay mo, mas kapaki-pakinabang ang sagot.

## Magbigay ng konteksto

Masama: "Ano ang kahulugan ng bersikulong ito?"
Mas maganda: "Binabasa ko ang Roma 8 kasama ang isang maliit na grupo. Ano ang kahulugan ng 'walang pagkahatol' sa kabanatang ito, at paano ito konektado sa natitira ng kabanata?"

Tumutulong ang konteksto para iakma ng AI ang sagot nito sa iyong sitwasyon.

## Humingi ng isa nang sabay-sabay

Masama: "Sabihin mo sa akin ang tungkol sa panalangin, pananampalataya, at paggaling."
Mas maganda: "Sabihin mo muna sa akin ang tungkol sa panalangin. Pagkatapos noon, itatanong ko ang tungkol sa pananampalataya."

Ang paghingi ng isa nang sabay-sabay ay pinapanatiling nakatuon ang mga sagot.

## Hilingin sa AI na gumampan ng isang papel

Maaari mong hilingin sa AI na sumagot sa isang tiyak na boses. Halimbawa:

- "Sumagot na para bang nagtuturo ka sa isang bagong Kristiyano."
- "Sumagot bilang isang Bible scholar."
- "Sumagot para sa isang 10-taong-gulang na bata."

Iniaakma ng AI ang sagot nito sa papel.

## Gumamit ng mga follow-up na tanong

Kung hindi masyadong tama ang unang sagot, magtanong ng follow-up:

- "Puwede mo bang gawing mas simple?"
- "Puwede mo ba akong bigyan ng halimbawa?"
- "Ano ang sinasabi ng orihinal na Griyego?"
- "Saan pa sa Bibliya lumilitaw ito?"

Ang isang magandang pag-uusap ay pabalik-balik. Naalala ng AI ang huling ilang mensahe.

## I-check ang mga sagot ng AI

Maaaring magkamali ang AI. Ito ay isang tool, hindi isang guro.

- Ihambing ang sagot ng AI sa mga bersikulo na itinuturo nito sa iyo.
- Gamitin ang mga commentary at lexicon sa app para sa pangalawang opinyon.
- Kung ang sagot ay tungkol sa doktrina, magtanong sa isang pastor o sa isang pinagkakatiwalaang kaibigan.

## Mga karaniwang pattern ng prompt

Narito ang ilang gumagana nang maayos:

- "Ipaliwanag mo sa akin ang bersikulong ito na para bagang bagong Kristiyano ako."
- "Ano ang pangunahing punto ng kabanatang ito sa isang pangungusap?"
- "Ilista ang tatlong aplikasyon sa aking pang-araw-araw na buhay mula sa talatang ito."
- "Anong mga tanong ang dapat itanong ko tungkol sa bersikulong ito bago ko ito ipangaral?"
