---
title: App User Mode
level: beginner
categories: [user-mode]
summary: Pumili sa Reader, Standard, at Scholar mode para kontrolin kung aling mga feature ang makikita sa app.
---

# App User Mode

Nag-aalok ang Theodia ng tatlong user mode na kumokontrol kung aling mga feature ang nakikita mo. Piliin ang angkop sa paraan na gusto mong gamitin ang app.

## Reader

Ang pinakasimpleng mode. Ang Reader mode ay para sa malinis at walang distraksyon na pagbabasa ng Bibliya.

- Basahin ang anumang pagsasalin ng Bibliya
- Gamitin ang Focus Mode para sa malinis, full-screen na pagbabasa
- Mag-navigate sa mga aklat at kabanata
- Walang study tools, walang AI, walang bookmarks, walang highlights

Ang Reader mode ay perpekto kung gusto mong maging parang malinis na digital na Bibliya ang Theodia na walang karagdagang ano pa man.

## Standard

Nagdaragdag ang Standard mode ng mga pang-araw-araw na feature para sa personal na Bible study.

Lahat sa Reader, dagdag pa ang:

- Bookmarks, highlights, at notes
- Text-to-speech
- Study Mode reader na may verse menu
- Parallel Bibles
- Command input
- Paghahanap sa Bibliya
- Daily devotionals at mga built-in na aklat

Ang Standard mode ang tamang pinili para sa karamihan ng mga gumagamit na gusto pang magbasa, magmarka, at maghanap sa Bibliya nang walang advanced na study tools.

## Scholar

Ang full-featured na mode. Binubuksan ng Scholar mode ang bawat tool sa Theodia para sa malalim na Bible study.

Lahat sa Standard, dagdag pa ang:

- Commentaries at lexicons
- Cross-references
- Bible Dictionary
- Word Info (Strong's lookups)
- AI assistant at AI Commentary
- Launcher Menu

Dinisenyo ang Scholar mode para sa mga pastor, seminary student, at sinumang nais ng mga orihinal-na-wikang tool at mga study aid na pinapagana ng AI.

## Paano magpalit ng mode

1. Buksan ang **Settings**.
2. I-tap ang **App User Mode**.
3. Piliin ang **Reader**, **Standard**, o **Scholar**.

Agad nagkakabisa ang pagbabago. Nakatago ang mga menu at button na hindi mo maa-access sa kasalukuyan mong mode.

## Pagpili ng mode

- **Reader** — Gusto mo lang basahin ang Bibliya, wala nang iba pa.
- **Standard** — Gusto mo ng bookmarks, highlights, notes, search, at devotionals.
- **Scholar** — Gusto mo ng lahat ng study tool, kabilang ang AI, commentaries, at lexicons.

Maaari kang magpalit ng mode anumang oras. Hindi kailanman binubura ang iyong mga bookmark, highlight, at note kapag nagpalit ka ng mode; itinatago lang ang mga ito hanggang sa bumalik ka sa mode na sumusuporta sa kanila.
