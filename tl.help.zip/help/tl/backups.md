---
title: Pag-back Up ng Iyong Data
level: everyday
categories: settings
summary: Kung paano i-save at i-restore ang iyong mga note, highlight, bookmark, at mga lihim na impormasyon.
---

# Pag-back Up ng Iyong Data

Naka-save sa iyong device ang iyong mga note, highlight, bookmark, at setting. Kapag nawala mo ang iyong telepono, nakakuha ka ng bago, o na-uninstall mo ang app, maaaring mawala ang data na iyon. Ipapakita ng gabay na ito kung paano i-back up ang mga ito.

## Paano buksan ang backup settings

1. Buksan ang **Settings**.
2. I-tap ang **App Backup**.

## Paano gumawa ng app backup

1. Buksan ang **Settings**.
2. I-tap ang **App Backup**.
3. I-tap ang **Create App Backup**.
4. Pumili ng folder sa iyong device para i-save ang file. Maaari ka ring pumili ng cloud drive.
5. Gumagawa ang app ng isang file na naglalaman ng lahat ng iyong data. Nagtatapos ang file sa `.zip`.

## Gaano kadalas gumawa ng backup

Gumawa ng backup:

- Pagkatapos mong magsulat ng maraming note.
- Bago mong i-update ang operating system ng iyong device.
- Bago mong i-uninstall ang app o magpalit ng telepono.

Magandang gawi ang isang backup kada buwan. May ilang taong nagba-back up kada linggo.

## Paano mag-restore mula sa isang app backup

1. Buksan ang **Settings**.
2. I-tap ang **App Backup**.
3. I-tap ang **Restore from App Backup**.
4. Piliin ang `.zip` backup file.
5. Para sa bawat uri ng data (notes, highlights, bookmarks, at iba pa), piliin kung pananatilihin ang nasa device, papalitan ito ng backup, o lalampasan ito.
6. I-tap ang **Restore**.

Pinapalitan ng app ang iyong data ng data sa backup. Kabilang dito ang:

- Mga note
- Mga highlight
- Mga bookmark
- Mga bookmark folder
- Mga setting (theme, font size, wika)

## Secrets Backup

Ang **App Backup** mo ay **hindi** kasama ang mga sensitibong lihim na impormasyon tulad ng AI API key mo o GitHub token. Para mai-back up ang mga ito nang hiwalay, gamitin ang **Secrets Backup**.

### Mag-save ng secrets backup

1. Buksan ang **Settings**.
2. I-tap ang **App Backup**.
3. Sa ilalim ng **Secrets Backup**, i-tap ang **Save Secrets Backup**.
4. Maglagay ng malakas na password at kumpirmahin ito.
5. Ine-encrypt ng app ang iyong mga lihim na impormasyon at ibinabagi ang naka-encrypt na file. I-save ito sa isang ligtas na lugar.

### Mag-restore ng secrets backup

1. Buksan ang **Settings**.
2. I-tap ang **App Backup**.
3. Sa ilalim ng **Secrets Backup**, i-tap ang **Restore Secrets Backup**.
4. Piliin ang naka-encrypt na secrets backup file.
5. Ilagay ang parehong password na ginamit mo nang i-save ito.
6. Nare-restore ang iyong mga lihim na impormasyon.

> **Mahalaga:** Kapag nakalimutan mo ang password, hindi na maibabalik ang mga lihim na impormasyon. Walang pag-reset.

## Mga dapat malaman

- **Pinapalitan** ng restore ang mga kategorya na pinili mo. Anumang idinagdag mo pagkatapos ng backup ay mawawala para sa mga kategoryang iyon.
- Ang isang app backup ay isang `.zip` file. Itago ito sa isang ligtas na lugar.
- Maaari mong kopyahin, ilipat, o iimbak ang file sa anumang cloud service.
- Hindi kasama ng app backups ang mismong mga pagsasalin ng Bibliya. Maaaring i-download muli ang mga ito mula sa **Settings** → **Manage Resources**.
- Naka-encrypt ang secrets backups gamit ang iyong password. Pumili ng password na matatandaan mo.

## Tip

Kung may higit sa isang device ka, maaari mong kopyahin ang backup file sa bawat device at i-restore ito. Magiging pareho ang iyong data sa dalawa.
