---
title: Pag-bookmark ng mga Bersikulo
level: everyday
categories: [annotate, read]
summary: Kung paano i-save ang mga bersikulo para mahanap mo ulit ang mga ito.
---

# Pag-bookmark ng mga Bersikulo

> **Mode:** Makukuha ang bookmarks sa **Standard** at **Scholar** mode. Ang Focus Mode ay para lang sa malinis at walang distraksyon na pagbabasa. Maaari mong palitan ang mode sa **Settings** → **App User Mode**.

Nagse-save ang bookmark ng isang bersikulo o kabanata ng aklat para mahanap mo ulit ito. Ang mga bookmark ay parang mga tab sa isang libro.

## Paano i-bookmark ang isang bersikulo

1. Buksan ang bersikulo.
2. I-tap ang bersikulo para lumabas ang menu.
3. I-tap ang **Bookmark** sa menu. Tinitikman ng star icon ang bersikulo bilang naka-save.

Ang check mark sa icon ay nangangahulugang naka-bookmark na ang bersikulo.

## Paano i-bookmark ang kabanata ng isang aklat

Kapag nagbabasa ng isang aklat (hindi Bibliya), maaari mong i-bookmark ang buong kabanata:

1. Buksan ang kabanata.
2. I-tap ang **Bookmark** icon sa itaas ng screen.

## Paano makita ang mga bookmark mo

I-tap ang **Bookmarks** tab sa ibaba. Makikita mo ang listahan ng bawat bersikulo at kabanata ng aklat na nai-save mo.

## Paano mag-alis ng bookmark

- **Isang bersikulo:** Buksan ang bersikulo. I-tap ang bersikulo, tapos i-tap ulit ang **Bookmark** icon. Mawawala ang check mark.
- **Mula sa listahan:** Sa **Bookmarks** tab, pindutin nang matagal ang isang bookmark. Lalabas ang isang maliit na menu. I-tap ang **Delete**. (Maaari mo ring i-tap ang maliit na × button sa row.)

## Ayusin gamit ang mga folder

Maaari mong ilagay ang mga bookmark sa mga folder. Halimbawa, maaaring mayroon kang folder na "Sermon Prep" at isa pang "Encouragement."

Para gumawa ng folder:

1. Buksan ang **Bookmarks** tab.
2. I-tap ang **Manage Folders** sa itaas.
3. I-tap ang **+ Create Folder** sa itaas ng folder list.
4. Mag-type ng pangalan at i-tap ang **Save**.

Hindi ka maaaring gumawa ng dalawang folder na may parehong pangalan. Kung mayroon nang pangalan, lalabas ang isang error sa loob ng create-folder box para mabago mo ito at subukan muli.

Para ilagay ang bookmark sa isang folder:

1. Sa **Bookmarks** tab, pindutin nang matagal ang isang bookmark.
2. I-tap ang **Save to Folder**.
3. Piliin ang folder, tapos i-tap ang **Done**.

## Pag-import ng mga bookmark

Maaari mong dalhin sa Theodia ang mga bookmark mula sa ibang app at file.

Pumunta sa **Settings** → **Bookmarks** → **Import Bookmarks**. Piliin ang **Import from File** o mag-paste mula sa clipboard. Awtomatikong nakikilala ng app ang format.

### Mga suportadong format

**Native JSON export** — Ang format na ginagamit ng sariling export feature ng Theodia. Pinapanatili nito ang mga folder at petsa ng paggawa.

**Netscape Bookmark HTML** — Ang format na ginagamit ng Chrome, Firefox, at Safari kapag nag-export ka ng mga bookmark. Pinapanatili ang mga folder.

**CSV** — Isang spreadsheet na may mga column. Naghahanap ang app ng mga `url` at `folder` column (o `href` / `category`). Halimbawa:

```csv
url,folder
/bible/KJV/John/3,Favorites
/bible/KJV/Genesis/1,Sermon Prep
```

**Plain text** — Ang bawat linya ay isang sanggunian sa Bibliya, isang app URL, o isang folder directive. Halimbawa:

```
folder: Favorites
John 3:16
Genesis 1:1
folder: Sermon Prep
Matthew 5:1
```

- Ang mga linyang nagsisimula sa `folder: <name>` ay nagtatakda ng aktibong folder para sa lahat ng susunod na bookmark.
- Ang mga sanggunian sa Bibliya tulad ng `John 3:16` ay ginagawang bookmark sa iyong default Bible.
- Ang mga app URL tulad ng `/bible/KJV/John/3#v3_16` o `/book/MyBook/1` ay ini-import nang diretso.
- Ang mga linyang nagsisimula sa `#` o `//` ay itinuturing na mga komento at linalaktawan.

### Mga tip sa pag-import

- Awtomatikong linalaktawan ang mga dobleng bookmark.
- Ang mga external URL (tulad ng mga link sa BibleGateway) ay ginagawang app bookmark hangga't maaari.
- Kung mayroon na ang isang folder mula sa import file, inilalagay ang mga bookmark sa umiiral na folder.

## Mga tip

- Maaari mong i-bookmark ang parehong bersikulo sa maraming pagsasalin. Lahat ng mga ito ay lalabas sa listahan.
- Nanatili sa iyong device ang mga bookmark. Hindi sila nag-se-sync sa cloud.
- Tingnan ang gabay na [Pag-back Up ng Iyong Data](theodia://help/backups) para panatilihing ligtas ang mga ito.

## Mga bookmark sa PDF

May sariling bookmarks ang mga PDF, na pinapanatili nang hiwalay sa iyong mga Bible bookmark. Habang nagbabasa ng isang PDF, i-tap ang **Bookmark** button sa toolbar ng reader para i-save ang kasalukuyang pahina, bigyan ito ng pangalan, at tumalon pabalik dito mamaya. May sariling listahan ang bawat PDF — tingnan ang [Mga PDF](theodia://help/pdfs).
