---
title: Pagpili ng AI Model
level: advanced
categories: ai
summary: Kung paano pumili ng model na maayos na gumagana sa mga built-in na tool at kakayahan ng Theodia.
---

# Pagpili ng AI Model

> **Mode:** Kailangan ng AI assistant ang **Scholar** mode. Maaari mong palitan ang mode sa **Settings** → **App User Mode**.

Hindi lahat ng AI model ay gumagana nang pareho sa Theodia. Ang pinakamagandang karanasan ay nanggagaling sa model na sumusuporta sa **tool calling** — ang kakayahan ng AI na gamitin ang mga built-in na feature ng Theodia tulad ng paghanap ng mga bersikulo sa Bibliya, paghahanap, pagbasa ng mga commentary, at pag-navigate sa app.

## Ano ang tool calling?

Kapag nagtanong ka sa AI ng Theodia, maaari itong gumawa ng higit pa sa pag-usap lang. Maaari rin itong **kumilos**. Halimbawa:

- Sinabi mo, "Ipakita mo sa akin ang Juan 3:16 sa ESV." Nagtawag ang AI ng tool para buksan ang bersikulong iyon sa reader.
- Sinabi mo, "Ano ang sinasabi ng mga commentary ko tungkol sa Roma 8:28?" Nagtawag ang AI ng tool para kunin ang nilalaman ng commentary.
- Sinabi mo, "I-save ang bersikulong ito bilang bookmark." Nagtawag ang AI ng tool para gumawa ng bookmark.

Ang mga model na hindi sumusuporta sa tool calling ay makakabigay lang sa iyo ng mga sagot na teksto. Hindi sila maaaring maghanap ng mga bagay, mag-navigate, o magbago ng ano pa man sa app.

## Aling mga model ang sumusuporta sa mga tool?

### Mga remote model

Karamihan sa mga modernong remote model mula sa mga malalaking provider ay sumusuporta sa OpenAI-compatible na tool calling. Sa pangkalahatan:

- Ang **malalaking model** (tulad ng GPT-4o, Claude Sonnet/Opus, Gemini Pro) ay maaasahan sa mga tool at kayang mag-chain ng maraming tool call sa isang pag-uusap. Ipinapakita ang mga pangalan ng provider at model ID sa app para sa kaginhawaan; ang aktwal na serbisyong kinokonekta mo ay ang nakonfigura mo sa endpoint at key.
- Ang **mas maliliit o mas murang model** ay maaaring sumuporta sa mga tool ngunit maaaring hindi masyadong maaasahan. Maaari nilang balewalain ang isang tool call o maling i-format ito.
- Ang **napakaluma o espesyalisadong model** ay kadalasang hindi sumusuporta sa mga tool.

Kung hindi ka sigurado, i-test ang model sa Theodia. Sabihin mo itong "Ipakita mo sa akin ang Genesis 1:1" o "Maghanap sa Bibliya ng mga bersikulo tungkol sa pag-ibig." Kapag bumukas ang bersikulo o lumabas ang mga resulta ng search, gumagana ang tool calling.

## Mga inirerekomendang model para sa Theodia

Ito ang mga magandang pinili na naghahatid-sayaw sa gastos, kalidad, at suporta sa tool:

- **OpenAI GPT-4o** — napakahusay na suporta sa tool, mabilis, magaling sa mga kumplikadong multi-step na tanong.
- **Anthropic Claude Sonnet / Opus** — napakaasahan sa paggamit ng tool, magaling sa mahahabang talata at detalyadong pag-aaral.
- **Groq** (iba't ibang model) — mabilis na inference, kadalasang libre o napakamura, iba-iba ang suporta sa tool ayon sa model.
- **OpenRouter** — pinapayagan kang sumubok ng maraming model mula sa isang account. Maghanap ng mga model na naglilista ng "function calling" o "tools" sa mga capability nila.
- **[GitHub Models](theodia://help/github-models)** — ang inirerekomendang libreng provider. Access sa OpenAI, Anthropic, at iba pang model sa pamamagitan ng iyong GitHub account na may malaking daily free tier. Gumagamit ng parehong `openai/gpt-4o` style na model ID.

## Mga model na iwasan

- Ang **mga pure text-completion model** (tulad ng GPT-3 base o raw LLaMA na walang instruction tuning) ay karaniwang hindi sumusuporta sa mga tool.
- Ang **mga image-only o vision model** na nakatuon sa mga larawan sa halip na teksto ay maaaring kulang sa suporta sa tool.
- Ang **napakaliit na model** na wala sa 1 bilyong parameter ay malamang hindi tama ang paggamit ng mga tool, kahit sinasabi ng API na sinusuporta nila ang mga ito.

## Paano i-test ang suporta sa tool

Awtomatikong sinusuri ng Theodia ang suporta sa tool. Pagkatapos mong i-set up ang isang model sa **Settings → AI Assistant**, i-tap ang **Test connection**. Kapag naging matagumpay ang koneksyon, nagpapadala ang app ng pangalawang request na may sample na tool definition. Makikita mo ang isa sa dalawang resulta:

- **✓ Tools supported** — Tinatanggap ng model ang mga tool call at kayang gamitin ang mga built-in na feature ng Theodia.
- **✗ Tools not supported** — Tinatanggihan ng model ang tool request. Sasagot ito sa teksto lang at hindi makabubukas ng mga bersikulo, maghahanap, o mamamahala ng mga bookmark para sa iyo.

Kung makikita mo ang "Tools not supported," maaari pa rin gumana ang model bilang isang plain text chat assistant, ngunit hindi mo makukuha ang pinagsama-sama at hands-free na karanasan.

Maaari mo ring i-verify nang mano-mano sa pamamagitan ng paghiling sa AI na gumawa ng isang bagay:

- "Ipakita mo sa akin ang Mateo 5:3 sa KJV." — Dapat bubuksan ang bersikulo sa reader.
- "Ano ang sinasabi ng lexicon tungkol sa salitang 'agape' sa Juan 3:16?" — Dapat magbabalik ng lexicon data.
- "Maghanap sa Bibliya ng mga bersikulo tungkol sa kapatawaran." — Dapat magbabalik ng mga resulta ng search.
- "I-bookmark ang Marcos 12:30." — Dapat gagawa ng bookmark.

Kung nagbibigay sa iyo ang AI ng deskripsyon sa teksto sa halip na aktwal na gawin ang bagay, nahihirapan ang model gamitin ang mga tool nito kahit na nagsabi ang app ng suporta.

## Paano kung hindi sumusuporta ang model ko sa mga tool?

Maaari mo pa rin itong gamitin. Sasagot ang AI sa teksto, at maaari mong mano-manong hanapin ang mga bersikulo, maghanap, at mag-navigate sa app. Ngunit mapapalampas mo ang hands-free at pinagsama-samang karanasan na nagpapalakas sa Theodia.

## Buod

- Pumili ng model na may suporta sa **tool calling / function calling** para sa pinakamagandang karanasan sa Theodia.
- Ang **malalaking remote model** ang pinakamaasahan sa mga tool.
- I-test ang anumang model gamit ang mga simpleng utos tulad ng "Ipakita mo sa akin ang Genesis 1:1" para i-verify ang suporta sa tool.
