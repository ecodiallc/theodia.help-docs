---
title: Mga Command
level: everyday
categories: [layout, study]
summary: Papayagan ka ng Command input na tumalon sa anumang feature sa pamamagitan ng pag-type ng maikling command. Alamin ang mga suportadong format at mga halimbawa.
---

# Mga Command

Papayagan ka ng **Command** input na tumalon sa halos anumang bahagi ng Theodia sa pamamagitan ng pag-type ng maikling instruksyon. Maaari mo itong gamitin mula sa Home tab o mula sa **Launcher Menu** (ang **▼** icon sa header).

## Paano ito gumagana

1. I-tap ang Command box.
2. Mag-type ng command.
3. I-tap ang go key sa iyong keyboard.

Babasahin ng app ang command at dadalhin ka nang diretso sa tamang screen.

## Walang slash prefix

Ang mga command ay **hindi** gumagamit ng `/` prefix. Inilalagay ang mga ito bilang plain text:

```
john 3:16
search love
backup
```

Kapag nag-type ka ng `/settings`, ginagawang hindi nakikilala ng nangungunang `/` ang command.

## Mga sanggunian sa Bibliya

Mag-type ng anumang sanggunian sa Bibliya para buksan ito sa reader.

```
psalms 23
john 3:16
matthew 5:1
1 cor 15:10
```

Maaaring itugma ang mga pangalan ng aklat sa pamamagitan ng buong pangalan o abbreviation. Sa mga non-English na wika ng UI, maaari ka ring mag-type ng mga pangalan ng aklat sa aktibong wika.

## Paghahanap

```
search abraham
search love
search faith not works
```

## Bookmarks, compare, commentary, cross-references, at word info

```
bookmark john 3:16
compare genesis 1:1
commentary john 1
aicommentary eph 2:8
xref 1 cor 15:10
word info john 1:1
```

Binubuksan ng mga command na ito ang pinangalanang tool para sa talatang ibinigay.

## Lexicon

Mag-type ng isang Strong's number para buksan ang lexicon entry.

```
g1161
h7225
```

## Mga devotional

```
devotional
devotional smith
devotional daily
```

Kung walang pangalan, binubuksan nito ang devotional list.

## Mga navigation shortcut

```
notes
highlights
bookmarks
flashcards
playlist
theoscript
resources
read john 3:16
```

Tumatalon nang diretso ang mga ito sa pinangalanang screen o binubuksan ang isang talata sa reader.

## Pagpalit ng pagsasalin

Mag-type ng isang abbreviation ng pagsasalin para lumipat dito.

```
kjv
web
trlit
ohgb
```

Sa isang reader screen, pumapalit nang doon mismo ang pagsasalin. Sa ibang lugar, binubuksan nito ang pagsasalin sa iyong pinakabagong talata.

## Mga localized na command verb

Ang mga pampublikong command verb ay maaaring i-type sa aktibong wika ng UI **o** sa Ingles. Laging gumagana ang Ingles bilang fallback. Ang mga nakatagong command (mga settings shortcut, install commands, Easter eggs) ay nananatiling Ingles lang ang syntax.

## Tulong

Mag-type ng `help` o `commands` sa Command box para buksan ang in-app command reference anumang oras.
