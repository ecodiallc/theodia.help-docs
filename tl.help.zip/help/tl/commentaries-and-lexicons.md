---
title: Mga Commentary at Lexicon
level: everyday
categories: study
summary: Kung paano hanapin ang mga kahulugan ng mga salita at magbasa ng mga study note.
---

# Mga Commentary at Lexicon

> **Mode:** Kailangan ng mga commentary at lexicon ang **Scholar** mode. Maaari mong palitan ang mode sa **Settings** → **App User Mode**.

Kasama sa Theodia ang dalawang study tool: ang **mga commentary** at **lexicons**. Tutulong sila sa iyo na unawain ang Bibliya nang mas malalim.

## Ano ang commentary?

Ang commentary ay isang aklat ng mga study note na isinulat ng isang Bible scholar. Para sa isang partikular na bersikulo, sinasabi sa iyo ng commentary ang background, ang kahulugan, at kung paano bumabagay ang bersikulo sa natitira ng Bibliya.

## Ano ang lexicon?

Ang lexicon ay isang dictionary ng mga salita sa Bibliya. Sinasabi nito sa iyo ang orihinal na salita sa Ebreo o Griyego, ang kahulugan nito, at kung paano ito ginagamit sa Bibliya.

## Paano buksan ang isang commentary

1. Buksan ang isang kabanata.
2. I-tap ang isang bersikulo.
3. I-tap ang **Commentary**.

Bubukas ang isang panel. Magpapakita ito ng mga note mula sa isang Bible scholar tungkol sa bersikulong iyon.

## Paano buksan ang isang lexicon

1. Buksan ang isang kabanata sa isang Bibliya na may kasamang Strong's numbers.
2. I-tap ang isang Strong's number sa bersikulo (halimbawa, G1234 o H1234).
3. Bubukas ang isang panel na nagpapakita ng orihinal na salita sa Ebreo o Griyego, ang kahulugan nito, at ibang mga bersikulo na gumagamit ng salita.

Lumilitaw ang Strong's numbers sa ibang kulay sa teksto ng bersikulo para maipagiba sila sa mga karaniwang salita.

## Pumili ng ibang commentary

Pinipili ang commentary mula sa isang dropdown sa itaas mismo ng commentary panel. Buksan ang panel, tapos i-tap ang dropdown para makita ang mga commentary na naka-install mo. Pumili ng iba.

## Pumili ng ibang lexicon

Pinipili ang lexicon mula sa isang dropdown sa itaas ng lexicon panel. Buksan ang panel, tapos i-tap ang dropdown para makita ang mga lexicon na naka-install mo. Pumili ng iba.

## Mga built-in na resource

Kasama sa Theodia ang isang built-in na set ng mga commentary at lexicon. Kasama ang mga ito sa app at gumagana nang offline. Hindi maaaring i-install o i-download nang hiwalay ang mga dagdag na commentary at lexicon.

## Kailan gagamitin ang mga ito

- Ang **mga commentary** ay maganda kapag mahirap unawain ang isang bersikulo. Nagbibigay sa iyo ng background ang mga note.
- Ang **mga lexicon** ay maganda para sa mga word study. Sinasabi nila sa iyo ang eksaktong kahulugan ng isang salita sa orihinal na wika.

## Tip

Kung may note ang isang bersikulo na gusto mong panatilihin, kumuha ng screenshot o kopyahin ang teksto sa isang note. (Tingnan ang gabay na [Pagsusulat ng mga Note](theodia://help/notes).)

## Bible dictionary sa payak na wika

Para sa mga kahulugan sa Ingles ng mga salita at konsepto sa Bibliya (tipan, pagbabayad-sala, mga Fariseo, at iba pa), kasama rin ng Theodia ang isang Bible Dictionary tool. Buksan ito mula sa verse menu sa pamamagitan ng pag-tap sa **Dictionary** (📖). Iba ito sa lexicon: ipinapaliwanag ng mga lexicon ang mga orihinal na salita sa Ebreo at Griyego, samantalang ipinapaliwanag ng dictionary ang salita sa Ingles sa payak na wika. Tingnan ang gabay na [Bible Dictionary](theodia://help/dictionary) para kung paano ito gamitin.
