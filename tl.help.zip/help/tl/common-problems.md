---
title: Mga Karaniwang Problema
level: everyday
categories: trouble
summary: Mabilis na mga solusyon sa mga problemang maaaring matuklasan mo.
---

# Mga Karaniwang Problema

Saklaw ng gabay na ito ang mga problemang pinakamadalas matuklasan ng mga tao. Kung wala rito ang problema mo, tingnan ang gabay na [Saan Magtanong](theodia://help/getting-more-help).

## Mabagal ang app

1. Isara ang ibang mga app na tumatakbo sa background.
2. I-restart ang app.
3. I-restart ang iyong device.

## Hindi ko mahanap ang isang pagsasalin ng Bibliya

1. Buksan ang **Settings** → **Manage Resources** para makita kung ano ang naka-install.
2. Kung wala doon ang pagsasalin, i-tap ang **Install from GitHub**.
3. Sa download modal, i-tap ang **Bibles** tab (o **Global Bibles**) at piliin ang pagsasalin na gusto mo.
4. I-tap ang **Install Selected** at hintayin matapos ang pag-download.
5. Kailangan mo ng internet para mag-download ng bagong pagsasalin.

## Nawala ang mga note o bookmark ko

1. Suriin na tama ang tab na tinitingnan mo. Ang mga note ay nasa **Notes** tab. Ang mga bookmark ay nasa **Bookmarks** tab.
2. Kung kamakailan kang nag-restore ng backup, maaaring pinagpalit ng backup ang iyong data. Tingnan ang petsa ng backup.
3. Kung nag-uninstall at nag-reinstall ka ng app, nawala ang iyong data. Sa susunod, gumawa muna ng backup.

## Hindi nakakahanap ang search ng mga bersikulo

1. Siguraduhing tama ang pagbaybay mo sa salita.
2. Sumubok ng mas maikling salita. Mas maraming bersikulo ang mahanap ng "Love" kaysa sa "loving."
3. Siguraduhing naka-install mo ang tamang pagsasalin ng Bibliya. Gumagana lang ang search sa mga pagsasalin na mayroon ka.

## Hindi gumagana ang read-aloud

1. Siguraduhing nakataas ang volume ng iyong device.
2. Siguraduhing pinapayagan ang app na gamitin ang speaker.
3. Sumubok ng ibang pagsasalin. May mga pagsasaling mas maayos gumana sa read-aloud kaysa sa iba.
4. Para sa step-by-step na checklist, tingnan ang gabay na [Pagbabasa nang Malakas](theodia://help/tts).

## Laging nagso-scrash ang app

1. I-restart ang app.
2. I-restart ang iyong device.
3. Kung patuloy ang problema, pakiusap i-report ito. Tingnan ang gabay na [Saan Magtanong](theodia://help/getting-more-help).

## Gusto kong i-uninstall ang app

Maaari mong i-uninstall ang Theodia na parang anumang ibang app. Bago mo ito gawin, gumawa ng backup ng iyong data. Pagkatapos mong i-uninstall, wala na ang data sa device.

## Naiwan pa rin?

Tingnan ang gabay na [Saan Magtanong](theodia://help/getting-more-help). Doon makakakita ka ng mga link para mag-report ng problema at magtanong sa komunidad.

Maaari ka ring maghanap sa mga help guide mula sa **Help & Guides** na pangunahing screen. Mag-type ng salita tulad ng `notifications`, `search`, o `bookmarks` para mahanap ang katugmang gabay.
