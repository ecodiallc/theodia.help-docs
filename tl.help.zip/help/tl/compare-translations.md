---
title: Pagkukumpara ng mga Pagsasalin
level: everyday
categories: [read, study]
summary: Kung paano makita ang parehong bersikulo sa bawat pagsasalin na naka-install mo.
---

# Pagkukumpara ng mga Pagsasalin

> **Mode:** Makukuha ang Compare tool sa **Standard** at **Scholar** mode. Ang Focus Mode ay para lang sa malinis at walang distraksyon na pagbabasa. Maaari mong palitan ang mode sa **Settings** → **App User Mode**.

Ipinapakita ng **Compare** tool ang isang bersikulo sa bawat pagsasalin ng Bibliya na naka-install mo, lahat sa isang panel. Kapaki-pakinabang ito kapag gusto mong makita kung paano hinarap ng iba't ibang tagasalin ang isang mahirap na bersikulo, o kapag pumipili ka ng pagsasalin at gusto mong tingnan ang parehong bersikulo sa bawat isa.

## Paano buksan ang Compare

1. Buksan ang isang kabanata sa anumang pagsasalin.
2. I-tap ang isang bersikulo para lumabas ang verse menu.
3. I-tap ang **Compare** (⇄).

Bubukas ang isang panel. Ipinapakita ng title bar ang sanggunian (halimbawa, "Juan 3:16 — Compare"). Inililista ng panel ang parehong bersikulo sa bawat naka-install na pagsasalin. Nakalista muna ang kasalukuyan mong pagsasalin; ang iba ay nakaayos ayon sa alpabeto.

## Ano ang itsura ng panel

Ang panel ay isang **patayong listahan**, hindi isang magkatabing column. Ang bawat row ay isang pagsasalin:

- Ang **pangalan ng pagsasalin** (halimbawa, "KJV") ay nasa itaas ng row. Nai-tap ito.
- Ang **teksto ng bersikulo** ay nasa ibaba ng pangalan.

I-scroll ang panel para makita ang lahat ng pagsasalin. Lalabas dito ang bawat pagsasalin na naka-install sa iyong device. Kung walang ganitong aklat o bersikulo ang isang pagsasalin, iniiwan ito.

## Paano basahin ang bersikulo sa ibang pagsasalin

I-tap ang pangalan ng pagsasalin sa row. Magsasara ang Compare panel at bubukas ang parehong kabanata na may napiling bersikulo na ipinapakita sa pagsasaling iyon. Ito ang pinakamabilis na paraan para tumalon mula sa paghahambing nang diretso sa pagbabasa ng isang partikular na pagsasalin.

## Paano isara ang Compare

- **Sa isang telepono:** i-tap ang X sa kanang itaas ng panel.
- **Sa isang tablet:** i-tap ang X sa header ng panel, o i-tap sa labas ng panel.

Bumalik ka sa chapter view sa orihinal mong pagsasalin.

## Kailan gagamitin ang Compare

- **Pagpili ng pagsasalin.** Buksan ang isang bersikulo na alam mo nang mabuti sa kasalukuyan mong pagsasalin, tapos i-Compare para makita ito sa iba. Napapansin agad ang mga pagkakaiba.
- **Mga mahihirap na bersikulo.** Ang isang bersikulo na nakakalito sa isang pagsasalin ay kadalasang mas malinaw sa isa pa.
- **Mga word study.** Tingnan kung paano hinarap ng iba't ibang tagasalin ang isang mahalagang salita o parirala.

Para sa isang sulyap-sulyap na paghahambing ng isang buong kabanata sa maraming pagsasalin nang sabay-sabay, gamitin ang **parallel view**. Tingnan ang gabay na [Study Mode](theodia://help/study-mode) para kung paano ito i-on.
