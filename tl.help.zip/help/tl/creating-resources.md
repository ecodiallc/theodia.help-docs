---
title: Paglikha ng Sarili mong mga Resource
level: advanced
categories: resources
summary: Kung paano gumawa ng custom na mga Bibliya, commentary, aklat, devotional, at lexicon at i-import ang mga ito sa Theodia.
---

# Paglikha ng Sarili mong mga Resource

Sinusuportahan ng Theodia ang mga custom na resource sa Unique Bible App format. Ang bawat resource ay isang SQLite file na may tiyak na istruktura ng mga table. Maaari mong gawin ang mga file na ito sa isang computer at i-import sa app.

## Mga uri ng file at kinakailangang mga table

### Mga Bibliya (`.bible`)

Ang isang Bible file ay isang SQLite database na may kahit isa sa mga table na ito:

- **`Verses`** — mga column: `Book` (integer, 1-66), `Chapter` (integer), `Verse` (integer), `Scripture` (text)
- **`Bible`** — mga column: `Book` (integer), `Chapter` (integer), `Verse` (integer), `Scripture` (text)

Maaari ka ring maglagay ng **`Details`** table na may mga metadata column tulad ng `Description`, `Abbreviation`, at `Version`.

Halimbawa ng SQL:

```sql
-- Main text table
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- Optional metadata table
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### Mga Commentary (`.commentary`)

Ang mga commentary ay may tatlong uri: **aklat**, **kabanata**, at **bersikulo**. Natutukoy ang uri sa **unang letra ng filename**.

#### Mga book commentary — nagsisimula sa `b` ang filename

Ang isang book commentary ay sumasaklaw sa isang buong aklat ng Bibliya sa isang entry. Ang `Commentary` table ay nangangailangan ng mga `Book` at `Scripture` (o `Content`) column. Hindi na kailangan ang mga `Chapter` o `Verse` column.

- **`Commentary`** — mga column: `Book` (integer), `Scripture` (text) o `Content` (text)

Halimbawa ng SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

Halimbawa ng filename: `bMyCommentary.commentary`

#### Mga chapter commentary — nagsisimula sa `c` ang filename

Ang isang chapter commentary ay sumasaklaw sa bawat kabanata ng isang aklat ng Bibliya.

- **`Commentary`** — mga column: `Book` (integer), `Chapter` (integer), `Scripture` (text) o `Content` (text)

Halimbawa ng SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

Halimbawa ng filename: `cMyCommentary.commentary`

#### Mga verse commentary — nagsisimula sa `v` ang filename

Ang isang verse commentary ay sumasaklaw sa mga indibidwal na bersikulo. Ang `Commentary` table ay nangangailangan ng mga `Book`, `Chapter`, `Verse`, at `Scripture` (o `Content`) column.

- **`Commentary`** — mga column: `Book` (integer), `Chapter` (integer), `Verse` (integer), `Scripture` (text) o `Content` (text)

Halimbawa ng SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

Halimbawa ng filename: `vMyCommentary.commentary`

### Mga Aklat (`.book`)

Ang isang book file ay isang SQLite database na may `Reference` table.

- **`Reference`** — mga column: `id` (integer), `Chapter` (text), `Content` (text)

Ang bawat row ay isang kabanata. Ang `Chapter` column ang pamagat ng kabanata. Ang `Content` column ang katawan ng kabanata, na maaaring maglaman ng HTML (`<b>`, `<i>`, `<br>`, at iba pa).

Halimbawa ng SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

Maaari ka ring gumawa ng mga aklat mula sa mga Markdown file. Maaaring i-import ng app ang mga `.md` file kung saan ang `#` ay pamagat ng aklat at ang `##` ay nagmamarka ng mga kabanata. Awtomatikong kino-convert ang Markdown sa HTML.

### Mga Devotional (`.devotional`)

Ang isang devotional file ay isang SQLite database na may `devotional` table.

- **`devotional`** — mga column: `month` (integer, 1-12), `day` (integer, 1-31), `devotion` (text)

Ang bawat row ay isang araw ng pagbabasa. Hinahanap ng app ang entry ayon sa kasalukuyang buwan at araw.

Halimbawa ng SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### Mga Lexicon (`.lexicon`)

Ang isang lexicon file ay isang SQLite database na may `Lexicon` table.

- **`Lexicon`** — mga column: `Topic` (text, ang Strong's number), `Definition` (text, ang lexicon entry)

Nakalagay sa `Topic` column ang Strong's number (halimbawa, `G1161` o `H7225`). Nakalagay sa `Definition` column ang buong teksto ng entry, na maaaring maglaman ng HTML.

Halimbawa ng SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

Pinapagana ng mga lexicon ang Word Info tool. Kapag nag-tap ka ng isang salita sa isang interlinear Bible, hinahanap ng app ang Strong's number sa mga naka-install na lexicon.

## Paglikha ng file sa iyong computer

1. Mag-install ng SQLite editor (DB Browser for SQLite, SQLiteStudio, o ang `sqlite3` command-line tool).
2. Gumawa ng bagong database file.
3. Gumawa ng kinakailangang table at i-insert ang iyong data.
4. I-save ang file na may tamang extension (`.bible`, `.commentary`, `.book`, `.devotional`, o `.lexicon`).

## Pag-import sa Theodia

1. Ilipat ang file sa iyong device (AirDrop, email, cloud storage, o USB).
2. Buksan ang **Theodia**.
3. Pumunta sa **Settings** → **Manage Resources**.
4. I-tap ang **Import from File**.
5. Piliin ang iyong file.

Sinusuri ng app ang file (tinitingnan kung mayroon ang kinakailangang table), kinokopya ito sa data folder ng app, at awtomatikong binubuksan ito. Kung hindi wasto ang file, makikita mo ang isang mensahe ng error na nagpapaliwanag kung ano ang mali.

## Mga limitasyon

- Hindi mo maaaring ibabaw-sulatin ang mga built-in na resource. Kung sinubukan mong mag-import ng file na may parehong pangalan ng isang built-in na Bibliya, commentary, o aklat, mabibigo ang import.
- Ang mga Bible file ay nangangailangan ng `Verses` o `Bible` table. Kung wala sa dalawa, mabibigo ang import.
- Ang mga commentary file ay nangangailangan ng `Commentary` table.
  - Ang mga book commentary ay nangangailangan ng mga `Book` at `Scripture` (o `Content`) column.
  - Ang mga chapter commentary ay nangangailangan ng mga `Book`, `Chapter`, at `Scripture` (o `Content`) column.
  - Ang mga verse commentary ay nangangailangan ng mga `Book`, `Chapter`, `Verse`, at `Scripture` (o `Content`) column.
- Ang mga book file ay nangangailangan ng `Reference` table.
- Ang mga lexicon file ay nangangailangan ng `Lexicon` table.
- Ang mga devotional file ay nangangailangan ng `devotional` table.

## Mga tip

- Panatilihing makatwiran ang laki ng mga file. Ang napakalalaking SQLite file ay maaaring magdulot ng mga problemang memorya sa mas lumang device.
- I-test muna ang iyong file sa isang computer. Buksan ito sa isang SQLite browser at patakbuhin ang `SELECT * FROM` sa kinakailangang table para i-verify na tama ang anyo ng data.
- Para sa mga Bibliya, siguraduhing gumagamit ang `Book` column ng mga numero (1 = Genesis, 66 = Pahayag).
- Para sa mga Commentary, maaari mong gamitin ang `Scripture` o `Content` bilang column ng teksto ng commentary.
- Para sa mga Aklat, inilalapat ang HTML sa `Content` column kapag nagbabasa. Panatilihing simple: ang `<b>`, `<i>`, `<br>`, at `<hr>` ay ligtas.

## Saan makakakita ng umiiral na mga resource

Maaaring magbasa ang Theodia ng mga resource mula sa proyektong [Unique Bible App](https://github.com/eliranwong/UniqueBible). Maraming Bibliya, commentary, aklat, at iba pang resource ang makukuha roon sa tamang SQLite format. Tingnan ang gabay na [Paggakuha ng mga Karagdagang Resource](theodia://help/getting-core-files) para kung paano hanapin at idagdag ang mga ito.
