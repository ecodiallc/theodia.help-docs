---
title: Mga Cross-Reference
level: everyday
categories: study
summary: Kung paano mahanap ang mga bersikulo na kaugnay ng binabasa mo.
---

# Mga Cross-Reference

Ang isang "cross-reference" ay ibang bersikulo na nag-uusap tungkol sa parehong bagay na bersikulo na binabasa mo. Ipinapakita sa iyo ng cross-reference panel kung aling mga bersikulo sa Bibliya ang magkakaugnay.

## Paano buksan ang mga cross-reference

1. Buksan ang isang kabanata.
2. I-tap ang isang bersikulo para lumabas ang verse menu.
3. I-tap ang **Cross References**.

Bubukas ang isang panel. Ipinapakita nito ang listahan ng iba pang mga bersikulo na kaugnay ng na-tap mo.

## Paano basahin ang listahan

Ang bawat row ay isang nag-uugnay na bersikulo. Nakikita mo:

- Ang aklat, kabanata, at bersikulo.
- Isang maikling prebiyu ng teksto ng bersikulo.
- Isang score na nagpapakita kung gaano kalakas ang koneksyon.

## Paano tumalon sa isang nag-uugnay na bersikulo

I-tap ang anumang row. Binubuksan ng app ang bersikulong iyon para sa iyo. Kapag tapos ka na, i-tap ang back button para bumalik.

## Ano ang kahulugan ng score

Sinasabi ng score kung gaano kalapit nakaugnay ang mga bersikulo. Ang mataas na score ay nangangahulugang malakas at direktang koneksyon. Ang mababang score ay mas luwag.

## Paggamit ng mga cross-reference sa pag-aaral

Kapaki-pakinabang ang mga cross-reference para sa:

- **Mga word study.** Makita kung paano ginagamit ng Bibliya ang isang salita sa iba't ibang lugar.
- **Mga theme study.** Sundan ang isang tema, tulad ng "pag-ibig" o "tipan," sa buong Kasulatan.
- **Sermon prep.** Mabilis na makahanap ng mga sumusuportang bersikulo.

## Tip

Pinakamaayos na gumagana ang mga cross-reference sa isang word-for-word na pagsasalin tulad ng WEB.
