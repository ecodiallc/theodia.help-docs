---
title: Mga Daily Devotional
level: everyday
categories: [content, read]
summary: Kung paano magbasa ng maikling devotional araw-araw.
---

# Mga Daily Devotional

Ang isang devotional ay isang maikling pagbabasa para sa isang araw. Kadalasang mayroon itong bersikulo, maikling pag-iisip, at isang tanong na pag-isipan. May kasamang maliit na aklatan ng mga devotional ang Theodia.

## Paano buksan ang isang devotional

1. I-tap ang **Devotionals** tab sa ibaba ng screen.
2. Makikita mo ang listahan ng mga devotional na naka-install sa iyong device.
3. I-tap ang isa para buksan ito.

## Paano magbasa ng devotional

1. Buksan ang devotional.
2. I-scroll para magbasa.
3. Gamitin ang mga button sa itaas para:
   - I-tap ang **petsa** para tumalon sa ibang araw.
   - I-tap ang **star** para i-bookmark ang araw.
   - I-tap ang **speaker** para basahin ito nang malakas (kung sinusuportahan ng iyong device). Tingnan ang gabay na [Pagbabasa nang Malakas](theodia://help/tts) para kung paano pumili ng boses.
   - I-tap ang **Previous** o **Next** para lumipat sa araw bago o pagkatapos.

## Paano i-save ang isang bersikulo mula sa devotional

1. Buksan ang devotional.
2. I-tap ang isang bersikulo.
3. I-tap ang **Bookmark** o **Highlight**.

Nase-save ang bersikulo sa iyong Bookmarks o Highlights.

## Paano magsulat ng note sa isang devotional

1. Buksan ang devotional.
2. I-tap ang isang bersikulo.
3. I-tap ang **Note**. I-type ang iyong pagninilay o panalangin. I-tap ang **Save**.

Lalabas ang note sa iyong Notes tab.

## Mga tip

- Hindi kailangan ng mga devotional ang internet. Gumagana sila nang offline.
- Kung gusto mo ng mas maraming devotional, tingnan ang gabay na [Paggakuha ng mga Karagdagang Resource mula sa GitHub](theodia://help/getting-core-files).
