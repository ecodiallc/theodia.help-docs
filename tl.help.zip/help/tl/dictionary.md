---
title: Bible Dictionary
level: everyday
categories: study
summary: Hanapin ang mga salita at konsepto sa Bibliya sa mga naka-install na dictionary resource. Buksan ito mula sa verse menu o mula sa isang lexicon entry, tapos i-tap ang anumang salita para makita ang parehong salita sa bawat dictionary.
---

# Bible Dictionary

> **Mode:** Kailangan ng Bible Dictionary ang **Scholar** mode. Maaari mong palitan ang mode sa **Settings** → **App User Mode**.

Hinahanap ng Bible Dictionary tool ang isang salita o parirala sa bawat dictionary resource na naka-install mo. Kapaki-pakinabang ito kapag gusto mo ng payak na kahulugan ng isang salita sa Bibliya, paglalarawan ng isang tao o lugar, o maikling artikulo tungkol sa isang theological na konsepto.

Iba ang Bible Dictionary sa **Word Info** tool, na nagpapahanap sa orihinal na salitang Ebreo o Griyego sa likod ng isang bersikulo. Binabasa ng dictionary ang salita sa **Ingles** na na-tap mo at ipinapakita sa iyo kung ano ang sinasabi ng mga naka-install mong dictionary tungkol dito. Para sa mga note sa word-by-word na pagsasalin ng Bibliya, tingnan ang gabay na [Mga Commentary at Lexicon](theodia://help/commentaries-and-lexicons).

## Paano buksan ang Dictionary

May dalawang paraan para buksan ang dictionary.

### Mula sa verse menu

1. Buksan ang isang kabanata sa [Study Mode](theodia://help/study-mode).
2. I-tap ang isang bersikulo para buksan ang verse menu.
3. I-tap ang **Dictionary** (📖).

Bubukas ang isang panel na pinamagatan ng sanggunian ng bersikulo (halimbawa, "Juan 3:16"). Nasa itaas ang teksto ng bersikulo na nai-tap ang bawat salita. Sa ibaba ng bersikulo ay isang chip strip na nagpapakita ng bawat naka-install na dictionary. Sa ibaba nito ang kahulugan, na walang laman hanggang sa mag-tap ka ng isang salita.

### Mula sa isang lexicon entry

Kapag nagbabasa ka ng isang lexicon entry sa Word Info panel, may ilang entry na naglalaman ng mga asul na link papunta sa mga kaugnay na dictionary article. I-tap ang anumang sa mga link na iyon. Magsasara ang lexicon at bubukas ang dictionary sa artikulong iyon. Ito ang pinakamabilis na paraan para tumalon mula sa isang salitang Griyego o Ebreo patungo sa payak na paliwanag ng kahulugan nito.

## Paano gumagana ang verse view

Kapag binuksan mo ang dictionary mula sa isang verse menu, lumilitaw ang bersikulo sa itaas ng panel bilang listahan ng mga nai-tap na salita. Ang mga karaniwang salita sa Ingles tulad ng "the," "and," "of," "to," at "a" ay hindi nai-tap. Ang bawat iba pang salita ay oo. Ang bawat nai-tap na salita ay may kulay at bold para maipagiba sa natitira ng bersikulo.

I-tap ang anumang salita sa bersikulo. Naghahanap ang Theodia sa bawat naka-install na dictionary ng eksaktong tugma sa salitang iyon. Ina-update ang chip strip sa ibaba para ipakita kung aling mga dictionary ang may entry: ang mga dictionary na walang entry para sa salitang iyon ay dina-dim. Awtomatikong napipili ang unang dictionary na may entry, at lumilitaw ang kahulugan nito sa ilalim ng chip strip.

Naka-highlight ang salita na na-tap mo sa teksto ng bersikulo sa itaas ng panel, kaya lagi mong alam kung ano ang hinahanap mo.

## Paglipat-lipat sa mga dictionary

Ipinapakita ang bawat naka-install na dictionary bilang isang maliit na chip sa ilalim ng bersikulo. Pagkatapos mag-tap ng isang salita:

- Ang chip na **solid na kulay** — may entry ang dictionary na ito para sa salita na na-tap mo. I-tap ito para lumipat sa kahulugan ng dictionary na iyon.
- Ang chip na **naka-dim** — walang entry ang dictionary na ito para sa salitang iyon. Ipinapakita itong naka-grey out para sa isang sulyap ay makita mo kung aling mga dictionary ang sumasaklaw sa salita, at hindi maaaring i-tap ang chip.

Naka-highlight ang napiling dictionary. I-tap ang anumang iba pang solid na chip para basahin ang parehong salita sa dictionary na iyon. Agad na ina-update ang kahulugan sa ibaba.

Kung mayroon lang sa isa sa mga naka-install mong dictionary ang salita, solid lang ang chip na iyon at naka-dim ang iba.

## Ano ang ipinapakita ng panel

May tatlong bahagi ang dictionary panel, mula itaas pababa:

- **Ang bersikulo** — ang bersikulo na pinagbuksan mo ng dictionary. Nai-tap ang mga salita, at naka-highlight ang pinakahuling na-tap mo.
- **Ang chip strip** — bawat naka-install na dictionary. Ang solid ay nangangahulugang "may entry para sa na-tap na salita." Ang naka-dim ay nangangahulugang "walang entry para sa salitang iyon."
- **Ang kahulugan** — ang artikulo mula sa napiling dictionary. Plain text, na naka-format na may mga talata at heading. Ang mga panloob na link papunta sa ibang dictionary entry ay nai-tap; ang pag-tap sa isa sa mga ito ay bubukas ng entry na iyon sa dictionary.

## Ano ang mangyayari kung walang natagpuang entry

Kung nag-tap ka ng isang salita na wala sa anuman sa mga naka-install mong dictionary, nagpapakita ang panel ng maikling mensaheng "no entries found" sa halip na isang kahulugan. Karaniwan ito para sa mga napakakaraniwang salita tulad ng "year" o "come" na hindi talagang mga salita ng Bible theology, kahit na laganap sila sa buong Bibliya. Sumubok ng mas tiyak na salita, o gamitin ang Word Info tool ng lexicon na gumagana sa pinagbabatayang teksto sa Griyego at Ebreo.

## Ano ang mangyayari kung walang naka-install na dictionary

Kailangan ng dictionary ng kahit isang dictionary resource file para maging kapaki-pakinabang. May kasamang isa ang Theodia. Kung inalis mo ito o nagpapatakbo ka ng custom na install na walang mga dictionary, lilitaw pa rin ang verse view at nai-tap pa rin ang mga salita, ngunit wala ang chip strip at bawat paghahanap ay magbabalik ng "no entries found."

Hindi maaaring i-install nang hiwalay ang mga karagdagang dictionary.

## Mga tip

- Naghahanap ang dictionary ng **eksaktong tugma ng salita**. Ang pag-tap ng "love" ay makakahanap ng mga entry na pinamagatang "love" ngunit hindi ang "loved" o "loving." Para maghanap ng kaugnay na anyo, gamitin ang Word Info tool ng lexicon sa salitang Griyego o Ebreo.
- Pareho ang chip strip sa mga telepono at tablet. Sa tablet, bumubukas ang dictionary bilang side panel sa tabi ng kabanata; sa telepono, bumubukas ito bilang full-screen modal. Pareho ang three-part na layout ng dalawa.
- Ang pag-tap ng isang salita sa ibang bersikulo ay bubukas ng bagong bersikulo sa panel. Nililinis ang iyong nakaraang pagpili. I-tap ang isang salita sa bagong bersikulo para magsimula ng bagong paghahanap.
- May ilang dictionary entry na tumutukoy sa parehong salita sa ibang dictionary. I-tap ang mga panloob na link na iyon para sundan ang landas sa lahat ng naka-install mong dictionary.

## Mga pagkakaiba ng Dictionary at Word Info

Bumubukas ang dalawang tool mula sa verse menu, ngunit magkaiba ang ginagawa nila:

- Ang **Dictionary** (📖) ay binabasa ang salita sa Ingles na na-tap mo at hinahanap ito sa mga naka-install mong English dictionary. Ito ang tamang tool para sa mga payak na kahulugan ng mga salita ng Bible theology tulad ng "tipan," "pagbabayad-sala," o "Fariseo."
- Ang **Word Info** (?) ay binabasa ang orihinal na salitang Griyego o Ebreo sa likod ng bersikulo at hinahanap ito sa mga naka-install mong lexicon. Ito ang tamang tool para sa mga seryosong word study, paghahanap sa bawat lugar na ginamit ang isang salitang Griyego, at pagbasa ng mga kahulugan sa orihinal na wika.

Kung nag-aalinlangan, magsimula sa dictionary. Kung gusto mong maghukay sa orihinal na wika, lumipat sa Word Info. Tingnan ang gabay na [Mga Commentary at Lexicon](theodia://help/commentaries-and-lexicons) para sa buong Word Info walkthrough.

## Mga kaugnay na gabay

- Ipinapaliwanag ng gabay na [Study Mode](theodia://help/study-mode) nang detalyado ang verse menu at kung saan nakaupo ang Dictionary (📖) tool sa tabi ng Bookmark, Highlight, Speak, Compare, Cross-References, AI Commentary, Word Info, at Notes.
- Saklaw ng gabay na [Mga Commentary at Lexicon](theodia://help/commentaries-and-lexicons) ang Word Info at ang mga orihinal-na-wikang lexicon.
- Ipinapaliwanag ng gabay na [Ano ang mga Resource?](theodia://help/what-are-resources) ang iba't ibang uri ng file na ginagamit ng Theodia, kabilang ang mga dictionary resource.
- Ang gabay na [Mga Karaniwang Problema](theodia://help/common-problems) ay may mga solusyon sa mga walang lamang resulta at iba pang problemang dictionary.
