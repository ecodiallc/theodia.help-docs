---
title: Encyclopedia
level: everyday
categories: study
summary: Kung paano maghanap ng mga encyclopedia article at mag-browse ng mga reference work.
---

# Encyclopedia

Kasama sa Theodia ang isang built-in na **Encyclopedia** para maghanap ng mga artikulo kaugnay ng Bibliya, mga tao, lugar, at paksa. Kasama sa app ang _Kitto's Illustrated Commentary_ (KIT), at maaari kang mag-download ng mga karagdagang encyclopedia mula sa repository.

## Ano ang encyclopedia sa Theodia?

Ang isang encyclopedia ay isang reference work na gawa sa mga maikling artikulo. Ang bawat artikulo ay sumasaklaw sa isang tao, lugar, pangyayari, o paksa sa Bibliya. Hindi tulad ng commentary, na nagpapaliwanag ng isang partikular na bersikulo, ipinapaliwanag ng isang encyclopedia article ang mismong paksa.

## Paano buksan ang Encyclopedia

1. I-tap ang **Encyclopedia** sa bottom toolbar.
2. Pumili ng encyclopedia mula sa hanay ng mga abbreviation sa itaas.
3. Mag-type ng paksa, tao, o lugar sa search box.

Nangangailangan ang search ng kahit **3 characters** bago lumabas ang mga resulta at mga autocomplete suggestion.

## Pagbabasa ng isang artikulo

- Sa **telepono**, i-tap ang anumang resulta para buksan ang artikulo sa isang bagong screen.
- Sa **tablet**, bumubukas ang artikulo sa panel sa kanan habang nananatili sa kaliwa ang listahan.

## Pagpili ng mga encyclopedia

I-tap ang isang abbreviation chip (tulad ng **KIT**) para lumipat sa encyclopedia na iyon. Para maghanap sa higit sa isang encyclopedia nang sabay-sabay, gamitin ang **Search** tab at piliin ang **Encyclopedia** bilang search mode.

## Paggakuha ng mas maraming encyclopedia

1. Buksan ang **Settings**.
2. I-tap ang **Manage Resources**.
3. I-tap ang **Install from GitHub**.
4. Piliin ang **Encyclopedias** tab.
5. I-tap ang download button sa tabi ng encyclopedia na gusto mo.

Dina-download ang mga encyclopedia mula sa encyclopedia GitHub repository ng Theodia at awtomatikong nai-install. Lumilitaw ang mga naka-install na encyclopedia sa Encyclopedia screen at sa Search.

Maaari ka ring mag-install ng isang encyclopedia mula sa isang lokal na file: sa **Manage Resources**, i-tap ang **Install Local File** at pumili ng `.encyclopedia` file. Kinokopya ang file sa encyclopedias folder ng app at idinadagdag sa shared lookup index.

## Pindutin nang matagal para sa buong pamagat

Sa Search screen, nagpapakita ang mga encyclopedia chip ng mga maikling abbreviation. Pindutin nang matagal ang isang chip para makita ang buong pangalan ng encyclopedia.

## Kailan gagamitin ang Encyclopedia

- Maghanap ng tao, lugar, o paksa bago o habang nagbabasa ng isang talata.
- Makakuha ng background sa isang salita o konsepto sa Bibliya na tumatawid sa maraming bersikulo.
- Magbasa katabi ng isang commentary para sa mas malalim na pag-aaral.
