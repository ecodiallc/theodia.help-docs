---
title: Mga Keyboard Shortcut ng External Keyboard
level: everyday
categories: [tablet, settings]
summary: Kumpletong sanggunian ng mga keyboard shortcut para sa iPad na may nakakabit na external keyboard.
---

# ⌨️ Mga Keyboard Shortcut ng External Keyboard

Kung ginagamit mo ang Theodia sa iPad na may external keyboard (Magic Keyboard, Bluetooth keyboard, o USB keyboard), maaari mong i-navigate ang app nang hindi hinahawakan ang screen.

> **Mode:** Ang ilang shortcut ay gumagana lang kapag makukuha ang katugmang feature sa kasalukuyan mong user mode. Halimbawa, ang `Cmd + Option + 6` (Bookmarks) at `Cmd + Option + 7` (Highlights) ay walang ginagawa sa Reader mode. Magpalit ng mode sa **Settings** → **App User Mode**.

Gumagana ang mga shortcut sa **iPad**.

## Mga global shortcut (kahit saan)

| Shortcut          | Aksyon                                       |
| ----------------- | -------------------------------------------- |
| `Cmd + /`         | Ipakita ang tulong sa mga keyboard shortcut na ito |
| `Cmd + .`         | Isara ang modal / panel (alternatibo sa Escape) |
| `Cmd + Option + 1` | Pumunta sa Home tab                         |
| `Cmd + Option + 2` | Pumunta sa Bibles tab                       |
| `Cmd + Option + 3` | Pumunta sa Books tab                        |
| `Cmd + Option + 4` | Pumunta sa Devotionals tab                  |
| `Cmd + Option + 5` | Pumunta sa Search tab                       |
| `Cmd + Option + 6` | Pumunta sa Bookmarks tab (Standard at Scholar) |
| `Cmd + Option + 7` | Pumunta sa Highlights tab (Standard at Scholar) |
| `Cmd + Option + 8` | Pumunta sa Notes tab (Standard at Scholar)  |
| `Cmd + Option + 9` | Pumunta sa AI tab (Scholar lang, kung naka-enable) |
| `Cmd + Option + 0` | Pumunta sa Help tab                         |
| `Cmd + Option + I` | Pumunta sa About tab                        |
| `Cmd + [`         | Bumalik                                      |
| `Cmd + F`         | Buksan ang Search                            |
| `Cmd + K`         | Buksan ang Launcher Menu (Scholar)           |
| `Cmd + ,`         | Buksan ang Settings                          |
| `Cmd + Shift + M` | Buksan ang pangunahing menu                  |
| `Cmd + Shift + T` | I-cycle ang theme (default / madilim)        |
| `Cmd + Shift + U` | Buksan ang user mode picker                  |
| `Escape`          | I-dismiss ang modal / isara ang panel        |

## Mga shortcut sa Bible Reader

Gumagana ang mga ito sa **Study Reader** at **Focus Reader**.

| Shortcut           | Aksyon                                                       |
| ------------------ | ------------------------------------------------------------ |
| `← Left Arrow`     | Naunang kabanata                                             |
| `→ Right Arrow`    | Susunod na kabanata                                          |
| `Cmd + R`          | Pagpalitin ang Study at Focus Reader (Standard at Scholar)   |
| `Cmd + Option + V` | Buksan ang version picker                                    |
| `Cmd + Option + B` | Buksan ang book picker                                       |
| `Cmd + Option + C` | Buksan ang chapter picker                                    |
| `Cmd + T`          | I-toggle ang TTS (itigil kapag nagpe-play/naka-pause, simulan kapag idle) |
| `Cmd + Option + T` | I-play / I-pause ang TTS                                     |

## Study Reader lang

| Shortcut           | Aksyon                                                                 |
| ------------------ | ---------------------------------------------------------------------- |
| `↑ Up Arrow`       | Piliin ang naunang bersikulo                                           |
| `↓ Down Arrow`     | Piliin ang susunod na bersikulo                                        |
| `Cmd + ↑`          | Piliin ang unang bersikulo                                             |
| `Cmd + ↓`          | Piliin ang huling bersikulo                                            |
| `Cmd + ←`          | Tumalon sa kabanata 1                                                  |
| `Cmd + →`          | Tumalon sa huling kabanata                                             |
| `Cmd + 0`–`9`      | Direktang pagtalon sa bersikulo (mag-type ng mga digit, hal. `Cmd + 1` `Cmd + 6` para sa bersikulo 16) |
| `Cmd + P`          | I-toggle ang parallel Bibles (Standard at Scholar)                     |
| `Cmd + B`          | I-bookmark ang napiling bersikulo (Standard at Scholar)                |
| `Cmd + H`          | I-highlight ang napiling bersikulo (Standard at Scholar)               |
| `Cmd + N`          | Magdagdag ng note para sa napiling bersikulo (Standard at Scholar)     |
| `Cmd + C`          | Ihambing ang mga pagsasalin ng napiling bersikulo (Standard at Scholar) |
| `Cmd + X`          | Buksan ang mga cross-reference ng napiling bersikulo (Standard at Scholar) |
| `Cmd + I`          | Buksan ang word info (Scholar)                                         |
| `Cmd + D`          | Buksan ang dictionary para sa napiling bersikulo (Scholar)             |
| `Cmd + A`          | Buksan ang AI panel para sa napiling bersikulo (Scholar)               |
| `Cmd + Option + S` | I-toggle ang mga subheading                                            |
| `Cmd + Option + W` | Isara ang lahat ng nakabukas na study panel                            |
| `Cmd + Option + M` | Buksan ang verse action menu                                           |

## Focus Reader lang

| Shortcut       | Aksyon           |
| -------------- | ---------------- |
| `↑ Up Arrow`   | I-scroll pataas  |
| `↓ Down Arrow` | I-scroll pababa  |
| `Cmd + ↑`      | I-scroll sa itaas |
| `Cmd + ↓`      | I-scroll sa ibaba |
| `Cmd + =`      | Paliitin (zoom in) |
| `Cmd + -`      | Lumimiit (zoom out) |

## Paghahanap

| Shortcut           | Aksyon                           |
| ------------------ | -------------------------------- |
| `Return`           | Patakbuhin ang search            |
| `Cmd + Return`     | Burahin ang search at i-focus ang input |
| `Cmd + ↑`          | I-scroll pataas ang mga resulta  |
| `Cmd + ↓`          | I-scroll pababa ang mga resulta  |
| `Cmd + Option + A` | Piliin lahat ng scope item       |
| `Cmd + Option + C` | Alisin ang lahat ng scope item   |
| `Cmd + Option + B` | Bible search mode                |
| `Cmd + Option + O` | Book search mode                 |
| `Cmd + Option + D` | Dictionary search mode (Scholar) |
| `Cmd + Option + X` | Lexicon search mode (Scholar)    |

## Mga Resulta ng Search

| Shortcut  | Aksyon              |
| --------- | ------------------- |
| `Cmd + S` | Buksan ang save-all sheet |
| `Cmd + ↑` | I-scroll pataas ang mga resulta |
| `Cmd + ↓` | I-scroll pababa ang mga resulta |

## Book Reader

| Shortcut           | Aksyon                   |
| ------------------ | ------------------------ |
| `← Left Arrow`     | Naunang kabanata         |
| `→ Right Arrow`    | Susunod na kabanata      |
| `Cmd + ↑`          | Naunang kabanata         |
| `Cmd + ↓`          | Susunod na kabanata      |
| `↑ Up Arrow`       | I-scroll pataas          |
| `↓ Down Arrow`     | I-scroll pababa          |
| `Cmd + B`          | I-bookmark ang kasalukuyang kabanata |
| `Cmd + J`          | Buksan ang chapter picker |
| `Cmd + L`          | Buksan ang voice picker  |
| `Cmd + T`          | I-toggle ang TTS         |
| `Cmd + Option + T` | I-play / I-pause ang TTS |

## Devotional Reader

| Shortcut           | Aksyon              |
| ------------------ | ------------------- |
| `← Left Arrow`     | Naunang araw        |
| `→ Right Arrow`    | Susunod na araw     |
| `↑ Up Arrow`       | I-scroll pataas     |
| `↓ Down Arrow`     | I-scroll pababa     |
| `Cmd + ↑`          | I-scroll pataas (malaki) |
| `Cmd + ↓`          | I-scroll pababa (malaki) |
| `Cmd + D`          | Buksan ang date picker |
| `Cmd + T`          | I-toggle ang TTS    |
| `Cmd + Option + T` | I-play / I-pause ang TTS |

## AI Chat

| Shortcut           | Aksyon                     |
| ------------------ | -------------------------- |
| `Cmd + Return`     | Ipadala ang mensahe        |
| `Cmd + N`          | Bagong chat                |
| `Cmd + D`          | I-toggle ang conversation drawer |
| `Cmd + Option + C` | Burahin ang kasalukuyang chat |
| `Cmd + S`          | Buksan ang save menu       |
| `Escape`           | Isara ang drawer / menu    |

## Mga Bookmark

| Shortcut                      | Aksyon                             |
| ----------------------------- | ---------------------------------- |
| `↑ Up Arrow` / `↓ Down Arrow` | Piliin ang bookmark                |
| `Return`                      | Buksan ang bookmark (tablet: piliin) |
| `Cmd + R`                     | Basahin ang bookmark sa konteksto  |
| `Cmd + M`                     | Ilipat ang napiling bookmark sa mga folder |
| `Cmd + N`                     | Pamahalaan ang mga folder          |
| `Escape`                      | Isara ang detail panel / folder picker |

Sa **Save to Folder** picker, inililipat ng `↑ Up Arrow` / `↓ Down Arrow` ang pagpili, pinapalitan ng `Return` ang napiling folder o inaaktibo ang naka-highlight na aksyon, at isinasara ng `Escape` ang picker. Nasa itaas ng listahan ang **+ Create Folder** row.

## Mga Bible Note

| Shortcut                      | Aksyon                |
| ----------------------------- | --------------------- |
| `↑ Up Arrow` / `↓ Down Arrow` | Piliin ang note       |
| `Return`                      | Buksan ang note       |
| `Cmd + Return`                | I-focus ang filter input |
| `Escape`                      | Isara ang detail / editor |

## Mga Highlight

| Shortcut                      | Aksyon             |
| ----------------------------- | ------------------ |
| `↑ Up Arrow` / `↓ Down Arrow` | Piliin ang highlight |
| `Return`                      | Buksan ang highlight |
| `Cmd + Return`                | I-focus ang filter input |
| `Escape`                      | Isara ang detail panel |

## Listahan ng mga Bibliya

| Shortcut                                 | Aksyon                            |
| ---------------------------------------- | --------------------------------- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | Susunod na Bibliya                |
| `← Left Arrow` / `↑ Up Arrow`            | Naunang Bibliya                   |
| `Return`                                 | Buksan ang naka-focus na Bibliya  |
| `Cmd + Shift + S`                        | I-toggle ang paborito para sa naka-focus na Bibliya |
| `Escape`                                 | Bumalik                           |

## Screen ng mga Aklat ng Bibliya

| Shortcut                | Aksyon                     |
| ----------------------- | -------------------------- |
| `Tab` / `→ Right Arrow` | Susunod na aklat           |
| `← Left Arrow`          | Naunang aklat              |
| `↓ Down Arrow`          | Aklat sa ibaba sa grid     |
| `↑ Up Arrow`            | Aklat sa itaas sa grid     |
| `Cmd + ↓`               | Susunod na seksyon (AT / NT) |
| `Cmd + ↑`               | Naunang seksyon (AT / NT)  |
| `Return`                | Buksan ang naka-focus na aklat |
| `Escape`                | Bumalik                    |

## Listahan ng mga Aklat

| Shortcut                                 | Aksyon            |
| ---------------------------------------- | ----------------- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | Susunod na aklat  |
| `← Left Arrow` / `↑ Up Arrow`            | Naunang aklat     |
| `Return`                                 | Buksan ang naka-focus na aklat |
| `Escape`                                 | Bumalik           |

## Screen ng mga Kabanata ng Bibliya

| Shortcut                                 | Aksyon               |
| ---------------------------------------- | -------------------- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | Susunod na kabanata  |
| `← Left Arrow` / `↑ Up Arrow`            | Naunang kabanata     |
| `Return`                                 | Buksan ang naka-focus na kabanata |
| `Escape`                                 | Bumalik              |

## Screen ng mga Kabanata ng Aklat

| Shortcut               | Aksyon                    |
| ---------------------- | ------------------------- |
| `Tab` / `↓ Down Arrow` | Susunod na kabanata       |
| `↑ Up Arrow`           | Naunang kabanata          |
| `Return`               | Buksan ang naka-focus na kabanata |
| `Cmd + Return`         | I-focus ang search/filter input |
| `Escape`               | Bumalik                   |

## Listahan ng mga Devotional

| Shortcut                                 | Aksyon                  |
| ---------------------------------------- | ----------------------- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | Susunod na devotional   |
| `← Left Arrow` / `↑ Up Arrow`            | Naunang devotional      |
| `Return`                                 | Buksan ang naka-focus na devotional |
| `Escape`                                 | Bumalik                 |

## Mga Chart

Sa mga screen na Statistics, Goals, at Concordance.

| Shortcut        | Aksyon                                 |
| --------------- | -------------------------------------- |
| `← Left Arrow`  | Piliin ang naunang kategorya sa isang chart |
| `→ Right Arrow` | Piliin ang susunod na kategorya sa isang chart |

Sinusunod ng caption sa ilalim ng chart ang pagpili, at binibigkas ang bagong halaga.

## Pangunahing menu (habang bukas)

| Shortcut       | Aksyon                  |
| -------------- | ----------------------- |
| `↑ Up Arrow`   | Naunang item sa menu    |
| `↓ Down Arrow` | Susunod na item sa menu |
| `Return`       | Piliin ang naka-highlight na item |
| `Escape`       | Isara ang menu          |

## Mga Setting

| Shortcut | Aksyon                    |
| -------- | ------------------------- |
| `Escape` | Isara ang nakabukas na modal / picker |

## Mga Editor Modal

| Shortcut  | Aksyon         |
| --------- | -------------- |
| `Cmd + S` | I-save         |
| `Escape`  | Kanselahin / isara |

## Typing guard

Kapag naka-focus ka sa isang text field (search box, note editor, AI input), pinipigilan ang mga non-Cmd shortcut tulad ng mga arrow key at `Space` para hindi sila aksidenteng mag-trigger ng navigation. Ang mga shortcut na gumagamit ng `Cmd` key (hal., `Cmd + S`, `Cmd + B`) ay gumagana pa rin habang nagta-type.
