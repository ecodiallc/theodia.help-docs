---
title: Mga Madalas Itanong
level: everyday
categories: faq
summary: Mga sagot sa pinakakaraniwang mga tanong tungkol sa paggamit ng Theodia.
---

# Mga Madalas Itanong

## May bayad ba ang Theodia?

Isang beses na pagbili ang Theodia. Walang subscription, walang advertising, walang in-app purchase, at walang paghingi ng donasyon. Lahat ng karagdagang resource sa catalog ay libreng i-download pagkatapos mong bilhin ang app.

## Kailangan ko ba ng koneksyon sa internet?

Hindi. Kapag naka-install na ang app at mga data file nito, gumagana nang offline ang lahat. Maaari kang magbasa, maghanap, mag-highlight, magsulat ng mga note, at gumamit ng karamihan sa mga study tool nang walang signal.

Ang tanging feature na nangangailangan ng internet ay ang pag-download ng mga bagong resource.

## Saan naka-imbak ang aking data?

Lahat ng iyong mga bookmark, highlight, note, at setting ay naka-save sa iyong device. Hindi ina-upload ang mga ito sa anumang server.

Maaari mong i-back up ang mga ito nang mano-mano. Tingnan ang gabay na [Pag-back Up ng Iyong Data](theodia://help/backups) para kung paano.

## Maaari ko bang pakinggan nang malakas ang Bibliya?

Oo. Buksan ang anumang kabanata, i-tap ang menu, at piliin ang read-aloud na opsyon. Kailangang may naka-install na text-to-speech voice ang iyong device. Tingnan ang gabay na [Pagbabasa nang Malakas](theodia://help/tts) para sa higit pa.

## Paano maghanap ng isang bersikulo?

Maaari kang mag-type ng isang sanggunian tulad ng `John 3:16` sa Command sa home screen, o gamitin ang **Search** tab para maghanap ayon sa salita o parirala.

## Paano mag-report ng bug o magmungahi ng feature?

I-tap ang **Submit Suggestion / Issue** sa About screen, [i-report ito sa GitHub](https://github.com/ecodiallc/theodia.app/issues/new), o bisitahin ang pahina ng [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions).

## Anong mga device ang sinusuportahan?

Tumatakbo ang Theodia sa iPhone, iPad, at mga telepono at tablet na Android. Pinakamaayos itong gumagana sa mga device na may kahit 2 GB ng malayang storage para sa mga core data file.

## Maaari ba akong gumamit ng external keyboard?

Oo. Sinusuportahan ng Theodia ang mga Bluetooth at USB keyboard sa iPad. Ang mga navigation, search, at maraming reading feature ay may mga keyboard shortcut. Tingnan ang gabay na [Mga Keyboard Shortcut ng External Keyboard](theodia://help/external-keyboard-shortcuts) para sa kumpletong listahan.

## Anong mga wika ang sinusuportahan?

Makukuha ang interface ng app sa Ingles, Arabo, Tsino (Simplified at Traditional), Tsek, Danes, Olandes, Filipino, Pranses, Aleman, Griyego, Ebreo, Hindi, Indones, Italyano, Hapones, Koreano, Polako, Portuges (Brazil), Rumano, Ruso, Kastila, Swahili, Suweko, Thai, Turko, Ukraniano, at Vietnamese.

Ang wika ng teksto ng Bibliya ay nakadependa sa aling mga pagsasalin ang naka-install mo.

## Paano ko palitan ang wika?

Pumunta sa **Settings** at hanapin ang opsyon ng wika.

## Wala rito ang tanong ko. Saan ako makakakuha ng higit pang tulong?

Mag-browse sa natitira pang mga help guide ayon sa paksa, o magtanong sa komunidad ng [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions).

Tip: Sa **Help & Guides** na pangunahing screen, gamitin ang search box para mag-type ng isang paksa tulad ng `notifications` o `search` para mahanap ang katugmang gabay.
