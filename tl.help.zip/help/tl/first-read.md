---
title: Pagbasa ng Iyong Unang Kabanata
level: beginner
categories: [start, read]
summary: Isang step-by-step na paglalakad sa pagbubukas at pagbasa ng isang kabanata.
---

# Pagbasa ng Iyong Unang Kabanata

Ginagabayan ka ng gabay na ito sa pagbubukas ng isang kabanata sa unang pagkakataon.

## Hakbang 1: Buksan ang Bible tab

Tingnan ang ibaba ng screen. Makakakita ka ng isang hanay ng mga tab. I-tap ang nakasulat na **Bible**.

## Hakbang 2: Pumili ng aklat

Makakakita ka ng listahan ng mga aklat ng Bibliya. Una ang Genesis. Malapit sa gitna ang Juan. Huli ang Pahayag.

I-tap ang pangalan ng aklat na gusto mo.

## Hakbang 3: Pumili ng kabanata

Makakakita ka ng mga numero mula 1 hanggang sa bilang ng mga kabanata ng aklat. I-tap ang kabanata na gusto mo.

Bubukas ang kabanata. Nasa screen ang mga bersikulo.

## Hakbang 4: Gumalaw-galaw

- Mag-swipe **pakaliwa** para pumunta sa susunod na kabanata.
- Mag-swipe **pakanan** para bumalik.

## Hakbang 5: Makipag-ugnayan sa isang bersikulo

Ang magagawa mo sa isang bersikulo ay nakadependa sa iyong user mode.

### Reader mode

Malinis at walang distraksyon ang Reader mode.

- I-tap ang isang bersikulo para mai-highlight ito nang maikli.
- Walang study tools, bookmarks, o mga menu.
- Kung gusto mo ng mas maraming feature, lumipat sa **Standard** o **Scholar** mode sa **Settings**.

### Standard mode

Nagdaragdag ang Standard mode ng mga pang-araw-araw na feature para sa personal na Bible study.

I-tap ang isang bersikulo para buksan ang menu na may mga opsyong ito:

- **I-bookmark** ang bersikulo.
- **I-highlight** ito ng isang kulay.
- **Magdagdag ng note** dito.
- **Kopyahin** ang teksto ng bersikulo.
- **Ihambing** ang bersikulo sa ibang pagsasalin.
- **Maghanap ng mga cross-reference** para sa bersikulo.

### Scholar mode

Binubuksan ng Scholar mode ang bawat tool para sa malalim na Bible study.

I-tap ang isang bersikulo para buksan ang menu na may lahat sa Standard mode, dagdag pa ang:

- **Commentary** sa bersikulo.
- **Word Info** at mga lookup sa orihinal na wika.
- Mga kahulugan sa **Dictionary**.
- **AI assistant** para sa mas malalim na pag-aaral.

Maaari kang magpalit ng mode anumang oras sa **Settings**.

## Kailangan ng tulong sa isang partikular na tool?

May sariling gabay ang bawat tool. I-tap ang **Help** sa home page para makita ang lahat. Ang gabay na [Study Mode](theodia://help/study-mode) ay magandang simula — dinadaan nito ang bawat tool sa verse menu.

Kung natututo ka pa lang kung saan naroon ang mga bagay, tingnan ang gabay na [Layout at Navigation ng App](theodia://help/navigating-the-app). Ipinapaliwanag nito ang home screen, ang pangunahing menu, at ang bottom toolbar.

## Gusto ng mas maraming resource?

May kasamang ilang malayang makukuhang bersyon ng Bibliya ang app. Kung gusto mong magdagdag ng higit pa, o magdagdag ng mga commentary, aklat, o devotional, tingnan ang gabay na [Paggakuha ng mga Karagdagang Resource mula sa GitHub](theodia://help/getting-core-files). Ipinapakita nito kung saan mo mahanap ang mga ito at kung paano idagdag.
