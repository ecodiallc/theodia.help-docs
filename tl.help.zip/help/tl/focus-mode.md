---
title: Focus Mode
level: beginner
categories: [layout, read]
summary: Isang malinis at walang distraksyon na paraan ng pagbasa ng mahahabang talata.
---

# Focus Mode

> **Mode:** Ang Focus Mode ay ang reader sa **Reader** mode. Makukuha rin ito sa **Standard** at **Scholar** mode bilang alternatibo sa Study Mode. Maaari mong palitan ang mode sa **Settings** → **App User Mode**.

Ang Focus Mode ay isang paraan ng pagbasa ng isang kabanata ng Bibliya nang walang mga button o menu na nakaharang. Maganda ito para sa mahahabang session ng pagbabasa.

## Paano ito i-on

1. Buksan ang anumang kabanata.
2. Sa hanay ng mga icon sa itaas ng screen, i-tap ang 📖 button. Bubuksan nito ang parehong kabanata sa Focus Mode.
3. Magtatago ang mga menu at button. Matitira lang ang teksto ng Bibliya.

Sa **Reader** mode, awtomatikong bumubukas sa Focus Mode ang mga kabanata. Nakatago ang 📖 button dahil walang Study Mode na maaaring lipatan.

## Ano ang magagawa mo sa Focus Mode

- **I-scroll** para magbasa.
- **Mag-swipe** para pumunta sa susunod o naunang kabanata.
- **I-tap ang 📖 button** sa bottom bar para bumalik sa Study Mode. (Nakatago sa Reader mode.)
- **I-tap ang 🔊 button** sa bottom bar para basahin nang malakas ang kabanata. Lilitaw ang isang maliit na control bar na may play, pause, rewind, fast-forward, at voice picker. (Nakatago sa Reader mode — nangangailangan ang TTS ng Standard o Scholar.)

## Magandang paggamit ng Focus Mode

- Pagdaanan ang isang buong aklat, isang kabanata nang sabay.
- Magbasa ng isang mahabang talata para sa devotional o quiet time.
- Magbasa nang malakas at sundan ang teksto nang walang distraksyon.

## Paglipat sa Study Mode

Itinatago ng Focus Mode ang bawat study tool, ngunit isang tap lang ang layo nila. I-tap ang 📖 button sa itaas ng screen para buksan ang parehong kabanata sa [Study Mode](theodia://help/study-mode). Ang Study Mode ang buong reader, na may commentary, cross-references, lexicon lookups, at mga note. Para malaman mo ang kayang gawin ng Study Mode, tingnan ang gabay na [Study Mode](theodia://help/study-mode).

Sa **Reader** mode, nakatago ang 📖 button dahil hindi makukuha ang Study Mode.
