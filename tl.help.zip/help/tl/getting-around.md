---
title: Mabilis na Pag-iikot sa App
level: beginner
categories: layout
summary: Bawat mabilis na paraan para tumalon sa isang bersikulo, kabanata, o screen sa Theodia.
---

# Mabilis na Pag-iikot sa App

Ang gabay na ito ay isang cheat sheet para sa navigation. Saklaw nito ang bawat mabilis na paraan para lumipat mula sa kinaroroonan mo patungo sa gusto mong puntahan.

## Tumalon nang diretso sa isang bersikulo

Ang pinakamabilis na paraan para buksan ang anumang bersikulo ay ang **Command** sa home screen.

- Mag-type ng `John 3:16` at i-tap ang Go.
- Mag-type ng `Psalms 23` at i-tap ang Go.
- Mag-type ng `Genesis 1` at i-tap ang Go.

Bubuksan ng app ang eksaktong kabanata (at i-scroll sa bersikulo kung naglagay ka ng isa).

## Mag-swipe sa pagitan ng mga kabanata

Kapag nagbabasa ka ng isang kabanata:

- **Mag-swipe pakaliwa** → susunod na kabanata.
- **Mag-swipe pakanan** → naunang kabanata.

Gumagana ito sa mga aklat. Pagkatapos ng Exodus 40, dadalhin ka ng pag-swipe pakaliwa sa Leviticus 1.

## Gamitin ang top bar

Habang nagbabasa, ipinapakita sa itaas ng screen ang kasalukuyang **pagsasalin**, **aklat**, at **kabanata**.

- I-tap ang pangalan ng pagsasalin para magpalit ng Bibliya.
- I-tap ang pangalan ng aklat para pumili ng ibang aklat.
- I-tap ang numero ng kabanata para pumili ng ibang kabanata.

## Tumalon mula sa isang bookmark

Kung naka-save ka ng isang bersikulo:

1. Buksan ang **Bookmarks** tab.
2. I-tap ang anumang entry.
3. Dadalhin ka nang diretso sa bersikulong iyon.

## Tumalon mula sa search

1. Buksan ang **Search** tab.
2. Mag-type ng salita o parirala.
3. I-tap ang anumang resulta.
4. Bubuksan ng app ang kabanata na naka-highlight ng dilaw ang mga salita sa search mo.

## Palitan ang reading layout

May dalawang layout ang Bible reader:

- **Study Mode** — ipinapakita ang kabanata na isang tap ang layo ng lahat ng study tool.
- **Focus Mode** — itinatago ang bawat tool at menu, at natitira lang ang teksto.

Para magpalit: i-tap ang **📖** button sa itaas ng screen habang nagbabasa. I-tap ulit para bumalik. (Ang Reader mode ay laging nananatili sa Focus Mode.)

## Gamitin ang mga bottom tab

Laging nakikita ang hanay ng mga icon sa ibaba ng screen. I-tap ang anumang tab para lumipat sa seksyong iyon. Nakadepende ang eksaktong mga tab sa iyong user mode:

**Lahat ng mode:**

- **Home** — balik sa home screen.
- **Bibles** — listahan ng mga pagsasalin.
- **Search** — maghanap sa Bibliya, mga aklat, dictionaries, lexicons, at mga PDF.
- **Settings** — mga kagustuhan at mga resource.

**Nakikita rin sa Standard at Scholar:**

- **Bookmarks** — mga naka-save na bersikulo.
- **Highlights** — mga bersikulong minarkahan ng kulay.
- **Notes** — ang iyong mga pribadong note.
- **PDFs** — ang mga in-import mong PDF document.

**Nakikita rin sa Scholar:**

- **AI** — ang AI assistant (kung naka-on sa Settings).

### Pag-alala kung saan ka huminto

May sariling navigation history ang bawat tab. Kapag bumalik ka sa isang tab, bumabalik ka sa **pinagkitiran mo**, hindi sa panimulang screen ng seksyong iyon.

- Binuksan mo ang **Bibles** tab, pumili ng pagsasalin, bumukas ng kabanata, tapos lumipat sa **Search**. Mamaya, i-tap muli ang **Bibles** at naroon ka ulit sa parehong kabanata.
- Binuksan mo ang **Bookmarks** tab, nag-tap ng isang bookmarked na bersikulo, tapos lumipat sa **Settings**. Ang pag-tap muli ng **Bookmarks** ay ibabalik ka sa bookmark list.

Pumapatol ito sa bawat tab. Bawat isa ay nag-aalala ng iyong lugar hanggang sa tuwirang mag-navigate ka sa ibang screen sa loob ng tab na iyon.

### Ano ang nagre-reset sa isang tab

Bumabalik lang sa root screen ang isang tab kapag:

- Nasa tab na iyon ka na at nag-tap ka muli ng parehong tab icon. Mabilis itong paraan para i-reset ito sa simula.
- Naging pilit na isinara ang app at binuksan muli.

### Mga bottom tab kumpara sa pangunahing menu

- **Mga bottom tab** — may sariling stack ang bawat tab. Ang pag-tap sa isang tab ay ibabalik ka sa pinagkitiran mo.
- **Pangunahing menu** — dinadala ka ng pag-tap sa isang item sa screen na iyon. Dropdown listahan ito, hindi isang overlay.

Halimbawa:

- Nagbabasa ka ng Juan 3. I-tap ang **Bookmarks** tab, tapos i-tap muli ang **Bibles**. Bumalik ka sa Juan 3.
- Nagbabasa ka ng Juan 3. Buksan ang menu at i-tap ang **Notes**. Suriin ang mga note mo, tapos i-tap ang **Bibles** tab para bumalik sa Juan 3.

## Mga tip

- Naalala ng home screen kung aling mga seksyon ang naka-expand o naka-collapse.
- Kung may nawawalang tab, tingnan ang iyong **user mode** sa **Settings** → **App User Mode**. Itinatago ng Reader mode ang bookmarks, highlights, notes, at AI. Itinatago ng Standard mode ang AI. Maaari ka ring kailanganing i-enable ang isang feature sa **Settings** o mag-install ng isang resource.
