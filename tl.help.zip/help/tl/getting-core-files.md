---
title: Paggakuha ng mga Karagdagang Resource
level: everyday
categories: resources
summary: Kung paano magdagdag ng mga Bibliya, commentary, aklat, at iba pang resource sa Theodia.
---

# Paggakuha ng mga Karagdagang Resource

May kasamang ilang resource ang Theodia, ngunit maaari kang magdagdag ng higit pa. Ang pinakamadaling paraan ay sa pamamagitan ng **Manage Resources** screen sa loob ng app.

## Ano ang maaaring idagdag

- **Mga Bibliya** — mas maraming pagsasalin sa iba't ibang wika
- **Mga Commentary** — mga study note na nagpapaliwanag ng mga bersikulo
- **Mga Aklat** — mga klasiko ng Kristiyano at mga reference work
- **Mga Devotional** — mga pang-araw-araw na devotional na pagbabasa
- **Mga core file** — mas malalaking data file tulad ng morphology, cross-references, at ang Marvel Interlinear Bible (MIB)

## Paano magdagdag ng mga resource mula sa loob ng app

1. Buksan ang **Settings**.
2. I-tap ang **Manage Resources**.
3. Pumili ng tab: **Core**, **Bibles**, **Commentaries**, **Books**, o **Devotionals**.
4. Mag-browse sa listahan. I-tap ang isang resource para magbasa pa tungkol dito.
5. I-tap ang checkbox para piliin ang gusto mo.
6. I-tap ang **Download** sa ibaba. Awtomatikong nai-download at nai-install ang mga file.

Kapag naka-install na, lumilitaw agad ang resource sa app. Hindi mo kailangang i-restart.

## Mga core file

Ang **Core** tab ay may mga malalaking data file na nagpapagana ng mas malalim na study feature. Kabilang dito ang:

- Morphology data (mga anyo ng salita sa orihinal na wika)
- Mga cross-reference database
- Ang Marvel Interlinear Bible (MIB)

Isang beses mo lang kailangang i-download ang mga core file. Nanatili ang mga ito sa iyong device at gumagana nang offline.

## Mga Global Bibles

Ang **Global Bibles** tab ay may mga pagsasalin ng Bibliya mula sa mas malawak na koleksyon. Kung hindi mo nakikita ang pagsasalin na gusto mo sa pangunahing **Bibles** tab, tingnan dito.

## Pamamahala ng mga naka-install na resource

Sa **Manage Resources** na pangunahing screen (hindi ang download tab), maaari mong:

- **I-enable o i-disable** ang isang resource nang hindi ito binubura. Nanatili sa iyong device ang mga naka-disable na resource ngunit nakatago sa mga menu.
- **Burahin** ang isang resource para makapagbakante ng espasyo. Maaari mong i-download muli ito mamaya.

## Pagdagdag ng sarili mong mga file

Kung mayroon kang resource file mula sa ibang lugar — isang kaibigan, ibang proyekto, o isang website — maaari mong i-import ito nang diretso:

1. Sa **Manage Resources**, i-tap ang **Import Local File**.
2. Piliin ang file mula sa iyong device.
3. Babasahin ng app ang file at idadagdag ito sa iyong library.

Tumatanggap ang app ng mga uri ng file na ito:

- `.bible` — mga pagsasalin ng Bibliya
- `.commentary` — mga commentary
- `.lexicon` — mga lexicon
- `.book` — mga aklat
- `.devotional` — mga devotional

## Pagkonekta ng custom na GitHub repository

Kung may nagpapanatili ng GitHub repository na may mga resource na tugma sa Theodia, maaari mong idagdag ito bilang custom na pinagmulan:

1. Pumunta sa **Settings → GitHub Repositories**.
2. I-tap ang **Add Repository**.
3. Ilagay ang GitHub URL (halimbawa, `https://github.com/username/repo-name`).
4. Piliin kung anong mga uri ng resource ang nilalaman ng repo (mga Bibliya, commentary, o aklat).
5. I-save ito.
6. Bumalik sa **Manage Resources**. Lilitaw ang isang bagong tab na may mga resource mula sa repo na iyon.

Kung pribado ang repository, kakailanganin mong magdagdag ng **Personal Access Token** sa **Settings → GitHub Repositories** para mabasa ito ng app.

## Paalala tungkol sa laki ng mga file

Maaaring maging malaki ang mga resource file. Maliit ang mga Bibliya kadalasan (ilang megabyte). Ang mga commentary at core file ay maaaring mas malaki nang marami (daan-daang megabyte). Mag-download sa Wi-Fi hangga't maaari.

## Buod

- Gamitin ang **Settings → Manage Resources** para mag-browse at mag-install ng mga resource.
- Binubuksan ng mga core file ang mas malalim na study tool tulad ng morphology at cross-references.
- Mag-import ng lokal na mga file kung may sarili ka.
- Magdagdag ng custom na GitHub repos kung gusto mo ng mga resource mula sa ibang pinagmulan.
