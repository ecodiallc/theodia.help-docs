---
title: Saan Magtanong
level: everyday
categories: trouble
summary: Kung paano makakuha ng tulong mula sa team at komunidad ng Theodia, at kung paano makahanap ng mga paksa ng tulong sa loob ng app.
---

# Saan Magtanong

Kung naiwan ka, may ilang lugar para humingi ng tulong.

## Paghahanap ng paksa ng tulong

Kung naghahanap ka ng impormasyon tungkol sa isang partikular na feature, sumubok ng isa sa mga landas na ito:

- **Mag-browse ayon sa kategorya.** Buksan ang **Help & Guides** at i-tap ang isang kategorya tulad ng **Settings & Customization** o **Troubleshooting**. May listahan ng mga kaugnay na gabay ang bawat card.
- **Maghanap ayon sa keyword.** Sa **Help & Guides** na pangunahing screen, mag-type ng isang salita sa search box sa itaas. Halimbawa, ang pag-type ng `notifications` ay ipapakita ang gabay na [Mga Notification at Reminder](theodia://help/notifications); ang pag-type ng `search` ay ipapakita ang gabay na [Paghahanap sa Bibliya](theodia://help/search-the-bible).
- **Tingnan muna ang Settings.** Maraming feature ang naka-configure sa **Settings**. Kung gusto mong mag-set up ng mga reminder, buksan ang **Settings** → **Notifications**. May **Help** link din ang settings screen para sa bawat seksyon.

## Sa loob ng app

Buksan ang **About** screen. Makakakita ka ng dalawang button:

- **Submit Suggestion / Issue** — bumubukas ng isang form para magpadala sa team ng isang tanong, ideya, o bug report.
- **Discussion / Feedback** — bumubukas ng community discussion board.

## Ang GitHub page

Makikita mo sa [GitHub](https://github.com/ecodiallc/theodia.app) ang listahan ng mga kilalang isyu at mga kamakailang pagbabago.

## Usapang komunidad

Ang ibang mga taong gumagamit ng Theodia ay nagtatanong at nagbabahagi ng mga tip sa [community discussion board](https://github.com/ecodiallc/theodia.app/discussions). Maaari kang magbasa ng mga lumang thread at magsimula ng bago.

## Bago ka magtanong

May ilang bagay na tutulong sa amin na masagap ka nang mas mabilis:

- **Ano ang iyong device?** (hal. iPhone 13, Pixel 7)
- **Anong bersyon ng app?** (Buksan ang **About** para makita.)
- **Ano ang ginawa mo?** Isang maikling paglalarawan ng mga hakbang.
- **Ano ang nangyari?** Ang nakita mo sa screen.
- **Ano ang inaasahan mong mangyari?** Kadalasan ito ang pinakapakikipakinabang na bahagi.

## Ano ang aasahan

- Para sa mga bug report, kadalasang sumasagot ang team sa loob ng ilang araw.
- Para sa mga ideya, binabasa ng team ang lahat. Hindi kami maaaring mangako kung kailan idadagdag ang isang ideya.
- Para sa mga tanong sa komunidad, kadalasang mas mabilis sumagot ang ibang mga gumagamit kaysa sa team.

## Paalala tungkol sa privacy

Kapag nagsumite ka ng isang tanong, pakiusap huwag maglagay ng pribadong impormasyon. Nakikita ng team ang ipinapadala mo.
