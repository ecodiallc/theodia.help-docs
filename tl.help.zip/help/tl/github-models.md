---
title: GitHub Models
categories: ai
level: advanced
summary: I-set up ang GitHub Models — isang libreng paraan para magsimulang saliksikin ang AI sa Theodia nang walang umiiral na API subscription.
---

# GitHub Models

> **Mode:** Kailangan ng AI assistant ang **Scholar** mode. Maaari mong palitan ang mode sa **Settings** → **App User Mode**.

Kung hindi ka pa nagbabayad para sa isang AI service, ang **GitHub Models** ang pinakamadaling paraan para magsimulang saliksikin ang AI ng Theodia. Nagbibigay ito ng libreng paraan para magsimula, at ang kailangan mo lang ay isang libreng GitHub account.

## Ano ang GitHub Models?

Ang GitHub Models ay isang serbisyo mula sa GitHub na nagpapahintulot sa iyo na patakbuhin ang mga modernong AI model sa pamamagitan ng isang API. Sinusuportahan nito ang parehong format ng OpenAI, kaya maayos itong gumagana sa Theodia.

## Bakit pipiliin ang GitHub Models?

- **Hindi kailangan ng credit card** — Isang GitHub account lang.
- **Mataas na kalidad na mga model** — Makakakuha ka ng access sa GPT-4o, GPT-4.1, at iba pang maaasahang model na sumusuporta sa mga tool ng Theodia.
- **Madaling set up** — Isang token, isang URL, at tapos ka na.

## Hakbang 1: Gumawa ng GitHub account

Kung mayroon ka nang GitHub account, lumaktaw sa Hakbang 2.

1. Pumunta sa [github.com](https://github.com).
2. I-tap ang **Sign up** at sundin ang mga prompt para gumawa ng libreng account.
3. I-verify ang iyong email address kapag nagpadala si GitHub ng kumpirmasyon.

## Hakbang 2: Gumawa ng Personal Access Token

Ang token na ito ang iyong API key. Sinasabi nito sa GitHub kung sino ka kapag nagpapadala ng mga tanong ang Theodia.

1. Pumunta sa [github.com/settings/tokens](https://github.com/settings/tokens).
2. I-tap ang **Generate new token** at piliin ang **Generate new token (classic)**.
3. Bigyan ang token ng pangalan tulad ng **Theodia AI**.
4. Sa ilalim ng **Select scopes**, lagyan ng tsek ang box para sa **`models:read`**.
   - Ito lang ang pahintulot na kailangan ng Theodia.
5. I-scroll sa pinakaibaba at i-tap ang **Generate token**.
6. **Kopyahin agad ang token.** Ipapakita lang ito ni GitHub nang minsan. I-paste ito sa isang ligtas na lugar (tulad ng notes app ng iyong telepono) hanggang sa idagdag mo ito sa Theodia.

## Hakbang 3: Pumili ng model

Nag-aalok ang GitHub Models ng ilang model. Para sa Theodia, ito ang pinakamagagandang opsyon:

| Model                 | Daily Free Limit   | Pinakamainam Para Sa                          |
| --------------------- | ------------------ | --------------------------------------------- |
| `openai/gpt-4.1-nano` | 150 request / araw | Mabilisang mga tanong at simpleng paliwanag ng bersikulo |
| `openai/gpt-4.1-mini` | 150 request / araw | Pangkalahatang pag-aaral na may magandang suporta sa tool |
| `openai/gpt-4.1`      | 50 request / araw  | Mas malalim na pag-aaral at mga kumplikadong multi-step na tanong |
| `openai/gpt-4o`       | 50 request / araw  | Magaling sa lahat, napakahusay na suporta sa tool |

Magsimula sa **`openai/gpt-4.1-mini`** — mabilis ito, maaasahan, at may mas mataas na daily request limit.

## Hakbang 4: I-configure ang Theodia

1. Buksan ang **Theodia**.
2. Pumunta sa **Settings** → **AI Assistant**.
3. Siguraduhing napili ang **Remote model**.
4. I-tap ang **Provider** dropdown at piliin ang **GitHub Models**.
   - Kung wala sa listahan ang GitHub Models, i-tap ang **Custom** at maglagay nang mano-mano ng base URL: `https://models.github.ai`
5. I-paste ang iyong GitHub Personal Access Token sa **API Key** field.
6. Ilagay ang napili mong model ID sa **Model** field (halimbawa: `openai/gpt-4.1-mini`).
7. I-tap ang **Test connection**.
8. Hintayin matapos ang pagsusuri. Dapat mong makita:
   - **✓ Connection successful**
   - **✓ Tools supported**

Kung makikita mo ang **✗ Tools not supported**, sumubok ng ibang model ID mula sa table sa itaas.

## Hakbang 5: Simulang mag-chat

1. I-tap ang **AI** tab sa ibaba ng screen.
2. Mag-type ng isang tanong at i-tap ang **Send**.
3. O, habang nagbabasa ng anumang kabanata ng Bibliya, i-tap ang numero ng isang bersikulo at piliin ang **AI Commentary** para magsimula ng chat na nakatuon sa bersikulo.

## Pag-aayos ng mga problema

### "Connection failed" o "HTTP 401"

- Siguraduhing nakopya mo ang **buong** token. Mahabang string ito na nagsisimula sa `ghp_`.
- Nag-e-expire ang mga token kung hindi ginagamit nang matagal. Bumalik sa GitHub at gumawa ng bago.
- Suriin na napili mo ang **models:read** noong ginawa ang token.

### "Tools not supported"

- May ilang model sa GitHub Models na hindi tumatanggap ng mga tool call. Sumubok sa halip na **`openai/gpt-4o`** o **`openai/gpt-4.1-mini`**.
- Siguraduhing eksaktong baybay ng model ID ang ipinakita, kabilang ang `openai/` prefix.

### Mga error sa rate limit

- Kung naabot mo ang daily limit, lumipat sa isang model na may mas malaking alokasyon (tulad ng `openai/gpt-4.1-nano` sa 150 request kada araw).
- Na-re-reset ang mga limitasyon bawat 24 oras.

## Buod

- Ang GitHub Models ang **inirerekomendang paraan para magsimulang saliksikin ang AI** sa Theodia.
- Kailangan mo ng **libreng GitHub account** at isang **Personal Access Token** na may `models:read`.
- Ang pinakamagandang panimulang model ay ang **`openai/gpt-4.1-mini`**.
- Ilagay ang token at model sa **Settings → AI Assistant**, i-tap ang **Test connection**, at simulang mag-chat.
