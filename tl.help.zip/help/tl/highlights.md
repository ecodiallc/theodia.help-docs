---
title: Pag-highlight ng mga Bersikulo
level: everyday
categories: [annotate, read]
summary: Kung paano markahan ng kulay ang mga bersikulo at hanapin ang mga ito mamaya.
---

# Pag-highlight ng mga Bersikulo

> **Mode:** Makukuha ang highlights sa **Standard** at **Scholar** mode. Ang Focus Mode ay para lang sa malinis at walang distraksyon na pagbabasa. Maaari mong palitan ang mode sa **Settings** → **App User Mode**.

Minamarkahan ng pag-highlight ang isang bersikulo ng isang kulay. Gumagana ito na parang dilaw na highlighter sa papel. Mananatiling naka-highlight ang bersikulo sa susunod mong buksan ito.

## Paano i-highlight ang isang bersikulo

1. Buksan ang bersikulo.
2. I-tap ang bersikulo para lumabas ang menu.
3. I-tap ang **Highlight** icon.
4. Pumili ng kulay.

Naka-highlight na ngayon ang bersikulo sa kulay na iyon.

## Paano palitan ang kulay ng highlight

1. Buksan ang bersikulo.
2. I-tap ang bersikulo, tapos i-tap ang **Highlight** icon.
3. Pumili ng bagong kulay.

## Paano mag-alis ng highlight

1. Buksan ang bersikulo.
2. I-tap ang bersikulo, tapos i-tap ang **Highlight** sa menu.
3. I-tap ang **Remove Highlight** sa ilalim ng color picker.

## Isang karaniwang paraan ng paggamit ng mga kulay

Gumagamit ang maraming mambabasa ng maliit na set ng mga kulay para sa maliit na set ng mga layunin:

- **Dilaw** para sa mga pangkalahatang paborito.
- **Berde** para sa mga bersikulo tungkol sa Diyos.
- **Asul** para sa mga bersikulo tungkol sa panalangin.
- **Rosas** para sa mga bersikulo tungkol sa kaaliw-aliw.
- **Kahel** para sa mga bersikulo tungkol sa babala o pagtutuwid.
- **Lila** para sa mga bersikulo tungkol sa propesiya o huling mga araw.

Pumili ng sistema na tumutugma sa iyo.

## Paano makita ang lahat ng highlights mo

I-tap ang **Highlights** tab sa ibaba. Makikita mo ang listahan ng bawat bersikulo na na-highlight mo, pinakabago muna. May isang hanay ng mga color chip sa itaas — i-tap ang isang kulay para ipakita lang ang mga highlight ng kulay na iyon, o i-tap ang **All** para alisin ang filter.

## Pag-import ng mga highlight

Maaari mong dalhin sa Theodia ang mga highlight mula sa ibang app at file.

Pumunta sa **Settings** → **Bookmarks** → **Import Highlights**. Piliin ang **Import from File** o mag-paste mula sa clipboard. Awtomatikong nakikilala ng app ang format.

### Mga suportadong format

**Native JSON export** — Ang format na ginagamit ng sariling export feature ng Theodia:

```json
{
  "/bible/KJV/John/3#v3_16": "yellow",
  "/bible/KJV/Genesis/1#v1_1": "green"
}
```

**CSV** — Isang spreadsheet na may `url` at `color` column. Halimbawa:

```csv
url,color
/bible/KJV/John/3#v3_16,yellow
/bible/KJV/Genesis/1#v1_1,green
```

**Plain text** — Ang bawat linya ay isang sanggunian sa Bibliya o URL, na sinundan nang opsyonal ng isang pangalan ng kulay. Halimbawa:

```
John 3:16 yellow
Genesis 1:1 green
Matthew 5:1
```

- Mga makukuhang kulay: `yellow`, `green`, `blue`, `pink`, `orange`, `purple`.
- Kung walang ibinigay na kulay, dilaw ang default ng highlight.
- Ang mga linyang nagsisimula sa `#` o `//` ay itinuturing na mga komento at linalaktawan.

## Mga tip

- Nanatili sa iyong device ang mga highlight. Hindi sila nag-se-sync sa cloud.
- Maaari mong i-highlight ang isang bersikulo sa isang pagsasalin at ito ay lilitaw sa iba mo pang mga pagsasalin ng parehong bersikulo.
- Tingnan ang gabay na [Pag-back Up ng Iyong Data](theodia://help/backups) para panatilihing ligtas ang mga ito.
