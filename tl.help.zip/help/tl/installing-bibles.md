---
title: Pag-install ng mga Salin ng Biblia
level: beginner
categories: start
summary: Kung paano magdagdag ng salin ng Biblia sa iyong library.
---

# Pag-install ng mga Salin ng Biblia

May kasamang ilang salin ng Biblia ang Theodia na handa nang basahin. Maaari kang magdagdag pa anumang oras. Ang "salin" ay ibang bersyon ng tekstong Biblia, tulad ng King James Version.

## Paano magdagdag ng salin

Ipinapakita ng Bible tab ang listahan ng mga salin na naka-install na. Para magdagdag pa, buksan ang resource manager:

1. Buksan ang **Settings**.
2. I-tap ang **Manage Resources**.
3. I-tap ang **Install from GitHub**.
4. Sa download modal, i-tap ang **Bibles** tab.
5. I-tap ang checkbox sa tabi ng bawat salin na gusto mo.
6. I-tap ang **Install Selected** sa ibaba.
7. Hintayin matapos ang download.

Nasa library mo na ang salin. Para makita ito, buksan ang **Bible** tab.

## Paano magpalit ng salin

1. Buksan ang kabanata na gusto mong basahin.
2. I-tap ang pangalan ng salin sa itaas ng screen.
3. Piliin ang gusto mo sa listahan.

Sine-save ng app ang pinili mo para sa susunod.

## Paano mag-alis ng salin

1. Buksan ang **Settings**.
2. I-tap ang **Manage Resources**.
3. Hanapin ang salin na gusto mong alisin.
4. I-tap ang **X** sa tabi nito.
5. Kumpirmahing gusto mo itong alisin.

Ang pag-alis ng salin ay hindi nagbubura ng iyong mga note, highlight, o bookmark. Mananatiling ligtas ang mga iyon.

## Magkano ang espasyo ng mga salin?

Karamihan sa mga salin ay nasa pagitan ng 2 at 10 MB. Naka-store ang mga ito sa iyong device, hindi sa cloud. Maaari kang mag-ipon ng kahit ilan, basta may sapat na espasyo ang device mo.

## Paano kung wala ang salin sa app?

May mga salin na wala sa listahan sa loob ng app. Maaari mo pa ring idagdag ang mga ito.

1. Buksan ang app at pumunta sa **Settings** → **Manage Resources**.
2. I-tap ang **Install from GitHub**.
3. Sa download modal, tingnan ang **Bibles** tab at ang **Global Bibles** tab. Kung nandoon ang salin mo, piliin ito at i-tap ang **Install Selected**.
4. Kung wala, i-tap ang **Install Local File** para mag-import ng `.bible` file. Kunin ang file sa GitHub page ng proyekto. Tingnan ang gabay na [Pagkuha ng Ibang Resources mula sa GitHub](theodia://help/getting-core-files) para sa hakbang-hakbang na tulong.
