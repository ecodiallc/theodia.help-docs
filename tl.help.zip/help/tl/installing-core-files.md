---
title: Pagdagdag ng mga Core File
level: beginner
categories: start
summary: Kung paano i-download ang malalaking data file na kailangan ng app para sa malalim na pag-aaral ng Biblia.
---

# Pagdagdag ng mga Core File

May kasamang Biblia at ilang maliliit na extra ang Theodia na handa nang gamitin. Para mapakinabangan nang buo ang app, kailangan mo ring i-download ang **mga core file**. Ito ay malalaking data file na nagdaragdag ng mga study tool tulad ng commentary, word lookup, at grammar notes. Kapag wala ang mga ito, gumagana pa rin ang app, pero limitado ang mga study feature.

## Bakit kailangan mo ang mga core file

Nagdaragdag ang mga core file ng:

- **Word lookup.** I-tap ang isang salita sa kahit anong bersikulo para makita ang orihinal na Ebreo o Griyego at ang kahulugan nito.
- **Commentary.** AI Commentary sa bawat bersikulo.
- **Grammar.** Impormasyon tungkol sa bawat salita sa orihinal na wika.
- **Interlinear Bible.** Basahin ang tekstong orihinal na wika na may salin sa Ingles sa ilalim ng bawat salita.

Maaari kang magbasa ng Biblia kahit wala ang mga ito, pero karamihan sa mga study tool ay nangangailangan ng mga ito.

## Paano i-install ang mga core file

**[I-install ang mga Core File](theodia://manage/core)**

1. Buksan ang **Settings**.
2. I-tap ang **Manage Resources**.
3. Bubukas ang **Core** tab. Makikita mo ang listahan ng mga core file. May pangalan, laki, at checkbox ang bawat isa.
4. I-tap ang bawat file na gusto mong i-install. Ang check mark ay nagsasabing napili na ito.
5. I-tap ang **Install Selected**.
6. Hintayin matapos ang pag-download at pag-install ng mga file. Malaki ang mga ito, kaya maaaring tumagal ng ilang minuto sa mabagal na koneksyon.

Nagda-download ang mga file sa iyong device. Isang beses mo lang itong kailangang gawin. Gagamitin na ng app ang mga file mula noon, kahit offline ka.

## Mga tip

- Gumamit ng Wi-Fi. Malaki ang mga file.
- Isaksak ang iyong telepono o tablet. Gumagamit ng baterya ang malalaking download.
- Kung nabigo ang isang download, i-tap muli ang file para subukan ulit.
- Maaari mong i-install ang lahat, o kung alin lang ang kailangan mo.

## Paano kung may file na wala sa listahan?

Kinukuha ng app ang listahan mula sa GitHub page ng proyekto. Kung walang laman ang listahan, i-check ang iyong internet connection at subukan ulit. Kung walang laman pa rin, tingnan ang gabay na [Saan Magtanong](theodia://help/getting-more-help).

Para sa mas advanced na paraan ng pagdaragdag ng resources, tingnan ang gabay na [Pagkuha ng Ibang Resources mula sa GitHub](theodia://help/getting-core-files).
