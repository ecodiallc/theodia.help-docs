---
title: Wika at Rehiyon ng App
level: everyday
categories: settings
summary: Kung paano palitan ang wika ng app.
---

# Wika at Rehiyon ng App

Available ang Theodia sa maraming wika. Maaaring palitan ng app ang wika ng mga menu at button. Available rin ang nilalaman ng tulong sa marami sa mga wikang ito at built in na sa app. Maaari ka ring mag-download o mag-update ng help pack ng isang wika — buksan ang **Settings** → **Help** o **Manage Resources** → **Install from GitHub** → **Help docs**.

## Paano buksan ang mga setting ng wika

1. Buksan ang **Settings**.
2. I-tap ang **Language**.

## Paano palitan ang wika ng app

1. Sa listahan ng **Language**, i-tap ang wikang gusto mo.
2. Agad inilalapat ng app ang bagong wika.

Depende sa mga wikang sinusuportahan ng app ang mga pagpipilian na makikita mo.

## Paano pinipili ang wika sa unang pag-install

Sa unang pag-install mo ng Theodia, pumipili ang app ng wika batay sa mga setting ng iyong device. Maaari mo itong palitan anumang oras.

## Ano ang isinalin

- Mga menu, button, at label.
- Mga screen ng Settings.
- Mga mensahe ng error.
- Mga tool sa paghahanap at pag-aaral.

## Ano ang nasa Ingles lamang

- Ilang nilalaman ng libro at devotional.

## Mga salin ng Biblia at wika ng app

Magkaiba ang wika ng app at ang wika ng salin ng Biblia. Maaaring naka-Espanyol ang app at naka-Ingles ang Biblia, o kabaliktaran.

Para palitan ang salin ng Biblia, tingnan ang gabay na [Pag-install ng mga Salin ng Biblia](theodia://help/installing-bibles).

## Mga tip

- Kung walang laman ang isang button o label, may kulang na salin ang app. Karaniwang nandoon bilang fallback ang bersyong Ingles.
- Kung gusto mong tumulong sa pagsasalin ng app, tingnan ang gabay na [Saan Magtanong](theodia://help/getting-more-help).
