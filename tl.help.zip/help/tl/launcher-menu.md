---
title: Ang Launcher Menu
level: everyday
categories: layout
summary: Mabilis na paraan para tumalon sa mga kamakailang bersikulo, magpatakbo ng mga command, at magpalit ng Bible layout nang hindi umaalis sa screen mo.
---

# Ang Launcher Menu

> **Mode:** Kailangan ng Launcher Menu ang **Scholar** mode. Maaari kang magpalit ng mode sa **Settings** → **App User Mode**.

Ang Launcher Menu ay isang mabilis na panel na maaari mong buksan mula sa halos kahit saang bahagi ng app. Nasa isang lugar dito ang iyong mga kamakailang bersikulo, mga command, at mga na-save na Bible setup.

## Paano ito buksan

I-tap ang **expand icon (⌄)** sa kanang sulok sa itaas ng header ng home screen. Mulas-slide pababa ang isang panel mula sa itaas.

## Ano ang nasa loob

### 1. Command Box

Sa itaas ng panel ay may text box na may keyboard icon. Mag-type ng command at i-tap ang **Go** sa keyboard mo. Binabasa ng app ang command at dinadala ka nang diretso roon.

Mga halimbawa:

- `John 3:16` — binubuksan ang bersikulong iyon.
- `search love` — hinahanap sa Biblia ang "love".
- `bookmark psalms 23` — ini-bookmark ang bersikulo.
- `kjv` — nagpapalit sa KJV translation.

Para sa buong listahan ng mga command, tingnan ang gabay na [Mga Command](theodia://help/commands).

### 2. Parallel Sets

Kung may mga na-save kang parallel Bible preset, lalabas ang mga ito dito bilang collapsible list. I-tap ang isa para agarang i-load ang parallel setup na iyon.

Para gumawa ng parallel preset:

1. Buksan ang **Settings** → **Parallel Bible**.
2. Magdagdag ng mga salin at i-tap ang **Save Preset**.
3. Bigyan ito ng pangalan. Lalabas ito sa Launcher Menu.

Pindutin nang matagal ang isang parallel set sa Launcher Menu para burahin ito.

### 3. Bible Collections

Ang mga Bible Collection ay mga shortcut na isang tap lang na sabay na nagpapalit ng iyong translation at parallel view. Kung may mga nagawa ka na, lalabas ang mga ito dito bilang collapsible list.

Pindutin nang matagal ang isang collection para burahin ito.

### 4. Mga Feature Icon

Sa ibaba ng command box maaari mong makita ang isang hanay ng mga bilugang emoji button. Mga shortcut na isang tap lang ang mga ito papunta sa mga pangunahing feature ng app.

Kasama sa mga available icon ang:

- **About**, **Bibles**, **Bible Notes**, **Bookmarks**, **Books**
- **Devotionals**, **Flashcards**, **Help**, **Highlights**
- **Playlists**, **Plugins**, **Search**, **Settings**, **Theoscript**

Para piliin kung aling icon ang lalabas at ano ang pagkakasunod-sunod:

1. Buksan ang **Settings** → **Launcher Menu**.
2. I-tap ang **Launcher Menu Icons**.
3. Gamitin ang mga switch para ipakita o itago ang bawat icon.
4. Gamitin ang mga arrow na pataas/pababa para ayusin ang pagkakasunod-sunod ng mga pinagana mo.

Ang pagkakasunod-sunod sa settings ay siyang pagkakasunod-sunod nila sa Launcher Menu.

### 5. Mga Kamakailang Bersikulo

Naaalala ng app ang mga huling kabanata at bersikulo na binuksan mo. Lumalabas ang mga ito bilang listahan sa ibaba ng panel. I-tap ang kahit aling entry para tumalon nang diretso roon.

- **I-tap** para buksan.
- **Swipe pakaliwa** o **pindutin nang matagal** para alisin sa listahan.
- I-tap ang **Clear all** para alisin lahat ng entry nang sabay-sabay.

## Kailan gagamitin ang Launcher Menu

Gamitin ito kapag gusto mong:

- Bumalik sa bersikulong kakabasa mo lang.
- Mag-type ng command nang hindi dumadaan sa home screen.
- Magpalit ng translation o parallel setup sa isang tap lang.
- Buksan ang isang pangunahing feature mula sa kahit saang bahagi ng app.
- Tingnan ang isang bagay nang mabilis nang hindi nagdidikitan sa mga menu.

## Mga tip

- Available ang Launcher Menu sa halos bawat screen, kaya maaari mo itong buksan habang nagbabasa ng kabanata.
- Sinusuportahan ng command box ang parehong mga command tulad ng command box sa home screen.
- Naka-save nang lokal sa iyong device ang mga feature icon at ang pagkakasunod-sunod nila. Nanatili ang mga ito kahit i-restart ang app.
- Naka-save nang lokal sa iyong device ang mga kamakailang bersikulo. Nanatili ang mga ito kahit i-restart ang app.
