---
title: Paglipat sa mga Libro, Kabanata, at Bersikulo
level: everyday
categories: [layout, read]
summary: Kung paano maglibot sa Biblia at tumalon sa pupuntahan mo.
---

# Paglipat sa mga Libro, Kabanata, at Bersikulo

Ipinapakita ng gabay na ito lahat ng paraan para maglibot sa Biblia.

## Ang madaling paraan: swipe

- Mag-swipe **pakaliwa** sa isang kabanata para pumunta sa susunod na kabanata.
- Mag-swipe **pakanan** para bumalik.
- Gumagana rin ito para sa susunod na libro. Pagkatapos ng huling kabanata ng, halimbawa, Exodus, dadalhin ka ng swipe sa unang kabanata ng Leviticus.

## Ang paraan gamit ang menu

- I-tap ang pangalan ng salin sa itaas para magpalit ng ibang Biblia.
- I-tap ang pangalan ng libro sa itaas para pumili ng ibang libro.
- I-tap ang numero ng kabanata para pumili ng ibang kabanata.

## Ang mabilis na paraan: mag-type

- Sa home page, may isang kahon sa itaas. Mag-type ng reference, tulad ng `John 3:16` o `psalms 23`, at i-tap ang **Go** key sa keyboard.
- Binubuksan ng app ang bersikulo.

## Ang paraan gamit ang bookmark

Kung may na-save kang bersikulo, buksan ang **Bookmarks** tab. I-tap ang kahit aling entry para tumalon roon.

## Ang paraan gamit ang search

I-tap ang **Search** tab. Mag-type ng isang salita. Ipinapakita ng app ang bawat bersikulong mayroon nito. I-tap ang kahit aling resulta para buksan ito.

## Ang paraan gamit ang history

Naaalala ng app ang mga kabanatang binuksan mo. Para mahanap mo ulit ang mga ito, tingnan ang **Bookmarks** tab (para sa mga bersikulong na-save mo) o i-scroll ang listahan ng mga libro sa **Bible** tab para hanapin ang librong kababasa mo lang.

## Mga tip

- Ipinapakita ng Bible tab ang mga libro ayon sa pagkakasunod-sunod mula Genesis hanggang Revelation.
- Para sa Psalms, Proverbs, at iba pang mahahabang libro, i-tap ang libro at gamitin ang listahan ng mga kabanata para tumalon nang malayo.
