---
title: Layout at Pag-navigate sa App
level: beginner
categories: layout
summary: Isang paglilibot sa home screen, pangunahing menu, at toolbar sa ibaba — kung saan matatagpuan ang bawat bagay.
---

# Layout at Pag-navigate sa App

May tatlong pangunahing bahagi ang Theodia na maaari mong paglipatan: ang **home screen**, ang **pangunahing menu**, at ang **toolbar sa ibaba**. Dinadaanan ng gabay na ito ang bawat isa para laging alam mo kung saan pupunta.

## Mabilisang mapa

- Ang **home screen** ang page na makikita mo kapag unang binuksan ang app. May search box ito, malalaking button para sa bawat bahagi ng app, at listahan ng mga na-install mong Biblia, libro, at devotional.
- Ang **toolbar sa ibaba** (tinatawag ding tab bar) ang hanay ng mga icon sa ibaba ng screen. I-tap ang kahit alin para tumalon nang diretso sa bahaging iyon ng app.
- Ang **pangunahing menu** ang icon na may tatlong linya (☰) sa kanang sulok sa itaas ng home screen. I-tap ito para buksan ang listahan ng bawat screen sa app, kabilang ang mga walang sariling tab.

## Ang home screen

Kapag unang binuksan ang Theodia, napupunta ka sa home screen. Nahahati ito sa apat na bahagi, mula itaas pababa.

### Ang header

Sa pinaka-itaas ay may kulay na bar. Sa kaliwa ay ang app icon at ang pangalang "Theodia." Sa kanan ay ang pangunahing menu button (☰). Kapag nasa loob ka ng libro o kabanata, nasa kaliwa ang back button (←) sa halip. I-tap ang pangunahing menu para buksan ang menu (tingnan sa ibaba).

### Ang Command

Sa ibaba mismo ng header ay may text box na kamukha ng search, na may label na **Command**. Mag-type ng maikling utos at i-tap ang go key sa keyboard mo. Binabasa ng app ang utos at dinadala ka sa tamang screen. Mga halimbawa:

- `psalms 23` — binubuksan ang Psalms kabanata 23
- `john 3:16` — binubuksan ang John 3:16
- `search love` — hinahanap sa Biblia ang "love"
- `bookmark john 3:16` — sine-save ang John 3:16 bilang bookmark
- `commentary romans 8:28` — binubuksan ang commentary para sa bersikulong iyon
- `xref` (sinusundan ng reference) — binubuksan ang mga cross-reference para sa bersikulong iyon
- `help` — binubuksan ang listahan ng mga command na may mga halimbawa

Kung hindi maintindihan ng app ang type mo, may maliit na alert na may pahiwatig ang lalabas. Tingnan ang gabay na **Common Problems** kung hindi gumagana ang mga command.

### Ang button grid

Sa ibaba ng Command ay may grid ng malalaking button, dalawa kada hanay. Dinadala ka ng bawat button sa ibang bahagi ng app. Ang mga button ay:

- 📖 **Bibles** — ang listahan mo ng mga salin ng Biblia
- 🔍 **Search** — maghanap sa Biblia ng salita o parirala
- 📚 **Books** — ang library mo ng mga klasikong Kristiyano
- 📅 **Devotionals** — mga araw-araw na devotional
- 🔖 **Bookmarks** — ang mga na-save mong bersikulo at kabanata
- 🖍 **Highlights** — ang mga bersikulong minarkahan mo ng kulay
- 📝 **Notes** — ang mga pribadong note mo sa mga bersikulo
- ⚙️ **Settings** — wika, tema, resources, at iba pa
- ❓ **Help** — ang sistema ng tulong (ang page na ito)
- ℹ️ **About** — bersyon ng app at mga kredit

### Ang mga listahan ng resources

Sa ibaba ng button grid ay ang mga expandable section: **Bibles**, **Books**, at **Devotionals**. Ipinapakita ng bawat section ang mga item na na-install mo. I-tap ang header ng isang section para palakihin o paliitin ito. I-tap ang kahit aling item sa isang section para buksan ito.

Ang Bibles section ang pinakamabilis na paraan para tumalon sa isang partikular na salin — walang menu, tap lang.

## Ang toolbar sa ibaba

Ang toolbar sa ibaba (tab bar) ay ang hanay ng mga icon sa ibaba ng screen. Halos laging nakikita ito sa buong app, kaya maaari kang laging tumalon sa ibang section. Depende sa user mode mo ang mga tab na makikita mo.

**Nakikita ng lahat ng mode:**

- 🏠 **Home** — binubuksan ang home screen
- 📖 **Bibles** — binubuksan ang listahan mo ng mga salin ng Biblia
- 📚 **Books** — binubuksan ang library mo ng mga libro
- 🔍 **Search** — binubuksan ang paghahanap sa Biblia
- ⚙️ **Settings** — binubuksan ang mga setting

**Nakikita rin ng Standard at Scholar mode:**

- 🔖 **Bookmarks** — binubuksan ang mga na-save mong bersikulo
- 🖍 **Highlights** — binubuksan ang mga bersikulong minarkahan mo ng kulay
- 📝 **Notes** — binubuksan ang mga pribadong note mo

**Nakikita rin ng Scholar mode:**

- 💻 **AI** — binubuksan ang AI assistant (kung naka-on mo ito sa Settings)

Naka-highlight ang kasalukuyang tab. I-tap ang kahit aling ibang tab para magpalit.

### Paano kumikilos ang toolbar

May sariling **stack** ng mga screen ang bawat tab sa toolbar. Kapag nag-tap ka ng tab, babalik ka sa **kung saan ka huminto** sa stack ng tab na iyon, hindi sa panimulang screen. Halimbawa:

- I-tap ang **Bibles** → makikita mo ang listahan ng mga salin ng Biblia.
- I-tap ang isang salin → makikita mo ang listahan ng mga libro.
- I-tap ang isang libro → makikita mo ang listahan ng mga kabanata.
- I-tap ang isang kabanata → binabasa mo na ang kabanata.
- Magpalit sa **Bookmarks** para tingnan ang isang bagay.
- I-tap ulit ang **Bibles** → bumalik ka sa kabanatang binabasa mo.

Naaalala ng bawat tab ang lugar mo. Pinapanatili ng app ang iyong navigation history sa loob ng bawat tab, kaya hindi nawawala ang pag-unlad mo kapag nagpalit-palit ka ng tab.

### Ano ang nagre-reset sa isang tab

Nagre-reset lang ang isang tab sa root screen nito kapag:

- Nasa tab ka na iyon at nag-tap ka ulit ng parehong tab icon. Mabilis itong paraan para bumalik sa simula.
- Isinara nang pwersahan ang app at binuksan ulit.

### Mga tab sa ibaba vs. ang pangunahing menu

- **Mga tab sa ibaba** — may sariling stack na naaalala ang bawat tab. Kapag nag-tap ka ng tab, babalik ka sa kung saan ka huminto.
- **Pangunahing menu** — kapag nag-tap ka ng item, pupunta ka sa screen na iyon gamit ang parehong sistema ng tab. Hindi ito bumubukas bilang overlay.

Gamitin ang mga tab para magpalit ng gawain. Gamitin ang pangunahing menu kapag gusto mo ang buong listahan ng bawat screen sa app.

### Kailan gagamitin ang toolbar

Gamitin ang toolbar kapag gusto mong magpalit ng ginagawa:

- Nagbabasa ka ng kabanata at gusto mong maghanap ng iba → i-tap ang **Search**.
- Naghahanap ka at gusto mong tingnan ang mga bookmark mo → i-tap ang **Bookmarks**.
- Kahit saan ka sa app at gusto mong umuwi → i-tap ang **Home**.

## Ang pangunahing menu

Ang pangunahing menu ay ang button na may tatlong nakapiling linya (☰) sa kanang sulok sa itaas ng home screen. I-tap ito at mula-slide-in ang isang panel mula sa kanang bahagi. Ipinapakita ng panel ang bawat screen na sinusuportahan ng kasalukuyan mong mode:

- 🏠 **Home**
- 📖 **Bibles**
- 📚 **Books**
- 🙏 **Devotionals**
- 🔍 **Search**
- 🔖 **Bookmarks** (Standard at Scholar)
- 🖍 **Highlights** (Standard at Scholar)
- 📝 **Notes** (Standard at Scholar)
- 💻 **AI Assistant** (Scholar lang, at kung naka-on ang AI)
- ⚙️ **Settings**
- ❓ **Help**
- ℹ️ **About**

Naka-highlight ang item na katumbas ng screen na kinaroroonan mo ngayon at may maliit na tuldok sa tabi nito. I-tap ang kahit aling item para tumalon nang diretso roon. I-tap ang labas ng panel, ang X sa itaas, o ang back button ng device mo para isara ito nang hindi nagpapalit ng screen.

### Paano naiiba ang pangunahing menu

Ang pangunahing menu ay isang dropdown panel, hindi hiwalay na layer ng navigation. Kapag nag-tap ka ng item, pupunta ang app sa screen na iyon sa parehong paraan kung paano kung ginamit mo ang tab sa ibaba o button grid. Napapanatili ang stack ng kasalukuyan mong tab, kaya maaari kang bumalik sa kung saan ka nagtapos sa pamamagitan ng pag-tap ulit sa orihinal na tab.

Halimbawa:

- Binabasa mo ang John 3. Nag-tap ka ng **Bookmarks** tab. Pumunta ka sa mga bookmark mo. Kapag nag-tap ka ulit ng **Bibles**, babalik ka sa John 3 — kung saan ka huminto.
- Binabasa mo ang John 3. Binuksan mo ang pangunahing menu at nag-tap ng **Notes**. Bumukas ang mga note mo. Para bumalik sa John 3, i-tap ang **Bibles** tab at babalik ka sa kabanata nang kusa.

Pinapalitan ng mga tab ang iyong konteksto at naaalala ang lugar mo. Ang pangunahing menu ay isa lang ibang paraan para makarating sa parehong mga screen.

### Kailan gagamitin ang pangunahing menu

Gamitin ang pangunahing menu kapag:

- Gusto mong buksan ang **Highlights**, **Notes**, **Devotionals**, **Help**, o **About** — mga screen na walang sariling tab sa toolbar.
- Malalim ka na sa isang kabanata o search at gusto mong tingnan nang mabilis ang isang bagay nang hindi nawawala ang lugar mo.
- Gusto mong buksan ang **Settings** nang iiwan ang screen na kinaroroonan mo.

## Scholar mode

Kung ang user mode mo ay **Scholar**, may mga dagdag na tab, menu item, at reader tool ang layout na itinatago ng Reader at Standard mode. Tingnan ang gabay na [Scholar Mode](theodia://help/scholar-mode) para sa buong paglilibot sa bawat feature.

## Paano nagkakatugma ang tatlong bahagi

- **Magpalit sa ibang pangunahing section** (Bibles, Search, Bookmarks, at iba pa) → Toolbar sa ibaba
- **Tumalon sa isang partikular na bersikulo o command** → Command sa home screen
- **Mag-browse ng lahat ng available na screen** → Button grid sa home screen
- **Tingnan ang Notes, Highlights, o Help nang hindi iiwan ang lugar mo** → pangunahing menu
- **Buksan ang Settings mula kahit saan** → pangunahing menu o toolbar

Gagamitin mo ang lahat ng tatlo. Walang isa sa kanila ang "tanging tamang paraan." Piliin ang pinakamadali para sa ginagawa mo.

### Toolbar vs. pangunahing menu: isang mabilis na halimbawa

Isipin na binabasa mo ang Romans 8 at gusto mong i-highlight ang isang bersikulong gusto mo.

**Gamit ang toolbar:**

1. I-tap ang bersikulo para buksan ang menu ng bersikulo.
2. I-tap ang **Highlight** at pumili ng kulay.
3. Tapos na. Hindi ka umalis sa kabanata.

**Gamit ang pangunahing menu (kung gusto mong balikan ang mga highlight mo):**

1. I-tap ang ☰ para buksan ang menu.
2. I-tap ang **Highlights**. Bubukas ang listahan ng mga highlight mo.
3. Balikan ang mga ito, tapos i-tap ang **Bibles** tab para bumalik sa Romans 8.

**Gamit ang toolbar (kung gusto mong magpalit ng gawain):**

1. I-tap ang **Home** o **Bookmarks** sa toolbar.
2. Iiwan mo ang Romans 8 at pupunta sa bagong screen.
3. Para bumalik sa Romans 8, i-tap ulit ang **Bibles** — babalik ka sa kabanata nang kusa.

## Mga tip

- Naaalala ng home screen kung aling section ang nakabukas o nakasara. Isang beses mo lang itong kailangang i-set up.
- Kung hindi mo nakikita ang isang tab na inaasahan mo, tingnan ang dalawang bagay:

1. **Ang user mode mo** — itinatago ng Reader mode ang bookmarks, highlights, notes, at AI. Itinatago ng Standard mode ang AI. Magpalit ng mode sa **Settings** → **App User Mode**.
2. **Mga setting ng feature** — kailangang i-on ang ilang tab sa **Settings** (halimbawa, ang AI assistant).
