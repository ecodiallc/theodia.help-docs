---
title: Pagsulat ng mga Note
level: everyday
categories: [annotate, read]
summary: Kung paano magsulat ng sarili mong mga kaisipan sa tabi ng isang bersikulo.
---

# Pagsulat ng mga Note

> **Mode:** Available ang mga note sa **Standard** at **Scholar** mode. Ang Focus Mode ay para lang sa malinis at walang istorbo na pagbabasa. Maaari kang magpalit ng mode sa **Settings** → **App User Mode**.

Ang mga note ay kung saan mo isinusulat ang sarili mong mga kaisipan, panalangin, o study idea sa tabi ng isang bersikulo. Nakatali ang bawat note sa isang partikular na bersikulo.

## Paano magdagdag ng note

1. Buksan ang bersikulo.
2. I-tap ang bersikulo para lumabas ang menu.
3. I-tap ang **Note** sa menu. May pencil icon ito.
4. I-type ang note mo.
5. I-tap ang **Save**.

Naka-save na ang note kasama ang bersikulo.

## Paano basahin ang isang note

1. Buksan ang bersikulo.
2. Hanapin ang marka ng lapis sa tabi ng bersikulo. Nangangahulugan itong may note.
3. I-tap ang bersikulo. Lalabas ang note sa ibaba.

## Paano i-edit ang isang note

1. Buksan ang bersikulo na may note.
2. I-tap ang bersikulo.
3. I-tap ang **Note** sa menu.
4. Gawin ang mga pagbabago mo.
5. I-tap ang **Save**.

## Paano burahin ang isang note

1. Buksan ang bersikulo na may note.
2. I-tap ang bersikulo.
3. I-tap ang **Note** sa menu.
4. I-tap ang **Delete**.

## Paano makita lahat ng note mo

I-tap ang **Notes** tab sa ibaba. Makikita mo ang listahan ng bawat note na nasulat mo, nakaayos ayon sa petsa.

## Maghanap sa mga note mo

Sa **Notes** tab, i-tap ang **Search** box. Mag-type ng isang salita. Hahanapin ng app ang bawat note na mayroon nito.

## Mga tip

- Maganda ang mga note para sa mga sermon, devotion, at study question.
- Pribado ang mga note. Nanatili ang mga ito sa iyong device.
- Tingnan ang gabay na [Pag-back Up ng Iyong Data](theodia://help/backups) para mapanatiling ligtas ang mga ito.
