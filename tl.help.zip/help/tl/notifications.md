---
title: Mga Notification at Reminder
level: everyday
categories: [settings]
summary: Kung paano i-on, i-customize, at pamahalaan ang mga offline reminder para sa panalangin, devotional, Bible plan, at iba pa.
---

# mga Notification at Reminder

Maaaring paalalahanan ka ng Theodia tungkol sa panalangin, devotional, Bible plan, flashcard, at iba pang gawain — kahit offline ang app. Naka-iskedyul lahat ng reminder sa iyong device; hindi kailangan ng internet connection o push-notification server.

## Paano i-on o i-off ang mga reminder

1. Buksan ang **Settings**.
2. I-tap ang **Notifications**.
3. I-on o i-off ang **Enable reminders**.

Sa unang pagkakataon na pipaganin mo ang mga reminder, maghihingi ng pahintulot ang app para magpadala ng notification. I-tap ang **Allow** para makalabas ang mga reminder.

Kung tinanggihan mo dati ang pahintulot, maaaring harangan ng iOS o Android ang kahilingan. Sa ganitong kaso, pumunta sa **Settings** app ng device mo, hanapin ang **Theodia**, at i-enable ang notifications doon.

## Mga uri ng reminder

Nahahati sa mga channel ang screen ng notifications. Ang bawat channel ay isang pamilya ng mga reminder na maaari mong i-on o i-off nang hiwalay:

- **Prayer reminders** — mga pangkalahatang paalala sa panalangin.
- **Prayer routine** — mga reminder na nakatali sa isang partikular na prayer routine.
- **Devotional** — ang paalala sa daily verse o devotional.
- **Bible plan reminders** — mga reminder para sa aktibong Bible plan.
- **Theoscript reminders** — mga paalala para magpatakbo ng Theoscript.
- **AI insight reminders** — mga reminder na gawa ng AI.
- **Flashcard review reminders** — mga paalala para mag-review ng mga flashcard.
- **Reading habit reminders** — mga araw-araw na paalala sa gawi sa pagbabasa.
- **Liturgical & seasonal reminders** — mga reminder na nakatali sa simbahang kalendaryo.
- **My reminders** — mga reminder na ginawa mo mula sa mga bookmark, highlight, playlist, kabanata ng Biblia, o libro.
- **Custom reminders** — ganap na pasadyang mga reminder na gagawa mo mismo.

I-tap ang kahit aling channel para makita ang mga reminder nito, palitan ang oras, piliin kung aling mga araw ito magpapakita, o i-off ito.

## Custom reminders

Ang mga custom reminder ay mga reminder na gagawa mo mula sa simula.

1. Sa **Settings** → **Notifications**, i-tap ang **Custom reminders**.
2. I-tap ang **+** button.
3. Maglagay ng **Title** at **Message**.
4. Pumili ng **Time**.
5. Piliin ang mga **Days** na gusto mong umulit ito.
6. Piliin kung ano ang bubuksanin ng reminder kapag tinap (opsyonal).
7. I-tap ang **Save**.

Maaari mong i-edit o burahin ang isang custom reminder anumang oras sa pamamagitan ng pag-tap dito sa listahan.

## Ano ang mangyayari kapag nag-tap ka ng reminder

Karamihan sa mga reminder ay bumubukas ng isang partikular na screen sa app. Halimbawa, ang reminder ng prayer routine ay bumubukas sa routine na iyon; ang reminder ng Bible plan ay bumubukas sa susunod na babasahin.

Kung walang naka-link na screen ang isang reminder, binubuksan nito ang app sa Home screen.

## Quiet hours

Pinatahimik ng quiet hours ang mga tunog ng notification pero pinapalabas pa rin ang mga biswal na reminder.

1. Sa **Settings** → **Notifications**, i-tap ang **Quiet hours**.
2. Magtakda ng oras ng **Start** at **End**.

Ang mga reminder na naka-iskedyul sa panahon ng quiet hours ay lalabas sa screen nang walang tunog.

## Mga paparating na reminder at history

- Ipinapakita ng **Upcoming reminders** ang lahat ng naka-iskedyul na susunod na lalabas.
- Ipinapakita ng **Notification history** ang mga kamakailang naihatid, naka-iskedyul, at nakanselang reminder.

Gamitin ang mga listahang ito para kumpirmahing tama ang nakatakda ng isang reminder o para malaman kung bakit hindi lumabas ang isa.

## Kung hindi lumalabas ang mga reminder

- Siguraduhing naka-on ang **Enable reminders**.
- I-check na pinapayagan ang notifications sa mga setting ng sistema ng device mo.
- Siguraduhing naka-enable ang channel ng reminder at may kahit isang araw na napili.
- Kung may quiet hours ka, maaaring tahimik ang reminder.
- May mga Android manufacturer na pinapatulog ang mga app. Idagdag ang Theodia sa listahan ng pinapayagan kung may battery-optimization settings ang device mo.
- Kung nakatali ang reminder sa nilalamang inalis mo (halimbawa, buradong Bible plan o routine), maaaring hindi ito lumabas hanggang pumili ka muli ng wastong target.

## Mga tunog ng notification

Maaari mong piliin ang tunog na tinutugtog ng mga reminder na sumusuporta sa tunog. I-tap ang **Sound** sa loob ng isang reminder o channel para pumili sa mga available na opsyon. Nakapaloob sa app ang mga tunog, kaya gumagana ang mga ito kahit offline.

Gamitin ang button na **Preview sound** para marinig ang napiling tunog bago i-save.

## Mga badge

May ilang reminder na maaaring magdagdag ng badge sa app icon. I-tap ang **Clear badge** sa screen ng notifications para i-reset ito.
