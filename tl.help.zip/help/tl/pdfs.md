---
title: mga PDF
level: everyday
categories: [read, resources]
summary: Mag-import, mag-ayos, at magbasa ng mga PDF document sa Theodia.
---

# mga PDF

> **Mode:** Available ang mga PDF sa **Standard** at **Scholar** mode. Ang Focus Mode ay para lang sa malinis at walang istorbo na pagbabasa. Maaari kang magpalit ng mode sa **Settings** → **App User Mode**.

Maaaring mag-imbak at magbasa ng mga PDF file ang Theodia. Nanatili sa iyong device ang mga na-import na PDF, kaya gumagana ang mga ito kahit offline.

## Buksan ang PDF library

I-tap ang **PDFs** tab sa ibaba ng screen, o i-tap ang **PDFs** tile sa Home screen.

## Mag-import ng PDF

1. Buksan ang **PDFs** tab.
2. I-tap ang **+** button sa kanang ibaba.
3. Pumili ng PDF mula sa device mo.
4. (Opsyonal) Mag-type o pumili ng category para maayos ito.

## Ayusin ang mga PDF

Pindutin nang matagal ang kahit aling PDF card para buksan ang menu na may mga opsyon na ito:

- **Rename** — palitan ang pamagat na ipinapakita sa library.
- **Change category** — ilipat ang PDF sa isang category.
- **Delete** — alisin ang PDF sa Theodia. Binubura rin nito ang na-save nitong posisyon sa pagbabasa.

Malayang teksto ang mga category. Mag-type ng bagong pangalan o pumili ng umiiral na isa kapag nag-import ka o nagpalit ng category.

## Basahin ang isang PDF

I-tap ang isang PDF card para buksan ito. Ipinapakita ng reader ang:

- Pamagat ng document sa isang bar sa itaas.
- Isang hanay ng mga page button: **First page**, **Previous**, ang kasalukuyang page ("3 / 120"), **Next**, at **Last page**.
- Isang toolbar na may mga tool ng document: **Contents**, **Zoom out**, **Zoom in**, **Reset zoom**, **Bookmark**, **Search**, **Listen**, at **Text view**.

Nakadim ang ilang tool kapag hindi magagamit — halimbawa, nakadim ang **Search** at **Listen** hanggang ma-install ang searchable text ng PDF.

### Pag-turn ng pahina

- I-tap ang **kaliwa** o **kanang chevron** para bumalik o umusang isang pahina.
- I-tap ang **First page** o **Last page** para tumalon sa dulo ng document.
- I-tap ang numero ng pahina (halimbawa "3 / 120") para buksan ang grid ng mga pahina, tapos i-tap ang pahinang gusto mo. Bumubukas ang grid malapit sa pahinang kinaroroonan mo.
- Gamitin ang mga **Left** at **Right arrow key** sa external keyboard.

### Zoom

- I-tap ang **Zoom in** (+) o **Zoom out** (−) para palitan ang laki ng pahina.
- I-tap ang **Reset zoom** para ibalik ang pahina sa normal na laki.
- Kung nag-zoom in ka, nag-turn ng pahina, tapos nag-zoom out, ibabalik ka ng Theodia sa pahinang binabasa mo.

## Maghanap sa loob ng isang PDF

1. Buksan ang PDF at i-tap ang **Search** (magnifying glass) button sa toolbar.
2. I-type ang hinahanap mo. Lalabas ang mga resulta habang nagta-type ka, kasama ang numero ng pahina at isang bahagi ng nakapaligid na teksto.
3. I-tap ang isang resulta para tumalon sa pahinang iyon.

Kailangan ng paghahanap na naka-install ang searchable text ng PDF. Kung hindi pa naka-install, nakadim ang Search button. Kasama ang searchable text sa mga PDF na naka-install mula sa community GitHub repository; ang mga PDF na in-import mo mismo ay wala nito hanggang maidagdag.

## Mga Nilalaman

Kung may built-in na table of contents ang PDF, ipinapakita ng **Contents** button sa toolbar ang mga ito bilang outline. I-tap ang isang pamagat ng section para tumalon sa pahinang iyon. Maaaring palakihin o paliitin ang mga section. Kung walang table of contents ang PDF, nakadim ang button.

## Mga Bookmark sa isang PDF

1. Buksan ang PDF at i-tap ang **Bookmark** button sa toolbar.
2. I-tap ang **Bookmark page** para i-save ang kasalukuyang pahina. Nagsisimula bilang numero ng pahina ang pangalan — mag-type ng pangalan kung gusto mo — tapos i-tap ang **Save**.
3. I-tap ang kahit aling bookmark sa listahan para tumalon sa pahina nito.
4. I-tap ang **×** sa tabi ng isang bookmark para burahin ito.

Hiwalay ang mga PDF bookmark sa mga bookmark mo sa Biblia. May sariling listahan ang bawat PDF.

## Basahin nang malakas ang isang PDF

Kung naka-install ang searchable text ng PDF, maaaring basahin nang malakas ng Theodia ang kasalukuyang pahina:

1. Buksan ang PDF at i-tap ang **Listen** (speaker) button sa toolbar.
2. May lalabas na control bar na may **Play/Pause**, **Rewind**, **Fast forward**, **Stop**, isang progress bar na maaari mong i-tap para lumaktaw sa loob ng pahina, ang bilis ng pagbasa, at ang boses.
3. Kapag natapos ang pahina, tuloy-tuloy ang pagbasa sa susunod na pahina nang kusa.

Pareho ang boses at bilis na ginagamit sa pagbabasa ng Biblia — tingnan ang [Pagbasa nang Malakas](theodia://help/tts) para sa kung paano palitan ang mga ito.

## Kopyahin, ibahagi, o i-save ang teksto ng pahina

I-tap ang **Text view** button sa toolbar para makita ang kasalukuyang pahina bilang plain text. Mula doon maaari mong:

- **Kopyahin** — kopyahin ang teksto ng pahina sa clipboard.
- **Ibahagi** — ibahagi ang teksto ng pahina sa kahit aling app sa device mo.
- **Idagdag sa study notes** — bubukas ng note editor na may teksto ng pahina, isang citation, at isang link pabalik sa pahinang ito na naka-prefill para sa iyo.

## Ituloy ang pagbabasa

Naaalala ng Theodia ang huling pahina na tiningnan mo at doon binubuksan ang PDF sa susunod.

## Mag-download ng mga PDF mula sa GitHub

Sa **Scholar** mode, may lalabas na **Download from GitHub** button sa ibaba ng library. Kumokonekta ito sa community PDF repository para maka-install ka ng mga naka-package na PDF document sa parehong paraan ng pag-install mo ng mga Biblia o libro.

## Mga tala

- Naka-imbak ang mga PDF sa pribadong documents folder ng Theodia. Hindi kasama ang mga ito sa mga backup, kaya kung lilipat ka sa bagong device, kakailanganin mong i-import muli ang mga ito.
