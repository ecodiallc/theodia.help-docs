---
title: mga Playlist
level: everyday
categories: playlists
summary: Gumawa at makinig ng mga pasalitang playlist ng mga bahagi ng Biblia, plain text, o kahit aling bersikulong gusto mong marinig.
---

# Playlists

Ang **playlist** ay isang listahan ng mga track na maaaring basahin nang malakas ng Theodia para sa iyo. Ang bawat track ay isang bahagi ng Biblia o isang maikling plain-text note. Kapaki-pakinabang ang mga playlist para sa hands-free na pakikinig habang bumibiyahe, naglalakad, nagde-devotional, o nagsasanay ng memorization.

Lumalabas ang mga playlist sa app kapag may kahit isang playlist nang nagawa o napuno.

## Saan makakita ng Playlists

Kapag available na ang mga playlist, maaari kang makarating sa mga ito sa dalawang paraan:

- **Home screen:** Sa section na **Plugins & More**, i-tap ang **Playlists**.
- **Pangunahing menu:** Buksan ang menu (☰) at i-tap ang **Playlists**.

Kung wala pang playlist, nakatago ang Playlists tile at ang menu item.

## Ano ang laman ng isang playlist

Mayroon ang bawat playlist ng:

- Isang **pangalan** — halimbawa, "Morning Verses" o "Memorize Psalm 23".
- Opsyonal na **category** — kapaki-pakinabang para pangkatin ang mga playlist ayon sa layunin.
- Isang listahan ng **mga track** — ang mga item na babasahin nang malakas.

Mayroon ang bawat track ng:

- **Content** — maaaring reference ng bahagi ng Biblia o plain text.
- Isang **label** — ipinapakita sa screen habang tumutugtog ang track.
- Opsyonal na **boses** — pumili ng ibang boses para sa track na ito kung gusto mo.

## Paglikha ng playlist

1. Buksan ang **Playlists** screen.
2. I-tap ang **Create playlist** (o ang **+** button).
3. Bigyan ng pangalan ang playlist.
4. (Opsyonal) Pumili o gumawa ng category.
5. Simulang magdagdag ng mga track.

### Pagdaragdag ng track mula sa bahagi ng Biblia

1. I-tap ang **Add track**.
2. Piliin ang **Bible passage** bilang uri ng content.
3. Maglagay ng reference, tulad ng `John 3:16` o `Psalm 23:1-6`.
4. Magdagdag ng label kung gusto mo, o iwanang blangko para gamitin ang reference.
5. I-save ang track.

### Pagdaragdag ng plain-text track

1. I-tap ang **Add track**.
2. Piliin ang **Plain text**.
3. I-type ang teksto na gusto mong basahin ng Theodia.
4. Magdagdag ng label.
5. I-save ang track.

### Pagdaragdag ng mga track nang maramihan

Kung may listahan ka ng mga reference o linya ng teksto, gamitin ang **Batch add**:

1. Buksan ang isang playlist.
2. I-tap ang menu at piliin ang **Batch add**.
3. I-paste ang isang reference o linya ng teksto kada linya.
4. I-on ang **Detect Bible references** kung karamihan sa mga linya ay mga verse reference.
5. I-tap ang **Add**. Magiging track ang bawat linya.

## Pakikinig sa isang playlist

1. Buksan ang playlist na gusto mong marinig.
2. I-tap ang **Play** button sa itaas o sa tabi ng isang track.
3. Basahin ng Theodia ang bawat track ayon sa pagkakasunod-sunod.

Habang tumutugtog ang playlist, may lalabas na control bar na may mga kontrol na ito:

- **Play / Pause**
- **Susunod na track**
- **Nakaraang track**
- **Stop**

Maaari ka ring magtakda ng:

- **Bilis** — kung gaano kabilis magbasa ang boses.
- **Ulitin** — ulitin ang buong playlist, ulitin ang isang track, o mag-play nang isang beses.
- **Shuffle** — mag-play ng mga track sa random na pagkakasunod-sunod.
- **Ignore parenthetical** — laktawan ang teksto sa loob ng mga panaklong.
- **Pagitan ng mga track** — magdagdag ng maikling katahimikan sa pagitan ng mga track.
- **Sleep timer** — ihinto ang pagtugtog pagkatapos ng itinakdang oras.

## Pag-edit ng playlist

Para palitan ang isang playlist, ihinto muna ang pagtugtog kung tumutugtog ito ngayon.

Maaari mong:

- **Palitan ang pangalan** ng playlist.
- **Ayusin muli ang mga track** — hilahin ang mga track sa bagong pagkakasunod-sunod.
- **I-edit ang isang track** — palitan ang reference, teksto, label, o boses nito.
- **Burahin ang isang track** — alisin ito sa playlist.
- **Burahin ang buong playlist** — hindi ito maaaring ibalik.

## Pag-export at pag-import ng mga playlist

Na-e-export ang mga playlist bilang JSON file na kasama ang lahat ng track, category, at setting. Maaari mong ibahagi ang file sa ibang device, panatilihin bilang backup, o i-edit sa computer.

- **I-export lahat ng playlist** — gumagawa ng `playlists-YYYY-MM-DD.json` file.
- **I-export ang isang category** — gumagawa ng JSON file na may lamang mga playlist sa isang category.
- **Mag-import ng mga playlist** — ibinabalik ang mga playlist mula sa JSON backup file.

## Mabilis na mga paraan para gumawa ng playlist

Maaari ka ring gumawa ng buong playlist bilang JSON at i-import ito. Narito ang isang halimbawa:

```json
{
  "playlists": [
    {
      "name": "Morning Verses",
      "category": "Devotional",
      "tracks": [
        {
          "info": "John 3:16",
          "contentSource": "passage",
          "content": "For God so loved the world...",
          "rawContent": "John 3:16"
        },
        {
          "info": "Psalm 23",
          "contentSource": "passage",
          "content": "The Lord is my shepherd...",
          "rawContent": "Psalm 23:1-6"
        }
      ]
    }
  ]
}
```

I-save ang file, tapos gamitin ang **Import playlists** para i-load ito sa Theodia.

## Mga tip

- Pinakamainam ang mga playlist sa maiikli at nakatuong set ng mga bersikulo.
- Gamitin ang mga category para paghiwalayin ang mga devotional playlist sa mga memorization playlist.
- Magtakda ng sleep timer kung nakikinig ka habang inaantok ka.
- Kung mali ang boses na ginagamit ng isang track, i-check na tugma ang wika ng boses sa wika ng teksto.
- Binabasa ng Theodia ang plain text nang eksakto kung paano ito nasulat; i-check ang spelling para sa pinakamainam na resulta.
