---
title: Pangkalahatang Tanaw sa Panalangin
level: beginner
categories: prayer
summary: Mabilis na pagpapakilala sa Prayer tab at sa mga pangunahing section nito.
---

# Pangkalahatang Tanaw sa Panalangin

Ang **Prayer** tab ay isang dedikadong lugar para sa panalangin. Pinagsasama nito ang mga listahan, mga giyad na sesyon, isang journal, isang timer, mga iskedyul ng lectionary reading, at mga klasikong nakatakdang panalangin.

## Ang mga pangunahing section

- **Prayer List** — subaybayan ang mga tao, sitwasyon, at paksa na pinapanalanginan mo.
- **Journal** — isulat ang mga repleksyon, sagot, at kaisipan sa paglipas ng panahon.
- **Generate Prayer** — pahatiwala si Theophilus na sumulat ng panalangin mula sa isang kahilingan o journal entry.
- **Creeds & Fixed Prayers** — mga klasikong panalangin at creed mula sa Kristiyanong tradisyon.
- **Lectionary** — mga iskedyul ng pagbabasa ng Kasulatan para sa pang-araw-araw o pana-panahong panalangin.
- **Guided Prayer** — mga sesyon ng panalangin na may gabay na audio gamit ang text-to-speech.
- **Timer** — mga sesyon ng panalangin na may takdang oras na may opsyonal na kampana.
