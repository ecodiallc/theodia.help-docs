---
title: Pagbabasa ng mga Built-in na Libro
level: beginner
categories: [content, read]
summary: Kung paano basahin ang mga klasikong Kristiyano na kasama ng app.
---

# Pagbabasa ng mga Built-in na Libro

May kasamang maliit na library ng mga Kristiyanong libro ang Theodia. Mga klasiko ang mga ito na maaari mong basahin sa iyong device.

## Paano buksan ang library

I-tap ang **Books** tab sa ibaba ng screen. Makikita mo ang listahan ng mga libro sa library mo.

## Paano basahin ang isang libro

1. I-tap ang pamagat ng libro.
2. Bubukas ang libro sa unang kabanata.
3. Gamitin ang mga **Previous** at **Next** button sa itaas para lumipat sa mga kabanata.

## Paano tumalon sa isang kabanata

I-tap ang pangalan ng kabanata sa itaas ng screen. May lalabas na listahan ng mga kabanata. Pumili ng kabanata para tumalon roon.

## Paano palitan ang laki ng font

Buksan ang **Settings** → **Appearance** at pumili ng laki ng font. Magbabago ang laki ng teksto sa buong app, kabilang sa mga libro.

## Paano magdagdag ng bookmark sa isang libro

I-tap ang **star** icon sa kanang itaas. Naka-save ang kasalukuyang kabanata. I-tap ang **Bookmarks** tab para makita ang mga na-save mong page.

## Paano makinig sa isang libro

I-tap ang **Speaker** icon sa kanang itaas. Babasahin nang malakas ng app ang kabanata. I-tap ulit para ihinto.

## Anong mga libro ang available?

May mga klasiko ang library tulad ng:

- Pilgrim's Progress
- The Imitation of Christ
- Practice of the Presence of God
- The Hymn Book

Maaaring lumago ang listahan ng mga libro sa paglipas ng panahon. Maaaring magdagdag pa ang mga update sa app.

## Mga tip

- Naka-imbak ang mga libro sa iyong device. Hindi kailangan ng internet.
- Hindi nagse-sync ang mga libro sa cloud.
