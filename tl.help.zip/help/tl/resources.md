---
title: Paghahanap ng mga Resource sa GitHub
level: everyday
categories: resources
summary: Hanapin nang sabay-sabay ang bawat GitHub repo na alam ng app, tapos i-install ang makita mo.
---

# Paghahanap ng mga Resource sa GitHub

May listahan ng mga GitHub repo ang Theodia na naglalathala ng mga resource — mga Biblia, commentary, libro, devotional, playlist, prayer package, at iba pa. **Hinahanap ng Search GitHub Repos ang lahat ng ito nang sabay-sabay**, kaya hindi mo na kailangang buksan ang bawat tab at mag-browse nang hiwalay.

> Available lang sa **Scholar mode** ang GitHub section ng Settings. Para i-on ito, pumunta sa **Settings → User Mode → Scholar**.

## Paano maghanap

1. Buksan ang **Settings**.
2. I-tap ang **Search GitHub Repos**.
3. Mag-type ng isang salita sa search box. Hinahanap ng app ang salitang iyon sa **pangalan** at sa **paglalarawan** ng bawat package sa bawat repo.

Ilang bagay na dapat malaman tungkol sa paghahanap:

- **Dapat magtugma ang bawat salita.** Ang paghahanap ng `morning evening` ay naghahanap lang ng mga package na ang pangalan o paglalarawan ay naglalaman ng *parehong* salita.
- **Hindi mahalaga ang case.** Parehong package ang mahahanap ng `Morning` at `morning`.
- **Ang pinakamahusay na tugma ang unang lalabas.** Ang isang package na ang pangalan ay *nagsisimula* sa hinahanap mo ay lalabas bago ang isa na banggit lang ito sa paglalarawan.

## Pagsasala

I-tap ang filter bar sa itaas ng mga resulta para paliitin pa ang listahan. May dalawang filter, at nagtutulungan ang mga ito:

- **Author** — mga package lang ng author na iyon.
- **Tradition** — mga package lang para sa tradisyong iyon.

I-tap muli ang isang filter para i-clear ito, o i-tap ang **Clear filters** para i-reset ang pareho.

## Pag-install mula sa isang resulta

Ipinapakita ng bawat resulta ang pangalan ng package, kung anong uri ng resource ito, kung sino ang gumawa, at kung aling repo ito galing. Sa kanan ng row ay may isang button:

- **Install** — wala pa sa iyong device ang package.
- **Update** — may mas bagong bersyon. Magtatanong muna ang app ng kumpirmasyon, dahil inaalisan ng pag-update ang lumang kopya kasama ang kahit anong note, highlight, o bookmark na nakadulo dito.
- **Open** — naka-install na ang package; kapag tinap mo ito, dadalhin ka sa screen kung saan ito ginagamit.

I-tap ang **Refresh** sa itaas para kunin agad ang pinakabagong listahan mula sa GitHub. Nagre-refresh ang app ng listahan mag-isa isang beses kada araw, kaya ang manual na refresh ay kailangan lang kapag alam mong may bago nang nailathala.

## Paghahanap nang walang koneksyon

Nagtatabi ang app ng kopya ng listahan sa iyong device, kaya gumagana ang paghahanap kahit offline ka. Kung hindi maabot ng app ang GitHub para i-refresh ang listahan, may banner sa itaas na nagsasabi sa iyo na nakikita mo ang naka-cache na resulta.

## Kung walang mahanap ang isang search

- Subukan ang isang mas maikli, isang salita lang.
- I-check na walang filter na **Author** o **Tradition** na nananatiling nakalapat — lalabas ang button na **Clear filters** kung mayroon man.
- May mga repo na naglalathala ng mga package nila sa ibang wika kaysa sa pangalan ng package, kaya ang paghahanap ng isinaling salita ay maaaring hindi makahanap ng mga ito.
