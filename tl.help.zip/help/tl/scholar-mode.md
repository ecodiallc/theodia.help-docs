---
title: Scholar Mode
level: advanced
categories: [layout, read, study]
summary: Ang pinakamalalim na study mode sa Theodia, na nagbubukas ng mga commentary, lexicon, cross-reference, AI tool, at Launcher Menu.
---

# Scholar Mode

> **Mode:** Available lang ang Scholar mode kapag ang user mode mo ay nakatakda sa **Scholar**. Magpalit ng mode sa **Settings** → **App User Mode**.

Binubuksan ng Scholar mode ang bawat study tool sa Theodia. Nakabatay ito sa Study Mode, kaya mayroon ka pa rin ang verse menu, parallel Bibles, bookmarks, highlights, at notes — kasama ang mga advanced tool na nakalista sa ibaba.

## Paano buksan ang Scholar mode

Ang Scholar mode ay hindi isang hiwalay na screen. Ito ay isang set ng mga dagdag na tool na lumalabas sa loob ng kasalukuyang reader at navigation kapag ang user mode mo ay Scholar.

1. Buksan ang **Settings**.
2. I-tap ang **App User Mode**.
3. Piliin ang **Scholar**.

Agad nagkakabisa ang pagbabago. Lumalabas na ang mga menu at button na dating nakatago.

## Mga dagdag na reader tool

Kapag binuksan mo ang isang kabanata sa [Study Mode](theodia://help/study-mode), nagdaragdag ang Scholar mode ng mga tool na ito sa verse menu:

- **AI Commentary** (◈) — pahatiwalain ang AI assistant na sumulat ng study note para sa bersikulong ito. (Hindi available sa lahat ng rehiyon.)
- **Word Info** (?) — buksan ang lexicon entry para sa orihinal na salitang Ebreo o Griyego sa likod ng bersikulo. Tingnan ang gabay na [Mga Commentary at Lexicon](theodia://help/commentaries-and-lexicons).
- **Dictionary** (📖) — hanapin ang mga pangkalahatang salita sa Biblia sa mga dictionary resource na naka-install mo. Tingnan ang gabay na [Bible Dictionary](theodia://help/dictionary).

Kailangan ng mga tool na ito na naka-install ang mga resource (mga commentary, lexicon, dictionary file). Kung abuhin ang isang tool o nagpapakita ng "not found", buksan ang **Settings** → **Manage Resources** at idagdag ang resource na kailangan nito.

## Mga dagdag na navigation

### Dagdag na toolbar tab

Nakakakuha ng isa pang tab ang toolbar sa ibaba:

- 💻 **AI** — binubuksan ang AI assistant (lang kung naka-on mo ang AI sa Settings). Nasa kanan ng Notes ang tab na ito.

### Mga dagdag na item sa pangunahing menu

May kasamang **AI Assistant** entry ang pangunahing menu sa ilalim ng parehong mga kondisyon.

## Ang Launcher Menu

Pinagagana ng Scholar mode ang **Launcher Menu**, isang mabilis na paraan para tumalon sa mga kamakailang bersikulo, magpatakbo ng mga command, at magpalit ng Bible layout nang hindi iiwan ang kasalukuyan mong screen. Tingnan ang gabay na [Launcher Menu](theodia://help/launcher-menu) para sa kung paano ito gamitin.

## Kailan gagamitin ang Scholar mode

- Gusto mo ang AI assistant, mga commentary, o mga lookup sa orihinal na wika habang nagbabasa.
- Gusto mo ang Launcher Menu para sa mabilis na pag-navigate sa mga bersikulo at AI chat.
- Pinag-aaralan mo nang malalim ang isang bahagi at kailangan mo ang bawat tool na isang tap lang ang layo.

## Paglipat sa mas magaan na mode

Kung gusto mo ng mas payapang reader nang wala ang mga advanced tool, magpalit sa **Standard** mode sa **Settings** → **App User Mode**. Pinapanatili ng Standard mode ang bookmarks, highlights, notes, at Study Mode pero itinatago ang AI, mga commentary, lexicon, at ang Launcher Menu.

Kung gusto mo ang pinakamalinis na karanasan sa pagbabasa, buksan ang isang kabanata sa [Focus Mode](theodia://help/focus-mode).

Hindi kailanman binubura ang iyong mga bookmark, highlight, at note kapag nagpalit ka ng mode; itinatago lang ang mga ito hanggang bumalik ka sa mode na sumusuporta sa mga ito.

## Tulong at mga tanong

Kung may nawawalang tool o may error na lumalabas, tingnan ang gabay na [Mga Karaniwang Problema](theodia://help/common-problems). Kung bago ka sa Theodia, dinadaanan ka ng gabay na [Pagbasa ng Iyong Unang Kabanata](theodia://help/first-read) sa mga pangunahing kaalaman nang hakbang-hakbang.
