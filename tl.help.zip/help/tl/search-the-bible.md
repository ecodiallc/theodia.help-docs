---
title: Paghahanap sa Biblia
level: everyday
categories: [study, read]
summary: Kung paano mahanap ang mga bersikulo ayon sa salita, parirala, o reference.
---

# Paghahanap sa Biblia

Tutulong sa iyo ang search bar na mabilisang mahanap ang mga bersikulo. Maaari kang maghanap ayon sa isang salita, isang parirala, o isang reference sa Biblia.

## Paano magsimula ng search

1. I-tap ang **Search** tab sa ibaba ng screen.
2. I-type ang gusto mong hanapin.
3. I-tap ang **Search** sa keyboard.

Lalabas ang mga resulta bilang listahan ng mga bersikulo. Ipinapakita ng bawat resulta ang libro, kabanata, at bersikulo, kasama ang teksto ng bersikulo.

## Paghahanap gamit ang kombinasyon ng mga salita

Kapag nag-type ka ng mahigit isang salita, tulad ng `love joy`, hahanapin ng app ang mga bersikulong naglalaman ng **parehong** salita. Isang **AND** search ito — dapat lumabas lahat ng salita sa bersikulo. Hindi nito ginagamit ang **OR** logic (mga bersikulong may kahit isang salita).

Para maghanap ng mga bersikulong may kahit isa sa mga salita, kailangan mong gumamit nang eksplisito ng keyword na `OR`: `love OR joy`.

## Paghahanap ayon sa salita

Mag-type ng isang salita, tulad ng `love` o `mercy`. Ipinapakita ng app ang bawat bersikulo sa Biblia na mayroon nito.

## Paghahanap ayon sa parirala

Mag-type ng dalawa o tatlong salita sa loob ng quote, tulad ng `"do not be afraid"`. Ipinapakita ng app ang mga bersikulong may eksaktong pariralang iyon.

## Salain ang mga resulta

Pagkatapos ng search, sinasala ang mga resulta sa mga salin ng Biblia na naka-install mo. Para paliitin pa, buksan ang **Bible** tab at tumingin sa isang partikular na salin — tumatakbo ang mga search laban sa mga salin na mayroon ka.

## Mga tip para sa mas mahusay na paghahanap

- Gumamit ng maiikling salita. Mas maraming bersikulo ang mahanap ng search para sa `love` kaysa sa search para sa `loving`.
- Ginagawang eksakto ng mga quote sa paligid ng isang parirala ang search.
- Naghahanap lang ang app sa mga salin ng Biblia na naka-install mo.
- Para tumalon sa isang partikular na bersikulo ayon sa reference (halimbawa, `John 3:16`), gamitin ang **Command** box sa home screen sa halip na Search tab.

## Search history

Naaalala ng app ang mga pinakabago mong search. Kapag binuksan mo ang **Search** tab, ipinapakita ng listahan ang mga kamakailang search mo sa itaas. I-tap ang isa para patakbuhin ito muli. Para i-clear ang listahan, i-tap ang **Clear All** sa itaas ng mga kamakailang search.

## Paghahanap sa mga PDF

Maaari rin maghanap sa loob ng iyong mga PDF document ang Search tab:

1. I-tap ang **Search** tab, tapos i-tap ang mode na **PDFs** sa itaas.
2. Pumili kung aling mga PDF ang hahanapin. I-tap ang isang PDF para isama o hindi isama; gamitin ang **All** o **Clear** sa itaas ng listahan para isama ang lahat o magsimulang muli. Mga PDF lang na naka-install na ang searchable text ang maaaring piliin.
3. I-type ang gusto mong hanapin at i-tap ang **Search**.

Ipinapakita ng bawat resulta ang pamagat ng PDF, ang numero ng pahina, at isang bahagi ng tugmang teksto. I-tap ang isang resulta para buksan ang PDF na iyon sa pahinang iyon.

Para maghanap sa loob ng isang PDF habang binabasa mo ito, gamitin ang **Search** button sa PDF reader sa halip — tingnan ang [mga PDF](theodia://help/pdfs).
