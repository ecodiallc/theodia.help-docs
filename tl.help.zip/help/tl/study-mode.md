---
title: Study Mode
level: everyday
categories: [layout, read]
summary: Ang buong Bible reader sa Theodia, puno ng mga study tool tulad ng commentary, cross-references, lexicon, at notes.
---

# Study Mode

> **Mode:** Available ang Study Mode sa **Standard** at **Scholar** mode. Bumubukas ang Reader mode ng mga kabanata sa Focus Mode sa halip. Maaari kang magpalit ng mode sa **Settings** → **App User Mode**.

Ang Study Mode ang pangunahing Bible reader sa Theodia. Mayroon ito lahat ng study tool na naka-built in: commentary, cross-references, word lookup, mga parallel na salin, notes, at iba pa.

Ang Focus Mode ay isang mas payapang reader na walang study tool. Tingnan ang gabay na [Focus Mode](theodia://help/focus-mode) kung gusto mo lang ng malinis na teksto. Para sa Study Mode ang gabay na ito.

## Paano buksan ang Study Mode

May ilang paraan para buksan ang isang kabanata sa Study Mode:

- I-tap ang **Bible** tab sa ibaba ng screen. Pumili ng salin, isang libro, at isang kabanata.
- I-tap ang isang bersikulo sa mga resulta ng **Search**.
- I-tap ang isang bookmark mula sa **Bookmarks** tab.
- Mula sa Focus Mode, i-tap ang 📖 button sa itaas ng screen para magpalit sa Study Mode.

## Pagbabasa ng kabanata

Bumubukas ang kabanata na nakaayos ang mga bersikulo. Sa itaas ng screen ay ang mga button para sa mga pinakakaraniwang aksyon. Sa ibaba ng screen ay may status bar.

- **Mag-swipe pakaliwa** para pumunta sa susunod na kabanata.
- **Mag-swipe pakanan** para bumalik sa nakaraang kabanata.
- **I-tap ang isang bersikulo** para buksan ang verse menu na may mga study tool (tingnan sa ibaba).
- **I-tap ang isang Strong's number sa isang bersikulo** (halimbawa, G1234 o H1234) para buksan ang mabilisang lexicon lookup para sa salitang iyon.

Kung naka-on ang isang parallel na salin, may lalabas na pangalawang kopya ng kabanata sa ibaba ng pangunahing isa, sa salin na pinili mo. Tingnan ang **Pagbasa ng dalawang salin nang sabay** sa ibaba.

## Ang verse menu

Kapag nag-tap ka ng isang bersikulo, may bubukas na menu na may pamagat na "Book Chapter:Verse". Depende sa user mode mo ang mga tool na makikita mo.

### Mga tool sa Standard at Scholar mode

- **Bookmark** (★) — i-save ang bersikulo para mahanap mo ito muli. I-tap ulit para alisin ang bookmark. Ang unang tap ay nagdaragdag nito. Tingnan ang gabay na [Pag-bo-bookmark ng mga Bersikulo](theodia://help/bookmarks).
- **Highlight** (□) — kulayan ang bersikulo para namumukod-tangi ito. I-tap ito para buksan ang color picker. I-tap muli ang parehong kulay para alisin ang highlight. Tingnan ang gabay na [Paghi-highlight ng mga Bersikulo](theodia://help/highlights).
- **Speak** (🔊) — basahin nang malakas ang bersikulo gamit ang text-to-speech voice ng device mo. Hindi ito ipinapakita para sa interlinear Bibles. Tingnan ang gabay na [Pagbasa nang Malakas](theodia://help/tts) para sa kung paano ito gamitin at kung paano pumili ng boses.
- **Copy** (⎘) — ilagay ang teksto ng bersikulo sa clipboard mo para mai-paste mo ito kahit saan.
- **Compare** (⇄) — buksan ang isang panel na nagpapakita ng parehong bersikulo sa bawat salin na naka-install mo. I-tap ang isang salin sa panel para basahin ang bersikulo sa salin na iyon. Tingnan ang gabay na [Paghahambing ng mga Salin](theodia://help/compare-translations).
- **Cross-References** (↗) — buksan ang listahan ng mga kaugnay na bersikulo mula sa cross-reference database. Tingnan ang gabay na [Mga Cross-Reference](theodia://help/cross-references).
- **Add/Edit Bible Note** (✎) — sumulat ng sarili mong pribadong note na nakakabit sa bersikulo. Tingnan ang gabay na [Pagsulat ng mga Note](theodia://help/notes).

### Mga tool sa Scholar mode lamang

- **AI Commentary** (◈) — pahatiwalain ang AI assistant na sumulat ng study note para sa bersikulong ito. (Hindi available sa lahat ng rehiyon.)
- **Word Info** (?) — buksan ang lexicon entry para sa orihinal na salitang Ebreo o Griyego sa likod ng bersikulo. Tingnan ang gabay na [Mga Commentary at Lexicon](theodia://help/commentaries-and-lexicons).
- **Dictionary** (📖) — hanapin ang mga pangkalahatang salita sa Biblia sa mga dictionary resource na naka-install mo. Tingnan ang gabay na [Bible Dictionary](theodia://help/dictionary).

May ilang tool na kailangan ng mga dagdag na resource para ma-install. Kung abuhin ang isang tool o nagpapakita ng "not found", buksan ang **Settings** → **Manage Resources** at idagdag ang resource na kailangan nito.

## Mga button sa itaas ng screen

Sa itaas ng teksto ng kabanata ay isang hanay ng mga icon. Mga mabilisang aksyon ang mga ito:

- **Bersyon ng Biblia** — i-tap ang pangalan ng salin (halimbawa, "KJV") para magpalit ng ibang salin.
- **Libro** — i-tap ang pangalan ng libro para tumalon sa ibang libro.
- **Kabanata** — i-tap ang numero ng kabanata para tumalon sa ibang kabanata.
- **Buksan sa AI** (🤖) — ipadala ang kasalukuyang kabanata sa AI assistant kasama ang tanong mo. (Scholar mode lang.)
- **Focus Mode** (📖) — lumipat sa Focus Mode para sa malinis na pagbabasa.
- **Parallel Bibles** (🔵 / ⚪) — i-tap para i-on o i-off ang mga parallel na salin. Kapag naka-enable, ipinapakita ang parehong kabanata sa mga parallel na salin na pinili mo sa ibaba ng pangunahing teksto. Kapag naka-disable, ipinapakita lang ang pangunahing salin. Tingnan ang **Pagbasa ng maraming salin nang sabay** sa ibaba.
- **Listen** — basahin nang malakas ang buong kabanata. Tingnan ang gabay na [Pagbasa nang Malakas](theodia://help/tts).
- **More** — buksan ang mga dagdag na aksyon sa kabanata (chapter Bible note, chapter commentary, share, at iba pa).

## Pagbasa ng maraming salin nang sabay

Maaari kang magpakita ng hanggang apat na dagdag na salin sa tabi ng pangunahing mo. Tinatawag itong **parallel view**.

1. Buksan ang **Settings**.
2. I-on ang **Parallel Bible**.
3. I-tap ang **Add Parallel Bible** at pumili ng salin.
4. Ulitin para magdagdag pa. Maaari kang magkaroon ng hanggang apat na parallel na salin.

Kapag naka-on ang parallel view, ipinapakita ng bawat bersikulo sa kabanata ang pangunahing salin mo muna, sinusundan ng parehong bersikulo sa bawat parallel na salin. Napapadali nito ang paghahambing kung paano hinahawakan ng iba't ibang tagasalin ang isang mahirap na bersikulo nang hindi iiwan ang kabanata.

Maaari mong i-save ang kasalukuyan mong parallel setup bilang isang **preset**. I-tap ang save button sa tabi ng mga piniling salin mo, bigyan ito ng pangalan, at magiging isang mabilisang pagpipilian ito. I-tap ang kahit aling preset mamaya para agarang i-load ang kombinasyong iyon. Pindutin nang matagal ang isang preset para burahin ito.

Maaari ka ring maghambing ng isang bersikulo lang nang sabay gamit ang **Compare** (⇄) tool sa verse menu. Bumubukas ito ng panel na nagpapakita ng bersikulo sa bawat naka-install na salin.

## Mga subheading

May ilang salin na may built-in na mga heading ng section (halimbawa, "Ang Sermon sa Bundok"). Kung mayroon ang salin mo, maaari mong ipakita o itago ang mga ito gamit ang setting na **Show Subheadings** sa **Settings**. Lumalabas ang mga subheading bilang maliliit na abuhing pamagat sa pagitan ng mga bersikulo.

## Ang chapter note

Ang chapter note ay isang note lang na nakakabit sa buong kabanata, hindi sa isang bersikulo lang. Kapaki-pakinabang ito para sa isang malaking kaisipan tungkol sa kabanata.

Para buksan ang chapter note:

1. I-tap ang **More** button sa itaas ng screen.
2. I-tap ang **Chapter Note**.
3. Isulat ang note mo. I-tap ang **Save**.

Naka-save ang chapter note kasama ang kabanata. Lalabas ito tuwing bubuksan mo ang kabanatang iyon.

## Mga highlight ng search

Kung dumating ka sa kabanata mula sa isang search, naka-highlight sa dilaw ang mga salita mo sa teksto ng bersikulo. Napapadali nitong makita kung bakit tumugma ang isang bersikulo.

Maaari ka ring magpatakbo muli ng search sa isang kabanatang binabasa mo. Buksan ang **Search** tab at maglagay ng isang salita. Pinapayagan ka ng mga resulta na tumalon nang diretso pabalik sa kabanata na naka-highlight ang mga tugma.

Laging bumubukas sa Study Mode ang mga interlinear Bible (MIB — Marvel Interlinear Bible — at OHGB) dahil kailangan nila ang word-level na layout.

## Paglipat sa Focus Mode para sa isang kabanata

Mula sa kahit aling kabanata sa Study Mode, i-tap ang 📖 button sa itaas. Bubukas ang parehong kabanata sa Focus Mode na nakatago lahat ng menu. I-tap ang 📖 button sa bottom bar para bumalik sa Study Mode.

## Kailan gagamitin ang Study Mode

Ang Study Mode ang tamang pagpipilian kapag gusto mong:

- **Magbasa at mag-aral nang sabay.** Isang tap lang ang layo ng lahat ng tool.
- **Hanapin ang isang salitang hindi mo alam.** I-tap ang isang Strong's number sa bersikulo para sa mabilisang lexicon entry.
- **Hambingin ang mga salin.** Gamitin ang Compare tool ng verse menu o i-on ang parallel view.
- **Makita kung paano konektado ang isang bersikulo sa iba ng Biblia.** Gamitin ang Cross-References.
- **Mag-note habang nagbabasa.** May mabilisang "Add note" option ang verse menu.

Para sa mahaba at walang istorbo na pagbabasa, lumipat sa Focus Mode.

## Paglipat sa Focus Mode

Mula sa kahit aling kabanata sa Study Mode, i-tap ang 📖 button sa itaas. Bubukas ang parehong kabanata sa [Focus Mode](theodia://help/focus-mode) na nakatago ang mga menu at study tool. I-tap ang 📖 button sa bottom bar para bumalik sa Study Mode. Para sa buong paglalarawan ng ginagawa ng Focus Mode, tingnan ang gabay na [Focus Mode](theodia://help/focus-mode).

## Tulong at mga tanong

Kung may nawawalang tool o may error na lumalabas, tingnan ang gabay na [Mga Karaniwang Problema](theodia://help/common-problems). Kung bago ka sa Theodia, dinadaanan ka ng gabay na [Pagbasa ng Iyong Unang Kabanata](theodia://help/first-read) sa mga pangunahing kaalaman nang hakbang-hakbang.
