---
title: Mga Feature sa Tablet
level: everyday
categories: [layout, tablet]
summary: Kung paano umaangkop ang layout ng Theodia sa mga tablet at mas malalaking screen, may split view, side panel, at two-pane reading mode.
---

# 📱 Mga Feature sa Tablet

Dinisenyo ang Theodia para pagsamantalahan ang mas malalaking screen ng mga tablet. Sa isang tablet (o kahit anong device na mas malapad sa mga 700 pixel), kusang lumilipat ang app sa two-column layout sa maraming lugar.

> **Mode:** Lalabas lang ang mga feature na inilalarawan dito kung sinusuportahan sila ng kasalukuyan mong user mode. Halimbawa, ang commentary side panel at AI chat ay available lang sa Scholar mode. Ang split view ng bookmarks, highlights, at notes ay nangangailangan ng Standard o Scholar mode. Malinis, one-column na pagbabasa lang ang ipinapakita ng Focus Mode. Maaari kang magpalit ng mode sa **Settings** → **App User Mode**.

## Verse menu ng reader

Kapag nag-tap ka ng numero ng bersikulo (o pindutin nang matagal ang teksto ng bersikulo), lalabas ang **verse menu** bilang isang **naka-gitnang card** sa itaas ng madilim na backdrop.

- Laging nakikita ang mga **Copy** at **Share** button sa itaas ng menu.
- Ipinapakita ang **Bookmarks** at **Highlights** kasama ang kasalukuyan nilang estado.
- Bumubukas mula sa menu ang **Commentary**, **Dictionary**, at **Compare**. Sa isang tablet, maaaring lumabas ang mga tool na ito sa isang side panel o malapad na card kapag napili na.
- I-tap ang backdrop o ang arrow na pangsara para tanggalin ang menu.

## Verse Commentary panel

Bumubukas ang **Commentary** tool bilang isang **dedikadong side panel** sa isang tablet:

- Lumalabas sa tabi ng teksto ng Biblia ang teksto ng commentary.
- Maaari kang mag-scroll sa commentary nang hiwalay sa Biblia.
- I-tap ang **X** o mag-swipe palayo para isara.
- Ang **book icon** sa itaas ng panel ay nagpapahintulot sa iyo na magpalit ng pinagkunan ng commentary.
- Ang **chapter icon** ay nagpapahintulot sa iyo na tumingin ng chapter-level na commentary.

Sa isang telepono, bumubukas ang commentary bilang full-screen modal.

## Chapter Commentary

Ina-access ang **Chapter Commentary** mula sa **More** button sa itaas ng screen, hindi sa verse menu. Sa isang tablet, bumubukas ito bilang side panel na katulad ng Verse Commentary, kaya maaari mong sabayang basahin ang commentary at ang teksto ng Biblia.

## Compare tab

Bumubukas ang **Compare** tab (sa verse menu) bilang isang **side panel** sa isang tablet. Ipinapakita nito ang napiling bersikulo sa bawat parallel na bersyon na naka-enable mo. Maaari mong i-tap ang kahit aling bersyon para tumalon sa bahaging iyon sa reader.

## Dictionary / Strong's popup

Bumubukas ang **Dictionary** tool (verse menu → Dictionary) bilang isang malapad na card sa isang tablet. Ipinapakita nito ang salitang Griyego o Ebreo, ang transliteration nito, ang kahulugan, at ang Strong's number. I-tap ang **Concordance** button para makita ang bawat paglagi ng salitang iyon sa Biblia.

## I-tap ang isang salita para buksan ang Lexicon nito

Sa **Word Info** side panel sa isang tablet, mai-tap ang bawat word card na may Strong's number. I-tap ang card para direktang buksan ang **Lexicon** panel para sa salitang iyon. Pumapalit ang Lexicon panel sa Word Info panel para makapag-aral ka nang tuloy-tuloy nang hindi isinasara ang reader.

Sa isang telepono, hindi mai-tap ang mga Word Info card dahil masyadong maliit ang screen para sa dalawang panel.

## Mga Parallel Bible na magkatabi

Sa Settings, i-tap ang **Parallel Bibles** at pumili ng hanggang tatlong bersyon. Sa isang tablet, lumalabas ang mga bersyon bilang **mga bertikal na pane** na magkatabi:

- Nag-i-scroll nang hiwalay ang bawat pane.
- Maaari mong i-tap ang numero ng bersikulo para buksan ang isang side panel na may mga tool.
- Ipinapakita ng **Compare** tab ang lahat ng napiling bersikulo sa isang lugar.
- I-tap ang **X** sa kahit aling pane para isara ito at bumalik sa one-column view.
- I-tap ang **Parallel Bibles** icon (🔵 / ⚪) sa top icon bar para i-on o i-off ang parallel view nang hindi binubuksan ang Settings.

Sa isang telepono, ipinapakita ang mga parallel na bersyon nang isa-isa (bertikal) sa halip na magkatabi. Gumagana rin ang parehong toggle icon sa mga telepono.

## Split view ng Bookmarks at Highlights

Sa isang tablet, gumagamit ng master-detail layout ang mga **Bookmarks** at **Highlights** tab:

- **Kaliwang bahagi** — ang listahan ng mga bookmark o highlight.
- **Kanang bahagi** — ang pag-tap ng isang item ay bumubukas ng preview pane na may teksto ng bersikulo o bahagi.

Maaari mong tuklawin ang mga na-save mong item at i-preview ang mga ito nang hindi iiwan ang tab. Sa isang telepono, ang pag-tap ng isang item ay nagpapunta sa iyo sa reader screen.

## Split view ng Notes

Ipinapakita ng **Notes** tab sa isang tablet ang listahan ng mga note mo sa kaliwa at ang napiling note sa kanan. Bumubukas ang pag-tap ng isang note sa isang side panel para maaari kang tumuklaw ng ilang note nang sunud-sunod nang hindi iiwan ang listahan. Gumagamit din ng side panel ang paglikha o pag-edit ng note.

## Split view ng Search

Sa isang tablet, ipinapakita ng **Search** tab ang search form sa kaliwa at ang mga resulta sa kanan kapag nagpatakbo ka agad ng search. Maaari mong pagandahin ang query mo at panoorin ang mga resulta na nag-a-update nang hindi nagpapalit ng screen. Sa isang telepono, bumubukas ang mga resulta ng search sa isang hiwalay na screen.

## Settings category sidebar

Ipinapakita ng **Settings** screen sa isang tablet ang isang listahan ng category sa kaliwa (AI, Appearance, Backup, Bibles, at iba pa). I-tap ang isang category para direktang tumalon sa mga setting nito sa kanan. Ang napiling category lang ang nakabukas, kaya hindi mo na kailangang mag-scroll sa buong listahan ng mga setting.

## Bible navigation sa mga tablet

Nanatiling one-column sa mga tablet ang **Bible List**, **Bible Books**, at **Bible Chapters** screens, pero mas malalaking touch target, mas malalapad na grid, at mas maluwag na padding ang ginagamit nila para mas madaling basahin at i-tap ang nilalaman. Hindi sila gumagamit ng split-view layout dahil kailangan ng bawat hakbang ang buong lapad para malinaw na maipakita ang listahan o grid nito.

## Landscape at portrait

Kusang naaayos ang layout kapag pinaiikot ang tablet. Sa **landscape**, maraming espasyo ang mga side panel. Sa **portrait**, pumipikit ang mga panel pero nananatili pa rin sa tabi ng teksto.

## AI chat ng napiling bersikulo

Bumubukas ang **AI** chat sa side panel ng verse menu. Ipinapakita nito ang isang interface ng pag-uusap kung saan maaari kang magtanong tungkol sa napiling bersikulo. Lalabas sa panel ang sagot ng AI, at maaari mong ipagpatuloy ang pag-uusap nang hindi iiwan ang reader.

## Conversation sidebar sa AI screen

Sa **AI** tab sa isang tablet, laging nakikita ang listahan ng pag-uusap bilang permanenteng kaliwang sidebar. Maaari kang lumipat-lipat sa mga chat nang hindi bumubukas ng menu. Laging nakikita rin ang **New Chat** button. Sa isang telepono, ang listahan ng pag-uusap ay isang popup drawer.

## Ano ang hindi nagbabago

Hindi bawat screen ay nahahati sa dalawang pane. Nanatiling one-column sa mga tablet ang mga sumusunod na screen:

- **Bible List** — listahan ng mga bersyon ng Biblia (buong lapad)
- **Bible Books** — book grid at mga section (buong lapad)
- **Bible Chapters** — chapter grid (buong lapad)
- **PDFs** — gumagamit ng mas malapad na card grid ang PDF library (buong lapad)
- **Settings** — mga indibidwal na page ng setting (buong lapad)
- **Help** — mga artikulo ng tulong (buong lapad)

## Buod

Sa isang tablet, makakakuha ka ng:

- **Mga Parallel Bible** sa magkatabing bertikal na pane
- **Commentary** sa mga permanenteng side panel
- **Compare** at **Dictionary** sa malalapad na card
- **Lexicon** mula sa isang tap sa kahit aling Word Info card
- **Bookmarks, Highlights, Notes, Devotionals, Books, Settings** sa master-detail split view
- **Search** na may inline na resulta sa tabi ng search form
- **Landscape** at **portrait** na parehong sinusuportahan, kusang nagbabago ang layout

Sa isang telepono, gumagamit ang lahat ng tradisyonal na one-column drill-down navigation. Nadarama ng app ang lapad ng screen sa paglunsad at kusang pumipili ng tamang layout.
