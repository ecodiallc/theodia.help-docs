---
title: Pagpalit ng mga Tema at Font
level: everyday
categories: settings
summary: Kung paano palitan ang itsura ng app.
---

# Pagpalit ng mga Tema at Font

Pinapayagan ka ng Theodia na palitan ang hitsura ng app. Maaari kang pumili ng tema (maliwanag o madilim) at laki ng font.

## Paano buksan ang mga setting ng appearance

1. Buksan ang **Settings**.
2. I-tap ang **Appearance**.

## Paano palitan ang tema

Sa section na **Appearance**, makikita mo ang dalawang theme button:

- **Default** — maliwanag na background na may madilim na teksto. Mainam para sa araw.
- **Dark** — madilim na background na may maliwanag na teksto. Mainam para sa gabi at nakakatipid ng baterya.

I-tap ang isang tema para i-apply ito. Agad ang pagbabago.

## Paano palitan ang laki ng font

Sa section na **Appearance**, i-tap ang isa sa mga size button: **---**, **--**, **-**, **Normal**, **+**, **++**, **+++**. Pumipikit o lumalaki ang teksto sa buong app. Piliin ang laki na pinakamadali para sa iyo basahin.

## Mga tip

- Nakakatipid ng baterya ang dark theme sa mga teleponong may OLED screen.
- Kung masyadong maliit ang teksto para basahin, dagdagan ang laki ng font sa app, hindi sa device. Mas pinong setting ang ng app.
- Para sa mahabang pagbabasa, subukan ang dark theme at mas malaking font.
- [I-activate ang desert theme](theodia://unlock-desert)
