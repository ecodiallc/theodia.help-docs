---
title: Mga Feature ng Theodia
level: beginner
categories: welcome
summary: Mabilisang pagtingin sa mga nagpapaiba sa Theodia at kung paano nito tinutulungan ang iyong pag-aaral ng Biblia.
---

# Mga Feature ng Theodia

Dinisenyo ang Theodia para maging buong kasama sa pag-aaral ng Biblia. Narito ang mga nagpapaiba dito.

## Offline Muna

Gumagana ang lahat nang walang internet. Naka-imbak sa iyong device ang mga Biblia, commentary, lexicon, libro, at devotional. Maaari kang magbasa, maghanap, at mag-aral kahit saan — sa eroplano, sa malayong lugar, o kahit saang walang signal.

## Nakatuon sa Privacy

Nananatili sa iyo ang data mo. Naka-imbak nang lokal sa iyong device ang mga note, highlight, bookmark, at history ng pagbabasa. Walang kinakailangang account, at walang naipapadala sa server maliban kung pinili mong gamitin ang opsyonal na AI assistant.

## Suporta sa Tablet

Dinisenyo ang Theodia para sa parehong telepono at tablet. Sa mas malaking screen, mas maraming espasyo kang nakukuha para sa pagbabasa, mga parallel Bible view, at isang layout na pagsasamantalahan ang dagdag na espasyo.

## Mga Nai-install na Resource

Hindi ka limitado sa kasama ng app. Maaari kang magdagdag ng mas maraming bersyon ng Biblia, commentary, lexicon, libro, at devotional. Available ang mga resources sa GitHub page ng proyekto at maaaring i-install nang diretso sa app.

## AI Assistant

Tutulong sa iyo ang opsyonal na AI assistant na maintindihan ang mga bersikulo, ipaliwanag ang konteksto, at sumagot ng mga tanong. Aktibo lang ito kung i-on mo ito. Sa default, kumokonekta ito sa isang remote na modelong ibibigay mo sa pamamagitan ng endpoint at API key na i-configure mo. Sa unang pagkakataon na gagamitin mo ang AI, maghihingi ng pahintulot ang app at ipapakita nang eksakto kung ano ang ipinapadala.

## Parallel na Pagbasa ng Biblia

Basahin nang sabay ang hanggang apat na bersyon ng Biblia. Kapag binuksan mo ang isang kabanata, lalabas muna ang pangunahing salin mo, at sinusundan ng bawat bersikulo ang parehong bersikulo sa mga parallel na salin na pinili mo. Hambingin ang mga pananalita, pag-aralan ang mga pagkakaiba, at makakuha ng mas buong larawan ng teksto. I-save ang mga paborito mong kombinasyon bilang mga preset at mabilisang lumipat-lipat sa mga ito.

## Full-Text na Paghahanap

Maghanap sa kahit aling bersyon ng Biblia. Hanapin ang mga salita, parirala, o bahagyang tugma. Maaari mo ring limitahan ang search sa isang saklaw ng mga libro.

## Mga Cross-Reference

I-tap ang isang reference ng bersikulo para direktang tumalon sa bahaging iyon. Naka-built in ang mga cross-reference at gumagana sa buong Biblia.

## Lexicon at mga Strong's Number

I-tap ang isang Strong's number para makita ang orihinal na kahulugan sa Griyego o Ebreo. Kasama ang mga lexicon entry para sa mas malalim na pag-aaral ng mga salita.

## Mga Bookmark at Highlight

I-save ang mga bersikulo gamit ang mga bookmark at markahan ang mga ito ng mga kulay. Naka-imbak nang lokal ang lahat at nananatili sa pagitan ng mga sesyon.

## Mga Note

Sumulat ng sarili mong mga kaisipan sa tabi ng kahit aling bersikulo. Nakatali sa bersikulo ang mga note at madaling mahanap mamaya.

## Pang-araw-araw na Devotional

Simulan ang araw mo sa isang maikling devotional reading. Kasama sa app ang mga devotional na bumubukas nang kusa sa entry ngayong araw.

## Mga Kristiyanong Libro

Basahin ang mga klasikong Kristiyanong panitikan sa loob ng app. Naka-format ang mga libro para madaling mabasa at may table of contents para sa mabilisang pag-navigate.

## Pagbasa ng PDF

Mag-import ng sarili mong mga PDF document at basahin ang mga ito offline, nakaayos sa mga category. Sinusuportahan ng reader ang paghahanap, table of contents, mga bookmark, zoom, at pagbasa nang malakas. Maaari ka ring mag-install ng mga naka-package na koleksyon ng PDF mula sa community repository.

## Maraming Wika

Maraming wika ang sinusuportahan ng Theodia, para sa interface ng app at sa nilalaman ng Biblia. Magpalit ng wika sa mga setting para mag-aral sa wikang gusto mo.

## Dark Mode at mga Tema

Pumili sa maliwanag o madilim na mode, o pumili ng tema na bagay sa gusto mo. Mahalaga ang ginhawa sa pagbabasa, lalo na sa mababang liwanag.

## Backup ng Data

I-back up ang iyong mga note, bookmark, at highlight. Panatilihing ligtas ang data mo at ilipat ito sa bagong device kung kinakailangan.

## Walang Ad, Walang Istorbo

Dinisenyo ang Theodia para sa pokus. Walang ad, walang pop-up, at walang paghahadlang. Ang teksto at ang mga study tool mo lang.
