---
title: Pagbasa nang Malakas (Text-to-Speech)
level: everyday
categories: tts
summary: Pabasahin nang malakas ang Theodia ng Biblia o isang devotional. Kung paano ito gamitin, kung paano pumili ng boses, at ano ang gagawin kapag tahimik.
---

# Pagbasa nang Malakas (Text-to-Speech)

> **Mode:** Available ang text-to-speech sa **Standard** at **Scholar** mode. Ang Focus Mode ay para lang sa malinis at walang istorbo na pagbabasa. Maaari kang magpalit ng mode sa **Settings** → **App User Mode**.

Maaaring magbasa nang malakas ang Theodia ng teksto gamit ang text-to-speech (TTS) voice ng device mo. Maaari kang makinig sa isang bersikulo, sa buong kabanata, o sa isang devotional. Kapaki-pakinabang ito para sa hands-free na pagbabasa, pakikinig habang naglalakad o bumibiyahe, pagbabasang sabay sa audio, o payapang pagpapahinga ng mata mo.

## Kung saan matatagpuan ang listen button

May makikita kang listen button sa tatlong lugar.

### 1. Sa verse menu (isang bersikulo)

Ito ang pinakamabilis na paraan para makinig sa isang bersikulo nang sabay-sabay. Buksan ang isang kabanata sa [Study Mode](theodia://help/study-mode), i-tap ang isang bersikulo para buksan ang verse menu, tapos i-tap ang **Speak** (🔊). Magsisimula ang pagbasa mula sa bersikulong iyon. May maliit na control bar na lalabas sa ibaba ng screen na may play, pause, rewind, fast-forward, at voice picker.

Hindi ipinapakita ang Speak option para sa mga interlinear Bible (MIB — Marvel Interlinear Bible — at OHGB), dahil nai-ipakita nila ang mga salita sa ibang layout na hindi natural nababasa.

### 2. Sa itaas ng isang kabanata (buong kabanata)

Kapag nagbabasa ka ng kabanata, tingnan ang hanay ng mga icon sa itaas ng screen. I-tap ang **Listen** (🔊) para simulan ang pagbasa ng buong kabanata mula sa simula. Nagiging stop button (⏹) ang button habang tumutugtog ang audio. I-tap ulit para ihinto. May lalabas na parehong control bar sa ibaba.

Maaari kang tumalon sa ibang bersikulo, at magsisimula mula sa bersikulong iyon ang Listen button doon.

### 3. Sa isang devotional

Buksan ang kahit aling araw ng devotional, tapos i-tap ang **Listen** (🔊) button sa itaas ng pagbabasa. Babasahin nang malakas ang buong teksto ng devotional, pangungusap-pangungusap. May control bar sa ibaba na nagbibigay sa iyo ng play, pause, rewind, at mga kontrol ng boses.

## Paggamit ng control bar

Habang tumutugtog ang audio, may maliit na bar na nananatiling nakikita sa ibaba ng screen. May anim na kontrol ito:

- ⏪ **Rewind** — bumalik ng isang bersikulo (o isang pangungusap sa isang devotional)
- ⏸ **Pause / ▶ Resume** — mag-pause nang nawawala ang lugar mo. I-tap muli para magpatuloy mula sa parehong pwesto.
- ⏩ **Fast forward** — lumaktaw sa susunod na bersikulo (o susunod na pangungusap sa isang devotional)
- 🎙 **Voice** — buksan ang voice picker nang hindi iiwan ang kabanata (tingnan sa ibaba)
- ⚙ **Mga option** — buksan ang extended options panel (tingnan sa ibaba)
- **Stop** — i-tap ang 🔊 button sa itaas ng screen, o ang ⏹ na pumapalit dito habang tumutugtog ang audio, para ihinto at isara ang bar.

Nagsasara ang control bar kapag natapos ang kabanata o kapag nag-tap ka ng stop.

### Mga extended option

I-tap ang ⚙ para palawigin ang mga dagdag na playback option. Nanatili lang ang mga setting na ito para sa kasalukuyang kabanata at nagre-reset kapag lumipat ka ng kabanata o tumigil sa pakikinig.

- ⏮ **Bumalik sa simula** — tumalon sa unang bersikulo ng saklaw na itinakda mo.
- **Simula** — mag-type ng numero ng bersikulo para itakda kung saan magsisimula ang pagbasa.
- **Wakas** — mag-type ng numero ng bersikulo para itakda kung saan tumitigil ang pagbasa.
- **Lahat** — i-reset ang saklaw sa buong kabanata.
- **()** — i-toggle kung bibigkasin ang parenthetical na teksto (teksto sa loob ng mga panaklong).
- 🔁 **Ulitin** — kusang muling magsimula sa simula ng saklaw kapag narating na ang dulo, na may maikling pagitan. Kung i-on mo ito nang walang itinakdang simula o wakas na bersikulo, uulitin ang buong kabanata.

### Sa mga screen ng panalangin

Ang mga creed at fixed prayer, mga gawing panalangin, at mga prayer routine ay may sariling set ng mga extended option. I-tap ang ⚙ sa control bar para palawigin ang mga ito:

- **Bilis** — i-tap ang rate (halimbawa `1x`) para pumili ng bilis ng pagbasa mula 0.1x hanggang 1.5x. Naaalala ang pinili mo at ginagamit sa susunod na pagkakataon na magbasa ka nang malakas.
- **()** — i-toggle kung bibigkasin ang parenthetical na teksto (teksto sa loob ng mga panaklong).
- 🔁 **Ulitin** — kusang muling sisimula ang panalangin mula sa simula kapag natapos na, na may maikling pagitan. Kapaki-pakinabang ito para matutunan sa memorya ang isang creed o fixed prayer.

Agad nagkakabisa ang pagpapalit ng bilis, nang hindi nawawala ang lugar mo. Ang pag-on o pag-off sa parenthetical option ay muling sisimula ang panalangin mula sa simula para maririnig ang pagbabago mula sa simula.

## Paano palitan ang boses

Maaari kang pumili kung aling boses ang gagamitin ng Theodia sa pagbabasa. Kapaki-pakinabang ito kung gusto mo ng ibang accent, ibang wika, o mas mabilis o mas mabagal na boses kaysa sa default ng device.

1. Buksan ang **Settings**.
2. Hanapin ang section na **Speech**.
3. I-tap ang **Select Voice**.
4. May lalabas na listahan ng mga boses. Ang unang row, **System Default**, ay gumagamit ng boses na gusto ng device mo. Piliin ang kahit aling ibang row para gawin itong bagong default.
5. Naka-save ang pinili mo at gagamitin sa susunod na pagkakataon na mag-tap ka ng **Listen** o **Speak**.

Maaari ka ring i-tap ang 🎙 icon sa listening control bar para buksan ang parehong picker nang hindi iiwan ang kabanata.

Lubos na nakadepende sa iyong device ang availability ng mga boses. May kanya-kanyang built-in na set ng mga boses ang iOS at Android. Maaari kang mag-install ng mas maraming boses mula sa **Accessibility** o **Language & Input** settings ng device mo. Magagamit ng Theodia ang kahit aling boses na naka-install sa iyong device.

## Mga paboritong boses

Kung maraming boses ang device mo, maaaring mabagal ang pag-scroll sa buong listahan bawat beses. Maaari kang gumawa ng maikling listahan ng **mga paboritong boses** at ipapakita lang ng mga voice picker ang mga boses na iyon.

1. Buksan ang **Settings**.
2. Hanapin ang section na **Speech**.
3. I-tap ang **Favorite Voices** (ang unang row sa itaas ng section).
4. I-tap ang **Set Favorite Voices** para buksan ang favorites screen.
5. I-tap ang play button sa tabi ng isang boses para i-preview ito. I-tap ang star para idagdag ito sa mga paborito mo. Maaari mong gawing paborito ang kahit ilang boses.
6. Bumalik. Ipinapakita na lang ngayon ng mga voice picker sa buong Theodia ang mga paborito mong boses.

Kung aalisin mo ang lahat ng paborito, babalik ang mga picker sa pagpapakita ng bawat boses. Kasama ang mga paboritong boses kapag nag-back up at nag-restore ka ng mga setting ng Theodia.

## Pagtatakda ng ibang boses bawat Biblia

Maaari mong bigyan ang bawat salin ng Biblia ng sariling boses. Kapaki-pakinabang ito kapag nagpalit ka ng mga salin na lubos na naiiba ang pagbasa — halimbawa, isang mas pormal na boses para sa King James Version at mas kuwentuhan na boses para sa isang modernong salin tulad ng NIV o NLT. Nakakatulong din ito kung nakikinig ka ng mga Biblia sa iba't ibang wika at gusto mong may tamang accent ang bawat isa.

1. Buksan ang **Settings**.
2. Hanapin ang section na **Speech**.
3. Hanapin ang **Bible Voices**.
4. I-tap ang kahit aling Biblia sa listahan.
5. Piliin ang boses na gusto mo para sa salin na iyon. Ang unang row, **System Default**, ay gumagamit ng pangunahing TTS voice mo para sa Biblias na iyon.
6. Ulitin para sa kahit aling ibang Biblia.

Ipinapakita ng header kung ilang salin ng Biblia ang may custom na boses. Ipinapakita rin ng **Select Voice**, **Commentary Voice**, **Bible Notes Voice**, at **Devotional Voice** ang isang bilang kapag may nakatakdang boses.

Sa susunod na pagkakataon na makinig ka sa isang kabanata mula sa Biblias na iyon, gagamitin ng Theodia ang boses na pinili mo. Gagamit pa rin ng pangunahing default na boses ang lahat ng ibang Biblia maliban kung palitan mo rin ang mga ito.

## Magpatuloy sa pagsasalita sa background

Sa default, tumitigil ang pagsasalita ng Theodia kapag umalis ka sa reader screen, lumipat sa ibang app, o ikinandado ang telepono mo. Naiiwasan nito ang hindi inaasahang audio kapag hindi na aktibong nagbabasa.

Para hayaang magpatuloy sa pagtugtog sa background ang pagsasalita:

1. Buksan ang **Settings**.
2. Hanapin ang section na **Speech**.
3. I-on ang **Continue speech in background**.

Kapag naka-on ito, maaari kang magpalit ng tab, bumukas ng ibang app, o ikandado ang screen at magpapatuloy sa pagbasa ang kabanata o devotional. Nanatiling aktibo ang control bar para maaari kang mag-pause o lumaktaw mula sa notification area (kung sinusuportahan ng device mo ito).

Ang pag-off sa toggle na ito habang tumutugtog na ang pagsasalita ay agad itong titigil.

## Ano ang gagawin kung hindi ito gumagana

Nakadepende sa iyong device ang text-to-speech. Ipinapadala ng Theodia ang teksto sa operating system, at binibigkas ito nang malakas ng operating system gamit ang isang boses. Kung hindi ito gumagana, subukan ang mga hakbang na ito sa pagkakasunod-sunod.

### Sinasabi ng Theodia na hindi available ang TTS

May mga device na walang TTS kahit ano. Buksan ang **Settings** at hanapin ang section na **TTS**. Kung wala ang section, hindi sinusuportahan ng device mo ang TTS sa build na ito.

### Walang laman ang listahan ng mga boses

Maaaring magpakita ang voice picker ng "no voices found." Karaniwang nangangahulugan itong hindi pa natatapos i-load ng device ang mga boses nito.

1. Buksan ang **Settings → Speech → Select Voice**.
2. Kung walang laman ang listahan, hanapin ang isang **Retest** button sa ibaba mismo ng dropdown. I-tap ito. Muling nagtatanong ang Theodia sa device tungkol sa mga boses.
3. Kung walang laman pa rin, i-check ang mga setting ng sistema ng device mo. Sa iOS, pumunta sa **Settings → Accessibility → Spoken Content → Voices** at mag-download ng boses para sa wika mo. Sa Android, pumunta sa **Settings → Language & Input → Text-to-Speech Output** at i-tap ang **Install voice data**.
4. Isara at buksan muli ang Theodia para makuha nito ang bagong boses.

Kung may nakatakdang mga paboritong boses ka at walang laman ang listahan, siguraduhing may kahit isang paborito mo na tugma sa isang boses na naka-install sa device na ito.

### Nag-tap ng Speak pero walang nangyayari

- I-check na hindi naka-silent mode ang device. Hindi magpi-play ng TTS audio ang karamihan ng mga device habang naka-silent mode.
- Siguraduhing mataas ang volume ng device.
- Subukan ang **Retest** button sa **Settings → Speech**.
- Buksan ang **Settings** at tingnan ang section na **System** sa ibaba. Dapat nagsasabing **Available** ang **TTS** row. Kung nagsasabing **Unavailable**, naka-off ang TTS sa antas ng operating system. I-enable muli ito doon, tapos buksan muli ang Theodia.

### Tumutugtog ang audio pero mali ang wika

Nagpapadala ang Theodia ng teksto sa wika ng kasalukuyang nilalaman at humihingi sa device ng boses na pinili mo. Kung para sa ibang wika ang napiling boses, maaari pa rin itong basahin ng device, pero kakaiba ang tunog nito.

1. Buksan ang **Settings → Speech → Select Voice**.
2. Piliin ang **System Default** para piliin ng device ang tama, o pumili ng boses na ang wika ay tugma sa tekstong binabasa mo.

Hindi kasalukuyang binabasa nang malakas ng Theodia ang mga Greek o Hebrew interlinear Bible. Nakatago ang mga Speak at Listen button sa mga salin na iyon.

### Tumutugtog ang audio pero tumitigil nang maaga

Kung may nawawala o hindi mabasang bersikulo, lumulaktaw ang kabanata sa susunod. Kung nagsasara mag-isa ang bar pagkatapos ng ilang bersikulo, i-tap ang **Listen** (🔊) button sa itaas ng screen para magsimulang muli.

### Tumutugtog ang pagsasalita pero hindi ko alam kung saan nagsimula

Kung i-on mo ang **Continue speech in background** at nakarinig ka mamaya ng audio pero hindi mo mahanap ang screen na nagsimula nito, maaari mo itong ihinto mula kahit saan sa app.

1. Buksan ang **Settings**.
2. Hanapin ang section na **Speech**.
3. I-tap ang pulang **Stop Speech** button sa ibaba ng section.

Agad nitong itinitigil ang kahit anong tumatakbong text-to-speech sa Theodia. Maaari ka ring buksan ang app switcher sa device mo at i-swipe palayo ang Theodia para pilitin itong tumigil.

### Masyadong mabilis o masyadong mabagal ang pagbasa

Hindi kinokontrol ng Theodia ang bilis ng pagbasa. Itinatakda ng napiling boses ang bilis. Para palitan ito:

- Sa iOS: **Settings → Accessibility → Spoken Content → Speaking Rate**.
- Sa Android: **Settings → Language & Input → Text-to-Speech Output → Speech Rate**.

## Mga tip

- Nananatiling nakikita ang control bar habang nag-navigate ka sa mga kabanata, kaya maaari kang mag-pause, lumaktaw, o magpalit ng boses nang hindi nawawala ang lugar mo.
- Binabasa ng Theodia ang mga numero ng bersikulo bilang maliliit na paghinto. Maaari mong ihinto ang bar, mag-swipe sa ibang bersikulo, tapos mag-tap ng play para magpatuloy mula doon.
- Para sa mahahabang pakikinig, i-on ang **Do Not Disturb** para hindi maiistorbo ang audio ng mga notification.
- Gumagamit ng kasalukuyang volume ng device mo ang 🔊 button. Kung saksakan mo ang mga headphone, lumilipat ang volume sa antas ng headphone.

## Pagbasa nang malakas ng isang PDF

Maaari rin basahin nang malakas ng Theodia ang mga pahina ng PDF. Buksan ang isang PDF at i-tap ang **Listen** (speaker) button sa toolbar nito. May lalabas na control bar na may play/pause, rewind, fast forward, stop, progress bar, at mga picker ng bilis at boses. Kapag natapos ang isang pahina, tuloy-tuloy ang pagbasa sa susunod na pahina nang kusa.

Gumagamit ang pagbasa ng PDF ng naka-install na searchable text ng PDF at ng parehong mga boses at bilis tulad sa pagbabasa ng Biblia.

## Mga kaugnay na gabay

- Saklaw ng gabay na [Study Mode](theodia://help/study-mode) ang verse menu at mga button sa itaas ng screen nang mas detalyado.
- Ang gabay na [Focus Mode](theodia://help/focus-mode) ay isang mas malinis na view ng pagbabasa na sumusuporta rin sa TTS gamit ang 🔊 button sa bottom bar.
- May mga fix ang gabay na [Mga Karaniwang Problema](theodia://help/common-problems) para sa iba pang mga issue sa audio, boses, at wika.
- Saklaw ng gabay na [Mga Pang-araw-araw na Devotional](theodia://help/daily-devotionals) ang pagbabasa ng devotional at kung saan matatagpuan ang listen button sa screen na iyon.
- Saklaw ng gabay na [mga PDF](theodia://help/pdfs) ang PDF reader at ang listen button nito.
