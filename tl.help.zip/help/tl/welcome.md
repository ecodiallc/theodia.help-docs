---
title: Maligayang Pagdating sa Theodia
level: beginner
categories: welcome
summary: Maikling paglilibot sa app at sa mga kaya nitong gawin para sa iyo.
---

# Maligayang Pagdating sa Theodia

Ang Theodia ay isang app sa pag-aaral ng Biblia. Tumatakbo ito sa telepono o tablet mo, kahit walang internet. Naka-save sa iyong device ang lahat ng binabasa, hinihanap, at pinag-aaralan mo.

## Ano ang kaya mong gawin

May tatlong user mode ang Theodia. Nagpapakita ang bawat mode ng ibang set ng mga feature.

- **Reader** — basahin ang Biblia sa malinis, walang istorbo na view.
- **Standard** — lahat ng nasa Reader, kasama ang mga bookmark, highlight, note, text-to-speech, search, at mga pang-araw-araw na devotional.
- **Scholar** — lahat ng nasa Standard, kasama ang mga commentary, lexicon, ang Bible Dictionary, ang AI assistant, at iba pa.

Maaari kang magpalit ng mode anumang oras sa **Settings** → **App User Mode**.

### Mga feature na available sa iyo

Anuman ang mode na pinili mo, maaari mo palaging:

- **Basahin ang Biblia.** Pumili sa maraming salin. Lumipat-lipat sa mga ito anumang oras.
- **Hanapin sa Biblia.** Maghanap ng isang salita o parirala. Ipinapakita sa iyo ng app ang bawat bersikulong tumutugma.
- **Basahin ang mga libro at devotional.** May kasamang mga klasikong Kristiyano at isang pang-araw-araw na devotional ang app.

Depende sa mode mo, maaari ka ring:

- **Makinig.** Pabasahin nang malakas ang mga bersikulo gamit ang read-aloud feature. (Standard at Scholar.)
- **Mag-note.** Sumulat ng sarili mong mga kaisipan sa tabi ng isang bersikulo. (Standard at Scholar.)
- **Mag-highlight.** Markahan ang mga paborito mong bersikulo ng kulay. (Standard at Scholar.)
- **Mag-bookmark.** I-save ang mga bersikulo para mabilis mo silang mahanap muli. (Standard at Scholar.)
- **Magtanong sa AI assistant.** Hingin ang tulong sa pag-unawa sa isang bersikulo. (Scholar lang.)

## Saan magsimula

1. Buksan ang **Bible** tab sa ibaba ng screen.
2. Pumili ng salin.
3. I-tap ang kahit aling libro para simulan ang pagbabasa.

Kung gusto mong matuto pa, narito para sa iyo ang natitirang mga gabay sa tulong. Pumili ng paksa mula sa listahan sa home page ng tulong.

## Ilang bagay na dapat malaman

- Hindi mo kailangan ng account.
- Nanatili sa iyong device ang mga note, highlight, at bookmark mo.
- Maaari mong i-back up ang mga ito. Tingnan ang gabay na [Pag-back Up ng Iyong Data](theodia://help/backups) para sa kung paano.

## Gusto ng mas maraming resources?

May kasamang ilang malayang available na bersyon ng Biblia ang app. Para sa mga dagdag na Biblia, commentary, lexicon, libro, at devotional, tingnan ang gabay na [Pagkuha ng Ibang Resources mula sa GitHub](theodia://help/getting-core-files). Ipinapakita nito sa iyo kung paano maghanap at magdagdag ng mas maraming resources mula sa GitHub page ng proyekto.

Maligayang pagdating. Umaasa kaming makatutulong ang Theodia sa pagbasa at pag-aaral mo.
