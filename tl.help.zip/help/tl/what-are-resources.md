---
title: Ano ang mga Resource?
level: beginner
categories: resources
summary: Pangkalahatang tanaw sa iba't ibang uri ng file na ginagamit ng Theodia — mga Biblia, commentary, libro, at iba pa.
---

# Ano ang mga Resource?

Sa Theodia, ang isang "resource" ay kahit anong file na nagdaragdag ng materyal sa pagbabasa o pag-aaral sa app. Ang mismong app ay isang reader at notebook lang. Ang mga Biblia, commentary, libro, at iba pang materyal na pinag-aaralan mo ay lahat hiwalay na mga file na iino-load mo.

Ipinapaliwanag ng gabay na ito ang iba't ibang uri ng resource at kung para saan ang bawat isa.

## Bakit mahalaga ito?

Kapag unang binuksan mo ang Theodia, mayroon na itong ilang bagay na babasahin. Habang nagsisiyasat ka, makakakita ka ng mga button para mag-install ng iba pa. Ang pagkilala kung anong uri ng resource ang bawat isa ay tutulong sa iyo magpasya kung ano ang idadagdag.

## Ang iba't ibang uri ng resource

Kinikilala ng Theodia ang mga file ayon sa extension nila. Iba't ibang uri ng resource ang bawat extension.

### `.bible` — isang salin ng Biblia

Ang isang salin ng Biblia ay buong kopya ng Biblia sa isang partikular na bersyon, tulad ng King James Version. May kasamang ilang salin ang Theodia at nagpapahintulot itong magdagdag ka pa.

Tingnan ang gabay na [Pag-install ng mga Salin ng Biblia](theodia://help/installing-bibles) para sa mga detalye.

### `.commentary` — isang commentary

Ang isang commentary ay isang libro ng mga study note na isinulat ng isang iskolar ng Biblia. Para sa isang partikular na bersikulo, sinasabi sa iyo ng commentary ang background, ang kahulugan, at kung paano tumutugma ang bersikulo sa iba ng Biblia.

Tingnan ang gabay na [Mga Commentary at Lexicon](theodia://help/commentaries-and-lexicons) para sa mga detalye.

### `.lexicon` — isang lexicon

Ang isang lexicon ay isang diksyunaryo ng mga salita sa Biblia. Sinasabi nito sa iyo ang orihinal na salitang Ebreo o Griyego, ang kahulugan nito, at kung paano ito ginagamit sa Biblia.

Tingnan ang gabay na [Mga Commentary at Lexicon](theodia://help/commentaries-and-lexicons) para sa mga detalye.

### `.book` — isang Kristiyanong libro

Ang isang libro ay isang mas mahabang Kristiyanong gawa, tulad ng isang klasiko mula sa kasaysayan ng simbahan. Gumagana nang katulad ng pagbasa ng Biblia ang pagbabasa ng mga libro sa app. May kasamang maliit na library ng mga malayang available na klasikong Kristiyano ang Theodia.

Tingnan ang gabay na [Pagbasa ng mga Built-in na Libro](theodia://help/reading-books) para sa mga detalye.

### `.devotional` — isang devotional

Ang isang devotional ay isang maikling pang-araw-araw na pagbabasa. Karaniwang may verse, isang maikling repleksyon, at isang panalangin o tanong na pag-isipan ang bawat entry. Maraming devotional ang dinisenyo para basahin nang isang entry kada araw sa loob ng isang taon.

Tingnan ang gabay na [Mga Pang-araw-araw na Devotional](theodia://help/daily-devotionals) para sa mga detalye.

### `.sqlite` — isang reference database

Ang isang reference database ay isang malaking lookup file na ginagamit ng app para bigyan ka ng dagdag na impormasyon habang nagbabasa. May dalawang uri:

- **Mga cross-reference** — mga listahan ng mga bersikulong konektado sa bersikulong binabasa mo.
- **Morphology** — impormasyon tungkol sa mga orihinal na salitang Ebreo o Griyego sa bersikulo.

Hindi mo binubuksan nang direkta ang mga ito. Gumagana ang mga ito sa background at nagdaragdag ng mga feature sa Bible reader. Tingnan ang gabay na [Mga Cross-Reference](theodia://help/cross-references) para sa mga detalye.

### `.data` — data ng mga salita

Ang isang word data file ay nag-iimbak ng dagdag na impormasyon tungkol sa mga orihinal na salita sa Biblia. Ginagamit ito ng lexicon at ng mga study tool. Tulad ng mga reference database, hindi mo ito binubuksan nang direkta. Ginagamit ito ng app sa background.

## Paano magdagdag ng resource

Ang **Manage Resources** screen ng app ang madaling paraan para magdagdag ng resource.

1. Buksan ang **Settings**.
2. I-tap ang **Manage Resources**.
3. I-tap ang **Install from GitHub**.
4. Sa download modal, pumili ng tab — **Bibles**, **Commentaries**, **Books**, **Devotionals**, o **Core** — tapos piliin ang gusto mo at i-tap ang **Install Selected**.
5. O i-tap ang **Install Local File** para mag-import ng file na na-download mo na.

Para sa hakbang-hakbang na paglilibot sa pagkuha ng mga file nang direkta mula sa GitHub, tingnan ang gabay na [Pagkuha ng Ibang Resources mula sa GitHub](theodia://help/getting-core-files).

## Paano alisin ang isang resource

1. Buksan ang **Settings**.
2. I-tap ang **Manage Resources**.
3. Hanapin ang resource na gusto mong alisin.
4. I-tap ang trash can icon sa tabi nito.
5. Kumpirmahing gusto mo itong alisin.

Ang pag-alis ng resource ay hindi nagbubura ng iyong mga note, highlight, o bookmark. Mananatiling ligtas ang mga iyon.

## Kung saan nakatira ang mga resources sa iyong device

Naka-imbak sa iyong device ang mga resources, hindi sa cloud. Kapag naka-install na ang isang resource, hindi mo na kailangan ng internet para basahin ito. Maaari mong i-back up ang iyong device, pero hindi inii-back up ng Theodia sa cloud ang mismong mga resources. Kung ia-uninstall at i-install muli mo ang app, kakailanganin mong i-add muli ang kahit anong resource na naka-install mo.

## Tulong at mga tanong

Kung may problema ka, tingnan ang gabay na [Saan Magtanong](theodia://help/getting-more-help). Makakatulong ang team at ang community.
