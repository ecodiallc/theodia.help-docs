---
title: AI Temelleri
level: advanced
categories: ai
summary: Anlamayı derinleştirmek için AI yardımcısının nasıl kullanılacağı.
---

# AI Temelleri

> **Mod:** AI asistanı **Scholar** modu gerektirir. Modları **Ayarlar** → **Uygulama Kullanıcı Modu** üzerinden değiştirebilirsiniz.

Theodia'nın bir AI asistanı vardır. Bir ayeti anlamanıza, soru yanıtlamanıza ya da İncil konularını konuşmanıza yardımcı olabilir.

## AI nasıl açılır

AI varsayılan olarak kapalıdır. Açmak için:

1. **Ayarlar**'ı açın.
2. **Yapay Zeka Asistanı**'na dokunun.
3. Açmak için düğmeye dokunun.

## AI nasıl açılır

Ekranın altındaki **AI** sekmesine dokunun. Bir sohbet penceresi açılır.

## Nasıl soru sorulur

Alttaki kutuya dokunun. Sorunuzu yazın. **Gönder**'e dokunun.

Sorabileceğiniz bazı örnekler:

- "Yuhanna 3:16 ne anlama geliyor?"
- "Romalılar kitabından bana bahset."
- "Ruhun meyvesi nedir?"
- "Matta ve Luka'daki Dağ Vaazını karşılaştır."

## Belirli bir ayet hakkında nasıl soru sorulur

1. Bir bölüm açın.
2. Ayet menüsünü açmak için bir ayete dokunun.
3. **AI Yorumu**'na dokunun.

Ayet AI'ya gönderilir. AI paneli, ayet önceden doldurulmuş şekilde açılır. "Bu ne anlama geliyor?" ya da "Bunu nasıl uygulamalıyım?" gibi bir soru ekleyebilirsiniz.

## Bilmeniz gereken önemli noktalar

- AI bir araçtır, bir kişi değildir. Hata yapabilir.
- AI'ın yanıtlarını her zaman İncil'in kendisiyle karşılaştırarak kontrol edin.
- AI için internet gerekebilir. Çevrimdışı çalışmaz.
- AI'yi kullandığınızda sorularınız, ayet bağlamı ve API anahtarınız seçtiğiniz uç noktaya gönderilir. Bunu ilk kez yaptığınızda uygulama sizden izin ister ve tam olarak neyin gönderildiğini gösterir. Bu izni daha sonra **Ayarlar → Yapay Zeka Asistanı → Uzak AI Veri Paylaşımı** bölümünden değiştirebilir ya da geri alabilirsiniz.
- Bazı bölgelerde, örneğin Çin anakarası App Store derlemesinde, AI asistanı sunulmaz. Bu derlemede yalnızca çevrimdışı İncil özellikleri kullanılabilir.

## Sohbetleri nasıl yönetilir

AI ekranı geçmiş sohbetlerin bir listesini tutar. Bu listeden eski bir sohbeti açabilir, yeni bir tane başlatabilir ya da artık ihtiyaç duymadığınız birini silebilirsiniz.

## AI ile daha derine inin

Bu sayfa temelleri kapsar. Theodia'nın AI'sı sohbet etmekten çok daha fazlasını yapabilir. Sıradaki adımlar burada:

- **[AI Özellikleri](theodia://help/ai-features)** — Theodia'nın yapabileceği her şeyi keşfedin: Yunanca ve İbranicede tek dokunuşla ayet incelemesi, çapraz referans zincirleri, vaaz taslakları, dua oluşturma, özgün dil biçimbilimi, sözlük aramaları ve eller serbest uygulama gezinmesi. Bu, AI'yi bir sohbet botundan tam bir çalışma ortağına dönüştürmeyi gösteren kılavuzdur.
- **[Daha İyi AI Komutları Yazmak](theodia://help/ai-prompts)** — Zengin ve doğru yanıtlar alan sorular sormanın sanatını öğrenin. İsteğinizi ifade etme şeklinizdeki küçük değişiklikler, AI'dan çok daha derin yanıtlar almanızı sağlayabilir.
- **[Bir AI Modeli Seçmek](theodia://help/choosing-a-model)** — Her AI modeli eşit değildir. Hangi modellerin Theodia'nın yerleşik araçlarını (ayet açma ve kutsal yazı arama gibi) desteklediğini ve hangilerinin AI'yi gerçek bir eller serbest İncil çalışma asistanına dönüştürdüğünü öğrenin.
- **[GitHub Models](theodia://help/github-models)** — Theodia için önerilen ücretsiz sağlayıcı. Bir GitHub hesabıyla ücretsiz API anahtarı alın ve cömert bir günlük kota üzerinden soru sormaya başlayın. Kredi kartı yok, abonelik yok.
- **[API Anahtarları ve Maliyetler](theodia://help/ai-keys-and-costs)** — API fiyatlandırmasının sağlayıcılar arasında nasıl çalıştığını ve maliyetleri neredeyse sıfırda nasıl tutacağınızı anlayın.
