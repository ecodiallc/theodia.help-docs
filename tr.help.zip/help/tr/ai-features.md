---
title: AI Özellikleri
categories: ai
level: advanced
summary: Theodia'nın AI'sının yapabildiklerini keşfedin — ayet ayet incelemeden vaaz hazırlığına, özgün dil araştırmasından eller serbest gezinmeye.
---

# AI Özellikleri

> **Mod:** AI asistanı **Scholar** modu gerektirir. Modları **Ayarlar** → **Uygulama Kullanıcı Modu** üzerinden değiştirebilirsiniz.

Theodia'nın AI asistanı Theophilus, yalnızca bir sohbet botu değildir. İncil'i sizinle birlikte okuyabilen, yorumlar arayan, kutsal yazı aramaları yapabilen, notlarınızı yöneten, hatta uygulamada gezinebilen — ses ya da yazıyla çalışan — bir çalışma ortağıdır.

Theophilus ilk kez bir AI uç noktasına veri göndermeden önce uygulama, neyin gönderildiğini açıklayan ve izninizi isteyen bir onay penceresi gösterir. Bu izni dilediğiniz zaman **Ayarlar → Yapay Zeka Asistanı → Uzak AI Veri Paylaşımı** bölümünden değiştirebilir ya da geri alabilirsiniz.

## AI Ayet Sohbeti: Tek bir Ayeti Derinlemesine İnceleyin

**AI Ayet Sohbeti**, Theodia'nın AI deneyiminin kalbidir. Herhangi bir bölümü okurken bir ayet numarasına dokunun (ya da ayet metnine uzun basın) ve **AI Yorumu**'nu seçin. O ayet önceden yüklenmiş bir sohbet paneli açılır. AI tam olarak ne okuduğunuzu bilir ve sizinle birlikte keşfetmeye hazırdır.

### Tek dokunuşla başlangıçlar

Ne soracağınızdan emin değil misiniz? Panel sekiz hazır başlangıç gösterir:

- **Bu ayeti açıkla** — Anlamın ve önemin net, düşünceli bir çözümlemesini alın.
- **Özgün dil** — İngilizce metnin arkasındaki Yunanca ya da İbranice kelimeleri, harf çevirilerini ve sözlük tanımlarını görün.
- **Tarihsel bağlam** — Ayetin çevresindeki kültürü, siyaseti ve olayları öğrenin.
- **Metinsel bağlam** — Ayetin bulunduğu paragrafa, bölüme ve kitaba nasıl yerleştiğini görün.
- **Ana temalar** — Bu ayetin İncil ilahiyatına kattığı büyük fikirleri keşfedin.
- **Hayatıma uygula** — Bugün harekete geçirebileceğiniz pratik, kişisel uygulamalar alın.
- **Dua oluştur** — Ayeti, diline ve hakikatlerine örnek alınmış bir duaya dönüştürün.
- **Vaaz taslağı oluştur** — Girişi ve sonucu olan, vaaz etmeye hazır üç noktalı bir taslak alın.

Herhangi bir başlangıca dokunun; AI hemen çalışmaya başlar. Ardından kendi sorularınızı sorabilir, açıklama isteyebilir ya da sohbeti yeni bir yöne çekebilirsiniz.

### Gerçek bir sohbet gibi sürdürün

AI sohbetteki son birkaç mesajı hatırlar; böylece doğal biçimde daha derine inebilirsiniz:

- "Bunu daha basit söyleyebilir misin?"
- "Özgün Yunanca metin burada ne diyor?"
- "Buna bağlanan çapraz referansları göster."
- "Bu ayeti üç farklı çeviride karşılaştır."
- "Bu, modern iş hayatında nasıl görünür?"
- "Bir ebeveyn için üç uygulama daha ver."

Sohbet ayete bağlı kalır; böylece her yanıt okuduğunuz metne dayanır.

### Herhangi bir İncil referansına dokunun

AI başka bir ayetten söz ettiğinde — örneğin "Bu, Romalılar 8:28'i yansıtıyor" — referans **dokunulabilir bir bağlantı** olarak görünür. Dokunduğunuzda uygulama İncil okuyucuda o pasaja atlar. Sohbeti terk etmeden referans zincirini keşfedebilirsiniz.

## AI, Ayet Sohbetinin Ötesinde Neler Yapabilir

Theophilus, Theodia'nın tüm içeriğine erişebilir — İnciller, yorumlar, sözlükler (leksiklar), ansiklopedik sözlükler, kitaplar, günlük öğretiler, notlarınız, yer imleriniz ve vurgularınız. Bunun pratikte ne anlama geldiği şöyledir.

### Kutsal yazıyı okuma ve gezinme

- **Herhangi bir ayeti ya da bölümü oku** — "Yuhanna 3:16'yı WEB'de oku" ya da "Mezmur 23'ü sesli oku."
- **Pasajları okuyucuda aç** — "Beni Yaratılış 1'e götür" ya da "Romalılar 8:28'i aç."
- **Sürümleri karşılaştır** — "Yuhanna 3:16'yı tüm İncillerimde göster."
- **İncil'de ara** — "Bağışlanmayla ilgili ayetleri bul" ya da "anlayışı aşan barış" ifadesini ara."
- **Çapraz referanslar al** — "Yeşaya 53:5 ile ilgili başka hangi ayetler var?"
- **Bölüm başlıklarını oku** — "Matta 5'teki alt başlıklar neler?"

### Özgün dilleri keşfedin

- **Leksik (sözlük) aramaları** — "Yuhanna 3:16'daki 'agape' Yunanca kelimesi ne anlama gelir?" ya da "Strong G26'ya bak."
- **Biçimbilim (morfoloji)** — "Romalılar 8:28'deki Yunanca fiilleri çözümle" ya da "V-PAI-3S biçimbilim kodu ne anlama gelir?"
- **Kelime Bilgisi** — AI, uygulamada gördüğünüz kelime kelime çözümlemeyi — harf çevirisi, anlam, dilbilgisi ve Strong numaraları — görebilir.

### Yorumları ve çalışma kitaplarını okuyun

- **Ayet yorumu** — "Matthew Henry Efesliler 2:8 hakkında ne diyor?"
- **Bölüm yorumu** — "Romalılar 8 için bölüm genel görünümünü ver."
- **Kitap yorumu** — "Vahiy üzerine kitap düzeyindeki yorumu özetle."
- **Çalışma kitapları** — "Hymn Lyrics English kitabından bir bölüm oku" ya da "kitaplarımada 'sabır' ara."
- **Günlük öğretiler** — "Bugünün günlüğünü oku" ya da "kaygıyla ilgili bir günlük bul."

### Sözlüklerde arama yapın

- "Melkisedek kimdi?"
- "İncil sözlüğü Gilgal hakkında ne diyor?"
- "Easton'da 'kefaret' kelimesine bak."

### Çalışma hayatınızı yönetin

AI kişisel verileriniz üzerinde işlem yapabilir — bunlar her zaman cihazınızda yerel olarak saklanır:

- **Yer imleri** — "Bu ayeti Vaaz Hazırlığı klasörüme kaydet" ya da "yer imlerimi listele."
- **Vurgular** — "Yuhanna 3:16'yı sarıyla vurgula" ya da "tüm vurgularımı göster."
- **Notlar** — "Bu ayete bir İncil notu oluştur" ya da "Yaratılış 1 için notlarımı oku."
- **Çalışma notları** — "Bu sohbeti çalışma notu olarak kaydet" ya da "Romalılar İncelemesi adında yeni bir çalışma defteri oluştur."
- **Klasörler** — "Sabah Öğretisi adında bir klasör oluştur" ya da "Yuhanna 3:16 yer imimi Dua klasörüne taşı."

### Uygulama ayarlarını değiştirin

- "Koyu moda geç."
- "BSB'yi varsayılan İncil'im yap."
- "NET ile paralel İncilleri aç."
- "Yazı boyutunu büyüt."

### Sesli okuma

- "Mezmur 23'ü sesli oku" — AI herhangi bir pasaj, kitap ya da not için metinden konuşmayı başlatabilir.
- "Okumayı durdur" — TTS'yi dilediğiniz an duraklatın.

## Sohbetlerinizi Kaydedin

Her AI ayet sohbeti kaydedilebilir. Sohbet panelindeki menüye dokunun ve şunu seçin:

- **İncil Notu Olarak Kaydet** — Sohbetin tamamını İncil okuyucudaki ayet notuna ekler.
- **Çalışma Notu Olarak Kaydet** — Sohbeti, daha sonra bakmak üzere Çalışma Notları kitabınıza saklar.

Böylece hızlı bir AI keşfi, sonradan gözden geçirebileceğiniz, düzenleyebileceğiniz ya da vaazlara temel yapabileceğiniz kalıcı çalışma malzemesine dönüşür.

## Tam AI Sekmesi

Ayet sohbet panelinin ötesinde Theodia'nın alt gezinmede ayrı bir **AI** sekmesi vardır. Burası özgür biçimli bir sohbet alanıdır — önceden seçilmiş bir ayet olmadan her şeyi sorabilirsiniz. Şunlar için kullanın:

- Tüm İncil'i kapsayan konu incelemeleri
- Vaaz araştırması ve taslak oluşturma
- Kitaplar arası ilahiyat temalarını karşılaştırma
- Günlük öğreti ve dua yönlendirmeleri
- İncil bilmece soruları ve okuma planları
- Uygulama yardımı — "Paralel İnciller nasıl çalışır?"

Sohbetleriniz otomatik kaydedilir. Geçmiş sohbetlere dönebilir, yenilerini başlatabilir ve eski sohbetleri silebilirsiniz.

## Başlamanız İçin Fikirler

AI'yi kullanmanın heyecan verici bazı yolları. Bir tane seçin ve bugün deneyin.

**Kişisel Gelişim**

- "Filipililer 4:6–7'yi açıkla ve kendimi kaygılı hissettiğimde için bir dua ver."
- "İncil dinlenme hakkında ne diyor? Bana beş ayet bul ve her birini açıkla."

**Aile ve Ebeveynlik**

- "Efesliler 6:4 modern ebeveynliğe nasıl yol göstermeli? Bana üç pratik kural ver."
- "Çocuk yetiştirmeyle ilgili ayetler bul ve bana sesli oku."

**Vaaz ve Öğretim Hazırlığı**

- "Romalılar 8:28 üzerine, girişi, üç noktası ve sonucu olan 25 dakikalık bir vaaz taslağı çıkar."
- "Yorumlarım, Efesliler 6'daki 'Tanrı'nın zırhı' hakkında ne diyor?"
- "Matta'daki Dağ Vaazını Luka'nın sürümüyle karşılaştır. Farklar neler?"

**Özgün Dil İncelemesi**

- "Yuhanna 1:1'deki her kelimenin biçimbilimini göster."
- "Yeni Antlaşma'da 'agape' ile 'philia' arasındaki fark nedir?"

**Günlük Öğreti Derinliği**

- "Bugünün günlüğünü oku ve onu Mezmurlar'daki bir ayete bağla."
- "Ruhun meyvesi üzerine yedi günlük bir öğreti taslağı ver."

**Çapraz Referans Zincirleri**

- "Yeşaya 53:5'ten başla ve 'yaralar' ve 'şifa' temasını Yeni Antlaşma boyunca izle."
- "'Antlaşma' kavramı Yaratılış'tan İbranilere kadar nerede geçer?"

**Ezber ve Tekrar**

- "İncil kitaplarını sırayla bana soru sorarak yokla."
- "Romalılar'ın her bölümünün ana fikrini özetleyen bir çalışma notu oluştur."

## Birkaç Önemli Not

- AI bir **araçtır**; İncil'in ya da pastoral yol göstermenin yerine geçmez. Yanıtlarını her zaman Kutsal Yazı'nın kendisiyle karşılaştırın.
- AI'yi kullandığınızda sorularınız internet üzerinden sağlayıcının sunucularına gider. Çoğu sağlayıcı verilerinizle model eğitmez, ama metin cihazınızdan çıkar.
- AI hata yapabilir. Yorumları, sözlükleri ve İncil metnini son otorite olarak kullanın.

## Özet

Theodia'nın AI'sı İncil çalışmasını daha hızlı, daha derin ve daha kişisel yapmak üzere tasarlanmıştır. Kafa karıştırıcı bir ayetin tek cümlelik açıklamasını, eksiksiz bir vaaz taslağını, bir Yunanca kelime incelemesini ya da tüm İncil'i kapsayan bir çapraz referans zincirini isteyin — Theophilus yardıma hazırdır. Bir ayete dokunun, bir soru sorun ve sohbetin sizi nereye götürdüğünü görün.
