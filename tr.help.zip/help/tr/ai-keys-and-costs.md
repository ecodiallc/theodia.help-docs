---
title: API Anahtarları ve Maliyetler
level: advanced
categories: ai
summary: Neden API anahtarına ihtiyacınız var, nasıl alırsınız ve uzak bir AI modelini kullanmak ortalama ne kadara mal olur.
---

# API Anahtarları ve Maliyetler

> **Mod:** AI asistanı **Scholar** modu gerektirir. Modları **Ayarlar** → **Uygulama Kullanıcı Modu** üzerinden değiştirebilirsiniz.

AI asistanı uzak AI modellerine bağlanır. Birini kullanmak istiyorsanız bir API anahtarına ihtiyacınız var. Bu sayfa nedenini, nasıl alacağınızı ve genellikle ne kadara mal olduğunu açıklar.

## Neden bir API anahtarına ihtiyacınız var

Uzak bir AI modeli internet üzerindeki bir sunucuda yaşar. API anahtarı, sunucuya "bu kişinin soru sormasına izin veriliyor" diyen bir tür parola gibidir. Anahtar olmadan sunucu yanıt vermez.

Uygulama yerleşik bir anahtar sunmaz. Kendi hesabınızı bir sağlayıcıda açmanız ve anahtarınızı uygulamaya yapıştırmanız gerekir.

## API anahtarı nasıl alınır

1. Theodia'da **Ayarlar**'ı açın.
2. **Yapay Zeka Asistanı**'na dokunun.
3. **Uzak model**'i seçin.
4. Listeden bir sağlayıcı seçin ya da **Özel**'i seçip bir taban URL girin.
5. Sağlayıcının anahtar sayfasındaki bağlantıya dokunun. Hesabınız yoksa bir hesap oluşturun.
6. Sağlayıcının sitesinde yeni bir API anahtarı oluşturun.
7. Anahtarı kopyalayın ve Theodia'ya yapıştırın.
8. Çalıştığından emin olmak için **Bağlantıyı sına**'ya dokunun.

## Desteklenen sağlayıcılar

Theodia, OpenAI uyumlu bir API kullanan herhangi bir sağlayıcıya bağlanabilir. Uygulamada hazır bağlantısı olanlar şunlardır:

- **GitHub Models** — github.com/marketplace/models (ücretsiz günlük kota, önerilen)
- **OpenAI** — platform.openai.com
- **OpenRouter** — openrouter.ai
- **Anthropic** — console.anthropic.com
- **Groq** — console.groq.com
- **Mistral** — console.mistral.ai
- **Together AI** — api.together.xyz

Kendi sunucunuzu çalıştırıyorsanız ya da farklı bir hizmet kullanıyorsanız **Özel** bir taban URL de kullanabilirsiniz.

## Ne kadar tutar?

Çoğu sağlayıcı **token** başına ücret alır. Bir token kabaca bir kelime ya da kelimenin bir parçasıdır. Gönderdiğiniz tokenlar (sorunuz) için de, AI'nın geri gönderdiği tokenlar (yanıt) için de ödeme yaparsınız.

### Tipik fiyatlar

Fiyatlar değişir, ancak 2026 ortası itibarıyla kabaca şöyledir:

- **Küçük hızlı modeller** (daha ucuz GPT-3.5 sınıfı uç noktalar gibi) bin token başına birkaç kuruşun altında tutar.
- **Orta seviye modeller** (GPT-4o ya da Claude Sonnet gibi) genellikle bin token başına birkaç sent tutar.
- **Büyük akıl yürütme modelleri** (GPT-4.5 ya da Claude Opus gibi) bin token başına on ila yirmi sent tutabilir.

Theodia'da tipik bir İncil sorusu toplamda birkaç yüz ile birkaç bin token kullanabilir. Bu da çoğu sorunun **bir sentin altından birkaç sana** mal olacağı anlamına gelir.

### Maliyeti düşük tutma ipuçları

- Daha ucuz bir modelle başlayın. Çoğu İncil sorusu en pahalı modeli gerektirmez.
- Farklı modelleri denemek ve fiyatları karşılaştırmak istiyorsanız Groq ya da OpenRouter kullanın.
- Sağlayıcının sitesindeki kullanım panelinizi izleyin.

## GitHub Models

[GitHub Models](https://github.com/marketplace/models), abonelik gerektirmeyen ücretsiz bir kota sunar. Tek ihtiyacınız olan ücretsiz bir GitHub hesabı ve model okuma izni olan bir kişisel erişim anahtarıdır.

**Nasıl kurulur:**

1. [github.com/settings/tokens](https://github.com/settings/tokens) adresine gidin ve bir **Kişisel erişim anahtarı (klasik)** oluşturun.
2. `models:read` kapsamını verin (ya da yalnızca modeller iznini seçin).
3. Theodia'da sağlayıcı olarak **GitHub Models**'i seçin ve anahtarınızı yapıştırın.

**Ücretsiz kota modelleri:**

- `openai/gpt-4.1-nano` — **dakikada 15 istek, günde 150 istek**
- `openai/gpt-4.1-mini` — **dakikada 15 istek, günde 150 istek**
- `openai/gpt-4.1` — **dakikada 10 istek, günde 50 istek**
- `openai/gpt-4o` — **dakikada 10 istek, günde 50 istek**

Bu sınırlar her gün sıfırlanır ve düzenli İncil çalışması için fazlasıyla yeterlidir.

Ekran görüntüleriyle birlikte adım adım tam kılavuz için ayrıntılı [GitHub Models](theodia://help/github-models) sayfasına bakın.

## Gizlilik notu

Uzak bir AI modeli kullandığınızda uygulama önce, neyin gönderildiğini açıklayan bir onay penceresi gösterir: mesajlarınız, ayet ya da bölüm bağlamı, araç çağrıları ve sonuçları, yapılandırılan model adı ve istek başlığında API anahtarınız. İstek, yapılandırdığınız uç noktaya doğrudan gider; Theodia üzerinden geçmez. Çoğu sağlayıcı verilerinizi modellerini eğitmek için kullanmaz, ama metin cihazınızdan çıkar. İzni dilediğiniz zaman **Ayarlar → Yapay Zeka Asistanı → Uzak AI Veri Paylaşımı** bölümünden değiştirebilir ya da geri alabilirsiniz.

## Özet

- AI asistanını kullanmak için bir API anahtarına ihtiyacınız var.
- Bir sağlayıcıyla hesap oluşturun, anahtar üretin ve Theodia'ya yapıştırın.
- Çoğu soru birkaç sent ya da daha azına mal olur.
