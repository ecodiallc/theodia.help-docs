---
title: AI Asistanı
level: advanced
category: ai
summary: Anlamayı derinleştirmek için AI yardımcısının nasıl kullanılacağı.
---

# AI Asistanı

Theodia'nın bir AI asistanı vardır. Bir ayeti anlamanıza, soru yanıtlamanıza ya da İncil konularını konuşmanıza yardımcı olabilir.

## AI nasıl açılır

AI varsayılan olarak kapalıdır. Açmak için:

1. **Ayarlar**'ı açın.
2. **Yapay Zeka Asistanı**'na dokunun.
3. Açmak için düğmeye dokunun.

Bir hesap ya da anahtar kurmanız gerekebilir. Uygulama size yol gösterecektir.

## AI nasıl açılır

Ekranın altındaki **AI** sekmesine dokunun. Bir sohbet penceresi açılır.

## Nasıl soru sorulur

Alttaki kutuya dokunun. Sorunuzu yazın. **Gönder**'e dokunun.

Sorabileceğiniz bazı örnekler:

- "Yuhanna 3:16 ne anlama geliyor?"
- "Romalılar kitabından bana bahset."
- "Ruhun meyvesi nedir?"
- "Matta ve Luka'daki Dağ Vaazını karşılaştır."

## Belirli bir ayet hakkında nasıl soru sorulur

1. Bir bölüm açın.
2. Ayet menüsünü açmak için bir ayete dokunun.
3. **AI Yorumu**'na dokunun.

Ayet AI'ya gönderilir. AI paneli, ayet önceden doldurulmuş şekilde açılır. "Bu ne anlama geliyor?" ya da "Bunu nasıl uygulamalıyım?" gibi bir soru ekleyebilirsiniz.

## Bilmeniz gereken önemli noktalar

- AI bir araçtır, bir kişi değildir. Hata yapabilir.
- AI'ın yanıtlarını her zaman İncil'in kendisiyle karşılaştırarak kontrol edin.
- AI için internet gerekebilir. Çevrimdışı çalışmaz.
- AI'yi kullandığınızda sorularınız, ayet bağlamı ve API anahtarınız seçtiğiniz uç noktaya gönderilir. Bunu ilk kez yaptığınızda uygulama sizden izin ister ve tam olarak neyin gönderildiğini gösterir. Bu izni daha sonra **Ayarlar → Yapay Zeka Asistanı → Uzak AI Veri Paylaşımı** bölümünden değiştirebilir ya da geri alabilirsiniz.
- Bazı bölgelerde, örneğin Çin anakarası App Store derlemesinde, AI asistanı sunulmaz. Bu derlemede yalnızca çevrimdışı İncil özellikleri kullanılabilir.

## Sohbetleri nasıl yönetilir

AI ekranı geçmiş sohbetlerin bir listesini tutar. Bu listeden eski bir sohbeti açabilir, yeni bir tane başlatabilir ya da artık ihtiyaç duymadığınız birini silebilirsiniz.

Daha ileri düzey ipuçları için [Daha İyi AI Komutları Yazmak](theodia://help/ai-prompts) kılavuzuna bakın.
