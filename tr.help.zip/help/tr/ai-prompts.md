---
title: Daha İyi AI Komutları Yazmak
level: advanced
categories: ai
summary: AI asistanına iyi yanıtlar alacak şekilde nasıl soru sorulacağı.
---

# Daha İyi AI Komutları Yazmak

> **Mod:** AI asistanı **Scholar** modu gerektirir. Modları **Ayarlar** → **Uygulama Kullanıcı Modu** üzerinden değiştirebilirsiniz.

"Komut" (prompt), AI'ya verdiğiniz soru ya da yönergedir. Daha iyi komutlar daha iyi yanıtlar getirir. Bu kılavuz size nasıl yapacağınızı gösterir.

## Net olun

Kötü: "Bana sevgiden bahset."
Daha iyi: "1. Korintliler 13'te Pavlus ne tür bir sevgiden söz ediyor ve bu, romantik sevgiden nasıl farklı?"

Ne kadar çok ayrıntı verirseniz yanıt o kadar faydalı olur.

## Bağlam verin

Kötü: "Bu ayet ne anlama geliyor?"
Daha iyi: "Romalılar 8'i küçük bir grupla okuyorum. 'Mahkûmiyet yok' ifadesi bu bölümde ne anlama geliyor ve bölümün geri kalanıyla nasıl bağlantılı?"

Bağlam, AI'nın yanıtını sizin durumunuza uyarlamasına yardım eder.

## Bir seferde tek bir şey isteyin

Kötü: "Bana dua, iman ve şifadan bahset."
Daha iyi: "Önce bana duadan bahset. Sonra imanı sorarım."

Bir seferde tek bir şey istemek yanıtların odaklı kalmasını sağlar.

## AI'dan bir rol üstlenmesini isteyin

AI'dan belirli bir sesle yanıt vermesini isteyebilirsiniz. Örneğin:

- "Yeni bir Hristiyan'a öğretir gibi yanıtla."
- "Bir İncil bilgini olarak yanıtla."
- "10 yaşındaki bir çocuk için yanıtla."

AI yanıtını role göre uyarlar.

## Devam soruları kullanın

İlk yanıt tam istediğiniz gibi değilse devam sorusu sorun:

- "Bunu daha basit söyleyebilir misin?"
- "Bana bir örnek verebilir misin?"
- "Özgün Yunanca metin ne diyor?"
- "Bu, İncil'in başka neresinde karşımıza çıkar?"

İyi bir sohbet karşılıklı gidiş gelerdir. AI son birkaç mesajı hatırlar.

## AI'ın yanıtlarını kontrol edin

AI hata yapabilir. Bir araçtır, bir öğretmen değil.

- AI'ın yanıtını, sizi yönlendirdiği ayetlerle karşılaştırın.
- İkinci bir görüş için uygulamadaki yorumları ve sözlükleri kullanın.
- Yanıt doktrinle ilgiliyse bir papaza ya da güvendiğiniz bir arkadaşınıza sorun.

## Yaygın komut kalıpları

İyi işleyen birkaç örnek:

- "Bu ayeti bana, yeni bir Hristiyan'mışım gibi açıkla."
- "Bu bölümün ana fikri tek cümleyle nedir?"
- "Bu pasajdan günlük hayatım için üç uygulama listele."
- "Bu ayeti vaaz etmeden önce kendime sormam gereken sorular neler?"
