---
title: Uygulama Kullanıcı Modu
level: beginner
categories: [user-mode]
summary: Uygulamada hangi özelliklerin kullanılacağını belirlemek için Okuyucu, Standart ve Scholar modlarından birini seçin.
---

# Uygulama Kullanıcı Modu

Theodia, hangi özellikleri göreceğinizi belirleyen üç kullanıcı modu sunar. Uygulamayı nasıl kullanmak istediğinize uyan modu seçin.

## Okuyucu

En yalın mod. Okuyucu modu, dikkatin dağılmayan İncil okuması içindir.

- Herhangi bir İncil çevirisini okuyun
- Temiz, tam ekran okuma için Odak Modu'nu kullanın
- Kitaplar ve bölümler arasında gezinin
- Çalışma aracı, AI, yer imi ve vurgu yoktur

Theodia'nın size fazlalığı olmayan temiz bir dijital İncil gibi hissettirilmesini istiyorsanız Okuyucu modu idealdir.

## Standart

Standart mod, kişisel İncil çalışması için günlük özellikler ekler.

Okuyucu modundaki her şey, ayrıca:

- Yer imleri, vurgular ve notlar
- Metinden konuşma
- Ayet menülü Çalışma Modu okuyucu
- Paralel İnciller
- Komut girişi
- İncil'de arama
- Günlük öğretiler ve yerleşik kitaplar

Gelişmiş çalışma araçları olmadan İncil'i okumak, işaretlemek ve aramak isteyen çoğu kullanıcı için Standart mod doğru seçimdir.

## Scholar

Tüm özelliklere sahip mod. Scholar modu, derin İncil çalışması için Theodia'daki her aracın kilidini açar.

Standart moddaki her şey, ayrıca:

- Yorumlar ve leksiklar (sözlükler)
- Çapraz referanslar
- İncil Sözlüğü
- Kelime Bilgisi (Strong aramaları)
- AI asistanı ve AI Yorumu
- Başlatıcı Menüsü

Scholar modu; papazlar, ilahiyat öğrencileri ve özgün dil araçları ile AI destekli çalışma yardımcıları isteyen herkes için tasarlanmıştır.

## Mod nasıl değiştirilir

1. **Ayarlar**'ı açın.
2. **Uygulama Kullanıcı Modu**'na dokunun.
3. **Okuyucu**, **Standart** ya da **Scholar** seçin.

Değişiklik hemen etkili olur. Bulunduğunuz modda erişiminiz olmayan menüler ve düğmeler gizlenir.

## Mod seçimi

- **Okuyucu** — Yalnızca İncil'i okumak istiyorsunuz, başka hiçbir şey değil.
- **Standart** — Yer imleri, vurgular, notlar, arama ve günlük öğretiler istiyorsunuz.
- **Scholar** — AI, yorumlar ve leksiklar dahil her çalışma aracını istiyorsunuz.

Modları dilediğiniz zaman değiştirebilirsiniz. Yer imleriniz, vurgularınız ve notlarınız mod değiştirdiğinizde asla silinmez; yalnızca onları destekleyen bir moda dönene kadar gizlenirler.
