---
title: Verilerinizi Yedekleme
level: everyday
categories: settings
summary: Notlarınızı, vurgularınızı, yer imlerinizi ve gizli anahtarlarınızı nasıl kaydedip geri yükleyeceğiniz.
---

# Verilerinizi Yedekleme

Notlarınız, vurgularınız, yer imleriniz ve ayarlarınız cihazınızda saklanır. Telefonunuzu kaybederseniz, yeni bir telefon alırsanız ya da uygulamayı kaldırırsanız bu veriler kaybolabilir. Bu kılavuz size nasıl yedekleyeceğinizi gösterir.

## Yedekleme ayarları nasıl açılır

1. **Ayarlar**'ı açın.
2. **Uygulama Yedekleme**'ye dokunun.

## Uygulama yedeklemesi nasıl yapılır

1. **Ayarlar**'ı açın.
2. **Uygulama Yedekleme**'ye dokunun.
3. **Uygulama Yedeklemesi Oluştur**'a dokunun.
4. Dosyayı kaydetmek için cihazınızda bir klasör seçin. Bir bulut sürücüsü de seçebilirsiniz.
5. Uygulama tüm verilerinizi içeren tek bir dosya oluşturur. Dosya `.zip` ile biter.

## Yedekleme ne sıklıkla yapılmalı

Şu durumlarda yedekleme yapın:

- Çok sayıda not yazdıktan sonra.
- Cihazınızın işletim sistemini güncellemeden önce.
- Uygulamayı kaldırmadan ya da telefon değiştirmeden önce.

İyi bir alışkanlık ayda bir yedeklemedir. Bazı insanlar her hafta yedekler.

## Uygulama yedeklemesinden geri yükleme

1. **Ayarlar**'ı açın.
2. **Uygulama Yedekleme**'ye dokunun.
3. **Uygulama Yedeklemesinden Geri Yükle**'ye dokunun.
4. `.zip` yedek dosyasını seçin.
5. Her veri türü için (notlar, vurgular, yer imleri vb.) cihazdakinin tutulmasını, yedekle değiştirilmesini ya da atlanmasını seçin.
6. **Geri Yükle**'ye dokunun.

Uygulama verilerinizi yedekteki verilerle değiştirir. Bu şunları içerir:

- Notlar
- Vurgular
- Yer imleri
- Yer imi klasörleri
- Ayarlar (tema, yazı boyutu, dil)

## Gizli Anahtarlar Yedeklemesi

**Uygulama Yedeklemeniz** AI API anahtarınız ya da GitHub jetonunuz gibi hassas gizli anahtarları **içermez**. Bunları ayrıca yedeklemek için **Gizli Anahtarlar Yedeklemesi**'ni kullanın.

### Gizli anahtar yedeklemesi kaydetme

1. **Ayarlar**'ı açın.
2. **Uygulama Yedekleme**'ye dokunun.
3. **Gizli Anahtarlar Yedeklemesi** altında **Gizli Anahtar Yedeklemesini Kaydet**'e dokunun.
4. Güçlü bir parola girin ve onaylayın.
5. Uygulama gizli anahtarlarınızı şifreler ve şifrelenmiş dosyayı paylaşır. Onu güvenli bir yere kaydedin.

### Gizli anahtar yedeklemesini geri yükleme

1. **Ayarlar**'ı açın.
2. **Uygulama Yedekleme**'ye dokunun.
3. **Gizli Anahtarlar Yedeklemesi** altında **Gizli Anahtar Yedeklemesini Geri Yükle**'ye dokunun.
4. Şifrelenmiş gizli anahtar yedek dosyasını seçin.
5. Kaydederken kullandığınız parolanın aynısını girin.
6. Gizli anahtarlarınız geri yüklenir.

> **Önemli:** Parolayı unutursanız gizli anahtarlar kurtarılamaz. Sıfırlama yoktur.

## Bilmeniz gerekenler

- Geri yükleme, seçtiğiniz kategorileri **değiştirir**. Yedeklemeden sonra eklediğiniz her şey bu kategoriler için kaybolur.
- Uygulama yedeklemesi tek bir `.zip` dosyasıdır. Onu güvenli bir yerde saklayın.
- Dosyayı kopyalayabilir, taşıyabilir ya da herhangi bir bulut hizmetinde saklayabilirsiniz.
- Uygulama yedeklemeleri İncil çevirilerinin kendilerini içermez. Bunlar **Ayarlar** → **Kaynakları Yönet** bölümünden yeniden indirilebilir.
- Gizli anahtar yedeklemeleri parolanızla şifrelenir. Hatırlayacağınız bir parola seçin.

## İpucu

Birden fazla cihazınız varsa yedek dosyasını her cihaza kopyalayabilir ve geri yükleyebilirsiniz. Verileriniz iki cihazda da aynı olur.
