---
title: Ayetleri Yer İmlerine Ekleme
level: everyday
categories: [annotate, read]
summary: Ayetleri, daha sonra tekrar bulabilmek için nasıl kaydedeceğiniz.
---

# Ayetleri Yer İmlerine Ekleme

> **Mod:** Yer imleri **Standart** ve **Scholar** modlarında kullanılabilir. Odak Modu yalnızca temiz, dikkatin dağılmadığı okuma içindir. Modları **Ayarlar** → **Uygulama Kullanıcı Modu** üzerinden değiştirebilirsiniz.

Yer imi, bir ayeti ya da kitap bölümünü daha sonra tekrar bulabilmek için kaydeder. Yer imleri bir kitaptaki sekmelere benzer.

## Bir ayet nasıl yer imine eklenir

1. Ayeti açın.
2. Menüyü açmak için ayete dokunun.
3. Menüden **Yer İmi**'ne dokunun. Bir yıldız simgesi ayeti kaydedilmiş olarak işaretler.

Simgedeki onay işareti, ayetin artık yer imlerine eklendiğini gösterir.

## Bir kitap bölümü nasıl yer imine eklenir

Bir kitabı (İncil değil) okurken bölümün tamamını yer imlerine ekleyebilirsiniz:

1. Bölümü açın.
2. Ekranın üstündeki **Yer İmi** simgesine dokunun.

## Yer imlerinizi nasıl görürsünüz

Alttaki **Yer İmleri** sekmesine dokunun. Kaydettiğiniz her ayetin ve kitap bölümünün listesini görürsünüz.

## Yer imi nasıl kaldırılır

- **Tek ayet:** Ayeti açın. Ayete dokunun, sonra **Yer İmi** simgesine yeniden dokunun. Onay işareti kaybolur.
- **Listeden:** **Yer İmleri** sekmesinde bir yer imine uzun basın. Küçük bir menü açılır. **Sil**'e dokunun. (Satırdaki küçük × düğmesine de dokunabilirsiniz.)

## Klasörlerle düzenleme

Yer imlerini klasörlere koyabilirsiniz. Örneğin "Vaaz Hazırlığı" adında bir klasörünüz ve "Güçlendirme" adında başka bir klasörünüz olabilir.

Klasör oluşturmak için:

1. **Yer İmleri** sekmesini açın.
2. Üstteki **Klasörleri Yönet**'e dokunun.
3. Klasör listesinin üstündeki **+ Klasör Oluştur**'a dokunun.
4. Bir ad yazın ve **Kaydet**'e dokunun.

Aynı adda iki klasör oluşturamazsınız. Ad zaten varsa klasör-oluşturma kutusunun içinde bir hata görünür; böylece adı değiştirip yeniden deneyebilirsiniz.

Bir yer imini klasöre koymak için:

1. **Yer İmleri** sekmesinde bir yer imine uzun basın.
2. **Klasöre Kaydet**'e dokunun.
3. Klasörü seçin, sonra **Bitti**'ye dokunun.

## Yer imlerini içe aktarma

Yer imlerini başka uygulamalardan ve dosyalardan Theodia'ya getirebilirsiniz.

**Ayarlar** → **Yer İmleri** → **Yer İmlerini İçe Aktar** bölümüne gidin. **Dosyadan İçe Aktar**'ı seçin ya da panodan yapıştırın. Uygulama biçimi otomatik olarak algılar.

### Desteklenen biçimler

**Yerel JSON dışa aktarımı** — Theodia'nın kendi dışa aktarma özelliğinin kullandığı biçim. Klasörleri ve oluşturma tarihlerini korur.

**Netscape Bookmark HTML** — Yer imlerini dışa aktardığınızda Chrome, Firefox ve Safari'nin kullandığı biçim. Klasörler korunur.

**CSV** — Sütunlu bir elektronik tablo. Uygulama `url` ve `folder` sütunlarını (ya da `href` / `category`) arar. Örnek:

```csv
url,folder
/bible/KJV/John/3,Favorites
/bible/KJV/Genesis/1,Sermon Prep
```

**Düz metin** — Her satır ya bir İncil referansı, ya bir uygulama URL'si ya da bir klasör yönergesidir. Örnek:

```
folder: Favorites
John 3:16
Genesis 1:1
folder: Sermon Prep
Matthew 5:1
```

- `folder: <ad>` ile başlayan satırlar, kendisinden sonraki tüm yer imleri için etkin klasörü belirler.
- `John 3:16` gibi İncil referansları varsayılan İncilinizde yer imlerine dönüştürülür.
- `/bible/KJV/John/3#v3_16` ya da `/book/MyBook/1` gibi uygulama URL'leri doğrudan içe aktarılır.
- `#` ya da `//` ile başlayan satırlar açıklama sayılır ve atlanır.

### İçe aktarma ipuçları

- Yinelenen yer imleri otomatik olarak atlanır.
- Dış URL'ler (BibleGateway bağlantıları gibi) olanaklı olduğunda uygulama yer imlerine dönüştürülür.
- İçe aktarma dosyasındaki bir klasör zaten varsa yer imleri mevcut klasöre konur.

## İpuçları

- Aynı ayeti birçok çeviride yer imlerine ekleyebilirsiniz. Tümü listede görünür.
- Yer imleri cihazınızda kalır. Bulutla eşzamanlanmaz.
- Onları güvende tutmak için [Verilerinizi Yedekleme](theodia://help/backups) kılavuzuna bakın.

## PDF'lerde Yer İmleri

PDF'lerin, İncil yer imlerinizden ayrı tutulan kendi yer imleri vardır. Bir PDF okurken o anki sayfayı kaydetmek, ona bir ad vermek ve daha sonra geri dönmek için okuyucunun araç çubuğundaki **Yer İmi** düğmesine dokunun. Her PDF kendi listesini tutar — bkz. [PDF'ler](theodia://help/pdfs).
