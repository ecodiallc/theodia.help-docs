---
title: Bir AI Modeli Seçmek
level: advanced
categories: ai
summary: Theodia'nın yerleşik araçları ve yetenekleriyle iyi çalışan bir modelin nasıl seçileceği.
---

# Bir AI Modeli Seçmek

> **Mod:** AI asistanı **Scholar** modu gerektirir. Modları **Ayarlar** → **Uygulama Kullanıcı Modu** üzerinden değiştirebilirsiniz.

Her AI modeli Theodia'da aynı şekilde çalışmaz. En iyi deneyim, **araç çağrısını** destekleyen — yani AI'nın İncil ayetlerine bakma, arama yapma, yorum okuma ve uygulamada gezinme gibi Theodia'nın yerleşik özelliklerini kullanabilme yeteneği veren — bir modelden gelir.

## Araç çağrısı nedir?

Theodia'nın AI'sına bir soru sorduğunuzda AI yalnızca konuşmakla kalmaz, aynı zamanda **eylem de yapabilir**. Örneğin:

- "Yuhanna 3:16'yı ESV'de göster" dersiniz. AI, o ayeti okuyucuda açmak için bir araç çağırır.
- "Yorumlarım Romalılar 8:28 hakkında ne diyor?" dersiniz. AI, yorum içeriğini getirmek için bir araç çağırır.
- "Bu ayeti yer imine kaydet" dersiniz. AI, yer imi oluşturmak için bir araç çağırır.

Araç çağrısını desteklemeyen modeller size yalnızca metin yanıt verebilir. Bir şey arayamaz, gezinemez ya da uygulamada hiçbir şeyi değiştiremez.

## Hangi modeller araçları destekler?

### Uzak modeller

Büyük sağlayıcıların çoğu modern uzak modeli, OpenAI uyumlu araç çağrısını destekler. Genel olarak:

- **Büyük modeller** (GPT-4o, Claude Sonnet/Opus, Gemini Pro gibi) araçları güvenilir biçimde kullanır ve tek bir sohbette birden çok araç çağrısını zincirleyebilir. Sağlayıcı adları ve model kimlikleri kolaylık olsun diye uygulamada gösterilir; bağlandığınız gerçek hizmet, uç noktasını ve anahtarını yapılandırdığınız o hizmettir.
- **Daha küçük ya da daha ucuz modeller** araçları destekleyebilir ama daha az güvenilir olabilir. Bir araç çağrısını yok sayabilir ya da yanlış biçimlendirebilir.
- **Çok eski ya da özel amaçlı modeller** çoğunlukla araçları hiç desteklemez.

Emin değilseniz modeli Theodia'da sınayın. "Bana Yaratılış 1:1'i göster" ya da "İncil'de sevgiyle ilgili ayetleri ara" deyin. Ayet açılırsa ya da arama sonuçları görünürse araç çağrısı çalışıyordur.

## Theodia için önerilen modeller

Maliyet, kalite ve araç desteğini dengeleyen iyi seçimler:

- **OpenAI GPT-4o** — mükemmel araç desteği, hızlı, karmaşık çok adımlı soruları iyi yönetir.
- **Anthropic Claude Sonnet / Opus** — çok güvenilir araç kullanımı, uzun pasajlar ve ayrıntılı çalışma için harika.
- **Groq** (çeşitli modeller) — hızlı çıkarım, çoğunlukla ücretsiz ya da çok ucuz, araç desteği modele göre değişir.
- **OpenRouter** — tek bir hesaptan birçok modeli denemenizi sağlar. Yeteneklerinde "function calling" ya da "tools" listeleyen modellere bakın.
- **[GitHub Models](theodia://help/github-models)** — önerilen ücretsiz sağlayıcı. Cömert bir günlük ücretsiz kota ile OpenAI, Anthropic ve diğer modellere GitHub hesabınız üzerinden erişim. Aynı `openai/gpt-4o` tarzı model kimliklerini kullanır.

## Kaçınılması gereken modeller

- **Salt metin tamamlama modelleri** (GPT-3 tabanı ya da yönerge ayarlaması yapılmamış ham LLaMA gibi) genellikle araçları desteklemez.
- **Yalnızca görsel modeller**, metinden çok resimlere odaklandıklarından araç desteği olmayabilir.
- **Aşırı küçük modeller**, 1 milyar parametrenin altındakiler, API desteklediğini söylese bile araçları doğru kullanamayabilir.

## Araç desteği nasıl sınanır

Theodia araç desteğini otomatik olarak denetler. **Ayarlar → Yapay Zeka Asistanı** bölümünde bir model kurduktan sonra **Bağlantıyı sına**'ya dokunun. Bağlantı başarılı olduktan sonra uygulama, örnek bir araç tanımıyla ikinci bir istek gönderir. İki sonuçtan birini görürsünüz:

- **✓ Araçlar destekleniyor** — Model araç çağrılarını kabul ediyor ve Theodia'nın yerleşik özelliklerini kullanabiliyor.
- **✗ Araçlar desteklenmiyor** — Model araç isteğini reddediyor. Yalnızca metinle yanıt verecek ve sizin için ayet açamayacak, arama yapamayacak, yer imlerini yönetemeyecek.

"Araçlar desteklenmiyor" görürseniz model, sıradan bir metin sohbet asistanı olarak yine çalışabilir; ama Theodia'yı güçlü kılan bütünleşik, eller serbest deneyimi kazanamazsınız.

Ayrıca AI'dan bir şey yapmasını isteyerek elle doğrulayabilirsiniz:

- "Matta 5:3'ü KJV'de göster." — Ayeti okuyucuda açmalı.
- "Yuhanna 3:16'daki 'agape' kelimesi için sözlük ne diyor?" — Leksik verisi döndürmeli.
- "İncil'de bağışlanmayla ilgili ayetleri ara." — Arama sonuçları döndürmeli.
- "Markos 12:30'u yer imine ekle." — Yer imi oluşturmalı.

AI, o işi gerçekten yapmak yerine bir metin açıklaması veriyorsa, uygulama destek bildirmiş olsa bile model araçlarını kullanmakta zorlanıyordur.

## Ya modelim araçları desteklemiyorsa?

Yine de kullanabilirsiniz. AI metinle yanıt verir; siz ayetlere elle bakabilir, arama yapabilir ve uygulamada kendiniz gezinebilirsiniz. Ama Theodia'yı güçlü kılan eller serbest, bütünleşik deneyimi kaçırırsınız.

## Özet

- En iyi Theodia deneyimi için **araç çağrısı / function calling** destekli bir model seçin.
- **Büyük uzak modeller** araçları en güvenilir biçimde yönetir.
- Araç desteğini doğrulamak için her modeli "Bana Yaratılış 1:1'i göster" gibi basit komutlarla sınayın.
