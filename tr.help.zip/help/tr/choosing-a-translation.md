---
title: Bir İncil Çevirisi Seçmek
level: beginner
categories: [read, study]
summary: Size uygun çeviriyi seçmek için sade dilli bir kılavuz.
---

# Bir İncil Çevirisi Seçmek

İncil "çevirisi", İncil'i okuyabileceğiniz kelimelere dökme çabasıdır. Farklı çeviriler farklı sesletilir. Bazıları sözcüğe sözcüktür. Bazıları düşünüce düşüncedir. Yanlış seçim yoktur. Sizin için en iyi okunanı seçin.

## İki ana üslup

**Sözcüğe sözcük çeviriler** özgün dillerdeki (İbranice ve Yunanca) kelimeleri korumaya çalışır. Okumaları daha zor olabilir ama kaynağa daha yakın hissettirir. Örnekler: KJV, WEB.

**Düşünüce düşüncе çeviriler** özgünün anlamını, insanların bugün kullandığı kelimelere koymaya çalışır. Okumaları daha kolaydır. Örnekler: BSB, UST.

## Bazı yaygın çeviriler

- **KJV (King James Version).** Eski İngilizce üslup. Birçok okur tarafından sevilir.
- **WEB (World English Bible).** Sözcüğe sözcük. Modern, kamuya açık İngilizce.
- **BSB (Berean Standard Bible).** Düşünüce düşüncе. Okuması kolay.
- **UST (unfoldingWord Simplified Text).** Düşünüce düşüncе. Basit, anlaşılır İngilizce kullanır.

## Birini nasıl denersiniz

İstediğiniz kadar çeviri kurabilirsiniz. Aynı ayeti iki ya da üç çeviride okuyun. Hangisinin size en çok yardımcı olduğunu görün.

## Nasıl karşılaştırılır

Bir bölüm açın, sonra geçiş yapmak için üstteki çeviri adına dokunun. **Karşılaştır** özelliği (bkz. [Çevirileri Karşılaştırma](theodia://help/compare-translations) kılavuzu) iki çeviriyi yan yana gösterir.
