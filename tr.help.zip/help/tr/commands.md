---
title: Komutlar
level: everyday
categories: [layout, study]
summary: Komut girişi, kısa bir komut yazarak herhangi bir özelliğe atlamanızı sağlar. Desteklenen biçimleri ve örnekleri öğrenin.
---

# Komutlar

**Komut** girişi, kısa bir yönerge yazarak Theodia'nın neredeyse her bölümüne atlamanızı sağlar. Bunu Giriş sekmesinden ya da **Başlatıcı Menü**'den (üstteki **▼** simgesi) kullanabilirsiniz.

## Nasıl çalışır

1. Komut kutusuna dokunun.
2. Bir komut yazın.
3. Klavyenizdeki git tuşuna dokunun.

Uygulama komutu okur ve sizi doğrudan doğruya ilgili ekrana götürür.

### Eğik çizgi öneki yok

Komutlar `/` öneki **kullanmaz**. Düz metin olarak yazılır:

```
john 3:16
search love
backup
```

`/settings` yazarsanız baştaki `/` komutu tanınmaz yapar.

## İncil referansları

Okuyucuda açılması için herhangi bir İncil referansı yazın.

```
psalms 23
john 3:16
matthew 5:1
1 cor 15:10
```

Kitap adları tam ad ya da kısaltma ile eşleşebilir. İngilizce olmayan arayüz dillerinde kitap adlarını etkin dilde de yazabilirsiniz.

## Arama

```
search abraham
search love
search faith not works
```

## Yer imleri, karşılaştırma, yorum, çapraz referanslar ve kelime bilgisi

```
bookmark john 3:16
compare genesis 1:1
commentary john 1
aicommentary eph 2:8
xref 1 cor 15:10
word info john 1:1
```

Bu komutlar, verilen pasaj için adı geçen aracı açar.

## Leksik (sözlük)

Leksik girdisini açmak için bir Strong numarası yazın.

```
g1161
h7225
```

## Günlük öğretiler

```
devotional
devotional smith
devotional daily
```

Ad verilmezse günlük öğreti listesini açar.

## Gezinme kısayolları

```
notes
highlights
bookmarks
flashcards
playlist
theoscript
resources
read john 3:16
```

Bunlar doğrudan adı geçen ekrana atlar ya da bir pasajı okuyucuda açar.

## Çeviri değiştirme

Geçiş yapmak için bir çeviri kısaltması yazın.

```
kjv
web
trlit
ohgb
```

Okuyucu ekranında çeviri yerinde değişir. Başka her yerde, en son okuduğunuz pasajda o çeviriyi açar.

## Yerelleştirilmiş komut fiilleri

Herkese açık komut fiilleri, etkin arayüz dilinde **ya da** İngilizce yazılabilir. İngilizce her zaman yedek olarak çalışır. Gizli komutlar (ayar kısayolları, kurma komutları, sürpriz yumurtalar) yalnızca İngilizce söz dizimi tutar.

## Yardım

Uygulama içi komut başvurusunu herhangi bir zamanda açmak için Komut kutusuna `help` ya da `commands` yazın.
