---
title: Yorumlar ve Leksiklar
level: everyday
categories: study
summary: Kelime anlamlarına nasıl bakılacağı ve çalışma notlarının nasıl okunacağı.
---

# Yorumlar ve Leksiklar

> **Mod:** Yorumlar ve leksiklar **Scholar** modu gerektirir. Modları **Ayarlar** → **Uygulama Kullanıcı Modu** üzerinden değiştirebilirsiniz.

Theodia iki çalışma aracı içerir: **yorumlar** ve **leksiklar** (sözlükler). İncil'i daha derinlemesine anlamanıza yardımcı olurlar.

## Yorum nedir?

Yorum, bir İncil bilgini tarafından yazılmış çalışma notlarından oluşan bir kitaptır. Verilen bir ayet için yorum, arka planı, anlamı ve ayetin İncil'in geri kalanına nasıl yerleştiğini söyler.

## Leksik nedir?

Leksik, İncil kelimelerinin sözlüğüdür. Özgün İbranice ya da Yunanca kelimeyi, ne anlama geldiğini ve İncil'de nasıl kullanıldığını söyler.

## Yorum nasıl açılır

1. Bir bölüm açın.
2. Bir ayete dokunun.
3. **Yorum**'a dokunun.

Bir panel açılır. O ayet hakkında bir İncil bilgininden notlar gösterir.

## Leksik nasıl açılır

1. Strong numaralarını içeren bir İncil'de bir bölüm açın.
2. Ayette bir Strong numarasına dokunun (örneğin G1234 ya da H1234).
3. Özgün İbranice ya da Yunanca kelimeyi, anlamını ve kelimenin geçtiği diğer ayetleri gösteren bir panel açılır.

Strong numaraları, düz kelimelerden ayrışmaları için ayet metninde farklı bir renkte görünür.

## Farklı bir yorum seçme

Yorum, yorum panelinin kendi üstündeki açılır listeden seçilir. Paneli açın, sonra kurduğunuz yorumları görmek için açılır listeye dokunun. Farklı birini seçin.

## Farklı bir leksik seçme

Leksik, leksik panelinin üstündeki açılır listeden seçilir. Paneli açın, sonra kurduğunuz leksikları görmek için açılır listeye dokunun. Farklı birini seçin.

## Yerleşik kaynaklar

Theodia, yerleşik bir yorum ve leksik kümesiyle birlikte gelir. Bunlar uygulamaya dahildir ve çevrimdışı çalışır. Ek yorumlar ve leksiklar ayrıca kurulamaz ya da indirilemez.

## Bunlar ne zaman kullanılır

- **Yorumlar**, bir ayet anlaması zor olduğunda iyidir. Notlar size arka plan verir.
- **Leksiklar** kelime incelemeleri için iyidir. Bir kelimenin özgün dildeki tam anlamını söyler.

## İpucu

Bir ayetin saklamak istediğiniz bir notu varsa ekran görüntüsü alın ya da metni bir nota kopyalayın. (Bkz. [Not Yazma](theodia://help/notes) kılavuzu.)

## Sade dilli İncil sözlüğü

İncil kelimeleri ve kavramlarının (antlaşma, kefaret, Ferisiler vb.) İngilizce tanımları için Theodia ayrıca bir İncil Sözlüğü aracı içerir. Ayet menüsünden **Sözlük**'e (📖) dokunarak açın. Bu, leksikten farklıdır: leksiklar özgün İbranice ve Yunanca kelimeleri açıklarken sözlük, İngilizce kelimeyi sade dille açıklar. Nasıl kullanılacağı için [İncil Sözlüğü](theodia://help/dictionary) kılavuzuna bakın.
