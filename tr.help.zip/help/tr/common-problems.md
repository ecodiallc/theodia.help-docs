---
title: Sık Görülen Sorunlar
level: everyday
categories: trouble
summary: Karşılaşabileceğiniz sorunlar için hızlı çözümler.
---

# Sık Görülen Sorunlar

Bu kılavuz insanların en sık karşılaştığı sorunları kapsar. Sorununuz burada yoksa [Soruları Nerede Sormalı](theodia://help/getting-more-help) kılavuzuna bakın.

## Uygulama yavaş

1. Arka planda çalışan diğer uygulamaları kapatın.
2. Uygulamayı yeniden başlatın.
3. Cihazınızı yeniden başlatın.

## Bir İncil çevirisi bulamıyorum

1. Kurulu olanları görmek için **Ayarlar** → **Kaynakları Yönet** bölümünü açın.
2. Çeviri orada yoksa **GitHub'dan Kur**'a dokunun.
3. İndirme penceresinde **İnciller** sekmesine (ya da **Global İnciller**'e) dokunun ve istediğiniz çeviriyi seçin.
4. **Seçilenleri Kur**'a dokunun ve indirmenin bitmesini bekleyin.
5. Yeni bir çeviri indirmek için internet gerekir.

## Notlarım ya da yer imlerim kayboldu

1. Doğru sekmeye baktığınızdan emin olun. Notlar **Notlar** sekmesindedir. Yer imleri **Yer İmleri** sekmesindedir.
2. Yakın zamanda bir yedekten geri yükleme yaptıysanız yedek, verilerinizi değiştirmiş olabilir. Yedeğin tarihini kontrol edin.
3. Uygulamayı kaldırıp yeniden kurduysanız verileriniz kaybolmuştur. Bir dahaki sefere önce yedekleme yapın.

## Arama ayetleri bulmuyor

1. Kelimeyi doğru yazdığınızdan emin olun.
2. Daha kısa bir kelime deneyin. "Love", "loving"den daha çok ayet bulur.
3. Doğru İncil çevirisinin kurulu olduğundan emin olun. Arama yalnızca kurulu olduğunuz çevirilerde çalışır.

## Sesli okuma çalışmıyor

1. Cihazınızın sesinin açık olduğundan emin olun.
2. Uygulamanın hoparlörü kullanmasına izin verildiğinden emin olun.
3. Farklı bir çeviri deneyin. Bazı çeviriler sesli okumayla diğerlerinden daha iyi çalışır.
4. Adım adım bir kontrol listesi için [Sesli Okuma](theodia://help/tts) kılavuzuna bakın.

## Uygulama sürekli çöküyor

1. Uygulamayı yeniden başlatın.
2. Cihazınızı yeniden başlatın.
3. Sorun sürerse lütfen bildirin. Bkz. [Soruları Nereye Sormalı](theodia://help/getting-more-help) kılavuzu.

## Uygulamayı kaldırmak istiyorum

Theodia'yı başka herhangi bir uygulama gibi kaldırabilirsiniz. Bunu yapmadan önce verilerinizi yedekleyin. Kaldırdıktan sonra cihazdaki veriler gider.

## Hâlâ takıldınız mı?

[Soruları Nereye Sormalı](theodia://help/getting-more-help) kılavuzuna bakın. Orada sorun bildirme ve topluluğa sorma bağlantılarını bulabilirsiniz.

Ayrıca **Yardım ve Kılavuzlar** ana ekranından yardım kılavuzlarında arama yapabilirsiniz. Eşleşen kılavuzu bulmak için `notifications`, `search` ya da `bookmarks` gibi bir kelime yazın.
