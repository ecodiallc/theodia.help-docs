---
title: Çevirileri Karşılaştırma
level: everyday
categories: [read, study]
summary: Aynı ayeti kurulu olduğunuz tüm çevirilerde görmenin yolu.
---

# Çevirileri Karşılaştırma

> **Mod:** Karşılaştır aracı **Standart** ve **Scholar** modlarında kullanılabilir. Odak Modu yalnızca temiz, dikkatin dağılmadığı okuma içindir. Modları **Ayarlar** → **Uygulama Kullanıcı Modu** üzerinden değiştirebilirsiniz.

**Karşılaştır** aracı tek bir ayeti, kurulu olduğunuz tüm İncil çevirilerinde, tek bir panelde gösterir. Farklı çevirmenlerin zor bir ayeti nasıl ele aldığını görmek ya da bir çeviri seçerken aynı ayeti her birinde incelemek istediğinizde kullanışlıdır.

## Karşılaştır nasıl açılır

1. Herhangi bir çeviride bir bölüm açın.
2. Ayet menüsünü açmak için bir ayete dokunun.
3. **Karşılaştır**'a (⇄) dokunun.

Bir panel açılır. Başlık çubuğu referansı gösterir (örneğin "John 3:16 — Compare"). Panel, aynı ayeti kurulu her çeviride listeler. Geçerli çeviriniz ilk sırada; geri kalanı alfabetik sıralanır.

## Panel neye benzer

Panel yan yana bir sütun değil **dikey bir listedir**. Her satır bir çeviridir:

- **Çeviri adı** (örneğin "KJV") satırın üstündedir. Dokunulabilir.
- **Ayet metni** adın altındadır.

Tüm çevirileri görmek için paneli kaydırın. Cihazınızda kurulu her çeviri burada görünür. Bir çeviride o kitap ya da ayet yoksa listede yer almaz.

## Ayeti farklı bir çeviride nasıl okursunuz

Satırdaki çeviri adına dokunun. Karşılaştır paneli kapanır ve aynı bölüm, seçilen ayet o çeviride gösterilerek açılır. Karşılaştırmadan doğrudan belirli bir çeviriyi okumaya atlamayı sağlayan en hızlı yol budur.

## Karşılaştır nasıl kapatılır

- **Telefonda:** panelin sağ üstündeki X'e dokunun.
- **Tablette:** panel başlığındaki X'e ya da panelin dışına dokunun.

Özgün çevirinizdeki bölüm görünümüne geri dönersiniz.

## Karşılaştır ne zaman kullanılır

- **Çeviri seçerken.** Geçerli çevirinizde iyi bildiğiniz bir ayet açın, sonra başkalarında görmek için Karşılaştır'ı kullanın. Farklar göze çarpar.
- **Zor ayetler.** Bir çeviride kafa karıştırıcı olan bir ayet, başka bir çeviride çoğunlukla daha nettir.
- **Kelime incelemeleri.** Farklı çevirmenlerin kilit bir kelimeyi ya da ifadeyi nasıl ele aldığına bakın.

Birden çok çeviride bir bölümün tamamının bir bakışta karşılaştırılması için onun yerine **paralel görünüm**ü kullanın. Açmak için [Çalışma Modu](theodia://help/study-mode) kılavuzuna bakın.
