---
title: Kendi Kaynaklarınızı Oluşturma
level: advanced
categories: resources
summary: Özel İnciller, yorumlar, kitaplar, günlük öğretiler ve leksikların nasıl oluşturulacağı ve Theodia'ya nasıl içe aktarılacağı.
---

# Kendi Kaynaklarınızı Oluşturma

Theodia, Unique Bible App biçiminde özel kaynakları destekler. Her kaynak, belirli bir tablo yapısına sahip bir SQLite dosyasıdır. Bu dosyaları bir bilgisayarda oluşturabilir ve uygulamaya içe aktarabilirsiniz.

## Dosya türleri ve gereken tablolar

### İnciller (`.bible`)

İncil dosyası, şu tablolardan en az birini içeren bir SQLite veritabanıdır:

- **`Verses`** — sütunlar: `Book` (tamsayı, 1-66), `Chapter` (tamsayı), `Verse` (tamsayı), `Scripture` (metin)
- **`Bible`** — sütunlar: `Book` (tamsayı), `Chapter` (tamsayı), `Verse` (tamsayı), `Scripture` (metin)

Ayrıca `Description`, `Abbreviation` ve `Version` gibi üstveri sütunlarıyla bir **`Details`** tablosu da ekleyebilirsiniz.

Örnek SQL:

```sql
-- Ana metin tablosu
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- İsteğe bağlı üstveri tablosu
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### Yorumlar (`.commentary`)

Yorumlar üç türde gelir: **kitap**, **bölüm** ve **ayet**. Tür, **dosya adının ilk harfiyle** belirlenir.

#### Kitap yorumları — dosya adı `b` ile başlar

Bir kitap yorumu, İncil'in tüm bir kitabını tek bir girdide kapsar. `Commentary` tablosu `Book` ve `Scripture` (ya da `Content`) sütunlarını gerektirir. `Chapter` ya da `Verse` sütunlarına gerek yoktur.

- **`Commentary`** — sütunlar: `Book` (tamsayı), `Scripture` (metin) ya da `Content` (metin)

Örnek SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

Dosya adı örneği: `bMyCommentary.commentary`

#### Bölüm yorumları — dosya adı `c` ile başlar

Bir bölüm yorumu, İncil kitabının her bölümünü kapsar.

- **`Commentary`** — sütunlar: `Book` (tamsayı), `Chapter` (tamsayı), `Scripture` (metin) ya da `Content` (metin)

Örnek SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

Dosya adı örneği: `cMyCommentary.commentary`

#### Ayet yorumları — dosya adı `v` ile başlar

Bir ayet yorumu, tek tek ayetleri kapsar. `Commentary` tablosu `Book`, `Chapter`, `Verse` ve `Scripture` (ya da `Content`) sütunlarını gerektirir.

- **`Commentary`** — sütunlar: `Book` (tamsayı), `Chapter` (tamsayı), `Verse` (tamsayı), `Scripture` (metin) ya da `Content` (metin)

Örnek SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

Dosya adı örneği: `vMyCommentary.commentary`

### Kitaplar (`.book`)

Kitap dosyası, bir `Reference` tablosu içeren bir SQLite veritabanıdır.

- **`Reference`** — sütunlar: `id` (tamsayı), `Chapter` (metin), `Content` (metin)

Her satır bir bölümdür. `Chapter` sütunu bölüm başlığıdır. `Content` sütunu bölüm gövdesidir; HTML içerebilir (`<b>`, `<i>`, `<br>` vb.).

Örnek SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

Kitapları Markdown dosyalarından da oluşturabilirsiniz. Uygulama, `#`'nin kitap başlığı ve `##`'nin bölümleri işaret ettiği `.md` dosyalarını içe aktarabilir. Markdown otomatik olarak HTML'ye dönüştürülür.

### Günlük öğretiler (`.devotional`)

Günlük öğreti dosyası, bir `devotional` tablosu içeren bir SQLite veritabanıdır.

- **`devotional`** — sütunlar: `month` (tamsayı, 1-12), `day` (tamsayı, 1-31), `devotion` (metin)

Her satır bir günün okumasıdır. Uygulama girdiyi günün ayına ve gününe göre arar.

Örnek SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### Leksiklar (`.lexicon`)

Leksik dosyası, bir `Lexicon` tablosu içeren bir SQLite veritabanıdır.

- **`Lexicon`** — sütunlar: `Topic` (metin, Strong numarası), `Definition` (metin, leksik girdisi)

`Topic` sütunu Strong numarasını tutar (örneğin `G1161` ya da `H7225`). `Definition` sütunu, HTML içerebilen tam girdi metnini tutar.

Örnek SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

Leksiklar Kelime Bilgisi aracını besler. Bir interlinear İncil'de bir kelimeye dokunduğunuzda uygulama, Strong numarasını kurulu leksiklarda arar.

## Bilgisayarınızda dosya oluşturma

1. Bir SQLite düzenleyici kurun (DB Browser for SQLite, SQLiteStudio ya da `sqlite3` komut satırı aracı).
2. Yeni bir veritabanı dosyası oluşturun.
3. Gerekli tabloyu oluşturun ve verilerinizi ekleyin.
4. Dosyayı doğru uzantıyla kaydedin (`.bible`, `.commentary`, `.book`, `.devotional` ya da `.lexicon`).

## Theodia'ya içe aktarma

1. Dosyayı cihazınıza aktarın (AirDrop, e-posta, bulut depolama ya da USB).
2. **Theodia**'yı açın.
3. **Ayarlar** → **Kaynakları Yönet** bölümüne gidin.
4. **Dosyadan İçe Aktar**'a dokunun.
5. Dosyanızı seçin.

Uygulama dosyayı doğrular (gerekli tabloyu denetler), uygulamanın veri klasörüne kopyalar ve otomatik olarak etkinleştirir. Dosya geçersizse neyin yanlış olduğunu açıklayan bir hata iletisi görürsünüz.

## Sınırlamalar

- Yerleşik kaynakların üzerine yazamazsınız. Yerleşik bir İncil, yorum ya da kitapla aynı ada sahip bir dosya içe aktarmaya çalışırsanız içe aktarma başarısız olur.
- İncil dosyalarının `Verses` ya da `Bible` tablosu gerekir. İkisi de yoksa içe aktarma başarısız olur.
- Yorum dosyalarının `Commentary` tablosu gerekir.
  - Kitap yorumları `Book` ve `Scripture` (ya da `Content`) sütunlarını gerektirir.
  - Bölüm yorumları `Book`, `Chapter` ve `Scripture` (ya da `Content`) sütunlarını gerektirir.
  - Ayet yorumları `Book`, `Chapter`, `Verse` ve `Scripture` (ya da `Content`) sütunlarını gerektirir.
- Kitap dosyalarının `Reference` tablosu gerekir.
- Leksik dosyalarının `Lexicon` tablosu gerekir.
- Günlük öğreti dosyalarının `devotional` tablosu gerekir.

## İpuçları

- Dosya boyutlarını makul tutun. Çok büyük SQLite dosyaları eski cihazlarda bellek sorunlarına yol açabilir.
- Dosyanızı önce bir bilgisayarda sınayın. Bir SQLite tarayıcısında açın ve verilerin doğru göründüğünü doğrulamak için gereken tabloya `SELECT * FROM` çalıştırın.
- İncillerde `Book` sütununun sayı kullandığından emin olun (1 = Yaratılış, 66 = Vahiy).
- Yorumlarda, yorum metni sütunu olarak `Scripture` ya da `Content`'ten herhangi birini kullanabilirsiniz.
- Kitaplarda `Content` sütunundaki HTML okuma sırasında işlenir. Basit tutun: `<b>`, `<i>`, `<br>` ve `<hr>` güvenlidir.

## Mevcut kaynakları nerede bulursunuz

Theodia, [Unique Bible App](https://github.com/eliranwong/UniqueBible) projesindeki kaynakları okuyabilir. Birçok İncil, yorum, kitap ve başka kaynak orada doğru SQLite biçiminde mevcuttur. Bunları bulma ve ekleme yöntemi için [Ek Kaynaklar Alma](theodia://help/getting-core-files) kılavuzuna bakın.
