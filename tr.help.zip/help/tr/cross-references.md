---
title: Çapraz Referanslar
level: everyday
categories: study
summary: Okuduğunuz ayetle bağlantılı ayetleri nasıl bulacağınız.
---

# Çapraz Referanslar

> **Mod:** Çapraz referanslar **Standart** ve **Scholar** modlarında kullanılabilir. Odak Modu yalnızca temiz, dikkatin dağılmadığı okuma içindir. Modları **Ayarlar** → **Uygulama Kullanıcı Modu** üzerinden değiştirebilirsiniz.

"Çapraz referans", okuduğunuz ayetle aynı şeyden söz eden başka bir ayettir. Çapraz referans paneli, İncil'deki hangi ayetlerin birbirine bağlandığını gösterir.

## Çapraz referanslar nasıl açılır

1. Bir bölüm açın.
2. Ayet menüsünü açmak için bir ayete dokunun.
3. **Çapraz Referanslar**'a dokunun.

Bir panel açılır. Dokunduğunuz ayete bağlanan diğer ayetlerin listesini gösterir.

## Liste nasıl okunur

Her satır bir bağlantılı ayettir. Görürsünüz:

- Kitabı, bölümü ve ayeti.
- Ayet metninin kısa bir önizlemesini.
- Bağlantının ne kadar güçlü olduğunu gösteren bir puanı.

## Bağlantılı bir ayete nasıl atlanır

Herhangi bir satıra dokunun. Uygulama o ayeti sizin için açar. Bitirdiğinizde dönmek için geri düğmesine dokunun.

## Puan ne anlama gelir

Puan, ayetlerin birbirine ne kadar yakın bağlandığını söyler. Yüksek puan güçlü, doğrudan bir bağlantı demektir. Düşük puan daha gevşek bir bağlantı demektir.

## Çalışma için çapraz referans kullanma

Çapraz referanslar şunlar için kullanışlıdır:

- **Kelime incelemeleri.** İncil'in bir kelimeyi farklı yerlerde nasıl kullandığını görün.
- **Tema incelemeleri.** "Sevgi" ya da "antlaşma" gibi bir temayı Kutsal Yazı boyunca izleyin.
- **Vaaz hazırlığı.** Destekleyici ayetleri hızla bulun.

## İpucu

Çapraz referanslar, WEB gibi sözcüğe sözcük bir çeviriyle en iyi şekilde çalışır.
