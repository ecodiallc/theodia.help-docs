---
title: Günlük Öğretiler
level: everyday
categories: [content, read]
summary: Her gün kısa bir günlük öğretinin nasıl okunacağı.
---

# Günlük Öğretiler

Günlük öğreti (devotional), tek bir gün için kısa bir okumadır. Çoğunlukla bir ayet, kısa bir düşünce ve üzerine düşünülecek bir soru içerir. Theodia, küçük bir öğreti kitaplığıyla birlikte gelir.

## Günlük öğreti nasıl açılır

1. Ekranın altındaki **Günlük Öğretiler** sekmesine dokunun.
2. Cihazınızda kurulu olan günlük öğretilerin listesini görürsünüz.
3. Açmak için birine dokunun.

## Günlük öğreti nasıl okunur

1. Öğretiyi açın.
2. Okumak için kaydırın.
3. Üstteki düğmeleri kullanın:
   - Farklı bir güne atlamak için **tarihe** dokunun.
   - Günü yer imine eklemek için **yıldıza** dokunun.
   - Sesli okumak için **hoparlöre** dokunun (cihazınız destekliyorsa). Ses seçmek için [Sesli Okuma](theodia://help/tts) kılavuzuna bakın.
   - Önceki ya da sonraki güne geçmek için **Önceki** ya da **Sonraki**'ye dokunun.

## Öğretiden bir ayet nasıl kaydedilir

1. Öğretiyi açın.
2. Bir ayete dokunun.
3. **Yer İmi** ya da **Vurgu**'ya dokunun.

Ayet, Yer İmlerinizde ya da Vurgularınızda kaydedilir.

## Bir günlük öğretiye not nasıl yazılır

1. Öğretiyi açın.
2. Bir ayete dokunun.
3. **Not**'a dokunun. Düşüncenizi ya da duanızı yazın. **Kaydet**'e dokunun.

Not, Notlar sekmenizde görünür.

## İpuçları

- Günlük öğretiler internet gerektirmez. Çevrimdışı çalışırlar.
- Daha çok öğreti isterseniz [GitHub'dan Ek Kaynaklar Alma](theodia://help/getting-core-files) kılavuzuna bakın.
