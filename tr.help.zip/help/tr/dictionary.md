---
title: İncil Sözlüğü
level: everyday
categories: study
summary: İncil kelimelerine ve kavramlarına kurulu sözlük kaynaklarında bakın. Ayet menüsünden ya da bir leksik girdisinden açın, sonra aynı kelimeyi her sözlükte görmek için herhangi bir kelimeye dokunun.
---

# İncil Sözlüğü

> **Mod:** İncil Sözlüğü **Scholar** modu gerektirir. Modları **Ayarlar** → **Uygulama Kullanıcı Modu** üzerinden değiştirebilirsiniz.

İncil Sözlüğü aracı, bir kelimeyi ya da ifadeyi kurulu olduğunuz her sözlük kaynağında arar. İncil kelimesinin sade dilli bir tanımını, bir kişinin ya da yerin tanımını ya da bir ilahiyat kavramı üzerine kısa bir makaleyi istediğinizde kullanışlıdır.

İncil Sözlüğü, bir ayetin arkasındaki özgün İbranice ya da Yunanca kelimeye bakan **Kelime Bilgisi** aracından farklıdır. Sözlük, dokunduğunuz **İngilizce** kelimeyi okur ve kurulu sözlüklerinizin o kelime hakkında ne söylediğini gösterir. Kelime kelime İncil çeviri notları için [Yorumlar ve Leksiklar](theodia://help/commentaries-and-lexicons) kılavuzuna bakın.

## Sözlük nasıl açılır

Sözlüğü açmanın iki yolu vardır.

### Ayet menüsünden

1. [Çalışma Modu](theodia://help/study-mode)'nda bir bölüm açın.
2. Ayet menüsünü açmak için bir ayete dokunun.
3. **Sözlük**'e (📖) dokunun.

Ayet referansıyla başlıklı bir panel açılır (örneğin "John 3:16"). Ayet metni, her kelimesi dokunulabilir olarak üsttedir. Ayetin altında kurulu her sözlüğü gösteren bir rozet şeridi vardır. Onun altında ise tanım bulunur; bir kelimeye dokunana dek boştur.

### Bir leksik girdisinden

Kelime Bilgisi panelinde bir leksik girdisi okurken bazı girdiler, ilgili sözlük makalelerine giden mavi bağlantılar içerir. Bu bağlantılardan herhangi birine dokunun. Leksik kapanır ve sözlük o makalede açılır. Bu, bir Yunanca ya da İbranice kelimeden onun sade dilli açıklamasına atlamanın en hızlı yoludur.

## Ayet görünümü nasıl çalışır

Sözlüğü bir ayet menüsünden açtığınızda ayet, panelin üstünde dokunulabilir kelimelerden oluşan bir liste olarak görünür. "the", "and", "of", "to" ve "a" gibi yaygın İngilizce kelimeler dokunulabilir değildir. Diğer her kelime dokunulabilirdir. Her dokunulabilir kelime, ayetin geri kalanından ayrışması için renkli ve koyu biçimlendirilmiştir.

Ayetteki herhangi bir kelimeye dokunun. Theodia, o kelimeyle tam eşleşme için kurulu her sözlüğü arar. Alttaki rozet şeridi, hangi sözlüklerin girdisi olduğunu gösterecek şekilde güncellenir: o kelime için girdisi olmayan sözlükler soluklaşır. Girdisi olan ilk sözlük otomatik olarak seçilir ve tanımı, rozet şeridinin altında görünür.

Dokunduğunuz kelime, panelin üstündeki ayet metninde vurgulanır; böylece neye baktığınızı her zaman bilirsiniz.

## Sözlükler arasında geçiş

Kurulu her sözlük, ayetin altında küçük bir rozet olarak gösterilir. Bir kelimeye dokunduktan sonra:

- **Dolgu renkli** rozet — bu sözlükte dokunduğunuz kelimenin girdisi vardır. O sözlüğün tanımına geçmek için dokunun.
- **Soluk** rozet — bu sözlükte o kelimenin girdisi yoktur. Hangi sözlüklerin kelimeyi kapsadığını bir bakışta görebilmeniz için gri gösterilir; rozete dokunulamaz.

Seçili sözlük vurgulanır. Aynı kelimeyi o sözlükte okumak için diğer dolgu renkli bir rozete dokunun. Alttaki tanım hemen güncellenir.

Kelime, kurulu sözlüklerinizden yalnızca birinde geçiyorsa yalnızca o rozet dolgu renklidir, diğerleri soluklaşır.

## Panel ne gösterir

Sözlük paneli yukarıdan aşağıya üç bölümden oluşur:

- **Ayet** — sözlüğü açtığınız ayet. Kelimeler dokunulabilirdir ve en son dokunduğunuz kelime vurgulanır.
- **Rozet şeridi** — kurulu her sözlük. Dolgu renkli olmak "dokunulan kelimeye girdi var" demektir. Soluk olmak "o kelimeye girdi yok" demektir.
- **Tanım** — seçili sözlükteki makale. Düz metin; paragraflar ve başlıklarla biçimlendirilmiş. Diğer sözlük girdilerine giden iç bağlantılar dokunulabilirdir; birine dokunmak o girdiyi sözlükte açar.

## Girdi bulunamazsa ne olur

Kurulu sözlüklerinizin hiçbirinin kapsamadığı bir kelimeye dokunursanız panel, tanım yerine kısa bir "girdi bulunamadı" iletisi gösterir. Bu, İncil'in her yerinde geçse bile gerçek bir İncil-ilahiyat kelimesi olmayan "yıl" ya da "gelmek" gibi çok yaygın kelimelerde sıktır. Daha belirli bir kelime deneyin ya da bunun yerine, altta yatan Yunanca ve İbranice metinde çalışan leksikun Kelime Bilgisi aracını kullanın.

## Hiçbir sözlük kurulmadıysa ne olur

Sözlüğün işe yaraması için en az bir sözlük kaynak dosyası gerekir. Theodia bir taneyle birlikte gelir. Onu kaldırdıysanız ya da sözlüksüz özel bir kurulum çalıştırıyorsanız ayet görünümü yine görünür ve kelimeler yine dokunulabilirdir, ama rozet şeridi boştur ve her arama "girdi bulunamadı" döndürür.

Ek sözlükler ayrı olarak kurulamaz.

## İpuçları

- Sözlük **tam kelime eşleşmesi** arar. "love"a dokunmak "love" başlıklı girdileri bulur ama "loved" ya da "loving"i bulmaz. İlgili bir biçime bakmak için Yunanca ya da İbranice kelime üzerinde leksikun Kelime Bilgisi aracını kullanın.
- Rozet şeridi telefonlarda ve tabletlerde aynıdır. Tablette sözlük, bölümün yanında bir yan panel olarak açılır; telefonda tam ekran bir pencere olarak açılır. Her ikisi de aynı üç bölümlü yerleşime sahiptir.
- Farklı bir ayetteki bir kelimeye dokunmak, panelde yeni bir ayet açar. Önceki seçiminiz temizlenir. Yeni aramaya başlamak için yeni ayetteki bir kelimeye dokunun.
- Bazı sözlük girdileri, aynı kelimeye başka bir sözlükte gönderme yapar. Kurulu tüm sözlükleriniz boyunca izi sürmek için o iç bağlantılara dokunun.

## Sözlük ile Kelime Bilgisi arasındaki farklar

İki araç da ayet menüsünden açılır, ama farklı işler yaparlar:

- **Sözlük** (📖) dokunduğunuz İngilizce kelimeyi okur ve kurulu İngilizce sözlüklerinizde bulur. "Antlaşma", "kefaret" ya da "Ferisi" gibi İncil-ilahiyat kelimelerinin sade dilli tanımları için doğru araçtır.
- **Kelime Bilgisi** (?) ayetin arkasındaki özgün Yunanca ya da İbranice kelimeyi okur ve kurulu leksıklarınızda bulur. Ciddi kelime incelemeleri, bir Yunanca kelimenin geçtiği her yeri bulma ve özgün dil tanımlarını okuma için doğru araçtır.

Emin olmadığınızda sözlükle başlayın. Özgün dile inmek isterseniz Kelime Bilgisi'ne geçin. Tam Kelime Bilgisi anlatımı için [Yorumlar ve Leksiklar](theodia://help/commentaries-and-lexicons) kılavuzuna bakın.

## İlgili kılavuzlar

- [Çalışma Modu](theodia://help/study-mode) kılavuzu, ayet menüsünü ayrıntılı ve Yer İmi, Vurgu, Seslendir, Karşılaştır, Çapraz Referanslar, AI Yorumu, Kelime Bilgisi ve Notlar'ın yanında Sözlük (📖) aracının nerede durduğunu açıklar.
- [Yorumlar ve Leksiklar](theodia://help/commentaries-and-lexicons) kılavuzu, Kelime Bilgisi'ni ve özgün dil leksiklarını kapsar.
- [Kaynak Nedir?](theodia://help/what-are-resources) kılavuzu, sözlük kaynakları dahil Theodia'nın kullandığı farklı dosya türlerini açıklar.
- [Sık Görülen Sorunlar](theodia://help/common-problems) kılavuzunda boş sonuçlar ve diğer sözlük sorunları için çözümler vardır.
