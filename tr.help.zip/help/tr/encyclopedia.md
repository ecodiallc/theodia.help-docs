---
title: Ansiklopedi
level: everyday
categories: study
summary: Ansiklopedi makalelerine nasıl bakılacağı ve başvuru eserlerinin nasıl gezileceği.
---

# Ansiklopedi

Theodia, İncil'le ilgili makalelere, kişilere, yerlere ve konulara bakmak için yerleşik bir **Ansiklopedi** içerir. Uygulama, yerleşik olarak _Kitto's Illustrated Commentary_ (KIT) ile birlikte gelir; ek ansiklopedileri depodan indirebilirsiniz.

## Theodia'daki ansiklopedi nedir?

Ansiklopedi, kısa makalelerden oluşan bir başvuru eseridir. Her makale bir kişiyi, yeri, olayı ya da İncil konusunu kapsar. Belirli bir ayeti açıklayan bir yorumun aksine, ansiklopedi makalesi konunun kendisini açıklar.

## Ansiklopedi nasıl açılır

1. Alttaki araç çubuğunda **Ansiklopedi**'ye dokunun.
2. Üstteki kısaltma satırından bir ansiklopedi seçin.
3. Arama kutusuna bir konu, kişi ya da yer yazın.

Arama için sonuçların ve otomatik tamamlama önerilerinin görünmesi üzere en az **3 karakter** gerekir.

## Makale okuma

- **Telefonda** herhangi bir sonuca dokunmak makaleyi yeni bir ekranda açar.
- **Tablette** makale sağdaki panelde açılır; liste solda kalır.

## Ansiklopedi seçme

O ansiklopediye geçmek için bir kısaltma rozetine (örneğin **KIT**) dokunun. Bir seferde birden çok ansiklopedide arama yapmak için **Arama** sekmesini kullanın ve arama modu olarak **Ansiklopedi**'yi seçin.

## Daha çok ansiklopedi alma

1. **Ayarlar**'ı açın.
2. **Kaynakları Yönet**'e dokunun.
3. **GitHub'dan Kur**'a dokunun.
4. **Ansiklopediler** sekmesini seçin.
5. İstediğiniz ansiklopedinin yanındaki indirme düğmesine dokunun.

Ansiklopediler Theodia'nın ansiklopedi GitHub deposundan indirilir ve otomatik kurulur. Kurulu ansiklopediler Ansiklopedi ekranında ve Arama'da görünür.

Bir ansiklopediyi yerel dosyadan da kurabilirsiniz: **Kaynakları Yönet** bölümünde **Yerel Dosya Kur**'a dokunun ve bir `.encyclopedia` dosyası seçin. Dosya uygulamanın ansiklopediler klasörüne kopyalanır ve ortak arama dizinine eklenir.

## Tam başlık için uzun basın

Arama ekranında ansiklopedi rozetleri kısa kısaltmalar gösterir. Tam ansiklopedi adını görmek için bir rozete uzun basın.

## Ansiklopedi ne zaman kullanılır

- Bir pasajı okurken ya da okumadan önce bir kişiye, yere ya da konuya bakın.
- Birçok ayete yayılan bir İncil kelimesi ya da kavramı hakkında arka plan alın.
- Daha derin çalışma için bir yorumla yan yana okuyun.
