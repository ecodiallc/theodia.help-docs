---
title: Harici Klavye Kısayolları
level: everyday
categories: [tablet, settings]
summary: Harici klavye takılıyken iPad için tam klavye kısayolu başvurusu.
---

# ⌨️ Harici Klavye Kısayolları

Theodia'yı harici bir klavyeyle (Magic Keyboard, Bluetooth klavye ya da USB klavye) iPad'de kullanıyorsanız ekrana dokunmadan uygulamada gezinebilirsiniz.

> **Mod:** Bazı kısayollar yalnızca ilgili özellik geçerli kullanıcı modunuzda kullanılabilirken çalışır. Örneğin `Cmd + Option + 6` (Yer İmleri) ve `Cmd + Option + 7` (Vurgular) Okuyucu modunda hiçbir şey yapmaz. Modları **Ayarlar** → **Uygulama Kullanıcı Modu** üzerinden değiştirin.

Kısayollar **iPad**'de çalışır.

## Genel kısayollar (her yerde)

| Kısayol           | Eylem                                        |
| ------------------ | ------------------------------------------- |
| `Cmd + /`          | Bu klavye kısayolları yardımını göster      |
| `Cmd + .`          | Pencereyi / paneli kapat (Escape alternatifi)    |
| `Cmd + Option + 1` | Giriş sekmesine git                              |
| `Cmd + Option + 2` | İnciller sekmesine git                            |
| `Cmd + Option + 3` | Kitaplar sekmesine git                             |
| `Cmd + Option + 4` | Günlük Öğretiler sekmesine git                       |
| `Cmd + Option + 5` | Arama sekmesine git                            |
| `Cmd + Option + 6` | Yer İmleri sekmesine git (Standart ve Scholar)  |
| `Cmd + Option + 7` | Vurgular sekmesine git (Standart ve Scholar) |
| `Cmd + Option + 8` | Notlar sekmesine git (Standart ve Scholar)      |
| `Cmd + Option + 9` | AI sekmesine git (yalnızca Scholar, etkinse)     |
| `Cmd + Option + 0` | Yardım sekmesine git                              |
| `Cmd + Option + I` | Hakkında sekmesine git                             |
| `Cmd + [`          | Geri git                                     |
| `Cmd + F`          | Arama'yı aç                                 |
| `Cmd + K`          | Başlatıcı Menü'yü aç (Scholar)                |
| `Cmd + ,`          | Ayarlar'ı aç                               |
| `Cmd + Shift + M`  | Ana menüyü aç                              |
| `Cmd + Shift + T`  | Temayı döngüye al (varsayılan / koyu)                |
| `Cmd + Shift + U`  | Kullanıcı modu seçiciyi aç                       |
| `Escape`           | Pencereyi kapat / paneli kapat                 |

## İncil Okuyucu kısayolları

Bunlar hem **Çalışma Okuyucu** hem de **Odak Okuyucu**'da çalışır.

| Kısayol           | Eylem                                                       |
| ------------------ | ------------------------------------------------------------ |
| `← Sol Ok`     | Önceki bölüm                                             |
| `→ Sağ Ok`    | Sonraki bölüm                                                 |
| `Cmd + R`          | Çalışma ve Odak Okuyucu arasında geçiş yap (Standart ve Scholar) |
| `Cmd + Option + V` | Sürüm seçiciyi aç                                          |
| `Cmd + Option + B` | Kitap seçiciyi aç                                             |
| `Cmd + Option + C` | Bölüm seçiciyi aç                                          |
| `Cmd + T`          | TTS'yi döngüye al (çalarken/duraklatılmışken durdur, boştayken başlat)       |
| `Cmd + Option + T` | TTS'yi Çal / Duraklat                                             |

## Yalnızca Çalışma Okuyucu

| Kısayol           | Eylem                                                                 |
| ------------------ | ---------------------------------------------------------------------- |
| `↑ Yukarı Ok`       | Önceki ayeti seç                                                  |
| `↓ Aşağı Ok`     | Sonraki ayeti seç                                                      |
| `Cmd + ↑`          | İlk ayeti seç                                                     |
| `Cmd + ↓`          | Son ayeti seç                                                      |
| `Cmd + ←`          | 1. bölüme atla                                                      |
| `Cmd + →`          | Son bölüme atla                                                   |
| `Cmd + 0`–`9`      | Doğrudan ayete atlama (rakamları yazın, örn. 16. ayet için `Cmd + 1` `Cmd + 6`) |
| `Cmd + P`          | Paralel İncilleri döngüye al (Standart ve Scholar)                          |
| `Cmd + B`          | Seçili ayeti yer imine ekle (Standart ve Scholar)                         |
| `Cmd + H`          | Seçili ayeti vurgula (Standart ve Scholar)                        |
| `Cmd + N`          | Seçili ayet için not ekle (Standart ve Scholar)                     |
| `Cmd + C`          | Seçili ayetin çevirilerini karşılaştır (Standart ve Scholar)             |
| `Cmd + X`          | Seçili ayet için çapraz referansları aç (Standart ve Scholar)        |
| `Cmd + I`          | Kelime bilgisini aç (Scholar)                                               |
| `Cmd + D`          | Seçili ayet için sözlüğü aç (Scholar)                           |
| `Cmd + A`          | Seçili ayet için AI panelini aç (Scholar)                             |
| `Cmd + Option + S` | Alt başlıkları döngüye al                                                     |
| `Cmd + Option + W` | Açık tüm çalışma panellerini kapat                                            |
| `Cmd + Option + M` | Ayet eylem menüsünü aç                                                 |

## Yalnızca Odak Okuyucu

| Kısayol       | Eylem           |
| -------------- | ---------------- |
| `↑ Yukarı Ok`   | Yukarı kaydır        |
| `↓ Aşağı Ok` | Aşağı kaydır      |
| `Cmd + ↑`      | En üste kaydır    |
| `Cmd + ↓`      | En alta kaydır |
| `Cmd + =`      | Yakınlaştır          |
| `Cmd + -`      | Uzaklaştır         |

## Arama

| Kısayol           | Eylem                           |
| ------------------ | -------------------------------- |
| `Return`           | Aramayı çalıştır                   |
| `Cmd + Return`     | Aramayı temizle ve girişi odakla     |
| `Cmd + ↑`          | Sonuçları yukarı kaydır                |
| `Cmd + ↓`          | Sonuçları aşağı kaydır              |
| `Cmd + Option + A` | Tüm kapsam öğelerini seç           |
| `Cmd + Option + C` | Tüm kapsam öğelerinin seçimini kaldır         |
| `Cmd + Option + B` | İncil arama modu                |
| `Cmd + Option + O` | Kitap arama modu                 |
| `Cmd + Option + D` | Sözlük arama modu (Scholar) |
| `Cmd + Option + X` | Leksik arama modu (Scholar)    |

## Arama Sonuçları

| Kısayol  | Eylem              |
| --------- | ------------------- |
| `Cmd + S` | Tümünü kaydet sayfasını aç |
| `Cmd + ↑` | Sonuçları yukarı kaydır   |
| `Cmd + ↓` | Sonuçları aşağı kaydır |

## Kitap Okuyucu

| Kısayol           | Eylem                   |
| ------------------ | ------------------------ |
| `← Sol Ok`     | Önceki bölüm         |
| `→ Sağ Ok`    | Sonraki bölüm         |
| `Cmd + ↑`          | Önceki bölüm         |
| `Cmd + ↓`          | Sonraki bölüm         |
| `↑ Yukarı Ok`       | Yukarı kaydır                |
| `↓ Aşağı Ok`     | Aşağı kaydır              |
| `Cmd + B`          | Geçerli bölümü yer imine ekle |
| `Cmd + J`          | Bölüm seçiciyi aç      |
| `Cmd + L`          | Ses seçiciyi aç        |
| `Cmd + T`          | TTS'yi döngüye al               |
| `Cmd + Option + T` | TTS'yi Çal / Duraklat         |

## Günlük Öğreti Okuyucu

| Kısayol           | Eylem              |
| ------------------ | ------------------- |
| `← Sol Ok`     | Önceki gün        |
| `→ Sağ Ok`    | Sonraki gün            |
| `↑ Yukarı Ok`       | Yukarı kaydır           |
| `↓ Aşağı Ok`     | Aşağı kaydır         |
| `Cmd + ↑`          | Yukarı kaydır (büyük)   |
| `Cmd + ↓`          | Aşağı kaydır (büyük) |
| `Cmd + D`          | Tarih seçiciyi aç    |
| `Cmd + T`          | TTS'yi döngüye al          |
| `Cmd + Option + T` | TTS'yi Çal / Duraklat    |

## AI Sohbeti

| Kısayol           | Eylem                     |
| ------------------ | -------------------------- |
| `Cmd + Return`     | Mesajı gönder               |
| `Cmd + N`          | Yeni sohbet                   |
| `Cmd + D`          | Sohbet çekmecesini döngüye al |
| `Cmd + Option + C` | Geçerli sohbeti temizle         |
| `Cmd + S`          | Kaydet menüsünü aç             |
| `Escape`           | Çekmeceyi / menüyü kapat        |

## Yer İmleri

| Kısayol                      | Eylem                             |
| ----------------------------- | ---------------------------------- |
| `↑ Yukarı Ok` / `↓ Aşağı Ok` | Yer imini seç                    |
| `Return`                      | Yer imini aç (tablet: seç)     |
| `Cmd + R`                     | Yer imini bağlamında oku           |
| `Cmd + M`                     | Seçili yer imini klasörlere taşı |
| `Cmd + N`                     | Klasörleri yönet                     |
| `Escape`                      | Ayrıntı panelini / klasör seçiciyi kapat |

**Klasöre Kaydet** seçicisinde `↑ Yukarı Ok` / `↓ Aşağı Ok` seçimi taşır, `Return` seçili klasörü değiştirir ya da vurgulanan eylemi etkinleştirir ve `Escape` seçiciyi kapatır. **+ Klasör Oluştur** satırı listenin tepesindedir.

## İncil Notları

| Kısayol                      | Eylem                |
| ----------------------------- | --------------------- |
| `↑ Yukarı Ok` / `↓ Aşağı Ok` | Notu seç           |
| `Return`                      | Notu aç             |
| `Cmd + Return`                | Filtre girişini odakla    |
| `Escape`                      | Ayrıntıyı / düzenleyiciyi kapat |

## Vurgular

| Kısayol                      | Eylem             |
| ----------------------------- | ------------------ |
| `↑ Yukarı Ok` / `↓ Aşağı Ok` | Vurguyu seç   |
| `Return`                      | Vurguyu aç     |
| `Cmd + Return`                | Filtre girişini odakla |
| `Escape`                      | Ayrıntı panelini kapat |

## İncil Listesi

| Kısayol                                 | Eylem                            |
| ---------------------------------------- | --------------------------------- |
| `Tab` / `→ Sağ Ok` / `↓ Aşağı Ok` | Sonraki İncil                        |
| `← Sol Ok` / `↑ Yukarı Ok`            | Önceki İncil                    |
| `Return`                                 | Odaktaki İncil'i aç                |
| `Cmd + Shift + S`                        | Odaktaki İncil için favoriyi döngüye al |
| `Escape`                                 | Geri git                           |

## İncil Kitapları Ekranı

| Kısayol                | Eylem                     |
| ----------------------- | -------------------------- |
| `Tab` / `→ Sağ Ok` | Sonraki kitap                  |
| `← Sol Ok`          | Önceki kitap              |
| `↓ Aşağı Ok`          | Izgarada alttaki kitap         |
| `↑ Yukarı Ok`            | Izgarada üstteki kitap         |
| `Cmd + ↓`               | Sonraki bölüm (ET / YT)     |
| `Cmd + ↑`               | Önceki bölüm (ET / YT) |
| `Return`                | Odaktaki kitabı aç          |
| `Escape`                | Geri git                    |

## Kitap Listesi

| Kısayol                                 | Eylem            |
| ---------------------------------------- | ----------------- |
| `Tab` / `→ Sağ Ok` / `↓ Aşağı Ok` | Sonraki kitap         |
| `← Sol Ok` / `↑ Yukarı Ok`            | Önceki kitap     |
| `Return`                                 | Odaktaki kitabı aç |
| `Escape`                                 | Geri git           |

## İncil Bölümleri Ekranı

| Kısayol                                 | Eylem               |
| ---------------------------------------- | -------------------- |
| `Tab` / `→ Sağ Ok` / `↓ Aşağı Ok` | Sonraki bölüm         |
| `← Sol Ok` / `↑ Yukarı Ok`            | Önceki bölüm     |
| `Return`                                 | Odaktaki bölümü aç |
| `Escape`                                 | Geri git              |

## Kitap Bölümleri Ekranı

| Kısayol               | Eylem                    |
| ---------------------- | ------------------------- |
| `Tab` / `↓ Aşağı Ok` | Sonraki bölüm              |
| `↑ Yukarı Ok`           | Önceki bölüm          |
| `Return`               | Odaktaki bölümü aç      |
| `Cmd + Return`         | Arama/filtre girişini odakla |
| `Escape`               | Geri git                   |

## Günlük Öğreti Listesi

| Kısayol                                 | Eylem                  |
| ---------------------------------------- | ----------------------- |
| `Tab` / `→ Sağ Ok` / `↓ Aşağı Ok` | Sonraki günlük öğreti         |
| `← Sol Ok` / `↑ Yukarı Ok`            | Önceki günlük öğreti     |
| `Return`                                 | Odaktaki günlük öğretiyi aç |
| `Escape`                                 | Geri git                 |

## Grafikler

İstatistikler, Hedefler ve Uyum Dizini ekranlarında.

| Kısayol        | Eylem                                 |
| --------------- | -------------------------------------- |
| `← Sol Ok`  | Grafikteki önceki kategoriyi seç |
| `→ Sağ Ok` | Grafikteki sonraki kategoriyi seç     |

Grafik altındaki altyazı seçimi izler ve yeni değer seslendirilir.

## Ana menü (açıyken)

| Kısayol       | Eylem                  |
| -------------- | ----------------------- |
| `↑ Yukarı Ok`   | Önceki menü öğesi      |
| `↓ Aşağı Ok` | Sonraki menü öğesi          |
| `Return`       | Vurgulanan öğeyi seç |
| `Escape`       | Menüyü kapat              |

## Ayarlar

| Kısayol | Eylem                    |
| -------- | ------------------------- |
| `Escape` | Açık pencereyi / seçiciyi kapat |

## Düzenleyici Pencereleri

| Kısayol  | Eylem         |
| --------- | -------------- |
| `Cmd + S` | Kaydet           |
| `Escape`  | İptal / kapat |

## Yazma koruması

Bir metin alanına odaklandığınızda (arama kutusu, not düzenleyici, AI girişi) ok tuşları ve `Boşluk` gibi Cmd'siz kısayollar yanlışlıkla gezinmeyi tetiklememesi için bastırılır. `Cmd` tuşunu kullanan kısayollar (örneğin `Cmd + S`, `Cmd + B`) yazarken de çalışmaya devam eder.
