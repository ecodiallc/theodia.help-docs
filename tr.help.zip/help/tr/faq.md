---
title: Sık Sorulan Sorular
level: everyday
categories: faq
summary: Theodia'nın kullanımıyla ilgili en yaygın soruların yanıtları.
---

# Sık Sorulan Sorular

## Theodia ücretli mi?

Theodia tek seferlik bir satın almadır. Abonelik yok, reklam yok, uygulama içi satın alma yok ve bağış talebi yok. Katalogdaki tüm ek kaynaklar, uygulamayı satın aldıktan sonra ücretsiz indirilebilir.

## İnternet bağlantısı gerekli mi?

Hayır. Uygulama ve veri dosyaları kurulduktan sonra her şey çevrimdışı çalışır. Sinyal olmadan okuyabilir, arama yapabilir, vurgu ekleyebilir, not alabilir ve çalışma araçlarının çoğunu kullanabilirsiniz.

İnternet gerektiren tek özellik yeni kaynak indirmektir.

## Verilerim nerede saklanır?

Tüm yer imleriniz, vurgularınız, notlarınız ve ayarlarınız cihazınızda saklanır. Hiçbir sunucuya yüklenmezler.

Bunları elle yedekleyebilirsiniz. Nasıl yapılacağı için [Verilerinizi Yedekleme](theodia://help/backups) kılavuzuna bakın.

## İncil'i sesli dinleyebilir miyim?

Evet. Herhangi bir bölümü açın, menüye dokunun ve sesli okuma seçeneğini belirleyin. Cihazınızda bir metinden konuşma sesi kurulu olmalıdır. Daha fazlası için [Sesli Okuma](theodia://help/tts) kılavuzuna bakın.

## Bir ayeti nasıl ararım?

Giriş ekranındaki Komut'a `John 3:16` gibi bir referans yazabilir ya da kelime ya da ifadeyle arama yapmak için **Arama** sekmesini kullanabilirsiniz.

## Nasıl hata bildiririm ya da özellik öneririm?

Hakkında ekranında **Öneri / Sorun Gönder**'e dokunun, [GitHub'da bildirin](https://github.com/ecodiallc/theodia.app/issues/new) ya da [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions) sayfasını ziyaret edin.

## Hangi cihazlar destekleniyor?

Theodia iPhone, iPad ve Android telefon ve tabletlerde çalışır. Çekirdek veri dosyaları için en az 2 GB boş depolama alanı olan cihazlarda en iyi şekilde çalışır.

## Harici klavye kullanabilir miyim?

Evet. Theodia, iPad'de Bluetooth ve USB klavyeleri destekler. Gezinme, arama ve birçok okuma özelliğinin klavye kısayolları vardır. Tam liste için [Harici Klavye Kısayolları](theodia://help/external-keyboard-shortcuts) kılavuzuna bakın.

## Hangi diller destekleniyor?

Uygulama arayüzü İngilizce, Arapça, Çince (Basit ve Geleneksel), Çekçe, Danca, Felemenkçe, Filipince, Fransızca, Almanca, Yunanca, İbranice, Hintçe, Endonezce, İtalyanca, Japonca, Korece, Lehçe, Portekizce (Brezilya), Rumence, Rusça, İspanyolca, Svahili, İsveççe, Tayca, Türkçe, Ukraynaca ve Vietnamca olarak sunulur.

İncil metninin dili, kurulu olduğunuz çevirilere bağlıdır.

## Dili nasıl değiştiririm?

**Ayarlar**'a gidin ve dil seçeneğini arayın.

## Sorum burada değil. Daha fazla yardım nereden alabilirim?

Kalan yardım kılavuzlarına konuya göre göz atın ya da [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions) topluluğunda bir soru sorun.

İpucu: **Yardım ve Kılavuzlar** ana ekranında, eşleşen kılavuzu bulmak için arama kutusuna `notifications` ya da `search` gibi bir konu yazın.
