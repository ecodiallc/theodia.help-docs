---
title: İlk Bölümünüzü Okumak
level: beginner
categories: [start, read]
summary: Bir bölümü açmanın ve okumanın adım adım anlatımı.
---

# İlk Bölümünüzü Okumak

Bu kılavuz size bir bölümü ilk kez açmayı adım adım gösterir.

## Adım 1: İncil sekmesini açın

Ekranın altına bakın. Bir dizi sekme göreceksiniz. **İncil** yazan sekmeye dokunun.

## Adım 2: Bir kitap seçin

İncil kitaplarının bir listesini göreceksiniz. Yaratılış ilk sırada. Yuhanna ortaya yakın. Vahiy son sırada.

İstediğiniz kitabın adına dokunun.

## Adım 3: Bir bölüm seçin

Kitabın kaç bölümü varsa 1'den o sayıya kadar numaraları göreceksiniz. İstediğiniz bölüme dokunun.

Bölüm açılır. Ayetler ekrandadır.

## Adım 4: Gezinin

- Sonraki bölüme geçmek için **sola** kaydırın.
- Geri dönmek için **sağa** kaydırın.

## Adım 5: Bir ayetle etkileşim kurun

Bir ayetle yapabilecekleriniz kullanıcı modunuza bağlıdır.

### Okuyucu modu

Okuyucu modu temiz ve dikkatten uzaktır.

- Kısa bir süre vurgulanması için bir ayete dokunun.
- Çalışma aracı, yer imi ya da menü yoktur.
- Daha fazla özellik istiyorsanız **Ayarlar**'da **Standart** ya da **Scholar** moduna geçin.

### Standart mod

Standart mod, kişisel İncil çalışması için günlük özellikler ekler.

Şu seçenekleri içeren bir menü açmak için bir ayete dokunun:

- Ayeti **yer imine ekleyin**.
- Bir renkle **vurgulayın**.
- Ayete **not ekleyin**.
- Ayet metnini **kopyalayın**.
- Ayeti başka bir çeviride **karşılaştırın**.
- Ayet için **çapraz referanslara bakın**.

### Scholar modu

Scholar modu, derin İncil çalışması için her aracın kilidini açar.

Standart moddaki her şeyi içeren bir menü açmak için bir ayete dokunun, ayrıca:

- Ayet üzerine **yorum**.
- **Kelime Bilgisi** ve özgün dil aramaları.
- **Sözlük** tanımları.
- Daha derin çalışma için **AI asistanı**.

Modları **Ayarlar**'da dilediğiniz zaman değiştirebilirsiniz.

## Belirli bir araçta yardım mı gerekiyor?

Her aracın kendi kılavuzu vardır. Hepsini görmek için ana sayfada **Yardım**'a dokunun. [Çalışma Modu](theodia://help/study-mode) kılavuzu iyi bir başlangıç noktasıdır — ayet menüsündeki her aracı tek tek gösterir.

Nelerin nerede olduğunu hâlâ öğreniyorsanız [Uygulama Yerleşimi ve Gezinme](theodia://help/navigating-the-app) kılavuzuna bakın. Ana ekranı, ana menüyü ve alttaki araç çubuğunu açıklar.

## Daha fazla kaynak mı istiyorsunuz?

Uygulama, serbestçe sunulan birkaç İncil sürümüyle birlikte gelir. Daha fazla eklemek ya da yorum, kitap ya da günlük öğreti eklemek isterseniz [GitHub'dan Ek Kaynaklar Alma](theodia://help/getting-core-files) kılavuzuna bakın. Onları nerede bulacağınızı ve nasıl ekleyeceğinizi gösterir.
