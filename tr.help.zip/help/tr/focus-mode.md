---
title: Odak Modu
level: beginner
categories: [layout, read]
summary: Uzun pasajları okumanın temiz, dikkatten uzak bir yolu.
---

# Odak Modu

> **Mod:** Odak Modu, **Okuyucu** modundaki okuyucudur. **Standart** ve **Scholar** modlarında da Çalışma Modu'na alternatif olarak mevcuttur. Modları **Ayarlar** → **Uygulama Kullanıcı Modu** üzerinden değiştirebilirsiniz.

Odak Modu, bir İncil bölümünü önünde düğme ya da menü olmadan okumanın yoludur. Uzun okuma seansları için iyidir.

## Nasıl açılır

1. Herhangi bir bölümü açın.
2. Ekranın üstündeki simge satırında 📖 düğmesine dokunun. Aynı bölümü Odak Modu'nda açar.
3. Menüler ve düğmeler gizlenir. Yalnızca İncil metni kalır.

**Okuyucu** modunda bölümler otomatik olarak Odak Modu'nda açılır. Geçilecek bir Çalışma Modu olmadığından 📖 düğmesi gizlidir.

## Odak Modu'nda yapabilecekleriniz

- Okumak için **kaydırın**.
- Sonraki ya da önceki bölüme geçmek için **kaydırma hareketi** yapın.
- Çalışma Modu'na geri dönmek için alt çubuktaki **📖 düğmesine** dokunun. (Okuyucu modunda gizlidir.)
- Bölümün sesli okunması için alt çubuktaki **🔊 düğmesine** dokunun. Oynat, duraklat, geri sarma, ileri sarma ve ses seçici içeren bir mini kontrol çubuğu görünür. (Okuyucu modunda gizlidir — TTS Standart ya da Scholar gerektirir.)

## Odak Modu'nun iyi bir kullanımı

- Tüm bir kitabı, bir seferde bir bölüm okumak.
- Günlük öğreti ya da sessiz zaman için uzun bir pasaj okumak.
- Sesli okurken dikkatin dağılmadan takip etmek.

## Çalışma Modu'na geçiş

Odak Modu her çalışma aracını gizler, ama bunlar hâlâ tek dokunuş uzaktadır. Aynı bölümü [Çalışma Modu](theodia://help/study-mode)'nda açmak için ekranın üstündeki 📖 düğmesine dokunun. Çalışma Modu, yorum, çapraz referans, leksik aramaları ve notlarla birlikte tam okuyucudur. Çalışma Modu'nun neler yapabildiğini öğrenmek için [Çalışma Modu](theodia://help/study-mode) kılavuzuna bakın.

**Okuyucu** modunda, Çalışma Modu mevcut olmadığından 📖 düğmesi gizlidir.
