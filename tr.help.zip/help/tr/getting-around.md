---
title: Hızlı Gezinme
level: beginner
categories: layout
summary: Theodia'da bir ayete, bölüme ya da ekrana atlamanın her hızlı yolu.
---

# Hızlı Gezinme

Bu kılavuz gezinme için bir hızlı başvuru sayfasıdır. Bulunduğunuz yerden gitmek istediğiniz yere hızlıca geçmenin her yolunu kapsar.

## Doğrudan bir ayete atlama

Herhangi bir ayeti açmanın en hızlı yolu ana ekrandaki **Komut**'tur.

- `John 3:16` yazın ve Git'e dokunun.
- `Psalms 23` yazın ve Git'e dokunun.
- `Genesis 1` yazın ve Git'e dokunun.

Uygulama, tam bölümü açar (bir ayet yazdıysanız o ayete kaydırır).

## Bölümler arasında kaydırma

Bir bölüm okurken:

- **Sola kaydırın** → sonraki bölüm.
- **Sağa kaydırın** → önceki bölüm.

Bu, kitaplar arasında da çalışır. Çıkış 40'tan sonra sola kaydırmak sizi Levililer 1'e götürür.

## Üst çubuğu kullanın

Okurken ekranın üstü geçerli **çeviriyi**, **kitabı** ve **bölümü** gösterir.

- İncil değiştirmek için çeviri adına dokunun.
- Farklı bir kitap seçmek için kitap adına dokunun.
- Farklı bir bölüm seçmek için bölüm numarasına dokunun.

## Yer iminden atlama

Bir ayet kaydettiyseniz:

1. **Yer İmleri** sekmesini açın.
2. Herhangi bir girdiye dokunun.
3. Doğrudan o ayete gidersiniz.

## Aramadan atlama

1. **Arama** sekmesini açın.
2. Bir kelime ya da ifade yazın.
3. Herhangi bir sonuca dokunun.
4. Uygulama, bölümü arama kelimeleriniz sarıyla vurgulanmış olarak açar.

## Okuma yerleşimlerini değiştirme

İncil okuyucunun iki yerleşimi vardır:

- **Çalışma Modu** — bölümü, tüm çalışma araçları tek dokunuş uzakta olacak şekilde gösterir.
- **Odak Modu** — yalnızca metni bırakarak her araç ve menüyü gizler.

Geçiş için: okurken ekranın üstündeki **📖** düğmesine dokunun. Geri dönmek için yeniden dokunun. (Okuyucu modu her zaman Odak Modu'nda kalır.)

## Alttaki sekmeleri kullanın

Ekranın altındaki simge satırı her zaman görünürdür. O bölüme geçmek için herhangi bir sekmeye dokunun. Tam sekmeler kullanıcı modunuza bağlıdır:

**Tüm modlar:**

- **Giriş** — ana ekrana dönün.
- **İnciller** — çeviri listesi.
- **Arama** — İncil'de, kitaplarda, sözlüklerde, leksiklarda ve PDF'lerde arama yapın.
- **Ayarlar** — tercihler ve kaynaklar.

**Standart ve Scholar ayrıca şunları görür:**

- **Yer İmleri** — kaydedilmiş ayetler.
- **Vurgular** — renkle işaretlenmiş ayetler.
- **Notlar** — kişisel notlarınız.
- **PDF'ler** — içe aktardığınız PDF belgeleri.

**Scholar ayrıca şunları görür:**

- **AI** — AI asistanı (Ayarlar'da açıldıysa).

### Nerede kaldığınızı hatırlama

Her sekme kendi gezinme geçmişini tutar. Bir sekmeye geri döndüğünüzde o bölümün başlangıç ekranına değil, **kaldığınız yere** dönersiniz.

- **İnciller** sekmesini açtınız, bir çeviri seçtiniz, bir bölüm açtınız, sonra **Arama**'ya geçtiniz. Daha sonra yeniden **İnciller**'e dokunduğunuzda doğruca o bölümde olursunuz.
- **Yer İmleri** sekmesini açtınız, yer imli bir ayete dokundunuz, sonra **Ayarlar**'a geçtiniz. **Yer İmleri**'ne yeniden dokunmak sizi yer imi listesine döndürür.

Bu her sekme için geçerlidir. Her biri, o sekmenin içinde açıkça farklı bir ekrana gitene dek yerinizi hatırlar.

### Bir sekmeyi ne sıfırlar

Bir sekme yalnızca şu durumlarda kök ekranına döner:

- Zaten o sekmedeyseniz ve aynı sekme simgesine yeniden dokunursanız. Bu, onu başlangıca sıfırlamanın hızlı yoludur.
- Uygulama zorla kapatılıp yeniden açıldığında.

### Alttaki sekmeler ile ana menü

- **Alttaki sekmeler** — her sekme kendi yığınını hatırlar. Bir sekmeye dokunmak sizi kaldığınız yere döndürür.
- **Ana menü** — bir öğeye dokunmak o ekrana gider. Bir örtü değil, açılır bir listedir.

Örnek:

- Yuhanna 3'ü okuyorsunuz. **Yer İmleri** sekmesine dokunun, sonra yeniden **İnciller**'e dokunun. Yuhanna 3'e dönersiniz.
- Yuhanna 3'ü okuyorsunuz. Menüyü açın ve **Notlar**'a dokunun. Notlarınızı gözden geçirin, sonra Yuhanna 3'e dönmek için **İnciller** sekmesine dokunun.

## İpuçları

- Ana ekran, hangi bölümlerin açık ya da kapalı olduğunu hatırlar.
- Bir sekme eksikse **Ayarlar** → **Uygulama Kullanıcı Modu** altındaki **kullanıcı modunuzu** kontrol edin. Okuyucu modu yer imlerini, vurguları, notları ve AI'yi gizler. Standart mod AI'yi gizler. Ayrıca **Ayarlar**'da bir özelliği etkinleştirmeniz ya da bir kaynak kurmanız gerekebilir.
