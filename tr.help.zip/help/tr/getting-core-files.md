---
title: Ek Kaynaklar Alma
level: everyday
categories: resources
summary: Theodia'ya İncillerin, yorumların, kitapların ve diğer kaynakların nasıl ekleneceği.
---

# Ek Kaynaklar Alma

Theodia bazı kaynakları yerleşik olarak getirir, ama daha fazlasını ekleyebilirsiniz. En kolay yol, uygulama içindeki **Kaynakları Yönet** ekranıdır.

## Neler ekleyebilirsiniz

- **İnciller** — farklı dillerde daha çok çeviri
- **Yorumlar** — ayetleri açıklayan çalışma notları
- **Kitaplar** — Hristiyan klasikleri ve başvuru eserleri
- **Günlük öğretiler** — her güne ait öğreti okumaları
- **Çekirdek dosyalar** — biçimbilim, çapraz referanslar ve Marvel Interlinear Bible (MIB) gibi büyük veri dosyaları

## Uygulama içinden kaynak ekleme

1. **Ayarlar**'ı açın.
2. **Kaynakları Yönet**'e dokunun.
3. Bir sekme seçin: **Çekirdek**, **İnciller**, **Yorumlar**, **Kitaplar** ya da **Günlük Öğretiler**.
4. Listeye göz atın. Hakkında daha fazla okumak için bir kaynağa dokunun.
5. İstediğinizi seçmek için onay kutusuna dokunun.
6. Alttaki **İndir**'e dokunun. Dosyalar indirilir ve otomatik kurulur.

Kurulduktan sonra kaynak uygulamada hemen görünür. Yeniden başlatmanıza gerek yoktur.

## Çekirdek dosyalar

**Çekirdek** sekmesi, daha derin çalışma özelliklerini besleyen büyük veri dosyalarını içerir. Bunlar:

- Biçimbilim verisi (özgün dil kelime biçimleri)
- Çapraz referans veritabanları
- Marvel Interlinear Bible (MIB)

Çekirdek dosyaları yalnızca bir kez indirmeniz gerekir. Cihazınızda kalırlar ve çevrimdışı çalışırlar.

## Global İnciller

**Global İnciller** sekmesi, daha geniş bir koleksiyondan İncil çevirilerini içerir. Ana **İnciller** sekmesinde istediğiniz çeviriyi görmüyorsanız buraya bakın.

## Kurulu kaynakları yönetme

**Kaynakları Yönet** ana ekranında (indirme sekmesi değil) şunları yapabilirsiniz:

- Bir kaynağı silmeden **etkinleştirin ya da devre dışı bırakın**. Devre dışı bırakılan kaynaklar cihazınızda kalır ama menülerde gizlenir.
- Yer açmak için bir kaynağı **silin**. Daha sonra yeniden indirebilirsiniz.

## Kendi dosyalarınızı ekleme

Başka bir yerden — bir arkadaş, başka bir proje ya da bir web sitesi — bir kaynak dosyanız varsa onu doğrudan içe aktarabilirsiniz:

1. **Kaynakları Yönet** bölümünde **Yerel Dosyayı İçe Aktar**'a dokunun.
2. Dosyayı cihazınızdan seçin.
3. Uygulama dosyayı okur ve kitaplığınıza ekler.

Uygulama şu dosya türlerini kabul eder:

- `.bible` — İncil çevirileri
- `.commentary` — yorumlar
- `.lexicon` — leksiklar
- `.book` — kitaplar
- `.devotional` — günlük öğretiler

## Özel bir GitHub deposuna bağlanma

Birisi, Theodia uyumlu kaynaklarla bir GitHub deposu yönetiyorsa onu özel bir kaynak olarak ekleyebilirsiniz:

1. **Ayarlar → GitHub Depoları** bölümüne gidin.
2. **Depo Ekle**'ye dokunun.
3. GitHub URL'sini girin (örneğin `https://github.com/username/repo-name`).
4. Deponun hangi kaynak türlerini içerdiğini seçin (İnciller, yorumlar ya da kitaplar).
5. Kaydedin.
6. **Kaynakları Yönet** bölümüne dönün. O depodaki kaynaklarla yeni bir sekme görünür.

Depo özelse uygulamanın onu okuyabilmesi için **Ayarlar → GitHub Depoları** altında bir **Kişisel Erişim Anahtarı** eklemeniz gerekir.

## Dosya boyutları hakkında bir not

Kaynak dosyaları büyük olabilir. İnciller genellikle küçüktür (birkaç megabayt). Yorumlar ve çekirdek dosyalar çok daha büyük olabilir (yüzlerce megabayt). Olanaklı olduğunda Wi-Fi üzerinden indirin.

## Özet

- Kaynaklara göz atmak ve kurmak için **Ayarlar → Kaynakları Yönet** bölümünü kullanın.
- Çekirdek dosyalar, biçimbilim ve çapraz referanslar gibi daha derin çalışma araçlarının kilidini açar.
- Kendi dosyalarınız varsa yerel dosyaları içe aktarın.
- Başka bir kaynaktan kaynak isterseniz özel GitHub depoları ekleyin.
