---
title: Soruları Nereye Sormalı
level: everyday
categories: trouble
summary: Theodia ekibinden ve topluluktan nasıl yardım alınacağı ve uygulama içinde yardım konularının nasıl bulunacağı.
---

# Soruları Nereye Sormalı

Takıldıysanız yardım istemek için birkaç yer vardır.

## Yardım konusu bulma

Belirli bir özellik hakkında bilgi arıyorsanız şu yollardan birini deneyin:

- **Kategoriye göre göz atın.** **Yardım ve Kılavuzlar**'ı açın ve **Ayarlar ve Özelleştirme** ya da **Sorun Giderme** gibi bir kategoriye dokunun. Her kart ilgili kılavuzları listeler.
- **Anahtar kelimeyle arayın.** **Yardım ve Kılavuzlar** ana ekranında üstteki arama kutusuna bir kelime yazın. Örneğin `notifications` yazmak [Bildirimler ve Hatırlatıcılar](theodia://help/notifications) kılavuzunu gösterir; `search` yazmak [İncil'de Arama](theodia://help/search-the-bible) kılavuzunu gösterir.
- Önce **Ayarlar**'ı kontrol edin. Birçok özellik **Ayarlar**'da yapılandırılır. Hatırlatıcı kurmak istiyorsanız **Ayarlar** → **Bildirimler** bölümünü açın. Ayarlar ekranında her bölüm için bir **Yardım** bağlantısı da vardır.

## Uygulama içinde

**Hakkında** ekranını açın. İki düğme göreceksiniz:

- **Öneri / Sorun Gönder** — ekibe bir soru, fikir ya da hata bildirimi göndermek için bir form açar.
- **Tartışma / Geri Bildirim** — topluluk tartışma panosunu açar.

## GitHub sayfası

Bilinen sorunların ve son değişikliklerin listesini [GitHub](https://github.com/ecodiallc/theodia.app) üzerinde görebilirsiniz.

## Topluluk tartışması

Theodia'yı kullanan diğer insanlar [topluluk tartışma panosunda](https://github.com/ecodiallc/theodia.app/discussions) sorular sorar ve ipuçları paylaşır. Eski yazışmaları okuyabilir ve yeni bir tane başlatabilirsiniz.

## Sormadan önce

Birkaç şey, size daha hızlı yanıt vermemize yardım eder:

- **Cihazınız nedir?** (örneğin iPhone 13, Pixel 7)
- **Uygulamanın hangi sürümü?** (Görmek için **Hakkında**'yı açın.)
- **Ne yaptınız?** Adımların kısa bir tanımı.
- **Ne oldu?** Ekranda gördüğünüz şey.
- **Ne olmasını bekliyordunuz?** Bu genellikle en yararlı kısımdır.

## Ne beklemelisiniz

- Hata bildirimlerinde ekip genellikle birkaç gün içinde yanıt verir.
- Fikirler için ekip hepsini okur. Bir fikrin ne zaman ekleneceğini vaat edemeyiz.
- Topluluk sorularında diğer kullanıcılar genellikle ekipten daha hızlı yanıt verir.

## Gizlilik hakkında bir not

Bir soru gönderirken lütfen kişisel bilgi eklemeyin. Ekip, gönderdiğinizi görebilir.
