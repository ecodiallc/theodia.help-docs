---
title: GitHub Models
categories: ai
level: advanced
summary: GitHub Models'u kurun — mevcut bir API aboneliği olmadan Theodia'da AI keşfetmeye başlamanın ücretsiz yolu.
---

# GitHub Models

> **Mod:** AI asistanı **Scholar** modu gerektirir. Modları **Ayarlar** → **Uygulama Kullanıcı Modu** üzerinden değiştirebilirsiniz.

Zaten bir AI hizmetine ödeme yapmıyorsanız **GitHub Models**, Theodia'nın AI'sını keşfetmeye başlamanın en kolay yoludur. Ücretsiz bir başlangıç yolu sunar ve tek ihtiyacınız olan ücretsiz bir GitHub hesabıdır.

## GitHub Models nedir?

GitHub Models, modern AI modellerini bir API üzerinden çalıştırmanızı sağlayan GitHub'ın bir hizmetidir. OpenAI ile aynı biçimi destekler; böylece Theodia ile sorunsuz çalışır.

## Neden GitHub Models?

- **Kredi kartı gerekmez** — Yalnızca bir GitHub hesabı.
- **Yüksek kaliteli modeller** — Theodia'nın araçlarını destekleyen GPT-4o, GPT-4.1 ve diğer güvenilir modellere erişirsiniz.
- **Kolay kurulum** — Bir jeton, bir URL ve işiniz biter.

## Adım 1: GitHub hesabı oluşturun

Zaten bir GitHub hesabınız varsa Adım 2'ye geçin.

1. [github.com](https://github.com) adresine gidin.
2. **Sign up**'a dokunun ve ücretsiz bir hesap oluşturmak için yönergeleri izleyin.
3. GitHub onayı gönderdiğinde e-posta adresinizi doğrulayın.

## Adım 2: Kişisel Erişim Anahtarı oluşturun

Bu jeton sizin API anahtarınızdır. Theodia soru gönderdiğinde GitHub'a kim olduğunuzu söyler.

1. [github.com/settings/tokens](https://github.com/settings/tokens) adresine gidin.
2. **Generate new token**'a dokunun ve **Generate new token (classic)** seçin.
3. Anahtara **Theodia AI** gibi bir ad verin.
4. **Select scopes** altında **`models:read`** kutusunu işaretleyin.
   - Bu, Theodia'nın gereksinim duyduğu tek izindir.
5. En alta kaydırın ve **Generate token**'a dokunun.
6. **Jetonu hemen kopyalayın.** GitHub onu yalnızca bir kez gösterecektir. Theodia'ya ekleyene dek güvenli bir yere (örneğin telefonunuzdaki notlar uygulamasına) yapıştırın.

## Adım 3: Bir model seçin

GitHub Models birkaç model sunar. Theodia için en iyi seçenekler şunlardır:

| Model                 | Günlük Ücretsiz Sınır   | En İyi Kullanım                                      |
| --------------------- | ------------------ | --------------------------------------------- |
| `openai/gpt-4.1-nano` | günde 150 istek | Hızlı sorular ve basit ayet açıklamaları |
| `openai/gpt-4.1-mini` | günde 150 istek | İyi araç desteğiyle genel çalışma          |
| `openai/gpt-4.1`      | günde 50 istek  | Daha derin çalışma ve karmaşık çok adımlı sorular |
| `openai/gpt-4o`       | günde 50 istek  | Çok yönlü, mükemmel araç desteği             |

**`openai/gpt-4.1-mini`** ile başlayın — hızlıdır, güvenilirdir ve daha yüksek bir günlük istek sınırı sunar.

## Adım 4: Theodia'yı yapılandırın

1. **Theodia**'yı açın.
2. **Ayarlar** → **Yapay Zeka Asistanı** bölümüne gidin.
3. **Uzak model**'in seçili olduğundan emin olun.
4. **Sağlayıcı** açılır listesine dokunun ve **GitHub Models**'u seçin.
   - GitHub Models listede yoksa **Özel**'e dokunun ve taban URL'yi elle girin: `https://models.github.ai`
5. GitHub Kişisel Erişim Anahtarınızı **API Anahtarı** alanına yapıştırın.
6. Seçtiğiniz model kimliğini **Model** alanına girin (örneğin: `openai/gpt-4.1-mini`).
7. **Bağlantıyı sına**'ya dokunun.
8. Denetimin bitmesini bekleyin. Şunu görmelisiniz:
   - **✓ Bağlantı başarılı**
   - **✓ Araçlar destekleniyor**

**✗ Araçlar desteklenmiyor** görürseniz yukarıdaki tablodan farklı bir model kimliği deneyin.

## Adım 5: Sohbete başlayın

1. Ekranın altındaki **AI** sekmesine dokunun.
2. Bir soru yazın ve **Gönder**'e dokunun.
3. Ya da herhangi bir İncil bölümünü okurken bir ayet numarasına dokunun ve ayete özel bir sohbet başlatmak için **AI Yorumu**'nu seçin.

## Sorun giderme

### "Bağlantı başarısız" ya da "HTTP 401"

- Anahtarın **tamamını** kopyaladığınızdan emin olun. `ghp_` ile başlayan uzun bir dizgedir.
- Anahtarlar uzun süre kullanılmazsa geçerliliğini yitirir. GitHub'a dönün ve yenisini oluşturun.
- Anahtarı oluştururken **models:read** seçtiğinizi kontrol edin.

### "Araçlar desteklenmiyor"

- GitHub Models'taki bazı modeller araç çağrılarını kabul etmez. Bunun yerine **`openai/gpt-4o`** ya da **`openai/gpt-4.1-mini`** deneyin.
- `openai/` öneki dahil model kimliğinin tam olarak gösterildiği gibi yazıldığından emin olun.

### İstek sınırı hataları

- Günlük sınıra ulaşırsanız daha yüksek kotalı bir modele geçin (günde 150 istekli `openai/gpt-4.1-nano` gibi).
- Sınırlar her 24 saatte sıfırlanır.

## Özet

- GitHub Models, Theodia'da **AI keşfetmeye başlamanın önerilen yoludur**.
- `models:read` izinli bir **ücretsiz GitHub hesabına** ve bir **Kişisel Erişim Anahtarı**na ihtiyacınız var.
- En iyi başlangıç modeli **`openai/gpt-4.1-mini`**'dir.
- Anahtarı ve modeli **Ayarlar → Yapay Zeka Asistanı** bölümüne girin, **Bağlantıyı sına**'ya dokunun ve sohbete başlayın.
