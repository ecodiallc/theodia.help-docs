---
title: Ayetleri Vurgulama
level: everyday
categories: [annotate, read]
summary: Ayetlerin renkle nasıl işaretleneceği ve sonradan nasıl bulunacağı.
---

# Ayetleri Vurgulama

> **Mod:** Vurgular **Standart** ve **Scholar** modlarında kullanılabilir. Odak Modu yalnızca temiz, dikkatten uzak okuma içindir. Modları **Ayarlar** → **Uygulama Kullanıcı Modu** üzerinden değiştirebilirsiniz.

Vurgulama, bir ayeti bir renkle işaretler. Kağıttaki sarı bir fosforlu kaleme benzer. Ayet, bir dahaki açılışınızda vurgulu kalır.

## Bir ayet nasıl vurgulanır

1. Ayeti açın.
2. Menüyü açmak için ayete dokunun.
3. **Vurgu** simgesine dokunun.
4. Bir renk seçin.

Ayet artık o renkle vurgulanmıştır.

## Vurgu rengi nasıl değiştirilir

1. Ayeti açın.
2. Ayete dokunun, sonra **Vurgu** simgesine dokunun.
3. Yeni bir renk seçin.

## Vurgu nasıl kaldırılır

1. Ayeti açın.
2. Ayete dokunun, sonra menüden **Vurgu**'ya dokunun.
3. Renk seçicinin altındaki **Vurguyu Kaldır**'a dokunun.

## Renkleri kullanmanın yaygın bir yolu

Birçok okur, küçük bir amaç kümesi için küçük bir renk kümesi kullanır:

- Genel favoriler için **sarı**.
- Tanrı hakkında ayetler için **yeşil**.
- Dua hakkında ayetler için **mavi**.
- Teselli hakkında ayetler için **pembe**.
- Uyarı ya da düzeltme hakkında ayetler için **turuncu**.
- Kehanet ya da son zamanlar hakkında ayetler için **mor**.

Size uyan bir sistem seçin.

## Tüm vurgularınızı görme

Alttaki **Vurgular** sekmesine dokunun. Vurguladığınız her ayetin, en yeniden başlayarak listesini görürsünüz. Üstte bir renk rozetleri satırı vardır — yalnızca o renkteki vurguları göstermek için bir renge dokunun ya da filtreyi temizlemek için **Tümü**'ne dokunun.

## Vurguları içe aktarma

Vurguları başka uygulamalardan ve dosyalardan Theodia'ya getirebilirsiniz.

**Ayarlar** → **Yer İmleri** → **Vurguları İçe Aktar** bölümüne gidin. **Dosyadan İçe Aktar**'ı seçin ya da panodan yapıştırın. Uygulama biçimi otomatik olarak algılar.

### Desteklenen biçimler

**Yerel JSON dışa aktarımı** — Theodia'nın kendi dışa aktarma özelliğinin kullandığı biçim:

```json
{
  "/bible/KJV/John/3#v3_16": "yellow",
  "/bible/KJV/Genesis/1#v1_1": "green"
}
```

**CSV** — `url` ve `color` sütunlu bir elektronik tablo. Örnek:

```csv
url,color
/bible/KJV/John/3#v3_16,yellow
/bible/KJV/Genesis/1#v1_1,green
```

**Düz metin** — Her satır bir İncil referansı ya da URL'dir; isteğe bağlı olarak ardından bir renk adı gelir. Örnek:

```
John 3:16 yellow
Genesis 1:1 green
Matthew 5:1
```

- Mevcut renkler: `yellow`, `green`, `blue`, `pink`, `orange`, `purple`.
- Renk verilmezse vurgu varsayılan olarak sarı olur.
- `#` ya da `//` ile başlayan satırlar açıklama sayılır ve atlanır.

## İpuçları

- Vurgular cihazınızda kalır. Bulutla eşzamanlanmaz.
- Bir ayeti bir çeviride vurgulayabilir ve aynı ayetin diğer çevirilerinizde görünmesini sağlayabilirsiniz.
- Onları güvende tutmak için [Verilerinizi Yedekleme](theodia://help/backups) kılavuzuna bakın.
