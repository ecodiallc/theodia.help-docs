---
title: İncil Çevirilerini Yükleme
level: beginner
categories: start
summary: Kitaplığınıza bir İncil çevirisi nasıl eklenir?
---

# İncil Çevirilerini Yükleme

Theodia, okumaya hazır birkaç İncil çevirisiyle birlikte gelir. Dilediğiniz zaman çeviri ekleyebilirsiniz. "Çeviri", İncil metninin farklı bir sürümüdür; örneğin King James Version.

## Çeviri ekleme

İncil sekmesi, hâlihazırda yüklü olan çevirilerin bir listesini gösterir. Daha fazlasını eklemek için kaynak yöneticisini açın:

1. **Ayarlar**'ı açın.
2. **Kaynakları Yönet**'e dokunun.
3. **GitHub'dan Yükle**'ye dokunun.
4. İndirme penceresinde **İnciller** sekmesine dokunun.
5. İstediğiniz her çevirinin yanındaki onay kutusuna dokunun.
6. Alt kısımdaki **Seçilenleri Yükle**'ye dokunun.
7. İndirme işleminin bitmesini bekleyin.

Çeviri artık kitaplığınızda. Görmek için **İncil** sekmesini açın.

## Çeviriler arasında geçiş yapma

1. Okumak istediğiniz bir bölümü açın.
2. Ekranın üstündeki çeviri adına dokunun.
3. Listeden istediğinizi seçin.

Uygulama seçiminizi bir sonraki sefere kadar hatırlar.

## Çeviri kaldırma

1. **Ayarlar**'ı açın.
2. **Kaynakları Yönet**'e dokunun.
3. Kaldırmak istediğiniz çeviriyi bulun.
4. Yanındaki **X** işaretine dokunun.
5. Kaldırmak istediğinizi onaylayın.

Bir çeviriyi kaldırmak notlarınızı, vurgulamalarınızı veya yer imlerinizi silmez. Bunlar güvende kalır.

## Çeviriler ne kadar yer kaplar?

Çoğu çeviri 2 ile 10 MB arasındadır. Bunlar cihazınızda depolanır, bulutta değil. Cihazınızda yer olduğu sürece dilediğiniz kadar çeviri tutabilirsiniz.

## Peki ya çeviri uygulamada yoksa?

Bazı çeviriler uygulama içi listede bulunmaz. Yine de bunları ekleyebilirsiniz.

1. Uygulamayı açın ve **Ayarlar** → **Kaynakları Yönet** bölümüne gidin.
2. **GitHub'dan Yükle**'ye dokunun.
3. İndirme penceresinde **İnciller** sekmesine ve **Küresel İnciller** sekmesine bakın. Çeviriniz oradaysa onu seçin ve **Seçilenleri Yükle**'ye dokunun.
4. Değilse, bir `.bible` dosyasını içe aktarmak için **Yerel Dosya Yükle**'ye dokunun. Dosyayı projenin GitHub sayfasından edinin. Adım adım yardım için [GitHub'dan Ek Kaynaklar Alma](theodia://help/getting-core-files) rehberine bakın.
