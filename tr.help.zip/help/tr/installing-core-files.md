---
title: Temel Dosyaları Ekleme
level: beginner
categories: start
summary: Uygulamanın İncil'i derinlemesine incelemek için ihtiyaç duyduğu büyük veri dosyalarını indirme.
---

# Temel Dosyaları Ekleme

Theodia, kullanıma hazır bir İncil ve birkaç küçük ek özellikle birlikte gelir. Uygulamadan en iyi şekilde yararlanmak için ayrıca **temel dosyaları** indirmeniz gerekir. Bunlar, yorumlar, kelime aramaları ve dil bilgisi notları gibi inceleme araçları ekleyen büyük veri dosyalarıdır. Bunlar olmadan uygulama çalışır, ancak inceleme özellikleri sınırlı olur.

## Temel dosyalara neden ihtiyacınız var?

Temel dosyaları şunları ekler:

- **Kelime aramaları.** Herhangi bir ayetteki bir kelimeye dokunarak özgün İbranice veya Yunancayı ve anlamını görün.
- **Yorum.** Her ayet için Yapay Zekâ Yorumu.
- **Dil bilgisi.** Özgün dildeki her kelimeyle ilgili bilgiler.
- **Karşılıklı İncil.** Özgün dildeki metni, her kelimenin altında İngilizcesiyle birlikte okuyun.

Bunlar olmadan İncil'i okuyabilirsiniz, ancak çoğu inceleme aracı bunlara ihtiyaç duyar.

## Temel dosyalar nasıl yüklenir?

**[Temel Dosyaları Yükle](theodia://manage/core)**

1. **Ayarlar**'ı açın.
2. **Kaynakları Yönet**'e dokunun.
3. **Temel** sekmesi açılır. Temel dosyaların bir listesini görürsünüz. Her birinin bir adı, bir boyutu ve bir onay kutusu vardır.
4. Yüklemek istediğiniz her dosyaya dokunun. Onay işareti seçildiğini gösterir.
5. **Seçilenleri Yükle**'ye dokunun.
6. Dosyaların indirilip yüklenmesini bekleyin. Dosyalar büyük olduğu için yavaş bir bağlantıda bu birkaç dakika sürebilir.

Dosyalar cihazınıza indirilir. Bunu yalnızca bir kez yapmanız gerekir. Uygulama bundan sonra dosyaları kullanır, çevrimdışı olduğunuzda bile.

## İpuçları

- Wi-Fi kullanın. Dosyalar büyüktür.
- Telefonunuzu veya tabletinizi fişe takın. Büyük indirmeler pil tüketir.
- Bir indirme başarısız olursa, yeniden denemek için dosyaya yeniden dokunun.
- Hepsini yükleyebilir ya da yalnızca ihtiyacınız olanları yükleyebilirsiniz.

## Peki ya bir dosya listede yoksa?

Uygulama, listeyi projenin GitHub sayfasından çeker. Liste boşsa internet bağlantınızı kontrol edin ve yeniden deneyin. Hâlâ boşsa [Soruları Nereye Sorabilirsiniz](theodia://help/getting-more-help) rehberine bakın.

Kaynak eklemenin daha gelişmiş yolları için [GitHub'dan Ek Kaynaklar Alma](theodia://help/getting-core-files) rehberine bakın.
