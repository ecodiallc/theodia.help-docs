---
title: Uygulama Dili ve Bölge
level: everyday
categories: settings
summary: Uygulamanın dilini nasıl değiştirirsiniz?
---

# Uygulama Dili ve Bölge

Theodia birçok dilde sunulur. Uygulama, menülerin ve düğmelerin dilini değiştirebilir. Yardım içerikleri de bu dillerin çoğunda sunulur ve uygulamaya gömülüdür. Bir dilin yardım paketini ayrıca indirebilir veya güncelleyebilirsiniz — **Ayarlar** → **Yardım** veya **Kaynakları Yönet** → **GitHub'dan Yükle** → **Yardım belgeleri** bölümünü açın.

## Dil ayarlarını açma

1. **Ayarlar**'ı açın.
2. **Dil**'e dokunun.

## Uygulama dilini değiştirme

1. **Dil** listesinde istediğiniz dile dokunun.
2. Uygulama yeni dili hemen uygular.

Gördüğünüz seçenekler uygulamanın hangi dilleri desteklediğine bağlıdır.

## Dil ilk yüklemede nasıl seçilir?

Theodia'yı ilk kez yüklediğinizde, uygulama cihazınızın ayarlarına dayanarak bir dil seçer. Bunu dilediğiniz zaman değiştirebilirsiniz.

## Neler çevrilir?

- Menüler, düğmeler ve etiketler.
- Ayarlar ekranları.
- Hata iletileri.
- Arama ve inceleme araçları.

## Neler yalnızca İngilizce?

- Bazı kitap ve ibret içerikleri.

## İncil çevirileri ve uygulama dili

Uygulama dili ile İncil çevirisinin dili farklı şeylerdir. Uygulama İspanyolca, İncil İngilizce olabilir ya da tersi.

İncil çevirisini değiştirmek için [İncil Çevirilerini Yükleme](theodia://help/installing-bibles) rehberine bakın.

## İpuçları

- Bir düğme veya etiket boşsa uygulamada o dilin çevirisi eksiktir. Genellikle yedek olarak İngilizce sürümü vardır.
- Uygulamayı çevirmemize yardım etmek isterseniz [Soruları Nereye Sorabilirsiniz](theodia://help/getting-more-help) rehberine bakın.
