---
title: Başlatıcı Menüsü
level: everyday
categories: layout
summary: Son ayetlere atlamanın, komut çalıştırmanın ve mevcut ekrandan ayrılmadan İncil düzenlerini değiştirmenin hızlı bir yolu.
---

# Başlatıcı Menüsü

> **Mod:** Başlatıcı Menüsü **Scholar** (Âlim) modunu gerektirir. Modları **Ayarlar** → **Uygulama Kullanıcı Modu**'ndan değiştirebilirsiniz.

Başlatıcı Menüsü, uygulamadaki neredeyse her yerden açabileceğiniz hızlı erişimli bir paneldir. Son ayetlerinizi, komutlarınızı ve kaydettiğiniz İncil düzenlerinizi tek bir yerde tutar.

## Nasıl açılır?

Ana ekran başlığının sağ üst köşesindeki **genişletme simgesine (⌄)** dokunun. Panel üstten içeri kayarak gelir.

## İçinde neler var?

### 1. Komut Kutusu

Panelin üstünde klavye simgeli bir metin kutusu bulunur. Bir komut yazın ve klavyenizde **Git**'e dokunun. Uygulama komutu okur ve sizi doğrudan oraya götürür.

Örnekler:

- `John 3:16` — o ayeti açar.
- `search love` — İncil'de "love" (sevgi) arar.
- `bookmark psalms 23` — ayeti yer imlerine ekler.
- `kjv` — KJV çevirisine geçer.

Komutların tam listesi için [Komutlar](theodia://help/commands) rehberine bakın.

### 2. Paralel Setler

Kaydettiğiniz paralel İncil ön ayarları varsa, bunlar burada açılır-kapanır bir liste olarak görünür. Birine dokunduğunuzda o paralel düzen anında yüklenir.

Paralel ön ayar oluşturmak için:

1. **Ayarlar** → **Paralel İncil** bölümünü açın.
2. Çeviriler ekleyin ve **Ön Ayarı Kaydet**'e dokunun.
3. Ona bir ad verin. Başlatıcı Menüsünde görünecektir.

Başlatıcı Menüsünde bir paralel seti silmek için üzerine uzun basın.

### 3. İncil Koleksiyonları

İncil Koleksiyonları, çevirinizi ve paralel görünümünüzü aynı anda değiştiren tek dokunuşluk kısayollardır. Oluşturduklarınız varsa, burada açılır-kapanır bir liste olarak görünür.

Bir koleksiyonu silmek için üzerine uzun basın.

### 4. Özellik Simgeleri

Komut kutusunun altında bir sıra yuvarlak emoji düğme görebilirsiniz. Bunlar, uygulamanın ana özelliklerine giden tek dokunuşluk kısayollardır.

Kullanılabilir simgeler şunları içerir:

- **Hakkında**, **İnciller**, **İncil Notları**, **Yer İmleri**, **Kitaplar**
- **İbretler**, **Bilgi Kartları**, **Yardım**, **Vurgulamalar**
- **Çalma Listeleri**, **Eklentiler**, **Arama**, **Ayarlar**, **Theoscript**

Hangi simgelerin görüneceğini ve hangi sırayla görüneceklerini seçmek için:

1. **Ayarlar** → **Başlatıcı Menüsü** bölümünü açın.
2. **Başlatıcı Menüsü Simgeleri**'ne dokunun.
3. Her simgeyi göstermek veya gizlemek için anahtarları kullanın.
4. Etkinleştirdiklerinizin sırasını değiştirmek için yukarı/aşağı okları kullanın.

Ayarlar'daki sıra, Başlatıcı Menüsünde göründükleri sıradır.

### 5. Son Ayetler

Uygulama, son açtığınız bölümleri ve ayetleri hatırlar. Bunlar panelin altında bir liste olarak görünür. Doğrudan geri dönmek için herhangi bir girişe dokunun.

- Açmak için **dokunun**.
- Listeden kaldırmak için **sola kaydırın** veya **uzun basın**.
- Tüm girişleri tek seferde kaldırmak için **Tümünü temizle**'ye dokunun.

## Başlatıcı Menüsü ne zaman kullanılır?

Şunları yapmak istediğinizde kullanın:

- Az önce okuduğunuz bir ayete geri dönmek.
- Ana ekrana gitmeden bir komut yazmak.
- Tek dokunuşla çeviriyi veya paralel düzeni değiştirmek.
- Uygulamanın herhangi bir yerinden ana bir özelliği açmak.
- Menüler arasında gezinmeden hızlıca bir şeyi kontrol etmek.

## İpuçları

- Başlatıcı Menüsü neredeyse her ekranda kullanılabilir, böylece bir bölümü okurken bile açabilirsiniz.
- Komut kutusu, ana ekran komut kutusuyla aynı komutları destekler.
- Özellik simgeleri ve sıraları cihazınızda yerel olarak kaydedilir. Uygulama yeniden başlatıldığında korunur.
- Son ayetler cihazınızda yerel olarak kaydedilir. Uygulama yeniden başlatıldığında korunur.
