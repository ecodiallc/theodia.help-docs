---
title: Kitaplar, Bölümler ve Ayetler Arasında Gezinme
level: everyday
categories: [layout, read]
summary: İncil'de nasıl gezinilir ve istediğiniz yere nasıl atlanır?
---

# Kitaplar, Bölümler ve Ayetler Arasında Gezinme

Bu rehber, İncil'de gezinmenin tüm yollarını gösterir.

## Kolay yol: kaydırma

- Sonraki bölüme geçmek için bir bölümde **sola** kaydırın.
- Geri gitmek için **sağa** kaydırın.
- Bu, sonraki kitap için de geçerlidir. Örneğin Çıkış'ın son bölümünden sonra kaydırma sizi Levililer'in ilk bölümüne götürür.

## Menü yolu

- Farklı bir İncil'e geçmek için üstteki çeviri adına dokunun.
- Farklı bir kitap seçmek için üstteki kitap adına dokunun.
- Farklı bir bölüm seçmek için bölüm numarasına dokunun.

## Hızlı yol: yazma

- Ana sayfada üstte bir kutu vardır. `John 3:16` veya `psalms 23` gibi bir referans yazın ve klavyedeki **Git** tuşuna dokunun.
- Uygulama ayeti açar.

## Yer imi yolu

Bir ayet kaydettiyseniz **Yer İmleri** sekmesini açın. Atlamak için herhangi bir girişe dokunun.

## Arama yolu

**Arama** sekmesine dokunun. Bir kelime yazın. Uygulama, o kelimeyi içeren her ayeti gösterir. Açmak için herhangi bir sonuca dokunun.

## Geçmiş yolu

Uygulama, açtığınız bölümleri hatırlar. Bunları yeniden bulmak için **Yer İmleri** sekmesine bakın (kaydettiğiniz ayetler için) ya da yakın zamanda okuduğunuz bir kitabı bulmak için **İncil** sekmesindeki kitap listesini kaydırın.

## İpuçları

- İncil sekmesi, kitapları Yaratılış'tan Vahiy'e sırayla gösterir.
- Mezmurlar, Süleyman'ın Özdeyişleri ve diğer uzun kitaplarda uzak bir yere atlamak için kitaba dokunun ve bölüm listesini kullanın.
