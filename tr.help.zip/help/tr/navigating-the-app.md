---
title: Uygulama Düzeni ve Gezinme
level: beginner
categories: layout
summary: Ana ekran, ana menü ve alt araç çubuğunda kısa bir tur — her şeyin bulunduğu yer.
---

# Uygulama Düzeni ve Gezinme

Theodia'da aralarında geçiş yapabileceğiniz üç ana alan vardır: **ana ekran**, **ana menü** ve **alt araç çubuğu**. Bu rehber her birini size tanıtır, böylece nereye gideceğinizi her zaman bilirsiniz.

## Kısa bir harita

- **Ana ekran**, uygulamayı ilk açtığınızda gördüğünüz sayfadır. Bir arama kutusu, uygulamanın her bölümü için büyük düğmeler ve yüklü İncillerinizin, kitaplarınızın ve ibretlerinizin bir listesi vardır.
- **Alt araç çubuğu** (sekme çubuğu da denir) ekranın altındaki simge sırasıdır. Doğrudan uygulamanın o bölümüne atlamak için herhangi birine dokunun.
- **Ana menü**, ana ekranın sağ üst köşesindeki üç çizgili simgedir (☰). Uygulamadaki her ekranın bir listesini açmak için ona dokunun; kendi sekmesi olmayanlar dahil.

## Ana ekran

Theodia'yı ilk açtığınızda ana ekrana gelirsiniz. Ekran, yukarıdan aşağıya dört parçaya bölünmüştür.

### Başlık

En üstte renkli bir çubuk vardır. Solda uygulama simgesi ve "Theodia" adı bulunur. Sağda ana menü düğmesi (☰) vardır. Bir kitabın veya bölümün içindeyken sol taraf bunun yerine bir geri düğmesi (←) gösterir. Menüyü açmak için ana menüye dokunun (aşağıya bakın).

### Komut

Başlığın hemen altında **Komut** etiketli, arama tarzı bir metin kutusu bulunur. Kısa bir talimat yazın ve klavyenizdeki git tuşuna dokunun. Uygulama talimatı okur ve sizi doğru ekrana götürür. Örnekler:

- `psalms 23` — Mezmurlar 23. bölümü açar
- `john 3:16` — Yuhanna 3:16'yı açar
- `search love` — İncil'de "love" (sevgi) arar
- `bookmark john 3:16` — Yuhanna 3:16'yı yer imi olarak kaydeder
- `commentary romans 8:28` — o ayetin yorumunu açar
- `xref` (ardından bir referans) — o ayetin çapraz referanslarını açar
- `help` — örneklerle birlikte komut listesini açar

Uygulama yazdığınızı anlamazsa ipucu içeren küçük bir uyarı gösterir. Komutlar çalışmıyorsa **Sık Karşılaşılan Sorunlar** rehberine bakın.

### Düğme ızgarası

Komutun altında, her sırada iki tane olan büyük düğmelerden oluşan bir ızgara bulunur. Her düğme sizi uygulamanın farklı bir bölümüne götürür. Düğmeler şunlardır:

- 📖 **İnciller** — İncil çevirilerinizin listesi
- 🔍 **Arama** — İncil'de bir kelime veya ifade arama
- 📚 **Kitaplar** — Hristiyan klasikleri kitaplığınız
- 📅 **İbretler** — günlük ibretler
- 🔖 **Yer İmleri** — kaydettiğiniz ayetler ve bölümler
- 🖍 **Vurgulamalar** — renkle işaretlediğiniz ayetler
- 📝 **Notlar** — ayetler hakkındaki özel notlarınız
- ⚙️ **Ayarlar** — dil, tema, kaynaklar ve daha fazlası
- ❓ **Yardım** — yardım sistemi (bu sayfa)
- ℹ️ **Hakkında** — uygulama sürümü ve teşekkürler

### Kaynak listeleri

Düğme ızgarasının altında açılabilir bölümler bulunur: **İnciller**, **Kitaplar** ve **İbretler**. Her bölüm, yüklediğiniz ögeleri gösterir. Bölümü genişletmek veya daraltmak için bölüm başlığına dokunun. Bir bölümdeki herhangi bir ögeyi açmak için üzerine dokunun.

İnciller bölümü, belirli bir çeviriye atlamak için en hızlı yoldur — menü yok, sadece dokunun.

## Alt araç çubuğu

Alt araç çubuğu (sekme çubuğu) ekranın altındaki simge sırasıdır. Uygulamada neredeyse her yerde görünür kalır, böylece her zaman başka bir bölüme atlayabilirsiniz. Gördüğünüz sekmeler kullanıcı modunuza bağlıdır.

**Tüm modlar şunları görür:**

- 🏠 **Ana Ekran** — ana ekranı açar
- 📖 **İnciller** — İncil çevirilerinizin listesini açar
- 📚 **Kitaplar** — kitap kitaplığınızı açar
- 🔍 **Arama** — İncil aramasını açar
- ⚙️ **Ayarlar** — ayarları açar

**Standard ve Scholar modu ayrıca şunları görür:**

- 🔖 **Yer İmleri** — kaydettiğiniz ayetleri açar
- 🖍 **Vurgulamalar** — renkle işaretlediğiniz ayetleri açar
- 📝 **Notlar** — özel notlarınızı açar

**Scholar modu ayrıca şunu görür:**

- 💻 **Yapay Zekâ** — yapay zekâ asistanını açar (Ayarlar'da açtıysanız)

Geçerli sekme vurgulanır. Değiştirmek için başka bir sekmeye dokunun.

### Araç çubuğu nasıl davranır?

Araç çubuğundaki her sekmenin kendi ekran **yığını** vardır. Bir sekmeye dokunduğunuzda, o sekmenin yığınındaki başlangıç ekranına değil, **kaldığınız yere** geri gidersiniz. Örneğin:

- **İnciller**'e dokunun → İncil çevirilerinin listesini görürsünüz.
- Bir çeviriye dokunun → kitapların listesini görürsünüz.
- Bir kitaba dokunun → bölümlerin listesini görürsünüz.
- Bir bölüme dokunun → bölümü okuyorsunuz.
- Bir şeyi kontrol etmek için **Yer İmleri**'ne geçin.
- Yeniden **İnciller**'e dokunun → okuduğunuz bölüme geri dönersiniz.

Her sekme yerinizi hatırlar. Uygulama, gezinme geçmişinizi her sekmenin içinde tutar, böylece sekmeler arasında geçiş yapmak ilerlemenizi kaybetmez.

### Bir sekmeyi ne sıfırlar?

Bir sekme yalnızca şu durumlarda kök ekranına sıfırlanır:

- Zaten o sekmedeyken aynı sekme simgesine yeniden dokunduğunuzda. Bu, başlangıca geri dönmenin hızlı bir yoludur.
- Uygulama zorla kapatılıp yeniden açıldığında.

### Alt sekmeler ve ana menü

- **Alt sekmeler** — her sekme kendi yığınıını hatırlar. Bir sekmeye dokunmak sizi kaldığınız yere geri götürür.
- **Ana menü** — bir ögeye dokunmak, aynı sekme sistemini kullanarak o ekrana gider. Kaplama olarak açılmaz.

Görev değiştirmek için sekmeleri kullanın. Uygulamadaki her ekranın tam listesini istediğinizde ana menüyü kullanın.

### Araç çubuğu ne zaman kullanılır?

Ne yaptığınızı değiştirmek istediğinizde araç çubuğunu kullanın:

- Bir bölümü okuyorsunuz ve başka bir şey aramak istiyorsunuz → **Arama**'ya dokunun.
- Arama yapıyorsunuz ve yer imlerinizi kontrol etmek istiyorsunuz → **Yer İmleri**'ne dokunun.
- Uygulamada nerede olursanız olun ana ekrana dönmek istiyorsunuz → **Ana Ekran**'a dokunun.

## Ana menü

Ana menü, ana ekranın sağ üst köşesindeki üst üste üç çizgili düğmedir (☰). Ona dokunduğunuzda bir panel sağdan içeri kayarak gelir. Panel, geçerli modunuzun desteklediği her ekranı gösterir:

- 🏠 **Ana Ekran**
- 📖 **İnciller**
- 📚 **Kitaplar**
- 🙏 **İbretler**
- 🔍 **Arama**
- 🔖 **Yer İmleri** (Standard ve Scholar)
- 🖍 **Vurgulamalar** (Standard ve Scholar)
- 📝 **Notlar** (Standard ve Scholar)
- 💻 **Yapay Zekâ Asistanı** (yalnızca Scholar ve yapay zekâ açıksa)
- ⚙️ **Ayarlar**
- ❓ **Yardım**
- ℹ️ **Hakkında**

Bulunduğunuz ekranla eşleşen öge vurgulanır ve yanında küçük bir nokta bulunur. Doğrudan gitmek için herhangi bir ögeye dokunun. Ekranı değiştirmeden kapatmak için panelin dışına, üstteki X'e veya cihazınızın geri düğmesine dokunun.

### Ana menü nasıl farklıdır?

Ana menü, ayrı bir gezinme katmanı değil, açılan bir paneldir. Bir ögeye dokunduğunuzda, uygulama alt sekme veya düğme ızgarasını kullanmışsınız gibi o ekrana gider. Geçerli sekmenizin yığını korunur, böylece özgün sekmeye yeniden dokunarak kaldığınız yere dönebilirsiniz.

Örneğin:

- Yuhanna 3'ü okuyorsunuz. **Yer İmleri** sekmesine dokunuyorsunuz. Yer imlerinize gidersiniz. Yeniden **İnciller**'e dokunduğunuzda Yuhanna 3'e geri dönersiniz — kaldığınız yere.
- Yuhanna 3'ü okuyorsunuz. Ana menüyü açıp **Notlar**'a dokunuyorsunuz. Notlarınız açılır. Yuhanna 3'e dönmek için **İnciller** sekmesine dokunun ve bölüme otomatik olarak geri dönersiniz.

Sekmeler bağlamınızı değiştirir ve yerinizi hatırlar. Ana menü, aynı ekranlara ulaşmanın başka bir yoludur.

### Ana menü ne zaman kullanılır?

Şu durumlarda ana menüyü kullanın:

- **Vurgulamalar**, **Notlar**, **İbretler**, **Yardım** veya **Hakkında** ekranlarını açmak istiyorsunuz — kendi araç çubuğu sekmesi olmayan ekranlar.
- Bir bölümün veya aramanın derinliklerindeyken yerinizi kaybetmeden hızlıca bir şeyi kontrol etmek istiyorsunuz.
- Bulunduğunuz ekrandan ayrılmadan **Ayarlar**'ı açmak istiyorsunuz.

## Scholar modu

Kullanıcı modunuz **Scholar** olarak ayarlıysa, düzen; Reader ve Standard modlarının gizlediği ek sekmeler, menü ögeleri ve okuma araçları kazanır. Her özelliğin tam bir turu için [Scholar Modu](theodia://help/scholar-mode) rehberine bakın.

## Üç alan nasıl birbirine uyar?

- **Farklı bir ana bölüme geçmek** (İnciller, Arama, Yer İmleri vb.) → Alt araç çubuğu
- **Belirli bir ayete veya komuta atlamak** → Ana ekran Komutu
- **Kullanılabilir tüm ekranlara göz atmak** → Ana ekran düğme ızgarası
- **Yerinizi kaybetmeden Notlara, Vurgulamalara veya Yardıma bakmak** → ana menü
- **Her yerden Ayarlar'ı açmak** → ana menü veya araç çubuğu

Üçünü de kullanacaksınız. Hiçbiri "doğru yol" değildir. Ne yaptığınıza göre enkolayı seçin.

### Araç çubuğu ve ana menü: hızlı bir örnek

Romalılar 8'i okuduğunuzu ve beğendiğiniz bir ayeti vurgulamak istediğinizi hayal edin.

**Araç çubuğunu kullanarak:**

1. Ayet menüsünü açmak için ayete dokunun.
2. **Vurgula**'ya dokunun ve bir renk seçin.
3. Bitti. Bölümden hiç ayrılmadınız.

**Ana menüyü kullanarak (vurgulamalarınızı gözden geçirmek istiyorsanız):**

1. Menüyü açmak için ☰ simgesine dokunun.
2. **Vurgulamalar**'a dokunun. Vurgulama listeniz açılır.
3. Gözden geçirin, sonra Romalılar 8'e dönmek için **İnciller** sekmesine dokunun.

**Araç çubuğunu kullanarak (görev değiştirmek istiyorsanız):**

1. Araç çubuğunda **Ana Ekran** veya **Yer İmleri**'ne dokunun.
2. Romalılar 8'den ayrılır ve yeni ekrana gidersiniz.
3. Romalılar 8'e geri dönmek için yeniden **İnciller**'e dokunun — bölüme otomatik olarak geri dönersiniz.

## İpuçları

- Ana ekran, hangi bölümlerin açık veya kapalı olduğunu hatırlar. Bunu yalnızca bir kez ayarlamanız yeterlidir.
- Beklediğiniz bir sekmeyi görmüyorsanız iki şeye bakın:

1. **Kullanıcı modunuz** — Reader modu yer imlerini, vurgulamaları, notları ve yapay zekâyı gizler. Standard mod yapay zekâyı gizler. Modları **Ayarlar** → **Uygulama Kullanıcı Modu**'ndan değiştirin.
2. **Özellik ayarları** — bazı sekmelerin **Ayarlar**'da açılması gerekir (örneğin yapay zekâ asistanı).
