---
title: Not Yazma
level: everyday
categories: [annotate, read]
summary: Bir ayetin yanına kendi düşüncelerinizi nasıl yazarsınız?
---

# Not Yazma

> **Mod:** Notlar **Standard** ve **Scholar** modunda kullanılabilir. Odak Modu yalnızca temiz, dikkat dağıtmayan okuma içindir. Modları **Ayarlar** → **Uygulama Kullanıcı Modu**'ndan değiştirebilirsiniz.

Notlar, bir ayetin yanına kendi düşüncelerinizi, dualarınızı veya inceleme fikirlerinizi yazdığınız yerdir. Her not belirli bir ayete bağlıdır.

## Not ekleme

1. Ayeti açın.
2. Menüyü getirmek için ayete dokunun.
3. Menüde **Not**'a dokunun. Kalem simgesi vardır.
4. Notunuzu yazın.
5. **Kaydet**'e dokunun.

Not artık ayetle birlikte kaydedildi.

## Not okuma

1. Ayeti açın.
2. Ayetin yanındaki kalem işaretine bakın. Bir not olduğu anlamına gelir.
3. Ayete dokunun. Not aşağıda görünür.

## Not düzenleme

1. Notun bulunduğu ayeti açın.
2. Ayete dokunun.
3. Menüde **Not**'a dokunun.
4. Değişikliklerinizi yapın.
5. **Kaydet**'e dokunun.

## Not silme

1. Notun bulunduğu ayeti açın.
2. Ayete dokunun.
3. Menüde **Not**'a dokunun.
4. **Sil**'e dokunun.

## Tüm notlarınızı görme

Altta **Notlar** sekmesine dokunun. Yazdığınız her notun, tarihe göre sıralanmış bir listesini görürsünüz.

## Notlarınızda arama

**Notlar** sekmesinde **Arama** kutusuna dokunun. Bir kelime yazın. Uygulama o kelimeyi içeren her notu bulur.

## İpuçları

- Notlar vaazlar, ibadetler ve inceleme soruları için harikadır.
- Notlar özeldir. Cihazınızda kalırlar.
- Onları güvende tutmak için [Verilerinizi Yedekleme](theodia://help/backups) rehberine bakın.
