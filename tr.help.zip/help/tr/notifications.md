---
title: Bildirimler ve Hatırlatıcılar
level: everyday
categories: [settings]
summary: Dua, ibret, İncil planları ve daha fazlası için çevrimdışı hatırlatıcıları açma, özelleştirme ve yönetme.
---

# Bildirimler ve Hatırlatıcılar

Theodia; dua, ibretler, İncil planları, bilgi kartları ve diğer etkinlikler hakkında sizi hatırlatabilir — uygulama çevrimdışıyken bile. Tüm hatırlatıcılar cihazınızda zamanlanır; internet bağlantısına veya anlık bildirim sunucusuna gerek yoktur.

## Hatırlatıcıları açma veya kapatma

1. **Ayarlar**'ı açın.
2. **Bildirimler**'e dokunun.
3. **Hatırlatıcıları etkinleştir** seçeneğini açın veya kapatın.

Hatırlatıcıları ilk kez etkinleştirdiğinizde, uygulama bildirim gönderme izni ister. Hatırlatıcıların görünmesi için **İzin Ver**'e dokunun.

İzini daha önce reddettiyseniz, iOS veya Android isteği engelleyebilir. Bu durumda cihazınızın **Ayarlar** uygulamasına gidin, **Theodia**'yı bulun ve bildirimleri orada etkinleştirin.

## Hatırlatıcı türleri

Bildirimler ekranı kanallara ayrılmıştır. Her kanal, bağımsız olarak açıp kapatabileceğiniz bir hatırlatıcı ailesidir:

- **Dua hatırlatıcıları** — genel dua hatırlatıcıları.
- **Dua rutini** — belirli bir dua rutinine bağlı hatırlatıcılar.
- **İbret** — günlük ayet veya ibret hatırlatıcısı.
- **İncil planı hatırlatıcıları** — etkin bir İncil planı için hatırlatıcılar.
- **Theoscript hatırlatıcıları** — bir Theoscript çalıştırmak için hatırlatıcılar.
- **Yapay zekâ içgörü hatırlatıcıları** — yapay zekâ tarafından oluşturulan hatırlatıcılar.
- **Bilgi kartı tekrar hatırlatıcıları** — bilgi kartlarını tekrarlamak için hatırlatıcılar.
- **Okuma alışkanlığı hatırlatıcıları** — günlük okuma alışkanlığı hatırlatıcıları.
- **Litürjik ve mevsimsel hatırlatıcılar** — kilise takvimine bağlı hatırlatıcılar.
- **Hatırlatıcılarım** — yer imlerinden, vurgulamalardan, çalma listelerinden, İncil bölümlerinden veya kitaplardan oluşturduğunuz hatırlatıcılar.
- **Özel hatırlatıcılar** — kendinizin sıfırdan oluşturduğu, tamamen özel hatırlatıcılar.

Hatırlatıcılarını görmek, saatini değiştirmek, hangi günlerde çalışacağını seçmek veya kapatmak için herhangi bir kanala dokunun.

## Özel hatırlatıcılar

Özel hatırlatıcılar, sıfırdan kendinizin oluşturduğu hatırlatıcılardır.

1. **Ayarlar** → **Bildirimler** bölümünde **Özel hatırlatıcılar**'a dokunun.
2. **+** düğmesine dokunun.
3. Bir **Başlık** ve **İleti** girin.
4. Bir **Saat** seçin.
5. Hangi **Günlerde** tekrarlanmasını istediğinizi seçin.
6. Dokunulduğunda hatırlatıcının neyi açacağını seçin (isteğe bağlı).
7. **Kaydet**'e dokunun.

Özel bir hatırlatıcıyı düzenlemek veya silmek için listede üzerine dokunarak dilediğiniz zaman yapabilirsiniz.

## Bir hatırlatıcıya dokunduğunuzda ne olur?

Çoğu hatırlatıcı, uygulamada belirli bir ekranı açar. Örneğin, bir dua rutini hatırlatıcısı o rutini açar; bir İncil planı hatırlatıcısı bir sonraki okumayı açar.

Bir hatırlatıcının bağlı ekranı yoksa, uygulamayı Ana Ekran'da açar.

## Sessiz saatler

Sessiz saatler, görsel hatırlatıcıların yine de görünmesine izin verirken bildirim seslerini susturur.

1. **Ayarlar** → **Bildirimler** bölümünde **Sessiz saatler**'e dokunun.
2. Bir **Başlangıç** ve **Bitiş** saati ayarlayın.

Sessiz saatlere denk gelen hatırlatıcılar sessiz şekilde ekranda görünür.

## Yaklaşan hatırlatıcılar ve geçmiş

- **Yaklaşan hatırlatıcılar**, bir sonraki sırada çalışacak her şeyi gösterir.
- **Bildirim geçmişi**, yakın zamanda teslim edilen, zamanlanmış ve iptal edilen hatırlatıcıları gösterir.

Bir hatırlatıcının doğru ayarlandığını doğrulamak veya birinin neden görünmediğini görmek için bu listeleri kullanın.

## Hatırlatıcılar görünmüyorsa

- **Hatırlatıcıları etkinleştir** seçeneğinin açık olduğundan emin olun.
- Cihazınızın sistem ayarlarında bildirimlere izin verildiğini kontrol edin.
- Hatırlatıcının kanalının etkin olduğunu ve en az bir günün seçili olduğunu doğrulayın.
- Sessiz saatler ayarladıysanız hatırlatıcı sessiz olabilir.
- Bazı Android üreticileri uygulamaları uyutur. Cihazınız pil optimizasyonu ayarları sunuyorsa Theodia'yı izin verilenler listesine ekleyin.
- Bir hatırlatıcı, kaldırdığınız içeriğe bağlıysa (örneğin silinmiş bir İncil planı veya rutin), geçerli bir hedef yeniden seçene kadar çalışmayabilir.

## Bildirim sesleri

Sesleri destekleyen hatırlatıcıların çaldığı sesi seçebilirsiniz. Kullanılabilir seçenekler arasından seçim yapmak için bir hatırlatıcının veya kanalın içindeki **Ses**'e dokunun. Sesler uygulamayla birlikte paketlenir, bu nedenle çevrimdışı çalışırlar.

Kaydetmeden önce seçili sesi duymak için **Sesi önizle** düğmesini kullanın.

## Rozetler

Bazı hatırlatıcılar uygulama simgesine bir rozet ekleyebilir. Sıfırlamak için bildirimler ekranında **Rozeti temizle**'ye dokunun.
