---
title: PDF'ler
level: everyday
categories: [read, resources]
summary: Theodia'da PDF belgelerini içe aktarma, düzenleme ve okuma.
---

# PDF'ler

> **Mod:** PDF'ler **Standard** ve **Scholar** modunda kullanılabilir. Odak Modu yalnızca temiz, dikkat dağıtmayan okuma içindir. Modları **Ayarlar** → **Uygulama Kullanıcı Modu**'ndan değiştirebilirsiniz.

Theodia, PDF dosyalarını depolayabilir ve okuyabilir. İçe aktarılan PDF'ler cihazınızda kalır, böylece çevrimdışı çalışırlar.

## PDF kitaplığını açma

Ekranın altındaki **PDF'ler** sekmesine ya da Ana Ekran'daki **PDF'ler** kutusuna dokunun.

## PDF içe aktarma

1. **PDF'ler** sekmesini açın.
2. Sağ alttaki **+** düğmesine dokunun.
3. Cihazınızdan bir PDF seçin.
4. (İsteğe bağlı) Düzenlemek için bir kategori yazın veya seçin.

## PDF'leri düzenleme

Şu seçenekleri içeren bir menü açmak için herhangi bir PDF kartına uzun basın:

- **Yeniden adlandır** — kitaplıkta gösterilen başlığı değiştirir.
- **Kategoriyi değiştir** — PDF'yi bir kategoriye taşır.
- **Sil** — PDF'yi Theodia'dan kaldırır. Bu, kaydedilmiş okuma konumunu da siler.

Kategoriler serbest biçimli metindir. İçe aktarırken veya kategoriyi değiştirirken yeni bir ad yazın ya da var olan birini seçin.

## PDF okuma

Açmak için bir PDF kartına dokunun. Okuyucu şunları gösterir:

- Üstte bir çubukta belge başlığı.
- Bir sıra sayfa düğmesi: **İlk sayfa**, **Önceki**, geçerli sayfa ("3 / 120"), **Sonraki** ve **Son sayfa**.
- Belgenin araçlarını içeren bir araç çubuğu: **İçindekiler**, **Uzaklaştır**, **Yakınlaştır**, **Yakınlaştırmayı sıfırla**, **Yer İmi**, **Ara**, **Dinle** ve **Metin görünümü**.

Bazı araçlar kullanılamadıklarında soluk görünür — örneğin, PDF'nin aranabilir metni yüklenene kadar **Ara** ve **Dinle** soluktur.

### Sayfa çevirme

- Bir sayfa geri veya ileri gitmek için **sol** veya **sağ chevron**'a dokunun.
- Belgenin iki ucundan birine atlamak için **İlk sayfa** veya **Son sayfa**'ya dokunun.
- Sayfa ızgarasını açmak için sayfa numarasına (örneğin "3 / 120") dokunun, sonra istediğiniz sayfaya dokunun. Izgara, bulunduğunuz sayfanın yakınında açılır.
- Harici bir klavyede **Sol** ve **Sağ ok tuşlarını** kullanın.

### Yakınlaştırma

- Sayfa boyutunu değiştirmek için **Yakınlaştır** (+) veya **Uzaklaştır** (−) seçeneğine dokunun.
- Sayfayı normal boyutuna döndürmek için **Yakınlaştırmayı sıfırla**'ya dokunun.
- Yakınlaştırır, sayfayı çevirir, sonra uzaklaştırırsanız Theodia sizi okuduğunuz sayfaya geri götürür.

## Bir PDF içinde arama

1. PDF'yi açın ve araç çubuğundaki **Ara** (büyüteç) düğmesine dokunun.
2. Aradığınızı yazın. Yazarken sonuçlar, sayfa numarası ve çevresindeki metinden bir kesit ile birlikte görünür.
3. O sayfaya atlamak için bir sonuca dokunun.

Arama, PDF'nin aranabilir metninin yüklü olmasını gerektirir. Henüz yüklenmediyse Ara düğmesi soluktur. Topluluk GitHub deposundan yüklenen PDF'ler aranabilir metin içerir; kendiniz içe aktardığınız PDF'lerde bu metin eklenene kadar bulunmaz.

## İçindekiler

PDF'nin yerleşik bir içindekiler tablosu varsa, araç çubuğundaki **İçindekiler** düğmesi bunu bir ana hat olarak gösterir. O sayfaya atlamak için bir bölüm başlığına dokunun. Bölümler genişletilebilir ve daraltılabilir. PDF'nin içindekiler tablosu yoksa düğme soluktur.

## Bir PDF'de yer imleri

1. PDF'yi açın ve araç çubuğundaki **Yer İmi** düğmesine dokunun.
2. Geçerli sayfayı kaydetmek için **Sayfayı işaretle**'ye dokunun. Ad başlangıçta sayfa numarasıdır — isterseniz bir ad yazın — sonra **Kaydet**'e dokunun.
3. Sayfasına atlamak için listedeki herhangi bir yer imine dokunun.
4. Silmek için bir yer iminin yanındaki **×** işaretine dokunun.

PDF yer imleri, İncil yer imlerinizden ayrıdır. Her PDF kendi listesini tutar.

## PDF'yi sesli okuma

PDF'nin aranabilir metni yüklüyse, Theodia geçerli sayfayı yüksek sesle okuyabilir:

1. PDF'yi açın ve araç çubuğundaki **Dinle** (hoparlör) düğmesine dokunun.
2. **Oynat/Duraklat**, **Geri sar**, **İleri sar**, **Durdur**, sayfa içinde atlamak için dokunabileceğiniz bir ilerleme çubuğu, okuma hızı ve ses içeren bir denetim çubuğu görünür.
3. Sayfa bittiğinde, okuma otomatik olarak bir sonraki sayfada devam eder.

Ses ve hız, İncil okumasında kullanılanlarla aynıdır — bunları nasıl değiştireceğiniz için [Yüksek Sesle Okuma](theodia://help/tts) bölümüne bakın.

## Sayfa metnini kopyalama, paylaşma veya kaydetme

Geçerli sayfayı düz metin olarak görmek için araç çubuğundaki **Metin görünümü** düğmesine dokunun. Oradan şunları yapabilirsiniz:

- **Kopyala** — sayfa metnini panoya kopyalar.
- **Paylaş** — sayfa metnini cihazınızdaki herhangi bir uygulama üzerinden paylaşır.
- **İnceleme notlarına ekle** — sayfa metni, bir kaynak gösterimi ve bu sayfaya geri dönüş bağlantısı sizin için doldurulmuş bir not düzenleyici açar.

## Okumaya devam etme

Theodia, son görüntülediğiniz sayfayı hatırlar ve PDF'yi bir dahaki sefere orada açar.

## PDF'leri GitHub'dan indirme

**Scholar** modunda kitaplığın altında bir **GitHub'dan İndir** düğmesi görünür. Bu, İncil veya kitapları yüklediğiniz gibi paketlenmiş PDF belgeleri yükleyebilmeniz için topluluk PDF deposuna bağlanır.

## Notlar

- PDF'ler Theodia'nın özel belgeler klasöründe depolanır. Bunlar yedeklemelere dahil edilmez, bu nedenle yeni bir cihaza geçerseniz yeniden içe aktarmanız gerekir.
