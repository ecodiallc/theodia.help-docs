---
title: Çalma Listeleri
level: everyday
categories: playlists
summary: İncil bölümlerinden, düz metinden ya da duymak istediğiniz herhangi bir ayetten sesli çalma listeleri oluşturun ve dinleyin.
---

# Çalma Listeleri

Bir **çalma listesi**, Theodia'nın sizin için yüksek sesle okuyabileceği parçaların bir listesidir. Her parça ya bir İncil bölümü ya da kısa bir düz metin notudur. Çalma listeleri, işe giderken, yürüyüşte, ibret zamanında veya ezber pratiğinde eller serbest dinleme için faydalıdır.

Çalma listeleri, en az bir çalma listesi oluşturulduğunda veya doldurulduğunda uygulamada görünür.

## Çalma Listelerini nerede bulursunuz?

Çalma listeleri kullanılabilir olduğunda, onlara iki yolla ulaşabilirsiniz:

- **Ana ekran:** **Eklentiler ve Daha Fazlası** bölümünde **Çalma Listeleri**'ne dokunun.
- **ana menü:** Menüyü (☰) açın ve **Çalma Listeleri**'ne dokunun.

Henüz çalma listesi yoksa, Çalma Listeleri kutusu ve menü ögesi gizlidir.

## Bir çalma listesi neler içerir?

Her çalma listesinin şunları vardır:

- Bir **ad** — örneğin, "Sabah Ayetleri" veya "Mezmur 23 Ezberle".
- İsteğe bağlı bir **kategori** — çalma listelerini amaca göre gruplamak için faydalıdır.
- Bir **parça** listesi — yüksek sesle okunacak ögeler.

Her parça şunları içerir:

- **İçerik** — ya bir İncil bölümü referansı ya da düz metin.
- Bir **etiket** — parça çalarken ekranda gösterilir.
- İsteğe bağlı bir **ses** — isterseniz bu parça için farklı bir ses seçin.

## Çalma listesi oluşturma

1. **Çalma Listeleri** ekranını açın.
2. **Çalma listesi oluştur**'a (veya **+** düğmesine) dokunun.
3. Çalma listesine bir ad verin.
4. (İsteğe bağlı) Bir kategori seçin veya oluşturun.
5. Parça eklemeye başlayın.

### Bir İncil bölümünden parça ekleme

1. **Parça ekle**'ye dokunun.
2. İçerik türü olarak **İncil bölümü**'nü seçin.
3. `John 3:16` veya `Psalm 23:1-6` gibi bir referans girin.
4. İsterseniz bir etiket ekleyin veya referansı kullanmak için boş bırakın.
5. Parçayı kaydedin.

### Düz metin parça ekleme

1. **Parça ekle**'ye dokunun.
2. **Düz metin**'i seçin.
3. Theodia'nın okumasını istediğiniz metni yazın.
4. Bir etiket ekleyin.
5. Parçayı kaydedin.

### Parçaları toplu ekleme

Referansların veya metin satırlarının bir listesi varsa **Toplu ekle**'yi kullanın:

1. Bir çalma listesi açın.
2. Menüye dokunun ve **Toplu ekle**'yi seçin.
3. Her satıra bir referans veya metin satırı yapıştırın.
4. Satırların çoğu ayet referansıysa **İncil referanslarını algıla**'yı açın.
5. **Ekle**'ye dokunun. Her satır bir parça olur.

## Bir çalma listesini dinleme

1. Duymak istediğiniz çalma listesini açın.
2. Üstteki veya bir parçanın yanındaki **Oynat** düğmesine dokunun.
3. Theodia her parçayı sırayla okur.

Bir çalma listesi çalarken şu denetimleri içeren bir denetim çubuğu görünür:

- **Oynat / Duraklat**
- **Sonraki parça**
- **Önceki parça**
- **Durdur**

Şunları da ayarlayabilirsiniz:

- **Hız** — sesin ne kadar hızlı okuduğu.
- **Tekrar** — tüm çalma listesini tekrarla, bir parçayı tekrarla veya bir kez oynat.
- **Karıştır** — parçaları rastgele sırayla oynat.
- **Parantez içini yok say** — parantez içindeki metni atla.
- **Parçalar arası duraklat** — parçalar arasında kısa bir sessizlik ekle.
- **Uyku zamanlayıcısı** — belirlenen süre sonunda oynatmayı durdurur.

## Bir çalma listesini düzenleme

Bir çalma listesini değiştirmek için önce, o anda çalıyorsa oynatmayı duraklatın.

Şunları yapabilirsiniz:

- Çalma listesini **yeniden adlandırın**.
- **Parçaları yeniden sıralayın** — parçaları yeni bir sıraya sürükleyin.
- **Bir parçayı düzenleyin** — referansını, metnini, etiketini veya sesini değiştirin.
- **Bir parçayı silin** — çalma listesinden kaldırın.
- **Tüm çalma listesini silin** — bu geri alınamaz.

## Çalma listelerini dışa ve içe aktarma

Çalma listeleri, tüm parçaları, kategorileri ve ayarları içeren JSON dosyaları olarak dışa aktarılır. Dosyayı başka bir cihazla paylaşabilir, yedek olarak saklayabilir veya bir bilgisayarda düzenleyebilirsiniz.

- **Tüm çalma listelerini dışa aktar** — bir `playlists-YYYY-MM-DD.json` dosyası oluşturur.
- **Bir kategoriyi dışa aktar** — yalnızca tek bir kategorideki çalma listelerini içeren bir JSON dosyası oluşturur.
- **Çalma listelerini içe aktar** — bir JSON yedek dosyasından çalma listelerini geri yükler.

## Çalma listesi oluşturmanın hızlı yolları

Ayrıca eksiksiz bir çalma listesini JSON olarak oluşturup içe aktarabilirsiniz. İşte bir örnek:

```json
{
  "playlists": [
    {
      "name": "Morning Verses",
      "category": "Devotional",
      "tracks": [
        {
          "info": "John 3:16",
          "contentSource": "passage",
          "content": "For God so loved the world...",
          "rawContent": "John 3:16"
        },
        {
          "info": "Psalm 23",
          "contentSource": "passage",
          "content": "The Lord is my shepherd...",
          "rawContent": "Psalm 23:1-6"
        }
      ]
    }
  ]
}
```

Dosyayı kaydedin, sonra Theodia'ya yüklemek için **Çalma listelerini içe aktar**'ı kullanın.

## İpuçları

- Çalma listeleri kısa, odaklı ayet setleriyle en iyi şekilde çalışır.
- İbret çalma listelerini ezber çalma listelerinden ayırmak için kategorileri kullanın.
- Uykuya dalarken dinliyorsanız bir uyku zamanlayıcısı ayarlayın.
- Bir parça yanlış ses kullanıyorsa, sesin dilinin metnin diliyle eşleştiğini kontrol edin.
- Theodia düz metni tam olarak yazıldığı gibi okur; en iyi sonuç için yazımı kontrol edin.
