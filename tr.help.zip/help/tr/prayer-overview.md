---
title: Dua Genel Bakış
level: beginner
categories: prayer
summary: Dua sekmesine ve ana bölümlerine hızlı bir giriş.
---

# Dua Genel Bakış

**Dua** sekmesi, dua için özel bir alandır. Listeleri, rehberli seansları, bir günlüğü, bir zamanlayıcıyı, ayin takvimi okuma çizelgelerini ve klasik sabit duaları bir araya getirir.

## Ana bölümler

- **Dua Listesi** — dua ettiğiniz kişileri, durumları ve konuları takip edin.
- **Günlük** — zaman içinde düşüncelerinizi, cevapları ve fikirleri yazın.
- **Dua Oluştur** — Theophilus'tan bir istek veya günlük girişinden bir dua yazmasını isteyin.
- **İman İlkeleri ve Sabit Dualar** — Hristiyan geleneğinden klasik dualar ve iman ilkeleri.
- **Ayin Takvimi** — günlük veya mevsimsel dua için kutsal yazı okuma çizelgeleri.
- **Rehberli Dua** — metinden konuşmayla sesli rehberli dua seansları.
- **Zamanlayıcı** — isteğe bağlı çanlarla süreli dua seansları.
