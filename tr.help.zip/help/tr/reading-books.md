---
title: Yerleşik Kitapları Okuma
level: beginner
categories: [content, read]
summary: Uygulamayla gelen Hristiyan klasikleri nasıl okunur?
---

# Yerleşik Kitapları Okuma

Theodia, küçük bir Hristiyan kitapları kitaplığıyla birlikte gelir. Bunlar, cihazınızda okuyabileceğiniz klasiklerdir.

## Kitaplığı açma

Ekranın altındaki **Kitaplar** sekmesine dokunun. Kitaplığınızdaki kitapların bir listesini görürsünüz.

## Bir kitabı okuma

1. Kitabın başlığına dokunun.
2. Kitap ilk bölüme açılır.
3. Bölümler arasında geçiş yapmak için üstteki **Önceki** ve **Sonraki** düğmelerini kullanın.

## Bir bölüme atlama

Ekranın üstündeki bölüm adına dokunun. Bölümlerin bir listesi görünür. Atlamak için bir bölüm seçin.

## Yazı tipi boyutunu değiştirme

**Ayarlar** → **Görünüm** bölümünü açın ve bir yazı tipi boyutu seçin. Metin boyutu kitaplar dahil tüm uygulamada değişir.

## Bir kitaba yer imi ekleme

Sağ üstteki **yıldız** simgesine dokunun. Geçerli bölüm kaydedilir. Kaydettiğiniz sayfaları görmek için **Yer İmleri** sekmesine dokunun.

## Bir kitabı dinleme

Sağ üstteki **Hoparlör** simgesine dokunun. Uygulama bölümü yüksek sesle okur. Durdurmak için yeniden dokunun.

## Hangi kitaplar var?

Kitaplıkta şu gibi klasikler vardır:

- Pilgrim's Progress
- The Imitation of Christ
- Practice of the Presence of God
- The Hymn Book

Kitap listesi zaman içinde büyüyebilir. Uygulama güncellemeleri daha fazlasını ekleyebilir.

## İpuçları

- Kitaplar cihazınızda depolanır. İnternet gerekmez.
- Kitaplar bulutla eşitlenmez.
