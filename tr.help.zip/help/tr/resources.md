---
title: GitHub'da Kaynak Bulma
level: everyday
categories: resources
summary: Uygulamanın bildiği her GitHub deposunda tek seferde arama yapın, sonra bulduğunuzu yükleyin.
---

# GitHub'da Kaynak Bulma

Theodia, kaynak yayımlayan GitHub depolarının bir listesini tutar — İnciller, yorumlar, kitaplar, ibretler, çalma listeleri, dua paketleri ve daha fazlası. **GitHub Depolarında Ara**, bunların tümünde aynı anda arama yapar, böylece her sekmeyi ayrı ayrı açıp gezinmek zorunda kalmazsınız.

> Ayarlar'ın GitHub bölümü yalnızca **Scholar modunda** kullanılabilir. Açmak için **Ayarlar → Kullanıcı Modu → Scholar** bölümüne gidin.

## Arama nasıl yapılır?

1. **Ayarlar**'ı açın.
2. **GitHub Depolarında Ara**'ya dokunun.
3. Arama kutusuna bir kelime yazın. Uygulama, her depodaki her paketin **adında** ve **açıklamasında** o kelimeyi arar.

Arama hakkında bilinmesi gereken birkaç şey:

- **Her kelime eşleşmelidir.** `morning evening` araması yalnızca adında veya açıklamasında her iki kelimeyi de içeren paketleri bulur.
- **Büyük/küçük harf önemli değildir.** `Morning` ve `morning` aynı paketleri bulur.
- **En iyi eşleşme önce gelir.** Adı aramanızla *başlayan* bir paket, yalnızca açıklamasında ondan bahseden bir paketten önce gösterilir.

## Filtreleme

Listeyi daha da daraltmak için sonuçların üstündeki filme çubuğuna dokunun. İki filtre vardır ve birlikte çalışırlar:

- **Yazar** — yalnızca o yazarın paketleri.
- **Gelenek** — yalnızca o geleneğe ait paketler.

Bir filtreyi temizlemek için yeniden dokunun veya ikisini de sıfırlamak için **Filtreleri temizle**'ye dokunun.

## Bir sonuçtan yükleme

Her sonuç, paketin adını, ne tür bir kaynak olduğunu, kimin yaptığını ve hangi depodan geldiğini gösterir. Satırın sağındaki tek bir düğme:

- **Yükle** — paket henüz cihazınızda değil.
- **Güncelle** — daha yeni bir sürüm mevcut. Uygulama önce onaylamanızı ister, çünkü güncelleme eski kopyayı, ona işaret eden notlar, vurgulamalar veya yer imleriyle birlikte kaldırır.
- **Aç** — paket hâlihazırda yüklüdür; dokunmak sizi onu kullandığınız ekrana götürür.

En son listeyi GitHub'dan hemen çekmek için üstteki **Yenile**'ye dokunun. Uygulama listeyi günde bir kez kendi kendine yeniler; bu nedenle elle yenileme yalnızca yeni bir şeyin yayımlandığını bildiğinizde gerekir.

## Bağlantı olmadan arama

Uygulama, listenin bir kopyasını cihazınızda tutar; bu nedenle çevrimdışıyken bile arama çalışır. Uygulama listeyi yenilemek için GitHub'a ulaşamazsa, üstteki bir başlık size önbelleğe alınmış sonuçları gördüğünüzü söyler.

## Arama hiçbir şey bulamazsa

- Daha kısa, tek bir kelime deneyin.
- Hiçbir **Yazar** veya **Gelenek** filtresinin hâlâ uygulanmadığını kontrol edin — biri uygulanmışsa **Filtreleri temizle** düğmesi görünür.
- Bazı depolar, paketlerini paket adından farklı bir dilde yayımlar; bu nedenle çevrilmiş bir kelimeyle arama yapmak onları bulamayabilir.
