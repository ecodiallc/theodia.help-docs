---
title: Scholar Modu
level: advanced
categories: [layout, read, study]
summary: Theodia'nın en derin inceleme modu; yorumları, sözlükleri, çapraz referansları, yapay zekâ araçlarını ve Başlatıcı Menüsünü açar.
---

# Scholar Modu

> **Mod:** Scholar modu yalnızca kullanıcı modunuz **Scholar** olarak ayarlandığında kullanılabilir. Modları **Ayarlar** → **Uygulama Kullanıcı Modu**'ndan değiştirin.

Scholar modu, Theodia'daki tüm inceleme araçlarını açar. Study Mode üzerine inşa edilmiştir, bu nedenle yine de ayet menüsünü, paralel İncilleri, yer imlerini, vurgulamaları ve notları alırsınız — ayrıca aşağıda listelenen gelişmiş araçlar da.

## Scholar modunu açma

Scholar modu ayrı bir ekran değildir. Kullanıcı modunuz Scholar olarak ayarlandığında, var olan okuyucunun ve gezinmenin içinde görünen ek araçlar dizisidir.

1. **Ayarlar**'ı açın.
2. **Uygulama Kullanıcı Modu**'na dokunun.
3. **Scholar**'ı seçin.

Değişiklik hemen geçerlilik kazanır. Daha önce gizli olan menüler ve düğmeler artık görünür.

## Ek okuyucu araçları

[Study Mode](theodia://help/study-mode)'da bir bölüm açtığınızda, Scholar modu ayet menüsüne şu araçları ekler:

- **Yapay Zekâ Yorumu** (◈) — yapay zekâ asistanından bu ayet için bir inceleme notu yazmasını isteyin. (Her bölgede kullanılamaz.)
- **Kelime Bilgisi** (?) — ayetin ardındaki özgün İbranice veya Yunanca kelime için bir sözlük girişi açar. [Yorumlar ve Sözlükler](theodia://help/commentaries-and-lexicons) rehberine bakın.
- **Sözlük** (📖) — yüklediğiniz sözlük kaynaklarında genel İncil kelimelerine bakın. [İncil Sözlüğü](theodia://help/dictionary) rehberine bakın.

Bu araçların kaynakların yüklü olmasını gerektirir (yorumlar, sözlükler, sözlük dosyaları). Bir araç soluk görünüyorsa veya "bulunamadı" gösteriyorsa, **Ayarlar** → **Kaynakları Yönet** bölümünü açın ve ihtiyaç duyduğu kaynağı ekleyin.

## Ek gezinme

### Ek araç çubuğu sekmesi

Alt araç çubuğu bir ek sekme kazanır:

- 💻 **Yapay Zekâ** — yapay zekâ asistanını açar (yalnızca Ayarlar'da yapay zekâyı açtıysanız). Bu sekme Notlar'ın sağındadır.

### Ek ana menü ögeleri

Ana menü, aynı koşullarda bir **Yapay Zekâ Asistanı** girişi içerir.

## Başlatıcı Menüsü

Scholar modu **Başlatıcı Menüsünü** etkinleştirir; mevcut ekrandan ayrılmadan son ayetlere atlamak, komut çalıştırmak ve İncil düzenlerini değiştirmenin hızlı bir yolu. Nasıl kullanılacağı için [Başlatıcı Menüsü](theodia://help/launcher-menu) rehberine bakın.

## Scholar modu ne zaman kullanılır?

- Okurken yapay zekâ asistanını, yorumları veya özgün dil aramalarını istiyorsunuz.
- Hızlı ayet gezinmesi ve yapay zekâ sohbeti için Başlatıcı Menüsünü istiyorsunuz.
- Bir bölümü derinlemesine inceliyorsunuz ve her aracın bir dokunuş uzağında olmasına ihtiyacınız var.

## Daha hafif bir moda geçme

Gelişmiş araçlar olmadan daha sade bir okuyucu istiyorsanız **Ayarlar** → **Uygulama Kullanıcı Modu**'ndan **Standard** moduna geçin. Standard mod, yer imlerini, vurgulamaları, notları ve Study Mode'u korur ama yapay zekâyı, yorumları, sözlükleri ve Başlatıcı Menüsünü gizler.

Mümkün olan en temiz okuma deneyimini istiyorsanız bir bölümü [Odak Modu](theodia://help/focus-mode)'nda açın.

Yer imleriniz, vurgulamalarınız ve notlarınız mod değiştirdiğinizde asla silinmez; onları destekleyen bir moda geri dönene kadar yalnızca gizlenirler.

## Yardım ve sorular

Bir araç eksikse veya hata gösteriyorsa [Sık Karşılaşılan Sorunlar](theodia://help/common-problems) rehberine bakın. Theodia'da yeniyseniz, [İlk Bölümünüzü Okuma](theodia://help/first-read) rehberi temel bilgileri adım adım anlatır.
