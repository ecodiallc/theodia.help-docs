---
title: İncil'de Arama
level: everyday
categories: [study, read]
summary: Ayetleri kelimeye, ifadeye veya referansa göre bulma.
---

# İncil'de Arama

Arama çubuğu, ayetleri hızlıca bulmanıza yardımcı olur. Bir kelimeye, bir ifadeye veya bir İncil referansına göre arama yapabilirsiniz.

## Arama başlatma

1. Ekranın altındaki **Arama** sekmesine dokunun.
2. Bulmak istediğinizi yazın.
3. Klavyede **Ara**'ya dokunun.

Sonuçlar ayetlerden oluşan bir liste olarak görünür. Her sonuç, kitabı, bölümü ve ayeti, ayrıca ayet metnini gösterir.

## Kelime kombinasyonlarına göre arama

`love joy` gibi birden fazla kelime yazdığınızda, uygulama **her iki** kelimeyi de içeren ayetleri bulur. Bu bir **VE** aramasıdır — tüm kelimeler ayette bulunmalıdır. **VEYA** mantığını (tek bir kelimeyi içeren ayetler) kullanmaz.

Her iki kelimeden birini içeren ayetleri aramak için `OR` anahtar kelimesini açıkça kullanmalısınız: `love OR joy`.

## Kelimeye göre arama

`love` veya `mercy` gibi tek bir kelime yazın. Uygulama, İncil'de o kelimeyi içeren her ayeti gösterir.

## İfadeye göre arama

`"do not be afraid"` gibi iki veya üç kelimeyi tırnak içinde yazın. Uygulama, o tam ifadeye sahip ayetleri gösterir.

## Sonuçları filtreleme

Bir aramadan sonra, sonuçlar yüklediğiniz İncil çevirilerine göre filtrelenir. Daha da daraltmak için **İncil** sekmesini açın ve belirli bir çeviriye bakın — aramalar elinizdeki çeviriler üzerinde çalışır.

## Daha iyi aramalar için ipuçları

- Kısa kelimeler kullanın. `love` araması, `loving` aramasından daha fazla ayet bulur.
- Bir ifadenin etrafındaki tırnak işaretleri aramayı tam eşleşmeli yapar.
- Uygulama yalnızca yüklediğiniz İncil çevirilerinde arama yapar.
- Referansa göre belirli bir ayete atlamak için (örneğin `John 3:16`), Arama sekmesi yerine ana ekrandaki **Komut** kutusunu kullanın.

## Arama geçmişi

Uygulama, en son aramalarınızı hatırlar. **Arama** sekmesini açtığınızda, liste en üstte son aramalarınızı gösterir. Yeniden çalıştırmak için birine dokunun. Listeyi temizlemek için son aramaların üstündeki **Tümünü Temizle**'ye dokunun.

## PDF'lerde arama

Arama sekmesi, PDF belgelerinizin içinde de arama yapabilir:

1. **Arama** sekmesine dokunun, sonra üstteki **PDF'ler** moduna dokunun.
2. Hangi PDF'lerde aranacağını seçin. Dahil etmek veya hariç tutmak için bir PDF'ye dokunun; her şeyi dahil etmek veya baştan başlamak için listenin üstündeki **Tümü** veya **Temizle**'yi kullanın. Yalnızca aranabilir metni yüklü olan PDF'ler seçilebilir.
3. Bulmak istediğinizi yazın ve **Ara**'ya dokunun.

Her sonuç, PDF'nin başlığını, sayfa numarasını ve eşleşen metinden bir kesit gösterir. O sayfada o PDF'yi açmak için bir sonuca dokunun.

Okurken tek bir PDF'nin içinde arama yapmak için bunun yerine PDF okuyucusundaki **Ara** düğmesini kullanın — bkz. [PDF'ler](theodia://help/pdfs).
