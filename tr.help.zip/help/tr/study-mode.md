---
title: Study Mode
level: everyday
categories: [layout, read]
summary: Theodia'daki tam İncil okuyucusu; yorum, çapraz referans, sözlük ve notlar gibi inceleme araçlarıyla dolu.
---

# Study Mode

> **Mod:** Study Mode **Standard** ve **Scholar** modunda kullanılabilir. Reader modu bölümleri bunun yerine Odak Modunda açar. Modları **Ayarlar** → **Uygulama Kullanıcı Modu**'ndan değiştirebilirsiniz.

Study Mode, Theodia'daki ana İncil okuyucusudur. Tüm inceleme araçları yerleşiktir: yorumlar, çapraz referanslar, kelime aramaları, paralel çeviriler, notlar ve daha fazlası.

Odak Modu, inceleme araçları olmayan daha sade bir okuyucudur. Yalnızca temiz metin istiyorsanız [Odak Modu](theodia://help/focus-mode) rehberine bakın. Bu rehber Study Mode içindir.

## Study Mode nasıl açılır?

Study Mode'da bir bölüm açmanın birkaç yolu vardır:

- Ekranın altındaki **İncil** sekmesine dokunun. Bir çeviri, bir kitap ve bir bölüm seçin.
- **Arama** sonuçlarındaki bir ayete dokunun.
- **Yer İmleri** sekmesinden bir yer imine dokunun.
- Odak Modundan, Study Mode'a geçmek için ekranın üstündeki 📖 düğmesine dokunun.

## Bölümü okuma

Bölüm, ayetler sırayla listelenmiş hâlde açılır. Ekranın üstünde en yaygın eylemler için düğmeler vardır. Ekranın altında bir durum çubuğu bulunur.

- Sonraki bölüme geçmek için **sola kaydırın**.
- Önceki bölüme dönmek için **sağa kaydırın**.
- İnceleme araçları içeren ayet menüsünü açmak için **bir ayete dokunun** (aşağıya bakın).
- O kelime için hızlı bir sözlük araması açmak için **bir ayetteki Strong's numarasına** (örneğin G1234 veya H1234) dokunun.

Bir paralel çeviri açtıysanız, bölümün ikinci bir kopyası ana metnin altında, seçtiğiniz çeviride görünür. Aşağıdaki **Aynı anda iki çeviri okuma** bölümüne bakın.

## Ayet menüsü

Bir ayete dokunduğunuzda, "Kitap Bölüm:Ayet" başlıklı bir menü açılır. Gördüğünüz araçlar kullanıcı modunuza bağlıdır.

### Standard ve Scholar modundaki araçlar

- **Yer İmi** (★) — yeniden bulabilmeniz için ayeti kaydedin. Yer imini kaldırmak için yeniden dokunun. İlk dokunuş ekler. [Ayetlere Yer İmi Koyma](theodia://help/bookmarks) rehberine bakın.
- **Vurgula** (□) — öne çıkması için ayeti renklendirin. Bir renk seçici açmak için dokunun. Vurgulamayı kaldırmak için aynı renge yeniden dokunun. [Ayetleri Vurgulama](theodia://help/highlights) rehberine bakın.
- **Oku** (🔊) — ayetin cihazınızın metinden konuşma sesiyle okunmasını sağlayın. Bu, karşılıklı İnciller için gösterilmez. Nasıl kullanılacağı ve ses seçimi için [Yüksek Sesle Okuma](theodia://help/tts) rehberine bakın.
- **Kopyala** (⎘) — herhangi bir yere yapıştırabilmeniz için ayet metnini panonuza koyar.
- **Karşılaştır** (⇄) — aynı ayeti yüklü her çeviride gösteren bir panel açar. O çevirideki ayeti okumak için panelde bir çeviriye dokunun. [Çevirileri Karşılaştırma](theodia://help/compare-translations) rehberine bakın.
- **Çapraz Referanslar** (↗) — çapraz referans veritabanından ilgili ayetlerin bir listesini açar. [Çapraz Referanslar](theodia://help/cross-references) rehberine bakın.
- **İncil Notu Ekle/Düzenle** (✎) — ayete eklenmiş kendi özel notunuzu yazın. [Not Yazma](theodia://help/notes) rehberine bakın.

### Yalnızca Scholar modundaki araçlar

- **Yapay Zekâ Yorumu** (◈) — yapay zekâ asistanından bu ayet için bir inceleme notu yazmasını isteyin. (Her bölgede kullanılamaz.)
- **Kelime Bilgisi** (?) — ayetin ardındaki özgün İbranice veya Yunanca kelime için bir sözlük girişi açar. [Yorumlar ve Sözlükler](theodia://help/commentaries-and-lexicons) rehberine bakın.
- **Sözlük** (📖) — yüklediğiniz sözlük kaynaklarında genel İncil kelimelerine bakın. [İncil Sözlüğü](theodia://help/dictionary) rehberine bakın.

Bazı araçların yüklü olması için ek kaynaklar gerekir. Bir araç soluk görünüyorsa veya "bulunamadı" gösteriyorsa, **Ayarlar** → **Kaynakları Yönet** bölümünü açın ve ihtiyaç duyduğu kaynağı ekleyin.

## Ekran üstü düğmeler

Bölüm metninin üstünde bir sıra simge bulunur. Bunlar hızlı eylemlerdir:

- **İncil sürümü** — farklı bir çeviriye geçmek için çeviri adına (örneğin "KJV") dokunun.
- **Kitap** — farklı bir kitaba atlamak için kitap adına dokunun.
- **Bölüm** — farklı bir bölüme atlamak için bölüm numarasına dokunun.
- **Yapay Zekâ'da Aç** (🤖) — geçerli bölümü sorunuzla birlikte yapay zekâ asistanına gönderin. (Yalnızca Scholar modu.)
- **Odak Modu** (📖) — temiz okuma için Odak Moduna geçin.
- **Paralel İnciller** (🔵 / ⚪) — paralel çevirileri açmak veya kapatmak için dokunun. Etkinleştirildiğinde, aynı bölüm ana metnin altında seçtiğiniz paralel çevirilerde gösterilir. Devre dışı bırakıldığında yalnızca ana çeviri gösterilir. Aşağıdaki **Aynı anda birden fazla çeviri okuma** bölümüne bakın.
- **Dinle** — tüm bölümün yüksek sesle okunmasını sağlayın. [Yüksek Sesle Okuma](theodia://help/tts) rehberine bakın.
- **Daha Fazla** — ek bölüm eylemlerini açın (bölüm İncil notu, bölüm yorumu, paylaşma vb.).

## Aynı anda birden fazla çeviri okuma

Ana çevirinizin yanında dört ek çeviriye kadar gösterebilirsiniz. Buna **paralel görünüm** denir.

1. **Ayarlar**'ı açın.
2. **Paralel İncil**'i açın.
3. **Paralel İncil Ekle**'ye dokunun ve bir çeviri seçin.
4. Daha fazlasını eklemek için tekrarlayın. Dört paralel çeviriye kadar olabilirsiniz.

Paralel görünüm açıkken, bölümdeki her ayet önce ana çevirinizi, ardından her paralel çevirideki aynı ayeti gösterir. Bu, zor bir ayeti farklı çevirmenlerin nasıl ele aldığını bölümü terk etmeden karşılaştırmayı kolaylaştırır.

Geçerli paralel düzeninizi bir **ön ayar** olarak kaydedebilirsiniz. Seçili çevirilerinizin yanındaki kaydet düğmesine dokunun, ona bir ad verin ve hızlı geçiş seçeneği olur. O kombinasyonu anında yüklemek için daha sonra herhangi bir ön ayara dokunun. Silmek için bir ön ayara uzun basın.

Ayrıca ayet menüsündeki **Karşılaştır** (⇄) aracıyla tek seferde yalnızca bir ayeti karşılaştırabilirsiniz. Bu, ayeti yüklü her çeviride gösteren bir panel açar.

## Alt başlıklar

Bazı çevirilerde bölüm başlıkları yerleşiktir (örneğin, "Dağ Vaazı"). Çevirinizde bunlar varsa, **Ayarlar**'daki **Alt Başlıkları Göster** ayarıyla bunları gösterebilir veya gizleyebilirsiniz. Alt başlıklar, ayetler arasında küçük gri başlıklar olarak görünür.

## Bölüm notu

Bölüm notu, tek bir ayete değil, tüm bölüme eklenen tek bir nottur. Bölüm hakkında tek bir büyük fikir için faydalıdır.

Bölüm notunu açmak için:

1. Ekranın üstündeki **Daha Fazla** düğmesine dokunun.
2. **Bölüm Notu**'na dokunun.
3. Notunuzu yazın. **Kaydet**'e dokunun.

Bölüm notu, bölümle birlikte kaydedilir. O bölümü her açtığınızda görünür.

## Arama vurguları

Bölüme bir aramadan geldiyseniz, arama kelimeleriniz ayet metninde sarıyla vurgulanır. Bu, bir ayetin neden eşleştiğini görmeyi kolaylaştırır.

Ayrıca okuduğunuz bir bölümde aramayı yeniden çalıştırabilirsiniz. **Arama** sekmesini açın ve bir kelime girin. Sonuçlar, eşleşmeler vurgulanmış hâlde doğrudan bölüme geri dönmenize izin verir.

Karşılıklı İnciller (MIB — Marvel Interlinear Bible — ve OHGB), kelime düzeyi düzen gerektirdikleri için her zaman Study Mode'da açılır.

## Tek bir bölüm için Odak Moduna geçme

Study Mode'daki herhangi bir bölümden üstteki 📖 düğmesine dokunun. Aynı bölüm, tüm menüler gizlenmiş hâlde Odak Modunda açılır. Study Mode'a geri dönmek için alt çubuktaki 📖 düğmesine dokunun.

## Study Mode ne zaman kullanılır?

Study Mode şu durumlarda doğru seçimdir:

- **Aynı anda okumak ve incelemek.** Tüm araçlar bir dokunuş uzağındadır.
- **Bilmediğiniz bir kelimeye bakmak.** Hızlı bir sözlük girişi için ayetteki bir Strong's numarasına dokunun.
- **Çevirileri karşılaştırmak.** Ayet menüsündeki Karşılaştır aracını kullanın veya paralel görünümü açın.
- **Bir ayetin İncil'in geri kalanına nasıl bağlandığını görmek.** Çapraz Referansları kullanın.
- **Okurken not almak.** Ayet menüsünde hızlı bir "Not ekle" seçeneği vardır.

Uzun, dikkat dağıtmayan okuma için Odak Moduna geçin.

## Odak Moduna geçme

Study Mode'daki herhangi bir bölümden üstteki 📖 düğmesine dokunun. Aynı bölüm, menüler ve inceleme araçları gizlenmiş hâlde [Odak Modunda](theodia://help/focus-mode) açılır. Study Mode'a geri dönmek için alt çubuktaki 📖 düğmesine dokunun. Odak Modunun ne yaptığı hakkında tam bir açıklama için [Odak Modu](theodia://help/focus-mode) rehberine bakın.

## Yardım ve sorular

Bir araç eksikse veya hata gösteriyorsa [Sık Karşılaşılan Sorunlar](theodia://help/common-problems) rehberine bakın. Theodia'da yeniyseniz, [İlk Bölümünüzü Okuma](theodia://help/first-read) rehberi temel bilgileri adım adım anlatır.
