---
title: Tablet Özellikleri
level: everyday
categories: [layout, tablet]
summary: Theodia'nın düzeninin bölmeli görünümler, yan paneller ve iki bölmeli okuma modlarıyla tabletlere ve daha geniş ekranlara nasıl uyum sağladığı.
---

# 📱 Tablet Özellikleri

Theodia, tabletlerdeki daha geniş ekranlardan yararlanacak şekilde tasarlanmıştır. Bir tablette (veya yaklaşık 700 pikselden geniş herhangi bir cihazda), uygulama birçok yerde otomatik olarak iki sütunlu bir düzene geçer.

> **Mod:** Burada açıklanan özellikler yalnızca geçerli kullanıcı modunuz onları destekliyorsa görünür. Örneğin, yorum yan panelleri ve yapay zekâ sohbeti yalnızca Scholar modunda kullanılabilir. Yer imleri, vurgulamalar ve notlar bölmeli görünümleri Standard veya Scholar modu gerektirir. Odak Modu yalnızca temiz, tek sütunlu okuma gösterir. Modları **Ayarlar** → **Uygulama Kullanıcı Modu**'ndan değiştirebilirsiniz.

## Okuyucu ayet menüsü

Bir ayet numarasına dokunduğunuzda (veya ayet metnine uzun bastığınızda), **ayet menüsü** koyu bir arka plan üzerinde **ortalanmış bir kart** olarak görünür.

- **Kopyala** ve **Paylaş** düğmeleri her zaman menünün üstünde görünürdür.
- **Yer İmleri** ve **Vurgulamalar** geçerli durumlarıyla gösterilir.
- **Yorum**, **Sözlük** ve **Karşılaştır** menüden açılır. Bir tablette bu araçlar seçildikten sonra bir yan panelde veya geniş bir kartta görünebilir.
- Menüyü kapatmak için arka plana veya kapatma okuna dokunun.

## Ayet Yorumu paneli

**Yorum** aracı, bir tablette **özel bir yan panel** açar:

- Yorum metni, İncil metninin yanında görünür.
- Yorumu İncil'den bağımsız olarak kaydırabilirsiniz.
- Kapatmak için **X**'e dokunun veya kaydırın.
- Panelin üstündeki bir **kitap simgesi**, yorum kaynaklarını değiştirmenizi sağlar.
- Bir **bölüm simgesi**, bölüm düzeyinde yorumu görüntülemenizi sağlar.

Bir telefonda yorum, tam ekran bir kaplama olarak açılır.

## Bölüm Yorumu

**Bölüm Yorumu**'na, ayet menüsünden değil, ekranın üstündeki **Daha Fazla** düğmesinden erişilir. Bir tablette, yorum metniyle ve İncil metnini birlikte okuyabilmeniz için Ayet Yorumu gibi bir yan panel olarak açılır.

## Karşılaştır sekmesi

**Karşılaştır** sekmesi (ayet menüsünde), bir tablette bir **yan panel** olarak açılır. Etkinleştirdiğiniz her paralel sürümde seçili ayeti gösterir. Okuyucuda o bölüme atlamak için herhangi bir sürüme dokunabilirsiniz.

## Sözlük / Strong's açılır penceresi

**Sözlük** aracı (ayet menüsü → Sözlük), bir tablette geniş bir kart olarak açılır. Yunanca veya İbranice kelimeyi, aktarmasını (transliterasyon), tanımını ve Strong's numarasını gösterir. O kelimenin İncil'deki her geçişini görmek için **Concordance** düğmesine dokunun.

## Sözlüğünü (Lexicon) açmak için bir kelimeye dokunun

Bir tabletteki **Kelime Bilgisi** yan panelinde, Strong's numarası olan her kelime kartına dokunulabilir. O kelime için **Lexicon** panelini doğrudan açmak için karta dokunun. Lexicon paneli, Kelime Bilgisi panelinin yerini alır, böylece okuyucuyu kapatmadan incelemeye devam edebilirsiniz.

Bir telefonda, Kelime Bilgisi kartlarına dokunulamaz, çünkü ekran iki panel için çok küçüktür.

## Yan yana Paralel İnciller

Ayarlar'da **Paralel İnciller**'e dokunun ve üç sürüme kadar seçin. Bir tablette, sürümler birbirinin yanında **dikey bölmeler** olarak görünür:

- Her bölme bağımsız olarak kaydırılır.
- Araçlarla bir yan panel açmak için bir ayet numarasına dokunabilirsiniz.
- **Karşılaştır** sekmesi, seçili tüm ayetleri tek bir yerde gösterir.
- Tek sütunlu görünüme dönmek ve bir bölmeyi kapatmak için herhangi bir bölmedeki **X**'e dokunun.
- Paralel görünümü Ayarlar'ı açmadan açmak veya kapatmak için üstteki simge çubuğundaki **Paralel İnciller** simgesine (🔵 / ⚪) dokunun.

Bir telefonda, paralel sürümler yan yana yerine art arda (dikey) gösterilir. Aynı geçiş simgesi telefonlarda da çalışır.

## Yer imleri ve vurgulamalar bölmeli görünümü

Bir tablette **Yer İmleri** ve **Vurgulamalar** sekmeleri bir ana-detay düzeni kullanır:

- **Sol taraf** — yer imlerinin veya vurgulamaların listesi.
- **Sağ taraf** — bir ögeye dokunmak, ayet veya bölüm metniyle bir önizleme bölmesi açar.

Kaydettiğiniz ögeleri gözden geçirebilir ve sekmeden ayrılmadan önizleyebilirsiniz. Bir telefonda, bir ögeye dokunmak okuyucu ekranına gider.

## Notlar bölmeli görünümü

Bir tabletteki **Notlar** sekmesi, solda not listenizi, sağda seçili notu gösterir. Listeden ayrılmadan art arda birkaç nota göz atabilmeniz için bir nota dokunmak onu bir yan panelde açar. Not oluşturma veya düzenleme de bir yan panel kullanır.

## Arama bölmeli görünümü

Bir tablette **Arama** sekmesi, bir arama yaptığınız anda solda arama formunu, sağda sonuçları gösterir. Sorgunuzu hassaslaştırabilir ve ekranları değiştirmeden sonuçların güncellenmesini izleyebilirsiniz. Bir telefonda, arama sonuçları ayrı bir ekranda açılır.

## Ayarlar kategori kenar çubuğu

Bir tabletteki **Ayarlar** ekranı, solda bir kategori listesi gösterir (Yapay Zekâ, Görünüm, Yedekleme, İnciller vb.). Sağda doğrudan ayarlarına atlamak için bir kategoriye dokunun. Yalnızca seçili kategori genişletilir, böylece tüm ayarlar listesinde kaydırma yapmanız gerekmez.

## Tabletlerde İncil gezinmesi

**İncil Listesi**, **İncil Kitapları** ve **İncil Bölümleri** ekranları tabletlerde tek sütunlu kalır, ancak içerik daha kolay okunabilmesi ve dokunulabilmesi için daha büyük dokunma hedefleri, daha geniş ızgaralar ve daha ferah boşluklar kullanır. Her adımın listesini veya ızgarasını netçe gösterebilmek için tam genişliğe ihtiyaç duyduğundan bölmeli görünüm düzeni kullanmazlar.

## Yatay ve dikey

Tableti döndürmek düzeni otomatik olarak ayarlar. **Yatayda**, yan panellerin bolca alanı vardır. **Dikeyde**, paneller daralır ama yine de metnin yanında kalır.

## Seçili ayet yapay zekâ sohbeti

**Yapay Zekâ** sohbeti, ayet menüsü yan panelinde açılır. Seçili ayet hakkında sorular sorabileceğiniz bir konuşma arayüzü gösterir. Yapay zekâ yanıtı panelde görünür ve okuyucudan ayrılmadan konuşmaya devam edebilirsiniz.

## Yapay zekâ ekranında konuşma kenar çubuğu

Bir tabletteki **Yapay Zekâ** sekmesinde, konuşma listesi her zaman kalıcı bir sol kenar çubuğu olarak görünürdür. Menü açmadan sohbetler arasında geçiş yapabilirsiniz. **Yeni Sohbet** düğmesi de her zaman görünürdür. Bir telefonda, konuşma listesi bir açılır çekmecededir.

## Aynı kalanlar

Her ekran iki bölmeye ayrılmaz. Aşağıdaki ekranlar tabletlerde tek sütunlu kalır:

- **İncil Listesi** — İncil sürümlerinin listesi (tam genişlik)
- **İncil Kitapları** — kitap ızgarası ve bölümler (tam genişlik)
- **İncil Bölümleri** — bölüm ızgarası (tam genişlik)
- **PDF'ler** — PDF kitaplığı daha geniş bir kart ızgarası kullanır (tam genişlik)
- **Ayarlar** — tek tek ayar sayfaları (tam genişlik)
- **Yardım** — yardım makaleleri (tam genişlik)

## Özet

Bir tablette şunları elde edersiniz:

- Yan yana dikey bölmelerde **Paralel İnciller**
- Kalıcı yan panellerde **Yorum**
- Geniş kartlarda **Karşılaştır** ve **Sözlük**
- Herhangi bir Kelime Bilgisi kartına dokunmayla **Lexicon**
- Ana-detay bölmeli görünümlerde **Yer İmleri, Vurgulamalar, Notlar, İbretler, Kitaplar, Ayarlar**
- Arama formunun yanında satır içi sonuçlarla **Arama**
- Otomatik düzen değişiklikleriyle hem **yatay** hem **dikey** desteklenir

Bir telefonda, her şey geleneksel tek sütunlu adım adım gezinmeyi kullanır. Uygulama, ekran genişliğini başlangıçta algılar ve doğru düzeni otomatik olarak seçer.
