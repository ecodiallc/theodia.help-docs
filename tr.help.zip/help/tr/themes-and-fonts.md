---
title: Temaları ve Yazı Tiplerini Değiştirme
level: everyday
categories: settings
summary: Uygulamanın görünüşünü nasıl değiştirirsiniz?
---

# Temaları ve Yazı Tiplerini Değiştirme

Theodia, uygulamanın görünüşünü değiştirmenize izin verir. Bir tema (açık veya koyu) ve bir yazı tipi boyutu seçebilirsiniz.

## Görünüm ayarlarını açma

1. **Ayarlar**'ı açın.
2. **Görünüm**'e dokunun.

## Temayı değiştirme

**Görünüm** bölümünde iki tema düğmesi görürsünüz:

- **Varsayılan** — koyu metinli açık bir arka plan. Gündüz için iyidir.
- **Koyu** — açık metinli koyu bir arka plan. Gece için iyidir ve pil tasarrufu sağlar.

Uygulamak için bir temaya dokunun. Değişiklik anında olur.

## Yazı tipi boyutunu değiştirme

**Görünüm** bölümünde boyut düğmelerinden birine dokunun: **---**, **--**, **-**, **Normal**, **+**, **++**, **+++**. Metin, tüm uygulamada küçülür veya büyür. Okuması sizin için en kolay olan boyutu seçin.

## İpuçları

- Koyu tema, OLED ekranlı telefonlarda pil tasarrufu sağlar.
- Metin okumak için çok küçükse, cihazın değil uygulamanın yazı tipi boyutunu artırın. Uygulamanın ayarı daha ince tanelidir.
- Uzun okumalar için koyu temayı ve daha büyük bir yazı tipini deneyin.
- [Çöl temasını etkinleştir](theodia://unlock-desert)
