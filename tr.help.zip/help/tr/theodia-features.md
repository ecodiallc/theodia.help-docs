---
title: Theodia Özellikleri
level: beginner
categories: welcome
summary: Theodia'yı özel kılan şeylere ve İncil incelemenize nasıl yardımcı olduğuna hızlı bir bakış.
---

# Theodia Özellikleri

Theodia, eksiksiz bir İncil inceleme arkadaşı olmak üzere inşa edilmiştir. İşte onu öne çıkaran şeyler.

## Önce Çevrimdışı

Her şey internet olmadan çalışır. İnciller, yorumlar, sözlükler, kitaplar ve ibretler cihazınızda depolanır. Uçakta, uzak bir bölgede veya sinyal olmayan herhangi bir yerde okuyabilir, arayabilir ve inceleyebilirsiniz.

## Gizlilik Odaklı

Verileriniz sizde kalır. Notlar, vurgulamalar, yer imleri ve okuma geçmişi cihazınızda yerel olarak depolanır. Hesap gerekmez ve isteğe bağlı yapay zekâ asistanını kullanmayı seçmediğiniz sürece hiçbir şey sunucuya gönderilmez.

## Tablet Desteği

Theodia hem telefonlar hem de tabletler için tasarlanmıştır. Daha geniş bir ekranda okuma, paralel İncil görünümleri ve fazladan alandan yararlanan bir düzen için daha fazla alan elde edersiniz.

## Yüklenebilir Kaynaklar

Uygulamayla gelenlerle sınırlı değilsiniz. Daha fazla İncil sürümü, yorum, sözlük, kitap ve ibret ekleyebilirsiniz. Kaynaklar projenin GitHub sayfasından edinilebilir ve doğrudan uygulamaya yüklenebilir.

## Yapay Zekâ Asistanı

İsteğe bağlı yapay zekâ asistanı, ayetleri anlamanıza, bağlamı açıklamanıza ve soruları yanıtlamanıza yardımcı olur. Yalnızca onu açarsanız etkindir. Varsayılan olarak, yapılandırdığınız bir uç nokta ve API anahtarı aracılığıyla sağladığınız uzak bir modele bağlanır. Yapay zekâyı ilk kez kullandığınızda, uygulama izninizi ister ve tam olarak neyin gönderildiğini gösterir.

## Paralel İncil Okuma

Aynı anda dört İncil sürümüne kadar okuyun. Bir bölüm açtığınızda, ana çeviriniz önce görünür ve her ayet, seçtiğiniz paralel çevirilerdeki aynı ayet tarafından takip edilir. İfadeleri karşılaştırın, farklılıkları inceleyin ve metnin daha eksiksiz bir resmini elde edin. En sevdiğiniz kombinasyonları ön ayar olarak kaydedin ve aralarında hızla geçiş yapın.

## Tam Metin Arama

Herhangi bir İncil sürümünde arama yapın. Kelimeler, ifadeler veya kısmi eşleşmeler arayın. Aramayı bir kitap aralığıyla da sınırlayabilirsiniz.

## Çapraz Referanslar

Doğrudan o bölüme atlamak için bir ayet referansına dokunun. Çapraz referanslar yerleşiktir ve tüm İncil'de çalışır.

## Sözlük ve Strong's Numaraları

Özgün Yunanca veya İbranice tanımı görmek için bir Strong's numarasına dokunun. Derinlemesine kelime incelemesi için sözlük girişleri dahildir.

## Yer İmleri ve Vurgulamalar

Ayetleri yer imleriyle kaydedin ve renklerle işaretleyin. Her şey yerel olarak depolanır ve oturumlar arasında kalıcıdır.

## Notlar

Herhangi bir ayetin yanına kendi düşüncelerinizi yazın. Notlar ayete bağlıdır ve sonradan bulması kolaydır.

## Günlük İbret

Günüze kısa bir ibret okumasıyla başlayın. Uygulama, bugünün girişine otomatik açılan ibretler içerir.

## Hristiyan Kitapları

Klasik Hristiyan edebiyatını uygulamanın içinde okuyun. Kitaplar kolay okuma için biçimlendirilmiştir ve hızlı gezinme için bir içindekiler tablosu içerir.

## PDF Okuma

Kendi PDF belgelerinizi içe aktarın, kategorilere düzenlenmiş olarak çevrimdışı okuyun. Okuyucu arama, içindekiler tablosu, yer imleri, yakınlaştırma ve sesli okuma destekler. Ayrıca topluluk deposundan paketlenmiş PDF koleksiyonları yükleyebilirsiniz.

## Çoklu Diller

Theodia, hem uygulama arayüzü hem de İncil içeriği için birçok dili destekler. Tercih ettiğiniz dilde inceleme yapmak için ayarlarda dilleri değiştirin.

## Koyu Mod ve Temalar

Açık veya koyu mod arasından seçim yapın ya da tercihinize uyan bir tema seçin. Okuma konforu önemlidir, özellikle düşük ışıkta.

## Veri Yedekleme

Notlarınızı, yer imlerinizi ve vurgulamalarınızı yedekleyin. Verilerinizi güvende tutun ve gerektiğinde yeni bir cihaza taşıyın.

## Reklam Yok, Dikkat Dağıtıcı Yok

Theodia odak için inşa edilmiştir. Reklam yok, açılır pencere yok, kesinti yok. Sadece metin ve inceleme araçlarınız.
