---
title: Yüksek Sesle Okuma (Metinden Konuşma)
level: everyday
categories: tts
summary: Theodia'nın İncil'i veya bir ibreti sesli okumasını sağlayın. Nasıl kullanılacağı, ses seçimi ve sessiz kaldığında ne yapılacağı.
---

# Yüksek Sesle Okuma (Metinden Konuşma)

> **Mod:** Metinden konuşma **Standard** ve **Scholar** modunda kullanılabilir. Odak Modu yalnızca temiz, dikkat dağıtmayan okuma içindir. Modları **Ayarlar** → **Uygulama Kullanıcı Modu**'ndan değiştirebilirsiniz.

Theodia, cihazınızın metinden konuşma (TTS) sesini kullanarak metni yüksek sesle okuyabilir. Tek bir ayeti, tüm bir bölümü veya bir ibreti dinleyebilirsiniz. Bu, eller serbest okuma, yürürken veya işe giderken dinleme, sesle birlikte okuma veya basitçe gözlerinize dinlenme vermek için faydalıdır.

## Dinle düğmesi nerededir?

Dinle düğmesini üç yerde bulursunuz.

### 1. Ayet menüsünde (tek ayet)

Tek seferde bir ayeti dinlemenin en hızlı yoludur. [Study Mode](theodia://help/study-mode)'da bir bölüm açın, ayet menüsünü açmak için bir ayete dokunun, sonra **Oku**'ya (🔊) dokunun. Okuma o ayetten başlar. Ekranın altında oynat, duraklat, geri sarma, ileri sarma ve bir ses seçici içeren küçük bir denetim çubuğu görünür.

Oku seçeneği, karşılıklı İnciller (MIB — Marvel Interlinear Bible — ve OHGB) için gösterilmez, çünkü onlar kelimeleri doğal okunmayan farklı bir düzende gösterir.

### 2. Bir bölümün üstünde (tüm bölüm)

Bir bölümü okurken ekranın üstündeki simge sırasına bakın. Tüm bölümü baştan itibaren okumaya başlamak için **Dinle**'ye (🔊) dokunun. Ses çalarken düğme bir durdurma düğmesine (⏹) dönüşür. Durdurmak için yeniden dokunun. Aynı denetim çubuğu altta görünür.

Farklı bir ayete atlayabilirsiniz ve oradaki Dinle düğmesi o ayetten başlayacaktır.

### 3. Bir ibrette

Herhangi bir ibret gününü açın, sonra okumanın üstündeki **Dinle** (🔊) düğmesine dokunun. İbret metninin tamamı, cümle cümle yüksek sesle okunur. Altta bir denetim çubuğu size oynatma, duraklatma, geri sarma ve ses denetimleri verir.

## Denetim çubuğunu kullanma

Ses çalarken ekranın altında küçük bir çubuk görünür kalır. Altı denetimi vardır:

- ⏪ **Geri sar** — bir ayet geri git (veya bir ibrette bir cümle)
- ⏸ **Duraklat / ▶ Devam et** — yerinizi kaybetmeden duraklatın. Aynı yerden devam etmek için yeniden dokunun.
- ⏩ **İleri sar** — sonraki ayete atla (veya bir ibrette sonraki cümle)
- 🎙 **Ses** — bölümden ayrılmadan ses seçiciyi açar (aşağıya bakın)
- ⚙ **Seçenekler** — genişletilmiş seçenekler panelini açar (aşağıya bakın)
- **Durdur** — durdurmak ve çubuğu kapatmak için ekranın üstündeki 🔊 düğmesine veya ses çalarken onun yerine geçen ⏹'a dokunun.

Denetim çubuğu, bölüm bittiğinde veya durdur'a dokunduğunuzda kapanır.

### Genişletilmiş seçenekler

Ek oynatma seçeneklerini genişletmek için ⚙'e dokunun. Bu ayarlar yalnızca geçerli bölüm için geçerlidir ve başka bir bölüme geçtiğinizde veya dinlemeyi bıraktığınızda sıfırlanır.

- ⏮ **Başa dön** — ayarladığınız aralığın ilk ayetine atlar.
- **Başlangıç** — okumanın nerede başlayacağını ayarlamak için bir ayet numarası yazın.
- **Bitiş** — okumanın nerede duracağını ayarlamak için bir ayet numarası yazın.
- **Tümü** — aralığı tüm bölüme sıfırlar.
- **()** — parantez içindeki metnin (parantezler arasındaki metin) sesli okunup okunmayacağını değiştirir.
- 🔁 **Tekrar** — sona ulaşıldığında arada kısa bir duraklamayla aralığın başında otomatik olarak yeniden başlar. Bunu bir başlangıç veya bitiş ayeti ayarlamadan açarsanız, tüm bölüm tekrarlanır.

### Dua ekranlarında

İman ilkeleri ve sabit dualar, oluşturulan dualar ve dua rutinlerinin kendi genişletilmiş seçenekleri vardır. Onları genişletmek için denetim çubuğundaki ⚙'e dokunun:

- **Hız** — 0.1x ile 1.5x arasından bir okuma hızı seçmek için hıza (örneğin `1x`) dokunun. Seçiminiz hatırlanır ve bir dahaki sefere sesli bir şey okuduğunuzda kullanılır.
- **()** — parantez içindeki metnin (parantezler arasındaki metin) sesli okunup okunmayacağını değiştirir.
- 🔁 **Tekrar** — dua bittiğinde arada kısa bir duraklamayla baştan otomatik olarak yeniden başlar. Bu, bir iman ilkesini veya sabit duayı ezbere öğrenmek için faydalıdır.

Hızı değiştirmek, yerinizi kaybetmeden hemen geçerlilik kazanır. Parantez içi seçeneğini açmak veya kapatmak, değişikliğin baştan duyulabilmesi için duayı baştan başlatır.

## Ses değiştirme

Theodia'nın okuma için hangi sesi kullanacağını seçebilirsiniz. Bu, cihaz varsayılanından farklı bir aksan, farklı bir dil veya daha hızlı ya da daha yavaş bir ses istiyorsanız faydalıdır.

1. **Ayarlar**'ı açın.
2. **Konuşma** bölümünü bulun.
3. **Ses Seç**'e dokunun.
4. Seslerin bir listesi görünür. İlk satır olan **Sistem Varsayılanı**, cihazınızın tercih ettiği sesi kullanır. Yeni varsayılan yapmak için başka herhangi bir satırı seçin.
5. Seçiminiz kaydedilir ve bir dahaki sefere **Dinle** veya **Oku**'ya dokunduğunuzda kullanılır.

Bölümden ayrılmadan aynı seçiciyi açmak için dinleme denetim çubuğundaki 🎙 simgesine de dokunabilirsiniz.

Ses kullanılabilirliği tamamen cihazınıza bağlıdır. iOS ve Android her biri bir dizi yerleşik sesle birlikte gelir. Cihazınızın **Erişilebilirlik** veya **Dil ve Giriş** ayarlarından daha fazla ses yükleyebilirsiniz. Theodia, cihazınızda yüklü olan herhangi bir sesi kullanabilir.

## Favori sesler

Cihazınızda birçok ses varsa, her seferinde tüm listeyi kaydırmak yavaş olabilir. Bir **favori sesler** kısa listesi oluşturabilirsiniz ve ses seçiciler yalnızca o sesleri gösterir.

1. **Ayarlar**'ı açın.
2. **Konuşma** bölümünü bulun.
3. **Favori Sesler**'e (bölümün en üstündeki ilk satır) dokunun.
4. Favoriler ekranını açmak için **Favori Sesleri Ayarla**'ya dokunun.
5. Önizlemek için bir sesin yanındaki oynat düğmesine dokunun. Favorilerinize eklemek için yıldıza dokunun. İstediğiniz kadar sesi favori yapabilirsiniz.
6. Geri dönün. Theodia genelindeki ses seçiciler artık yalnızca favori seslerinizi gösterir.

Tüm favorileri kaldırırsanız, seçiciler her sesi göstermeye geri döner. Favori sesler, Theodia ayarlarını yedekleyip geri yüklediğinizde dahil edilir.

## İncil başına farklı ses ayarlama

Her İncil çevirisine kendi sesini verebilirsiniz. Bu, çok farklı okuyan çeviriler arasında geçiş yaptığınızda faydalıdır — örneğin, King James Version için daha resmi bir ses ve NIV veya NLT gibi modern bir çeviri için daha sohbet edvari bir ses. Ayrıca farklı dillerdeki İncilleri dinliyorsanız ve her birinin doğru aksanla seslendirilmesini istiyorsanız yardımcı olur.

1. **Ayarlar**'ı açın.
2. **Konuşma** bölümünü bulun.
3. **İncil Sesleri**'ne bakın.
4. Listedeki herhangi bir İncil'e dokunun.
5. O çeviri için istediğiniz sesi seçin. İlk satır olan **Sistem Varsayılanı**, o İncil için ana TTS sesinizi kullanır.
6. Diğer herhangi bir İncil için tekrarlayın.

Üst bilgi, kaç İncil çevirisinin özel bir ses ayarlı olduğunu gösterir. Bir ses ayarlandığında **Ses Seç**, **Yorum Sesi**, **İncil Notları Sesi** ve **İbret Sesi** de bir sayı gösterir.

O İncil'den bir bölümü bir dahaki sefere dinlediğinizde, Theodia seçtiğiniz sesi kullanacaktır. Diğer tüm İnciller, siz onları değiştirmedikçe ana varsayılan sesi kullanmaya devam eder.

## Konuşmayı arka planda sürdürme

Varsayılan olarak, Theodia okuyucu ekranından ayrıldığınızda, başka bir uygulamaya geçtiğinizde veya telefonunuzu kilitlediğinizde konuşmayı durdurur. Bu, artık etkin biçimde okumuyorken beklenmedik sesleri önler.

Konuşmanın arka planda çalmaya devam etmesini sağlamak için:

1. **Ayarlar**'ı açın.
2. **Konuşma** bölümünü bulun.
3. **Konuşmayı arka planda sürdür** seçeneğini açın.

Bu açıkken, sekmeler arasında geçiş yapabilir, başka bir uygulama açabilir veya ekranı kilitleyebilirsiniz ve bölüm veya ibret okumaya devam eder. Denetim çubuğu etkin kalır, böylece bildirim alanından duraklatabilir veya atlayabilirsiniz (cihazınız destekliyorsa).

Konuşma hâlâ çalarken bu anahtarı **kapatmak** onu hemen durdurur.

## Çalışmıyorsa ne yapmalı?

Metinden konuşma cihazınıza bağlıdır. Theodia metni işletim sistemine gönderir ve işletim sistemi onu bir sesle yüksek sesle okur. Çalışmıyorsa şu adımları sırayla deneyin.

### Theodia TTS'in kullanılamaz olduğunu söylüyor

Bazı cihazlarda hiç TTS yoktur. **Ayarlar**'ı açın ve **TTS** bölümünü arayın. Bölüm orada değilse, cihazınız bu derlemede TTS'i desteklemiyor.

### Ses listesi boş

Ses seçici "ses bulunamadı" gösterebilir. Bu genellikle cihazın seslerini yüklemeyi henüz bitirmediği anlamına gelir.

1. **Ayarlar → Konuşma → Ses Seç** bölümünü açın.
2. Liste boşsa, açılır menünün hemen altında bir **Yeniden test et** düğmesi arayın. Ona dokunun. Theodia cihazı sesler için yeniden sorgular.
3. Hâlâ boşsa, cihazınızın sistem ayarlarını kontrol edin. iOS'ta **Ayarlar → Erişilebilirlik → Konuşulan İçerik → Sesler** bölümüne gidin ve diliniz için bir ses indirin. Android'de **Ayarlar → Dil ve Giriş → Metinden Konuşma Çıkışı** bölümüne gidin ve **Ses verisini yükle**'ye dokunun.
4. Yeni sesi alması için Theodia'yı kapatın ve yeniden açın.

Favori sesler ayarladıysanız ve liste boşsa, favorilerinizden en az birinin bu cihazda yüklü bir sesle eşleştiğinden emin olun.

### Oku'ya dokundum ama hiçbir şey olmuyor

- Cihazın sessiz modda olmadığını kontrol edin. Çoğu cihaz, sessiz moddayken TTS sesini çalmaz.
- Cihaz sesinin açık olduğundan emin olun.
- **Ayarlar → Konuşma** bölümündeki **Yeniden test et** düğmesini deneyin.
- **Ayarlar**'ı açın ve alttaki **Sistem** bölümüne bakın. **TTS** satırı **Kullanılabilir** demelidir. **Kullanılamaz** diyorsa, TTS işletim sistemi düzeyinde kapatılmıştır. Orada yeniden etkinleştirin, sonra Theodia'yı yeniden açın.

### Ses çalıyor ama yanlış dil

Theodia metni, geçerli içeriğin dilinde gönderir ve cihazdan seçtiğiniz sesi ister. Seçili ses farklı bir dil içinse, cihaz yine de metni okuyabilir, ancak tuhaf duyulur.

1. **Ayarlar → Konuşma → Ses Seç** bölümünü açın.
2. Cihazın doğrusunu seçmesine izin vermek için **Sistem Varsayılanı**'nı seçin veya okuduğunuz metnin diliyle eşleşen bir ses seçin.

Theodia şu anda Yunanca veya İbranice karşılıklı İncilleri sesli okumuyor. Oku ve Dinle düğmelerini o çevirilerde gizlidir.

### Ses çalıyor ama erken duruyor

Bir ayet eksikse veya okunamıyorsa, bölüm bir sonrakine atlar. Çubuk birkaç ayetten sonra kendiliğinden kapanırsa, baştan başlamak için ekranın üstündeki **Dinle** (🔊) düğmesine dokunun.

### Konuşma çalıyor ama nerede başladığını bilmiyorum

**Konuşmayı arka planda sürdür**'ü açtıysanız ve daha sonra ses duyuyorsanız ama onu başlatan ekranı bulamıyorsanız, uygulamanın herhangi bir yerinden durdurabilirsiniz.

1. **Ayarlar**'ı açın.
2. **Konuşma** bölümünü bulun.
3. Bölümün altındaki kırmızı **Konuşmayı Durdur** düğmesine dokunun.

Bu, Theodia'daki çalışan herhangi bir metinden konuşmayı hemen durdurur. Ayrıca cihazınızda uygulama değiştiriciyi açıp Theodia'yı kaydırarak sesi zorla durdurabilirsiniz.

### Çok hızlı veya çok yavaş okuyor

Theodia okuma hızını denetlemez. Hız, seçilen ses tarafından ayarlanır. Değiştirmek için:

- iOS'ta: **Ayarlar → Erişilebilirlik → Konuşulan İçerik → Konuşma Hızı**.
- Android'de: **Ayarlar → Dil ve Giriş → Metinden Konuşma Çıkışı → Konuşma Hızı**.

## İpuçları

- Denetim çubuğu, bölümler arasında gezinirken görünür kalır, böylece yerinizi kaybetmeden duraklatabilir, atlayabilir veya sesi değiştirebilirsiniz.
- Theodia ayet numaralarını küçük duraklamalar olarak okur. Çubuğu durdurabilir, farklı bir ayete kaydırabilir, sonra oradan devam etmek için oynat'a dokunabilirsiniz.
- Uzun dinlemeler için bildirimlerin sesi kesmemesi için **Rahatsız Etme**'yi açın.
- 🔊 düğmesi, cihazınızın geçerli ses düzeyini kullanır. Kulaklık takarsanız ses düzeyi kulaklık düzeyine geçer.

## Bir PDF'yi sesli okuma

Theodia ayrıca PDF sayfalarını sesli okuyabilir. Bir PDF açın ve araç çubuğundaki **Dinle** (hoparlör) düğmesine dokunun. Oynat/duraklat, geri sarma, ileri sarma, durdurma, bir ilerleme çubuğu ve hız ile ses seçicileri içeren bir denetim çubuğu görünür. Bir sayfa bittiğinde, okuma bir sonraki sayfada otomatik olarak devam eder.

PDF okuma, PDF'nin yüklü aranabilir metnini ve İncil okumasıyla aynı sesleri ve hızı kullanır.

## İlgili rehberler

- [Study Mode](theodia://help/study-mode) rehberi, ayet menüsünü ve ekran üstü düğmeleri daha ayrıntılı ele alır.
- [Odak Modu](theodia://help/focus-mode) rehberi, alt çubuktaki 🔊 düğmesiyle TTS'i de destekleyen daha temiz bir okuma görünümüdür.
- [Sık Karşılaşılan Sorunlar](theodia://help/common-problems) rehberi, diğer ses, ses ve dil sorunları için çözümler içerir.
- [Günlük İbretler](theodia://help/daily-devotionals) rehberi ibret okumayı ve dinle düğmesinin o ekranda nerede olduğunu ele alır.
- [PDF'ler](theodia://help/pdfs) rehberi PDF okuyucusunu ve dinle düğmesini ele alır.
