---
title: Theodia'ya Hoş Geldiniz
level: beginner
categories: welcome
summary: Uygulamaya kısa bir tur ve sizin için neler yapabileceği.
---

# Theodia'ya Hoş Geldiniz

Theodia bir İncil inceleme uygulamasıdır. Telefonunuzda veya tabletinizde, internetiniz olmasa bile çalışır. Okuduğunuz, aradığınız ve incelediğiniz her şey cihazınızda kaydedilir.

## Neler yapabilirsiniz?

Theodia'nın üç kullanıcı modu vardır. Her mod farklı bir özellik seti gösterir.

- **Reader** — İncil'i temiz, dikkat dağıtmayan bir görünümde okuyun.
- **Standard** — Reader'daki her şey, ayrıca yer imleri, vurgulamalar, notlar, metinden konuşma, arama ve günlük ibretler.
- **Scholar** — Standard'daki her şey, ayrıca yorumlar, sözlükler, İncil Sözlüğü, yapay zekâ asistanı ve daha fazlası.

Modları **Ayarlar** → **Uygulama Kullanıcı Modu**'ndan dilediğiniz zaman değiştirebilirsiniz.

### Size sunulan özellikler

Hangi modu seçerseniz seçin, her zaman şunları yapabilirsiniz:

- **İncil'i okuyun.** Birçok çeviri arasından seçim yapın. Aralarında dilediğiniz zaman geçiş yapın.
- **İncil'de arama yapın.** Bir kelime veya ifade arayın. Uygulama, eşleşen her ayeti gösterir.
- **Kitapları ve ibretleri okuyun.** Uygulama, Hristiyan klasikleri ve günlük bir ibretle birlikte gelir.

Modunuza bağlı olarak şunları da yapabilirsiniz:

- **Dinleyin.** Sesli okuma özelliğiyle ayetlerin okunmasını sağlayın. (Standard ve Scholar.)
- **Not alın.** Bir ayetin yanına kendi düşüncelerinizi yazın. (Standard ve Scholar.)
- **Vurgulayın.** Favori ayetlerinizi renkle işaretleyin. (Standard ve Scholar.)
- **Yer imi koyun.** Ayetleri hızlıca yeniden bulabilmeniz için kaydedin. (Standard ve Scholar.)
- **Yapay zekâ asistanına sorun.** Bir ayeti anlamak için yardım alın. (Yalnızca Scholar.)

## Nereden başlamalı?

1. Ekranın altındaki **İncil** sekmesini açın.
2. Bir çeviri seçin.
3. Okumaya başlamak için herhangi bir kitaba dokunun.

Daha fazlasını öğrenmek isterseniz, yardım rehberlerinin geri kalanı sizi bekliyor. Yardım ana sayfasındaki listeden bir konu seçin.

## Bilinmesi gereken birkaç şey

- Bir hesaba ihtiyacınız yok.
- Notlarınız, vurgulamalarınız ve yer imleriniz cihazınızda kalır.
- Onları yedekleyebilirsiniz. Nasıl yapılacağı için [Verilerinizi Yedekleme](theodia://help/backups) rehberine bakın.

## Daha fazla kaynak ister misiniz?

Uygulama, birkaç ücretsiz İncil sürümüyle birlikte gelir. Ek İnciller, yorumlar, sözlükler, kitaplar ve ibretler için [GitHub'dan Ek Kaynaklar Alma](theodia://help/getting-core-files) rehberine bakın. Size projenin GitHub sayfasından nasıl daha fazla kaynak bulup ekleyeceğinizi gösterir.

Hoş geldiniz. Theodia'nın okumanıza ve incelemenize yardımcı olmasını umuyoruz.
