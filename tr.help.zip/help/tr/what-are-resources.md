---
title: Kaynaklar Nedir?
level: beginner
categories: resources
summary: Theodia'nın kullandığı farklı dosya türlerine genel bakış — İnciller, yorumlar, kitaplar ve daha fazlası.
---

# Kaynaklar Nedir?

Theodia'da "kaynak", uygulamaya okuma veya inceleme malzemesi ekleyen herhangi bir dosyadır. Uygulamanın kendisi yalnızca bir okuyucu ve bir defterdir. İncil incelediğiniz İnciller, yorumlar, kitaplar ve diğer malzemeler, içine yüklediğiniz ayrı dosyalardır.

Bu rehber, farklı kaynak türlerini ve her birinin ne işe yaradığını açıklar.

## Bu neden önemli?

Theodia'yı ilk açtığınızda, okuyacak birkaç şey hâlihazırda vardır. Keşfettikçe, daha fazlasını yüklemek için düğmeler göreceksiniz. Her kaynak türünün ne olduğunu bilmek, neyi ekleyeceğinize karar vermenize yardımcı olur.

## Farklı kaynak türleri

Theodia, dosyaları uzantılarına göre tanır. Her uzantı, farklı bir kaynak türüdür.

### `.bible` — bir İncil çevirisi

Bir İncil çevirisi, King James Version gibi belirli bir sürümdeki İncil'in eksiksiz bir kopyasıdır. Theodia birkaç çeviriyle birlikte gelir ve daha fazlasını eklemenize izin verir.

Ayrıntılar için [İncil Çevirilerini Yükleme](theodia://help/installing-bibles) rehberine bakın.

### `.commentary` — bir yorum

Bir yorum, bir İncil bilgini tarafından yazılmış inceleme notları kitabıdır. Belirli bir ayet için, bir yorum size arka planı, anlamı ve ayetin İncil'in geri kalanına nasıl uyduğunu söyler.

Ayrıntılar için [Yorumlar ve Sözlükler](theodia://help/commentaries-and-lexicons) rehberine bakın.

### `.lexicon` — bir sözlük (lexicon)

Bir sözlük, İncil kelimelerinin bir sözlüğüdür. Size özgün İbranice veya Yunanca kelimeyi, ne anlama geldiğini ve İncil'de nasıl kullanıldığını söyler.

Ayrıntılar için [Yorumlar ve Sözlükler](theodia://help/commentaries-and-lexicons) rehberine bakın.

### `.book` — bir Hristiyan kitabı

Bir kitap, kilise tarihinden bir klasik gibi daha uzun bir Hristiyan eseridir. Uygulamada kitap okumak, İncil okumaya çok benzer şekilde çalışır. Theodia, ücretsiz olarak erişilebilen küçük bir Hristiyan klasikleri kitaplığıyla birlikte gelir.

Ayrıntılar için [Yerleşik Kitapları Okuma](theodia://help/reading-books) rehberine bakın.

### `.devotional` — bir ibret

Bir ibret, kısa bir günlük okumadır. Her girişte genellikle bir ayet, kısa bir tefekkür ve üzerinde düşünülecek bir dua veya soru bulunur. Birçok ibret, bir yıl boyunca günde bir giriş okunacak şekilde tasarlanmıştır.

Ayrıntılar için [Günlük İbretler](theodia://help/daily-devotionals) rehberine bakın.

### `.sqlite` — bir referans veritabanı

Bir referans veritabanı, uygulamanın okurken size ek bilgi vermek için kullandığı büyük bir arama dosyasıdır. İki türü vardır:

- **Çapraz referanslar** — okuduğunuz ayete bağlanan ayetlerin listeleri.
- **Morfoloji** — ayetteki özgün İbranice veya Yunanca kelimelerle ilgili bilgiler.

Bunları doğrudan açmazsınız. Bunlar arka planda çalışır ve İncil okuyucusuna özellikler ekler. Ayrıntılar için [Çapraz Referanslar](theodia://help/cross-references) rehberine bakın.

### `.data` — kelime verisi

Bir kelime verisi dosyası, özgün İncil kelimeleriyle ilgili ek bilgiler tutar. Sözlük ve inceleme araçları tarafından kullanılır. Referans veritabanları gibi, onu doğrudan açmazsınız. Uygulama onu arka planda kullanır.

## Kaynak ekleme

Uygulamanın **Kaynakları Yönet** ekranı, kaynak eklemenin kolay yoludur.

1. **Ayarlar**'ı açın.
2. **Kaynakları Yönet**'e dokunun.
3. **GitHub'dan Yükle**'ye dokunun.
4. İndirme penceresinde bir sekme seçin — **İnciller**, **Yorumlar**, **Kitaplar**, **İbretler** veya **Temel** — sonra istediğinizi seçin ve **Seçilenleri Yükle**'ye dokunun.
5. Ya da hâlihazırda indirdiğiniz bir dosyayı içe aktarmak için **Yerel Dosya Yükle**'ye dokunun.

Dosyaları doğrudan GitHub'dan almanın adım adım bir turu için [GitHub'dan Ek Kaynaklar Alma](theodia://help/getting-core-files) rehberine bakın.

## Kaynak kaldırma

1. **Ayarlar**'ı açın.
2. **Kaynakları Yönet**'e dokunun.
3. Kaldırmak istediğiniz kaynağı bulun.
4. Yanındaki çöp kutusu simgesine dokunun.
5. Kaldırmak istediğinizi onaylayın.

Bir kaynağı kaldırmak notlarınızı, vurgulamalarınızı veya yer imlerinizi silmez. Bunlar güvende kalır.

## Kaynaklar cihazınızda nerede durur?

Kaynaklar bulutta değil, cihazınızda depolanır. Bir kaynak yüklendikten sonra, onu okumak için internete ihtiyacınız yoktur. Cihazınızı yedekleyebilirsiniz, ancak kaynakların kendileri Theodia tarafından buluta yedeklenmez. Uygulamayı kaldırıp yeniden yüklerseniz, yüklediğiniz kaynakları yeniden eklemeniz gerekir.

## Yardım ve sorular

Sorun yaşıyorsanız [Soruları Nereye Sorabilirsiniz](theodia://help/getting-more-help) rehberine bakın. Ekip ve topluluk yardımcı olabilir.
