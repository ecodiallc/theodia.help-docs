---
title: Створення власних ресурсів
level: advanced
categories: resources
summary: Як створювати власні Біблії, коментарі, книги, щоденні чтання та лексикони й імпортувати їх до Theodia.
---

# Створення власних ресурсів

Theodia підтримує користувацькі ресурси у форматі Unique Bible App. Кожен ресурс — це файл SQLite з певною структурою таблиць. Ви можете створювати ці файли на комп’ютері та імпортувати їх до додатка.

## Типи файлів і необхідні таблиці

### Біблії (`.bible`)

Файл Біблії — це база даних SQLite з хоча б однією з цих таблиць:

- **`Verses`** — стовпці: `Book` (ціле, 1–66), `Chapter` (ціле), `Verse` (ціле), `Scripture` (текст)
- **`Bible`** — стовпці: `Book` (ціле), `Chapter` (ціле), `Verse` (ціле), `Scripture` (текст)

Можна також додати таблицю **`Details`** із метаданими, такими як `Description`, `Abbreviation` і `Version`.

Приклад SQL:

```sql
-- Основна таблиця тексту
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- Додаткова таблиця метаданих
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### Коментарі (`.commentary`)

Коментарі бувають трьох типів: **книжний**, **роздільний** та **віршовий**. Тип визначається **першою літерою імені файла**.

#### Книжні коментарі — ім’я файла починається з `b`

Книжний коментар охоплює всю книгу Біблії одним записом. Таблиці `Commentary` потрібні стовпці `Book` і `Scripture` (або `Content`). Стовпці `Chapter` і `Verse` не потрібні.

- **`Commentary`** — стовпці: `Book` (ціле), `Scripture` (текст) або `Content` (текст)

Приклад SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

Приклад імені файла: `bMyCommentary.commentary`

#### Роздільні коментарі — ім’я файла починається з `c`

Роздільний коментар охоплює кожен розділ біблійної книги.

- **`Commentary`** — стовпці: `Book` (ціле), `Chapter` (ціле), `Scripture` (текст) або `Content` (текст)

Приклад SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

Приклад імені файла: `cMyCommentary.commentary`

#### Віршові коментарі — ім’я файла починається з `v`

Віршовий коментар охоплює окремі вірші. Таблиці `Commentary` потрібні стовпці `Book`, `Chapter`, `Verse` і `Scripture` (або `Content`).

- **`Commentary`** — стовпці: `Book` (ціле), `Chapter` (ціле), `Verse` (ціле), `Scripture` (текст) або `Content` (текст)

Приклад SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

Приклад імені файла: `vMyCommentary.commentary`

### Книги (`.book`)

Файл книги — це база даних SQLite з таблицею `Reference`.

- **`Reference`** — стовпці: `id` (ціле), `Chapter` (текст), `Content` (текст)

Кожен рядок — один розділ. Стовпець `Chapter` — назва розділу. Стовпець `Content` — тіло розділу, яке може містити HTML (`<b>`, `<i>`, `<br>` тощо).

Приклад SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

Можна також створювати книги з файлів Markdown. Додаток може імпортувати файли `.md`, де `#` — назва книги, а `##` позначає розділи. Markdown автоматично перетворюється на HTML.

### Щоденні чтання (`.devotional`)

Файл щоденних читань — це база даних SQLite з таблицею `devotional`.

- **`devotional`** — стовпці: `month` (ціле, 1–12), `day` (ціле, 1–31), `devotion` (текст)

Кожен рядок — читання на один день. Додаток шукає запис за поточним місяцем і днем.

Приклад SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### Лексикони (`.lexicon`)

Файл лексикона — це база даних SQLite з таблицею `Lexicon`.

- **`Lexicon`** — стовпці: `Topic` (текст, номер Стронга), `Definition` (текст, стаття лексикона)

Стовпець `Topic` містить номер Стронга (наприклад, `G1161` або `H7225`). Стовпець `Definition` містить повний текст статті, який може містити HTML.

Приклад SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

Лексикони забезпечують роботу інструмента **Інформація про слово**. Коли ви натискаєте слово в інтерлінійній Біблії, додаток шукає номер Стронга в установлених лексиконах.

## Створення файла на комп’ютері

1. Встановіть редактор SQLite (DB Browser for SQLite, SQLiteStudio або інструмент командного рядка `sqlite3`).
2. Створіть новий файл бази даних.
3. Створіть необхідну таблицю та вставте дані.
4. Збережіть файл із правильним розширенням (`.bible`, `.commentary`, `.book`, `.devotional` або `.lexicon`).

## Імпорт до Theodia

1. Передайте файл на пристрій (AirDrop, електронна пошта, хмара або USB).
2. Відкрийте **Theodia**.
3. Перейдіть до **Налаштування** → **Керування ресурсами**.
4. Натисніть **Імпорт з файлу**.
5. Виберіть свій файл.

Додаток перевіряє файл (перевіряє наявність необхідної таблиці), копіює його до папки даних додатка та вмикає автоматично. Якщо файл неправильний, з’явиться повідомлення про помилку з поясненням.

## Обмеження

- Ви не можете перезаписати вбудовані ресурси. Якщо ви спробуєте імпортувати файл із тим самим іменем, що й вбудована Біблія, коментар чи книга, імпорт завершиться помилкою.
- Файли Біблії потребують таблиці `Verses` або `Bible`. Якщо жодної немає, імпорт завершиться помилкою.
- Файли коментарів потребують таблиці `Commentary`.
  - Книжні коментарі потребують стовпців `Book` і `Scripture` (або `Content`).
  - Роздільні коментарі потребують стовпців `Book`, `Chapter` і `Scripture` (або `Content`).
  - Віршові коментарі потребують стовпців `Book`, `Chapter`, `Verse` і `Scripture` (або `Content`).
- Файли книг потребують таблиці `Reference`.
- Файли лексиконів потребують таблиці `Lexicon`.
- Файли щоденних читань потребують таблиці `devotional`.

## Поради

- Тримайте розміри файлів розумними. Дуже великі файли SQLite можуть спричинити проблеми з пам’яттю на старих пристроях.
- Спочатку протестуйте файл на комп’ютері. Відкрийте його в оглядачі SQLite та виконайте `SELECT * FROM` необхідної таблиці, щоб переконатися, що дані виглядають правильно.
- Для Біблій переконайтеся, що стовпець `Book` використовує числа (1 = Буття, 66 = Об’явлення).
- Для коментарів можна використовувати або `Scripture`, або `Content` як текст коментаря.
- Для книг HTML у стовпці `Content` відображається під час читання. Тримайте його простим: `<b>`, `<i>`, `<br>` і `<hr>` є безпечними.

## Де знайти наявні ресурси

Theodia може читати ресурси з проєкту [Unique Bible App](https://github.com/eliranwong/UniqueBible). Там доступно багато Біблій, коментарів, книг та інших ресурсів у правильному форматі SQLite. Як знайти та додати їх, див. у посібнику [Отримання додаткових ресурсів](theodia://help/getting-core-files).
