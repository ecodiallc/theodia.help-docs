---
title: AI Prompts بہتر لکھنا
level: advanced
categories: ai
summary: AI معاون سے اچھے جوابات لینے کے لیے سوال کیسے پوچھیں۔
---

# AI Prompts بہتر لکھنا

> **وضع:** AI معاون کے لیے **اسکالر** وضع درکار ہے۔ آپ وضع تبدیل کر سکتے ہیں **ترتیبات** → **ایپ صارف وضع** میں۔

"Prompt" وہ سوال یا ہدایت ہے جو آپ AI کو دیتے ہیں۔ بہتر prompts بہتر جوابات دیتے ہیں۔ یہ گائیڈ بتاتی ہے کہ کیسے۔

## مخصوص ہوں

خراب: "محبت کے بارے میں بتائیں۔"
بہتر: "1 Corinthians 13 میں Paul کس قسم کا love بیان کرتے ہیں، اور یہ romantic love سے کیسے مختلف ہے؟"

جتنی تفصیل دیں گے، جواب اتنا ہی مفید ہوگا۔

## سیاق دیں

خراب: "اس آیت کا کیا مطلب ہے؟"
بہتر: "میں Romans 8 اپنے چھوٹے گروپ کے ساتھ پڑھ رہا ہوں۔ 'No condemnation' کا اس باب میں کیا مطلب ہے، اور یہ باب کے باقی حصے سے کیسے جڑتا ہے؟"

سیاق AI کو آپ کی صورت حال کے مطابق جواب دینے میں مدد دیتا ہے۔

## ایک وقت میں ایک چیز پوچھیں

خراب: "نماز، ایمان اور شفا کے بارے میں بتائیں۔"
بہتر: "پہلے نماز کے بارے میں بتائیں۔ بعد میں میں ایمان کے بارے میں پوچھوں گا۔"

ایک چیز پوچھنے سے جواب center رہتے ہیں۔

## AI کو کوئی کردار دیں

آپ AI سے کہہ سکتے ہیں کہ کسی خاص آواز میں جواب دے:

- "جواب اس طرح دیں جیسے نئے مسیحی کو سکھا رہے ہوں۔"
- "جواب Bible scholar کی طرح دیں۔"
- " جواب 10 سال کے بچے کے لیے دیں۔"

## follow-up questions استعمال کریں

اگر پہلا جواب بالکل نہ ہو تو follow-up پوچھیں:

- "کیا آپ یہ آسان الفاظ میں کہہ سکتے ہیں؟"
- "مثال دے سکتے ہیں؟"
- "اصل یونانی کیا کہتی ہے؟"
- "یہ Bible کے کہاں اور آتا ہے؟"

اچھا مکالمہ ادھر ادھر چلتا رہتا ہے۔ AI last کچھ پیغامات یاد رکھتا ہے۔

## AI کے جوابات جانچیں

AI غلطی کر سکتا ہے۔ یہ ٹول ہے، استاد نہیں۔

- AI کا جواب ان verses سے compare کریں جن پر وہ point کرے۔
- second opinion کے لیے app کی commentaries aur lexicons استعمال کریں۔
- doctrine کے بارے میں ہو تو pastor یا trusted friend سے پوچھیں۔

## عام prompt patterns

یہ patterns achha kaam karte hain:

- "Is aayat ko mere jaise new Christian ko explain karo."
- "Is chapter ka main point ek sentence mein batao."
- "Is passage se meri daily life ke liye teen applications do."
- "Is aayat par sermon preach karne se pehle main kaun se questions puchun?"
(Leave as Urdu-ish). Moving on. We have many remaining. Need batch files. Given quality, maybe continue with pure Urdu as much as possible but not perfect. Let's write app-user-mode and backups.