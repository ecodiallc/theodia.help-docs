---
title: App صارف وضع
level: beginner
categories: [user-mode]
summary: Reader، Standard اور Scholar وضع منتخب کریں تاکہ دستیاب فیچرز کنٹرول ہوں۔
---

# App صارف وضع

Theodia teen user modes deta hai jo control karte hain آپ kaun se features dekhte hain. اپنی usage ke according choose karen.

## Reader

SabSe simply mode. Reader mode distraction-free Bible reading ke liye hai.

- Koi bhi Bible translation padh sakte hain
- Focus Mode use clean full-screen reading
- Books and chapters navigate
- No study tools, no AI, no bookmarks, no highlights

Reader mode ideal hai agar aap chahate hain Theodia clean digital Bible lage bina extras.

## Standard

Standard mode everyday features add karta hai personal Bible study ke liye.

Reader plus:

- Bookmarks, highlights, aur notes
- Text-to-speech
- Study Mode reader with verse menu
- Parallel Bibles
- Command input
- Search the Bible
- Daily devotionals and built-in books

Standard mode most users ke liye sahi hai jo bina advanced study tools Bible padh, mark up, search chahate hain.

## Scholar

Full-featured mode. Scholar mode Theodia ke tamam tools unlock karta hai deep Bible study ke liye.

Standard plus:

- Commentaries and lexicons
- Cross-references
- Bible Dictionary
- Word Info (Strong's lookups)
- AI assistant and AI Commentary
- Launcher Menu

Scholar mode pastors, seminary students, aur original-language tools aur AI-powered study aids chahne walon ke liye hai.

## وضع کیسے بدلا جائے

1. ** tertibat** کھولیں۔
2. **App User Mode** ٹیپ کریں۔
3. **Reader**, **Standard**, یا **Scholar** چنیں۔

Change turant effect hoti hai. Menus aur buttons jo aapke mode me accessible nahi, hidden ho jate hain.

## وضع منتخب کرنا

- **Reader** — بس Bible padhna chahte hain, kuch aur nahi.
- **Standard** — bookmarks, highlights, notes, search, devotionals chahate hain.
- **Scholar** — tamam study tools chahate hain including AI, commentaries, lexicons.

Aap kabhi bhi mode switch kar sakte hain. Jab aap mode change karte hain to aapke bookmarks, highlights, aur notes delete nahi hote; support karne wale mode tak bas chupe rehte hain.
