---
title: اپنے data کا backup بنانا
level: everyday
categories: settings
summary: notes، highlights، bookmarks aur secrets save aur restore karna.
---

# اپنے data کا backup بنانا

Aap ke notes, highlights, bookmarks aur settings device par save hoti hain. Phone kho jaye, naya ho jaye, ya app uninstall ho to data kho sakta hai. Yeh guide batati hai kaise backup banayein.

## Backup settings kaise kholein

1. **Settings** kholein.
2. **App Backup** ٹیپ کریں۔

## App backup kaise banayein

1. **Settings** kholein.
2. **App Backup** ٹیپ کریں۔
3. **Create App Backup** ٹیپ کریں۔
4. device par folder chunne ke liye pick karen ya cloud drive.
5. App ek single file banata hai jisme aapka data hota hai. file `.zip` par khatam hoti hai.

## Backup kaise arrange karein

Backup banayein:

- Notes bohat likhne ke baad.
- Device OS update karne se pehle.
- App uninstall karne ya phone badalne se pehle.

Achha habit monthly backup. Kuch log weekly backup karte hain.

## App backup se restore

1. **Settings** kholein.
2. **App Backup** ٹیپ کریں۔
3. **Restore from App Backup** ٹیپ کریں۔
4. `.zip` backup file choose karen.
5. Har data type ke liye choose karen: device ka rakho, backup se replace karo, ya skip.
6. **Restore** ٹیپ karen.

Restore karta hai:

- Notes
- Highlights
- Bookmarks
- Bookmarks folders
- Settings (theme, font size, language)

## Secrets backup

Aapka **App Backup** sensitive secrets (AI API key, GitHub token) include nahi karta. Unhe alag backup ke liye **Secrets Backup** use karen.

### Secrets backup save

1. **Settings** kholein.
2. **App Backup** ٹیپ karen.
3. **Secrets Backup** ke neeche **Save Secrets Backup** ٹیپ karen.
4. Strong password enter aur confirm karen.
5. App secrets encrypt karke file share karta hai. Safe jagah save karen.

### Secrets backup restore

1. **Settings** kholein.
2. **App Backup** ٹیپ karen.
3. **Secrets Backup** ke neeche **Restore Secrets Backup** ٹیپ karen.
4. Encrypted file choose karen.
5. Save karte وقت wahi password enter karen.
6. Secrets restore ho jayenge.

> **Zaroori:** Password bhool jayen to secrets recover nahi ho sakte. Reset nahi hai.

## Janne wali batein

- Restore chosen categories ko replace karta hai. Backup ke baad added data those categories ke liye lost.
- App backup ek single `.zip` file hai. Safe rakho.
- Copy/move/cloud any service store.
- App backup me Bible translations nahi; woh **Settings → Manage Resources** se re-download.
- Secrets backups password se encrypted. Password yaad rakhne wala choose karen.

## Tip

Ek se zyada devices ho to backup file each device par copy aur restore karen. Data same hoga.
