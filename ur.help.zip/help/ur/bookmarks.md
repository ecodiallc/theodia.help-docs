---
title: آیات کو bookmark کرنا
level: everyday
categories: [annotate, read]
summary: آیات ko save karen taake phir se mil jayen.
---

# آیات کو bookmark کرنا

> **Mode:** Bookmarks **Standard** and **Scholar** mode me available hain. Focus Mode sirf clean reading ke liye hai. Aap mode switch kar sakte hain **Settings** → **App User Mode** mein.

Bookmark kisi verse ya book chapter ko save karta hai taake aap dobara find kar saken. Bookmarks book me tabs ki tarah hain.

## Verse bookmark kaise karein

1. Verse kholein.
2. Verse tap kar menu layein.
3. Menu mein **Bookmark** tap karen. Star icon verse saved mark karta hai.

Icon par check mark matlab verse bookmarked hai.

## Book chapter bookmark kaise karein

Book read karte waqt (Bible nahi) poori chapter bookmark kar sakte hain:

1. Chapter kholein.
2. Screen ke upar **Bookmark** icon ٹیپ karen.

## Bookmarks kaise dekhen

Neeche **Bookmarks** ٹیپ karen. Sari saved verses aur book chapters ki list.

## Bookmark remove kaise karein

- **One verse:** Verse kholein. Verse tap karen, phir **Bookmark** icon phir se tap karen. Check mark hat jata hai.
- **List se:** **Bookmarks** tab me long-press karen bookmark par. Menu Open. **Delete** tap karen. (Row par small × بھی use kar sakte.)

## Folders se organize karen

Bookmarks ko folders me rakh sakte ho, jaise "Sermon Prep" aur "Encouragement".

Folder banane ke liye:

1. **Bookmarks** tab kholein.
2. Upar **Manage Folders** tap karen.
3. Folder list ke upar **+ Create Folder** tap karen.
4. Name type kar **Save** tap karen.

Same name ke do folders nahi. Agar name exist karta hai to create-folder box me error aata hai.

Bookmark folder me put karne ke liye:

1. **Bookmarks** tab me bookmark long-press.
2. **Save to Folder** tap karen.
3. Folder choose kar **Done** tap karen.

## Bookmarks import karna

Theodia me other apps/files se bookmarks la sakte hain.

**Settings** → **Bookmarks** → **Import Bookmarks**. **Import from File** choose karen ya clipboard se paste karen. App format auto detect karta hai.

### Supported formats

**Native JSON export** — Theodia ka own export format. folders aur dates preserve.

**Netscape Bookmark HTML** — Chrome, Firefox, Safari export format. folders preserve.

**CSV** — Columns wala spreadsheet. App `url` aur `folder` (ya `href` / `category`) look karta hai. Example:

```csv
url,folder
/bible/KJV/John/3,Favorites
/bible/KJV/Genesis/1,Sermon Prep
```

**Plain text** — Har line Bible reference, app URL, ya folder directive. Example:

```
folder: Favorites
John 3:16
Genesis 1:1
folder: Sermon Prep
Matthew 5:1
```

- `folder: <name>` se shuru hoti lines following bookmarks ke active folder set.
- Bible refs default Bible me bookmarks ban jaate.
- App URLs seedha import.
- `#` ya `//` se shuru lines comments, skip.

### Tips for importing

- Duplicate bookmarks skip.
- External URLs (BibleGateway etc.) convert jab possible.
- Agar imported folder already exists, bookmarks existing folder me place.

## Tips

- Same verse many translations me bookmark kar sakte; all list me.
- Bookmarks device par rehte; cloud sync nahi.
- Backup ke liye [Backing Up Your Data](theodia://help/backups) dekho.

## PDFs me bookmarks

PDFs ke apne bookmarks separate. Reading PDF, toolbar ka **Bookmark** button tap kar current page save, naam do, aur baad me jump back. Har PDF ka apna list. [PDFs](theodia://help/pdfs).
