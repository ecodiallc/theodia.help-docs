---
title: AI ماڈل منتخب کرنا
level: advanced
categories: ai
summary: Theodia کے built-in tools aur capabilities ke sath kam karne wala model kaise chunen.
---

# AI ماڈل منتخب کرنا

> **وضع:** AI معاون کے لیے **اسکالر** وضع درکار ہے۔ آپ وضع تبدیل کر سکتے ہیں **ترتیبات** → **ایپ صارف وضع** میں۔

Theodia mein har AI model same kaam nahi karta. Best experience un models se aata hai jo **tool calling** support karte hain — AI ko Theodia ke built-in features use karne ki ability (verses lookup, search, commentaries, app navigation).

## Tool calling kya hai?

Jab aap Theodia AI ko question puchte hain, AI sirf text nahi deta; vo **act** bhi kar sakta hai.

- "John 3:16 ESV me dikhao." — AI verse reader me open karta hai.
- "Romans 8:28 par commentaries kya kehti hain?" — commentary content fetch.
- "Is verse ko bookmark karen." — bookmark create.

Models without tool calling sirf text answers de sakte hain; lookup/navigation/change nahi kar sakte.

## Kaun se models tools support karte hain?

### Remote models

Major providers ke modern remote models mostly OpenAI-compatible tool calling support. General:

- **Large models** (GPT-4o, Claude Sonnet/Opus, Gemini Pro) tools reliably handle karte hain aur chains.
- **Smaller/cheaper models** tools support kar sakte hain but less reliable.
- **Very old/specialized models** often tools nahi.

Agar unsure hain, Theodia mein test karen. "Show me Genesis 1:1" ya "Search the Bible for verses about love" puchen. Verse open ho ya search results aayen to tools working.

## Recommended models

- **OpenAI GPT-4o** — excellent tool support, fast, multi-step.
- **Anthropic Claude Sonnet / Opus** — reliable tool use, long passages.
- **Groq** (various) — fast, cheap, tool support varies.
- **OpenRouter** — many models ek account se; "function calling/tools" look karen.
- **[GitHub Models](theodia://help/github-models)** — recommended free provider.

## Avoid karen

- Pure text-completion models (GPT-3 base, raw LLaMA instruction-tuning na ho).
- Image/vision focused models.
- Under 1B parameters models.

## Tool support test

**Settings → AI Assistant** setup ke baad **Test connection** ٹیپ karen. Connection success ke baad app second request sample tool definition ke sath bhejte. Result:

- **✓ Tools supported** — accepts tool calls.
- **✗ Tools not supported** — text only, cannot open/search/bookmark.

Manual verify: "Show me Matthew 5:3 in the KJV." "What does lexicon say about 'agape' in John 3:16?" "Search the Bible for verses about forgiveness." "Bookmark Mark 12:30."

## Agar tools support nahi

Model phir bhi text answer de sakta hai, manually app navigate karna padega. Integrated experience miss hoga.

## Summary

- **tool calling / function calling** support wala model choose karen.
- Large remote models most reliable.
- Simple commands se test karen.
