---
title: Commands
level: everyday
categories: [layout, study]
summary: Command input se short command type kar kisi feature par jump karna. formats aur examples.
---

# Commands

**Command** input se Theodia ke almost any part me short instruction type kar jump kar sakte ho. Home tab ya **Launcher Menu** (header **▼**) se use.

## Kaise kaam

1. Command box ٹیپ.
2. Command type.
3. Keyboard go key ٹیپ.

App command padhta aur right screen le jaata.

## No slash prefix

Commands `/` prefix use nahi karte. Plain text:

```
john 3:16
search love
backup
```

`/settings` type karoge to unrecognizable.

## Bible references

Any Bible ref type open in reader.

```
psalms 23
john 3:16
matthew 5:1
1 cor 15:10
```

Book names full ya abbreviation. Non-English UI languages me active language book names bhi type.

## Search

```
search abraham
search love
search faith not works
```

## Bookmarks, compare, commentary, cross-references, word info

```
bookmark john 3:16
compare genesis 1:1
commentary john 1
aicommentary eph 2:8
xref 1 cor 15:10
word info john 1:1
```

## Lexicon

Strong's number type.

```
g1161
h7225
```

## Devotionals

```
devotional
devotional smith
devotional daily
```

No name => devotional list.

## Navigation shortcuts

```
notes
highlights
bookmarks
flashcards
playlist
theoscript
resources
read john 3:16
```

## Translation switch

Translation abbreviation type.

```
kjv
web
trlit
ohgb
```

Reader screen me swap; elsewhere opens translation at recent passage.

## Localized command verbs

Public command verbs active UI language ya English me type. English fallback. Hidden commands (settings shortcuts, install, Easter eggs) English syntax only.

## Help

Command box me `help` ya `commands` type kar in-app command reference.
