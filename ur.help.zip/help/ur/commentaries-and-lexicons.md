---
title: Commentaries aur Lexicons
level: everyday
categories: study
summary: Word meanings lookup kaise karen aur study notes padhna.
---

# Commentaries aur Lexicons

> **Mode:** Commentaries aur lexicons **Scholar** mode chahiye. Mode switch **Settings** → **App User Mode**.

Theodia two study tools: **commentaries** and **lexicons**. Bible deeper understand.

## Commentary kya hai?

Commentary Bible scholar likhi study notes ka book. Verse ke liye background, meaning, aur Bible rest connection.

## Lexicon kya hai?

Lexicon Bible words ka dictionary. Original Hebrew/Greek word, meaning, usage.

## Commentary open kaise

1. Chapter kholein.
2. Verse ٹیپ.
3. **Commentary** ٹیپ.

Panel notes show.

## Lexicon open kaise

1. Strong's numbers wala Bible chapter kholein.
2. Verse me Strong's number tap (G1234/H1234).
3. Panel original word, meaning, other verses show.

Strong's numbers different color.

## Different commentary choose

Commentary panel top dropdown. Installed commentaries list se pick.

## Different lexicon choose

Lexicon panel top dropdown. Installed lexicons list se pick.

## Built-in resources

Theodia built-in commentaries/lexicons ship. Offline. Additional nahi install/download.

## Kab use

- Commentary hard verse understand.
- Lexicon word studies.

## Tip

Note keep karne ke liye screenshot ya copy notes me (see Writing Notes).

## Plain-language Bible dictionary

English definitions Bible words/concepts (covenant, atonement, Pharisees). Verse menu tap **Dictionary** (📖). Lexicon se different. [Bible Dictionary](theodia://help/dictionary).
