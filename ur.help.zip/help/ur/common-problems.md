---
title: Aam problems
level: everyday
categories: trouble
summary: Jo problems frequently aayen unke quick fixes.
---

# Aam problems

Yeh guide most common problems cover karta. Agar problem yahan nahi, see [Where to Ask Questions](theodia://help/getting-more-help).

## App slow

1. Background apps close.
2. App restart.
3. Device restart.

## Bible translation nahi mil rahi

1. **Settings** → **Manage Resources** dekho installed.
2. Agar nahi, **Install from GitHub** ٹیپ.
3. Download modal me **Bibles** (ya Global Bibles) tab select.
4. **Install Selected** ٹیپ and wait.
5. Internet needed.

## Notes/bookmarks gone

1. Right tab check: Notes tab, Bookmarks tab.
2. Backup restore recent? backup data replace kar sakta. Backup date check.
3. Uninstall/reinstall data lost. Next time backup.

## Search not finding verses

1. Spelling correct.
2. Shorter word try. "Love" > "loving."
3. Right Bible translation installed. Search works installed translations.

## Read-aloud not working

1. Device volume up.
2. App speaker permission.
3. Different translation.
4. See [Reading Out Loud](theodia://help/tts).

## App crashing

1. App restart.
2. Device restart.
3. Still, report. See help guide.

## Uninstall

Normal app uninstall. Before backup. After uninstall data gone.

## Still stuck?

See getting more help. Search help guides from Help & Guides main screen with words like notifications/search/bookmarks.
