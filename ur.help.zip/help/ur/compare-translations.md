---
title: Translations compare karna
level: everyday
categories: [read, study]
summary: Same verse every installed translation me kaise dekhen.
---

# Translations compare karna

> **Mode:** Compare tool **Standard** and **Scholar** mode me. Focus Mode sirf clean reading. Mode switch **Settings** → **App User Mode**.

**Compare** tool one verse in every installed Bible translation one panel me. Useful different translators handle hard verse, ya translation pick time.

## Compare open

1. Any translation me chapter open.
2. Verse ٹیپ menu.
3. **Compare** (⇄) ٹیپ.

Panel opens title bar reference. Same verse every installed translation. Current first, rest alphabetical.

## Panel look

**Vertical list**, side-by-side columns nahi. Har row ek translation:

- **Translation name** (KJV) top row, tapable.
- **Verse text** below.

Scroll all translations. Installed all. Agar translation book/verse nahi has, left out.

## Verse different translation me padhna

Translation name tap. Compare closes, same chapter chosen translation me. Fastest jump.

## Compare close

- Phone: X top right.
- Tablet: X header, ya outside panel tap.

Back original translation.

## When use

- Translation pick.
- Hard verses.
- Word studies.

Whole chapter glance multiple translations parallel view: see [Study Mode](theodia://help/study-mode).
