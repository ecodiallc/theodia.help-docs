---
title: Apne resources create karna
level: advanced
categories: resources
summary: Custom Bibles, commentaries, books, devotionals, lexicons bana kar Theodia me import.
---

# Apne resources create karna

Theodia custom resources Unique Bible App format support. Har resource SQLite file specific table structure. Computer par create aur app me import.

## File types and required tables

### Bibles (`.bible`)

SQLite database at least one:

- **`Verses`** — Book (1-66), Chapter, Verse, Scripture
- **`Bible`** — same

**`Details`** optional metadata.

SQL example:

```sql
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);
INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');
CREATE TABLE Details (Title TEXT, Abbreviation TEXT, Information TEXT, Version INTEGER, OldTestament INTEGER, NewTestament INTEGER, Apocrypha INTEGER, Strongs INTEGER);
INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### Commentaries (`.commentary`)

Three types based on filename first letter:

#### Book (`b`)

Book entire book one entry. Commentary: Book and Scripture/Content.

Filename `bMyCommentary.commentary`.

#### Chapter (`c`)

Per chapter commentary. Book, Chapter, Scripture/Content.

Filename `cMyCommentary.commentary`.

#### Verse (`v`)

Per verse. Book, Chapter, Verse, Scripture/Content.

Filename `vMyCommentary.commentary`.

### Books (`.book`)

SQLite with `Reference` table: id, Chapter, Content. Each row chapter. Content HTML (`<b>`, `<i>`, `<br>`). Also import `.md`: `#` title, `##` chapters (converted HTML).

### Devotionals (`.devotional`)

`devotional` table: month (1-12), day (1-31), devotion. Lookup today's month/day.

### Lexicons (`.lexicon`)

`Lexicon` table: Topic (Strong's number), Definition (text incl HTML). Word Info tool uses.

## Computer par file create

1. SQLite editor install (DB Browser, SQLiteStudio, sqlite3 CLI).
2. New DB file create.
3. Required table create and insert data.
4. Correct extension save.

## Theodia me import

1. Device transfer (AirDrop, email, cloud, USB).
2. Theodia open.
3. **Settings** → **Manage Resources**.
4. **Import from File**.
5. File select.

App validates table, copies, enables. Invalid gives error.

## Limitations

- Built-in resources overwrite nahi. Same name import fails.
- Bibles need Verses or Bible table.
- Commentary needs Commentary table with columns respective.
- Books need Reference.
- Lexicons need Lexicon.
- Devotionals need devotional.

## Tips

- File sizes reasonable.
- Computer test: `SELECT * FROM required table`.
- Bible Book numeric (1 Genesis, 66 Revelation).
- Commentary Scripture or Content both.
- Books HTML keep simple.

## Existing resources where

Unique Bible App project has many. See [Getting Extra Resources](theodia://help/getting-core-files).
