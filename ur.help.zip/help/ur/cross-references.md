---
title: Cross-References
level: everyday
categories: study
summary: Aap jo verse padh rahe ho usse connect karne wale verses find karna.
---

# Cross-References

> **Mode:** Cross-references **Standard** aur **Scholar** mode me. Focus Mode sirf clean reading. Mode switch **Settings** → **App User Mode**.

Cross-reference ek aur verse hota hai jo aapke verse ke same baat karta hai. Panel connected verses dikhata.

## Cross-references open

1. Chapter kholein.
2. Verse ٹیپ menu.
3. **Cross References** ٹیپ.

Panel connected verses list.

## List read

Har row ek connecting verse:

- Book, chapter, verse.
- Verse text preview.
- Score connection strength.

## Jump

Row tap kar verse open. Back button return.

## Score meaning

High score strong direct; low loose.

## Study use

- Word studies.
- Theme studies (love, covenant).
- Sermon prep supporting verses.

## Tip

Word-for-word translations like WEB best.
