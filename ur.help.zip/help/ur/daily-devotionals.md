---
title: Daily Devotionals
level: everyday
categories: [content, read]
summary: Har din chhota devotional kaise padhen.
---

# Daily Devotionals

Devotional ek day ka short reading hota hai. Usually verse, short thought, thinking question. Theodia built-in devotional library.

## Devotional open

1. Neeche **Devotionals** ٹیپ.
2. Installed devotionals list.
3. Tap open.

## Read

1. Open.
2. Scroll read.
3. Top buttons:
   - **date** tap jump day.
   - **star** bookmark day.
   - **speaker** read aloud (device support). See [Reading Out Loud](theodia://help/tts).
   - **Previous/Next** previous/next day.

## Verse save

1. Open devotional.
2. Verse ٹیپ.
3. **Bookmark** or **Highlight**.

Saved in Bookmarks/Highlights.

## Note on devotional

1. Open.
2. Verse ٹیپ.
3. **Note** type save.

Note Notes tab me.

## Tips

- Offline kaam.
- More devotionals see [Getting Extra Resources from GitHub](theodia://help/getting-core-files).
