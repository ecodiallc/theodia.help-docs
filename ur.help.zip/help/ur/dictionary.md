---
title: Bible Dictionary
level: everyday
categories: study
summary: Installed dictionary resources me Bible words/concepts lookup. Verse menu ya lexicon entry se open; tap word to same word every dictionary me dekho.
---

# Bible Dictionary

> **Mode:** Bible Dictionary **Scholar** mode chahiye. Mode switch **Settings** → **App User Mode**.

Bible Dictionary tool har installed dictionary resource me word/phrase lookup. Plain-language definition, person/place description, theology concept.

Dictionary alag hota hai **Word Info** se: Word Info original Hebrew/Greek; dictionary tapped English word. Word-by-word notes see [Commentaries and Lexicons](theodia://help/commentaries-and-lexicons).

## Dictionary open

### Verse menu se

1. [Study Mode](theodia://help/study-mode) me chapter open.
2. Verse ٹیپ menu.
3. **Dictionary** (📖) ٹیپ.

Panel title verse ref. Verse text top, har word tappable. Below chip strip installed dictionaries. Definition empty until tap.

### Lexicon entry se

Word Info panel lexicon entry ke blue links tap. Lexicon close, dictionary opens that article. Fastest.

## Verse view kaise

Opening from verse menu, verse top panel list of tappable words. Common English words (the, and, of, to, a) not tappable. Others colored bold. Tap any word. Theodia every installed dictionary exact match search. Chip strip update (no entry dimmed). First with entry selected, definition below.

Tapped word highlighted verse top.

## Dictionaries switch

Every installed dict chip below verse after tap:
- Solid color: entry exists. Tap switch.
- Dimmed: no entry for that word.
- Selected highlighted. Tap another solid chip updates definition.

Only one has entry => only one solid.

## Panel parts

- **Verse** opened verse, tapped word highlighted.
- **Chip strip** installed dictionaries; solid/dimmed.
- **Definition** selected dictionary article, paragraphs/headings, internal links tappable.

## No entry

No installed dict covers tapped word => "no entries found". Common words like year/come. Try specific word or Word Info tool.

## No dictionary installed

Needs at least one dictionary resource. Theodia ships one. Removed/custom install none => verse view still, chips empty, every search no entries.

Additional dictionaries separately install nahi.

## Tips

- Exact word matches. "love" finds "love" not "loved"/"loving". Related form ke liye Word Info use original language.
- Phone full-screen modal, tablet side panel; same 3 parts.
- Different verse tap opens new verse; selection cleared.
- Some dictionary entries link another dict; tap follow trail.

## Dictionary vs Word Info

- **Dictionary** (📖) English word lookup in English dictionaries. Plain-language definitions.
- **Word Info** (?) original Greek/Hebrew behind verse in lexicons. Word studies.

Start dictionary; original language dig switch Word Info. See [Commentaries and Lexicons](theodia://help/commentaries-and-lexicons).

## Related guides

- [Study Mode](theodia://help/study-mode) verse menu details.
- [Commentaries and Lexicons](theodia://help/commentaries-and-lexicons) Word Info.
- [What are Resources?](theodia://help/what-are-resources)
- [Common Problems](theodia://help/common-problems)
