---
title: Encyclopedia
level: everyday
categories: study
summary: Encyclopedia articles lookup aur reference works browse karna.
---

# Encyclopedia

Theodia built-in **Encyclopedia** Bible-related articles, people, places, topics. App me _Kitto's Illustrated Commentary_ (KIT) built-in, aur GitHub repo se additional download.

## Encyclopedia kya?

Encyclopedia short articles ka reference work. Each article person/place/event/Bible topic. Commentary specific verse; encyclopedia topic itself.

## Open

1. Bottom toolbar **Encyclopedia**.
2. Top abbreviation row se encyclopedia choose.
3. Search box type topic/person/place.

Search requires at least **3 characters** before results/autocomplete.

## Article read

- **Phone**: result tap opens article new screen.
- **Tablet**: article right panel, list left.

## Select encyclopedias

Abbreviation chip (KIT) tap switch. More than one encyclopedia search, use **Search** tab and mode **Encyclopedia**.

## More encyclopedias

1. **Settings**.
2. **Manage Resources**.
3. **Install from GitHub**.
4. **Encyclopedias** tab.
5. Download button next to encyclopedia.

GitHub repo se download/install. Installed appear Encyclopedia screen/Search.

Local file: Manage Resources → **Install Local File** choose `.encyclopedia`. Copied folder + shared lookup index.

## Long-press full title

Search screen encyclopedia chips abbreviations. Long-press chip full name.

## When use

- Passage read karne se pehle/while look up.
- Broad Bible word/concept spanning many verses.
- Companion commentary deepen study.
