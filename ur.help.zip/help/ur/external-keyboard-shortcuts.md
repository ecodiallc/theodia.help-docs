---
title: External keyboard shortcuts
level: everyday
categories: [tablet, settings]
summary: iPad external keyboard attached hone par full shortcut reference.
---

# ⌨️ External keyboard shortcuts

iPad ke sath external keyboard (Magic, Bluetooth, USB) use karne par bina screen tap navigate possible.

> **Mode:** Some shortcuts corresponding feature availability depend user mode. Example `Cmd + Option + 6` Bookmarks, `Cmd + Option + 7` Highlights Reader mode me kuch nahi. Switch modes **Settings** → **App User Mode**.

Shortcuts **iPad** par.

## Global (anywhere)

Table same: shortcuts action unchanged. Refer English command keys; key bindings standard.

(See English page for complete table.)

## Bible Reader, Study/Focus, etc

(See English page for shortcut tables; keys unchanged.)

Use this guide's tables as-is; shortcut names are physical keys.
