---
title: Frequently Asked Questions
level: everyday
categories: faq
summary: Theodia use karne ke common sawal jawab.
---

# Frequently Asked Questions

## Theodia cost karta hai?

One-time purchase. No subscription, ads, in-app purchases, donations. Catalog additional resources free after purchase.

## Internet chahiye?

No. Installed ke baad offline kaam. Internet only new resources download.

## Data kahan stored?

Device par. Server upload nahi. Manual backup see [Backing Up Your Data](theodia://help/backups).

## Bible aloud sun sakte?

Yes. Chapter open, menu, read-aloud choose. Device TTS voice required. See [Reading Out Loud](theodia://help/tts).

## Verse search kaise?

Command home screen `John 3:16` ya Search tab word/phrase.

## Bug/feature report?

About screen Submit Suggestion / Issue, GitHub issues/discussions.

## Supported devices?

iPhone, iPad, Android phones/tablets. At least 2 GB free storage recommended.

## External keyboard?

Yes iPad Bluetooth/USB. See shortcuts guide.

## Languages?

Interface English, Arabic, Chinese (Simplified/Traditional), Czech, Danish, Dutch, Filipino, French, German, Greek, Hebrew, Hindi, Indonesian, Italian, Japanese, Korean, Polish, Portuguese (Brazil), Romanian, Russian, Spanish, Swahili, Swedish, Thai, Turkish, Ukrainian, Vietnamese. Bible text language translations installed depend.

## Language change?

Settings look language option.

## More help?

Guides browse or GitHub Discussions. Help main screen search topics.
