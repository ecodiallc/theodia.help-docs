---
title: Apna pehla chapter padhna
level: beginner
categories: [start, read]
summary: Chapter open karke padhne ka step-by-step guide.
---

# Apna pehla chapter padhna

Yeh guide first time chapter open.

## Step 1: Bible tab open

Bottom tabs me **Bible** tap.

## Step 2: Book pick

Bible books list. Genesis pehla, John middle, Revelation last. Book name tap.

## Step 3: Chapter pick

Numbers 1 onward. Chapter tap. Chapter opens verses.

## Step 4: Move

- Swipe **left** next chapter.
- Swipe **right** previous.

## Step 5: Verse interact

Depends user mode.

### Reader mode

Clean distraction-free.
- Verse tap highlight briefly.
- No study tools/menus.
- More features? Standard/Scholar in Settings.

### Standard mode

Everyday study. Tap verse menu:
- Bookmark
- Highlight color
- Add note
- Copy
- Compare translation
- Cross-references

### Scholar mode

All Standard plus:
- Commentary
- Word Info/original language
- Dictionary
- AI assistant

Mode switch anytime Settings.

## Need tool help?

Each tool guide. Tap **Help** home. Start [Study Mode](theodia://help/study-mode). Layout location [navigating-the-app](theodia://help/navigating-the-app). More resources [getting-core-files](theodia://help/getting-core-files).
