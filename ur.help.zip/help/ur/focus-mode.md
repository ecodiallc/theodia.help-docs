---
title: Focus Mode
level: beginner
categories: [layout, read]
summary: Clean distraction-free long passage reading.
---

# Focus Mode

> **Mode:** Focus Mode Reader mode reader. Standard/Scholar me alternative Study Mode. Mode switch Settings → App User Mode.

Focus Mode Bible chapter without buttons/menus read. Long reading sessions good.

## On

1. Koi bhi chapter open.
2. Top row icons mein 📖 tap. Same chapter Focus Mode opens. Menus/buttons hide, only Bible text.
Reader mode chapters Focus Mode auto. 📖 hidden (no Study Mode).

## Do

- Scroll read.
- Swipe next/previous chapter.
- Tap bottom bar 📖 back Study Mode. (Reader mode hidden.)
- Tap 🔊 bottom bar TTS. Mini control bar play/pause/rewind/ff/voice. (Reader mode hidden—TTS needs Standard/Scholar.)

## Use

- Whole book chapter by chapter.
- Devotional/quiet time long passage.
- Read aloud follow along without distractions.

## Switch Study Mode

Focus Mode tools hides but one tap. Top 📖 tap same chapter [Study Mode](theodia://help/study-mode). Study Mode commentary, crossrefs, lexicon, notes. See guide. Reader mode hides 📖 because Study Mode unavailable.
