---
title: Quickly aana jaana
level: beginner
categories: layout
summary: Theodia me verse, chapter ya screen par jump karne ke fast ways.
---

# Quickly aana jaana

Navigation cheat sheet.

## Verse directly jump

Home screen **Command** fastest.
- `John 3:16` type Go.
- `Psalms 23` type Go.
- `Genesis 1` type Go.
Exact chapter opens (included verse scroll).

## Swipe chapters

Reading:
- Swipe left → next.
- Swipe right → previous.
Across books. Exodus 40 ke baad Leviticus.

## Top bar

Reading top translation, book, chapter.
- Translation tap switch Bibles.
- Book tap pick book.
- Chapter tap pick chapter.

## Bookmark jump

Saved verse: Bookmarks tab tap entry → verse.

## Search jump

Search tab → word/phrase → result tap → chapter opens with search words highlighted yellow.

## Switch layouts

Study Mode: chapter with tools. Focus Mode: tools hidden only text. Top 📖 tap switch (again back). Reader mode always Focus.

## Bottom tabs

Bottom icons always. Tabs by user mode.

All modes:
- Home
- Bibles
- Search
- Settings

Standard/Scholar:
- Bookmarks
- Highlights
- Notes
- PDFs

Scholar:
- AI (if turned on)

### Remembering place

Each tab own nav history. Switch back same place.
- Bibles tab pick translation/chapter, then Search; later Bibles same chapter.
- Bookmarks tap bookmarked verse, then Settings; Bookmarks returns list.

Each tab remembers until explicitly navigate different screen in that tab.

### Reset

Tab root screen when:
- Already on tab tap same icon.
- App force-closed/reopened.

### Bottom tabs vs main menu

- Bottom tabs remember stack.
- Main menu item navigates, dropdown not overlay.

Example:
- Reading John 3. Bookmarks tab then Bibles again → John 3.
- Reading John 3. Menu Notes review, then Bibles tab → John 3.

## Tips

- Home remembers expanded/collapsed.
- Tab missing check user mode Settings → App User Mode. Reader hides bookmarks/highlights/notes/AI. Standard hides AI. Enable feature or resource.
