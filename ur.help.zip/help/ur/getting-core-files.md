---
title: Extra resources lena
level: everyday
categories: resources
summary: Bibles, commentaries, books, other resources app me kaise add karen.
---

# Extra resources lena

Theodia built-in resources ke sath aata, aur add kar sakte ho through Manage Resources.

## Kya add kar sakte

- Bibles (translations languages)
- Commentaries (study notes)
- Books (classics/reference)
- Devotionals (daily readings)
- Core files (morphology, cross-references, MIB)

## In-app add

1. Settings.
2. Manage Resources.
3. Tab choose: Core/Bibles/Commentaries/Books/Devotionals.
4. Browse tap read more.
5. Checkbox select.
6. Bottom Download. Auto install.
Instant available, restart not needed.

## Core files

Large data deeper study tools: Morphology original-language forms, cross-reference DBs, Marvel Interlinear Bible (MIB). Once download, offline.

## Global Bibles

Global tab broader collection. Main Bibles me desired na ho to check.

## Installed manage

Manage Resources main screen:
- Enable/disable (Hidden menus but on-device).
- Delete free space, re-download later.

## Own files

1. Manage Resources → Import Local File.
2. Pick file.
3. App reads adds.

Accepted:
- .bible
- .commentary
- .lexicon
- .book
- .devotional

## Custom GitHub repo

1. Settings → GitHub Repositories.
2. Add Repository.
3. GitHub URL enter.
4. Types choose (bibles/commentaries/books).
5. Save.
6. Manage Resources new tab resources.

Private repo: Personal Access Token add Settings → GitHub Repositories.

## File sizes

Bibles small few MB. Commentaries/core large (hundreds MB). Wi-Fi recommended.
- Use Manage Resources browse install.
- Core files deeper study.
- Import local own.
- Custom GitHub repos other sources.
