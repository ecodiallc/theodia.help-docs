---
title: Questions kahan puchhen
level: everyday
categories: trouble
summary: Theodia team/community se help kaise len aur app ke andar help topics find.
---

# Questions kahan puchhen

Stuck ho to kuch places.

## Finding help topic

- Browse category: Help & Guides → category tap (Settings/troubleshooting).
- Search keyword: Help main screen search box. Example notifications guide, search guide.
- Check Settings first: features config Settings → Notifications. Each settings section help link.

## In app

About screen two buttons:
- Submit Suggestion / Issue — form question/idea/bug.
- Discussion / Feedback — community discussion board.

## GitHub

Known issues/recent changes [GitHub](https://github.com/ecodiallc/theodia.app).

## Community

[community discussion board](https://github.com/ecodiallc/theodia.app/discussions).

## Before ask

- Device?
- App version? (About)
- Steps?
- Happened?
- Expected?

## Expect

- Bug reports reply few days.
- Ideas read all, timing no promise.
- Community faster.
- Privacy: no private info in submission.
