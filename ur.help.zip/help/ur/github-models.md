---
title: GitHub Models
categories: ai
level: advanced
summary: GitHub Models setup — API subscription bina AI exploring free.
---

# GitHub Models

> **Mode:** AI assistant **Scholar** mode. Mode switch Settings → App User Mode.

Agar paid AI service nahi, GitHub Models easiest Theodia AI start. Free GitHub account chahiye.

## What is GitHub Models?

GitHub service modern AI models API ke through. OpenAI format same, Theodia works.

## Why choose?

- No credit card, only GitHub account.
- GPT-4o, GPT-4.1 and others with tool support.
- One token one URL setup.

## Step 1 GitHub account

Sign up github.com, verify email.

## Step 2 Personal Access Token

Token API key.

1. github.com/settings/tokens.
2. Generate new token → classic.
3. Name "Theodia AI".
4. Select scopes models:read (only needed).
5. Generate token.
6. Copy immediately (once). Notes app paste safe.

## Step 3 Model choose

| Model | Daily Free Limit | Best For |
|---|---|---|
| openai/gpt-4.1-nano | 150/day | Quick simple explanations |
| openai/gpt-4.1-mini | 150/day | General study good tools |
| openai/gpt-4.1 | 50/day | Deeper multi-step |
| openai/gpt-4o | 50/day | Versatile tool support |

Start openai/gpt-4.1-mini (fast reliable higher daily limit).

## Step 4 Configure Theodia

1. Theodia open.
2. Settings → AI Assistant.
3. Remote model selected.
4. Provider dropdown GitHub Models (ya Custom base URL https://models.github.ai).
5. Paste token API Key.
6. Model field model ID.
7. Test connection.
8. ✓ Connection successful, ✓ Tools supported.

Tools not supported try different model ID.

## Step 5 Chat

AI tab or verse AI Commentary.

## Troubleshooting

### Connection failed/HTTP401
- Full token copied (starts ghp_).
- Token expired generate fresh.
- models:read selected.

### Tools not supported
- Try openai/gpt-4o or openai/gpt-4.1-mini.
- Model ID exact as page incl openai/ prefix.

### Rate limit
- Switch higher allowance model (nano 150/day).
- Resets 24h.

## Summary

- GitHub Models recommended to start.
- Free GitHub account + PAT models:read.
- Best starter openai/gpt-4.1-mini.
- Settings AI Assistant Test connection then chat.
