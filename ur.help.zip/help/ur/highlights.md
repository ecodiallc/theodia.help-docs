---
title: Verses highlight karna
level: everyday
categories: [annotate, read]
summary: Verses color mark karna aur baad me find.
---

# Verses highlight karna

> **Mode:** Highlights **Standard** aur **Scholar**. Focus Mode clean reading. Mode switch Settings → App User Mode.

Highlight verse color mark karta. Yellow highlighter jaisa on paper. Verse highlight state next open.

## Highlight kaise

1. Verse kholein.
2. Verse ٹیپ menu.
3. **Highlight** icon.
4. Color pick.

Highlighted.

## Change color

1. Verse kholein.
2. Verse → Highlight icon.
3. New color pick.

## Remove

1. Verse kholein.
2. Verse → Highlight.
3. Bottom **Remove Highlight** color picker.

## Colors system

Common usage:
- Yellow general favorites.
- Green God/about.
- Blue prayer.
- Pink comfort.
- Orange warning/correction.
- Purple prophecy/end times.

Apna choose.

## All highlights

Bottom **Highlights** tap. List newest first. Top color chips filter or All clear.

## Import highlights

Settings → Bookmarks → Import Highlights. File or clipboard.

Formats:
- Native JSON: url: color.
- CSV: url,color.
- Plain text: reference/URL optional color; no color yellow; # or // comments skip.

Colors: yellow green blue pink orange purple.

## Tips

- Device-only, no sync.
- Highlight verse one translation shows same verse in others.
- Backup see [Backing Up Your Data](theodia://help/backups).
