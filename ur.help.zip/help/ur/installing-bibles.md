---
title: Bible translations install karna
level: beginner
categories: start
summary: Bible translation library me kaise add karen.
---

# Bible translations install karna

Theodia few translations ready. More anytime. "Translation" Bible text ka different version.

## Add

Bible tab shows installed. More via resource manager:
1. Settings.
2. Manage Resources.
3. Install from GitHub.
4. Download modal **Bibles** tab.
5. Checkbox each translation.
6. **Install Selected**.
7. Download finish.

Translation library me. Bible tab see.

## Switch

1. Chapter open.
2. Top translation name tap.
3. List choose.
App saves choice.

## Remove

1. Settings.
2. Manage Resources.
3. Find translation.
4. **X** tap.
5. Confirm.
Notes/highlights/bookmarks safe.

## Space

2-10 MB each. Device storage. Keep as room.

## Not in app?

1. Settings → Manage Resources.
2. Install from GitHub.
3. Bibles and Global Bibles tabs.
4. Select + Install Selected.
5. Otherwise Import Local File `.bible`. GitHub project page see [Getting Extra Resources from GitHub](theodia://help/getting-core-files).
