---
title: Core files add karna
level: beginner
categories: start
summary: App depth study ke large data files download.
---

# Core files add karna

Theodia Bible + small extras ready. Most out of app ke liye **core files** download. Large data files study tools: commentary, word lookups, grammar. Without them app works but study limited.

## Why core files

- Word lookups: tap word original Hebrew/Greek and meaning.
- Commentary: verse AI Commentary.
- Grammar: original-language word info.
- Interlinear Bible: English under word.

Read without them can, but most study tools need.

## Install

**[Install Core Files](theodia://manage/core)**

1. Settings.
2. Manage Resources.
3. **Core** tab. Core files list name/size/checkbox.
4. Pick checkboxes.
5. **Install Selected**.
6. Download/install wait. Large minutes slow conn.

Device pe download once. Offline use.

## Tips

- Wi-Fi use (large).
- Plug device (battery).
- Download fail tap retry.
- All ya needed picks.

## Missing from list?

App GitHub list pull. Empty list: internet check retry. Still empty see [Where to Ask Questions](theodia://help/getting-more-help). Advanced adding see [Getting Extra Resources from GitHub](theodia://help/getting-core-files).
