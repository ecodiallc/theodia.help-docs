---
title: App language aur region
level: everyday
categories: settings
summary: App language kaise change karen.
---

# App language aur region

Theodia many languages. Menus/buttons language change. Help content built-in many languages; download/update language help pack: Settings → Help or Manage Resources → Install from GitHub → Help docs.

## Language settings open

1. Settings.
2. Language.

## Change language

1. Language list tap desired.
2. New language right away applies.

Choices supported languages depend.

## First install language chosen

Device settings based auto. Anytime change.

## Translated what

- Menus, buttons, labels.
- Settings screens.
- Error messages.
- Search/study tools.

## English only

Some book/devotional content.

## Bible vs app language

Different. App Spanish + Bible English possible. Bible translation change see [Installing Bible Translations](theodia://help/installing-bibles).

## Tips

- Empty button/label missing translation; English fallback usually.
- Help translate see [Where to Ask Questions](theodia://help/getting-more-help).
