---
title: Launcher menu
level: everyday
categories: layout
summary: Recent verses, commands, saved Bible layouts switch bina current screen chhoray.
---

# Launcher menu

> **Mode:** Launcher Menu **Scholar**. Mode switch Settings → App User Mode.

Fast-access panel almost anywhere. Recent verses, commands, saved setups one place.

## Open

Home screen header top-right expand icon (⌄). Panel top slides.

## Inside

### 1. Command Box

Top text box keyboard icon. Command type + keyboard Go. App straight there.

Examples:
- `John 3:16`
- `search love`
- `bookmark psalms 23`
- `kjv`

Full commands [Commands](theodia://help/commands).

### 2. Parallel Sets

Saved parallel Bible presets collapsible. Tap instantly load.

Preset create:
1. Settings → Parallel Bible.
2. Add translations Save Preset.
3. Name appears.
Long-press parallel set delete.

### 3. Bible Collections

One-tap shortcuts switch translation + parallel view. Created any collapse list. Long-press delete.

### 4. Feature Icons

Round emoji buttons major features. Available: About, Bibles, Bible Notes, Bookmarks, Books, Devotionals, Flashcards, Help, Highlights, Playlists, Plugins, Search, Settings, Theoscript.

Choose order:
1. Settings → Launcher Menu.
2. Launcher Menu Icons tap.
3. Switches show/hide.
4. Up/down arrows reorder enabled.

Settings order Launcher menu order.

### 5. Recent Verses

Last chapters/verses opened list bottom. Tap jump.
- Tap open.
- Swipe left or long-press remove.
- Clear all remove all.

## When use

- Jump back recent verse.
- Command type without home.
- Translation/parallel switch one tap.
- Major feature open anywhere.
- Fast check without navigating.

## Tips

- Available almost every screen including reading chapter.
- Same commands home command box.
- Feature icons/order local saved survive restart.
- Recent verses local saved survive restart.
