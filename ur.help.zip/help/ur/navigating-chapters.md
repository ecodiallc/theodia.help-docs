---
title: Books, chapters, verses ke beech navigate
level: everyday
categories: [layout, read]
summary: Bible me move kaise karen aur target tak jump.
---

# Navigating Between Books, Chapters, Verses

Bible move ways.

## Swipe easy

- Swipe **left** next chapter.
- Swipe **right** previous.
- Next book bhi: Exodus last ke baad Leviticus first.

## Menu way

- Translation name top tap switch Bible.
- Book name tap pick book.
- Chapter number tap pick chapter.

## Quick type

Home box top. Type `John 3:16` or `psalms 23`, tap keyboard Go. App verse opens.

## Bookmark

Saved verse Bookmarks tab tap → verse.

## Search

Search tab word type, occurrences, tap result open.

## History

App remembers opened chapters. Bookmarks tab saved and Bible tab book list recent.

## Tips

- Bible tab Genesis to Revelation.
- Psalms/Proverbs long books tap and chapter list jump.
