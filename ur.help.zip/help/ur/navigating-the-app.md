---
title: App layout aur navigation
level: beginner
categories: layout
summary: Home screen, main menu, bottom toolbar tour — kahan kya hai.
---

# App layout aur navigation

Theodia three main areas: home screen, main menu, bottom toolbar. Tour to locate everything.

## Quick map

- Home screen: first open page; search box, big buttons, installed Bibles/books/devotionals.
- Bottom toolbar/tab bar: bottom icons; jump straight.
- Main menu ☰ top-right home: all screens including tabs na.

## Home screen

Four parts top-bottom:

### Header
Top colored bar: left app icon/name Theodia; right main menu ☰. Inside book/chapter left back ← instead. Tap menu open.

### Command
Below header search-style box. Type short instruction + keyboard Go. Examples:
- `psalms 23`
- `john 3:16`
- `search love`
- `bookmark john 3:16`
- `commentary romans 8:28`
- `xref ref`
- `help`
Unknown shows alert hint. Common problems help.

### Button grid
Large buttons two per row:
- 📖 Bibles
- 🔍 Search
- 📚 Books
- 📅 Devotionals
- 🔖 Bookmarks
- 🖍 Highlights
- 📝 Notes
- ⚙️ Settings
- ❓ Help
- ℹ️ About

### Resource lists
Expandable Bibles, Books, Devotionals. Tap header expand/collapse; tap item open. Bibles section fastest.

## Bottom toolbar

Bottom row icons stays almost everywhere. Tabs by user mode.

All modes:
- 🏠 Home
- 📖 Bibles
- 📚 Books
- 🔍 Search
- ⚙️ Settings

Standard/Scholar:
- 🔖 Bookmarks
- 🖍 Highlights
- 📝 Notes

Scholar:
- 💻 AI (if turned on)

Current highlighted. Tap other switch.

### Behavior

Each tab own stack. Tap returns where left off, not start. Example Bibles list → translation → book → chapter; switch Bookmarks; Bibles tab back same chapter.

### Reset

Tab root only:
- Already on tab tap same icon.
- App force-close/reopen.

### Bottom tabs vs main menu

Tabs preserve stack. Main menu same navigation, not overlay. Use tabs switch tasks; menu full list.

### When use

Switch tasks with tabs.

## Main menu

☰ top-right home. Panel slides right all mode-supported screens:
- 🏠 Home
- 📖 Bibles
- 📚 Books
- 🙏 Devotionals
- 🔍 Search
- 🔖 Bookmarks (Standard/Scholar)
- 🖍 Highlights
- 📝 Notes
- 💻 AI (Scholar, if enabled)
- ⚙️ Settings
- ❓ Help
- ℹ️ About

Current screen highlighted dot. Outside/X/back close. Navigates same as tabs, stack preserved return same tab.

### Different

Dropdown panel same navigation. Notes highlights help no toolbar own can quick access.

## Scholar mode

Extra tabs/menu/tools; see [Scholar Mode](theodia://help/scholar-mode).

## Fit together

- switch main section → toolbar
- jump verse/command → Home Command
- browse all screens → button grid
- notes/highlights/help without lose place → main menu
- settings anywhere → menu/toolbar

### Example

Reading Romans 8 highlight verse:
- Toolbar: tap verse menu → Highlight color; done.
- Main menu review highlights: ☰ Highlights opens; Bibles tab back Romans.
- Toolbar switch tasks: Home/Bookmarks, then Bibles returns chapter.

## Tips

- Home remembers expanded/collapsed.
- Missing tab check user mode and feature settings.
