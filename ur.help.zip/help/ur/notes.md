---
title: Notes likhna
level: everyday
categories: [annotate, read]
summary: Verses ke paas apne thoughts write karna.
---

# Notes likhna

> **Mode:** Notes **Standard** and **Scholar**. Focus Mode clean reading. Mode switch Settings → App User Mode.

Notes verses next your thoughts, prayers, study ideas. Each note a specific verse tied.

## Note add

1. Open verse.
2. Tap verse menu.
3. Menu **Note** tap (pencil icon).
4. Type note.
5. **Save** tap.

Note verse ke sath save.

## Read note

1. Open verse.
2. Pencil mark verse side means note.
3. Tap verse. Note below appears.

## Edit

1. Open verse with note.
2. Tap verse.
3. Menu **Note** tap.
4. Changes.
5. **Save** tap.

## Delete

1. Open verse with note.
2. Tap verse.
3. Menu **Note** tap.
4. **Delete** tap.

## All notes see

Bottom **Notes** tap. List sorted date.

## Search

Notes tab **Search** box tap. Word type. App finds notes containing word.

## Tips

- Notes sermons/devotions/study questions.
- Notes private device.
- Backup see [Backing Up Your Data](theodia://help/backups).
