---
title: Notifications aur reminders
level: everyday
categories: [settings]
summary: Prayer, devotionals, Bible plans wale offline reminders turn/customize/manage.
---

# Notifications aur reminders

Theodia prayer, devotionals, Bible plans, flashcards, other activities remind — even app offline. All device scheduler; internet/push server nahi.

## Turn on/off

1. Settings.
2. Notifications.
3. Enable reminders on/off.

First enable permission popup Allow.

If denied, device Settings → Theodia notifications enable.

## Reminder types

Notifications screen channels, each family:
- Prayer reminders
- Prayer routine
- Devotional
- Bible plan
- Theoscript
- AI insight
- Flashcard review
- Reading habit
- Liturgical & seasonal
- My reminders (from bookmarks, highlights, playlists, Bible chapters/books)
- Custom reminders

Channel tap reminders see/time/days/off.

## Custom reminders

1. Settings → Notifications → Custom reminders.
2. + button.
3. Title and Message.
4. Time choose.
5. Repeat days.
6. Optional open screen when tapped.
7. Save.

Edit/delete tap list.

## Tapped behavior

Reminder opens specific app screen. No linked screen opens Home.

## Quiet hours

Silence sounds while visual reminders.
1. Settings → Notifications → Quiet hours.
2. Start/End set.
During quiet hours on-screen without sound.

## Upcoming/history

Upcoming reminders scheduled next. Notification history delivered/scheduled/cancelled. Confirm or investigate.

## Not appearing

- Enable reminders on.
- Device notifications allowed.
- Channel enabled and at least day selected.
- Quiet hours silent.
- Android battery optimization; allow Theodia.
- Tied content removed (deleted plan/routine) maybe no fire until valid target reselect.

## Sounds

Supporting reminders choose sound. Inside reminder/channel Sound tap options. Bundled offline. Preview button hear before save.

## Badges

Some reminders app icon badge. Clear badge button reset.
