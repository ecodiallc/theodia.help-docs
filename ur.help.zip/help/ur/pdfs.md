---
title: PDFs
level: everyday
categories: [read, resources]
summary: PDF documents app me import, organize aur read karna.
---

# PDFs

> **Mode:** PDFs **Standard** aur **Scholar**. Focus Mode clean reading. Mode switch Settings → App User Mode.

Theodia PDF store/read. Imported offline.

## PDF library open

Bottom **PDFs** tab ya Home PDFs tile.

## Import

1. PDFs tab.
2. Bottom +.
3. Device PDF choose.
4 (optional) category choose.

## Organize

Long-press PDF card menu:
- Rename
- Change category
- Delete (reading position too)

Categories free-form; new/existing when import/change.

## Read

Tap card reader. Top title bar. Page buttons: First, Previous, current (`3 / 120`), Next, Last. Toolbar: Contents, Zoom out, Zoom in, Reset zoom, Bookmark, Search, Listen, Text view. Some dimmed unavailable until searchable text installed.

### Turn pages

- Left/right chevron one page.
- First/Last jump ends.
- Page number grid (near current) then choose.
- External keyboard arrows.

### Zoom

- Zoom in/out.
- Reset zoom normal.
- Zoom turn page then zoom out returns same page.

## Search

1. PDF open Search toolbar.
2. Type; results as you type with page number/snippet.
3. Tap result jump page.
Needs searchable text. Dimmed if not. Community GitHub PDFs include; imported don't until added.

## Contents

PDF built-in TOC, Contents button outline. Section titles jump. Expand/collapse. No TOC dim.

## Bookmarks

1. PDF open Bookmark toolbar.
2. Bookmark page saves current page; name default page number type custom Save.
3. Tap bookmark jumps page.
4. × deletes.
Separate Bible bookmarks; each PDF own list.

## Read aloud

Searchable text installed:
1. Listen speaker button.
2. Control bar Play/Pause, Rewind, Fast forward, Stop, progress tap skip, speed, voice.
3. Page finish auto next.

Voice/speed Bible reading ke like see [Reading Out Loud](theodia://help/tts).

## Text view copy/share

Text view current page plain text:
- Copy clipboard
- Share
- Add to study notes opens note editor filled page text/citation/link.

## Resume

Remembers last page, next open there.

## Download PDFs from GitHub

Scholar mode bottom **Download from GitHub** button connects community PDF repo; install packaged PDFs like others.

## Notes

- Theodia private documents folder. Backups not include; new device re-import.
