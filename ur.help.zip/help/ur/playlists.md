---
title: Playlists
level: everyday
categories: playlists
summary: Bible passages, plain text, koi verse sunne ke playlists create/listen.
---

# Playlists

**Playlist** list of tracks Theodia out loud read. Track Bible passage ya plain text note. Hands-free listening commute/walk/devotion/memorization.

Playlists appear when at least one playlist created/populated.

## Where

Playlists available:
- Home screen: Plugins & More → Playlists.
- Main menu: ☰ → Playlists.
If no playlist, tile/menu hidden.

## Contents

Playlist:
- Name (Morning Verses)
- Optional category.
- Tracks.

Track:
- Content (passage reference/plain text)
- Label (on-screen)
- Optional voice.

## Create

1. Playlists open.
2. Create playlist/+.
3. Name.
4. Optional category select/create.
5. Tracks add.

### Track from Bible passage

1. Add track.
2. Content type Bible passage.
3. Reference `John 3:16`/`Psalm 23:1-6`.
4. Label optional (else reference).
5. Save.

### Plain text track

1. Add track.
2. Plain text.
3. Type text.
4. Label.
5. Save.

### Batch add

1. Open playlist.
2. Menu Batch add.
3. Paste one ref/text per line.
4. Detect Bible references if mostly refs.
5. Add. Each line track.

## Listen

1. Playlist open.
2. Top/track Play.
3. Reads order.

Control bar:
- Play/Pause
- Next
- Previous
- Stop

Set:
- Speed
- Repeat all/track/once
- Shuffle
- Ignore parenthetical
- Pause between tracks
- Sleep timer

## Edit

Pause playback first.

- Rename
- Reorder tracks drag
- Edit track
- Delete track
- Delete playlist (undo nahi)

## Export/import

JSON all tracks/categories/settings share/backup/edit.
- Export all → playlists-YYYY-MM-DD.json
- Export category → JSON
- Import playlists restore from JSON.

Quick create JSON example (save and import).

## Tips

- Short focused verses best.
- Categories separate devotional/memorization.
- Sleep timer bedtime.
- Wrong voice check language matches text.
- TTS reads text exactly; spelling check.
