---
title: Prayer overview
level: beginner
categories: prayer
summary: Prayer tab aur uske main sections ka quick introduction.
---

# Prayer overview

Prayer tab dedicated prayer space. Lists, guided sessions, journal, timer, lectionary reading schedules, classic fixed prayers.

## Main sections

- Prayer List — people, situations, topics you pray for.
- Journal — reflections, answers, thoughts over time.
- Generate Prayer — Theophilus writes prayer from request/journal.
- Creeds & Fixed Prayers — classic prayers/creeds Christian tradition.
- Lectionary — scripture reading schedules daily/seasonal prayer.
- Guided Prayer — audio-guided sessions TTS.
- Timer — timed prayer optional bells.
