---
title: Built-in books reading
level: beginner
categories: [content, read]
summary: App ke Christian classics padhna.
---

# Reading Built-in Books

Theodia small library Christian classics. Device read.

## Library open

Bottom **Books** tab. Installed list.

## Read

1. Book title tap.
2. Opens first chapter.
3. Top **Previous/Next** move.

## Jump chapter

Top chapter name tap list choose.

## Font size

Settings → Appearance pick. Whole app books included.

## Bookmark

Top right star. Current chapter saved. Bookmarks tab saved pages.

## Listen

Top right Speaker. Read aloud chapter. Again stop.

## Available

Classics like Pilgrim's Progress, Imitation of Christ, Practice of Presence, Hymn Book. Updates may add.

## Tips

- Device stored no net.
- No cloud sync.
