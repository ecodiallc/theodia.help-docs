---
title: Finding resources on GitHub
level: everyday
categories: resources
summary: App known GitHub repos across search then install.
---

# Finding resources on GitHub

Theodia GitHub repos publish resources (Bibles, commentaries, books, devotionals, playlists, prayer packages, more). **Search GitHub Repos** all once, no browsing tabs separately.

> GitHub section Settings only **Scholar mode**. Enable Settings → User Mode → Scholar.

## Search

1. Settings.
2. Search GitHub Repos.
3. Type word. App searches name/description every package every repo.

Know:
- Every word match: `morning evening` package contains both.
- Case not matter.
- Best match first: name starts with search before description mention.

## Filtering

Filter bar narrow:
- Author — only that author packages.
- Tradition — only that tradition.
Both combine. Tap clear or Clear filters.

## Install from result

Each result name/type/author/repo. Right button:
- Install — not on device.
- Update — newer available; confirm, removes old copy plus notes/highlights/bookmarks referencing.
- Open — installed, goes use screen.

Top Refresh latest immediately. Auto refresh daily, manual when new published.

## Offline search

Cached copy local, works no connection. Can't reach GitHub banner cached results.

## Nothing found

- Shorter single word.
- Check Author/Tradition filter clear.
- Some repos publish packages another language than name; translated search may not find.
