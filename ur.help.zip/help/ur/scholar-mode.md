---
title: Scholar mode
level: advanced
categories: [layout, read, study]
summary: Deepest study mode, unlocking commentaries, lexicons, cross-references, AI tools, Launcher Menu.
---

# Scholar mode

> **Mode:** Scholar mode available only when user mode **Scholar**. Switch Settings → App User Mode.

Scholar unlocks every study tool. Study Mode pe based, so verse menu, parallel Bibles, bookmarks/highlights/notes plus advanced lists.

## Open

1. Settings.
2. App User Mode.
3. Scholar.

Immediate effect. Hidden menus/buttons appear.

## Extra reader tools

Study Mode chapter verse menu adds (Scholar):
- **AI Commentary** (◈) — verse study note AI (not all regions).
- **Word Info** (?) — original Hebrew/Greek lexicon entry. See commentaries/lexicons.
- **Dictionary** (📖) — general Bible words in installed dictionary. See Bible Dictionary.

Needs resources. Greyed/not found => Settings → Manage Resources add needed.

## Extra navigation

- Bottom toolbar extra tab: 💻 AI (if AI on) after Notes.
- Main menu includes **AI Assistant** under same conditions.

## Launcher Menu

Scholar enables Launcher Menu fast jump/command/Bible layouts. See [Launcher Menu](theodia://help/launcher-menu).

## When use

- AI, commentaries, original-language lookups wanted.
- Launcher Menu fast navigation/AI chat.
- In-depth passage.
## Lighter mode

Standard in Settings → App User Mode: keeps bookmarks/highlights/notes/Study but hides AI/commentaries/lexicons/Launcher. Focus Mode clean reading.

Data never deleted switching modes; hidden until supporting mode.

## Help

Missing/error see [Common Problems](theodia://help/common-problems). New see [Reading Your First Chapter](theodia://help/first-read).
