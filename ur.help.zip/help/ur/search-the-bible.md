---
title: Bible search karna
level: everyday
categories: [study, read]
summary: Word, phrase ya reference se verses find.
---

# Bible search karna

Search bar verses fast. Word, phrase, Bible reference.

## Start

1. Bottom Search tab.
2. Type.
3. Keyboard Search tap.

Results list: book/chapter/verse + text.

## Word combinations

More than one word (`love joy`) => verses contain **both** (AND). Not OR. Either word need type OR keyword explicitly: `love OR joy`.

## Single word

Type single word, app every verse with word.

## Phrase

Two/three words quotes exact phrase: `"do not be afraid"`.

## Filter

Results filter installed translations. Narrow Bible specific translation.

## Tips

- Short words more results. `love` > `loving`.
- Quotes exact.
- Only installed translations searched.
- Specific verse reference in home Command instead Search tab.

## History

Recent searches top. Tap rerun. Clear all top clear.

## Search PDFs

Search tab PDFs mode:
1. Search tab → PDFs mode top.
2. Pick PDFs to search; tap include/exclude; All/Clear. Searchable text installed only.
3. Type Search.

Result PDF title, page number, snippet. Tap open PDF at page.

Single PDF reading Search button in reader see [PDFs](theodia://help/pdfs).
