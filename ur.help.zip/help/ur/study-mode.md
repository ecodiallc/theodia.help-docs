---
title: Study mode
level: everyday
categories: [layout, read]
summary: Theodia ka full Bible reader commentary, crossrefs, lexicon, notes packed.
---

# Study mode

> **Mode:** Study Mode available in **Standard** and **Scholar**. Reader mode opens Focus instead. Mode switch Settings → App User Mode.

Study Mode main Bible reader. All study tools built in: commentary, crossrefs, word lookups, parallel, notes.

Focus simpler no tools see [Focus Mode](theodia://help/focus-mode).

## Open

- Bottom Bible tab; translation/book/chapter choose.
- Tap Search results verse.
- Bookmarks tab bookmark.
- Focus Mode top 📖 switch to Study.

## Read

Verses order. Top buttons, bottom status bar.
- Swipe left next chapter, right previous.
- Tap verse menu.
- Tap Strong's number (G/H) quick lexicon lookup.

Parallel translation on, second copy below.

## Verse menu

Tap verse title "Book Chapter:Verse". Tools by mode.

### Standard and Scholar

- **Bookmark** (★) save/remove. First tap adds.
- **Highlight** (□), color picker, same color remove.
- **Speak** (🔊), TTS read; interlinear nahi. See [Reading Out Loud](theodia://help/tts).
- **Copy** (⎘), clipboard.
- **Compare** (⇄), verse every translation panel; tap read that.
- **Cross-References** (↗), related verses.
- **Add/Edit Bible Note** (✎), private note verse.

### Scholar only

- **AI Commentary** (◈), study note AI (not all regions).
- **Word Info** (?), original Hebrew/Greek lexicon.
- **Dictionary** (📖), general Bible words installed dictionaries.

Needs resources; greyed/not found => Settings → Manage Resources.

## Top buttons

Above chapter:
- Bible version translation switch
- Book jump
- Chapter jump
- Open in AI (🤖) current chapter AI (Scholar)
- Focus Mode (📖)
- Parallel Bibles (🔵/⚪) on/off; parallel disable. See parallel
- Listen read aloud
- More extra chapter actions (chapter note, commentary, share)

## Parallel view

Until four extra translations. 
1. Settings.
2. Parallel Bible on.
3. Add Parallel Bible pick.
4. Repeat up to four.
Each verse main + parallels. Easy compare without leaving chapter.
Save preset: save button selected translations name; quick switch. Long-press delete.

Compare single verse Compare (⇄) tool.

## Subheadings

Some translations section headings. Settings **Show Subheadings** show/hide grey titles.

## Chapter note

One note whole chapter.
1. More tap.
2. Chapter Note.
3. Write Save.
Saved chapter, shows every open.

## Search highlights

From search, search words yellow in verse. Re-run search via Search tab tap back chapter with matches highlighted.

Interlinear (MIB/OHGB) always Study needs word-level layout.

## Switch Focus per chapter
Study tap top 📖; same chapter Focus menus hidden. Bottom bar 📖 switch back.

## When use

- Read and study simultaneously.
- Word lookup Strong's tap.
- Compare translations verse tool or parallel.
- Verse connections Crossrefs.
- Notes while reading.

Long distraction-free Focus.

## Switch Focus
Study top 📖→[Focus Mode](theodia://help/focus-mode) with menus hidden. Bottom 📖 switch back. Full see Focus guide.

## Help
Missing/error see [Common Problems](theodia://help/common-problems). New see [Reading Your First Chapter](theodia://help/first-read).
