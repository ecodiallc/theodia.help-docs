---
title: Tablet features
level: everyday
categories: [layout, tablet]
summary: Theodia layout adapts tablets, split views, side panels, two-pane reading.
---

# Tablet features

Theodia designed for larger screens tablets. Tablet (or >700 px) app many places two-column.

> **Mode:** Features appear only if mode supports. Commentary side panels/AI chat Scholar; bookmarks/highlights/notes split views Standard/Scholar; Focus clean single-column. Mode switch Settings → App User Mode.

## Reader verse menu

Tap verse number/long-press verse text → **verse menu** centered card over dark backdrop.
- Copy and Share top always.
- Bookmarks/Highlights current state.
- Commentary/Dictionary/Compare open; on tablet side panel/wide card once selected.
- Backdrop or close arrow dismiss.

## Verse commentary panel

Commentary opens **dedicated side panel** tablet:
- Beside Bible text.
- Scroll independently.
- X or swipe close.
- Book icon switch commentary sources.
- Chapter icon chapter-level commentary.
Phone full-screen modal.

## Chapter commentary

More top button; tablet side panel like verse commentary, read together.

## Compare tab

Compare verse menu opens side panel tablet showing selected verse every parallel version. Tap any version jumps passage. Phone each after another.

## Dictionary / Strong's popup

Dictionary verse menu → Dictionary opens wide card tablet Greek/Hebrew, transliteration, definition, Strong's. Concordance all occurrences.

Tap word open lexicon

In Word Info side panel tablet each card Strong's tappable; tap opens Lexicon panel for word directly; Lexicon replaces Word Info. Phone not tappable (screen small).

## Parallel side by side

Settings parallel up to three. Tablet versions **vertical panes**:
- Each scrolls independently.
- Verse number tap side tools.
- Compare tab all selected verses one place.
- X close pane returns single-column.
- Parallel icon top bar toggle without settings.
Phone versions shown vertical sequentially; same toggle.

## Bookmarks/highlights split

Tablet tab master-detail:
- Left list.
- Right preview tapping item.
Skim without leave. Phone navigate reader.

## Notes split

Notes list left, selected note right; creating/editing side panel.

## Search split

Tablet Search form left, results right as search run. Phone separate results.

## Settings category sidebar

Tablet settings categories left (AI, Appearance, Backup, Bibles etc), tap jumps right selected; only expanded.

## Bible nav

Bible List/Books/Chapters single-column tablets but larger touch targets, wider grids, padding. Not split because full width needed.

## Landscape/portrait

Rotating auto. Landscape side panels room; portrait narrower beside text.

## Selected verse AI chat

AI chat verse menu side panel, conversation interface, no leaving reader.

## AI conversation sidebar

AI tab tablet conversation list always persistent left; switch chats without menu, New Chat always. Phone popup drawer.

## Stays same

Screens remain single-column:
- Bible List full width
- Bible Books grid
- Bible Chapters grid
- PDFs wider card grid
- Settings individual pages
- Help

## Summary

Tablet:
- parallel side-by-side vertical panes
- commentary persistent side panels
- Compare/Dictionary wide cards
- Lexicon from Word Info tap
- Bookmarks/Highlights/Notes/Devotionals/Books/Settings master-detail split views
- Search inline results
- landscape/portrait
Phone traditional single-column drill navigation. Screen width detect choose layout.
