---
title: Themes aur fonts change
level: everyday
categories: settings
summary: App look kaise change karen.
---

# Themes aur fonts

App look change: theme light/dark and font size.

## Appearance settings open

1. Settings.
2. Appearance.

## Theme

Two theme buttons:
- Default — light background dark text, daytime.
- Dark — dark background light text, nighttime and battery.

Tap applies instant.

## Font size

Appearance size buttons: ---, --, -, Normal, +, ++, ++++. Text size all app. Readable size choose.

## Tips

- Dark battery OLED saves.
- Text too small, app setting finer than device.
- Long reading dark + larger.
- [Activate desert theme](theodia://unlock-desert)
