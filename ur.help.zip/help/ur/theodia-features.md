---
title: Theodia features
level: beginner
categories: welcome
summary: Theodia ko special banane aur Bible study help quick overview.
---

# Theodia features

Theodia complete Bible study companion. Stand out.

## Offline first

Everything without internet. Bibles, commentaries, lexicons, books, devotionals device. Read/search/study anywhere.

## Privacy focused

Data yours. Notes/highlights/bookmarks/history local. No account; optional AI except nothing server unless AI.

## Tablet support

Phones/tablets designed. Larger screen space, parallel views, layout uses extra.

## Installable resources

Not limited built-in. Add translations, commentaries, lexicons, books, devotionals from project GitHub install.

## AI assistant

Optional AI understand verses, context, questions. Only if turn on. Remote model endpoint/API key you configure; permission first use shows sent.

## Parallel Bible reading

Up to four versions at once. Main plus parallels same verses. Wording compare, study differences. Save presets quick switch.

## Full-text search

Any Bible version. Words/phrases/partial matches, limit books range.

## Cross-references

Tap reference jump passage. Built-in across Bible.

## Lexicon and Strong's

Strong's tap original Greek/Hebrew definition. Lexicon entries deeper.

## Bookmarks/highlights

Verses save and color mark. Local/persist sessions.

## Notes

Own thoughts verse next. Tied verse.

## Daily devotional

Start day short devotional. Opens today automatically.

## Christian books

Classic Christian literature app. Formatted reading with TOC.

## PDF reading

Import own PDFs, offline, categories. Reader search/TOC/bookmarks/zoom/read aloud. Packaged PDFs community repo install.

## Multiple languages

Interface and Bible content many. Switch settings.

## Dark mode/themes

Light/dark or themes. Low light comfort.

## Data backup

Notes/bookmarks/highlights backup. Safe and move device.

## No ads distractions

Focus, no ads/popups/interruptions. Only text and study tools.
