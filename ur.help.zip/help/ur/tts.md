---
title: Reading out loud (Text-to-Speech)
level: everyday
categories: tts
summary: Theodia verse/devotional aloud read, voice choose, silent ho to fix.
---

# Reading out loud (Text-to-Speech)

> **Mode:** TTS **Standard** and **Scholar**. Focus clean reading. Mode switch Settings → App User Mode.

Device TTS voice use Theodia text aloud. Single verse, whole chapter, or devotional. Hands-free/commute/walk/eyes rest.

## Listen button where

Three places.

### 1. Verse menu (single verse)

Fast one verse. Study chapter open, verse tap menu, **Speak** (🔊). Starts that verse. Small control bar bottom play/pause/rewind/ff/voice picker.

Speak option interlinear (MIB/OHGB) hidden because layout reads naturally not.

### 2. Chapter top (whole chapter)

Reading chapter top icons row; **Listen** (🔊), whole chapter start. While audio playing stop (⏹). Same control bar bottom.

Jump a verse; Listen button there starts that verse.

### 3. Devotional

Open devotional day, top **Listen** (🔊). Full devotional sentence by sentence. Control bar bottom play/pause/rewind/voice.

## Control bar

While playing bar:
- ⏪ Rewind one verse/sentence
- ⏸ Pause / ▶ Resume same spot continue
- ⏩ Fast forward next verse/sentence
- 🎙 Voice picker without leave
- ⚙ Options extended (current chapter reset on chapter switch/stop)
- Stop 🔊 top becomes ⏹ stop close bar.

Finishes or stop closes.

### Extended options

⚙:
- ⏮ Back to begin range first verse
- Begin type verse where start
- End type verse where stop
- All reset full chapter
- () toggle parenthetical read
- 🔁 Repeat auto restart range end with short pause; turned without begin/end full chapter repeats.

### Prayer screens

Creeds/fixed prayers, generated prayers, routines have own options. ⚙ expand:
- Speed tap rate 0.1x-1.5x; remembered next read.
- () parenthetical toggle.
- 🔁 Repeat restart from beginning with short pause; learning by heart useful.

Speed immediate effect. Parenthood toggle starts over from beginning so change heard.

## Voice change

Settings → Speech → Select Voice. List voices; System Default device preferred. Saved next Listen/Speak.

Also 🎙 control bar.

Availability device. iOS/Android built-in; settings download more. Any installed voice Theodia.

## Favorite voices

Many device voices. Favorite short list.
1. Settings → Speech → Favorite Voices (first row).
2. Set Favorite Voices.
3. Tap play preview; star favorite any count.
4. back. Pickers show only favorites.
Remove all → all voices. Included backup/restore.

## Per Bible voice

Each translation own voice. Useful formal KJV and conversational NIV/NLT, different language accent.
1. Settings → Speech → Bible Voices.
2. Tap Bible.
3. Pick voice; System Default uses main TTS.
4. Repeat. Header counts custom. Select Voice/Commentary Voice/Bible Notes Voice/Devotional Voice count when set.

Next listen chapter uses chosen; others default unless changed.

## Background continue

Default stops if leave reader/switch app/lock phone. Prevent unexpected audio.

Allow:
1. Settings.
2. Speech.
3. Continue speech in background on.

Speech stays tab switch/app/lock, control bar active pause/skip notification area.

Toggle off while playing stops immediately.

## Not working

Device dependent. Theodia text OS; OS reads chosen voice.

### TTS not available

No TTS some devices. Settings → TTS section absent => not supported.

### Empty voice list

Picker no voices. Device still loading.
1. Settings → Speech → Select Voice.
2. empty look for Retest below dropdown tap. Re-query device.
3. still empty check device settings. iOS Settings → Accessibility → Spoken Content → Voices download. Android Settings → Language & Input → Text-to-Speech Output → Install voice data.
4. close/reopen Theodia.
If favorites set and empty, ensure favorites match installed.

### Tap Speak nothing

- Not silent mode.
- Volume up.
- Retest Settings → Speech.
- Settings System bottom; TTS row Available. Unavailable enable OS then reopen.

### Wrong language audio

Current content language; selected voice mismatch maybe odd.
1. Settings → Speech → Select Voice.
2. System Default or language matching voice.

Theodia does not read Greek/Hebrew interlinear aloud; buttons hidden.

### Audio stops early

Missing/unreadable verse skips. Bar closes after few verses? Listen (🔊) top start over.

### Playing but unknown start

Background on, later audio no screen, stop anywhere:
1. Settings.
2. Speech.
3. red Stop Speech.

Stops all running TTS. App switcher swipe Theodia away force stop audio.

### Too fast/slow

Theodia doesn't control speed. Chosen voice speed:
- iOS Settings → Accessibility → Spoken Content → Speaking Rate.
- Android Settings → Language & Input → Text-to-Speech Output → Speech Rate.

## Tips

- Control bar visible across chapters; pause/skip/change voice without losing place.
- Verse numbers pauses. Stop bar, swipe different verse, play continue.
- Long listen Do Not Disturb avoid interruptions.
- 🔊 uses device volume; headphones switches.

## PDF read aloud

PDF pages read aloud. Open PDF Listen speaker toolbar. Control bar play/pause/rewind/ff/stop/progress/speed/voice. Page finish auto next.

PDF searchable text + same voices/speed.

## Related guides

- [Study Mode](theodia://help/study-mode)
- [Focus Mode](theodia://help/focus-mode)
- [Common Problems](theodia://help/common-problems)
- [Daily Devotionals](theodia://help/daily-devotionals)
- [PDFs](theodia://help/pdfs)