---
title: Welcome to Theodia
level: beginner
categories: welcome
summary: App short tour aur kya kar sakta.
---

# Welcome to Theodia

Theodia Bible study app. Phone/tablet, no internet bhi. Read/search/study everything device.

## What you can do

Three user modes. Each different features.

- Reader — clean distraction-free Bible.
- Standard — Reader plus bookmarks/highlights/notes/TTS/search/daily devotionals.
- Scholar — Standard plus commentaries/lexicons/Bible Dictionary/AI more.

Mode anytime Settings → App User Mode.

### Available always

- Read Bible. Many translations, switch.
- Search Bible. word/phrase; all matching verses.
- Read books and devotionals. Christian classics and daily devotional.

Depending mode:
- Listen verses read aloud. Standard/Scholar.
- Notes own thoughts verse. Standard/Scholar.
- Highlight favorite verses color. Standard/Scholar.
- Bookmark verses fast. Standard/Scholar.
- AI assistant verse help. Scholar only.

## Where start

1. Bottom Bible tab open.
2. Pick translation.
3. Tap book read.

More help guides pick topic.

## Know

- No account.
- Notes/highlights/bookmarks device.
- Backup see [Backing Up Your Data](theodia://help/backups).

## More resources?

Comes few free Bible versions. Extra Bibles/commentaries/lexicons/books/devotionals see [Getting Extra Resources from GitHub](theodia://help/getting-core-files), find/add from GitHub page.

Welcome. Hope helps read/study.
