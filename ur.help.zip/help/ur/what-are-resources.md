---
title: Resources kya hain?
level: beginner
categories: resources
summary: Theodia different files types overview Bibles, commentaries, books more.
---

# What are resources?

Theodia me "resource" jo file reading/study material app me add. App itself reader+notebook. Bibles/commentaries/books/materials separate files.

## Why matter?

First open few reading items. Explore install buttons. Knowing types helps decide add.

## Kinds

Extension recognizes. Each different type.

### `.bible` — Bible translation

Full Bible particular version (KJV). Comes few, add more.

See [Installing Bible Translations](theodia://help/installing-bibles).

### `.commentary` — commentary

Scholar notes. Given verse background/meaning/fit Bible.

See [Commentaries and Lexicons](theodia://help/commentaries-and-lexicons).

### `.lexicon` — lexicon

Bible words dictionary. Original Hebrew/Greek, meaning, usage.

See same guide.

### `.book` — Christian book

Longer Christian work classic. Reading like Bible; TOC. Built-in classics.

See [Reading Built-in Books](theodia://help/reading-books).

### `.devotional` — devotional

Short daily reading. Verse/reflection/prayer/question. One per day year often.

See [Daily Devotionals](theodia://help/daily-devotionals).

### `.sqlite` — reference database

Large lookup file. Two:
- Cross-references: connected verses.
- Morphology: original Hebrew/Greek word info.

Not open directly; background adds reader features. See [Cross-References](theodia://help/cross-references).

### `.data` — word data

Extra original Bible word info; lexicon/study tools. Background use.

## Add resource

Manage Resources:
1. Settings.
2. Manage Resources.
3. Install from GitHub.
4. Download modal tab (Bibles/Commentaries/Books/Devotionals/Core) select + Install Selected.
5. Or Install Local File downloaded file.

Step-by-step GitHub see [Getting Extra Resources from GitHub](theodia://help/getting-core-files).

## Remove

1. Settings.
2. Manage Resources.
3. Find resource trash icon.
4. Confirm.
Notes/highlights/bookmarks safe.

## Where live

Device, not cloud. Installed no internet needed. Backup device but resources not cloud backed up by Theodia. Uninstall/reinstall need re-add.

## Help

Trouble see [Where to Ask Questions](theodia://help/getting-more-help). Team/community.