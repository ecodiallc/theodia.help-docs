---
title: Kiến thức cơ bản về AI
level: advanced
categories: ai
summary: Cách dùng trợ lý AI để hiểu các câu Kinh Thánh.
---

# Kiến thức cơ bản về AI

> **Chế độ:** Trợ lý AI yêu cầu chế độ **Học giả**. Bạn có thể đổi chế độ trong **Cài đặt** → **Chế độ người dùng ứng dụng**.

Theodia có một trợ lý AI. Nó có thể giúp bạn hiểu một câu Kinh Thánh, trả lời câu hỏi, hoặc trò chuyện về một chủ đề Kinh Thánh.

## Cách bật AI

AI mặc định đang tắt. Để bật:

1. Mở **Cài đặt**.
2. Nhấn **Trợ lý AI**.
3. Nhấn công tắc để bật.

## Cách mở AI

Nhấn thẻ **AI** ở cuối màn hình. Một cửa sổ trò chuyện sẽ mở ra.

## Cách đặt câu hỏi

Nhấn vào ô ở dưới cùng. Gõ câu hỏi của bạn. Nhấn **Gửi**.

Một số điều bạn có thể hỏi:

- "Giăng 3:16 có nghĩa là gì?"
- "Hãy cho tôi biết về sách Rô-ma."
- "Quả của Thần là gì?"
- "So sánh Bài giảng trên núi trong Ma-thi-ơ và Lu-ca."

## Cách hỏi về một câu cụ thể

1. Mở một chương.
2. Nhấn một câu để hiện menu câu.
3. Nhấn **Bình giải bằng AI**.

Câu đó được gửi tới AI. Bảng AI mở ra với câu đã có sẵn. Bạn có thể thêm câu hỏi, như "Điều này nghĩa là gì?" hoặc "Tôi nên áp dụng điều này thế nào?"

## Những điều quan trọng cần biết

- AI là một công cụ, không phải một con người. Nó có thể mắc lỗi.
- Luôn đối chiếu câu trả lời của AI với chính Kinh Thánh.
- AI có thể cần internet. Nó không hoạt động ngoại tuyến.
- Khi bạn dùng AI, các câu hỏi, ngữ cảnh câu Kinh Thánh và khóa API của bạn được gửi tới điểm cuối bạn chọn. Lần đầu làm điều này, ứng dụng sẽ xin phép bạn và hiển thị chính xác những gì được gửi. Bạn có thể thay đổi hoặc thu hồi quyền đó sau này trong **Cài đặt → Trợ lý AI → Chia sẻ dữ liệu AI từ xa**.
- Một số khu vực, chẳng hạn bản App Store đại lục Trung Quốc, không có trợ lý AI. Trong bản đó chỉ có các tính năng Kinh Thánh ngoại tuyến.

## Cách quản lý các cuộc trò chuyện

Màn hình AI giữ danh sách các cuộc trò chuyện trước đây. Từ danh sách, bạn có thể mở một cuộc trò chuyện cũ, bắt đầu một cuộc mới, hoặc xóa cuộc bạn không còn cần.

## Đi sâu hơn với AI

Trang này nói về những điều cơ bản. AI của Theodia có thể làm được nhiều hơn cả trò chuyện. Đây là nơi để tiếp tục:

- **[Tính năng AI](theodia://help/ai-features)** — Khám phá mọi thứ Theophilus có thể làm: học một câu Kinh Thánh bằng một chạm bằng Hy Lạp văn và Hê-bơ-rơ, chuỗi tham chiếu chéo, dàn bài giảng, tạo lời cầu nguyện, hình thái học ngôn ngữ gốc, tra từ điển, và điều hướng ứng dụng không cần tay. Đây là hướng dẫn cho bạn cách biến AI từ chatbot thành bạn học tập toàn diện.
- **[Viết câu lệnh AI hay hơn](theodia://help/ai-prompts)** — Học cách đặt câu hỏi để nhận câu trả lời phong phú, chính xác. Vài thay đổi nhỏ trong cách diễn đạt có thể mở ra câu trả lời sâu hơn hẳn từ AI.
- **[Chọn mô hình AI](theodia://help/choosing-a-model)** — Không phải mọi mô hình AI đều như nhau. Tìm hiểu mô hình nào hỗ trợ các công cụ có sẵn của Theodia (như mở câu Kinh Thánh và tìm kiếm Kinh Thánh) và mô hình nào biến AI thành trợ lý học Kinh Thánh thực sự không cần tay.
- **[GitHub Models](theodia://help/github-models)** — Nhà cung cấp miễn phí được khuyên dùng cho Theodia. Lấy khóa API miễn phí bằng tài khoản GitHub và bắt đầu đặt câu hỏi với hạn mức hàng ngày hào phóng. Không cần thẻ tín dụng, không cần gói thuê bao.
- **[Khóa API và chi phí](theodia://help/ai-keys-and-costs)** — Hiểu cách định giá API hoạt động giữa các nhà cung cấp và cách giữ chi phí gần bằng không.
