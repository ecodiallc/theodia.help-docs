---
title: Tính năng AI
categories: ai
level: advanced
summary: Khám phá mọi thứ AI của Theodia có thể làm — từ học từng câu Kinh Thánh đến soạn bài giảng, khám phá ngôn ngữ gốc, và điều hướng không cần tay.
---

# Tính năng AI

> **Chế độ:** Trợ lý AI yêu cầu chế độ **Học giả**. Bạn có thể đổi chế độ trong **Cài đặt** → **Chế độ người dùng ứng dụng**.

Trợ lý AI của Theodia, Theophilus, không chỉ là một chatbot. Nó là một người bạn học tập có thể đọc Kinh Thánh cùng bạn, tra bình giải, tìm kiếm Kinh Thánh, quản lý ghi chú của bạn, và thậm chí điều hướng ứng dụng — tất cả bằng giọng nói hoặc chữ.

Trước khi Theophilus gửi dữ liệu tới một điểm cuối AI lần đầu tiên, ứng dụng hiển thị hộp thoại xin phép giải thích những gì được gửi và hỏi sự cho phép của bạn. Bạn có thể thay đổi hoặc thu hồi quyền đó bất cứ lúc nào trong **Cài đặt → Trợ lý AI → Chia sẻ dữ liệu AI từ xa**.

## Trò chuyện câu Kinh Thánh bằng AI: Học sâu một câu

**Trò chuyện câu Kinh Thánh bằng AI** là trung tâm của trải nghiệm AI trong Theodia. Khi đang đọc bất kỳ chương nào, hãy nhấn số câu (hoặc nhấn giữ văn bản câu) và chọn **Bình giải bằng AI**. Một bảng trò chuyện mở ra với câu đó đã được tải sẵn. AI biết chính xác bạn đang đọc gì và sẵn sàng cùng bạn khám phá.

### Các nút bắt đầu bằng một chạm

Chưa biết hỏi gì? Bảng hiển thị tám mục bắt đầu tức thì:

- **Giải thích câu này** — Nhận lời phân tích rõ ràng, chu đáo về ý nghĩa và tầm quan trọng.
- **Ngôn ngữ gốc** — Xem các từ Hy Lạp văn hoặc Hê-bơ-rơ, cách phiên âm, và định nghĩa từ vựng đằng sau văn bản tiếng Anh.
- **Ngữ cảnh lịch sử** — Tìm hiểu văn hóa, chính trị, và các sự kiện xung quanh câu.
- **Ngữ cảnh văn bản** — Xem câu đó nằm như thế nào trong đoạn, chương, và sách xung quanh.
- **Chủ đề chính** — Khám phá các ý tưởng lớn mà câu này đóng góp vào thần học Kinh Thánh.
- **Áp dụng vào đời sống** — Nhận các bài áp dụng thiết thực, cá nhân mà bạn có thể hành động ngay hôm nay.
- **Tạo lời cầu nguyện** — Biến câu thành một lời cầu nguyện theo mẫu ngôn ngữ và chân lý của nó.
- **Tạo dàn bài giảng** — Nhận dàn bài ba điểm với phần mở đầu và kết luận, sẵn sàng giảng.

Nhấn bất kỳ mục nào và AI bắt đầu ngay. Bạn có thể hỏi thêm câu riêng, xin giải thích rõ hơn, hoặc chuyển hướng cuộc trò chuyện.

### Hỏi tiếp như một cuộc trò chuyện thật

AI nhớ một vài tin nhắn gần đây trong trò chuyện, nên bạn có thể đào sâu một cách tự nhiên:

- "Bạn có thể nói đơn giản hơn không?"
- "Tiếng Hy Lạp gốc nói gì ở đây?"
- "Cho tôi xem các tham chiếu chéo liên quan đến điều này."
- "So sánh câu này trong ba bản dịch khác nhau."
- "Điều này sẽ trông như thế nào ở nơi làm việc hiện đại?"
- "Cho tôi thêm ba bài áp dụng dành cho cha mẹ."

Cuộc trò chuyện luôn gắn với câu Kinh Thánh, nên mọi câu trả lời đều dựa trên văn bản bạn đang đọc.

### Nhấn vào bất kỳ tham chiếu Kinh Thánh nào

Khi AI nhắc đến một câu khác — ví dụ, "Điều này phản chiếu Rô-ma 8:28" — tham chiếu đó hiện như một **liên kết có thể nhấn**. Nhấn vào đó và ứng dụng nhảy đến đoạn đó trong trình đọc Kinh Thánh. Bạn có thể khám phá chuỗi tham chiếu mà không rời cuộc trò chuyện.

## AI Có Thể Làm Gì Ngoài Trò Chuyện Câu Kinh Thánh

Theophilus có quyền truy cập toàn bộ nội dung của Theodia — Kinh Thánh, bình giải, từ điển từ vựng, từ điển, sách, tài liệu tĩnh tâm, ghi chú, dấu trang, và phần đánh dấu của bạn. Dưới đây là điều đó có nghĩa gì trong thực tế.

### Đọc và điều hướng Kinh Thánh

- **Đọc bất kỳ câu hoặc chương nào** — "Đọc Giăng 3:16 trong bản WEB" hoặc "Đọc to Thi Thiên 23."
- **Mở đoạn trong trình đọc** — "Đưa tôi đến Sáng Thế Ký 1" hoặc "Mở Rô-ma 8:28."
- **So sánh các bản dịch** — "Cho tôi xem Giăng 3:16 trong tất cả Kinh Thánh của tôi."
- **Tìm kiếm Kinh Thánh** — "Tìm các câu về sự tha thứ" hoặc "Tìm kiếm 'bình an vượt qua mọi hiểu biết.'"
- **Nhận tham chiếu chéo** — "Những câu nào liên quan đến Ê-sai 53:5?"
- **Đọc tiêu đề các phần** — "Các tiêu đề phụ trong Ma-thi-ơ 5 là gì?"

### Khám phá ngôn ngữ gốc

- **Tra từ điển từ vựng** — "Từ Hy Lạp 'agape' trong Giăng 3:16 nghĩa là gì?" hoặc "Tra Strong's G26."
- **Hình thái học** — "Phân tích các động từ Hy Lạp trong Rô-ma 8:28" hoặc "Mã hình thái V-PAI-3S nghĩa là gì?"
- **Thông tin từ** — AI có thể nhìn thấy cùng bản phân tích từng từ như bạn thấy trong ứng dụng — phiên âm, nghĩa tương đương, ngữ pháp, và số Strong.

### Đọc bình giải và sách học tập

- **Bình giải theo câu** — "Matthew Henry nói gì về Ê-phê-sô 2:8?"
- **Bình giải theo chương** — "Cho tôi tổng quan chương Rô-ma 8."
- **Bình giải theo sách** — "Tóm tắt bình giải cấp sách về Khải Huyền."
- **Sách học tập** — "Đọc cho tôi một chương từ Lời Thánh Ca Tiếng Anh" hoặc "Tìm trong sách của tôi từ 'kiên nhẫn.'"
- **Tài liệu tĩnh tâm** — "Đọc tài liệu tĩnh tâm hôm nay" hoặc "Tìm một bài tĩnh tâm về lo âu."

### Tìm kiếm từ điển

- "Mel-chi-xê-đéc là ai?"
- "Từ điển Kinh Thánh nói gì về Ghinh-ganh?"
- "Tra 'đền tội' trong Easton's."

### Quản lý đời học tập của bạn

AI có thể thao tác trên dữ liệu cá nhân của bạn — luôn được lưu trên thiết bị của bạn:

- **Dấu trang** — "Đánh dấu câu này vào thư mục Chuẩn bị Bài Giảng của tôi" hoặc "Liệt kê các dấu trang của tôi."
- **Đánh dấu văn bản** — "Đánh dấu Giăng 3:16 màu vàng" hoặc "Cho tôi xem tất cả các phần đã đánh dấu."
- **Ghi chú** — "Tạo ghi chú Kinh Thánh cho câu này" hoặc "Đọc ghi chú của tôi cho Sáng Thế Ký 1."
- **Ghi chú học tập** — "Lưu cuộc trò chuyện này thành ghi chú học tập" hoặc "Tạo sổ ghi chú học tập mới tên Học Rô-ma."
- **Thư mục** — "Tạo thư mục tên Tĩnh Tâm Buổi Sáng" hoặc "Chuyển dấu trang Giăng 3:16 của tôi sang thư mục Cầu Nguyện."

### Thay đổi cài đặt ứng dụng

- "Chuyển sang chế độ tối."
- "Đặt BSB làm Kinh Thánh mặc định của tôi."
- "Bật Kinh Thánh song song với bản NET."
- "Tăng cỡ chữ."

### Đọc to

- "Đọc to Thi Thiên 23" — AI có thể kích hoạt đọc văn bản thành tiếng cho bất kỳ đoạn, sách, hoặc ghi chú nào.
- "Ngừng đọc" — Tạm dừng TTS bất cứ lúc nào.

## Lưu Các Cuộc Trò Chuyện Của Bạn

Mọi cuộc trò chuyện câu Kinh Thánh bằng AI đều có thể lưu. Nhấn menu trong bảng trò chuyện và chọn:

- **Lưu thành Ghi chú Kinh Thánh** — Thêm toàn bộ cuộc trò chuyện vào ghi chú của câu trong trình đọc Kinh Thánh.
- **Lưu thành Ghi chú Học tập** — Lưu cuộc trò chuyện vào sổ Ghi Chú Học Tập để tham khảo sau.

Điều này biến một lần khám phá nhanh bằng AI thành tư liệu học tập lâu dài mà bạn có thể xem lại, chỉnh sửa, hoặc dùng để soạn bài giảng.

## Thẻ AI Đầy Đủ

Ngoài bảng trò chuyện theo câu, Theodia có thẻ **AI** riêng trong thanh điều hướng dưới cùng. Đây là nơi trò chuyện tự do nơi bạn có thể hỏi bất cứ điều gì — không có câu nào được chọn sẵn. Dùng nó cho:

- Học theo chủ đề trên toàn bộ Kinh Thánh
- Nghiên cứu và lập dàn bài giảng
- So sánh các chủ đề thần học giữa các sách
- Gợi ý tĩnh tâm và cầu nguyện hàng ngày
- Câu đố Kinh Thánh và kế hoạch đọc
- Trợ giúp ứng dụng — "Kinh Thánh song song hoạt động thế nào?"

Các cuộc trò chuyện của bạn được tự động lưu. Bạn có thể quay lại các trò chuyện cũ, bắt đầu trò chuyện mới, và xóa các luồng cũ.

## Những Ý Tưởng Để Bắt Đầu

Đây là một vài cách dùng AI thú vị. Chọn một và thử ngay hôm nay.

**Phát Triển Cá Nhân**

- "Giải thích Phi-lip-pi 4:6–7 và cho tôi một lời cầu nguyện cho lúc tôi lo lắng."
- "Kinh Thánh nói gì về sự nghỉ ngơi? Tìm cho tôi năm câu và giải thích từng câu."

**Gia Đình và Nuôi Dạy Con**

- "Ê-phê-sô 6:4 nên hướng dẫn việc nuôi dạy con hiện đại thế nào? Cho tôi ba nguyên tắc thực tế."
- "Tìm các câu về nuôi dạy con cái và đọc to cho tôi nghe."

**Chuẩn Bị Bài Giảng và Giảng Dạy**

- "Lập dàn bài giảng 25 phút về Rô-ma 8:28 với phần mở đầu, ba điểm, và kết luận."
- "Các bình giải của tôi nói gì về 'giáp linh' trong Ê-phê-sô 6?"
- "So sánh Bài Giảng Trên Núi trong Ma-thi-ơ với bản của Lu-ca. Có gì khác nhau?"

**Học Ngôn Ngữ Gốc**

- "Cho tôi xem hình thái của từng từ trong Gia-nê 1:1."
- "'Agape' và 'philia' trong Tân Ước khác nhau thế nào?"

**Tĩnh Tâm Sâu Sắc**

- "Đọc tài liệu tĩnh tâm hôm nay và liên kết nó với một câu trong Thi Thiên."
- "Cho tôi dàn bài tĩnh tâm bảy ngày về quả của Thần."

**Chuỗi Tham Chiếu Chéo**

- "Bắt đầu từ Ê-sai 53:5 và lần theo chủ đề 'vết thương' và 'sự chữa lành' qua Tân Ước."
- "Khái niệm 'ước' xuất hiện từ Sáng Thế Ký đến Hê-bơ-rơ ở đâu?"

**Ghi Nhớ và Ôn Tập**

- "Kiểm tra tôi về các sách của Kinh Thánh theo thứ tự."
- "Tạo ghi chú học tập tóm tắt ý chính của từng chương trong Rô-ma."

## Một Vài Lưu Ý Quan Trọng

- AI là một **công cụ**, không thay thế Kinh Thánh hay sự hướng dẫn mục vụ. Luôn đối chiếu câu trả lời của nó với chính Kinh Thánh.
- Khi bạn dùng AI, các câu hỏi của bạn đi qua internet đến máy chủ của nhà cung cấp. Hầu hết nhà cung cấp không dùng dữ liệu của bạn để huấn luyện, nhưng văn bản vẫn rời thiết bị của bạn.
- AI có thể mắc lỗi. Hãy dùng các bình giải, từ điển từ vựng, và chính văn bản Kinh Thánh làm thẩm quyền cuối cùng.

## Tóm Tắt

AI của Theodia được thiết kế để làm cho việc học Kinh Thánh nhanh hơn, sâu hơn, và mang tính cá nhân hơn. Dù bạn muốn một lời giải thích ngắn gọn cho một câu khó hiểu, một dàn bài giảng đầy đủ, một cuộc học từ Hy Lạp văn, hay một chuỗi tham chiếu chéo trải khắp Kinh Thánh, Theophilus sẵn sàng giúp đỡ. Nhấn một câu, đặt một câu hỏi, và xem cuộc trò chuyện đưa bạn đến đâu.
