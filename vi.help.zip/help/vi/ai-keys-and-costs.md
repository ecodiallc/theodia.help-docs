---
title: Khóa API và chi phí
level: advanced
categories: ai
summary: Vì sao bạn cần khóa API, cách lấy một khóa, và việc dùng một mô hình AI từ xa thường tốn bao nhiêu.
---

# Khóa API và chi phí

> **Chế độ:** Trợ lý AI yêu cầu chế độ **Học giả**. Bạn có thể đổi chế độ trong **Cài đặt** → **Chế độ người dùng ứng dụng**.

Trợ lý AI kết nối tới các mô hình AI từ xa. Nếu bạn muốn dùng nó, bạn cần một khóa API. Trang này giải thích vì sao, cách lấy một khóa, và nó thường tốn bao nhiêu.

## Vì sao bạn cần một khóa API

Một mô hình AI từ xa nằm trên một máy chủ trên internet. Khóa API giống như một mật khẩu nói với máy chủ rằng: "Người này được phép đặt câu hỏi." Không có nó, máy chủ sẽ không trả lời.

Ứng dụng không cung cấp khóa có sẵn. Bạn phải tự tạo tài khoản với một nhà cung cấp và dán khóa của mình vào ứng dụng.

## Cách lấy một khóa API

1. Mở **Cài đặt** trong Theodia.
2. Nhấn **Trợ lý AI**.
3. Chọn **Mô hình từ xa**.
4. Chọn một nhà cung cấp trong danh sách, hoặc chọn **Tùy chỉnh** và nhập một URL gốc.
5. Nhấn liên kết tới trang khóa của nhà cung cấp. Tạo tài khoản nếu bạn chưa có.
6. Tạo một khóa API mới trên trang của nhà cung cấp.
7. Sao chép khóa và dán vào Theodia.
8. Nhấn **Kiểm tra kết nối** để chắc chắn nó hoạt động.

## Các nhà cung cấp được hỗ trợ

Theodia có thể kết nối tới bất kỳ nhà cung cấp nào dùng API tương thích OpenAI. Đây là những nhà cung cấp có liên kết đặt sẵn trong ứng dụng:

- **GitHub Models** — github.com/marketplace/models (hạn mức hàng ngày miễn phí, được khuyên dùng)
- **OpenAI** — platform.openai.com
- **OpenRouter** — openrouter.ai
- **Anthropic** — console.anthropic.com
- **Groq** — console.groq.com
- **Mistral** — console.mistral.ai
- **Together AI** — api.together.xyz

Bạn cũng có thể dùng URL gốc **Tùy chỉnh** nếu bạn tự vận hành máy chủ hoặc dùng một dịch vụ khác.

## Chi phí bao nhiêu?

Hầu hết nhà cung cấp tính phí theo **token**. Một token xấp xỉ một từ hoặc một phần của từ. Bạn trả tiền cho các token bạn gửi đi (câu hỏi của bạn) cộng với các token AI gửi trả lại (câu trả lời).

### Giá thông thường

Giá cả thay đổi, nhưng đây là mức ước tính vào giữa năm 2026:

- **Các mô hình nhỏ, nhanh** (như các điểm cuối loại GPT-3.5 rẻ hơn) tốn một phần xu cho mỗi nghìn token.
- **Các mô hình tầm trung** (như GPT-4o hay Claude Sonnet) thường tốn vài xu cho mỗi nghìn token.
- **Các mô hình suy luận lớn** (như GPT-4.5 hay Claude Opus) có thể tốn mười đến hai mươi xu cho mỗi nghìn token.

Một câu hỏi Kinh Thánh thông thường trong Theodia có thể dùng tổng cộng vài trăm đến vài nghìn token. Điều đó có nghĩa hầu hết các câu hỏi tốn từ **dưới một xu đến vài xu**.

### Mẹo giữ chi phí thấp

- Bắt đầu với một mô hình rẻ hơn. Hầu hết câu hỏi Kinh Thánh không cần mô hình đắt nhất.
- Dùng Groq hoặc OpenRouter nếu bạn muốn thử các mô hình khác nhau và so sánh giá.
- Theo dõi bảng sử dụng của bạn trên trang của nhà cung cấp.

## GitHub Models

[GitHub Models](https://github.com/marketplace/models) cung cấp hạn mức miễn phí không cần thuê bao. Tất cả những gì bạn cần là một tài khoản GitHub miễn phí và một mã truy cập cá nhân có quyền đọc mô hình.

**Cách thiết lập:**

1. Vào [github.com/settings/tokens](https://github.com/settings/tokens) và tạo một **Personal access token (classic)**.
2. Cấp cho nó phạm vi `models:read` (hoặc chỉ cần chọn quyền models).
3. Trong Theodia, chọn **GitHub Models** làm nhà cung cấp và dán mã của bạn vào.

**Các mô hình hạn mức miễn phí:**

- `openai/gpt-4.1-nano` — **15 yêu cầu mỗi phút, 150 yêu cầu mỗi ngày**
- `openai/gpt-4.1-mini` — **15 yêu cầu mỗi phút, 150 yêu cầu mỗi ngày**
- `openai/gpt-4.1` — **10 yêu cầu mỗi phút, 50 yêu cầu mỗi ngày**
- `openai/gpt-4o` — **10 yêu cầu mỗi phút, 50 yêu cầu mỗi ngày**

Các giới hạn này được đặt lại hàng ngày và là quá đủ cho việc học Kinh Thánh thường lệ.

Để xem hướng dẫn từng bước đầy đủ kèm ảnh chụp màn hình, hãy xem hướng dẫn riêng về [GitHub Models](theodia://help/github-models).

## Lưu ý về quyền riêng tư

Khi bạn dùng một mô hình AI từ xa, ứng dụng trước tiên hiển thị hộp thoại xin phép giải thích những gì được gửi: các tin nhắn của bạn, ngữ cảnh câu hoặc chương, các lệnh gọi công cụ và kết quả, tên mô hình đã cấu hình, và khóa API của bạn trong phần đầu yêu cầu. Yêu cầu đi thẳng tới điểm cuối bạn đã cấu hình, không qua Theodia. Hầu hết nhà cung cấp không dùng dữ liệu của bạn để huấn luyện mô hình của họ, nhưng văn bản vẫn rời thiết bị của bạn. Bạn có thể thay đổi hoặc thu hồi quyền bất cứ lúc nào trong **Cài đặt → Trợ lý AI → Chia sẻ dữ liệu AI từ xa**.

## Tóm tắt

- Bạn cần một khóa API để dùng trợ lý AI.
- Tạo tài khoản với một nhà cung cấp, tạo một khóa, và dán nó vào Theodia.
- Hầu hết câu hỏi tốn vài xu hoặc ít hơn.
