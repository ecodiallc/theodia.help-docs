---
title: Trợ lý AI
level: advanced
category: ai
summary: Cách dùng trợ lý AI để hiểu các câu Kinh Thánh.
---

# Trợ lý AI

Theodia có một trợ lý AI. Nó có thể giúp bạn hiểu một câu Kinh Thánh, trả lời câu hỏi, hoặc trò chuyện về một chủ đề Kinh Thánh.

## Cách bật AI

AI mặc định đang tắt. Để bật:

1. Mở **Cài đặt**.
2. Nhấn **Trợ lý AI**.
3. Nhấn công tắc để bật.

Bạn có thể cần thiết lập một tài khoản hoặc một khóa. Ứng dụng sẽ hướng dẫn bạn.

## Cách mở AI

Nhấn thẻ **AI** ở cuối màn hình. Một cửa sổ trò chuyện sẽ mở ra.

## Cách đặt câu hỏi

Nhấn vào ô ở dưới cùng. Gõ câu hỏi của bạn. Nhấn **Gửi**.

Một số điều bạn có thể hỏi:

- "Giăng 3:16 có nghĩa là gì?"
- "Hãy cho tôi biết về sách Rô-ma."
- "Quả của Thần là gì?"
- "So sánh Bài giảng trên núi trong Ma-thi-ơ và Lu-ca."

## Cách hỏi về một câu cụ thể

1. Mở một chương.
2. Nhấn một câu để hiện menu câu.
3. Nhấn **Bình giải bằng AI**.

Câu đó được gửi tới AI. Bảng AI mở ra với câu đã có sẵn. Bạn có thể thêm câu hỏi, như "Điều này nghĩa là gì?" hoặc "Tôi nên áp dụng điều này thế nào?"

## Những điều quan trọng cần biết

- AI là một công cụ, không phải một con người. Nó có thể mắc lỗi.
- Luôn đối chiếu câu trả lời của AI với chính Kinh Thánh.
- AI có thể cần internet. Nó không hoạt động ngoại tuyến.
- Khi bạn dùng AI, các câu hỏi, ngữ cảnh câu Kinh Thánh và khóa API của bạn được gửi tới điểm cuối bạn chọn. Lần đầu làm điều này, ứng dụng sẽ xin phép bạn và hiển thị chính xác những gì được gửi. Bạn có thể thay đổi hoặc thu hồi quyền đó sau này trong **Cài đặt → Trợ lý AI → Chia sẻ dữ liệu AI từ xa**.
- Một số khu vực, chẳng hạn bản App Store đại lục Trung Quốc, không có trợ lý AI. Trong bản đó chỉ có các tính năng Kinh Thánh ngoại tuyến.

## Cách quản lý các cuộc trò chuyện

Màn hình AI giữ danh sách các cuộc trò chuyện trước đây. Từ danh sách, bạn có thể mở một cuộc trò chuyện cũ, bắt đầu một cuộc mới, hoặc xóa cuộc bạn không còn cần.

Để biết thêm các mẹo nâng cao, xem hướng dẫn [Viết câu lệnh AI hay hơn](theodia://help/ai-prompts).
