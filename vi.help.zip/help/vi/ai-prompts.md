---
title: Viết câu lệnh AI hay hơn
level: advanced
categories: ai
summary: Cách đặt câu hỏi cho trợ lý AI để nhận được câu trả lời tốt.
---

# Viết câu lệnh AI hay hơn

> **Chế độ:** Trợ lý AI yêu cầu chế độ **Học giả**. Bạn có thể đổi chế độ trong **Cài đặt** → **Chế độ người dùng ứng dụng**.

Một "câu lệnh" (prompt) là câu hỏi hoặc chỉ dẫn bạn đưa cho AI. Câu lệnh tốt hơn sẽ cho câu trả lời tốt hơn. Hướng dẫn này chỉ cho bạn cách làm.

## Hãy cụ thể

Xấu: "Hãy cho tôi biết về tình yêu."
Tốt hơn: "Trong 1 Cô-rinh-tô 13, Phao-lô mô tả loại tình yêu nào, và nó khác với tình yêu nam nữ thế nào?"

Càng nhiều chi tiết, câu trả lời càng hữu ích.

## Cung cấp ngữ cảnh

Xấu: "Câu này nghĩa là gì?"
Tốt hơn: "Tôi đang đọc Rô-ma 8 với một nhóm nhỏ. 'Không bị kết tội' trong chương này nghĩa là gì, và nó liên kết với phần còn lại của chương ra sao?"

Ngữ cảnh giúp AI điều chỉnh câu trả lời phù hợp với tình huống của bạn.

## Mỗi lần hỏi một điều

Xấu: "Hãy cho tôi biết về cầu nguyện, đức tin, và sự chữa lành."
Tốt hơn: "Trước tiên cho tôi biết về cầu nguyện. Sau đó tôi sẽ hỏi về đức tin."

Mỗi lần hỏi một điều giúp câu trả lời tập trung.

## Yêu cầu AI vào một vai trò

Bạn có thể yêu cầu AI trả lời theo một giọng điệu nhất định. Ví dụ:

- "Hãy trả lời như thể bạn đang dạy dỗ một tín hữu mới."
- "Hãy trả lời như một học giả Kinh Thánh."
- "Hãy trả lời cho một đứa trẻ 10 tuổi."

AI điều chỉnh câu trả lời theo vai trò đó.

## Dùng các câu hỏi tiếp theo

Nếu câu trả lời đầu chưa hoàn toàn đúng, hãy hỏi tiếp:

- "Bạn có thể nói đơn giản hơn không?"
- "Bạn có thể cho tôi một ví dụ không?"
- "Tiếng Hy Lạp gốc nói gì?"
- "Ở đâu khác trong Kinh Thánh điều này được nhắc đến?"

Một cuộc trò chuyện tốt là qua lại qua lại nhiều lần. AI nhớ một vài tin nhắn gần đây.

## Kiểm tra câu trả lời của AI

AI có thể mắc lỗi. Nó là một công cụ, không phải một người thầy.

- Đối chiếu câu trả lời của AI với các câu Kinh Thánh nó chỉ đến.
- Dùng các bình giải và từ điển từ vựng trong ứng dụng để có ý kiến thứ hai.
- Nếu câu trả lời liên quan đến giáo lý, hãy hỏi một mục sư hoặc một người bạn tin cậy.

## Các mẫu câu lệnh thông dụng

Đây là vài mẫu hoạt động tốt:

- "Hãy giải thích câu này cho tôi như thể tôi là một tín hữu mới."
- "Ý chính của chương này là gì trong một câu?"
- "Liệt kê ba bài áp dụng cho đời sống hàng ngày của tôi từ đoạn này."
- "Tôi nên hỏi những câu gì về câu này trước khi giảng nó?"
