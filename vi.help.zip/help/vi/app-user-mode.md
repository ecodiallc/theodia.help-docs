---
title: Chế độ người dùng ứng dụng
level: beginner
categories: [user-mode]
summary: Chọn giữa ba chế độ Đọc, Tiêu chuẩn, và Học giả để kiểm soát những tính năng nào có sẵn trong ứng dụng.
---

# Chế độ người dùng ứng dụng

Theodia cung cấp ba chế độ người dùng kiểm soát những tính năng bạn thấy. Hãy chọn chế độ phù hợp với cách bạn muốn dùng ứng dụng.

## Đọc

Chế độ đơn giản nhất. Chế độ Đọc dành cho việc đọc Kinh Thánh không bị làm phiền.

- Đọc bất kỳ bản dịch Kinh Thánh nào
- Dùng Chế độ Tập Trung để đọc toàn màn hình, sạch sẽ
- Di chuyển giữa các sách và chương
- Không có công cụ học tập, không có AI, không có dấu trang, không có phần đánh dấu

Chế độ Đọc là lý tưởng nếu bạn muốn Theodia như một cuốn Kinh Thánh số sạch sẽ, không thêm gì khác.

## Tiêu chuẩn

Chế độ Tiêu chuẩn bổ sung các tính năng hàng ngày cho việc học Kinh Thánh cá nhân.

Tất cả những gì có trong chế độ Đọc, cộng thêm:

- Dấu trang, phần đánh dấu, và ghi chú
- Đọc văn bản thành tiếng
- Trình đọc Chế độ Học Tập với menu câu
- Kinh Thánh song song
- Nhập lệnh
- Tìm kiếm Kinh Thánh
- Tài liệu tĩnh tâm hàng ngày và sách có sẵn

Chế độ Tiêu chuẩn là lựa chọn đúng cho hầu hết người dùng muốn đọc, đánh dấu, và tìm kiếm Kinh Thánh mà không cần các công cụ học tập nâng cao.

## Học giả

Chế độ đầy đủ tính năng. Chế độ Học giả mở khóa mọi công cụ trong Theodia cho việc học Kinh Thánh sâu.

Tất cả những gì có trong chế độ Tiêu chuẩn, cộng thêm:

- Bình giải và từ điển từ vựng
- Tham chiếu chéo
- Từ điển Kinh Thánh
- Thông Tin Từ (tra cứu Strong)
- Trợ lý AI và Bình Giải Bằng AI
- Menu Khởi Đầu Nhanh

Chế độ Học giả được thiết kế cho các mục sư, sinh viên chủng thần học, và bất kỳ ai muốn các công cụ ngôn ngữ gốc cùng các phương tiện học tập có AI hỗ trợ.

## Cách đổi chế độ

1. Mở **Cài đặt**.
2. Nhấn **Chế độ người dùng ứng dụng**.
3. Chọn **Đọc**, **Tiêu chuẩn**, hoặc **Học giả**.

Thay đổi có hiệu lực ngay lập tức. Các menu và nút mà bạn không có quyền truy cập ở chế độ hiện tại sẽ bị ẩn.

## Chọn một chế độ

- **Đọc** — Bạn chỉ muốn đọc Kinh Thánh, không gì khác.
- **Tiêu chuẩn** — Bạn muốn dấu trang, phần đánh dấu, ghi chú, tìm kiếm, và tài liệu tĩnh tâm.
- **Học giả** — Bạn muốn mọi công cụ học tập, bao gồm AI, bình giải, và từ điển từ vựng.

Bạn có thể đổi chế độ bất cứ lúc nào. Dấu trang, phần đánh dấu, và ghi chú của bạn không bao giờ bị xóa khi bạn đổi chế độ; chúng chỉ đơn giản là bị ẩn cho đến khi bạn quay lại một chế độ hỗ trợ chúng.
