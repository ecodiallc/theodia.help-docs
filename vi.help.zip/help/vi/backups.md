---
title: Sao lưu dữ liệu của bạn
level: everyday
categories: settings
summary: Cách lưu và khôi phục ghi chú, phần đánh dấu, dấu trang, và các thông tin mật của bạn.
---

# Sao lưu dữ liệu của bạn

Ghi chú, phần đánh dấu, dấu trang, và cài đặt của bạn được lưu trên thiết bị. Nếu bạn mất điện thoại, đổi điện thoại mới, hoặc gỡ ứng dụng, dữ liệu đó có thể bị mất. Hướng dẫn này chỉ cho bạn cách sao lưu.

## Cách mở cài đặt sao lưu

1. Mở **Cài đặt**.
2. Nhấn **Sao lưu ứng dụng**.

## Cách tạo bản sao lưu ứng dụng

1. Mở **Cài đặt**.
2. Nhấn **Sao lưu ứng dụng**.
3. Nhấn **Tạo Sao Lưu Ứng Dụng**.
4. Chọn một thư mục trên thiết bị để lưu tệp. Bạn cũng có thể chọn một ổ đĩa đám mây.
5. Ứng dụng tạo một tệp duy nhất chứa tất cả dữ liệu của bạn. Tệp có đuôi `.zip`.

## Bao lâu nên sao lưu một lần

Hãy sao lưu:

- Sau khi bạn đã viết rất nhiều ghi chú.
- Trước khi cập nhật hệ điều hành của thiết bị.
- Trước khi gỡ ứng dụng hoặc đổi điện thoại.

Một thói quen tốt là sao lưu mỗi tháng một lần. Một số người sao lưu mỗi tuần.

## Cách khôi phục từ bản sao lưu ứng dụng

1. Mở **Cài đặt**.
2. Nhấn **Sao lưu ứng dụng**.
3. Nhấn **Khôi Phục Từ Sao Lưu Ứng Dụng**.
4. Chọn tệp sao lưu `.zip`.
5. Với mỗi loại dữ liệu (ghi chú, phần đánh dấu, dấu trang, v.v.), hãy chọn giữ lại dữ liệu hiện có trên thiết bị, thay thế bằng bản sao lưu, hoặc bỏ qua.
6. Nhấn **Khôi Phục**.

Ứng dụng thay thế dữ liệu của bạn bằng dữ liệu trong bản sao lưu. Điều này bao gồm:

- Ghi chú
- Phần đánh dấu
- Dấu trang
- Thư mục dấu trang
- Cài đặt (giao diện, cỡ chữ, ngôn ngữ)

## Sao lưu thông tin mật

**Sao lưu ứng dụng** của bạn **không** bao gồm các thông tin mật như khóa API AI hay mã GitHub. Để sao lưu riêng những thứ đó, dùng **Sao Lưu Thông Tin Mật**.

### Lưu một bản sao lưu thông tin mật

1. Mở **Cài đặt**.
2. Nhấn **Sao lưu ứng dụng**.
3. Trong phần **Sao Lưu Thông Tin Mật**, nhấn **Lưu Sao Lưu Thông Tin Mật**.
4. Nhập một mật khẩu mạnh và xác nhận lại.
5. Ứng dụng mã hóa các thông tin mật của bạn và cho bạn tệp đã mã hóa. Hãy lưu nó ở nơi an toàn.

### Khôi phục bản sao lưu thông tin mật

1. Mở **Cài đặt**.
2. Nhấn **Sao lưu ứng dụng**.
3. Trong phần **Sao Lưu Thông Tin Mật**, nhấn **Khôi Phục Sao Lưu Thông Tin Mật**.
4. Chọn tệp sao lưu thông tin mật đã mã hóa.
5. Nhập cùng mật khẩu bạn đã dùng khi lưu.
6. Các thông tin mật của bạn được khôi phục.

> **Quan trọng:** Nếu bạn quên mật khẩu, các thông tin mật không thể khôi phục được. Không có cách đặt lại.

## Những điều cần biết

- Việc khôi phục **thay thế** các loại dữ liệu bạn đã chọn. Mọi thứ bạn thêm sau khi sao lưu sẽ bị mất với những loại dữ liệu đó.
- Bản sao lưu ứng dụng là một tệp `.zip` duy nhất. Hãy giữ nó ở nơi an toàn.
- Bạn có thể sao chép tệp, di chuyển nó, hoặc lưu vào bất kỳ dịch vụ đám mây nào.
- Bản sao lưu ứng dụng không bao gồm chính các bản dịch Kinh Thánh. Những bản đó có thể tải lại từ **Cài đặt** → **Quản Lý Tài Nguyên**.
- Các bản sao lưu thông tin mật được mã hóa bằng mật khẩu của bạn. Hãy chọn một mật khẩu bạn sẽ nhớ.

## Mẹo

Nếu bạn có nhiều hơn một thiết bị, bạn có thể sao chép tệp sao lưu sang từng thiết bị và khôi phục. Dữ liệu của bạn sẽ giống nhau trên cả hai.
