---
title: Đánh dấu câu Kinh Thánh
level: everyday
categories: [annotate, read]
summary: Cách lưu các câu Kinh Thánh để có thể tìm lại chúng.
---

# Đánh dấu câu Kinh Thánh

> **Chế độ:** Dấu trang có sẵn trong chế độ **Tiêu chuẩn** và **Học giả**. Chế độ Tập Trung chỉ dành cho việc đọc sạch sẽ, không bị làm phiền. Bạn có thể đổi chế độ trong **Cài đặt** → **Chế độ người dùng ứng dụng**.

Một dấu trang lưu một câu Kinh Thánh hoặc một chương sách để bạn có thể tìm lại nó. Dấu trang giống như các dải băng đánh dấu trong một cuốn sách.

## Cách đánh dấu một câu

1. Mở câu đó.
2. Nhấn vào câu để hiện menu.
3. Nhấn **Dấu Trang** trong menu. Một biểu tượng ngôi sao đánh dấu câu đã được lưu.

Một dấu tích trên biểu tượng nghĩa là câu bây giờ đã được đánh dấu.

## Cách đánh dấu một chương sách

Khi đọc một cuốn sách (không phải Kinh Thánh), bạn có thể đánh dấu cả chương:

1. Mở chương đó.
2. Nhấn biểu tượng **Dấu Trang** ở đầu màn hình.

## Cách xem dấu trang của bạn

Nhấn thẻ **Dấu Trang** ở dưới cùng. Bạn sẽ thấy danh sách mọi câu và chương sách bạn đã lưu.

## Cách xóa một dấu trang

- **Một câu:** Mở câu đó. Nhấn vào câu, rồi nhấn lại biểu tượng **Dấu Trang**. Dấu tích biến mất.
- **Từ danh sách:** Trong thẻ **Dấu Trang**, nhấn giữ một dấu trang. Một menu nhỏ hiện ra. Nhấn **Xóa**. (Bạn cũng có thể nhấn nút × nhỏ trên hàng đó.)

## Sắp xếp bằng thư mục

Bạn có thể đặt dấu trang vào các thư mục. Ví dụ, bạn có thể có một thư mục tên "Chuẩn Bị Bài Giảng" và một thư mục khác tên "Động Viên".

Để tạo một thư mục:

1. Mở thẻ **Dấu Trang**.
2. Nhấn **Quản Lý Thư Mục** ở trên cùng.
3. Nhấn **+ Tạo Thư Mục** ở đầu danh sách thư mục.
4. Gõ tên và nhấn **Lưu**.

Bạn không thể tạo hai thư mục trùng tên. Nếu tên đã tồn tại, một thông báo lỗi hiện ra trong khung tạo thư mục để bạn đổi tên và thử lại.

Để đặt một dấu trang vào một thư mục:

1. Trong thẻ **Dấu Trang**, nhấn giữ một dấu trang.
2. Nhấn **Lưu Vào Thư Mục**.
3. Chọn thư mục, rồi nhấn **Xong**.

## Nhập dấu trang

Bạn có thể đưa dấu trang vào Theodia từ các ứng dụng và tệp khác.

Vào **Cài đặt** → **Dấu Trang** → **Nhập Dấu Trang**. Chọn **Nhập Từ Tệp** hoặc dán từ bảng tạm. Ứng dụng tự động nhận diện định dạng.

### Các định dạng được hỗ trợ

**Xuất JSON gốc** — Định dạng mà tính năng xuất của chính Theodia dùng. Định dạng này giữ nguyên các thư mục và ngày tạo.

**HTML Dấu Trang Netscape** — Định dạng mà Chrome, Firefox, và Safari dùng khi bạn xuất dấu trang. Các thư mục được giữ nguyên.

**CSV** — Một bảng tính với các cột. Ứng dụng tìm các cột `url` và `folder` (hoặc `href` / `category`). Ví dụ:

```csv
url,folder
/bible/KJV/John/3,Favorites
/bible/KJV/Genesis/1,Sermon Prep
```

**Văn bản thuần** — Mỗi dòng là một tham chiếu Kinh Thánh, một URL ứng dụng, hoặc một chỉ thị thư mục. Ví dụ:

```
folder: Favorites
John 3:16
Genesis 1:1
folder: Sermon Prep
Matthew 5:1
```

- Các dòng bắt đầu bằng `folder: <tên>` đặt thư mục đang hoạt động cho tất cả các dấu trang theo sau.
- Các tham chiếu Kinh Thánh như `John 3:16` được chuyển thành dấu trang trong Kinh Thánh mặc định của bạn.
- Các URL ứng dụng như `/bible/KJV/John/3#v3_16` hoặc `/book/MyBook/1` được nhập trực tiếp.
- Các dòng bắt đầu bằng `#` hoặc `//` được coi là ghi chú và bị bỏ qua.

### Mẹo khi nhập

- Các dấu trang trùng nhau được bỏ qua tự động.
- Các URL bên ngoài (như liên kết BibleGateway) được chuyển thành dấu trang ứng dụng khi có thể.
- Nếu một thư mục trong tệp nhập đã tồn tại, các dấu trang được đặt vào thư mục hiện có đó.

## Mẹo

- Bạn có thể đánh dấu cùng một câu trong nhiều bản dịch. Tất cả đều hiện trong danh sách.
- Dấu trang nằm trên thiết bị của bạn. Chúng không đồng bộ lên đám mây.
- Xem hướng dẫn [Sao lưu dữ liệu của bạn](theodia://help/backups) để giữ chúng an toàn.

## Dấu trang trong tệp PDF

Tệp PDF có dấu trang riêng, tách biệt với các dấu trang Kinh Thánh của bạn. Khi đọc một tệp PDF, hãy nhấn nút **Dấu Trang** trên thanh công cụ của trình đọc để lưu trang hiện tại, đặt cho nó một cái tên, và quay lại sau. Mỗi tệp PDF giữ danh sách riêng của mình — xem [Tệp PDF](theodia://help/pdfs).
