---
title: Chọn một mô hình AI
level: advanced
categories: ai
summary: Cách chọn một mô hình hoạt động tốt với các công cụ và khả năng có sẵn của Theodia.
---

# Chọn một mô hình AI

> **Chế độ:** Trợ lý AI yêu cầu chế độ **Học giả**. Bạn có thể đổi chế độ trong **Cài đặt** → **Chế độ người dùng ứng dụng**.

Không phải mô hình AI nào cũng hoạt động như nhau trong Theodia. Trải nghiệm tốt nhất đến từ một mô hình hỗ trợ **gọi công cụ** — khả năng để AI dùng các tính năng có sẵn của Theodia như tra cứu câu Kinh Thánh, tìm kiếm, đọc bình giải, và điều hướng ứng dụng.

## Gọi công cụ là gì?

Khi bạn hỏi AI của Theodia một câu, AI có thể làm nhiều hơn là chỉ nói chuyện. Nó còn có thể **hành động**. Ví dụ:

- Bạn nói, "Cho tôi xem Giăng 3:16 trong bản ESV." AI gọi một công cụ để mở câu đó trong trình đọc.
- Bạn nói, "Các bình giải của tôi nói gì về Rô-ma 8:28?" AI gọi một công cụ để lấy nội dung bình giải.
- Bạn nói, "Lưu câu này thành dấu trang." AI gọi một công cụ để tạo dấu trang.

Các mô hình không hỗ trợ gọi công cụ chỉ có thể cho bạn câu trả lời bằng chữ. Chúng không thể tra cứu, điều hướng, hoặc thay đổi bất cứ thứ gì trong ứng dụng.

## Mô hình nào hỗ trợ công cụ?

### Các mô hình từ xa

Hầu hết các mô hình từ xa hiện đại từ các nhà cung cấp lớn đều hỗ trợ gọi công cụ tương thích OpenAI. Nói chung:

- **Các mô hình lớn** (như GPT-4o, Claude Sonnet/Opus, Gemini Pro) xử lý công cụ đáng tin cậy và có thể nối nhiều lần gọi công cụ trong một cuộc trò chuyện. Tên nhà cung cấp và ID mô hình được hiển thị trong ứng dụng để tiện theo dõi; dịch vụ thực tế bạn kết nối là dịch vụ có điểm cuối và khóa bạn đã cấu hình.
- **Các mô hình nhỏ hơn hoặc rẻ hơn** có thể hỗ trợ công cụ nhưng ít đáng tin cậy hơn. Chúng có thể bỏ qua một lần gọi công cụ hoặc định dạng sai.
- **Các mô hình rất cũ hoặc chuyên biệt** thường không hỗ trợ công cụ chút nào.

Nếu bạn không chắc, hãy thử mô hình trong Theodia. Hãy yêu cầu nó "Cho tôi xem Sáng Thế Ký 1:1" hoặc "Tìm trong Kinh Thánh các câu về tình yêu." Nếu câu mở ra hoặc kết quả tìm kiếm hiện ra, gọi công cụ đang hoạt động.

## Các mô hình được khuyên dùng cho Theodia

Đây là những lựa chọn tốt cân bằng giữa chi phí, chất lượng, và hỗ trợ công cụ:

- **OpenAI GPT-4o** — hỗ trợ công cụ xuất sắc, nhanh, xử lý tốt các câu hỏi phức tạp nhiều bước.
- **Anthropic Claude Sonnet / Opus** — dùng công cụ rất đáng tin cậy, rất tốt cho các đoạn dài và việc học chi tiết.
- **Groq** (nhiều mô hình) — suy luận nhanh, thường miễn phí hoặc rất rẻ, hỗ trợ công cụ tùy từng mô hình.
- **OpenRouter** — cho bạn thử nhiều mô hình từ một tài khoản. Hãy tìm các mô hình liệt kê "function calling" hoặc "tools" trong khả năng của chúng.
- **[GitHub Models](theodia://help/github-models)** — nhà cung cấp miễn phí được khuyên dùng. Truy cập các mô hình OpenAI, Anthropic, và khác qua tài khoản GitHub của bạn với hạn mức hàng ngày miễn phí hào phóng. Dùng cùng kiểu ID mô hình như `openai/gpt-4o`.

## Các mô hình nên tránh

- **Các mô hình chỉ hoàn thành văn bản** (như GPT-3 gốc hay LLaMA thô không tinh chỉnh theo chỉ dẫn) thường không hỗ trợ công cụ.
- **Các mô hình chỉ dành cho hình ảnh hoặc thị giác** tập trung vào hình ảnh hơn là văn bản có thể thiếu hỗ trợ công cụ.
- **Các mô hình cực nhỏ** dưới 1 tỷ tham số khó có thể dùng công cụ đúng cách, ngay cả khi API cho rằng chúng hỗ trợ.

## Cách kiểm tra hỗ trợ công cụ

Theodia tự động kiểm tra hỗ trợ công cụ. Sau khi bạn thiết lập một mô hình trong **Cài đặt → Trợ lý AI**, hãy nhấn **Kiểm tra kết nối**. Khi kết nối thành công, ứng dụng gửi một yêu cầu thứ hai kèm định nghĩa công cụ mẫu. Bạn sẽ thấy một trong hai kết quả:

- **✓ Hỗ trợ công cụ** — Mô hình chấp nhận các lần gọi công cụ và có thể dùng các tính năng có sẵn của Theodia.
- **✗ Không hỗ trợ công cụ** — Mô hình từ chối yêu cầu công cụ. Nó sẽ chỉ trả lời bằng chữ và không thể mở câu Kinh Thánh, tìm kiếm, hay quản lý dấu trang cho bạn.

Nếu bạn thấy "Không hỗ trợ công cụ", mô hình vẫn có thể hoạt động như một trợ lý trò chuyện thuần văn bản, nhưng bạn sẽ không có trải nghiệm tích hợp, không cần tay.

Bạn cũng có thể tự xác nhận bằng cách yêu cầu AI làm một việc:

- "Cho tôi xem Ma-thi-ơ 5:3 trong bản KJV." — Nên mở câu đó trong trình đọc.
- "Từ điển từ vựng nói gì về từ 'agape' trong Giăng 3:16?" — Nên trả về dữ liệu từ điển.
- "Tìm trong Kinh Thánh các câu về sự tha thứ." — Nên trả về kết quả tìm kiếm.
- "Đánh dấu Mác 12:30." — Nên tạo một dấu trang.

Nếu AI chỉ đưa cho bạn một đoạn mô tả bằng chữ thay vì thực sự làm việc đó, mô hình đang gặp khó khăn khi dùng công cụ của mình dù ứng dụng đã báo có hỗ trợ.

## Nếu mô hình của tôi không hỗ trợ công cụ thì sao?

Bạn vẫn có thể dùng nó. AI sẽ trả lời bằng chữ, và bạn có thể tự tra câu Kinh Thánh, tìm kiếm, và điều hướng ứng dụng. Nhưng bạn sẽ bỏ lỡ trải nghiệm tích hợp, không cần tay khiến Theodia mạnh mẽ.

## Tóm tắt

- Chọn một mô hình có hỗ trợ **gọi công cụ / function calling** để có trải nghiệm Theodia tốt nhất.
- **Các mô hình từ xa lớn** xử lý công cụ đáng tin cậy nhất.
- Thử bất kỳ mô hình nào với các lệnh đơn giản như "Cho tôi xem Sáng Thế Ký 1:1" để xác nhận hỗ trợ công cụ.
