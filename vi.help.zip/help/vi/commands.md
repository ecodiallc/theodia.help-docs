---
title: Các lệnh
level: everyday
categories: [layout, study]
summary: Ô nhập lệnh cho phép bạn nhảy đến bất kỳ tính năng nào bằng cách gõ một lệnh ngắn. Tìm hiểu các định dạng được hỗ trợ và các ví dụ.
---

# Các lệnh

Ô nhập **Lệnh** cho phép bạn nhảy đến gần như bất kỳ phần nào của Theodia bằng cách gõ một chỉ dẫn ngắn. Bạn có thể dùng nó từ thẻ Trang Chủ hoặc từ **Menu Khởi Đầu Nhanh** (biểu tượng **▼** trên đầu trang).

## Cách hoạt động

1. Nhấn vào ô Lệnh.
2. Gõ một lệnh.
3. Nhấn phím đi (go) trên bàn phím của bạn.

Ứng dụng đọc lệnh và đưa bạn thẳng đến đúng màn hình.

## Không có tiền tố gạch chéo

Các lệnh **không** dùng tiền tố `/`. Chúng được nhập dưới dạng văn bản thuần:

```
john 3:16
search love
backup
```

Nếu bạn gõ `/settings`, dấu `/` ở đầu khiến nó không được nhận diện.

## Tham chiếu Kinh Thánh

Gõ bất kỳ tham chiếu Kinh Thánh nào để mở nó trong trình đọc.

```
psalms 23
john 3:16
matthew 5:1
1 cor 15:10
```

Tên sách có thể khớp theo tên đầy đủ hoặc viết tắt. Trong các ngôn ngữ giao diện không phải tiếng Anh, bạn cũng có thể gõ tên sách bằng ngôn ngữ đang dùng.

## Tìm kiếm

```
search abraham
search love
search faith not works
```

## Dấu trang, so sánh, bình giải, tham chiếu chéo, và thông tin từ

```
bookmark john 3:16
compare genesis 1:1
commentary john 1
aicommentary eph 2:8
xref 1 cor 15:10
word info john 1:1
```

Các lệnh này mở công cụ được nêu cho đoạn Kinh Thánh đã cho.

## Từ điển từ vựng

Gõ một số Strong để mở mục từ điển từ vựng.

```
g1161
h7225
```

## Tài liệu tĩnh tâm

```
devotional
devotional smith
devotional daily
```

Nếu không có tên, lệnh này mở danh sách tài liệu tĩnh tâm.

## Phím tắt điều hướng

```
notes
highlights
bookmarks
flashcards
playlist
theoscript
resources
read john 3:16
```

Các lệnh này nhảy thẳng đến màn hình được nêu hoặc mở một đoạn trong trình đọc.

## Đổi bản dịch

Gõ một chữ viết tắt của bản dịch để chuyển sang nó.

```
kjv
web
trlit
ohgb
```

Trên màn hình trình đọc, bản dịch được thay tại chỗ. Ở nơi khác, nó mở bản dịch tại đoạn gần nhất của bạn.

## Động từ lệnh theo ngôn ngữ

Các động từ lệnh công khai có thể được gõ bằng ngôn ngữ giao diện đang dùng **hoặc** bằng tiếng Anh. Tiếng Anh luôn hoạt động như phương án dự phòng. Các lệnh ẩn (phím tắt cài đặt, lệnh cài đặt, các điều ngạc nhiên) chỉ giữ cú pháp tiếng Anh.

## Trợ giúp

Gõ `help` hoặc `commands` vào ô Lệnh để mở tra cứu lệnh trong ứng dụng bất cứ lúc nào.
