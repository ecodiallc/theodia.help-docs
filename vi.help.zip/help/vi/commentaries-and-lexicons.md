---
title: Bình giải và từ điển từ vựng
level: everyday
categories: study
summary: Cách tra nghĩa của các từ và đọc các ghi chú học tập.
---

# Bình giải và từ điển từ vựng

> **Chế độ:** Bình giải và từ điển từ vựng yêu cầu chế độ **Học giả**. Bạn có thể đổi chế độ trong **Cài đặt** → **Chế độ người dùng ứng dụng**.

Theodia bao gồm hai công cụ học tập: **bình giải** và **từ điển từ vựng**. Chúng giúp bạn hiểu Kinh Thánh sâu hơn.

## Bình giải là gì?

Một bình giải là một cuốn sách ghi chú học tập được viết bởi một học giả Kinh Thánh. Với một câu nhất định, bình giải cho bạn biết bối cảnh, ý nghĩa, và câu đó liên quan đến phần còn lại của Kinh Thánh ra sao.

## Từ điển từ vựng là gì?

Một từ điển từ vựng là một cuốn từ điển về các từ Kinh Thánh. Nó cho bạn biết từ Hê-bơ-rơ hoặc Hy Lạp gốc là gì, nghĩa của nó, và cách nó được dùng trong Kinh Thánh.

## Cách mở một bình giải

1. Mở một chương.
2. Nhấn vào một câu.
3. Nhấn **Bình Giải**.

Một bảng mở ra. Nó hiển thị các ghi chú của một học giả Kinh Thánh về câu đó.

## Cách mở một từ điển từ vựng

1. Mở một chương trong một bản Kinh Thánh có số Strong.
2. Nhấn vào một số Strong trong câu (ví dụ, G1234 hoặc H1234).
3. Một bảng mở ra hiển thị từ Hê-bơ-rơ hoặc Hy Lạp gốc, nghĩa của nó, và các câu khác dùng từ đó.

Các số Strong hiện màu khác trong văn bản câu để chúng nổi bật so với các từ thường.

## Chọn một bình giải khác

Bình giải được chọn từ một danh sách thả xuống ngay trên đầu bảng bình giải. Mở bảng, rồi nhấn vào danh sách để xem các bình giải bạn đã cài. Chọn một bình giải khác.

## Chọn một từ điển từ vựng khác

Từ điển từ vựng được chọn từ một danh sách thả xuống trên đầu bảng từ điển. Mở bảng, rồi nhấn vào danh sách để xem các từ điển bạn đã cài. Chọn một từ điển khác.

## Tài nguyên có sẵn

Theodia đi kèm một bộ bình giải và từ điển từ vựng có sẵn. Chúng được bao gồm cùng ứng dụng và hoạt động ngoại tuyến. Các bình giải và từ điển từ vựng thêm không thể được cài hoặc tải xuống riêng.

## Khi nào nên dùng những công cụ này

- **Bình giải** rất tốt khi một câu khó hiểu. Các ghi chú cho bạn bối cảnh.
- **Từ điển từ vựng** rất tốt cho việc học từ. Chúng cho bạn biết nghĩa chính xác của một từ trong ngôn ngữ gốc.

## Mẹo

Nếu một câu có một ghi chú bạn muốn giữ lại, hãy chụp màn hình hoặc sao chép văn bản vào một ghi chú. (Xem hướng dẫn [Viết Ghi Chú](theodia://help/notes).)

## Từ điển Kinh Thánh bằng ngôn ngữ đời thường

Để có các định nghĩa tiếng Anh về các từ và khái niệm Kinh Thánh (ước, lễ đền tội, người Pha-ri-si, v.v.), Theodia cũng bao gồm một công cụ Từ Điển Kinh Thánh. Mở nó từ menu câu bằng cách nhấn **Từ Điển** (📖). Nó khác với từ điển từ vựng: từ điển từ vựng giải thích các từ Hê-bơ-rơ và Hy Lạp gốc, còn từ điển giải thích từ tiếng Anh bằng ngôn ngữ đời thường. Xem hướng dẫn [Từ Điển Kinh Thánh](theodia://help/dictionary) để biết cách dùng nó.
