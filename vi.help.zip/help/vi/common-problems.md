---
title: Các vấn đề thường gặp
level: everyday
categories: trouble
summary: Các cách khắc phục nhanh cho những vấn đề bạn có thể gặp phải.
---

# Các vấn đề thường gặp

Hướng dẫn này nói về những vấn đề mọi người gặp phải thường nhất. Nếu vấn đề của bạn không có ở đây, xem hướng dẫn [Hỏi Đáp Ở Đâu](theodia://help/getting-more-help).

## Ứng dụng chạy chậm

1. Đóng các ứng dụng khác đang chạy trong nền.
2. Khởi động lại ứng dụng.
3. Khởi động lại thiết bị của bạn.

## Tôi không tìm thấy một bản dịch Kinh Thánh

1. Mở **Cài đặt** → **Quản Lý Tài Nguyên** để xem những gì đã được cài.
2. Nếu bản dịch không có ở đó, hãy nhấn **Cài Từ GitHub**.
3. Trong hộp thoại tải xuống, nhấn thẻ **Kinh Thánh** (hoặc **Kinh Thánh Toàn Cầu**) và chọn bản dịch bạn muốn.
4. Nhấn **Cài Mục Đã Chọn** và đợi tải xong.
5. Bạn cần internet để tải xuống một bản dịch mới.

## Ghi chú hoặc dấu trang của tôi biến mất

1. Kiểm tra xem bạn có đang xem đúng thẻ không. Ghi chú nằm trong thẻ **Ghi Chú**. Dấu trang nằm trong thẻ **Dấu Trang**.
2. Nếu bạn vừa khôi phục một bản sao lưu, bản sao lưu đó có thể đã thay thế dữ liệu của bạn. Kiểm tra ngày của bản sao lưu.
3. Nếu bạn gỡ rồi cài lại ứng dụng, dữ liệu của bạn đã bị mất. Lần tới, hãy sao lưu trước.

## Tính năng tìm kiếm không tìm thấy các câu

1. Đảm bảo bạn viết đúng chính tả từ đó.
2. Thử một từ ngắn hơn. "Yêu" tìm được nhiều câu hơn "đang yêu."
3. Đảm bảo bạn đã cài đúng bản dịch Kinh Thánh. Tìm kiếm chỉ hoạt động với các bản dịch bạn đã có.

## Đọc to không hoạt động

1. Đảm bảo âm lượng thiết bị của bạn đang bật.
2. Đảm bảo ứng dụng được phép dùng loa.
3. Thử một bản dịch khác. Một số bản dịch hoạt động tốt hơn với tính năng đọc to.
4. Để có danh sách kiểm tra từng bước, xem hướng dẫn [Đọc To](theodia://help/tts).

## Ứng dụng liên tục bị đóng đột ngột

1. Khởi động lại ứng dụng.
2. Khởi động lại thiết bị của bạn.
3. Nếu vấn đề vẫn tiếp tục xảy ra, vui lòng báo cáo. Xem hướng dẫn [Hỏi Đáp Ở Đâu](theodia://help/getting-more-help).

## Tôi muốn gỡ ứng dụng

Bạn có thể gỡ Theodia như bất kỳ ứng dụng nào khác. Trước khi làm, hãy sao lưu dữ liệu của bạn. Sau khi gỡ, dữ liệu trên thiết bị sẽ biến mất.

## Vẫn gặp khó khăn?

Xem hướng dẫn [Hỏi Đáp Ở Đâu](theodia://help/getting-more-help). Ở đó, bạn có thể tìm các liên kết để báo cáo một vấn đề và để hỏi cộng đồng.

Bạn cũng có thể tìm kiếm trong các hướng dẫn từ màn hình chính **Trợ Giúp & Hướng Dẫn**. Gõ một từ như `notifications`, `search`, hoặc `bookmarks` để tìm hướng dẫn tương ứng.
