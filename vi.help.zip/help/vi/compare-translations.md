---
title: So sánh các bản dịch
level: everyday
categories: [read, study]
summary: Cách xem cùng một câu trong mọi bản dịch bạn đã cài.
---

# So sánh các bản dịch

> **Chế độ:** Công cụ So Sánh có sẵn trong chế độ **Tiêu chuẩn** và **Học giả**. Chế độ Tập Trung chỉ dành cho việc đọc sạch sẽ, không bị làm phiền. Bạn có thể đổi chế độ trong **Cài đặt** → **Chế độ người dùng ứng dụng**.

Công cụ **So Sánh** hiển thị một câu duy nhất trong mọi bản dịch Kinh Thánh bạn đã cài, tất cả trong một bảng. Nó hữu ích khi bạn muốn xem các người dịch khác nhau xử lý một câu khó thế nào, hoặc khi bạn đang chọn một bản dịch và muốn xem cùng một câu trong từng bản.

## Cách mở So Sánh

1. Mở một chương trong bất kỳ bản dịch nào.
2. Nhấn vào một câu để hiện menu câu.
3. Nhấn **So Sánh** (⇄).

Một bảng mở ra. Thanh tiêu đề hiển thị tham chiếu (ví dụ, "Giăng 3:16 — So Sánh"). Bảng liệt kê cùng câu đó trong mọi bản dịch đã cài. Bản dịch hiện tại của bạn được liệt kê trước; phần còn lại được xếp theo thứ tự chữ cái.

## Bảng trông như thế nào

Bảng là một **danh sách dọc**, không phải các cột cạnh nhau. Mỗi hàng là một bản dịch:

- **Tên bản dịch** (ví dụ, "KJV") nằm ở đầu hàng. Nó có thể nhấn được.
- **Văn bản câu** nằm dưới tên.

Cuộn bảng để xem tất cả các bản dịch. Mọi bản dịch đã cài trên thiết bị của bạn sẽ xuất hiện ở đây. Nếu một bản dịch không có sách hoặc câu đó, nó bị bỏ qua.

## Cách đọc câu trong một bản dịch khác

Nhấn vào tên bản dịch trong hàng. Bảng So Sánh đóng lại và cùng chương đó mở ra với câu đã chọn hiển thị trong bản dịch đó. Đây là cách nhanh nhất để từ việc so sánh nhảy thẳng vào việc đọc một bản dịch cụ thể.

## Cách đóng So Sánh

- **Trên điện thoại:** nhấn nút X ở góc trên bên phải của bảng.
- **Trên máy tính bảng:** nhấn nút X trên đầu bảng, hoặc nhấn ngoài bảng.

Bạn quay lại chế độ xem chương trong bản dịch gốc của mình.

## Khi nào nên dùng So Sánh

- **Đang chọn một bản dịch.** Mở một câu bạn quen thuộc trong bản dịch hiện tại, rồi So Sánh để xem nó trong các bản khác. Các điểm khác biệt sẽ nổi bật.
- **Các câu khó.** Một câu khó hiểu trong bản dịch này thường rõ ràng hơn trong bản dịch khác.
- **Học từ.** Xem các người dịch khác nhau xử lý một từ hoặc cụm từ then chốt thế nào.

Để so sánh cả một chương trong nhiều bản dịch cùng lúc, dùng **chế độ xem song song**. Xem hướng dẫn [Chế Độ Học Tập](theodia://help/study-mode) để biết cách bật nó.
