---
title: Tạo tài nguyên của riêng bạn
level: advanced
categories: resources
summary: Cách tạo các bản Kinh Thánh, bình giải, sách, tài liệu tĩnh tâm, và từ điển từ vựng tùy chỉnh rồi nhập chúng vào Theodia.
---

# Tạo tài nguyên của riêng bạn

Theodia hỗ trợ các tài nguyên tùy chỉnh ở định dạng Unique Bible App. Mỗi tài nguyên là một tệp SQLite với cấu trúc bảng cụ thể. Bạn có thể tạo các tệp này trên một máy tính và nhập chúng vào ứng dụng.

## Các loại tệp và các bảng bắt buộc

### Kinh Thánh (`.bible`)

Một tệp Kinh Thánh là một cơ sở dữ liệu SQLite có ít nhất một trong các bảng này:

- **`Verses`** — các cột: `Book` (số nguyên, 1-66), `Chapter` (số nguyên), `Verse` (số nguyên), `Scripture` (văn bản)
- **`Bible`** — các cột: `Book` (số nguyên), `Chapter` (số nguyên), `Verse` (số nguyên), `Scripture` (văn bản)

Bạn cũng có thể thêm một bảng **`Details`** với các cột siêu dữ liệu như `Description`, `Abbreviation`, và `Version`.

Ví dụ SQL:

```sql
-- Main text table
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- Optional metadata table
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### Bình giải (`.commentary`)

Bình giải có ba loại: **sách**, **chương**, và **câu**. Loại được xác định bởi **chữ cái đầu của tên tệp**.

#### Bình giải theo sách — tên tệp bắt đầu bằng `b`

Một bình giải theo sách bao trùm cả một sách Kinh Thánh trong một mục duy nhất. Bảng `Commentary` cần các cột `Book` và `Scripture` (hoặc `Content`). Không cần các cột `Chapter` hay `Verse`.

- **`Commentary`** — các cột: `Book` (số nguyên), `Scripture` (văn bản) hoặc `Content` (văn bản)

Ví dụ SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

Ví dụ tên tệp: `bMyCommentary.commentary`

#### Bình giải theo chương — tên tệp bắt đầu bằng `c`

Một bình giải theo chương bao trùm từng chương của một sách Kinh Thánh.

- **`Commentary`** — các cột: `Book` (số nguyên), `Chapter` (số nguyên), `Scripture` (văn bản) hoặc `Content` (văn bản)

Ví dụ SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

Ví dụ tên tệp: `cMyCommentary.commentary`

#### Bình giải theo câu — tên tệp bắt đầu bằng `v`

Một bình giải theo câu bao trùm từng câu riêng lẻ. Bảng `Commentary` cần các cột `Book`, `Chapter`, `Verse`, và `Scripture` (hoặc `Content`).

- **`Commentary`** — các cột: `Book` (số nguyên), `Chapter` (số nguyên), `Verse` (số nguyên), `Scripture` (văn bản) hoặc `Content` (văn bản)

Ví dụ SQL:

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

Ví dụ tên tệp: `vMyCommentary.commentary`

### Sách (`.book`)

Một tệp sách là một cơ sở dữ liệu SQLite với bảng `Reference`.

- **`Reference`** — các cột: `id` (số nguyên), `Chapter` (văn bản), `Content` (văn bản)

Mỗi hàng là một chương. Cột `Chapter` là tiêu đề chương. Cột `Content` là nội dung chương, có thể chứa HTML (`<b>`, `<i>`, `<br>`, v.v.).

Ví dụ SQL:

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

Bạn cũng có thể tạo sách từ các tệp Markdown. Ứng dụng có thể nhập các tệp `.md` trong đó `#` là tên sách và `##` đánh dấu các chương. Markdown được tự động chuyển thành HTML.

### Tài liệu tĩnh tâm (`.devotional`)

Một tệp tài liệu tĩnh tâm là một cơ sở dữ liệu SQLite với bảng `devotional`.

- **`devotional`** — các cột: `month` (số nguyên, 1-12), `day` (số nguyên, 1-31), `devotion` (văn bản)

Mỗi hàng là một ngày đọc. Ứng dụng tra mục theo tháng và ngày hôm nay.

Ví dụ SQL:

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### Từ điển từ vựng (`.lexicon`)

Một tệp từ điển từ vựng là một cơ sở dữ liệu SQLite với bảng `Lexicon`.

- **`Lexicon`** — các cột: `Topic` (văn bản, số Strong), `Definition` (văn bản, mục từ điển)

Cột `Topic` chứa số Strong (ví dụ, `G1161` hoặc `H7225`). Cột `Definition` chứa toàn bộ văn bản mục từ điển, có thể chứa HTML.

Ví dụ SQL:

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

Các từ điển từ vựng là sức mạnh của công cụ Thông Tin Từ. Khi bạn nhấn vào một từ trong một bản Kinh Thánh song ngữ, ứng dụng tra số Strong trong các từ điển đã cài.

## Tạo một tệp trên máy tính của bạn

1. Cài một trình soạn thảo SQLite (DB Browser for SQLite, SQLiteStudio, hoặc công cụ dòng lệnh `sqlite3`).
2. Tạo một tệp cơ sở dữ liệu mới.
3. Tạo bảng bắt buộc và chèn dữ liệu của bạn.
4. Lưu tệp với đuôi đúng (`.bible`, `.commentary`, `.book`, `.devotional`, hoặc `.lexicon`).

## Nhập vào Theodia

1. Chuyển tệp sang thiết bị của bạn (AirDrop, email, lưu trữ đám mây, hoặc USB).
2. Mở **Theodia**.
3. Vào **Cài đặt** → **Quản Lý Tài Nguyên**.
4. Nhấn **Nhập Từ Tệp**.
5. Chọn tệp của bạn.

Ứng dụng xác thực tệp (kiểm tra bảng bắt buộc), sao chép nó vào thư mục dữ liệu của ứng dụng, và bật nó tự động. Nếu tệp không hợp lệ, bạn thấy một thông báo lỗi giải thích điều gì sai.

## Các giới hạn

- Bạn không thể ghi đè các tài nguyên có sẵn. Nếu bạn cố nhập một tệp trùng tên với một bản Kinh Thánh, bình giải, hoặc sách có sẵn, việc nhập sẽ thất bại.
- Các tệp Kinh Thánh cần bảng `Verses` hoặc `Bible`. Nếu không có bảng nào, việc nhập sẽ thất bại.
- Các tệp bình giải cần bảng `Commentary`.
  - Bình giải theo sách cần các cột `Book` và `Scripture` (hoặc `Content`).
  - Bình giải theo chương cần các cột `Book`, `Chapter`, và `Scripture` (hoặc `Content`).
  - Bình giải theo câu cần các cột `Book`, `Chapter`, `Verse`, và `Scripture` (hoặc `Content`).
- Các tệp sách cần bảng `Reference`.
- Các tệp từ điển từ vựng cần bảng `Lexicon`.
- Các tệp tài liệu tĩnh tâm cần bảng `devotional`.

## Mẹo

- Giữ kích thước tệp hợp lý. Các tệp SQLite rất lớn có thể gây vấn đề bộ nhớ trên các thiết bị cũ.
- Thử tệp của bạn trên một máy tính trước. Mở nó trong một trình duyệt SQLite và chạy `SELECT * FROM` bảng bắt buộc để xác nhận dữ liệu trông đúng.
- Với các bản Kinh Thánh, đảm bảo cột `Book` dùng các con số (1 = Sáng Thế Ký, 66 = Khải Huyền).
- Với các bình giải, bạn có thể dùng `Scripture` hoặc `Content` làm cột văn bản bình giải.
- Với các sách, HTML trong cột `Content` được hiển thị khi đọc. Hãy giữ đơn giản: `<b>`, `<i>`, `<br>`, và `<hr>` là an toàn.

## Tìm các tài nguyên có sẵn ở đâu

Theodia có thể đọc các tài nguyên từ dự án [Unique Bible App](https://github.com/eliranwong/UniqueBible). Nhiều bản Kinh Thánh, bình giải, sách, và các tài nguyên khác có sẵn ở đó theo đúng định dạng SQLite. Xem hướng dẫn [Lấy Thêm Tài Nguyên](theodia://help/getting-core-files) để biết cách tìm và thêm chúng.
