---
title: Tham chiếu chéo
level: everyday
categories: study
summary: Cách tìm các câu Kinh Thánh liên quan đến câu bạn đang đọc.
---

# Tham chiếu chéo

> **Chế độ:** Tham chiếu chéo có sẵn trong chế độ **Tiêu chuẩn** và **Học giả**. Chế độ Tập Trung chỉ dành cho việc đọc sạch sẽ, không bị làm phiền. Bạn có thể đổi chế độ trong **Cài đặt** → **Chế độ người dùng ứng dụng**.

Một "tham chiếu chéo" là một câu khác nói về cùng điều mà câu bạn đang đọc nói. Bảng tham chiếu chéo cho bạn biết những câu nào trong Kinh Thánh liên kết với nhau.

## Cách mở tham chiếu chéo

1. Mở một chương.
2. Nhấn vào một câu để hiện menu câu.
3. Nhấn **Tham Chiếu Chéo**.

Một bảng mở ra. Nó hiển thị danh sách các câu khác liên kết với câu bạn vừa nhấn.

## Cách đọc danh sách

Mỗi hàng là một câu liên kết. Bạn thấy:

- Sách, chương, và câu.
- Một đoạn xem trước ngắn của văn bản câu.
- Một điểm số cho biết mối liên kết mạnh đến đâu.

## Cách nhảy đến một câu liên kết

Nhấn vào bất kỳ hàng nào. Ứng dụng mở câu đó cho bạn. Khi bạn đọc xong, nhấn nút quay lại để trở về.

## Điểm số nghĩa là gì

Điểm số cho bạn biết các câu liên kết chặt đến đâu. Điểm cao nghĩa là một mối liên kết mạnh, trực tiếp. Điểm thấp nghĩa là mối liên kết lỏng hơn.

## Dùng tham chiếu chéo để học

Tham chiếu chéo hữu ích cho:

- **Học từ.** Xem Kinh Thánh dùng một từ ở những nơi khác nhau thế nào.
- **Học chủ đề.** Lần theo một chủ đề, như "tình yêu" hay "ước," khắp Kinh Thánh.
- **Chuẩn bị bài giảng.** Tìm nhanh các câu hỗ trợ.

## Mẹo

Tham chiếu chéo hoạt động tốt nhất với một bản dịch theo từng chữ như WEB.
