---
title: Tài liệu tĩnh tâm hàng ngày
level: everyday
categories: [content, read]
summary: Cách đọc một bài tĩnh tâm ngắn mỗi ngày.
---

# Tài liệu tĩnh tâm hàng ngày

Một bài tĩnh tâm là một bài đọc ngắn cho một ngày. Nó thường có một câu Kinh Thánh, một suy niệm ngắn, và một câu hỏi để suy gẫm. Theodia đi kèm một thư viện nhỏ các tài liệu tĩnh tâm.

## Cách mở một bài tĩnh tâm

1. Nhấn thẻ **Tĩnh Tâm** ở cuối màn hình.
2. Bạn thấy danh sách các tài liệu tĩnh tâm đã cài trên thiết bị của bạn.
3. Nhấn vào một bài để mở nó.

## Cách đọc một bài tĩnh tâm

1. Mở bài tĩnh tâm.
2. Cuộn để đọc.
3. Dùng các nút ở trên cùng để:
   - Nhấn vào **ngày** để nhảy sang một ngày khác.
   - Nhấn vào **ngôi sao** để đánh dấu ngày đó.
   - Nhấn vào **loa** để đọc to bài đó (nếu thiết bị của bạn hỗ trợ). Xem hướng dẫn [Đọc To](theodia://help/tts) để biết cách chọn giọng đọc.
   - Nhấn **Trước** hoặc **Sau** để chuyển sang ngày trước hoặc sau.

## Cách lưu một câu từ một bài tĩnh tâm

1. Mở bài tĩnh tâm.
2. Nhấn vào một câu.
3. Nhấn **Dấu Trang** hoặc **Đánh Dấu**.

Câu được lưu trong Dấu Trang hoặc Đánh Dấu của bạn.

## Cách viết một ghi chú về một bài tĩnh tâm

1. Mở bài tĩnh tâm.
2. Nhấn vào một câu.
3. Nhấn **Ghi Chú**. Gõ suy niệm hoặc lời cầu nguyện của bạn. Nhấn **Lưu**.

Ghi chú xuất hiện trong thẻ Ghi Chú của bạn.

## Mẹo

- Tài liệu tĩnh tâm không cần internet. Chúng hoạt động ngoại tuyến.
- Nếu bạn muốn thêm tài liệu tĩnh tâm, xem hướng dẫn [Lấy Thêm Tài Nguyên Từ GitHub](theodia://help/getting-core-files).
