---
title: Từ điển Kinh Thánh
level: everyday
categories: study
summary: Tra các từ và khái niệm Kinh Thánh trong các tài nguyên từ điển đã cài. Mở từ menu câu hoặc từ một mục từ điển từ vựng, rồi nhấn vào bất kỳ từ nào để xem cùng từ đó trong mọi từ điển.
---

# Từ điển Kinh Thánh

> **Chế độ:** Từ điển Kinh Thánh yêu cầu chế độ **Học giả**. Bạn có thể đổi chế độ trong **Cài đặt** → **Chế độ người dùng ứng dụng**.

Công cụ Từ Điển Kinh Thánh tra một từ hoặc cụm từ trong mọi tài nguyên từ điển bạn đã cài. Nó hữu ích khi bạn muốn một định nghĩa đời thường cho một từ Kinh Thánh, một mô tả về một nhân vật hoặc địa danh, hoặc một bài viết ngắn về một khái niệm thần học.

Từ điển Kinh Thánh khác với công cụ **Thông Tin Từ**, công cụ tra từ Hê-bơ-rơ hoặc Hy Lạp gốc đứng sau một câu. Từ điển đọc **từ tiếng Anh** bạn nhấn vào và cho bạn xem các từ điển đã cài nói gì về nó. Để xem các ghi chú dịch Kinh Thánh theo từng từ, xem hướng dẫn [Bình Giải và Từ Điển Từ Vựng](theodia://help/commentaries-and-lexicons).

## Cách mở Từ Điển

Có hai cách để mở từ điển.

### Từ menu câu

1. Mở một chương trong [Chế Độ Học Tập](theodia://help/study-mode).
2. Nhấn vào một câu để mở menu câu.
3. Nhấn **Từ Điển** (📖).

Một bảng mở ra với tiêu đề là tham chiếu câu (ví dụ, "Giăng 3:16"). Văn bản câu nằm ở trên cùng với mọi từ đều nhấn được. Dưới câu là một dải ô hiển thị mọi từ điển đã cài. Dưới đó là phần định nghĩa, vốn trống cho đến khi bạn nhấn vào một từ.

### Từ một mục từ điển từ vựng

Khi bạn đang đọc một mục trong bảng Thông Tin Từ, một số mục chứa các liên kết màu xanh dẫn đến các bài từ điển liên quan. Nhấn vào bất kỳ liên kết nào trong số đó. Từ điển từ vựng đóng lại và từ điển mở ra tại bài viết đó. Đây là cách nhanh nhất để từ một từ Hy Lạp hoặc Hê-bơ-rơ nhảy đến một lời giải thích đời thường về ý nghĩa của nó.

## Chế độ xem câu hoạt động thế nào

Khi bạn mở từ điển từ một menu câu, câu xuất hiện ở đầu bảng như một danh sách các từ có thể nhấn. Các từ tiếng Anh thông dụng như "the," "and," "of," "to," và "a" không nhấn được. Mọi từ khác thì được. Mỗi từ nhấn được có màu và in đậm để nổi bật so với phần còn lại của câu.

Nhấn vào bất kỳ từ nào trong câu. Theodia tìm kiếm trong mọi từ điển đã cài một kết quả khớp chính xác với từ đó. Dải ô ở dưới cập nhật để cho biết từ điển nào có mục: các từ điển không có mục cho từ đó bị mờ đi. Từ điển đầu tiên có mục được chọn tự động, và định nghĩa của nó xuất hiện dưới dải ô.

Từ bạn nhấn vào được đánh dấu trong văn bản câu ở đầu bảng, nên bạn luôn biết mình đang tra gì.

## Chuyển đổi giữa các từ điển

Mỗi từ điển đã cài được hiển thị như một ô nhỏ dưới câu. Sau khi nhấn vào một từ:

- Ô **màu đặc** — từ điển này có mục cho từ bạn vừa nhấn. Nhấn vào đó để chuyển sang định nghĩa của từ điển đó.
- Ô **mờ** — từ điển này không có mục cho từ đó. Nó được hiển thị mờ đi để bạn nhìn một cái là biết từ điển nào có từ đó, và ô này không thể nhấn.

Từ điển được chọn được làm nổi bật. Nhấn vào bất kỳ ô màu đặc nào khác để đọc cùng từ đó trong từ điển kia. Phần định nghĩa dưới đó cập nhật ngay lập tức.

Nếu từ chỉ tồn tại trong một trong các từ điển bạn đã cài, chỉ ô đó là màu đặc và các ô khác bị mờ.

## Bảng hiển thị những gì

Bảng từ điển có ba phần, từ trên xuống:

- **Câu Kinh Thánh** — câu mà bạn đã mở từ điển. Các từ đều nhấn được, và từ bạn vừa nhấn gần nhất được làm nổi bật.
- **Dải ô** — mọi từ điển đã cài. Màu đặc nghĩa là "có mục cho từ vừa nhấn." Mờ nghĩa là "không có mục cho từ đó."
- **Định nghĩa** — bài viết từ từ điển được chọn. Văn bản thuần, được định dạng với các đoạn và tiêu đề. Các liên kết nội bộ đến các mục từ điển khác đều nhấn được; nhấn vào một trong chúng sẽ mở mục đó trong từ điển.

## Điều gì xảy ra nếu không tìm thấy mục nào

Nếu bạn nhấn vào một từ mà không từ điển nào bạn đã cài có, bảng hiển thị một thông báo ngắn "không tìm thấy mục nào" thay cho định nghĩa. Điều này thường xảy ra với các từ rất thông dụng như "year" hay "come" vốn không phải là từ thần học Kinh Thánh thực sự, dù chúng xuất hiện khắp nơi trong Kinh Thánh. Thử một từ cụ thể hơn, hoặc dùng công cụ Thông Tin Từ của từ điển từ vựng thay thế, công cụ hoạt động trên văn bản Hy Lạp và Hê-bơ-rơ gốc.

## Điều gì xảy ra nếu không có từ điển nào được cài

Từ điển cần ít nhất một tệp tài nguyên từ điển để có ích. Theodia đi kèm một từ điển. Nếu bạn đã gỡ nó hoặc đang chạy một bản cài tùy chỉnh không có từ điển, chế độ xem câu vẫn xuất hiện và các từ vẫn nhấn được, nhưng dải ô trống và mọi tìm kiếm đều trả về "không tìm thấy mục nào."

Các từ điển thêm không thể được cài đặt riêng.

## Mẹo

- Từ điển tìm kiếm theo **khớp từ chính xác**. Nhấn vào "love" tìm thấy các mục có tiêu đề "love" nhưng không tìm thấy "loved" hay "loving." Để tra một dạng từ liên quan, dùng công cụ Thông Tin Từ của từ điển từ vựng trên từ Hy Lạp hoặc Hê-bơ-rơ.
- Dải ô giống nhau trên điện thoại và máy tính bảng. Trên máy tính bảng, từ điển mở như một bảng bên cạnh chương; trên điện thoại nó mở như một hộp toàn màn hình. Cả hai có cùng bố cục ba phần.
- Nhấn vào một từ trong một câu khác sẽ mở một câu mới trong bảng. Lựa chọn trước của bạn bị xóa. Nhấn vào một từ trong câu mới để bắt đầu một lần tra mới.
- Một số mục từ điển nhắc đến cùng từ đó trong một từ điển khác. Nhấn vào các liên kết nội bộ đó để lần theo dấu khắp các từ điển bạn đã cài.

## Khác biệt giữa Từ Điển và Thông Tin Từ

Cả hai công cụ đều mở từ menu câu, nhưng chúng làm những việc khác nhau:

- **Từ Điển** (📖) đọc từ tiếng Anh bạn nhấn vào và tìm nó trong các từ điển tiếng Anh bạn đã cài. Đây là công cụ đúng cho các định nghĩa đời thường của các từ thần học Kinh Thánh như "ước," "lễ đền tội," hay "người Pha-ri-si."
- **Thông Tin Từ** (?) đọc từ Hy Lạp hoặc Hê-bơ-rơ gốc đứng sau câu và tìm nó trong các từ điển từ vựng bạn đã cài. Đây là công cụ đúng cho các cuộc học từ nghiêm túc, tìm mọi nơi một từ Hy Lạp được dùng, và đọc các định nghĩa bằng ngôn ngữ gốc.

Khi phân vân, hãy bắt đầu với từ điển. Nếu bạn muốn đào sâu vào ngôn ngữ gốc, hãy chuyển sang Thông Tin Từ. Xem hướng dẫn [Bình Giải và Từ Điển Từ Vựng](theodia://help/commentaries-and-lexicons) để có hướng dẫn đầy đủ về Thông Tin Từ.

## Các hướng dẫn liên quan

- Hướng dẫn [Chế Độ Học Tập](theodia://help/study-mode) giải thích chi tiết menu câu và vị trí của công cụ Từ Điển (📖) cạnh Dấu Trang, Đánh Dấu, Đọc To, So Sánh, Tham Chiếu Chéo, Bình Giải Bằng AI, Thông Tin Từ, và Ghi Chú.
- Hướng dẫn [Bình Giải và Từ Điển Từ Vựng](theodia://help/commentaries-and-lexicons) nói về Thông Tin Từ và các từ điển từ vựng bằng ngôn ngữ gốc.
- Hướng dẫn [Tài Nguyên Là Gì?](theodia://help/what-are-resources) giải thích các loại tệp khác nhau mà Theodia dùng, kể cả các tài nguyên từ điển.
- Hướng dẫn [Các Vấn Đề Thường Gặp](theodia://help/common-problems) có các cách khắc phục cho kết quả trống và các vấn đề từ điển khác.
