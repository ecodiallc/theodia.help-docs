---
title: Bách khoa thư
level: everyday
categories: study
summary: Cách tra các bài bách khoa và duyệt các sách tham khảo.
---

# Bách khoa thư

Theodia bao gồm một **Bách Khoa Thư** có sẵn để tra các bài viết liên quan đến Kinh Thánh, các nhân vật, địa danh, và chủ đề. Ứng dụng đi kèm _Kitto's Illustrated Commentary_ (KIT) có sẵn, và bạn có thể tải thêm các bách khoa thư từ kho lưu trữ.

## Bách khoa thư trong Theodia là gì?

Một bách khoa thư là một sách tham khảo gồm các bài viết ngắn. Mỗi bài viết nói về một nhân vật, địa danh, sự kiện, hoặc chủ đề Kinh Thánh. Khác với bình giải — vốn giải thích một câu cụ thể — một bài bách khoa giải thích chính chủ đề đó.

## Cách mở Bách Khoa Thư

1. Nhấn **Bách Khoa Thư** trên thanh công cụ dưới cùng.
2. Chọn một bách khoa thư từ hàng các chữ viết tắt ở trên cùng.
3. Gõ một chủ đề, nhân vật, hoặc địa danh vào ô tìm kiếm.

Tìm kiếm cần ít nhất **3 ký tự** trước khi các kết quả và gợi ý tự động xuất hiện.

## Đọc một bài viết

- Trên **điện thoại**, nhấn vào bất kỳ kết quả nào để mở bài viết trên một màn hình mới.
- Trên **máy tính bảng**, bài viết mở trong bảng bên phải trong khi danh sách vẫn ở bên trái.

## Chọn bách khoa thư

Nhấn vào một ô chữ viết tắt (chẳng hạn **KIT**) để chuyển sang bách khoa thư đó. Để tìm kiếm nhiều hơn một bách khoa thư cùng lúc, dùng thẻ **Tìm Kiếm** và chọn **Bách Khoa Thư** làm chế độ tìm kiếm.

## Lấy thêm bách khoa thư

1. Mở **Cài đặt**.
2. Nhấn **Quản Lý Tài Nguyên**.
3. Nhấn **Cài Từ GitHub**.
4. Chọn thẻ **Bách Khoa Thư**.
5. Nhấn nút tải xuống cạnh bách khoa thư bạn muốn.

Các bách khoa thư được tải xuống từ kho GitHub bách khoa thư của Theodia và được cài tự động. Các bách khoa thư đã cài xuất hiện trên màn hình Bách Khoa Thư và trong Tìm Kiếm.

Bạn cũng có thể cài một bách khoa thư từ một tệp nội bộ: trong **Quản Lý Tài Nguyên**, nhấn **Cài Tệp Nội Bộ** và chọn một tệp `.encyclopedia`. Tệp được sao chép vào thư mục bách khoa thư của ứng dụng và thêm vào chỉ mục tra cứu dùng chung.

## Nhấn giữ để xem tên đầy đủ

Trên màn hình Tìm Kiếm, các ô bách khoa thư hiển thị các chữ viết tắt ngắn. Nhấn giữ một ô để xem tên đầy đủ của bách khoa thư.

## Khi nào nên dùng Bách Khoa Thư

- Tra một nhân vật, địa danh, hoặc chủ đề trước hoặc trong khi đọc một đoạn.
- Lấy bối cảnh về một từ hoặc khái niệm Kinh Thánh trải qua nhiều câu.
- Đọc cùng với một bình giải để học sâu hơn.
