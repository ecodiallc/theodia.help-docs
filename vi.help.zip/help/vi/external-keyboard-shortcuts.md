---
title: Phím tắt bàn phím ngoài
level: everyday
categories: [tablet, settings]
summary: Tra cứu đầy đủ các phím tắt bàn phím cho iPad với bàn phím ngoài gắn vào.
---

# ⌨️ Phím tắt bàn phím ngoài

Nếu bạn dùng Theodia trên iPad với một bàn phím ngoài (Magic Keyboard, bàn phím Bluetooth, hoặc bàn phím USB), bạn có thể điều hướng ứng dụng mà không cần chạm màn hình.

> **Chế độ:** Một số phím tắt chỉ hoạt động khi tính năng tương ứng có sẵn trong chế độ người dùng hiện tại của bạn. Ví dụ, `Cmd + Option + 6` (Dấu Trang) và `Cmd + Option + 7` (Đánh Dấu) không có tác dụng trong chế độ Đọc. Đổi chế độ trong **Cài đặt** → **Chế độ người dùng ứng dụng**.

Các phím tắt hoạt động trên **iPad**.

## Phím tắt toàn cục (ở bất cứ đâu)

| Phím tắt          | Hành động                                        |
| ------------------ | ------------------------------------------- |
| `Cmd + /`          | Hiển thị phần trợ giúp phím tắt bàn phím này |
| `Cmd + .`          | Đóng hộp thoại / bảng (thay thế Escape)    |
| `Cmd + Option + 1` | Đến thẻ Trang Chủ                              |
| `Cmd + Option + 2` | Đến thẻ Kinh Thánh                            |
| `Cmd + Option + 3` | Đến thẻ Sách                                 |
| `Cmd + Option + 4` | Đến thẻ Tĩnh Tâm                       |
| `Cmd + Option + 5` | Đến thẻ Tìm Kiếm                            |
| `Cmd + Option + 6` | Đến thẻ Dấu Trang (Tiêu chuẩn và Học giả)  |
| `Cmd + Option + 7` | Đến thẻ Đánh Dấu (Tiêu chuẩn và Học giả) |
| `Cmd + Option + 8` | Đến thẻ Ghi Chú (Tiêu chuẩn và Học giả)      |
| `Cmd + Option + 9` | Đến thẻ AI (chỉ Học giả, nếu được bật)     |
| `Cmd + Option + 0` | Đến thẻ Trợ Giúp                              |
| `Cmd + Option + I` | Đến thẻ Giới Thiệu                             |
| `Cmd + [`          | Quay lại                                     |
| `Cmd + F`          | Mở Tìm Kiếm                                 |
| `Cmd + K`          | Mở Menu Khởi Đầu Nhanh (Học giả)                |
| `Cmd + ,`          | Mở Cài Đặt                               |
| `Cmd + Shift + M`  | Mở menu chính                              |
| `Cmd + Shift + T`  | Chuyển vòng giao diện (mặc định / tối)                |
| `Cmd + Shift + U`  | Mở trình chọn chế độ người dùng                       |
| `Escape`           | Đóng hộp thoại / đóng bảng                 |

## Phím tắt trình đọc Kinh Thánh

Những phím này hoạt động trong cả **Trình Đọc Học Tập** và **Trình Đọc Tập Trung**.

| Phím tắt           | Hành động                                                       |
| ------------------ | ------------------------------------------------------------ |
| `← Left Arrow`     | Chương trước                                             |
| `→ Right Arrow`    | Chương sau                                                 |
| `Cmd + R`          | Chuyển đổi giữa Trình Đọc Học Tập và Trình Đọc Tập Trung (Tiêu chuẩn và Học giả) |
| `Cmd + Option + V` | Mở trình chọn bản dịch                                          |
| `Cmd + Option + B` | Mở trình chọn sách                                             |
| `Cmd + Option + C` | Mở trình chọn chương                                          |
| `Cmd + T`          | Bật/tắt TTS (ngừng khi đang phát/tạm dừng, bắt đầu khi rảnh)       |
| `Cmd + Option + T` | Phát / Tạm dừng TTS                                             |

## Chỉ trong Trình Đọc Học Tập

| Phím tắt           | Hành động                                                                 |
| ------------------ | ---------------------------------------------------------------------- |
| `↑ Up Arrow`       | Chọn câu trước                                                  |
| `↓ Down Arrow`     | Chọn câu sau                                                      |
| `Cmd + ↑`          | Chọn câu đầu tiên                                                     |
| `Cmd + ↓`          | Chọn câu cuối cùng                                                      |
| `Cmd + ←`          | Nhảy đến chương 1                                                      |
| `Cmd + →`          | Nhảy đến chương cuối                                                   |
| `Cmd + 0`–`9`      | Nhảy trực tiếp đến câu (gõ các số, ví dụ `Cmd + 1` `Cmd + 6` cho câu 16) |
| `Cmd + P`          | Bật/tắt Kinh Thánh song song (Tiêu chuẩn và Học giả)                          |
| `Cmd + B`          | Đánh dấu câu đã chọn (Tiêu chuẩn và Học giả)                         |
| `Cmd + H`          | Đánh dấu nổi bật câu đã chọn (Tiêu chuẩn và Học giả)                        |
| `Cmd + N`          | Thêm ghi chú cho câu đã chọn (Tiêu chuẩn và Học giả)                     |
| `Cmd + C`          | So sánh các bản dịch của câu đã chọn (Tiêu chuẩn và Học giả)             |
| `Cmd + X`          | Mở tham chiếu chéo cho câu đã chọn (Tiêu chuẩn và Học giả)        |
| `Cmd + I`          | Mở thông tin từ (Học giả)                                               |
| `Cmd + D`          | Mở từ điển cho câu đã chọn (Học giả)                           |
| `Cmd + A`          | Mở bảng AI cho câu đã chọn (Học giả)                             |
| `Cmd + Option + S` | Bật/tắt tiêu đề phụ                                                     |
| `Cmd + Option + W` | Đóng tất cả các bảng học tập đang mở                                            |
| `Cmd + Option + M` | Mở menu hành động cho câu                                            |

## Chỉ trong Trình Đọc Tập Trung

| Phím tắt       | Hành động           |
| -------------- | ---------------- |
| `↑ Up Arrow`   | Cuộn lên        |
| `↓ Down Arrow` | Cuộn xuống      |
| `Cmd + ↑`      | Cuộn lên đầu    |
| `Cmd + ↓`      | Cuộn xuống cuối |
| `Cmd + =`      | Phóng to          |
| `Cmd + -`      | Thu nhỏ        |

## Tìm kiếm

| Phím tắt           | Hành động                           |
| ------------------ | -------------------------------- |
| `Return`           | Thực hiện tìm kiếm                   |
| `Cmd + Return`     | Xóa tìm kiếm và đặt tiêu điểm vào ô nhập     |
| `Cmd + ↑`          | Cuộn kết quả lên                |
| `Cmd + ↓`          | Cuộn kết quả xuống              |
| `Cmd + Option + A` | Chọn tất cả các mục phạm vi           |
| `Cmd + Option + C` | Bỏ chọn tất cả các mục phạm vi         |
| `Cmd + Option + B` | Chế độ tìm kiếm Kinh Thánh                |
| `Cmd + Option + O` | Chế độ tìm kiếm Sách                 |
| `Cmd + Option + D` | Chế độ tìm kiếm Từ Điển (Học giả) |
| `Cmd + Option + X` | Chế độ tìm kiếm Từ Điển Từ Vựng (Học giả)    |

## Kết quả tìm kiếm

| Phím tắt  | Hành động              |
| --------- | ------------------- |
| `Cmd + S` | Mở trang lưu tất cả |
| `Cmd + ↑` | Cuộn kết quả lên   |
| `Cmd + ↓` | Cuộn kết quả xuống |

## Trình Đọc Sách

| Phím tắt           | Hành động                   |
| ------------------ | ------------------------ |
| `← Left Arrow`     | Chương trước         |
| `→ Right Arrow`    | Chương sau             |
| `Cmd + ↑`          | Chương trước         |
| `Cmd + ↓`          | Chương sau             |
| `↑ Up Arrow`       | Cuộn lên                |
| `↓ Down Arrow`     | Cuộn xuống              |
| `Cmd + B`          | Đánh dấu chương hiện tại |
| `Cmd + J`          | Mở trình chọn chương      |
| `Cmd + L`          | Mở trình chọn giọng đọc        |
| `Cmd + T`          | Bật/tắt TTS               |
| `Cmd + Option + T` | Phát / Tạm dừng TTS         |

## Trình Đọc Tĩnh Tâm

| Phím tắt           | Hành động              |
| ------------------ | ------------------- |
| `← Left Arrow`     | Ngày trước        |
| `→ Right Arrow`    | Ngày sau            |
| `↑ Up Arrow`       | Cuộn lên           |
| `↓ Down Arrow`     | Cuộn xuống         |
| `Cmd + ↑`          | Cuộn lên (nhiều)   |
| `Cmd + ↓`          | Cuộn xuống (nhiều) |
| `Cmd + D`          | Mở trình chọn ngày    |
| `Cmd + T`          | Bật/tắt TTS          |
| `Cmd + Option + T` | Phát / Tạm dừng TTS    |

## Trò chuyện AI

| Phím tắt           | Hành động                     |
| ------------------ | -------------------------- |
| `Cmd + Return`     | Gửi tin nhắn               |
| `Cmd + N`          | Trò chuyện mới                   |
| `Cmd + D`          | Bật/tắt ngăn trò chuyện |
| `Cmd + Option + C` | Xóa cuộc trò chuyện hiện tại         |
| `Cmd + S`          | Mở menu lưu             |
| `Escape`           | Đóng ngăn / menu        |

## Dấu Trang

| Phím tắt                      | Hành động                             |
| ----------------------------- | ---------------------------------- |
| `↑ Up Arrow` / `↓ Down Arrow` | Chọn dấu trang                    |
| `Return`                      | Mở dấu trang (máy tính bảng: chọn)     |
| `Cmd + R`                     | Đọc dấu trang trong ngữ cảnh           |
| `Cmd + M`                     | Chuyển dấu trang đã chọn vào các thư mục  |
| `Cmd + N`                     | Quản lý các thư mục                     |
| `Escape`                      | Đóng bảng chi tiết / trình chọn thư mục |

Trong trình chọn **Lưu Vào Thư Mục**, `↑ Up Arrow` / `↓ Down Arrow` di chuyển lựa chọn, `Return` bật/tắt thư mục được chọn hoặc kích hoạt hành động đang được làm nổi bật, và `Escape` đóng trình chọn. Hàng **+ Tạo Thư Mục** nằm ở đầu danh sách.

## Ghi Chú Kinh Thánh

| Phím tắt                      | Hành động                |
| ----------------------------- | --------------------- |
| `↑ Up Arrow` / `↓ Down Arrow` | Chọn ghi chú           |
| `Return`                      | Mở ghi chú             |
| `Cmd + Return`                | Đặt tiêu điểm vào ô lọc    |
| `Escape`                      | Đóng chi tiết / trình soạn |

## Đánh Dấu

| Phím tắt                      | Hành động             |
| ----------------------------- | ------------------ |
| `↑ Up Arrow` / `↓ Down Arrow` | Chọn phần đánh dấu   |
| `Return`                      | Mở phần đánh dấu     |
| `Cmd + Return`                | Đặt tiêu điểm vào ô lọc |
| `Escape`                      | Đóng bảng chi tiết |

## Danh Sách Kinh Thánh

| Phím tắt                                 | Hành động                            |
| ---------------------------------------- | --------------------------------- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | Bản Kinh Thánh sau                        |
| `← Left Arrow` / `↑ Up Arrow`            | Bản Kinh Thánh trước                    |
| `Return`                                 | Mở bản Kinh Thánh đang được chọn                |
| `Cmd + Shift + S`                        | Bật/tắt yêu thích cho bản Kinh Thánh đang được chọn |
| `Escape`                                 | Quay lại                           |

## Màn Hình Sách Của Kinh Thánh

| Phím tắt                | Hành động                     |
| ----------------------- | -------------------------- |
| `Tab` / `→ Right Arrow` | Sách sau                  |
| `← Left Arrow`          | Sách trước                  |
| `↓ Down Arrow`          | Sách phía dưới trong lưới         |
| `↑ Up Arrow`            | Sách phía trên trong lưới           |
| `Cmd + ↓`               | Phần sau (Cựu Ước / Tân Ước)     |
| `Cmd + ↑`               | Phần trước (Cựu Ước / Tân Ước) |
| `Return`                | Mở sách đang được chọn          |
| `Escape`                | Quay lại                   |

## Danh Sách Sách

| Phím tắt                                 | Hành động            |
| ---------------------------------------- | ----------------- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | Sách sau         |
| `← Left Arrow` / `↑ Up Arrow`            | Sách trước     |
| `Return`                                 | Mở sách đang được chọn |
| `Escape`                                 | Quay lại           |

## Màn Hình Chương Kinh Thánh

| Phím tắt                                 | Hành động               |
| ---------------------------------------- | -------------------- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | Chương sau         |
| `← Left Arrow` / `↑ Up Arrow`            | Chương trước     |
| `Return`                                 | Mở chương đang được chọn |
| `Escape`                                 | Quay lại              |

## Màn Hình Chương Sách

| Phím tắt               | Hành động                    |
| ---------------------- | ------------------------- |
| `Tab` / `↓ Down Arrow` | Chương sau              |
| `↑ Up Arrow`           | Chương trước          |
| `Return`               | Mở chương đang được chọn      |
| `Cmd + Return`         | Đặt tiêu điểm vào ô tìm kiếm/lọc |
| `Escape`               | Quay lại                   |

## Danh Sách Tĩnh Tâm

| Phím tắt                                 | Hành động                  |
| ---------------------------------------- | ----------------------- |
| `Tab` / `→ Right Arrow` / `↓ Down Arrow` | Tài liệu tĩnh tâm sau         |
| `← Left Arrow` / `↑ Up Arrow`            | Tài liệu tĩnh tâm trước     |
| `Return`                                 | Mở tài liệu tĩnh tâm đang được chọn |
| `Escape`                                 | Quay lại                 |

## Biểu Đồ

Trên các màn hình Thống Kê, Mục Tiêu, và Concordance.

| Phím tắt        | Hành động                                 |
| --------------- | -------------------------------------- |
| `← Left Arrow`  | Chọn loại trước trong một biểu đồ |
| `→ Right Arrow` | Chọn loại tiếp theo trong một biểu đồ     |

Chú thích dưới biểu đồ đi theo lựa chọn, và giá trị mới được đọc lên.

## Menu chính (khi đang mở)

| Phím tắt       | Hành động                  |
| -------------- | ----------------------- |
| `↑ Up Arrow`   | Mục menu trước      |
| `↓ Down Arrow` | Mục menu tiếp theo          |
| `Return`       | Chọn mục được làm nổi bật |
| `Escape`       | Đóng menu              |

## Cài Đặt

| Phím tắt | Hành động                    |
| -------- | ------------------------- |
| `Escape` | Đóng hộp thoại / trình chọn đang mở |

## Các Hộp Trình Soạn Thảo

| Phím tắt  | Hành động         |
| --------- | -------------- |
| `Cmd + S` | Lưu           |
| `Escape`  | Hủy / đóng |

## Chế độ bảo vệ khi gõ chữ

Khi bạn đang gõ trong một ô văn bản (ô tìm kiếm, trình soạn ghi chú, ô nhập AI), các phím tắt không dùng Cmd như các phím mũi tên và `Space` bị vô hiệu để chúng không vô tình kích hoạt điều hướng. Các phím tắt dùng phím `Cmd` (ví dụ, `Cmd + S`, `Cmd + B`) vẫn hoạt động trong khi gõ.
