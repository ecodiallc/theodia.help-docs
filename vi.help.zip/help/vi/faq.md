---
title: Các câu hỏi thường gặp
level: everyday
categories: faq
summary: Trả lời những câu hỏi phổ biến nhất về việc dùng Theodia.
---

# Các câu hỏi thường gặp

## Theodia có tốn tiền không?

Theodia là một lần mua duy nhất. Không có thuê bao, không có quảng cáo, không có mua hàng trong ứng dụng, và không có lời kêu gọi quyên góp. Tất cả các tài nguyên bổ sung có trong danh mục đều được tải miễn phí sau khi bạn mua ứng dụng.

## Tôi có cần kết nối internet không?

Không. Sau khi ứng dụng và các tệp dữ liệu của nó được cài, mọi thứ đều hoạt động ngoại tuyến. Bạn có thể đọc, tìm kiếm, đánh dấu nổi bật, ghi chú, và dùng hầu hết các công cụ học tập mà không cần sóng.

Tính năng duy nhất cần internet là tải xuống các tài nguyên mới.

## Dữ liệu của tôi được lưu ở đâu?

Tất cả dấu trang, phần đánh dấu, ghi chú, và cài đặt của bạn được lưu trên thiết bị của bạn. Chúng không được tải lên bất kỳ máy chủ nào.

Bạn có thể sao lưu chúng thủ công. Xem hướng dẫn [Sao lưu dữ liệu của bạn](theodia://help/backups) để biết cách làm.

## Tôi có thể nghe Kinh Thánh đọc to không?

Có. Mở bất kỳ chương nào, nhấn vào menu, và chọn tùy chọn đọc to. Thiết bị của bạn phải có một giọng đọc văn bản thành tiếng đã cài. Xem hướng dẫn [Đọc To](theodia://help/tts) để biết thêm.

## Làm thế nào để tìm một câu?

Bạn có thể gõ một tham chiếu như `John 3:16` vào ô Lệnh trên màn hình chính, hoặc dùng thẻ **Tìm Kiếm** để tìm theo từ hoặc cụm từ.

## Làm thế nào để báo lỗi hoặc đề xuất một tính năng?

Nhấn **Gửi Đề Xuất / Vấn Đề** trên màn hình Giới Thiệu, [báo cáo trên GitHub](https://github.com/ecodiallc/theodia.app/issues/new), hoặc truy cập trang [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions).

## Những thiết bị nào được hỗ trợ?

Theodia chạy trên iPhone, iPad, và các điện thoại và máy tính bảng Android. Nó hoạt động tốt nhất trên các thiết bị có ít nhất 2 GB dung lượng trống cho các tệp dữ liệu cốt lõi.

## Tôi có thể dùng bàn phím ngoài không?

Có. Theodia hỗ trợ các bàn phím Bluetooth và USB trên iPad. Điều hướng, tìm kiếm, và nhiều tính năng đọc đều có các phím tắt bàn phím. Xem hướng dẫn [Phím Tắt Bàn Phím Ngoài](theodia://help/external-keyboard-shortcuts) để có danh sách đầy đủ.

## Những ngôn ngữ nào được hỗ trợ?

Giao diện ứng dụng có sẵn bằng tiếng Anh, tiếng Ả Rập, tiếng Trung (Giản thể và Phồn thể), tiếng Séc, tiếng Đan Mạch, tiếng Hà Lan, tiếng Philippines, tiếng Pháp, tiếng Đức, tiếng Hy Lạp, tiếng Hê-bơ-rơ, tiếng Hindi, tiếng Indonesia, tiếng Ý, tiếng Nhật, tiếng Hàn, tiếng Ba Lan, tiếng Bồ Đào Nha (Brazil), tiếng Romania, tiếng Nga, tiếng Tây Ban Nha, tiếng Swahili, tiếng Thụy Điển, tiếng Thái, tiếng Thổ Nhĩ Kỳ, tiếng Ukraina, và tiếng Việt.

Ngôn ngữ của văn bản Kinh Thánh phụ thuộc vào những bản dịch nào bạn đã cài.

## Làm thế nào để đổi ngôn ngữ?

Vào **Cài đặt** và tìm tùy chọn ngôn ngữ.

## Câu hỏi của tôi không có ở đây. Tôi có thể tìm thêm trợ giúp ở đâu?

Duyệt phần còn lại của các hướng dẫn theo chủ đề, hoặc đặt một câu hỏi trong cộng đồng [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions).

Mẹo: Trên màn hình chính **Trợ Giúp & Hướng Dẫn**, dùng ô tìm kiếm để gõ một chủ đề như `notifications` hoặc `search` để tìm hướng dẫn tương ứng.
