---
title: Đọc chương đầu tiên của bạn
level: beginner
categories: [start, read]
summary: Hướng dẫn từng bước để mở và đọc một chương.
---

# Đọc chương đầu tiên của bạn

Hướng dẫn này dẫn bạn qua các bước mở một chương lần đầu tiên.

## Bước 1: Mở thẻ Kinh Thánh

Nhìn xuống dưới màn hình. Bạn sẽ thấy một hàng các thẻ. Nhấn vào thẻ có chữ **Kinh Thánh**.

## Bước 2: Chọn một sách

Bạn sẽ thấy danh sách các sách Kinh Thánh. Sáng Thế Ký ở đầu. Giăng ở gần giữa. Khải Huyền ở cuối.

Nhấn vào tên sách bạn muốn.

## Bước 3: Chọn một chương

Bạn sẽ thấy các số từ 1 đến số chương mà sách có. Nhấn vào chương bạn muốn.

Chương mở ra. Các câu hiện trên màn hình.

## Bước 4: Di chuyển

- Vuốt **trái** để sang chương tiếp theo.
- Vuốt **phải** để quay lại.

## Bước 5: Tương tác với một câu

Những gì bạn có thể làm với một câu phụ thuộc vào chế độ người dùng của bạn.

### Chế độ Đọc

Chế độ Đọc sạch sẽ và không bị làm phiền.

- Nhấn vào một câu để làm nổi bật nó trong chốc lát.
- Không có công cụ học tập, dấu trang, hay menu nào cả.
- Nếu bạn muốn nhiều tính năng hơn, hãy chuyển sang chế độ **Tiêu chuẩn** hoặc **Học giả** trong **Cài đặt**.

### Chế độ Tiêu chuẩn

Chế độ Tiêu chuẩn bổ sung các tính năng hàng ngày cho việc học Kinh Thánh cá nhân.

Nhấn vào một câu để mở menu với các tùy chọn sau:

- **Đánh dấu** câu đó.
- **Đánh dấu nổi bật** nó bằng một màu.
- **Thêm một ghi chú** cho nó.
- **Sao chép** văn bản câu.
- **So sánh** câu đó trong một bản dịch khác.
- **Tra tham chiếu chéo** cho câu đó.

### Chế độ Học giả

Chế độ Học giả mở khóa mọi công cụ cho việc học Kinh Thánh sâu.

Nhấn vào một câu để mở menu với tất cả những gì có trong chế độ Tiêu chuẩn, cộng thêm:

- **Bình giải** cho câu đó.
- **Thông Tin Từ** và các tra cứu bằng ngôn ngữ gốc.
- Các định nghĩa **Từ Điển**.
- **Trợ lý AI** để học sâu hơn.

Bạn có thể đổi chế độ bất cứ lúc nào trong **Cài đặt**.

## Cần trợ giúp về một công cụ cụ thể?

Mỗi công cụ có hướng dẫn riêng. Nhấn **Trợ Giúp** trên trang chủ để xem tất cả. Hướng dẫn [Chế Độ Học Tập](theodia://help/study-mode) là một điểm bắt đầu tốt — nó đi qua từng công cụ trong menu câu.

Nếu bạn vẫn đang làm quen với vị trí các thứ, xem hướng dẫn [Bố Cục và Điều Hướng Ứng Dụng](theodia://help/navigating-the-app). Nó giải thích màn hình chính, menu chính, và thanh công cụ dưới cùng.

## Muốn thêm tài nguyên?

Ứng dụng đi kèm vài bản Kinh Thánh có sẵn miễn phí. Nếu bạn muốn thêm nữa, hoặc thêm bình giải, sách, hoặc tài liệu tĩnh tâm, xem hướng dẫn [Lấy Thêm Tài Nguyên Từ GitHub](theodia://help/getting-core-files). Nó chỉ cho bạn chỗ tìm chúng và cách thêm chúng.
