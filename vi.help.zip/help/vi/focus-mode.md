---
title: Chế độ Tập Trung
level: beginner
categories: [layout, read]
summary: Một cách đọc sạch sẽ, không bị làm phiền cho các đoạn dài.
---

# Chế độ Tập Trung

> **Chế độ:** Chế độ Tập Trung là trình đọc trong chế độ **Đọc**. Nó cũng có trong chế độ **Tiêu chuẩn** và **Học giả** như một lựa chọn thay thế cho Chế Độ Học Tập. Bạn có thể đổi chế độ trong **Cài đặt** → **Chế độ người dùng ứng dụng**.

Chế độ Tập Trung là một cách đọc một chương Kinh Thánh không bị các nút hay menu che lấp. Nó tốt cho những buổi đọc dài.

## Cách bật nó

1. Mở bất kỳ chương nào.
2. Trong hàng các biểu tượng ở đầu màn hình, nhấn nút 📖. Nó mở cùng chương đó trong Chế Độ Tập Trung.
3. Các menu và nút được ẩn đi. Chỉ còn văn bản Kinh Thánh.

Trong chế độ **Đọc**, các chương mở trong Chế Độ Tập Trung tự động. Nút 📖 bị ẩn vì không có Chế Độ Học Tập nào để chuyển sang.

## Bạn có thể làm gì trong Chế Độ Tập Trung

- **Cuộn** để đọc.
- **Vuốt** để sang chương trước hoặc sau.
- **Nhấn nút 📖** trên thanh dưới để chuyển lại sang Chế Độ Học Tập. (Bị ẩn trong chế độ Đọc.)
- **Nhấn nút 🔊** trên thanh dưới để cho chương được đọc to. Một thanh điều khiển nhỏ xuất hiện với các nút phát, tạm dừng, tua lại, tua nhanh, và chọn giọng đọc. (Bị ẩn trong chế độ Đọc — TTS yêu cầu Tiêu chuẩn hoặc Học giả.)

## Một cách dùng hay cho Chế Độ Tập Trung

- Đọc qua cả một cuốn sách, mỗi lần một chương.
- Đọc một đoạn dài cho một buổi tĩnh tâm hay thời gian yên lặng.
- Đọc to và đọc theo mà không bị phân tâm.

## Chuyển sang Chế Độ Học Tập

Chế độ Tập Trung ẩn mọi công cụ học tập, nhưng chúng vẫn chỉ cách một lần nhấn. Nhấn nút 📖 ở đầu màn hình để mở cùng chương đó trong [Chế Độ Học Tập](theodia://help/study-mode). Chế Độ Học Tập là trình đọc đầy đủ, với bình giải, tham chiếu chéo, tra từ điển từ vựng, và ghi chú. Để tìm hiểu Chế Độ Học Tập có thể làm gì, xem hướng dẫn [Chế Độ Học Tập](theodia://help/study-mode).

Trong chế độ **Đọc**, nút 📖 bị ẩn vì Chế Độ Học Tập không có sẵn.
