---
title: Di chuyển nhanh
level: beginner
categories: layout
summary: Mọi cách nhanh để nhảy đến một câu, chương, hoặc màn hình trong Theodia.
---

# Di chuyển nhanh

Hướng dẫn này là một bảng ghi nhanh về điều hướng. Nó bao gồm mọi cách nhanh để đi từ nơi bạn đang ở đến nơi bạn muốn đến.

## Nhảy thẳng đến một câu

Cách nhanh nhất để mở bất kỳ câu nào là ô **Lệnh** trên màn hình chính.

- Gõ `John 3:16` rồi nhấn Go.
- Gõ `Psalms 23` rồi nhấn Go.
- Gõ `Genesis 1` rồi nhấn Go.

Ứng dụng mở đúng chương đó (và cuộn đến câu nếu bạn có ghi rõ).

## Vuốt giữa các chương

Khi bạn đang đọc một chương:

- **Vuốt trái** → chương tiếp theo.
- **Vuốt phải** → chương trước.

Điều này hoạt động qua các sách. Sau Xuất Ê-díp-tô Ký 40, vuốt trái đưa bạn đến Lê-vi Ký 1.

## Dùng thanh trên cùng

Trong khi đọc, phần trên màn hình hiển thị **bản dịch**, **sách**, và **chương** hiện tại.

- Nhấn vào tên bản dịch để đổi Kinh Thánh.
- Nhấn vào tên sách để chọn một sách khác.
- Nhấn vào số chương để chọn một chương khác.

## Nhảy từ một dấu trang

Nếu bạn đã lưu một câu:

1. Mở thẻ **Dấu Trang**.
2. Nhấn vào bất kỳ mục nào.
3. Bạn được đưa thẳng đến câu đó.

## Nhảy từ kết quả tìm kiếm

1. Mở thẻ **Tìm Kiếm**.
2. Gõ một từ hoặc cụm từ.
3. Nhấn vào bất kỳ kết quả nào.
4. Ứng dụng mở chương với các từ tìm kiếm của bạn được làm nổi bật màu vàng.

## Đổi bố cục đọc

Trình đọc Kinh Thánh có hai bố cục:

- **Chế Độ Học Tập** — hiển thị chương với mọi công cụ học tập cách một lần nhấn.
- **Chế Độ Tập Trung** — ẩn mọi công cụ và menu, chỉ để lại văn bản.

Để chuyển đổi: nhấn nút **📖** ở đầu màn hình trong khi đọc. Nhấn lại để chuyển về. (Chế độ Đọc luôn ở trong Chế Độ Tập Trung.)

## Dùng các thẻ dưới cùng

Hàng biểu tượng ở dưới màn hình luôn hiện ra. Nhấn vào bất kỳ thẻ nào để chuyển sang phần đó. Các thẻ chính xác phụ thuộc vào chế độ người dùng của bạn:

**Tất cả các chế độ:**

- **Trang Chủ** — quay lại màn hình chính.
- **Kinh Thánh** — danh sách các bản dịch.
- **Tìm Kiếm** — tìm kiếm trong Kinh Thánh, sách, từ điển, từ điển từ vựng, và PDF.
- **Cài Đặt** — tùy chọn và tài nguyên.

**Tiêu chuẩn và Học giả còn thấy:**

- **Dấu Trang** — các câu đã lưu.
- **Đánh Dấu** — các câu được đánh dấu bằng màu.
- **Ghi Chú** — ghi chú riêng tư của bạn.
- **PDF** — các tài liệu PDF bạn đã nhập.

**Học giả còn thấy:**

- **AI** — trợ lý AI (nếu đã bật trong Cài Đặt).

### Nhớ nơi bạn đang dừng

Mỗi thẻ giữ lịch sử điều hướng riêng của mình. Khi bạn chuyển lại một thẻ, bạn quay về **nơi bạn đã dừng**, chứ không phải màn hình khởi đầu của phần đó.

- Bạn mở thẻ **Kinh Thánh**, chọn một bản dịch, mở một chương, rồi chuyển sang **Tìm Kiếm**. Sau đó bạn nhấn lại **Kinh Thánh** và bạn đứng ngay tại cùng chương đó.
- Bạn mở thẻ **Dấu Trang**, nhấn vào một câu đã đánh dấu, rồi chuyển sang **Cài Đặt**. Nhấn lại **Dấu Trang** sẽ đưa bạn về danh sách dấu trang.

Điều này áp dụng cho mọi thẻ. Mỗi thẻ nhớ vị trí của bạn cho đến khi bạn chủ động điều hướng đến một màn hình khác bên trong thẻ đó.

### Điều gì đặt lại một thẻ

Một thẻ chỉ quay về màn hình gốc khi:

- Bạn đang ở thẻ đó và bạn nhấn lại cùng biểu tượng thẻ đó. Đây là cách nhanh để đặt lại nó về điểm bắt đầu.
- Ứng dụng bị buộc đóng rồi mở lại.

### Các thẻ dưới cùng so với menu chính

- **Các thẻ dưới cùng** — mỗi thẻ nhớ chồng màn hình riêng của mình. Nhấn vào một thẻ đưa bạn về nơi bạn đã dừng.
- **Menu chính** — nhấn vào một mục sẽ điều hướng đến màn hình đó. Đó là một danh sách thả xuống, không phải một lớp phủ.

Ví dụ:

- Bạn đang đọc Giăng 3. Nhấn thẻ **Dấu Trang**, rồi nhấn lại **Kinh Thánh**. Bạn quay về Giăng 3.
- Bạn đang đọc Giăng 3. Mở menu và nhấn **Ghi Chú**. Xem lại các ghi chú của bạn, rồi nhấn thẻ **Kinh Thánh** để quay về Giăng 3.

## Mẹo

- Màn hình chính nhớ phần nào được mở rộng hoặc thu gọn.
- Nếu một thẻ bị thiếu, hãy kiểm tra **chế độ người dùng** của bạn trong **Cài đặt** → **Chế độ người dùng ứng dụng**. Chế độ Đọc ẩn dấu trang, đánh dấu, ghi chú, và AI. Chế độ Tiêu chuẩn ẩn AI. Bạn cũng có thể cần bật một tính năng trong **Cài đặt** hoặc cài một tài nguyên.
