---
title: Lấy thêm tài nguyên
level: everyday
categories: resources
summary: Cách thêm các bản Kinh Thánh, bình giải, sách, và các tài nguyên khác vào Theodia.
---

# Lấy thêm tài nguyên

Theodia đi kèm một số tài nguyên có sẵn, nhưng bạn có thể thêm nhiều hơn. Cách dễ nhất là qua màn hình **Quản Lý Tài Nguyên** trong ứng dụng.

## Bạn có thể thêm gì

- **Kinh Thánh** — thêm các bản dịch bằng nhiều ngôn ngữ khác nhau
- **Bình Giải** — các ghi chú học tập giải thích các câu
- **Sách** — các sách kinh điển Cơ Đốc và sách tham khảo
- **Tài Liệu Tĩnh Tâm** — các bài đọc tĩnh tâm hàng ngày
- **Tệp cốt lõi** — các tệp dữ liệu lớn như hình thái học, tham chiếu chéo, và Kinh Thánh Song Ngữ Marvel Interlinear Bible (MIB)

## Cách thêm tài nguyên từ trong ứng dụng

1. Mở **Cài đặt**.
2. Nhấn **Quản Lý Tài Nguyên**.
3. Chọn một thẻ: **Cốt Lõi**, **Kinh Thánh**, **Bình Giải**, **Sách**, hoặc **Tĩnh Tâm**.
4. Duyệt danh sách. Nhấn vào một tài nguyên để đọc thêm về nó.
5. Nhấn vào ô đánh dấu để chọn những thứ bạn muốn.
6. Nhấn **Tải Xuống** ở dưới cùng. Các tệp được tải xuống và cài tự động.

Sau khi cài, tài nguyên xuất hiện trong ứng dụng ngay lập tức. Bạn không cần khởi động lại.

## Các tệp cốt lõi

Thẻ **Cốt Lõi** có các tệp dữ liệu lớn nuôi các tính năng học sâu. Chúng bao gồm:

- Dữ liệu hình thái học (các dạng từ bằng ngôn ngữ gốc)
- Các cơ sở dữ liệu tham chiếu chéo
- Kinh Thánh Song Ngữ Marvel Interlinear Bible (MIB)

Bạn chỉ cần tải các tệp cốt lõi một lần. Chúng nằm trên thiết bị của bạn và hoạt động ngoại tuyến.

## Kinh Thánh Toàn Cầu

Thẻ **Kinh Thánh Toàn Cầu** có các bản dịch Kinh Thánh từ một bộ sưu tập rộng hơn. Nếu bạn không thấy một bản dịch mình muốn trong thẻ **Kinh Thánh** chính, hãy tìm ở đây.

## Quản lý các tài nguyên đã cài

Trên màn hình chính **Quản Lý Tài Nguyên** (không phải thẻ tải xuống), bạn có thể:

- **Bật hoặc tắt** một tài nguyên mà không xóa nó. Các tài nguyên bị tắt vẫn nằm trên thiết bị của bạn nhưng bị ẩn khỏi các menu.
- **Xóa** một tài nguyên để giải phóng bộ nhớ. Bạn có thể tải lại nó sau.

## Thêm tệp của riêng bạn

Nếu bạn có một tệp tài nguyên từ nơi khác — một người bạn, một dự án khác, hoặc một trang web — bạn có thể nhập trực tiếp:

1. Trong **Quản Lý Tài Nguyên**, nhấn **Nhập Tệp Nội Bộ**.
2. Chọn tệp từ thiết bị của bạn.
3. Ứng dụng đọc tệp và thêm nó vào thư viện của bạn.

Ứng dụng chấp nhận các loại tệp sau:

- `.bible` — các bản dịch Kinh Thánh
- `.commentary` — các bình giải
- `.lexicon` — các từ điển từ vựng
- `.book` — các sách
- `.devotional` — các tài liệu tĩnh tâm

## Kết nối một kho GitHub tùy chỉnh

Nếu ai đó duy trì một kho GitHub chứa các tài nguyên tương thích Theodia, bạn có thể thêm nó như một nguồn tùy chỉnh:

1. Vào **Cài đặt → Kho GitHub**.
2. Nhấn **Thêm Kho**.
3. Nhập URL GitHub (ví dụ, `https://github.com/username/repo-name`).
4. Chọn kho chứa những loại tài nguyên nào (Kinh Thánh, bình giải, hoặc sách).
5. Lưu lại.
6. Quay về **Quản Lý Tài Nguyên**. Một thẻ mới xuất hiện với các tài nguyên từ kho đó.

Nếu kho là riêng tư, bạn sẽ cần thêm một **Mã Truy Cập Cá Nhân** trong **Cài đặt → Kho GitHub** để ứng dụng có thể đọc nó.

## Một lưu ý về kích thước tệp

Các tệp tài nguyên có thể lớn. Các bản Kinh Thánh thường nhỏ (vài megabyte). Bình giải và các tệp cốt lõi có thể lớn hơn nhiều (hàng trăm megabyte). Hãy tải qua Wi-Fi khi có thể.

## Tóm tắt

- Dùng **Cài đặt → Quản Lý Tài Nguyên** để duyệt và cài các tài nguyên.
- Các tệp cốt lõi mở khóa các công cụ học sâu như hình thái học và tham chiếu chéo.
- Nhập các tệp nội bộ nếu bạn có sẵn của riêng mình.
- Thêm các kho GitHub tùy chỉnh nếu bạn muốn tài nguyên từ một nguồn khác.
