---
title: Hỏi Đáp Ở Đâu
level: everyday
categories: trouble
summary: Cách nhận trợ giúp từ đội ngũ và cộng đồng Theodia, và cách tìm các chủ đề trợ giúp trong ứng dụng.
---

# Hỏi Đáp Ở Đâu

Nếu bạn gặp khó khăn, có một vài nơi để xin trợ giúp.

## Tìm một chủ đề trợ giúp

Nếu bạn đang tìm thông tin về một tính năng cụ thể, hãy thử một trong các cách sau:

- **Duyệt theo danh mục.** Mở **Trợ Giúp & Hướng Dẫn** và nhấn vào một danh mục như **Cài Đặt & Tùy Biến** hoặc **Xử Lý Sự Cố**. Mỗi thẻ liệt kê các hướng dẫn liên quan.
- **Tìm theo từ khóa.** Trên màn hình chính **Trợ Giúp & Hướng Dẫn**, gõ một từ vào ô tìm kiếm ở trên cùng. Ví dụ, gõ `notifications` hiển thị hướng dẫn [Thông Báo và Nhắc Nhở](theodia://help/notifications); gõ `search` hiển thị hướng dẫn [Tìm Kiếm Kinh Thánh](theodia://help/search-the-bible).
- **Kiểm tra Cài Đặt trước.** Nhiều tính năng được cấu hình trong **Cài đặt**. Nếu bạn muốn thiết lập nhắc nhở, hãy mở **Cài đặt** → **Thông Báo**. Màn hình cài đặt cũng có một liên kết **Trợ Giúp** cho từng phần.

## Trong ứng dụng

Mở màn hình **Giới Thiệu**. Bạn sẽ thấy hai nút:

- **Gửi Đề Xuất / Vấn Đề** — mở một biểu mẫu để gửi cho đội ngũ một câu hỏi, một ý tưởng, hoặc một báo cáo lỗi.
- **Thảo Luận / Phản Hồi** — mở bảng thảo luận cộng đồng.

## Trang GitHub

Bạn có thể xem danh sách các vấn đề đã biết và các thay đổi gần đây trên [GitHub](https://github.com/ecodiallc/theodia.app).

## Thảo luận cộng đồng

Những người dùng Theodia khác đặt câu hỏi và chia sẻ mẹo trong [bảng thảo luận cộng đồng](https://github.com/ecodiallc/theodia.app/discussions). Bạn có thể đọc các luồng cũ và bắt đầu một luồng mới.

## Trước khi bạn hỏi

Một vài điều giúp chúng tôi trả lời bạn nhanh hơn:

- **Thiết bị của bạn là gì?** (ví dụ iPhone 13, Pixel 7)
- **Phiên bản ứng dụng nào?** (Mở **Giới Thiệu** để xem.)
- **Bạn đã làm gì?** Một mô tả ngắn về các bước.
- **Điều gì đã xảy ra?** Những gì bạn thấy trên màn hình.
- **Bạn kỳ vọng điều gì sẽ xảy ra?** Đây thường là phần hữu ích nhất.

## Những gì bạn có thể chờ đợi

- Với các báo cáo lỗi, đội ngũ thường trả lời trong vài ngày.
- Với các ý tưởng, đội ngũ đọc tất cả. Chúng tôi không thể hứa khi nào một ý tưởng sẽ được thêm vào.
- Với các câu hỏi cộng đồng, các người dùng khác thường trả lời nhanh hơn đội ngũ.

## Một lưu ý về quyền riêng tư

Khi bạn gửi một câu hỏi, xin đừng bao gồm thông tin riêng tư. Đội ngũ có thể thấy những gì bạn gửi đi.
