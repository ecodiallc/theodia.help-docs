---
title: GitHub Models
categories: ai
level: advanced
summary: Thiết lập GitHub Models — một cách miễn phí để bắt đầu khám phá AI trong Theodia mà không cần thuê bao API có sẵn.
---

# GitHub Models

> **Chế độ:** Trợ lý AI yêu cầu chế độ **Học giả**. Bạn có thể đổi chế độ trong **Cài đặt** → **Chế độ người dùng ứng dụng**.

Nếu bạn chưa trả tiền cho một dịch vụ AI nào, **GitHub Models** là cách dễ nhất để bắt đầu khám phá AI của Theodia. Nó cho phép bạn bắt đầu miễn phí, và tất cả những gì bạn cần là một tài khoản GitHub miễn phí.

## GitHub Models là gì?

GitHub Models là một dịch vụ của GitHub cho phép bạn chạy các mô hình AI hiện đại qua một API. Nó hỗ trợ cùng định dạng với OpenAI, nên nó hoạt động liền mạch với Theodia.

## Vì sao chọn GitHub Models?

- **Không cần thẻ tín dụng** — Chỉ cần một tài khoản GitHub.
- **Các mô hình chất lượng cao** — Bạn được truy cập GPT-4o, GPT-4.1, và các mô hình đáng tin cậy khác hỗ trợ các công cụ của Theodia.
- **Thiết lập dễ dàng** — Một mã, một URL, là xong.

## Bước 1: Tạo một tài khoản GitHub

Nếu bạn đã có tài khoản GitHub, hãy bỏ qua đến Bước 2.

1. Vào [github.com](https://github.com).
2. Nhấn **Sign up** và làm theo các hướng dẫn để tạo một tài khoản miễn phí.
3. Xác minh địa chỉ email của bạn khi GitHub gửi thư xác nhận.

## Bước 2: Tạo một Mã Truy Cập Cá Nhân

Mã này là khóa API của bạn. Nó cho GitHub biết bạn là ai khi Theodia gửi các câu hỏi.

1. Vào [github.com/settings/tokens](https://github.com/settings/tokens).
2. Nhấn **Generate new token** và chọn **Generate new token (classic)**.
3. Đặt cho mã một cái tên như **Theodia AI**.
4. Trong phần **Select scopes**, đánh dấu ô **`models:read`**.
   - Đây là quyền duy nhất Theodia cần.
5. Cuộn xuống dưới cùng và nhấn **Generate token**.
6. **Sao chép mã ngay lập tức.** GitHub chỉ hiển thị nó một lần. Dán nó vào một nơi an toàn (như ứng dụng ghi chú trên điện thoại của bạn) cho đến khi bạn thêm nó vào Theodia.

## Bước 3: Chọn một mô hình

GitHub Models cung cấp vài mô hình. Đối với Theodia, đây là các lựa chọn tốt nhất:

| Mô hình               | Giới hạn miễn phí mỗi ngày | Phù hợp nhất với                          |
| --------------------- | ------------------ | --------------------------------------------- |
| `openai/gpt-4.1-nano` | 150 yêu cầu / ngày | Câu hỏi nhanh và giải thích câu đơn giản |
| `openai/gpt-4.1-mini` | 150 yêu cầu / ngày | Học tập tổng quát với hỗ trợ công cụ tốt          |
| `openai/gpt-4.1`      | 50 yêu cầu / ngày  | Học sâu và các câu hỏi phức tạp nhiều bước |
| `openai/gpt-4o`       | 50 yêu cầu / ngày  | Đa năng, hỗ trợ công cụ xuất sắc             |

Hãy bắt đầu với **`openai/gpt-4.1-mini`** — nó nhanh, đáng tin cậy, và có hạn mức yêu cầu hàng ngày cao hơn.

## Bước 4: Cấu hình Theodia

1. Mở **Theodia**.
2. Vào **Cài đặt** → **Trợ lý AI**.
3. Đảm bảo **Mô hình từ xa** đã được chọn.
4. Nhấn danh sách thả xuống **Nhà cung cấp** và chọn **GitHub Models**.
   - Nếu GitHub Models không có trong danh sách, hãy nhấn **Tùy chỉnh** và nhập URL gốc bằng tay: `https://models.github.ai`
5. Dán Mã Truy Cập Cá Nhân GitHub của bạn vào ô **Khóa API**.
6. Nhập ID mô hình bạn đã chọn vào ô **Mô hình** (ví dụ: `openai/gpt-4.1-mini`).
7. Nhấn **Kiểm tra kết nối**.
8. Đợi việc kiểm tra hoàn tất. Bạn sẽ thấy:
   - **✓ Kết nối thành công**
   - **✓ Hỗ trợ công cụ**

Nếu bạn thấy **✗ Không hỗ trợ công cụ**, hãy thử một ID mô hình khác trong bảng trên.

## Bước 5: Bắt đầu trò chuyện

1. Nhấn thẻ **AI** ở cuối màn hình.
2. Gõ một câu hỏi và nhấn **Gửi**.
3. Hoặc, trong khi đọc bất kỳ chương Kinh Thánh nào, hãy nhấn vào một số câu và chọn **Bình Giải Bằng AI** để bắt đầu một cuộc trò chuyện riêng cho câu đó.

## Xử lý sự cố

### "Kết nối thất bại" hoặc "HTTP 401"

- Đảm bảo bạn đã sao chép **toàn bộ** mã. Đó là một chuỗi dài bắt đầu bằng `ghp_`.
- Các mã hết hạn nếu lâu không dùng. Hãy quay lại GitHub và tạo một mã mới.
- Kiểm tra rằng bạn đã chọn **models:read** khi tạo mã.

### "Không hỗ trợ công cụ"

- Một số mô hình trên GitHub Models không chấp nhận các lần gọi công cụ. Hãy thử **`openai/gpt-4o`** hoặc **`openai/gpt-4.1-mini`** thay thế.
- Đảm bảo ID mô hình được viết đúng chính xác như hiển thị, kể cả tiền tố `openai/`.

### Lỗi giới hạn tần suất

- Nếu bạn chạm đến giới hạn hàng ngày, hãy chuyển sang một mô hình có hạn mức cao hơn (như `openai/gpt-4.1-nano` với 150 yêu cầu mỗi ngày).
- Các giới hạn được đặt lại mỗi 24 giờ.

## Tóm tắt

- GitHub Models là **cách được khuyên dùng để bắt đầu khám phá AI** trong Theodia.
- Bạn cần một **tài khoản GitHub miễn phí** và một **Mã Truy Cập Cá Nhân** có quyền `models:read`.
- Mô hình khởi đầu tốt nhất là **`openai/gpt-4.1-mini`**.
- Nhập mã và mô hình trong **Cài đặt → Trợ lý AI**, nhấn **Kiểm tra kết nối**, và bắt đầu trò chuyện.
