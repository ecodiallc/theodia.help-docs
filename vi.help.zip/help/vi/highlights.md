---
title: Đánh dấu nổi bật các câu
level: everyday
categories: [annotate, read]
summary: Cách đánh dấu các câu bằng màu và tìm lại chúng sau này.
---

# Đánh dấu nổi bật các câu

> **Chế độ:** Tính năng Đánh Dấu Nổi Bật có sẵn trong chế độ **Tiêu chuẩn** và **Học giả**. Chế độ Tập Trung chỉ dành cho việc đọc sạch sẽ, không bị làm phiền. Bạn có thể đổi chế độ trong **Cài đặt** → **Chế độ người dùng ứng dụng**.

Đánh dấu nổi bật tô màu cho một câu. Nó hoạt động như một cây bút dạ quang màu vàng trên giấy. Câu vẫn giữ màu đánh dấu lần sau khi bạn mở lại.

## Cách đánh dấu nổi bật một câu

1. Mở câu đó.
2. Nhấn vào câu để hiện menu.
3. Nhấn biểu tượng **Đánh Dấu Nổi Bật**.
4. Chọn một màu.

Câu bây giờ được đánh dấu nổi bật bằng màu đó.

## Cách đổi màu đánh dấu

1. Mở câu đó.
2. Nhấn vào câu, rồi nhấn biểu tượng **Đánh Dấu Nổi Bật**.
3. Chọn một màu mới.

## Cách gỡ một phần đánh dấu

1. Mở câu đó.
2. Nhấn vào câu, rồi nhấn **Đánh Dấu Nổi Bật** trong menu.
3. Nhấn **Gỡ Đánh Dấu** ở dưới cùng của bảng chọn màu.

## Một cách dùng màu phổ biến

Nhiều người đọc dùng một bộ màu nhỏ cho một số mục đích nhỏ:

- **Vàng** cho những câu yêu thích nói chung.
- **Xanh lá** cho các câu về Đức Chúa Trời.
- **Xanh dương** cho các câu về cầu nguyện.
- **Hồng** cho các câu về sự an ủi.
- **Cam** cho các câu về sự cảnh bảo hay sửa phạt.
- **Tím** cho các câu về tiên tri hay thời kỳ cuối cùng.

Hãy chọn một hệ thống phù hợp với bạn.

## Cách xem tất cả các phần đánh dấu của bạn

Nhấn thẻ **Đánh Dấu** ở dưới cùng. Bạn thấy danh sách mọi câu bạn đã đánh dấu, mới nhất lên đầu. Có một hàng ô màu ở trên cùng — nhấn vào một màu để chỉ hiện các phần đánh dấu màu đó, hoặc nhấn **Tất Cả** để xóa bộ lọc.

## Nhập các phần đánh dấu

Bạn có thể đưa các phần đánh dấu vào Theodia từ các ứng dụng và tệp khác.

Vào **Cài đặt** → **Dấu Trang** → **Nhập Đánh Dấu**. Chọn **Nhập Từ Tệp** hoặc dán từ bảng tạm. Ứng dụng tự động nhận diện định dạng.

### Các định dạng được hỗ trợ

**Xuất JSON gốc** — Định dạng mà tính năng xuất của chính Theodia dùng:

```json
{
  "/bible/KJV/John/3#v3_16": "yellow",
  "/bible/KJV/Genesis/1#v1_1": "green"
}
```

**CSV** — Một bảng tính với các cột `url` và `color`. Ví dụ:

```csv
url,color
/bible/KJV/John/3#v3_16,yellow
/bible/KJV/Genesis/1#v1_1,green
```

**Văn bản thuần** — Mỗi dòng là một tham chiếu Kinh Thánh hoặc URL, tùy chọn theo sau là một tên màu. Ví dụ:

```
John 3:16 yellow
Genesis 1:1 green
Matthew 5:1
```

- Các màu có sẵn: `yellow`, `green`, `blue`, `pink`, `orange`, `purple`.
- Nếu không có màu nào được ghi, phần đánh dấu mặc định là màu vàng.
- Các dòng bắt đầu bằng `#` hoặc `//` được coi là ghi chú và bị bỏ qua.

## Mẹo

- Các phần đánh dấu nằm trên thiết bị của bạn. Chúng không đồng bộ lên đám mây.
- Bạn có thể đánh dấu nổi bật một câu trong một bản dịch và nó cũng xuất hiện trong các bản dịch khác của cùng câu đó.
- Xem hướng dẫn [Sao lưu dữ liệu của bạn](theodia://help/backups) để giữ chúng an toàn.
