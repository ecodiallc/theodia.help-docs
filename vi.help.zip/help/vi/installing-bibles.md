---
title: Cài đặt bản dịch Kinh Thánh
level: beginner
categories: start
summary: Cách thêm một bản dịch Kinh Thánh vào thư viện của bạn.
---

# Cài đặt bản dịch Kinh Thánh

Theodia đã sẵn sàng một vài bản dịch Kinh Thánh để đọc ngay. Bạn có thể thêm bản khác bất cứ lúc nào. "Bản dịch" là một phiên bản khác của văn bản Kinh Thánh, chẳng hạn như King James Version.

## Cách thêm một bản dịch

Thẻ Kinh Thánh hiển thị danh sách các bản dịch đã được cài đặt. Để thêm bản khác, hãy mở trình quản lý tài nguyên:

1. Mở **Cài đặt**.
2. Chạm **Quản lý tài nguyên**.
3. Chạm **Cài đặt từ GitHub**.
4. Trong cửa sổ tải xuống, chạm thẻ **Kinh Thánh**.
5. Chạm ô đánh dấu bên cạnh mỗi bản dịch bạn muốn.
6. Chạm **Cài đặt mục đã chọn** ở dưới cùng.
7. Chờ tải xuống hoàn tất.

Bản dịch này nay đã có trong thư viện của bạn. Để xem, hãy mở thẻ **Kinh Thánh**.

## Cách chuyển giữa các bản dịch

1. Mở một chương bạn muốn đọc.
2. Chạm tên bản dịch ở đầu màn hình.
3. Chọn bản dịch bạn muốn từ danh sách.

Ứng dụng sẽ lưu lựa chọn của bạn cho lần sau.

## Cách gỡ một bản dịch

1. Mở **Cài đặt**.
2. Chạm **Quản lý tài nguyên**.
3. Tìm bản dịch bạn muốn gỡ.
4. Chạm **X** bên cạnh nó.
5. Xác nhận bạn muốn gỡ.

Gỡ một bản dịch không xóa ghi chú, phần đánh dấu hay dấu trang của bạn. Những mục đó vẫn được giữ an toàn.

## Bản dịch chiếm bao nhiêu dung lượng?

Hầu hết các bản dịch có dung lượng từ 2 đến 10 MB. Chúng được lưu trên thiết bị của bạn, không phải trên đám mây. Bạn có thể giữ bao nhiêu tùy thích, miễn là thiết bị còn chỗ trống.

## Nếu bản dịch không có trong ứng dụng thì sao?

Một số bản dịch không có trong danh sách của ứng dụng. Bạn vẫn có thể thêm chúng.

1. Mở ứng dụng và đi tới **Cài đặt** → **Quản lý tài nguyên**.
2. Chạm **Cài đặt từ GitHub**.
3. Trong cửa sổ tải xuống, xem thẻ **Kinh Thánh** và thẻ **Kinh Thánh toàn cầu**. Nếu có bản dịch của bạn, hãy chọn nó và chạm **Cài đặt mục đã chọn**.
4. Nếu không có, chạm **Cài đặt tệp cục bộ** để nhập tệp `.bible`. Hãy tải tệp từ trang GitHub của dự án. Xem hướng dẫn [Tải tài nguyên bổ sung từ GitHub](theodia://help/getting-core-files) để được trợ giúp từng bước.
