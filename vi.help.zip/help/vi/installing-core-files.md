---
title: Thêm các tệp cốt lõi
level: beginner
categories: start
summary: Cách tải xuống các tệp dữ liệu lớn mà ứng dụng cần để nghiên cứu Kinh Thánh sâu sắc hơn.
---

# Thêm các tệp cốt lõi

Theodia đã có sẵn một Kinh Thánh và vài tiện ích nhỏ để dùng ngay. Để tận dụng tối đa ứng dụng, bạn cũng cần tải xuống **các tệp cốt lõi**. Đây là những tệp dữ liệu lớn bổ sung các công cụ nghiên cứu như sách chú giải, tra từ, và ghi chú ngữ pháp. Không có chúng, ứng dụng vẫn hoạt động, nhưng các tính năng nghiên cứu bị hạn chế.

## Tại sao bạn cần các tệp cốt lõi

Các tệp cốt lõi bổ sung:

- **Tra từ.** Chạm một từ trong bất kỳ câu Kinh Thánh nào để xem tiếng Do Thái hoặc tiếng Hy Lạp gốc và ý nghĩa của nó.
- **Chú giải.** Chú giải bằng AI cho từng câu Kinh Thánh.
- **Ngữ pháp.** Thông tin về từng từ trong ngôn ngữ gốc.
- **Kinh Thánh song ngữ.** Đọc văn bản ngôn ngữ gốc kèm tiếng Anh dưới từng từ.

Bạn có thể đọc Kinh Thánh mà không cần chúng, nhưng hầu hết công cụ nghiên cứu đều cần đến.

## Cách cài đặt các tệp cốt lõi

**[Cài đặt tệp cốt lõi](theodia://manage/core)**

1. Mở **Cài đặt**.
2. Chạm **Quản lý tài nguyên**.
3. Thẻ **Cốt lõi** mở ra. Bạn thấy danh sách các tệp cốt lõi. Mỗi tệp có tên, dung lượng, và một ô đánh dấu.
4. Chạm từng tệp bạn muốn cài. Dấu kiểm cho thấy tệp đã được chọn.
5. Chạm **Cài đặt mục đã chọn**.
6. Chờ các tệp tải xuống và cài đặt. Chúng khá lớn, nên có thể mất vài phút nếu kết nối chậm.

Các tệp tải về thiết bị của bạn. Bạn chỉ cần làm điều này một lần. Ứng dụng sẽ dùng các tệp đó từ đó về sau, kể cả khi bạn ngoại tuyến.

## Mẹo

- Dùng Wi-Fi. Các tệp này khá lớn.
- Cắm sạc điện thoại hoặc máy tính bảng. Tải xuống lớn tốn pin.
- Nếu một lượt tải thất bại, chạm lại vào tệp để thử lần nữa.
- Bạn có thể cài tất cả, hoặc chỉ cài những tệp mình cần.

## Nếu một tệp không có trong danh sách thì sao?

Ứng dụng lấy danh sách từ trang GitHub của dự án. Nếu danh sách trống, hãy kiểm tra kết nối internet và thử lại. Nếu vẫn trống, xem hướng dẫn [Đặt câu hỏi ở đâu](theodia://help/getting-more-help).

Để biết các cách nâng cao hơn để thêm tài nguyên, xem hướng dẫn [Tải tài nguyên bổ sung từ GitHub](theodia://help/getting-core-files).
