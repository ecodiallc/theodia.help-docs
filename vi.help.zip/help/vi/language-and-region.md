---
title: Ngôn ngữ và khu vực của ứng dụng
level: everyday
categories: settings
summary: Cách đổi ngôn ngữ của ứng dụng.
---

# Ngôn ngữ và khu vực của ứng dụng

Theodia có mặt bằng nhiều ngôn ngữ. Ứng dụng có thể đổi ngôn ngữ của trình đơn và nút bấm. Nội dung trợ giúp cũng có bằng nhiều ngôn ngữ trong số này và được tích hợp sẵn trong ứng dụng. Bạn cũng có thể tải xuống hoặc cập nhật gói trợ giúp của một ngôn ngữ — mở **Cài đặt** → **Trợ giúp** hoặc **Quản lý tài nguyên** → **Cài đặt từ GitHub** → **Tài liệu trợ giúp**.

## Cách mở cài đặt ngôn ngữ

1. Mở **Cài đặt**.
2. Chạm **Ngôn ngữ**.

## Cách đổi ngôn ngữ ứng dụng

1. Trong danh sách **Ngôn ngữ**, chạm ngôn ngữ bạn muốn.
2. Ứng dụng áp dụng ngôn ngữ mới ngay lập tức.

Các lựa chọn bạn thấy tùy vào những ngôn ngữ mà ứng dụng hỗ trợ.

## Ngôn ngữ được chọn thế nào khi lần đầu cài đặt

Khi bạn lần đầu cài Theodia, ứng dụng chọn ngôn ngữ dựa trên cài đặt của thiết bị. Bạn có thể đổi bất cứ lúc nào.

## Những gì được dịch

- Trình đơn, nút bấm, và nhãn.
- Màn hình cài đặt.
- Thông báo lỗi.
- Công cụ tìm kiếm và nghiên cứu.

## Những gì chỉ có tiếng Anh

- Một số nội dung sách và tài liệu linh đạo hằng ngày.

## Bản dịch Kinh Thánh và ngôn ngữ ứng dụng

Ngôn ngữ ứng dụng và ngôn ngữ bản dịch Kinh Thánh là hai chuyện khác nhau. Bạn có thể để ứng dụng bằng tiếng Tây Ban Nha mà Kinh Thánh bằng tiếng Anh, hoặc ngược lại.

Để đổi bản dịch Kinh Thánh, xem hướng dẫn [Cài đặt bản dịch Kinh Thánh](theodia://help/installing-bibles).

## Mẹo

- Nếu một nút hoặc nhãn bị trống, ứng dụng đang thiếu bản dịch. Bản tiếng Anh thường có sẵn làm phương án dự phòng.
- Nếu bạn muốn góp phần dịch ứng dụng, xem hướng dẫn [Đặt câu hỏi ở đâu](theodia://help/getting-more-help).
