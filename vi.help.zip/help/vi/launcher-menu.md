---
title: Trình đơn Launcher
level: everyday
categories: layout
summary: Cách nhanh để quay lại câu vừa đọc, chạy lệnh, và đổi bố cục Kinh Thánh mà không rời màn hình đang dùng.
---

# Trình đơn Launcher

> **Chế độ:** Trình đơn Launcher yêu cầu chế độ **Học giả**. Bạn có thể đổi chế độ trong **Cài đặt** → **Chế độ người dùng ứng dụng**.

Trình đơn Launcher là bảng truy cập nhanh mà bạn có thể mở từ hầu như mọi nơi trong ứng dụng. Nó gom các câu Kinh Thánh gần đây, các lệnh, và các bộ bố cục Kinh Thánh đã lưu vào một chỗ.

## Cách mở

Chạm **biểu tượng mở rộng (⌄)** ở góc trên bên phải của phần đầu màn hình chính. Một bảng sẽ trượt vào từ trên xuống.

## Bên trong có gì

### 1. Ô lệnh

Ở đầu bảng là một ô nhập liệu có biểu tượng bàn phím. Gõ một lệnh rồi chạm **Go** trên bàn phím. Ứng dụng đọc lệnh và đưa bạn thẳng tới đó.

Ví dụ:

- `John 3:16` — mở câu đó.
- `search love` — tìm trong Kinh Thánh từ "love".
- `bookmark psalms 23` — đánh dấu trang câu đó.
- `kjv` — chuyển sang bản dịch KJV.

Để xem danh sách đầy đủ các lệnh, xem hướng dẫn [Các lệnh](theodia://help/commands).

### 2. Bộ song song

Nếu bạn đã lưu các bộ song hành Kinh Thánh, chúng hiện ra ở đây như một danh sách có thể gập lại. Chạm một bộ để nạp ngay bố cục song hành đó.

Để tạo một bộ song hành:

1. Mở **Cài đặt** → **Kinh Thánh song hành**.
2. Thêm các bản dịch và chạm **Lưu bộ sẵn**.
3. Đặt tên cho nó. Nó sẽ xuất hiện trong Trình đơn Launcher.

Nhấn giữ một bộ song hành trong Trình đơn Launcher để xóa nó.

### 3. Bộ sưu tập Kinh Thánh

Bộ sưu tập Kinh Thánh là phím tắt một chạm, đổi đồng thời bản dịch và chế độ xem song hành của bạn. Nếu bạn đã tạo bộ nào, chúng hiện ra ở đây như một danh sách có thể gập lại.

Nhấn giữ một bộ sưu tập để xóa nó.

### 4. Biểu tượng tính năng

Bên dưới ô lệnh, bạn có thể thấy một hàng nút tròn dùng biểu tượng emoji. Đây là các phím tắt một chạm tới những tính năng chính của ứng dụng.

Các biểu tượng có sẵn gồm:

- **Giới thiệu**, **Kinh Thánh**, **Ghi chú Kinh Thánh**, **Dấu trang**, **Sách**
- **Tài liệu linh đạo**, **Thẻ ghi nhớ**, **Trợ giúp**, **Phần đánh dấu**
- **Danh sách phát**, **Trình cắm thêm**, **Tìm kiếm**, **Cài đặt**, **Theoscript**

Để chọn biểu tượng nào hiện ra và theo thứ tự nào:

1. Mở **Cài đặt** → **Trình đơn Launcher**.
2. Chạm **Biểu tượng trình đơn Launcher**.
3. Dùng các công tắc để hiện hoặc ẩn từng biểu tượng.
4. Dùng mũi tên lên/xuống để sắp xếp lại những biểu tượng bạn đã bật.

Thứ tự trong phần cài đặt chính là thứ tự chúng xuất hiện trong Trình đơn Launcher.

### 5. Câu Kinh Thánh gần đây

Ứng dụng nhớ những chương và câu bạn mở gần nhất. Chúng hiện ra như một danh sách ở đáy bảng. Chạm mục nào để quay thẳng lại mục đó.

- **Chạm** để mở.
- **Vuốt sang trái** hoặc **nhấn giữ** để xóa khỏi danh sách.
- Chạm **Xóa hết** để xóa tất cả các mục cùng lúc.

## Khi nào dùng Trình đơn Launcher

Dùng nó khi bạn muốn:

- Quay lại một câu vừa đọc.
- Gõ lệnh mà không cần về màn hình chính.
- Đổi bản dịch hoặc bố cục song hành chỉ bằng một chạm.
- Mở một tính năng chính từ bất kỳ đâu trong ứng dụng.
- Kiểm tra nhanh điều gì đó mà không phải lội qua các trình đơn.

## Mẹo

- Trình đơn Launcher có mặt trên hầu như mọi màn hình, nên bạn có thể mở nó ngay khi đang đọc một chương.
- Ô lệnh hỗ trợ cùng các lệnh như ô lệnh trên màn hình chính.
- Các biểu tượng tính năng và thứ tự của chúng được lưu cục bộ trên thiết bị. Chúng vẫn còn sau khi khởi động lại ứng dụng.
- Các câu gần đây được lưu cục bộ trên thiết bị. Chúng vẫn còn sau khi khởi động lại ứng dụng.
