---
title: Di chuyển giữa sách, chương và câu
level: everyday
categories: [layout, read]
summary: Cách di chuyển trong Kinh Thánh và nhảy tới nơi bạn muốn đến.
---

# Di chuyển giữa sách, chương và câu

Hướng dẫn này chỉ cho bạn mọi cách di chuyển trong Kinh Thánh.

## Cách dễ nhất: vuốt

- Vuốt **sang trái** trên một chương để sang chương kế tiếp.
- Vuốt **sang phải** để quay lại.
- Cách này cũng áp dụng cho sách kế tiếp. Sau chương cuối của, chẳng hạn, Xuất Ê-díp-tô Ký, cú vuốt đưa bạn tới chương đầu của Lê-vi Ký.

## Cách qua trình đơn

- Chạm tên bản dịch ở đầu trang để chuyển sang một Kinh Thánh khác.
- Chạm tên sách ở đầu trang để chọn sách khác.
- Chạm số chương để chọn chương khác.

## Cách nhanh: gõ

- Ở trang chủ, có một ô nhập liệu phía trên. Gõ địa chỉ câu, chẳng hạn `John 3:16` hay `psalms 23`, rồi chạm phím **Go** trên bàn phím.
- Ứng dụng mở câu đó.

## Cách qua dấu trang

Nếu bạn đã lưu một câu, hãy mở thẻ **Dấu trang**. Chạm bất kỳ mục nào để nhảy tới đó.

## Cách qua tìm kiếm

Chạm thẻ **Tìm kiếm**. Gõ một từ. Ứng dụng cho bạn xem mọi câu có chứa từ đó. Chạm kết quả nào để mở nó.

## Cách qua lịch sử

Ứng dụng nhớ các chương bạn đã mở. Để tìm lại, hãy xem trong thẻ **Dấu trang** (đối với những câu bạn đã lưu) hoặc lướt danh sách sách trong thẻ **Kinh Thánh** để tìm một cuốn sách bạn mới đọc.

## Mẹo

- Thẻ Kinh Thánh hiển thị các sách theo thứ tự từ Sáng Thế cho đến Khải Huyền.
- Với Thi Thiên, Châm Ngôn và các sách dài khác, chạm vào sách rồi dùng danh sách chương để nhảy xa về phía trước.
