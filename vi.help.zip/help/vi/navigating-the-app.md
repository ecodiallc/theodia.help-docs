---
title: Bố cục và điều hướng của ứng dụng
level: beginner
categories: layout
summary: Một vòng tham quan màn hình chính, trình đơn chính, và thanh công cụ dưới đáy — mọi thứ nằm ở đâu.
---

# Bố cục và điều hướng của ứng dụng

Theodia có ba khu vực chính bạn có thể di chuyển giữa: **màn hình chính**, **trình đơn chính**, và **thanh công cụ dưới đáy**. Hướng dẫn này đi qua từng khu để bạn luôn biết cần đi đâu.

## Sơ đồ nhanh

- **Màn hình chính** là trang bạn thấy khi mới mở ứng dụng. Nó có ô tìm kiếm, các nút lớn cho từng phần của ứng dụng, và danh sách các Kinh Thánh, sách, và tài liệu linh đạo bạn đã cài.
- **Thanh công cụ dưới đáy** (còn gọi là thanh thẻ) là hàng biểu tượng ở đáy màn hình. Chạm biểu tượng nào để nhảy thẳng tới phần đó của ứng dụng.
- **Trình đơn chính** là biểu tượng ba gạch (☰) ở góc trên bên phải của màn hình chính. Chạm nó để mở danh sách mọi màn hình trong ứng dụng, kể cả những màn hình không có thẻ riêng.

## Màn hình chính

Khi lần đầu mở Theodia, bạn đến màn hình chính. Nó được chia thành bốn phần, từ trên xuống dưới.

### Phần đầu

Ngay trên cùng là một thanh màu. Bên trái là biểu tượng ứng dụng và tên "Theodia." Bên phải là nút trình đơn chính (☰). Khi bạn đang trong một sách hoặc chương, bên trái hiện nút quay lại (←) thay thế. Chạm trình đơn chính để mở trình đơn (xem bên dưới).

### Ô lệnh

Ngay dưới phần đầu là một ô nhập liệu kiểu tìm kiếm mang nhãn **Lệnh**. Gõ một chỉ dẫn ngắn rồi chạm phím go trên bàn phím. Ứng dụng đọc chỉ dẫn và đưa bạn đến đúng màn hình. Ví dụ:

- `psalms 23` — mở Thi Thiên chương 23
- `john 3:16` — mở Giăng 3:16
- `search love` — tìm trong Kinh Thánh từ "love"
- `bookmark john 3:16` — lưu Giăng 3:16 làm dấu trang
- `commentary romans 8:28` — mở phần chú giải cho câu đó
- `xref` (kèm theo một địa chỉ câu) — mở các câu Thánh Kinh liên hệ của câu đó
- `help` — mở danh sách các lệnh kèm ví dụ

Nếu ứng dụng không hiểu bạn gõ gì, nó hiện một cảnh báo nhỏ kèm gợi ý. Xem hướng dẫn **Sự cố thường gặp** nếu các lệnh không hoạt động.

### Lưới nút

Bên dưới Ô lệnh là một lưới các nút lớn, mỗi hàng hai nút. Mỗi nút đưa bạn tới một phần khác của ứng dụng. Các nút gồm:

- 📖 **Kinh Thánh** — danh sách các bản dịch Kinh Thánh của bạn
- 🔍 **Tìm kiếm** — tìm trong Kinh Thánh một từ hoặc cụm từ
- 📚 **Sách** — thư viện các tác phẩm kinh điển Cơ Đốc
- 📅 **Tài liệu linh đạo** — tài liệu linh đạo hằng ngày
- 🔖 **Dấu trang** — các câu và chương bạn đã lưu
- 🖍 **Phần đánh dấu** — các câu bạn đã tô màu
- 📝 **Ghi chú** — ghi chú riêng của bạn về các câu
- ⚙️ **Cài đặt** — ngôn ngữ, giao diện, tài nguyên, và hơn nữa
- ❓ **Trợ giúp** — hệ thống trợ giúp (trang này)
- ℹ️ **Giới thiệu** — phiên bản ứng dụng và phần ghi công

### Các danh sách tài nguyên

Bên dưới lưới nút là các mục có thể mở rộng: **Kinh Thánh**, **Sách**, và **Tài liệu linh đạo**. Mỗi mục hiển thị những gì bạn đã cài. Chạm phần đầu của mục để mở rộng hoặc gập lại. Chạm bất kỳ mục con nào để mở nó.

Mục Kinh Thánh là cách nhanh nhất để nhảy vào một bản dịch cụ thể — không cần trình đơn, chỉ cần chạm.

## Thanh công cụ dưới đáy

Thanh công cụ dưới đáy (thanh thẻ) là hàng biểu tượng ở đáy màn hình. Nó hiển thị gần như khắp nơi trong ứng dụng, nên bạn luôn có thể nhảy sang phần khác. Các thẻ bạn thấy tùy vào chế độ người dùng của bạn.

**Mọi chế độ đều thấy:**

- 🏠 **Trang chủ** — mở màn hình chính
- 📖 **Kinh Thánh** — mở danh sách các bản dịch Kinh Thánh
- 📚 **Sách** — mở thư viện sách của bạn
- 🔍 **Tìm kiếm** — mở tìm kiếm Kinh Thánh
- ⚙️ **Cài đặt** — mở phần cài đặt

**Chế độ Chuẩn và Học giả còn thấy:**

- 🔖 **Dấu trang** — mở các câu bạn đã lưu
- 🖍 **Phần đánh dấu** — mở các câu bạn đã tô màu
- 📝 **Ghi chú** — mở ghi chú riêng của bạn

**Chế độ Học giả còn thấy:**

- 💻 **AI** — mở trợ lý AI (nếu bạn đã bật nó trong Cài đặt)

Thẻ hiện tại được làm nổi bật. Chạm thẻ khác để chuyển đổi.

### Thanh công cụ hoạt động thế nào

Mỗi thẻ trong thanh công cụ có **ngăn xếp** màn hình riêng. Khi bạn chạm một thẻ, bạn quay lại **nơi bạn đã dừng** trong ngăn xếp của thẻ đó, chứ không phải màn hình khởi đầu. Ví dụ:

- Chạm **Kinh Thánh** → bạn thấy danh sách các bản dịch Kinh Thánh.
- Chạm một bản dịch → bạn thấy danh sách các sách.
- Chạm một sách → bạn thấy danh sách các chương.
- Chạm một chương → bạn đang đọc chương đó.
- Chuyển sang **Dấu trang** để xem việc gì đó.
- Chạm lại **Kinh Thánh** → bạn quay về chương đang đọc dở.

Mỗi thẻ nhớ vị trí của bạn. Ứng dụng giữ lịch sử điều hướng trong từng thẻ, nên việc chuyển qua lại giữa các thẻ không làm mất tiến trình của bạn.

### Điều gì làm một thẻ quay về đầu

Một thẻ chỉ quay về màn hình gốc khi:

- Bạn đang ở thẻ đó và chạm lại chính biểu tượng thẻ đó một lần nữa. Đây là cách nhanh để về điểm khởi đầu.
- Ứng dụng bị tắt cưỡng bức rồi mở lại.

### Thẻ dưới đáy so với trình đơn chính

- **Thẻ dưới đáy** — mỗi thẻ nhớ ngăn xếp riêng của mình. Chạm một thẻ đưa bạn về nơi bạn đã dừng.
- **Trình đơn chính** — chạm một mục sẽ điều hướng tới màn hình đó bằng cùng hệ thống thẻ. Nó không mở dạng phủ lên trên.

Dùng các thẻ để chuyển việc. Dùng trình đơn chính khi bạn muốn xem danh sách đầy đủ mọi màn hình của ứng dụng.

### Khi nào dùng thanh công cụ

Dùng thanh công cụ khi bạn muốn đổi việc đang làm:

- Bạn đang đọc một chương và muốn tìm kiếm điều khác → chạm **Tìm kiếm**.
- Bạn đang tìm kiếm và muốn xem dấu trang → chạm **Dấu trang**.
- Bạn đang ở bất kỳ đâu trong ứng dụng và muốn về trang chủ → chạm **Trang chủ**.

## Trình đơn chính

Trình đơn chính là nút ba gạch chồng lên nhau (☰) ở góc trên bên phải của màn hình chính. Chạm nó và một bảng trượt vào từ bên phải. Bảng hiển thị mọi màn hình mà chế độ hiện tại của bạn hỗ trợ:

- 🏠 **Trang chủ**
- 📖 **Kinh Thánh**
- 📚 **Sách**
- 🙏 **Tài liệu linh đạo**
- 🔍 **Tìm kiếm**
- 🔖 **Dấu trang** (Chuẩn và Học giả)
- 🖍 **Phần đánh dấu** (Chuẩn và Học giả)
- 📝 **Ghi chú** (Chuẩn và Học giả)
- 💻 **Trợ lý AI** (chỉ Học giả, và chỉ khi AI đã được bật)
- ⚙️ **Cài đặt**
- ❓ **Trợ giúp**
- ℹ️ **Giới thiệu**

Mục khớp với màn hình bạn đang ở được làm nổi bật và có một chấm nhỏ bên cạnh. Chạm mục nào để đi thẳng tới đó. Chạm ngoài bảng, chữ X phía trên, hoặc nút back của thiết bị để đóng nó mà không đổi màn hình.

### Trình đơn chính khác gì

Trình đơn chính là một bảng thả xuống, không phải một lớp điều hướng riêng. Khi bạn chạm một mục, ứng dụng điều hướng tới màn hình đó y như khi bạn dùng thẻ dưới đáy hoặc lưới nút. Ngăn xếp của thẻ hiện tại được giữ nguyên, nên bạn có thể quay lại nơi cũ bằng cách chạm lại thẻ ban đầu.

Ví dụ:

- Bạn đang đọc Giăng 3. Bạn chạm thẻ **Dấu trang**. Bạn đến trang dấu trang. Khi chạm lại **Kinh Thánh**, bạn quay về Giăng 3 — đúng nơi bạn đã dừng.
- Bạn đang đọc Giăng 3. Bạn mở trình đơn chính và chạm **Ghi chú**. Ghi chú của bạn mở ra. Để quay về Giăng 3, chạm thẻ **Kinh Thánh** và bạn được đưa về chương đó tự động.

Các thẻ đổi ngữ cảnh và nhớ vị trí của bạn. Trình đơn chính chỉ đơn giản là một cách khác để đến cùng những màn hình đó.

### Khi nào dùng trình đơn chính

Dùng trình đơn chính khi:

- Bạn muốn mở **Phần đánh dấu**, **Ghi chú**, **Tài liệu linh đạo**, **Trợ giúp**, hoặc **Giới thiệu** — những màn hình không có thẻ riêng trên thanh công cụ.
- Bạn đang sâu trong một chương hay một lượt tìm kiếm và muốn xem nhanh điều gì đó mà không mất vị trí.
- Bạn muốn mở **Cài đặt** mà không rời màn hình đang dùng.

## Chế độ Học giả

Nếu chế độ người dùng của bạn là **Học giả**, bố cục có thêm các thẻ, mục trình đơn, và công cụ đọc mà chế độ Đọc giả và Chuẩn ẩn đi. Xem hướng dẫn [Chế độ Học giả](theodia://help/scholar-mode) để được giới thiệu đầy đủ từng tính năng.

## Ba khu vực phối hợp thế nào

- **Chuyển sang một khu vực chính khác** (Kinh Thánh, Tìm kiếm, Dấu trang, v.v.) → Thanh công cụ dưới đáy
- **Nhảy tới một câu cụ thể hoặc chạy lệnh** → Ô lệnh trên màn hình chính
- **Xem tất cả các màn hình có sẵn** → Lưới nút trên màn hình chính
- **Xem Ghi chú, Phần đánh dấu, hoặc Trợ giúp mà không rời chỗ** → Trình đơn chính
- **Mở Cài đặt từ bất kỳ đâu** → Trình đơn chính hoặc thanh công cụ

Bạn sẽ dùng cả ba. Không cái nào là "cách đúng duy nhất." Chọn cái nào dễ nhất cho việc bạn đang làm.

### Thanh công cụ so với trình đơn chính: một ví dụ nhanh

Giả sử bạn đang đọc Rô-ma 8 và muốn đánh dấu một câu bạn thích.

**Dùng thanh công cụ:**

1. Chạm vào câu để mở trình đơn câu.
2. Chạm **Đánh dấu** và chọn một màu.
3. Xong. Bạn chưa hề rời chương đó.

**Dùng trình đơn chính (nếu bạn muốn xem lại các phần đánh dấu):**

1. Chạm ☰ để mở trình đơn.
2. Chạm **Phần đánh dấu**. Danh sách các phần đánh dấu của bạn mở ra.
3. Xem lại chúng, rồi chạm thẻ **Kinh Thánh** để quay về Rô-ma 8.

**Dùng thanh công cụ (nếu bạn muốn đổi việc):**

1. Chạm **Trang chủ** hoặc **Dấu trang** trên thanh công cụ.
2. Bạn rời Rô-ma 8 và đến màn hình mới.
3. Để quay về Rô-ma 8, chạm lại **Kinh Thánh** — bạn được đưa về chương đó tự động.

## Mẹo

- Màn hình chính nhớ những mục nào đang mở rộng hay gập lại. Bạn chỉ cần thiết lập một lần.
- Nếu bạn không thấy một thẻ mà mình mong đợi, hãy kiểm tra hai điều:

1. **Chế độ người dùng của bạn** — chế độ Đọc giả ẩn dấu trang, phần đánh dấu, ghi chú, và AI. Chế độ Chuẩn ẩn AI. Đổi chế độ trong **Cài đặt** → **Chế độ người dùng ứng dụng**.
2. **Cài đặt tính năng** — một số thẻ cần được bật trong **Cài đặt** (ví dụ, trợ lý AI).
