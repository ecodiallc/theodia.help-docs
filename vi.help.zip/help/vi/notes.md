---
title: Viết ghi chú
level: everyday
categories: [annotate, read]
summary: Cách viết suy nghĩ của riêng bạn bên cạnh một câu Kinh Thánh.
---

# Viết ghi chú

> **Chế độ:** Ghi chú có trong chế độ **Chuẩn** và **Học giả**. Chế độ Tập trung chỉ dành cho việc đọc sạch sẽ, không bị làm phiền. Bạn có thể đổi chế độ trong **Cài đặt** → **Chế độ người dùng ứng dụng**.

Ghi chú là nơi bạn viết suy nghĩ, lời cầu nguyện, hoặc ý tưởng học về Kinh Thánh của riêng mình bên cạnh một câu. Mỗi ghi chú gắn với một câu cụ thể.

## Cách thêm ghi chú

1. Mở câu đó.
2. Chạm vào câu để hiện trình đơn.
3. Chạm **Ghi chú** trong trình đơn. Nó có biểu tượng cây bút chì.
4. Gõ ghi chú của bạn.
5. Chạm **Lưu**.

Ghi chú nay được lưu cùng với câu đó.

## Cách đọc một ghi chú

1. Mở câu đó.
2. Tìm dấu bút chì bên cạnh câu. Nó cho biết có một ghi chú.
3. Chạm vào câu. Ghi chú hiện ra bên dưới.

## Cách sửa một ghi chú

1. Mở câu có ghi chú.
2. Chạm vào câu.
3. Chạm **Ghi chú** trong trình đơn.
4. Thay đổi nội dung.
5. Chạm **Lưu**.

## Cách xóa một ghi chú

1. Mở câu có ghi chú.
2. Chạm vào câu.
3. Chạm **Ghi chú** trong trình đơn.
4. Chạm **Xóa**.

## Cách xem tất cả ghi chú của bạn

Chạm thẻ **Ghi chú** ở dưới đáy. Bạn thấy danh sách mọi ghi chú đã viết, sắp theo ngày.

## Tìm trong ghi chú của bạn

Trong thẻ **Ghi chú**, chạm ô **Tìm kiếm**. Gõ một từ. Ứng dụng tìm ra mọi ghi chú có chứa từ đó.

## Mẹo

- Ghi chú rất hữu ích cho bài giảng, giờ tôn kính, và câu hỏi học Kinh Thánh.
- Ghi chú là riêng tư. Chúng nằm trên thiết bị của bạn.
- Xem hướng dẫn [Sao lưu dữ liệu của bạn](theodia://help/backups) để giữ chúng an toàn.
