---
title: Thông báo và lời nhắc
level: everyday
categories: [settings]
summary: Cách bật, tùy chỉnh, và quản lý lời nhắc ngoại tuyến cho cầu nguyện, tài liệu linh đạo, kế hoạch đọc Kinh Thánh, và hơn nữa.
---

# Thông báo và lời nhắc

Theodia có thể nhắc bạn về cầu nguyện, tài liệu linh đạo, kế hoạch đọc Kinh Thánh, thẻ ghi nhớ, và các hoạt động khác — kể cả khi ứng dụng ngoại tuyến. Mọi lời nhắc được đặt lịch ngay trên thiết bị của bạn; không cần kết nối internet hay máy chủ thông báo đẩy.

## Cách bật hoặc tắt lời nhắc

1. Mở **Cài đặt**.
2. Chạm **Thông báo**.
3. Bật hoặc tắt **Bật lời nhắc**.

Lần đầu bạn bật lời nhắc, ứng dụng xin quyền gửi thông báo. Chạm **Cho phép** để các lời nhắc có thể xuất hiện.

Nếu trước đây bạn đã từ chối quyền, iOS hoặc Android có thể chặn yêu cầu. Trong trường hợp đó, hãy vào ứng dụng **Cài đặt** của thiết bị, tìm **Theodia**, và bật thông báo tại đó.

## Các loại lời nhắc

Màn hình thông báo được chia thành các kênh. Mỗi kênh là một nhóm lời nhắc mà bạn có thể bật hoặc tắt độc lập:

- **Lời nhắc cầu nguyện** — các lời nhắc cầu nguyện chung.
- **Phụ đề cầu nguyện** — lời nhắc gắn với một phụ đề cầu nguyện cụ thể.
- **Tài liệu linh đạo** — lời nhắc câu Kinh Thánh hằng ngày hoặc tài liệu linh đạo.
- **Lời nhắc kế hoạch Kinh Thánh** — lời nhắc cho một kế hoạch Kinh Thánh đang thực hiện.
- **Lời nhắc Theoscript** — lời nhắc để chạy một Theoscript.
- **Lời nhắc linh hoạt AI** — các lời nhắc do AI tạo.
- **Lời nhắc ôn thẻ ghi nhớ** — nhắc bạn ôn các thẻ ghi nhớ.
- **Lời nhắc thói quen đọc** — nhắc thói quen đọc hằng ngày.
- **Lời nhắc phụng vụ & theo mùa** — lời nhắc gắn với lịch phụng vụ của hội thánh.
- **Lời nhắc của tôi** — lời nhắc bạn tạo từ dấu trang, phần đánh dấu, danh sách phát, các chương Kinh Thánh, hoặc sách.
- **Lời nhắc tùy chỉnh** — lời nhắc hoàn toàn tùy chỉnh do chính bạn tạo.

Chạm bất kỳ kênh nào để xem các lời nhắc của nó, đổi giờ, chọn ngày nào nó nhắc, hoặc tắt nó đi.

## Lời nhắc tùy chỉnh

Lời nhắc tùy chỉnh là lời nhắc bạn tự tạo từ đầu.

1. Trong **Cài đặt** → **Thông báo**, chạm **Lời nhắc tùy chỉnh**.
2. Chạm nút **+**.
3. Nhập **Tiêu đề** và **Nội dung**.
4. Chọn một **Giờ**.
5. Chọn các **Ngày** bạn muốn nó lặp lại.
6. Chọn lời nhắc mở màn hình nào khi được chạm (không bắt buộc).
7. Chạm **Lưu**.

Bạn có thể sửa hoặc xóa một lời nhắc tùy chỉnh bất cứ lúc nào bằng cách chạm nó trong danh sách.

## Điều gì xảy ra khi bạn chạm một lời nhắc

Hầu hết lời nhắc mở một màn hình cụ thể trong ứng dụng. Ví dụ, lời nhắc phụ đề cầu nguyện mở chính phụ đề đó; lời nhắc kế hoạch Kinh Thánh mở phần đọc tiếp theo.

Nếu một lời nhắc không gắn với màn hình nào, nó mở ứng dụng ở màn hình Trang chủ.

## Giờ yên lặng

Giờ yên lặng làm im tiếng thông báo nhưng vẫn để lời nhắc hiện lên màn hình.

1. Trong **Cài đặt** → **Thông báo**, chạm **Giờ yên lặng**.
2. Đặt giờ **Bắt đầu** và **Kết thúc**.

Lời nhắc đặt trong giờ yên lặng sẽ hiện trên màn hình mà không có âm thanh.

## Lời nhắc sắp đến và lịch sử

- **Lời nhắc sắp đến** hiển thị mọi thứ đang được hẹn sẽ nhắc tiếp theo.
- **Lịch sử thông báo** hiển thị các lời nhắc vừa được gửi, đang được hẹn, và đã bị hủy trong thời gian gần đây.

Dùng các danh sách này để xác nhận một lời nhắc đã được đặt đúng, hoặc để xem lý do một lời nhắc không xuất hiện.

## Nếu lời nhắc không xuất hiện

- Đảm bảo **Bật lời nhắc** đang bật.
- Kiểm tra thông báo đã được cho phép trong cài đặt hệ thống của thiết bị chưa.
- Đảm bảo kênh của lời nhắc đã được bật và ít nhất một ngày đã được chọn.
- Nếu bạn đặt giờ yên lặng, lời nhắc có thể im lặng.
- Một số nhà sản xuất Android cho ứng dụng ngủ đông. Thêm Theodia vào danh sách được phép nếu thiết bị của bạn có cài đặt tối ưu pin.
- Nếu một lời nhắc gắn với nội dung bạn đã gỡ (ví dụ, một kế hoạch Kinh Thánh hoặc phụ đề đã xóa), lời nhắc có thể không chạy cho đến khi bạn chọn lại mục tiêu hợp lệ.

## Âm thanh thông báo

Bạn có thể chọn âm thanh cho những lời nhắc hỗ trợ âm thanh. Chạm **Âm thanh** bên trong một lời nhắc hoặc kênh để chọn từ các lựa chọn có sẵn. Âm thanh được đóng gói cùng ứng dụng, nên chúng hoạt động ngoại tuyến.

Dùng nút **Nghe thử âm thanh** để nghe âm thanh đã chọn trước khi lưu.

## Huy hiệu

Một số lời nhắc có thể gắn huy hiệu lên biểu tượng ứng dụng. Chạm **Xóa huy hiệu** trên màn hình thông báo để đặt lại nó.
