---
title: Tệp PDF
level: everyday
categories: [read, resources]
summary: Nhập, sắp xếp, và đọc tài liệu PDF trong Theodia.
---

# Tệp PDF

> **Chế độ:** Tệp PDF có trong chế độ **Chuẩn** và **Học giả**. Chế độ Tập trung chỉ dành cho việc đọc sạch sẽ, không bị làm phiền. Bạn có thể đổi chế độ trong **Cài đặt** → **Chế độ người dùng ứng dụng**.

Theodia có thể lưu và đọc tệp PDF. Các tệp PDF đã nhập nằm trên thiết bị của bạn, nên chúng hoạt động ngoại tuyến.

## Mở thư viện PDF

Chạm thẻ **PDF** ở đáy màn hình, hoặc chạm ô **PDF** trên màn hình chính.

## Nhập một tệp PDF

1. Mở thẻ **PDF**.
2. Chạm nút **+** ở góc dưới bên phải.
3. Chọn một tệp PDF từ thiết bị của bạn.
4. (Không bắt buộc) Gõ hoặc chọn một danh mục để sắp xếp nó.

## Sắp xếp tệp PDF

Nhấn giữ bất kỳ thẻ PDF nào để mở trình đơn với các lựa chọn sau:

- **Đổi tên** — đổi tiêu đề hiển thị trong thư viện.
- **Đổi danh mục** — chuyển tệp PDF vào một danh mục.
- **Xóa** — gỡ tệp PDF khỏi Theodia. Thao tác này cũng xóa vị trí đọc đã lưu của nó.

Danh mục là dạng văn bản tự do. Gõ một tên mới hoặc chọn tên có sẵn khi bạn nhập hoặc đổi danh mục.

## Đọc một tệp PDF

Chạm một thẻ PDF để mở nó. Trình đọc hiển thị:

- Tiêu đề tài liệu trên một thanh ở đầu trang.
- Một hàng nút trang: **Trang đầu**, **Trước**, trang hiện tại ("3 / 120"), **Sau**, và **Trang cuối**.
- Một thanh công cụ với các công cụ của tài liệu: **Mục lục**, **Thu nhỏ**, **Phóng to**, **Đặt lại cỡ**, **Dấu trang**, **Tìm kiếm**, **Nghe**, và **Chế độ văn bản**.

Một số công cụ bị mờ khi không thể dùng — ví dụ, **Tìm kiếm** và **Nghe** bị mờ cho đến khi văn bản tìm kiếm được của tệp PDF được cài vào.

### Lật trang

- Chạm **mũi tên trái** hoặc **mũi tên phải** để lùi hoặc tiến một trang.
- Chạm **Trang đầu** hoặc **Trang cuối** để nhảy tới đầu hoặc cuối tài liệu.
- Chạm số trang (ví dụ "3 / 120") để mở một lưới các trang, rồi chạm trang bạn muốn. Lưới mở gần trang bạn đang đọc.
- Dùng các **phím mũi tên Trái và Phải** trên bàn phím ngoài.

### Phóng to, thu nhỏ

- Chạm **Phóng to** (+) hoặc **Thu nhỏ** (−) để đổi kích thước trang.
- Chạm **Đặt lại cỡ** để trả trang về kích thước thường.
- Nếu bạn phóng to, lật trang, rồi thu nhỏ, Theodia đưa bạn trở về trang bạn đang đọc.

## Tìm kiếm trong một tệp PDF

1. Mở tệp PDF và chạm nút **Tìm kiếm** (kính lúp) trên thanh công cụ.
2. Gõ điều bạn đang tìm. Kết quả hiện ra ngay khi bạn gõ, kèm số trang và một đoạn văn bản xung quanh.
3. Chạm một kết quả để nhảy tới trang đó.

Tính năng tìm kiếm cần văn bản tìm kiếm được của tệp PDF đã được cài. Nếu chưa cài, nút Tìm kiếm bị mờ. Các tệp PDF cài từ kho GitHub cộng đồng có sẵn văn bản tìm kiếm được; tệp PDF bạn tự nhập thì chưa có cho đến khi văn bản đó được thêm vào.

## Mục lục

Nếu tệp PDF có mục lục sẵn, nút **Mục lục** trên thanh công cụ hiển thị nó dạng dàn ý. Chạm tiêu đề một mục để nhảy tới trang đó. Các mục có thể mở rộng và gập lại. Nếu tệp PDF không có mục lục, nút này bị mờ.

## Dấu trang trong tệp PDF

1. Mở tệp PDF và chạm nút **Dấu trang** trên thanh công cụ.
2. Chạm **Đánh dấu trang này** để lưu trang hiện tại. Tên ban đầu là số trang — gõ tên khác nếu bạn muốn — rồi chạm **Lưu**.
3. Chạm bất kỳ dấu trang nào trong danh sách để nhảy tới trang của nó.
4. Chạm **×** bên cạnh một dấu trang để xóa nó.

Dấu trang PDF tách biệt với dấu trang Kinh Thánh của bạn. Mỗi tệp PDF giữ danh sách riêng của nó.

## Đọc tệp PDF thành tiếng

Nếu văn bản tìm kiếm được của tệp PDF đã được cài, Theodia có thể đọc to trang hiện tại:

1. Mở tệp PDF và chạm nút **Nghe** (loa) trên thanh công cụ.
2. Một thanh điều khiển xuất hiện với **Phát/Tạm dừng**, **Tua lại**, **Tua nhanh**, **Dừng**, một thanh tiến trình có thể chạm để nhảy trong trang, tốc độ đọc, và giọng đọc.
3. Khi trang kết thúc, việc đọc tự động tiếp tục sang trang kế.

Giọng đọc và tốc độ là những cái được dùng cho việc đọc Kinh Thánh — xem [Đọc thành tiếng](theodia://help/tts) để biết cách thay đổi chúng.

## Sao chép, chia sẻ, hoặc lưu văn bản trang

Chạm nút **Chế độ văn bản** trên thanh công cụ để xem trang hiện tại dưới dạng văn bản thuần. Từ đó bạn có thể:

- **Sao chép** — sao chép văn bản trang vào bộ nhớ tạm.
- **Chia sẻ** — chia sẻ văn bản trang qua bất kỳ ứng dụng nào trên thiết bị.
- **Thêm vào ghi chú học** — mở trình soạn ghi chú với văn bản trang, một trích dẫn, và một liên kết dẫn về trang này, tất cả đã được điền sẵn cho bạn.

## Đọc tiếp từ chỗ đang dở

Theodia nhớ trang cuối cùng bạn xem và mở tệp PDF tại đó trong lần sau.

## Tải tệp PDF từ GitHub

Ở chế độ **Học giả**, một nút **Tải từ GitHub** xuất hiện ở đáy thư viện. Nó kết nối tới kho PDF cộng đồng để bạn có thể cài các tài liệu PDF đã đóng gói theo cùng cách như cài Kinh Thánh hay sách.

## Ghi chú

- Các tệp PDF được lưu trong thư mục tài liệu riêng của Theodia. Chúng không được đưa vào bản sao lưu, nên nếu bạn chuyển sang thiết bị mới, bạn sẽ cần nhập lại chúng.
