---
title: Danh sách phát
level: everyday
categories: playlists
summary: Tạo và nghe các danh sách phát gồm các đoạn Kinh Thánh, văn bản thuần, hoặc bất kỳ câu nào bạn muốn nghe.
---

# Danh sách phát

Một **danh sách phát** là danh sách các đoạn Theodia có thể đọc to cho bạn. Mỗi đoạn là một bài Kinh Thánh hoặc một ghi chú văn bản thuần ngắn. Danh sách phát hữu ích để nghe tay không khi đi đường, đi bộ dạo, giờ tôn kính, hoặc luyện ghi nhớ.

Danh sách phát xuất hiện trong ứng dụng một khi đã có ít nhất một danh sách được tạo hoặc được điền nội dung.

## Tìm danh sách phát ở đâu

Khi danh sách phát đã khả dụng, bạn có thể đến đó bằng hai cách:

- **Màn hình chính:** Trong mục **Trình cắm thêm & Khác**, chạm **Danh sách phát**.
- **Trình đơn chính:** Mở trình đơn (☰) và chạm **Danh sách phát**.

Nếu chưa có danh sách phát nào, ô Danh sách phát và mục trên trình đơn bị ẩn.

## Một danh sách phát gồm những gì

Mỗi danh sách phát có:

- Một **tên** — ví dụ, "Câu Kinh Thánh buổi sáng" hay "Ghi nhớ Thi Thiên 23".
- Một **danh mục** không bắt buộc — hữu ích để nhóm các danh sách phát theo mục đích.
- Một danh sách **các đoạn** — những mục sẽ được đọc to.

Mỗi đoạn chứa:

- **Nội dung** — hoặc là địa chỉ một bài Kinh Thánh, hoặc là văn bản thuần.
- Một **nhãn** — hiện trên màn hình khi đoạn đó phát.
- Một **giọng đọc** không bắt buộc — chọn giọng khác cho đoạn này nếu bạn muốn.

## Tạo một danh sách phát

1. Mở màn hình **Danh sách phát**.
2. Chạm **Tạo danh sách phát** (hoặc nút **+**).
3. Đặt tên cho danh sách phát.
4. (Không bắt buộc) Chọn hoặc tạo một danh mục.
5. Bắt đầu thêm các đoạn.

### Thêm một đoạn từ bài Kinh Thánh

1. Chạm **Thêm đoạn**.
2. Chọn **Bài Kinh Thánh** làm loại nội dung.
3. Nhập địa chỉ câu, chẳng hạn `John 3:16` hay `Psalm 23:1-6`.
4. Thêm nhãn nếu bạn muốn, hoặc để trống để dùng địa chỉ câu làm nhãn.
5. Lưu đoạn đó.

### Thêm một đoạn văn bản thuần

1. Chạm **Thêm đoạn**.
2. Chọn **Văn bản thuần**.
3. Gõ nội dung bạn muốn Theodia đọc.
4. Thêm một nhãn.
5. Lưu đoạn đó.

### Thêm nhiều đoạn cùng lúc

Nếu bạn có sẵn một danh sách các địa chỉ câu hoặc các dòng văn bản, hãy dùng **Thêm hàng loạt**:

1. Mở một danh sách phát.
2. Chạm trình đơn và chọn **Thêm hàng loạt**.
3. Dán mỗi địa chỉ câu hoặc dòng văn bản vào từng dòng riêng.
4. Bật **Phát hiện địa chỉ Kinh Thánh** nếu hầu hết các dòng là địa chỉ câu.
5. Chạm **Thêm**. Mỗi dòng trở thành một đoạn.

## Nghe một danh sách phát

1. Mở danh sách phát bạn muốn nghe.
2. Chạm nút **Phát** ở trên cùng hoặc bên cạnh một đoạn.
3. Theodia đọc từng đoạn theo thứ tự.

Trong khi danh sách phát đang phát, một thanh điều khiển hiện ra với các nút:

- **Phát / Tạm dừng**
- **Đoạn kế**
- **Đoạn trước**
- **Dừng**

Bạn cũng có thể đặt:

- **Tốc độ** — giọng đọc nhanh hay chậm.
- **Lặp lại** — lặp cả danh sách phát, lặp một đoạn, hoặc chỉ phát một lần.
- **Phát ngẫu nhiên** — phát các đoạn theo thứ tự ngẫu nhiên.
- **Bỏ ngoặc đơn** — bỏ qua văn bản nằm trong ngoặc đơn.
- **Tạm dừng giữa các đoạn** — thêm khoảng lặng ngắn giữa các đoạn.
- **Hẹn giờ ngủ** — dừng phát sau một khoảng thời gian đặt sẵn.

## Sửa một danh sách phát

Để đổi một danh sách phát, trước hết hãy tạm dừng việc phát nếu nó đang chạy.

Bạn có thể:

- **Đổi tên** danh sách phát.
- **Sắp xếp lại các đoạn** — kéo các đoạn vào thứ tự mới.
- **Sửa một đoạn** — đổi địa chỉ, văn bản, nhãn, hoặc giọng đọc của nó.
- **Xóa một đoạn** — gỡ nó khỏi danh sách phát.
- **Xóa cả danh sách phát** — thao tác này không thể hoàn tác.

## Xuất và nhập danh sách phát

Danh sách phát được xuất thành các tệp JSON bao gồm mọi đoạn, danh mục, và cài đặt. Bạn có thể chia sẻ tệp cho thiết bị khác, giữ nó làm bản sao lưu, hoặc sửa nó trên máy tính.

- **Xuất tất cả danh sách phát** — tạo tệp `playlists-YYYY-MM-DD.json`.
- **Xuất một danh mục** — tạo tệp JSON chỉ chứa các danh sách phát trong một danh mục.
- **Nhập danh sách phát** — khôi phục danh sách phát từ một tệp sao lưu JSON.

## Các cách nhanh để dựng một danh sách phát

Bạn cũng có thể tạo một danh sách phát đầy đủ dưới dạng JSON rồi nhập vào. Đây là một ví dụ:

```json
{
  "playlists": [
    {
      "name": "Morning Verses",
      "category": "Devotional",
      "tracks": [
        {
          "info": "John 3:16",
          "contentSource": "passage",
          "content": "For God so loved the world...",
          "rawContent": "John 3:16"
        },
        {
          "info": "Psalm 23",
          "contentSource": "passage",
          "content": "The Lord is my shepherd...",
          "rawContent": "Psalm 23:1-6"
        }
      ]
    }
  ]
}
```

Lưu tệp, rồi dùng **Nhập danh sách phát** để nạp nó vào Theodia.

## Mẹo

- Danh sách phát hoạt động tốt nhất với những bộ câu ngắn, tập trung.
- Dùng danh mục để tách các danh sách phát tôn kính khỏi các danh sách ghi nhớ.
- Đặt hẹn giờ ngủ nếu bạn nghe khi đang thiếp đi.
- Nếu một đoạn dùng nhầm giọng đọc, kiểm tra xem ngôn ngữ của giọng có khớp với ngôn ngữ của văn bản không.
- Theodia đọc văn bản thuần đúng như đã viết; kiểm tra chính tả để có kết quả tốt nhất.
