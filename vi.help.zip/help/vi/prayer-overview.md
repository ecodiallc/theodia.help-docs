---
title: Tổng quan về Cầu nguyện
level: beginner
categories: prayer
summary: Giới thiệu nhanh về thẻ Cầu nguyện và các mục chính của nó.
---

# Tổng quan về Cầu nguyện

Thẻ **Cầu nguyện** là một không gian riêng dành cho việc cầu nguyện. Nó gom chung các danh sách, các buổi cầu nguyện có hướng dẫn, một nhật ký, một bộ hẹn giờ, lịch đọc Kinh Thánh theo phụng vụ, và các lời cầu nguyện cổ điển cố định.

## Các mục chính

- **Danh sách cầu nguyện** — theo dõi những người, hoàn cảnh, và chủ đề bạn đang cầu nguyện.
- **Nhật ký** — ghi lại những suy niệm, câu trả lời, và suy nghĩ theo thời gian.
- **Tạo lời cầu nguyện** — nhờ Theophilus viết một lời cầu nguyện từ một lời thỉnh cầu hoặc một mục nhật ký.
- **Tín điều & Lời cầu nguyện cố định** — các lời cầu nguyện và tín điều cổ điển trong truyền thống Cơ Đốc.
- **Lịch phụng vụ** — lịch đọc Kinh Thánh cho việc cầu nguyện hằng ngày hoặc theo mùa.
- **Cầu nguyện có hướng dẫn** — các buổi cầu nguyện dẫn dắt bằng âm thanh dùng đọc máy.
- **Bộ hẹn giờ** — các buổi cầu nguyện có bấm giờ, tùy chọn kèm chuông.
