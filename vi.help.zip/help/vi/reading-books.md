---
title: Đọc các sách có sẵn
level: beginner
categories: [content, read]
summary: Cách đọc các tác phẩm kinh điển Cơ Đốc đi kèm với ứng dụng.
---

# Đọc các sách có sẵn

Theodia đi kèm một thư viện nhỏ gồm các sách Cơ Đốc. Đây là những tác phẩm kinh điển bạn có thể đọc ngay trên thiết bị.

## Cách mở thư viện

Chạm thẻ **Sách** ở đáy màn hình. Bạn thấy danh sách các sách trong thư viện của mình.

## Cách đọc một cuốn sách

1. Chạm tiêu đề sách.
2. Sách mở ra ở chương đầu tiên.
3. Dùng các nút **Trước** và **Sau** ở trên cùng để chuyển giữa các chương.

## Cách nhảy tới một chương

Chạm tên chương ở đầu màn hình. Danh sách các chương hiện ra. Chọn một chương để nhảy tới đó.

## Cách đổi cỡ chữ

Mở **Cài đặt** → **Diện mạo** và chọn cỡ chữ. Cỡ chữ thay đổi trên toàn ứng dụng, kể cả trong sách.

## Cách thêm dấu trang trong một cuốn sách

Chạm biểu tượng **ngôi sao** ở trên cùng bên phải. Chương hiện tại được lưu. Chạm thẻ **Dấu trang** để xem các trang đã lưu của bạn.

## Cách nghe một cuốn sách

Chạm biểu tượng **Loa** ở trên cùng bên phải. Ứng dụng đọc chương đó thành tiếng. Chạm lại một lần nữa để dừng.

## Có những sách nào?

Thư viện có các tác phẩm kinh điển như:

- Pilgrim's Progress
- The Imitation of Christ
- Practice of the Presence of God
- The Hymn Book

Danh sách sách có thể lớn dần theo thời gian. Các bản cập nhật của ứng dụng có thể thêm sách mới.

## Mẹo

- Sách được lưu trên thiết bị của bạn. Không cần internet.
- Sách không đồng bộ lên đám mây.
