---
title: Tìm tài nguyên trên GitHub
level: everyday
categories: resources
summary: Tìm kiếm tất cả các kho GitHub mà ứng dụng biết trong một lần, rồi cài những gì bạn tìm thấy.
---

# Tìm tài nguyên trên GitHub

Theodia giữ một danh sách các kho GitHub có phát hành tài nguyên — Kinh Thánh, chú giải, sách, tài liệu linh đạo, danh sách phát, gói cầu nguyện, và hơn nữa. **Tìm kho GitHub** tìm kiếm tất cả cùng một lúc, nên bạn không phải mở từng thẻ và duyệt riêng lẻ.

> Phần GitHub trong Cài đặt chỉ có ở **chế độ Học giả**. Để bật nó, vào **Cài đặt → Chế độ người dùng → Học giả**.

## Cách tìm kiếm

1. Mở **Cài đặt**.
2. Chạm **Tìm kho GitHub**.
3. Gõ một từ vào ô tìm kiếm. Ứng dụng tìm từ đó trong **tên** và **mô tả** của mọi gói trong mọi kho.

Vài điều cần biết về việc tìm kiếm:

- **Mọi từ đều phải khớp.** Tìm `morning evening` chỉ tìm ra các gói mà tên hoặc mô tả của chúng chứa *cả hai* từ.
- **Chữ hoa chữ thường không quan trọng.** `Morning` và `morning` tìm ra cùng các gói.
- **Kết quả khớp nhất đứng trước.** Một gói có tên *bắt đầu* bằng từ bạn tìm sẽ hiện trước một gói chỉ nhắc đến từ đó trong phần mô tả.

## Lọc

Chạm thanh lọc phía trên kết quả để thu hẹp danh sách hơn nữa. Có hai bộ lọc, và chúng phối hợp với nhau:

- **Tác giả** — chỉ các gói của tác giả đó.
- **Truyền thống** — chỉ các gói thuộc truyền thống đó.

Chạm một bộ lọc lần nữa để xóa nó, hoặc chạm **Xóa bộ lọc** để đặt lại cả hai.

## Cài từ một kết quả

Mỗi kết quả hiển thị tên gói, loại tài nguyên, ai tạo ra nó, và nó đến từ kho nào. Bên phải hàng là một nút:

- **Cài đặt** — gói chưa có trên thiết bị của bạn.
- **Cập nhật** — có phiên bản mới hơn. Ứng dụng xin bạn xác nhận trước, vì việc cập nhật xóa bản cũ cùng mọi ghi chú, phần đánh dấu, hoặc dấu trang đang trỏ tới nó.
- **Mở** — gói đã được cài; chạm nó sẽ đưa bạn đến màn hình để dùng nó.

Chạm **Làm mới** ở trên cùng để lấy danh sách mới nhất từ GitHub ngay lập tức. Ứng dụng tự làm mới danh sách mỗi ngày một lần, nên việc làm mới thủ công chỉ cần khi bạn biết có điều mới vừa được phát hành.

## Tìm kiếm khi không có kết nối

Ứng dụng giữ một bản sao của danh sách trên thiết bị của bạn, nên việc tìm kiếm vẫn hoạt động cả khi bạn ngoại tuyến. Nếu ứng dụng không kết nối được GitHub để làm mới danh sách, một banner ở trên cùng cho biết bạn đang thấy kết quả đã lưu trong bộ nhớ đệm.

## Nếu tìm kiếm không thấy gì

- Thử một từ ngắn hơn, chỉ một từ.
- Kiểm tra chưa có bộ lọc **Tác giả** hay **Truyền thống** nào còn áp dụng — nút **Xóa bộ lọc** xuất hiện mỗi khi có một bộ lọc đang bật.
- Một số kho phát hành gói của mình bằng ngôn ngữ khác với tên gói, nên tìm bằng một từ đã dịch có thể không ra chúng.
