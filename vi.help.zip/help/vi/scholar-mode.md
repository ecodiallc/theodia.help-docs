---
title: Chế độ Học giả
level: advanced
categories: [layout, read, study]
summary: Chế độ học sâu nhất trong Theodia, mở khóa chú giải, từ điển, câu liên hệ, công cụ AI, và Trình đơn Launcher.
---

# Chế độ Học giả

> **Chế độ:** Chế độ Học giả chỉ có khi chế độ người dùng của bạn được đặt là **Học giả**. Đổi chế độ trong **Cài đặt** → **Chế độ người dùng ứng dụng**.

Chế độ Học giả mở khóa mọi công cụ học trong Theodia. Nó được xây trên nền Chế độ Nghiên cứu, nên bạn vẫn có trình đơn câu, Kinh Thánh song hành, dấu trang, phần đánh dấu, và ghi chú — cộng thêm các công cụ nâng cao dưới đây.

## Cách mở Chế độ Học giả

Chế độ Học giả không phải một màn hình riêng. Nó là một bộ công cụ bổ sung xuất hiện bên trong trình đọc và điều hướng có sẵn khi chế độ người dùng của bạn là Học giả.

1. Mở **Cài đặt**.
2. Chạm **Chế độ người dùng ứng dụng**.
3. Chọn **Học giả**.

Thay đổi có hiệu lực ngay lập tức. Các trình đơn và nút trước đây bị ẩn nay xuất hiện.

## Công cụ đọc bổ sung

Khi bạn mở một chương trong [Chế độ Nghiên cứu](theodia://help/study-mode), chế độ Học giả thêm các công cụ này vào trình đơn câu:

- **Chú giải AI** (◈) — nhờ trợ lý AI viết một ghi chú học cho câu này. (Không có ở mọi khu vực.)
- **Thông tin từ** (?) — mở một mục từ điển cho từ tiếng Do Thái hoặc Hy Lạp gốc đứng sau câu đó. Xem hướng dẫn [Chú giải và từ điển](theodia://help/commentaries-and-lexicons).
- **Từ điển** (📖) — tra các từ Kinh Thánh chung trong các tài nguyên từ điển bạn đã cài. Xem hướng dẫn [Từ điển Kinh Thánh](theodia://help/dictionary).

Các công cụ này cần tài nguyên được cài (chú giải, từ điển, tệp từ vựng). Nếu một công cụ bị xám hoặc hiện "không tìm thấy", hãy mở **Cài đặt** → **Quản lý tài nguyên** và thêm tài nguyên mà nó cần.

## Điều hướng bổ sung

### Thẻ thanh công cụ bổ sung

Thanh công cụ dưới đáy thêm một thẻ:

- 💻 **AI** — mở trợ lý AI (chỉ khi bạn đã bật AI trong Cài đặt). Thẻ này nằm bên phải Ghi chú.

### Mục trình đơn chính bổ sung

Trình đơn chính có thêm mục **Trợ lý AI** với cùng điều kiện như trên.

## Trình đơn Launcher

Chế độ Học giả bật **Trình đơn Launcher**, một cách nhanh để nhảy tới các câu gần đây, chạy lệnh, và đổi bố cục Kinh Thánh mà không rời màn hình đang dùng. Xem hướng dẫn [Trình đơn Launcher](theodia://help/launcher-menu) để biết cách dùng.

## Khi nào dùng Chế độ Học giả

- Bạn muốn có trợ lý AI, chú giải, hoặc tra từ ngôn ngữ gốc trong lúc đọc.
- Bạn muốn Trình đơn Launcher để điều hướng câu nhanh và trò chuyện với AI.
- Bạn đang học một bài Kinh Thánh sâu sắc và cần mọi công cụ chỉ cách một chạm.

## Chuyển sang chế độ nhẹ hơn

Nếu bạn muốn một trình đọc đơn giản hơn mà không cần các công cụ nâng cao, chuyển sang chế độ **Chuẩn** trong **Cài đặt** → **Chế độ người dùng ứng dụng**. Chế độ Chuẩn giữ dấu trang, phần đánh dấu, ghi chú, và Chế độ Nghiên cứu nhưng ẩn AI, chú giải, từ điển, và Trình đơn Launcher.

Nếu bạn muốn trải nghiệm đọc "sạch" nhất có thể, hãy mở một chương trong [Chế độ Tập trung](theodia://help/focus-mode).

Dấu trang, phần đánh dấu, và ghi chú của bạn không bao giờ bị xóa khi bạn đổi chế độ; chúng chỉ được ẩn đi cho đến khi bạn trở về một chế độ hỗ trợ chúng.

## Trợ giúp và câu hỏi

Nếu một công cụ bị thiếu hoặc hiện lỗi, xem hướng dẫn [Sự cố thường gặp](theodia://help/common-problems). Nếu bạn mới dùng Theodia, hướng dẫn [Đọc chương đầu tiên](theodia://help/first-read) sẽ đưa bạn qua từng bước cơ bản.
