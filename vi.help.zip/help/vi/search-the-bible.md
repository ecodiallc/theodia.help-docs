---
title: Tìm kiếm trong Kinh Thánh
level: everyday
categories: [study, read]
summary: Cách tìm các câu theo từ, cụm từ, hoặc địa chỉ câu.
---

# Tìm kiếm trong Kinh Thánh

Thanh tìm kiếm giúp bạn tìm câu nhanh. Bạn có thể tìm theo một từ, một cụm từ, hoặc một địa chỉ Kinh Thánh.

## Cách bắt đầu tìm kiếm

1. Chạm thẻ **Tìm kiếm** ở đáy màn hình.
2. Gõ điều bạn muốn tìm.
3. Chạm **Tìm kiếm** trên bàn phím.

Kết quả hiện ra dưới dạng danh sách các câu. Mỗi kết quả cho thấy sách, chương, và câu, cộng với văn bản câu đó.

## Tìm kiếm theo kết hợp từ

Khi bạn gõ nhiều hơn một từ, chẳng hạn `love joy`, ứng dụng tìm các câu chứa **cả hai** từ. Đây là tìm kiếm kiểu **AND** — mọi từ phải xuất hiện trong câu. Nó **không** dùng lô-gíc **OR** (các câu chỉ cần chứa một trong các từ).

Để tìm các câu chứa từ này hoặc từ kia, bạn phải dùng từ khóa `OR` tường minh: `love OR joy`.

## Tìm theo từ

Gõ một từ đơn, chẳng hạn `love` hay `mercy`. Ứng dụng hiện mọi câu trong Kinh Thánh có từ đó.

## Tìm theo cụm từ

Gõ hai hoặc ba từ trong dấu ngoặc kép, chẳng hạn `"do not be afraid"`. Ứng dụng hiện các câu có đúng cụm từ đó.

## Lọc kết quả

Sau một lượt tìm kiếm, kết quả được lọc theo các bản dịch Kinh Thánh bạn đã cài. Để thu hẹp hơn nữa, hãy mở thẻ **Kinh Thánh** và xem một bản dịch cụ thể — việc tìm kiếm chạy trên các bản dịch bạn đang có.

## Mẹo để tìm tốt hơn

- Dùng từ ngắn. Tìm `love` cho ra nhiều câu hơn tìm `loving`.
- Dấu ngoặc kép quanh một cụm từ làm cho tìm kiếm trở nên chính xác tuyệt đối.
- Ứng dụng chỉ tìm trong các bản dịch Kinh Thánh bạn đã cài.
- Để nhảy tới một câu cụ thể theo địa chỉ (ví dụ, `John 3:16`), hãy dùng ô **Lệnh** trên màn hình chính thay vì thẻ Tìm kiếm.

## Lịch sử tìm kiếm

Ứng dụng nhớ các lần tìm gần nhất của bạn. Khi mở thẻ **Tìm kiếm**, danh sách hiện các lần tìm gần đây của bạn ở trên cùng. Chạm một mục để chạy lại. Để xóa danh sách, chạm **Xóa hết** ở đầu phần tìm kiếm gần đây.

## Tìm trong tệp PDF

Thẻ Tìm kiếm cũng có thể tìm bên trong các tài liệu PDF của bạn:

1. Chạm thẻ **Tìm kiếm**, rồi chạm chế độ **PDF** ở trên cùng.
2. Chọn các tệp PDF cần tìm. Chạm một tệp PDF để thêm vào hoặc loại ra; dùng **Tất cả** hoặc **Xóa** phía trên danh sách để chọn tất cả hoặc bắt đầu lại. Chỉ các tệp PDF đã cài văn bản tìm kiếm được mới có thể được chọn.
3. Gõ điều bạn muốn tìm và chạm **Tìm kiếm**.

Mỗi kết quả hiển thị tiêu đề tệp PDF, số trang, và một đoạn văn bản khớp. Chạm một kết quả để mở tệp PDF đó tại trang đó.

Để tìm bên trong một tệp PDF đơn khi đang đọc nó, hãy dùng nút **Tìm kiếm** trong trình đọc PDF — xem [Tệp PDF](theodia://help/pdfs).
