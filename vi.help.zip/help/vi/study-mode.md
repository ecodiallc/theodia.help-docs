---
title: Chế độ Nghiên cứu
level: everyday
categories: [layout, read]
summary: Trình đọc Kinh Thánh đầy đủ của Theodia, chứa sẵn công cụ học như chú giải, câu liên hệ, từ điển, và ghi chú.
---

# Chế độ Nghiên cứu

> **Chế độ:** Chế độ Nghiên cứu có trong chế độ **Chuẩn** và **Học giả**. Chế độ Đọc giả mở các chương bằng Chế độ Tập trung thay thế. Bạn có thể đổi chế độ trong **Cài đặt** → **Chế độ người dùng ứng dụng**.

Chế độ Nghiên cứu là trình đọc Kinh Thánh chính của Theodia. Nó có sẵn mọi công cụ học: chú giải, câu liên hệ, tra từ, các bản dịch song hành, ghi chú, và hơn nữa.

Chế độ Tập trung là một trình đọc đơn giản hơn, không có công cụ học. Xem hướng dẫn [Chế độ Tập trung](theodia://help/focus-mode) nếu bạn chỉ muốn văn bản sạch sẽ. Hướng dẫn này dành cho Chế độ Nghiên cứu.

## Cách mở Chế độ Nghiên cứu

Có vài cách để mở một chương trong Chế độ Nghiên cứu:

- Chạm thẻ **Kinh Thánh** ở đáy màn hình. Chọn một bản dịch, một sách, và một chương.
- Chạm một câu trong kết quả **Tìm kiếm**.
- Chạm một dấu trang từ thẻ **Dấu trang**.
- Từ Chế độ Tập trung, chạm nút 📖 ở đầu màn hình để chuyển sang Chế độ Nghiên cứu.

## Đọc chương

Chương mở ra với các câu được liệt kê theo thứ tự. Ở đầu màn hình là các nút cho những thao tác thông dụng nhất. Ở đáy màn hình có một thanh trạng thái.

- **Vuốt sang trái** để sang chương kế.
- **Vuốt sang phải** để về chương trước.
- **Chạm vào một câu** để mở trình đơn câu với các công cụ học (xem bên dưới).
- **Chạm một số Strong trong câu** (ví dụ, G1234 hoặc H1234) để mở một tra cứu từ điển nhanh cho từ đó.

Nếu bạn đã bật một bản dịch song hành, một bản sao thứ hai của chương xuất hiện bên dưới bản chính, theo bản dịch bạn đã chọn. Xem **Đọc hai bản dịch cùng lúc** bên dưới.

## Trình đơn câu

Khi bạn chạm vào một câu, một trình đơn mở ra với tiêu đề "Sách Chương:Câu". Các công cụ bạn thấy tùy vào chế độ người dùng của bạn.

### Công cụ trong chế độ Chuẩn và Học giả

- **Dấu trang** (★) — lưu câu để bạn tìm lại được. Chạm lần nữa để gỡ dấu trang. Lần chạm đầu tiên sẽ thêm nó. Xem hướng dẫn [Đánh dấu trang các câu](theodia://help/bookmarks).
- **Đánh dấu** (□) — tô màu câu để nó nổi bật. Chạm nó để mở bộ chọn màu. Chạm lại cùng một màu để gỡ phần đánh dấu. Xem hướng dẫn [Đánh dấu màu các câu](theodia://help/highlights).
- **Đọc** (🔊) — cho câu được đọc thành tiếng bằng giọng đọc máy của thiết bị. Không hiện cho các Kinh Thánh song ngữ. Xem hướng dẫn [Đọc thành tiếng](theodia://help/tts) để biết cách dùng và cách chọn giọng.
- **Sao chép** (⎘) — đặt văn bản câu vào bộ nhớ tạm để bạn dán ở bất kỳ đâu.
- **So sánh** (⇄) — mở một bảng hiển thị cùng câu đó trong mọi bản dịch bạn đã cài. Chạm một bản dịch trong bảng để đọc câu theo bản dịch đó. Xem hướng dẫn [So sánh các bản dịch](theodia://help/compare-translations).
- **Câu liên hệ** (↗) — mở danh sách các câu liên quan từ cơ sở dữ liệu câu liên hệ. Xem hướng dẫn [Câu liên hệ](theodia://help/cross-references).
- **Thêm/Sửa ghi chú Kinh Thánh** (✎) — viết ghi chú riêng của bạn gắn với câu. Xem hướng dẫn [Viết ghi chú](theodia://help/notes).

### Công cụ chỉ trong chế độ Học giả

- **Chú giải AI** (◈) — nhờ trợ lý AI viết một ghi chú học cho câu này. (Không có ở mọi khu vực.)
- **Thông tin từ** (?) — mở một mục từ điển cho từ tiếng Do Thái hoặc Hy Lạp gốc đứng sau câu đó. Xem hướng dẫn [Chú giải và từ điển](theodia://help/commentaries-and-lexicons).
- **Từ điển** (📖) — tra các từ Kinh Thánh chung trong các tài nguyên từ điển bạn đã cài. Xem hướng dẫn [Từ điển Kinh Thánh](theodia://help/dictionary).

Một số công cụ cần thêm tài nguyên được cài. Nếu một công cụ bị xám hoặc hiện "không tìm thấy", hãy mở **Cài đặt** → **Quản lý tài nguyên** và thêm tài nguyên mà nó cần.

## Các nút phía trên màn hình

Phía trên văn bản chương là một hàng biểu tượng. Đây là các thao tác nhanh:

- **Phiên bản Kinh Thánh** — chạm tên bản dịch (ví dụ, "KJV") để chuyển sang bản dịch khác.
- **Sách** — chạm tên sách để nhảy sang sách khác.
- **Chương** — chạm số chương để nhảy sang chương khác.
- **Mở trong AI** (🤖) — gửi chương hiện tại tới trợ lý AI kèm câu hỏi của bạn. (Chỉ chế độ Học giả.)
- **Chế độ Tập trung** (📖) — chuyển sang Chế độ Tập trung để đọc sạch sẽ.
- **Kinh Thánh song hành** (🔵 / ⚪) — chạm để bật hoặc tắt các bản dịch song hành. Khi bật, cùng chương đó được hiển thị trong các bản dịch song hành bạn đã chọn, bên dưới văn bản chính. Khi tắt, chỉ bản dịch chính được hiện. Xem **Đọc nhiều bản dịch cùng lúc** bên dưới.
- **Nghe** — cho cả chương được đọc thành tiếng. Xem hướng dẫn [Đọc thành tiếng](theodia://help/tts).
- **Thêm** — mở các thao tác chương bổ sung (ghi chú Kinh Thánh cho chương, chú giải chương, chia sẻ, v.v.).

## Đọc nhiều bản dịch cùng lúc

Bạn có thể hiển thị tới bốn bản dịch bổ sung song song với bản chính. Tính năng này gọi là **chế độ xem song hành**.

1. Mở **Cài đặt**.
2. Bật **Kinh Thánh song hành**.
3. Chạm **Thêm Kinh Thánh song hành** và chọn một bản dịch.
4. Lặp lại để thêm bản khác. Bạn có thể có tới bốn bản dịch song hành.

Khi chế độ xem song hành bật, mỗi câu trong chương hiển thị bản dịch chính của bạn trước, rồi đến cùng câu đó trong từng bản dịch song hành. Điều này giúp dễ so sánh các dịch giả khác nhau xử lý một câu khó ra sao mà không phải rời chương.

Bạn có thể lưu bộ song hành hiện tại làm một **bộ sẵn**. Chạm nút lưu bên cạnh các bản dịch bạn đã chọn, đặt tên cho nó, và nó trở thành một lựa chọn chuyển nhanh. Chạm bất kỳ bộ sẵn nào sau này để nạp ngay tổ hợp đó. Nhấn giữ một bộ sẵn để xóa nó.

Bạn cũng có thể so sánh từng câu một với công cụ **So sánh** (⇄) trong trình đơn câu. Nó mở một bảng hiển thị câu đó trong mọi bản dịch đã cài.

## Tiêu đề phụ

Một số bản dịch có sẵn các tiêu đề mục (ví dụ, "Bài giảng trên núi"). Nếu bản dịch của bạn có chúng, bạn có thể hiện hoặc ẩn chúng bằng cài đặt **Hiện tiêu đề phụ** trong **Cài đặt**. Tiêu đề phụ xuất hiện dưới dạng các tiêu đề nhỏ màu xám giữa các câu.

## Ghi chú chương

Ghi chú chương là một ghi chú duy nhất gắn với cả chương, không phải với một câu. Nó hữu ích cho một suy nghĩ lớn về chương đó.

Để mở ghi chú chương:

1. Chạm nút **Thêm** ở đầu màn hình.
2. Chạm **Ghi chú chương**.
3. Viết ghi chú của bạn. Chạm **Lưu**.

Ghi chú chương được lưu cùng với chương. Nó xuất hiện mỗi khi bạn mở chương đó.

## Tô sáng kết quả tìm kiếm

Nếu bạn đến chương này từ một lượt tìm kiếm, các từ tìm kiếm của bạn được tô vàng trong văn bản câu. Điều này giúp dễ thấy lý do một câu khớp.

Bạn cũng có thể chạy lại một lượt tìm kiếm trên chương đang đọc. Mở thẻ **Tìm kiếm** và nhập một từ. Kết quả cho phép bạn chạm quay thẳng vào chương với các chỗ khớp được tô sáng.

Các Kinh Thánh song ngữ (MIB — Marvel Interlinear Bible — và OHGB) luôn mở trong Chế độ Nghiên cứu vì chúng cần bố cục ở mức từ.

## Chuyển sang Chế độ Tập trung cho một chương đơn lẻ

Từ bất kỳ chương nào trong Chế độ Nghiên cứu, chạm nút 📖 ở trên cùng. Cùng chương đó mở ra trong Chế độ Tập trung với mọi trình đơn được ẩn. Chạm nút 📖 trên thanh dưới đáy để chuyển ngược về Chế độ Nghiên cứu.

## Khi nào dùng Chế độ Nghiên cứu

Chế độ Nghiên cứu là lựa chọn đúng khi bạn muốn:

- **Vừa đọc vừa học cùng lúc.** Mọi công cụ chỉ cách một chạm.
- **Tra một từ bạn không biết.** Chạm một số Strong trong câu để xem nhanh mục từ điển.
- **So sánh các bản dịch.** Dùng công cụ So sánh trong trình đơn câu hoặc bật chế độ xem song hành.
- **Xem một câu liên hệ thế nào với phần còn lại của Kinh Thánh.** Dùng Câu liên hệ.
- **Ghi chú trong khi đọc.** Trình đơn câu có nhanh một lựa chọn "Thêm ghi chú".

Để đọc lâu dài không bị làm phiền, hãy chuyển sang Chế độ Tập trung.

## Chuyển sang Chế độ Tập trung

Từ bất kỳ chương nào trong Chế độ Nghiên cứu, chạm nút 📖 ở trên cùng. Cùng chương đó mở ra trong [Chế độ Tập trung](theodia://help/focus-mode) với các trình đơn và công cụ học được ẩn. Chạm nút 📖 trên thanh dưới đáy để chuyển ngược về Chế độ Nghiên cứu. Để có mô tả đầy đủ về những gì Chế độ Tập trung làm, xem hướng dẫn [Chế độ Tập trung](theodia://help/focus-mode).

## Trợ giúp và câu hỏi

Nếu một công cụ bị thiếu hoặc hiện lỗi, xem hướng dẫn [Sự cố thường gặp](theodia://help/common-problems). Nếu bạn mới dùng Theodia, hướng dẫn [Đọc chương đầu tiên](theodia://help/first-read) sẽ đưa bạn qua từng bước cơ bản.
