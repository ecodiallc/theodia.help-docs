---
title: Tính năng trên máy tính bảng
level: everyday
categories: [layout, tablet]
summary: Bố cục của Theodia thích ứng với máy tính bảng và màn hình lớn thế nào, với chế độ xem chia đôi, bảng bên, và chế độ đọc hai khung.
---

# 📱 Tính năng trên máy tính bảng

Theodia được thiết kế để tận dụng màn hình lớn trên máy tính bảng. Trên máy tính bảng (hoặc bất kỳ thiết bị nào rộng hơn khoảng 700 pixel), ứng dụng tự động chuyển sang bố cục hai cột ở nhiều nơi.

> **Chế độ:** Các tính năng mô tả ở đây chỉ xuất hiện nếu chế độ người dùng hiện tại của bạn hỗ trợ chúng. Ví dụ, bảng chú giải bên và trò chuyện AI chỉ có ở chế độ Học giả. Các chế độ xem chia đôi cho dấu trang, phần đánh dấu, và ghi chú cần chế độ Chuẩn hoặc Học giả. Chế độ Tập trung chỉ hiển thị đọc một cột sạch sẽ. Bạn có thể đổi chế độ trong **Cài đặt** → **Chế độ người dùng ứng dụng**.

## Trình đơn câu của trình đọc

Khi bạn chạm số câu (hoặc nhấn giữ văn bản câu), **trình đơn câu** xuất hiện như một **thẻ ở giữa màn hình** trên một nền tối.

- Các nút **Sao chép** và **Chia sẻ** luôn hiển thị ở đầu trình đơn.
- **Dấu trang** và **Phần đánh dấu** được hiển thị cùng trạng thái hiện tại.
- **Chú giải**, **Từ điển**, và **So sánh** mở từ trình đơn này. Trên máy tính bảng, các công cụ này có thể xuất hiện trong một bảng bên hoặc thẻ rộng sau khi được chọn.
- Chạm nền tối hoặc mũi tên đóng để bỏ trình đơn đi.

## Bảng Chú giải câu

Công cụ **Chú giải** mở một **bảng bên riêng** trên máy tính bảng:

- Văn bản chú giải xuất hiện bên cạnh văn bản Kinh Thánh.
- Bạn có thể cuộn chú giải độc lập với Kinh Thánh.
- Chạm **X** hoặc vuốt ra xa để đóng.
- Một **biểu tượng sách** ở đầu bảng cho phép bạn đổi nguồn chú giải.
- Một **biểu tượng chương** cho phép bạn xem chú giải cấp chương.

Trên điện thoại, chú giải mở dạng cửa sổ toàn màn hình.

## Chú giải chương

**Chú giải chương** được truy cập từ nút **Thêm** ở đầu màn hình, không phải từ trình đơn câu. Trên máy tính bảng nó mở như một bảng bên giống Chú giải câu, nên bạn có thể đọc chú giải và văn bản Kinh Thánh cùng lúc.

## Thẻ So sánh

Thẻ **So sánh** (trong trình đơn câu) mở dạng **bảng bên** trên máy tính bảng. Nó hiển thị câu đã chọn trong mọi phiên bản song hành bạn đã bật. Bạn có thể chạm bất kỳ phiên bản nào để nhảy tới bài đó trong trình đọc.

## Cửa sổ Từ điển / Strong

Công cụ **Từ điển** (trình đơn câu → Từ điển) mở như một thẻ rộng trên máy tính bảng. Nó hiển thị từ tiếng Hy Lạp hoặc Do Thái, cách phiên âm, định nghĩa, và số Strong. Chạm nút **Sách hợp nhịp** để xem mọi lần từ đó xuất hiện trong Kinh Thánh.

## Chạm một từ để mở Lexicon của nó

Trong bảng **Thông tin từ** trên máy tính bảng, mỗi thẻ từ có số Strong đều có thể chạm được. Chạm thẻ để mở trực tiếp bảng **Lexicon** cho từ đó. Bảng Lexicon thay thế bảng Thông tin từ nên bạn có thể tiếp tục học mà không cần đóng trình đọc.

Trên điện thoại, các thẻ Thông tin từ không thể chạm vì màn hình quá nhỏ để chứa hai bảng.

## Kinh Thánh song hành cạnh nhau

Trong Cài đặt, chạm **Kinh Thánh song hành** và chọn tới ba phiên bản. Trên máy tính bảng, các phiên bản xuất hiện như các **khung dọc** cạnh nhau:

- Mỗi khung cuộn độc lập.
- Bạn có thể chạm số câu để mở một bảng bên với các công cụ.
- Thẻ **So sánh** hiển thị mọi câu đã chọn ở một chỗ.
- Chạm **X** trên bất kỳ khung nào để đóng nó và trở về chế độ xem một cột.
- Chạm biểu tượng **Kinh Thánh song hành** (🔵 / ⚪) trên hàng biểu tượng phía trên để bật/tắt chế độ xem song hành mà không cần mở Cài đặt.

Trên điện thoại, các phiên bản song hành được hiển thị lần lượt (theo chiều dọc) thay vì cạnh nhau. Biểu tượng bật/tắt đó cũng hoạt động trên điện thoại.

## Chế độ xem chia đôi cho Dấu trang và Phần đánh dấu

Trên máy tính bảng, các thẻ **Dấu trang** và **Phần đánh dấu** dùng bố cục danh sách–chi tiết:

- **Bên trái** — danh sách các dấu trang hoặc phần đánh dấu.
- **Bên phải** — chạm một mục sẽ mở một khung xem trước với văn bản câu hoặc bài đó.

Bạn có thể lướt qua các mục đã lưu và xem trước chúng mà không rời thẻ. Trên điện thoại, chạm một mục sẽ điều hướng tới màn hình trình đọc.

## Chế độ xem chia đôi cho Ghi chú

Thẻ **Ghi chú** trên máy tính bảng hiển thị danh sách ghi chú bên trái và ghi chú đã chọn bên phải. Chạm một ghi chú sẽ mở nó trong một bảng bên nên bạn có thể lướt qua vài ghi chú liên tiếp mà không rời danh sách. Việc tạo hoặc sửa ghi chú cũng dùng bảng bên.

## Chế độ xem chia đôi cho Tìm kiếm

Trên máy tính bảng, thẻ **Tìm kiếm** hiển thị biểu mẫu tìm kiếm bên trái và kết quả bên phải ngay khi bạn chạy tìm kiếm. Bạn có thể tinh chỉnh truy vấn và xem kết quả cập nhật mà không đổi màn hình. Trên điện thoại, kết quả tìm kiếm mở trên một màn hình riêng.

## Thanh bên danh mục trong Cài đặt

Màn hình **Cài đặt** trên máy tính bảng hiển thị một danh sách danh mục bên trái (AI, Diện mạo, Sao lưu, Kinh Thánh, v.v.). Chạm một danh mục để nhảy thẳng tới cài đặt của nó bên phải. Chỉ danh mục được chọn mới được mở rộng, nên bạn không bao giờ phải cuộn qua toàn bộ danh sách cài đặt.

## Điều hướng Kinh Thánh trên máy tính bảng

Các màn hình **Danh sách Kinh Thánh**, **Các sách Kinh Thánh**, và **Các chương Kinh Thánh** vẫn giữ một cột trên máy tính bảng, nhưng chúng dùng mục tiêu chạm lớn hơn, lưới rộng hơn, và khoảng đệm thoáng hơn để nội dung dễ đọc và dễ chạm hơn. Chúng không dùng bố cục chia đôi vì mỗi bước cần toàn bộ chiều rộng để hiển thị danh sách hoặc lưới của mình rõ ràng.

## Ngang và dọc

Xoay máy tính bảng tự động điều chỉnh bố cục. Ở chế độ **ngang**, các bảng bên có nhiều không gian. Ở chế độ **dọc**, các bảng hẹp hơn nhưng vẫn nằm bên cạnh văn bản.

## Trò chuyện AI cho câu đã chọn

Trò chuyện **AI** mở trong bảng bên của trình đơn câu. Nó hiển thị một giao diện hội thoại nơi bạn có thể đặt câu hỏi về câu đã chọn. Câu trả lời của AI xuất hiện trong bảng, và bạn có thể tiếp tục trò chuyện mà không rời trình đọc.

## Thanh bên hội thoại trong màn hình AI

Trong thẻ **AI** trên máy tính bảng, danh sách hội thoại luôn hiển thị như một thanh bên trái cố định. Bạn có thể chuyển giữa các cuộc trò chuyện mà không cần mở trình đơn. Nút **Trò chuyện mới** cũng luôn hiển thị. Trên điện thoại, danh sách hội thoại là một ngăn kéo dạng cửa sổ.

## Cái gì giữ nguyên

Không phải mọi màn hình đều chia thành hai khung. Các màn hình sau vẫn một cột trên máy tính bảng:

- **Danh sách Kinh Thánh** — danh sách các phiên bản Kinh Thánh (toàn chiều rộng)
- **Các sách Kinh Thánh** — lưới sách và các phần (toàn chiều rộng)
- **Các chương Kinh Thánh** — lưới chương (toàn chiều rộng)
- **PDF** — thư viện PDF dùng lưới thẻ rộng hơn (toàn chiều rộng)
- **Cài đặt** — từng trang cài đặt riêng lẻ (toàn chiều rộng)
- **Trợ giúp** — các bài trợ giúp (toàn chiều rộng)

## Tóm lại

Trên máy tính bảng, bạn có:

- **Kinh Thánh song hành** trong các khung dọc cạnh nhau
- **Chú giải** trong các bảng bên cố định
- **So sánh** và **Từ điển** trong các thẻ rộng
- **Lexicon** chỉ với một chạm vào bất kỳ thẻ Thông tin từ nào
- **Dấu trang, Phần đánh dấu, Ghi chú, Tài liệu linh đạo, Sách, Cài đặt** trong các chế độ xem chia đôi kiểu danh sách–chi tiết
- **Tìm kiếm** với kết quả ngay cạnh biểu mẫu tìm kiếm
- Cả chế độ **ngang** và **dọc** đều được hỗ trợ với bố cục tự điều chỉnh

Trên điện thoại, mọi thứ dùng điều hướng kiểu đi sâu từng tầng một cột truyền thống. Ứng dụng dò chiều rộng màn hình khi khởi động và tự chọn bố cục phù hợp.
