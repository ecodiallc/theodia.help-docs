---
title: Đổi giao diện và phông chữ
level: everyday
categories: settings
summary: Cách đổi hình thức của ứng dụng.
---

# Đổi giao diện và phông chữ

Theodia cho phép bạn đổi hình thức của ứng dụng. Bạn có thể chọn một chủ đề (sáng hoặc tối) và một cỡ chữ.

## Cách mở cài đặt diện mạo

1. Mở **Cài đặt**.
2. Chạm **Diện mạo**.

## Cách đổi chủ đề

Trong mục **Diện mạo**, bạn thấy hai nút chủ đề:

- **Mặc định** — nền sáng với chữ tối. Hợp ban ngày.
- **Tối** — nền tối với chữ sáng. Hợp ban đêm và tiết kiệm pin.

Chạm một chủ đề để áp dụng nó. Thay đổi có hiệu lực ngay lập tức.

## Cách đổi cỡ chữ

Trong mục **Diện mạo**, chạm một trong các nút cỡ: **---**, **--**, **-**, **Vừa**, **+**, **++**, **+++**. Chữ to lên hoặc nhỏ xuống trên toàn ứng dụng. Chọn cỡ dễ đọc nhất cho bạn.

## Mẹo

- Chủ đề tối tiết kiệm pin trên các điện thoại màn hình OLED.
- Nếu chữ quá nhỏ để đọc, hãy tăng cỡ chữ trong ứng dụng, không phải trên thiết bị. Cài đặt của ứng dụng tinh hơn.
- Để đọc lâu, hãy thử chủ đề tối cùng một cỡ chữ lớn hơn.
- [Bật chủ đề sa mạc](theodia://unlock-desert)
