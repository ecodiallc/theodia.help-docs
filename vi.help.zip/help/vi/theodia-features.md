---
title: Các tính năng của Theodia
level: beginner
categories: welcome
summary: Tổng quan nhanh về những gì làm cho Theodia đặc biệt và cách nó giúp bạn học Kinh Thánh.
---

# Các tính năng của Theodia

Theodia được xây để là một người bạn đồng hành học Kinh Thánh trọn vẹn. Đây là những điều làm nó nổi bật.

## Ngoại tuyến là ưu tiên

Mọi thứ đều hoạt động khi không có internet. Kinh Thánh, chú giải, từ điển, sách, và tài liệu linh đạo được lưu trên thiết bị của bạn. Bạn có thể đọc, tìm, và học ở bất kỳ đâu — trên máy bay, ở vùng hẻo lánh, hay bất kỳ nơi nào không có sóng.

## Tập trung vào riêng tư

Dữ liệu của bạn ở lại với bạn. Ghi chú, phần đánh dấu, dấu trang, và lịch sử đọc được lưu cục bộ trên thiết bị. Không cần tài khoản, và không có gì được gửi tới máy chủ trừ khi bạn chọn dùng trợ lý AI tùy chọn.

## Hỗ trợ máy tính bảng

Theodia được thiết kế cho cả điện thoại và máy tính bảng. Trên màn hình lớn hơn, bạn có nhiều không gian để đọc, các chế độ xem Kinh Thánh song hành, và một bố cục tận dụng được phần không gian thêm đó.

## Tài nguyên có thể cài

Bạn không bị giới hạn ở những gì đi kèm ứng dụng. Bạn có thể thêm nhiều phiên bản Kinh Thánh, chú giải, từ điển, sách, và tài liệu linh đạo hơn. Tài nguyên có trên trang GitHub của dự án và có thể cài trực tiếp vào ứng dụng.

## Trợ lý AI

Trợ lý AI tùy chọn giúp bạn hiểu các câu, giải thích ngữ cảnh, và trả lời câu hỏi. Nó chỉ hoạt động khi bạn bật nó. Theo mặc định, nó kết nối tới một mô hình từ xa mà bạn cung cấp qua một điểm cuối và khóa API do bạn cấu hình. Lần đầu bạn dùng AI, ứng dụng xin phép bạn và hiển thị chính xác những gì được gửi đi.

## Đọc Kinh Thánh song hành

Đọc tới bốn phiên bản Kinh Thánh cùng lúc. Khi bạn mở một chương, bản dịch chính của bạn hiện trước, và mỗi câu được theo sau bởi cùng câu đó trong các bản dịch song hành bạn đã chọn. So sánh cách diễn đạt, học những khác biệt, và có được bức tranh đầy đủ hơn về văn bản. Lưu các tổ hợp ưa thích làm bộ sẵn và chuyển giữa chúng một cách nhanh chóng.

## Tìm kiếm toàn văn

Tìm trên bất kỳ phiên bản Kinh Thánh nào. Tìm từ, cụm từ, hoặc khớp một phần. Bạn cũng có thể giới hạn tìm kiếm trong một khoảng sách.

## Câu liên hệ

Chạm một địa chỉ câu để nhảy thẳng tới bài đó. Câu liên hệ được xây sẵn và hoạt động trên toàn bộ Kinh Thánh.

## Từ điển và số Strong

Chạm một số Strong để xem định nghĩa tiếng Hy Lạp hoặc Do Thái gốc. Các mục từ điển có sẵn để học từ sâu hơn.

## Dấu trang và Phần đánh dấu

Lưu các câu bằng dấu trang và tô màu chúng. Mọi thứ được lưu cục bộ và giữ nguyên giữa các lần dùng.

## Ghi chú

Viết suy nghĩ của riêng bạn bên cạnh bất kỳ câu nào. Ghi chú gắn với câu và dễ tìm lại sau này.

## Tài liệu linh đạo hằng ngày

Bắt đầu ngày của bạn với một bài đọc tôn kính ngắn. Ứng dụng có các tài liệu linh đạo tự mở tới mục của hôm nay.

## Sách Cơ Đốc

Đọc văn chương Cơ Đốc kinh điển ngay trong ứng dụng. Sách được định dạng để đọc dễ dàng và có mục lục để điều hướng nhanh.

## Đọc PDF

Nhập các tài liệu PDF của riêng bạn và đọc chúng ngoại tuyến, được sắp xếp theo danh mục. Trình đọc hỗ trợ tìm kiếm, mục lục, dấu trang, phóng to, và đọc thành tiếng. Bạn cũng có thể cài các bộ sưu tập PDF đã đóng gói từ kho cộng đồng.

## Nhiều ngôn ngữ

Theodia hỗ trợ nhiều ngôn ngữ cho cả giao diện ứng dụng lẫn nội dung Kinh Thánh. Đổi ngôn ngữ trong phần cài đặt để học bằng ngôn ngữ bạn ưa thích.

## Chế độ tối và các chủ đề

Chọn chế độ sáng hoặc tối, hoặc chọn một chủ đề hợp ý bạn. Sự dễ chịu khi đọc rất quan trọng, nhất là nơi thiếu ánh sáng.

## Sao lưu dữ liệu

Sao lưu ghi chú, dấu trang, và phần đánh dấu của bạn. Giữ dữ liệu an toàn và chuyển sang thiết bị mới khi cần.

## Không quảng cáo, Không xao nhãng

Theodia được xây để tập trung. Không quảng cáo, không cửa sổ bật lên, không làm phiền. Chỉ có văn bản và các công cụ học của bạn.
