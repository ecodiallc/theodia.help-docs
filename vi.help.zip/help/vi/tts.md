---
title: Đọc thành tiếng (Text-to-Speech)
level: everyday
categories: tts
summary: Cho Theodia đọc Kinh Thánh hay tài liệu linh đạo thành tiếng. Cách dùng, cách chọn giọng, và việc cần làm khi nó im lặng.
---

# Đọc thành tiếng (Text-to-Speech)

> **Chế độ:** Đọc máy (text-to-speech) có trong chế độ **Chuẩn** và **Học giả**. Chế độ Tập trung chỉ dành cho việc đọc sạch sẽ, không bị làm phiền. Bạn có thể đổi chế độ trong **Cài đặt** → **Chế độ người dùng ứng dụng**.

Theodia có thể đọc văn bản thành tiếng bằng giọng đọc máy (TTS) của thiết bị. Bạn có thể nghe một câu đơn, cả một chương, hay một tài liệu linh đạo. Cách này hữu ích để đọc tay không, nghe khi đi bộ hay đi đường, đọc cùng với âm thanh, hoặc đơn giản là cho đôi mắt nghỉ ngơi.

## Nút nghe nằm ở đâu

Bạn sẽ thấy một nút nghe ở ba nơi.

### 1. Trong trình đơn câu (một câu đơn)

Đây là cách nhanh nhất để nghe từng câu một. Mở một chương trong [Chế độ Nghiên cứu](theodia://help/study-mode), chạm một câu để mở trình đơn câu, rồi chạm **Đọc** (🔊). Việc đọc bắt đầu từ câu đó. Một thanh điều khiển nhỏ xuất hiện ở đáy màn hình với phát, tạm dừng, tua lại, tua nhanh, và một bộ chọn giọng.

Tùy chọn Đọc không hiện cho các Kinh Thánh song ngữ (MIB — Marvel Interlinear Bible — và OHGB), vì chúng hiển thị các từ theo một bố cục khác mà đọc lên nghe không tự nhiên.

### 2. Ở đầu một chương (cả chương)

Khi đang đọc một chương, hãy nhìn vào hàng biểu tượng ở đầu màn hình. Chạm **Nghe** (🔊) để bắt đầu đọc cả chương từ đầu. Nút này biến thành nút dừng (⏹) khi âm thanh đang phát. Chạm lại để dừng. Thanh điều khiển như vậy xuất hiện ở đáy.

Bạn có thể nhảy tới một câu khác, và nút Nghe tại đó sẽ bắt đầu từ câu đó thay vì chỗ cũ.

### 3. Trong một tài liệu linh đạo

Mở một ngày bất kỳ của tài liệu linh đạo, rồi chạm nút **Nghe** (🔊) ở đầu bài đọc. Toàn bộ văn bản linh đạo được đọc to, từng câu một. Một thanh điều khiển ở đáy cho bạn các nút phát, tạm dừng, tua lại, và điều khiển giọng đọc.

## Dùng thanh điều khiển

Trong khi âm thanh đang phát, một thanh nhỏ luôn hiển thị ở đáy màn hình. Nó có sáu nút điều khiển:

- ⏪ **Tua lại** — lùi lại một câu (hoặc một câu chữ trong tài liệu linh đạo)
- ⏸ **Tạm dừng / ▶ Tiếp tục** — tạm dừng mà không mất vị trí. Chạm lần nữa để tiếp tục từ đúng chỗ đó.
- ⏩ **Tua nhanh** — nhảy sang câu kế (hoặc câu chữ kế trong tài liệu linh đạo)
- 🎙 **Giọng đọc** — mở bộ chọn giọng mà không rời chương (xem bên dưới)
- ⚙ **Tùy chọn** — mở bảng tùy chọn mở rộng (xem bên dưới)
- **Dừng** — chạm nút 🔊 ở đầu màn hình, hoặc nút ⏹ thay thế nó khi âm thanh đang phát, để dừng và đóng thanh.

Thanh điều khiển đóng khi chương kết thúc hoặc khi bạn chạm dừng.

### Tùy chọn mở rộng

Chạm ⚙ để mở các tùy chọn phát bổ sung. Các cài đặt này chỉ áp dụng cho chương hiện tại và được đặt lại khi bạn đổi chương hay ngừng nghe.

- ⏮ **Về đầu** — nhảy tới câu đầu tiên của đoạn bạn đã đặt.
- **Bắt đầu** — gõ số câu để đặt nơi bắt đầu đọc.
- **Kết thúc** — gõ số câu để đặt nơi ngừng đọc.
- **Tất cả** — đặt lại đoạn về toàn bộ chương.
- **()** — bật/tắt việc đọc to văn bản trong ngoặc đơn.
- 🔁 **Lặp lại** — tự động bắt đầu lại từ đầu đoạn khi đến cuối, kèm một khoảng ngắn xen giữa. Nếu bạn bật tùy chọn này mà không đặt câu bắt đầu hay kết thúc, cả chương sẽ được lặp lại.

### Trong các màn hình cầu nguyện

Các tín điều và lời cầu nguyện cố định, các lời cầu nguyện được tạo ra, và các phụ đề cầu nguyện có bộ tùy chọn mở rộng riêng. Chạm ⚙ trên thanh điều khiển để mở chúng:

- **Tốc độ** — chạm mức tốc (ví dụ `1x`) để chọn tốc độ đọc từ 0.1x đến 1.5x. Lựa chọn của bạn được ghi nhớ và dùng cho lần đọc to tiếp theo.
- **()** — bật/tắt việc đọc to văn bản trong ngoặc đơn.
- 🔁 **Lặp lại** — tự động bắt đầu lại lời cầu nguyện từ đầu khi nó kết thúc, kèm một khoảng ngắn xen giữa. Điều này hữu ích để học thuộc một tín điều hay một lời cầu nguyện cố định.

Đổi tốc độ có hiệu lực ngay lập tức mà không mất vị trí. Bật hoặc tắt tùy chọn ngoặc đơn sẽ bắt đầu lại lời cầu nguyện từ đầu để thay đổi có thể được nghe từ đầu.

## Cách đổi giọng đọc

Bạn có thể chọn giọng Theodia dùng để đọc. Điều này hữu ích nếu bạn muốn một giọng khác, một ngôn ngữ khác, hoặc một giọng nhanh hơn hay chậm hơn so với mặc định của thiết bị.

1. Mở **Cài đặt**.
2. Tìm mục **Phát âm**.
3. Chạm **Chọn giọng**.
4. Một danh sách giọng xuất hiện. Hàng đầu tiên, **Mặc định hệ thống**, dùng giọng thiết bị bạn ưa dùng. Chọn bất kỳ hàng khác nào để làm mặc định mới.
5. Lựa chọn của bạn được lưu và dùng cho lần chạm **Nghe** hay **Đọc** tiếp theo.

Bạn cũng có thể chạm biểu tượng 🎙 trên thanh điều khiển nghe để mở cùng bộ chọn đó mà không rời chương.

Giọng có sẵn hoàn toàn tùy vào thiết bị của bạn. iOS và Android đều kèm một bộ giọng cài sẵn. Bạn có thể cài thêm giọng từ phần **Trợ năng** hoặc **Ngôn ngữ & Nhập liệu** của thiết bị. Theodia có thể dùng bất kỳ giọng nào đã cài trên thiết bị của bạn.

## Các giọng ưa thích

Nếu thiết bị của bạn có nhiều giọng, việc cuộn qua toàn bộ danh sách mỗi lần có thể chậm. Bạn có thể tạo một danh sách ngắn **các giọng ưa thích** và các bộ chọn giọng sẽ chỉ hiện những giọng đó.

1. Mở **Cài đặt**.
2. Tìm mục **Phát âm**.
3. Chạm **Giọng ưa thích** (hàng đầu tiên ở đầu mục).
4. Chạm **Đặt giọng ưa thích** để mở màn hình yêu thích.
5. Chạm nút phát bên cạnh một giọng để nghe thử. Chạm ngôi sao để thêm nó vào danh sách yêu thích. Bạn có thể yêu thích bao nhiêu giọng tùy thích.
6. Quay lại. Các bộ chọn giọng trong toàn Theodia nay chỉ hiện các giọng ưa thích của bạn.

Nếu bạn xóa hết yêu thích, các bộ chọn quay lại hiển thị mọi giọng. Các giọng ưa thích được đưa vào khi bạn sao lưu và khôi phục cài đặt Theodia.

## Đặt giọng riêng cho từng bản Kinh Thánh

Bạn có thể cho mỗi bản dịch Kinh Thánh một giọng riêng. Điều này hữu ích khi bạn chuyển giữa các bản dịch đọc rất khác nhau — ví dụ, một giọng trang trọng hơn cho King James Version và một giọng gần gũi hơn cho bản dịch hiện đại như NIV hay NLT. Nó cũng giúp khi bạn nghe các Kinh Thánh bằng nhiều ngôn ngữ khác nhau và muốn mỗi bản được đọc đúng giọng.

1. Mở **Cài đặt**.
2. Tìm mục **Phát âm**.
3. Tìm **Giọng Kinh Thánh**.
4. Chạm bất kỳ bản Kinh Thánh nào trong danh sách.
5. Chọn giọng bạn muốn cho bản dịch đó. Hàng đầu tiên, **Mặc định hệ thống**, dùng giọng TTS chính của bạn cho bản Kinh Thánh đó.
6. Lặp lại cho các bản Kinh Thánh khác.

Phần đầu hiển thị số bản dịch Kinh Thánh đã có giọng riêng. **Chọn giọng**, **Giọng chú giải**, **Giọng ghi chú Kinh Thánh**, và **Giọng tài liệu linh đạo** cũng hiện một con số khi có giọng được đặt.

Lần tới bạn nghe một chương từ bản Kinh Thánh đó, Theodia sẽ dùng giọng bạn đã chọn. Tất cả các bản Kinh Thánh khác vẫn dùng giọng mặc định chính trừ khi bạn cũng đổi chúng.

## Tiếp tục phát âm ở nền

Theo mặc định, Theodia dừng việc phát âm khi bạn rời màn hình trình đọc, chuyển sang ứng dụng khác, hoặc khóa điện thoại. Điều này tránh âm thanh bất ngờ khi bạn không còn đang đọc.

Để cho việc phát âm tiếp tục chạy ở nền:

1. Mở **Cài đặt**.
2. Tìm mục **Phát âm**.
3. Bật **Tiếp tục phát âm ở nền**.

Khi điều này bật, bạn có thể chuyển thẻ, mở ứng dụng khác, hoặc khóa màn hình và chương hay tài liệu linh đạo sẽ tiếp tục được đọc. Thanh điều khiển vẫn hoạt động nên bạn có thể tạm dừng hay bỏ qua từ khu thông báo (nếu thiết bị của bạn hỗ trợ).

Tắt công tắc này khi việc phát âm đang chạy sẽ dừng nó ngay lập tức.

## Nếu nó không hoạt động thì làm gì

Đọc máy phụ thuộc vào thiết bị của bạn. Theodia gửi văn bản cho hệ điều hành, và hệ điều hành đọc nó to bằng một giọng. Nếu nó không hoạt động, hãy thử các bước sau theo thứ tự.

### Theodia báo TTS không có sẵn

Một số thiết bị không có TTS nào cả. Mở **Cài đặt** và tìm mục **TTS**. Nếu mục không có ở đó, thiết bị của bạn không hỗ trợ TTS trong bản dựng này.

### Danh sách giọng trống

Bộ chọn giọng có thể hiện "không tìm thấy giọng nào". Điều này thường có nghĩa thiết bị chưa nạp xong các giọng của nó.

1. Mở **Cài đặt → Phát âm → Chọn giọng**.
2. Nếu danh sách trống, tìm nút **Thử lại** ngay bên dưới ô chọn. Chạm nó. Theodia hỏi lại thiết bị về các giọng.
3. Nếu vẫn trống, kiểm tra cài đặt hệ thống của thiết bị. Trên iOS, vào **Cài đặt → Trợ năng → Nội dung đọc thành tiếng → Giọng đọc** và tải xuống một giọng cho ngôn ngữ của bạn. Trên Android, vào **Cài đặt → Ngôn ngữ & Nhập liệu → Đầu ra Text-to-Speech** và chạm **Cài dữ liệu giọng**.
4. Đóng rồi mở lại Theodia để nó nhận giọng mới.

Nếu bạn đã đặt các giọng ưa thích mà danh sách trống, hãy đảm bảo ít nhất một giọng yêu thích của bạn khớp với một giọng đã cài trên thiết bị này.

### Chạm Đọc nhưng không có gì xảy ra

- Kiểm tra thiết bị không đang ở chế độ im lặng. Hầu hết thiết bị sẽ không phát âm thanh TTS khi đang im lặng.
- Đảm bảo âm lượng thiết bị đã bật lên.
- Thử nút **Thử lại** trong **Cài đặt → Phát âm**.
- Mở **Cài đặt** và xem mục **Hệ thống** ở đáy. Hàng **TTS** phải ghi **Có sẵn**. Nếu nó ghi **Không có sẵn**, TTS bị tắt ở cấp hệ điều hành. Bật lại nó tại đó, rồi mở lại Theodia.

### Âm thanh phát nhưng sai ngôn ngữ

Theodia gửi văn bản theo ngôn ngữ của nội dung hiện tại và xin thiết bị giọng bạn đã chọn. Nếu giọng đã chọn thuộc ngôn ngữ khác, thiết bị vẫn có thể đọc văn bản, nhưng nó sẽ nghe kỳ lạ.

1. Mở **Cài đặt → Phát âm → Chọn giọng**.
2. Chọn **Mặc định hệ thống** để để thiết bị tự chọn giọng đúng, hoặc chọn một giọng có ngôn ngữ khớp với văn bản bạn đang đọc.

Theodia hiện không đọc to các Kinh Thánh song ngữ tiếng Hy Lạp hay Do Thái. Các nút Đọc và Nghe bị ẩn trên những bản dịch đó.

### Âm thanh phát nhưng dừng sớm

Nếu một câu bị thiếu hoặc không đọc được, chương sẽ bỏ qua sang câu kế. Nếu thanh tự đóng sau vài câu, chạm nút **Nghe** (🔊) ở đầu màn hình để bắt đầu lại.

### Âm thanh đang phát nhưng tôi không biết nó bắt đầu từ đâu

Nếu bạn đã bật **Tiếp tục phát âm ở nền** và sau đó nghe thấy âm thanh nhưng không tìm ra màn hình đã khởi phát, bạn có thể dừng nó từ bất kỳ đâu trong ứng dụng.

1. Mở **Cài đặt**.
2. Tìm mục **Phát âm**.
3. Chạm nút đỏ **Dừng phát âm** ở đáy mục.

Điều này dừng ngay lập tức mọi việc đọc máy đang chạy trong Theodia. Bạn cũng có thể mở trình chuyển ứng dụng trên thiết bị và vuốt Theodia đi để buộc dừng âm thanh.

### Nó đọc quá nhanh hoặc quá chậm

Theodia không điều khiển tốc độ đọc. Tốc độ được đặt bởi giọng đã chọn. Để đổi nó:

- Trên iOS: **Cài đặt → Trợ năng → Nội dung đọc thành tiếng → Tốc độ đọc**.
- Trên Android: **Cài đặt → Ngôn ngữ & Nhập liệu → Đầu ra Text-to-Speech → Tốc độ đọc**.

## Mẹo

- Thanh điều khiển vẫn hiển thị khi bạn di chuyển giữa các chương, nên bạn có thể tạm dừng, bỏ qua, hay đổi giọng mà không mất vị trí.
- Theodia đọc số câu như một khoảng ngắt nhỏ. Bạn có thể dừng thanh, vuốt sang một câu khác, rồi chạm phát để tiếp tục từ đó.
- Với những lần nghe dài, hãy bật **Không làm phiền** để các thông báo không ngắt âm thanh.
- Nút 🔊 dùng âm lượng hiện tại của thiết bị. Nếu bạn cắm tai nghe, âm lượng chuyển sang mức tai nghe.

## Đọc một tệp PDF thành tiếng

Theodia cũng có thể đọc to các trang PDF. Mở một tệp PDF và chạm nút **Nghe** (loa) trên thanh công cụ của nó. Một thanh điều khiển xuất hiện với phát/tạm dừng, tua lại, tua nhanh, dừng, một thanh tiến trình, và các bộ chọn tốc độ cùng giọng. Khi một trang kết thúc, việc đọc tự động tiếp tục trên trang kế.

Việc đọc PDF dùng văn bản tìm kiếm được đã cài của tệp PDF, cùng các giọng và tốc độ như khi đọc Kinh Thánh.

## Các hướng dẫn liên quan

- Hướng dẫn [Chế độ Nghiên cứu](theodia://help/study-mode) nói kỹ hơn về trình đơn câu và các nút phía trên màn hình.
- Hướng dẫn [Chế độ Tập trung](theodia://help/focus-mode) là chế độ xem đọc "sạch" hơn, cũng hỗ trợ TTS qua nút 🔊 trên thanh dưới đáy.
- Hướng dẫn [Sự cố thường gặp](theodia://help/common-problems) có cách khắc phục cho các vấn đề âm thanh, giọng đọc, và ngôn ngữ khác.
- Hướng dẫn [Tài liệu linh đạo hằng ngày](theodia://help/daily-devotionals) nói về việc đọc tài liệu linh đạo và nút nghe nằm ở đâu trên màn hình đó.
- Hướng dẫn [Tệp PDF](theodia://help/pdfs) nói về trình đọc PDF và nút nghe của nó.
