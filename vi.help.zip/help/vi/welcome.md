---
title: Chào mừng đến với Theodia
level: beginner
categories: welcome
summary: Một vòng giới thiệu ngắn về ứng dụng và những gì nó có thể làm cho bạn.
---

# Chào mừng đến với Theodia

Theodia là một ứng dụng học Kinh Thánh. Nó chạy trên điện thoại hoặc máy tính bảng của bạn, kể cả khi không có internet. Mọi thứ bạn đọc, tìm, và học đều được lưu trên thiết bị.

## Bạn có thể làm gì

Theodia có ba chế độ người dùng. Mỗi chế độ hiển thị một bộ tính năng khác nhau.

- **Đọc giả** — đọc Kinh Thánh trong một chế độ xem sạch sẽ, không xao nhãng.
- **Chuẩn** — mọi thứ trong Đọc giả, cộng thêm dấu trang, phần đánh dấu, ghi chú, đọc máy, tìm kiếm, và tài liệu linh đạo hằng ngày.
- **Học giả** — mọi thứ trong Chuẩn, cộng thêm chú giải, từ điển, Từ điển Kinh Thánh, trợ lý AI, và hơn nữa.

Bạn có thể đổi chế độ bất cứ lúc nào trong **Cài đặt** → **Chế độ người dùng ứng dụng**.

### Các tính năng sẵn có cho bạn

Dù chọn chế độ nào, bạn luôn có thể:

- **Đọc Kinh Thánh.** Chọn trong nhiều bản dịch. Chuyển giữa chúng bất cứ lúc nào.
- **Tìm trong Kinh Thánh.** Tìm một từ hay một cụm từ. Ứng dụng cho bạn xem mọi câu khớp.
- **Đọc sách và tài liệu linh đạo.** Ứng dụng đi kèm các tác phẩm kinh điển Cơ Đốc và một tài liệu linh đạo hằng ngày.

Tùy vào chế độ của bạn, bạn còn có thể:

- **Nghe.** Cho các câu được đọc thành tiếng bằng tính năng đọc to. (Chuẩn và Học giả.)
- **Ghi chú.** Viết suy nghĩ của riêng bạn bên cạnh một câu. (Chuẩn và Học giả.)
- **Đánh dấu.** Tô màu các câu yêu thích. (Chuẩn và Học giả.)
- **Đánh dấu trang.** Lưu các câu để tìm lại nhanh. (Chuẩn và Học giả.)
- **Hỏi trợ lý AI.** Nhận giúp đỡ để hiểu một câu. (Chỉ Học giả.)

## Bắt đầu từ đâu

1. Mở thẻ **Kinh Thánh** ở đáy màn hình.
2. Chọn một bản dịch.
3. Chạm bất kỳ sách nào để bắt đầu đọc.

Nếu bạn muốn tìm hiểu thêm, các hướng dẫn trợ giúp còn lại sẵn sàng cho bạn. Chọn một chủ đề từ danh sách trên trang chủ của phần trợ giúp.

## Vài điều cần biết

- Bạn không cần tài khoản.
- Ghi chú, phần đánh dấu, và dấu trang của bạn nằm trên thiết bị.
- Bạn có thể sao lưu chúng. Xem hướng dẫn [Sao lưu dữ liệu của bạn](theodia://help/backups) để biết cách làm.

## Muốn thêm tài nguyên?

Ứng dụng đi kèm vài phiên bản Kinh Thánh có sẵn miễn phí. Để có thêm Kinh Thánh, chú giải, từ điển, sách, và tài liệu linh đạo, xem hướng dẫn [Tải tài nguyên bổ sung từ GitHub](theodia://help/getting-core-files). Nó chỉ cho bạn cách tìm và thêm nhiều tài nguyên hơn từ trang GitHub của dự án.

Chào mừng bạn. Chúng tôi mong Theodia giúp bạn đọc và học Kinh Thánh.
