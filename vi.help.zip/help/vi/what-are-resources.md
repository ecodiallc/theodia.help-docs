---
title: Tài nguyên là gì?
level: beginner
categories: resources
summary: Tổng quan về các loại tệp Theodia dùng — Kinh Thánh, chú giải, sách, và hơn nữa.
---

# Tài nguyên là gì?

Trong Theodia, một "tài nguyên" là bất kỳ tệp nào bổ sung tư liệu đọc hoặc học vào ứng dụng. Bản thân ứng dụng chỉ là một trình đọc và một cuốn sổ. Các Kinh Thánh, chú giải, sách, và tư liệu khác bạn dùng để học đều là những tệp riêng biệt mà bạn nạp vào.

Hướng dẫn này giải thích các loại tài nguyên khác nhau và mỗi loại dùng để làm gì.

## Tại sao điều này quan trọng?

Khi bạn lần đầu mở Theodia, nó đã có sẵn vài thứ để đọc. Trong khi khám phá, bạn sẽ thấy các nút để cài thêm. Biết mỗi loại tài nguyên là gì sẽ giúp bạn quyết định nên thêm gì.

## Các loại tài nguyên khác nhau

Theodia nhận diện tệp theo phần mở rộng của chúng. Mỗi phần mở rộng là một loại tài nguyên khác nhau.

### `.bible` — một bản dịch Kinh Thánh

Một bản dịch Kinh Thánh là một bản sao đầy đủ của Kinh Thánh theo một phiên bản cụ thể, chẳng hạn King James Version. Theodia đi kèm vài bản dịch và cho phép bạn thêm bản khác.

Xem hướng dẫn [Cài đặt bản dịch Kinh Thánh](theodia://help/installing-bibles) để biết chi tiết.

### `.commentary` — một sách chú giải

Một sách chú giải là một cuốn ghi chú học do một học giả Kinh Thánh viết. Với một câu cụ thể, chú giải cho bạn biết bối cảnh, ý nghĩa, và câu đó hòa vào phần còn lại của Kinh Thánh thế nào.

Xem hướng dẫn [Chú giải và từ điển](theodia://help/commentaries-and-lexicons) để biết chi tiết.

### `.lexicon` — một từ điển

Một từ điển (lexicon) là cuốn từ điển các từ trong Kinh Thánh. Nó cho bạn biết từ tiếng Do Thái hoặc Hy Lạp gốc, ý nghĩa của nó, và nó được dùng trong Kinh Thánh thế nào.

Xem hướng dẫn [Chú giải và từ điển](theodia://help/commentaries-and-lexicons) để biết chi tiết.

### `.book` — một cuốn sách Cơ Đốc

Một sách là một tác phẩm Cơ Đốc dài hơn, chẳng hạn một tác phẩm kinh điển từ lịch sử hội thánh. Đọc sách trong ứng dụng hoạt động gần như đọc Kinh Thánh. Theodia đi kèm một thư viện nhỏ các tác phẩm kinh điển Cơ Đốc có sẵn miễn phí.

Xem hướng dẫn [Đọc các sách có sẵn](theodia://help/reading-books) để biết chi tiết.

### `.devotional` — một tài liệu linh đạo

Một tài liệu linh đạo là một bài đọc hằng ngày ngắn. Mỗi mục thường có một câu, một đoạn suy niệm ngắn, và một lời cầu nguyện hoặc câu hỏi để suy gẫm. Nhiều tài liệu linh đạo được thiết kế để đọc mỗi ngày một mục trong suốt một năm.

Xem hướng dẫn [Tài liệu linh đạo hằng ngày](theodia://help/daily-devotionals) để biết chi tiết.

### `.sqlite` — một cơ sở dữ liệu tham chiếu

Một cơ sở dữ liệu tham chiếu là một tệp tra cứu lớn mà ứng dụng dùng để cho bạn thêm thông tin trong khi đọc. Có hai loại:

- **Câu liên hệ** — danh sách các câu kết nối với câu bạn đang đọc.
- **Hình thái học** — thông tin về các từ tiếng Do Thái hoặc Hy Lạp gốc trong câu.

Bạn không mở các tệp này trực tiếp. Chúng làm việc trong nền và bổ sung tính năng cho trình đọc Kinh Thánh. Xem hướng dẫn [Câu liên hệ](theodia://help/cross-references) để biết chi tiết.

### `.data` — dữ liệu từ

Một tệp dữ liệu từ chứa thông tin bổ sung về các từ gốc trong Kinh Thánh. Nó được từ điển và các công cụ học dùng đến. Giống như các cơ sở dữ liệu tham chiếu, bạn không mở nó trực tiếp. Ứng dụng dùng nó trong nền.

## Cách thêm một tài nguyên

Màn hình **Quản lý tài nguyên** của ứng dụng là cách dễ nhất để thêm một tài nguyên.

1. Mở **Cài đặt**.
2. Chạm **Quản lý tài nguyên**.
3. Chạm **Cài đặt từ GitHub**.
4. Trong cửa sổ tải xuống, chọn một thẻ — **Kinh Thánh**, **Chú giải**, **Sách**, **Tài liệu linh đạo**, hoặc **Cốt lõi** — rồi chọn điều bạn muốn và chạm **Cài đặt mục đã chọn**.
5. Hoặc chạm **Cài đặt tệp cục bộ** để nhập một tệp bạn đã tải sẵn.

Để xem hướng dẫn từng bước lấy tệp trực tiếp từ GitHub, xem hướng dẫn [Tải tài nguyên bổ sung từ GitHub](theodia://help/getting-core-files).

## Cách gỡ một tài nguyên

1. Mở **Cài đặt**.
2. Chạm **Quản lý tài nguyên**.
3. Tìm tài nguyên bạn muốn gỡ.
4. Chạm biểu tượng thùng rác bên cạnh nó.
5. Xác nhận bạn muốn gỡ.

Gỡ một tài nguyên không xóa ghi chú, phần đánh dấu, hay dấu trang của bạn. Những mục đó vẫn được giữ an toàn.

## Tài nguyên nằm ở đâu trên thiết bị của bạn

Tài nguyên được lưu trên thiết bị của bạn, không phải trên đám mây. Một khi tài nguyên đã được cài, bạn không cần internet để đọc nó. Bạn có thể sao lưu thiết bị, nhưng chính các tài nguyên không được Theodia sao lưu lên đám mây. Nếu bạn gỡ rồi cài lại ứng dụng, bạn sẽ cần thêm lại mọi tài nguyên đã từng cài.

## Trợ giúp và câu hỏi

Nếu bạn gặp khó khăn, xem hướng dẫn [Đặt câu hỏi ở đâu](theodia://help/getting-more-help). Đội ngũ và cộng đồng có thể giúp.
