---
title: API 密钥与费用
level: advanced
categories: ai
summary: 为什么需要 API 密钥、如何获取，以及使用远程 AI 模型通常需要多少费用。
---

# API 密钥与费用

> **模式：** AI 助手需要 **学者模式**。你可以在 **设置 → 应用用户模式** 中切换模式。

AI 助手连接远程 AI 模型。如果你想使用，就需要 API 密钥。本页解释原因、获取方式以及通常费用。

## 为什么需要 API 密钥

远程 AI 模型位于互联网上的服务器中。API 密钥就像密码，告诉服务器“此人被允许提问”。没有它，服务器不会回答。

应用不内置密钥。你必须在提供商处创建账户，并将密钥粘贴到应用中。

## 如何获取 API 密钥

1. 在 Theodia 中打开 **设置**。
2. 点击 **AI 助手**。
3. 选择 **远程模型**。
4. 从列表中选择一个提供商，或选择 **自定义** 并输入基础 URL。
5. 点击指向提供商密钥页面的链接。如果你还没有账户，请创建一个。
6. 在提供商网站上生成新的 API 密钥。
7. 复制密钥并粘贴到 Theodia。
8. 点击 **测试连接**，确保可用。

## 支持的提供商

Theodia 可连接任何使用 OpenAI 兼容 API 的提供商。以下是应用中有预设链接的：

- **GitHub Models** — github.com/marketplace/models（免费每日额度，推荐）
- **OpenAI** — platform.openai.com
- **OpenRouter** — openrouter.ai
- **Anthropic** — console.anthropic.com
- **Groq** — console.groq.com
- **Mistral** — console.mistral.ai
- **Together AI** — api.together.xyz

如果你运行自己的服务器或使用其他服务，也可以使用 **自定义** 基础 URL。

## 费用是多少

大多数提供商按 **token** 收费。token 大致相当于一个词或词的一部分。你为你发送的 token（你的问题）和 AI 返回的 token（回答）付费。

### 大致价格

价格会变动，以下是 2026 年中期的粗略参考：

- **小型快速模型**（如较便宜的 GPT-3.5 级别端点）每千 token 不到一美分。
- **中端模型**（如 GPT-4o 或 Claude Sonnet）通常每千 token 几美分。
- **大型推理模型**（如 GPT-4.5 或 Claude Opus）每千 token 可能达到十到二十美分。

Theodia 中一个典型的圣经问题可能总共使用几百到两千 token。这意味着大多数问题费用从**不到一美分到几美分**不等。

### 降低费用的技巧

- 从便宜模型开始。大多数圣经问题不需要最贵的模型。
- 如果想尝试不同模型并比较价格，可使用 Groq 或 OpenRouter。
- 在提供商网站上查看用量面板。

## GitHub Models

[GitHub Models](https://github.com/marketplace/models) 提供免费层级，无需订阅。你只需要一个免费 GitHub 账户和具有读取模型权限的个人访问令牌。

**设置步骤：**

1. 前往 [github.com/settings/tokens](https://github.com/settings/tokens)，创建 **Personal access token (classic)**。
2. 授予 `models:read` 范围（或直接选择模型权限）。
3. 在 Theodia 中选择 **GitHub Models** 作为提供商并粘贴令牌。

**免费层级模型：**

- `openai/gpt-4.1-nano` — **每分钟 15 次请求，每天 150 次**
- `openai/gpt-4.1-mini` — **每分钟 15 次请求，每天 150 次**
- `openai/gpt-4.1` — **每分钟 10 次请求，每天 50 次**
- `openai/gpt-4o` — **每分钟 10 次请求，每天 50 次**

这些限额每天重置，对日常圣经学习来说已足够。

完整图文步骤请参阅专门的 [GitHub Models](theodia://help/github-models) 指南。

## 隐私说明

使用远程 AI 模型时，应用会先显示同意提示，说明发送内容：你的消息、经文或章节上下文、工具调用及结果、配置的模型名称，以及请求头中的 API 密钥。请求直接发送到你配置的端点，不经过 Theodia。大多数提供商不会用你的数据训练模型，但文本确实会离开你的设备。你可以随时在 **设置 → AI 助手 → 远程 AI 数据共享** 中更改或撤销许可。

## 总结

- 使用 AI 助手需要 API 密钥。
- 在提供商处创建账户、生成密钥并粘贴到 Theodia。
- 大多数问题费用为几美分或更少。
