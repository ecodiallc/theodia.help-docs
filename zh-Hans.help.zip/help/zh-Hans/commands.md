---
title: 快速命令
level: everyday
categories: [layout, study]
summary: 命令输入让你通过输入简短指令跳转到任意功能。了解支持的格式和示例。
---

# 快速命令

**快速命令**输入让你通过输入简短指令跳转到 Theodia 的几乎任何部分。你可以在首页标签或从 **启动菜单**（标题栏中的 **▼** 图标）使用它。

## 如何工作

1. 点击命令框。
2. 输入命令。
3. 点击键盘上的前往键。

应用会读取命令并直接带你到正确的屏幕。

## 不需要斜杠前缀

命令**不要**使用 `/` 前缀。它们是纯文本输入：

```
john 3:16
search love
backup
```

如果你输入 `/settings`，前面的 `/` 会让它无法识别。

## 圣经引用

输入任意圣经引用，在阅读器中打开。

```
psalms 23
john 3:16
matthew 5:1
1 cor 15:10
```

书卷名称可以用全名或缩写匹配。在非英文界面语言中，你也可以用当前语言输入书卷名称。

## 搜索

```
search abraham
search love
search faith not works
```

## 书签、比较、注释、交叉引用与词语信息

```
bookmark john 3:16
compare genesis 1:1
commentary john 1
aicommentary eph 2:8
xref 1 cor 15:10
word info john 1:1
```

这些命令会为给定经文打开相应工具。

## 词典

输入斯特朗编号以打开词典条目。

```
g1161
h7225
```

## 灵修

```
devotional
devotional smith
devotional daily
```

不指定名称时，会打开灵修列表。

## 导航快捷方式

```
notes
highlights
bookmarks
flashcards
playlist
theoscript
resources
read john 3:16
```

这些会直接跳转到指定屏幕，或在阅读器中打开经文。

## 切换译本

输入译本缩写即可切换。

```
kjv
web
trlit
ohgb
```

在阅读器屏幕上，译本会原地切换。在其他地方，它会打开你最近经文所在的译本。

## 本地化命令动词

公开命令动词可以用当前界面语言**或**英语输入。英语始终作为后备。隐藏命令（设置快捷方式、安装命令、彩蛋）仅保留英语语法。

## 帮助

在命令框中输入 `help` 或 `commands`，可随时打开应用内命令参考。
