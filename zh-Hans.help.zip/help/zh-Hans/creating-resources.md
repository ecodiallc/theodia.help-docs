---
title: 创建你自己的资源
level: advanced
categories: resources
summary: 如何创建自定义圣经、注释、书籍、灵修和词典，并导入到 Theodia。
---

# 创建你自己的资源

Theodia 支持 Unique Bible App 格式的自定义资源。每种资源都是一个具有特定表结构的 SQLite 文件。你可以在电脑上创建这些文件，然后导入应用。

## 文件类型与必需表

### 圣经（`.bible`）

圣经文件是 SQLite 数据库，至少包含以下表之一：

- **`Verses`** — 列：`Book`（整数，1-66）、`Chapter`（整数）、`Verse`（整数）、`Scripture`（文本）
- **`Bible`** — 列：`Book`（整数）、`Chapter`（整数）、`Verse`（整数）、`Scripture`（文本）

你还可以包含 **`Details`** 表，用于元数据，如 `Description`、`Abbreviation`、`Version` 等列。

示例 SQL：

```sql
-- 主文本表
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- 可选元数据表
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### 注释（`.commentary`）

注释有三种类型：**逐书**、**逐章**、**逐节**。类型由**文件名的第一个字母**决定。

#### 逐书注释 — 文件名以 `b` 开头

逐书注释用单一条目覆盖整本圣经书卷。`Commentary` 表需要 `Book` 和 `Scripture`（或 `Content`）列。不需要 `Chapter` 或 `Verse` 列。

- **`Commentary`** — 列：`Book`（整数）、`Scripture`（文本）或 `Content`（文本）

示例 SQL：

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

文件名示例：`bMyCommentary.commentary`

#### 逐章注释 — 文件名以 `c` 开头

逐章注释覆盖圣经书卷的每一章。

- **`Commentary`** — 列：`Book`（整数）、`Chapter`（整数）、`Scripture`（文本）或 `Content`（文本）

示例 SQL：

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

文件名示例：`cMyCommentary.commentary`

#### 逐节注释 — 文件名以 `v` 开头

逐节注释覆盖每一节经文。`Commentary` 表需要 `Book`、`Chapter`、`Verse` 和 `Scripture`（或 `Content`）列。

- **`Commentary`** — 列：`Book`（整数）、`Chapter`（整数）、`Verse`（整数）、`Scripture`（文本）或 `Content`（文本）

示例 SQL：

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

文件名示例：`vMyCommentary.commentary`

### 书籍（`.book`）

书籍文件是带有 `Reference` 表的 SQLite 数据库。

- **`Reference`** — 列：`id`（整数）、`Chapter`（文本）、`Content`（文本）

每一行是一章。`Chapter` 列是章节标题。`Content` 列是章节正文，可包含 HTML（`<b>`、`<i>`、`<br>` 等）。

示例 SQL：

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

你也可以从 Markdown 文件创建书籍。应用可以导入 `.md` 文件，其中 `#` 是书名，`##` 标记章节。Markdown 会自动转换为 HTML。

### 灵修（`.devotional`）

灵修文件是带有 `devotional` 表的 SQLite 数据库。

- **`devotional`** — 列：`month`（整数，1-12）、`day`（整数，1-31）、`devotion`（文本）

每一行是一天的阅读。应用按今天的月份和日期查找条目。

示例 SQL：

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### 词典（`.lexicon`）

词典文件是带有 `Lexicon` 表的 SQLite 数据库。

- **`Lexicon`** — 列：`Topic`（文本，斯特朗编号）、`Definition`（文本，词典条目）

`Topic` 列存放斯特朗编号（例如 `G1161` 或 `H7225`）。`Definition` 列存放完整条目文本，可包含 HTML。

示例 SQL：

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

词典驱动词语信息工具。点击行间对照圣经中的词时，应用会在已安装词典中查找斯特朗编号。

## 在电脑上创建文件

1. 安装 SQLite 编辑器（DB Browser for SQLite、SQLiteStudio 或 `sqlite3` 命令行工具）。
2. 创建新数据库文件。
3. 创建所需表并插入数据。
4. 用正确的扩展名保存文件（`.bible`、`.commentary`、`.book`、`.devotional` 或 `.lexicon`）。

## 导入到 Theodia

1. 将文件传输到设备（AirDrop、邮件、云存储或 USB）。
2. 打开 **Theodia**。
3. 前往 **设置 → 管理资源**。
4. 点击 **从文件导入**。
5. 选择你的文件。

应用会验证文件（检查所需表），复制到应用数据文件夹，并自动启用。如果文件无效，你会看到错误说明。

## 限制

- 你不能覆盖内置资源。如果导入的文件与内置圣经、注释或书籍同名，导入会失败。
- 圣经文件需要 `Verses` 或 `Bible` 表。如果两者都没有，导入失败。
- 注释文件需要 `Commentary` 表。
  - 逐书注释需要 `Book` 和 `Scripture`（或 `Content`）列。
  - 逐章注释需要 `Book`、`Chapter` 和 `Scripture`（或 `Content`）列。
  - 逐节注释需要 `Book`、`Chapter`、`Verse` 和 `Scripture`（或 `Content`）列。
- 书籍文件需要 `Reference` 表。
- 词典文件需要 `Lexicon` 表。
- 灵修文件需要 `devotional` 表。

## 提示

- 文件大小要合理。过大的 SQLite 文件可能在旧设备上导致内存问题。
- 先在电脑上测试。用 SQLite 浏览器打开，运行 `SELECT * FROM` 所需表，确认数据正确。
- 圣经的 `Book` 列必须使用数字（1 = 创世记，66 = 启示录）。
- 注释可以使用 `Scripture` 或 `Content` 作为注释文本列。
- 书籍的 `Content` 列中的 HTML 会在阅读时渲染。保持简单：`<b>`、`<i>`、`<br>`、`<hr>` 是安全的。

## 哪里找现有资源

Theodia 可以读取 [Unique Bible App](https://github.com/eliranwong/UniqueBible) 项目的资源。那里有许多正确 SQLite 格式的圣经、注释、书籍等。如何查找和添加请参阅 [获取额外资源](theodia://help/getting-core-files) 指南。
