---
title: 常见问题
level: everyday
categories: faq
summary: 关于使用 Theodia 最常见问题的回答。
---

# 常见问题

## Theodia 收费吗？

Theodia 是一次性购买。没有订阅、没有广告、没有应用内购买，也不会请求捐款。购买应用后，目录中的所有额外资源都可以免费下载。

## 需要联网吗？

不需要。应用及其数据文件安装后，所有功能都可以离线使用。你可以阅读、搜索、高亮、做笔记，以及使用大多数学习工具，无需信号。

唯一需要联网的功能是下载新资源。

## 我的数据存在哪里？

你的所有书签、高亮、笔记和设置都保存在设备上。它们不会上传到任何服务器。

你可以手动备份。方法请参阅 [备份你的数据](theodia://help/backups) 指南。

## 我可以听圣经朗读吗？

可以。打开任意章节，点击菜单，选择朗读选项。你的设备必须已安装文本转语音语音。更多内容请参阅 [朗读](theodia://help/tts) 指南。

## 如何搜索经文？

你可以在首页命令框中输入 `John 3:16` 等引用，或使用 **搜索** 标签按词或短语搜索。

## 如何报告 bug 或建议功能？

点击关于屏幕上的 **提交建议/问题**，或 [在 GitHub 上报告](https://github.com/ecodiallc/theodia.app/issues/new)，或访问 [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions) 页面。

## 支持哪些设备？

Theodia 运行在 iPhone、iPad 和 Android 手机与平板上。设备最好至少有 2 GB 可用存储空间用于核心数据文件。

## 可以使用外接键盘吗？

可以。Theodia 支持 iPad 上的蓝牙和 USB 键盘。导航、搜索和许多阅读功能都有键盘快捷键。完整列表请参阅 [外接键盘快捷键](theodia://help/external-keyboard-shortcuts) 指南。

## 支持哪些语言？

应用界面提供英语、阿拉伯语、中文（简体与繁体）、捷克语、丹麦语、荷兰语、菲律宾语、法语、德语、希腊语、希伯来语、印地语、印尼语、意大利语、日语、韩语、波兰语、葡萄牙语（巴西）、罗马尼亚语、俄语、西班牙语、瑞典语、泰语、土耳其语、乌克兰语和越南语。

圣经文本语言取决于你安装了哪些译本。

## 如何更改语言？

前往 **设置**，找到语言选项。

## 这里没回答我的问题。在哪里可以获得更多帮助？

按主题浏览其余帮助指南，或在 [GitHub Discussions](https://github.com/ecodiallc/theodia.app/discussions) 社区提问。

提示：在 **帮助与指南** 主屏幕上，使用搜索框输入 `notifications` 或 `search` 等词来找到对应指南。
