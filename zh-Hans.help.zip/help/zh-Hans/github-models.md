---
title: GitHub Models
level: advanced
categories: ai
summary: 设置 GitHub Models——无需现有 API 订阅即可免费开始探索 Theodia AI 的方式。
---

# GitHub Models

> **模式：** AI 助手需要 **学者模式**。你可以在 **设置 → 应用用户模式** 中切换模式。

如果你还没有为 AI 服务付费，**GitHub Models** 是开始探索 Theodia AI 最简单的方式。它提供免费起点，你只需要一个免费 GitHub 账户。

## 什么是 GitHub Models？

GitHub Models 是 GitHub 提供的一项服务，让你可以通过 API 运行现代 AI 模型。它支持与 OpenAI 相同的格式，因此能与 Theodia 无缝配合。

## 为什么选择 GitHub Models？

- **无需信用卡** — 只需 GitHub 账户。
- **高质量模型** — 你可以访问支持 Theodia 工具的 GPT-4o、GPT-4.1 等可靠模型。
- **设置简单** — 一个令牌、一个 URL，即可完成。

## 第一步：创建 GitHub 账户

如果你已有 GitHub 账户，跳到第二步。

1. 前往 [github.com](https://github.com)。
2. 点击 **注册**，按提示创建免费账户。
3. GitHub 发送确认邮件时，验证你的邮箱地址。

## 第二步：创建个人访问令牌

这个令牌就是你的 API 密钥。当 Theodia 发送问题时，它告诉 GitHub 你的身份。

1. 前往 [github.com/settings/tokens](https://github.com/settings/tokens)。
2. 点击 **生成新令牌**，选择 **生成新令牌（经典）**。
3. 给令牌起个名字，例如 **Theodia AI**。
4. 在 **选择范围** 下，勾选 **`models:read`**。
   - 这是 Theodia 唯一需要的权限。
5. 滚动到底部，点击 **生成令牌**。
6. **立即复制令牌。** GitHub 只显示一次。把它粘贴到安全的地方（例如手机的备忘录应用），直到你添加到 Theodia。

## 第三步：选择模型

GitHub Models 提供多个模型。对于 Theodia，以下选项最佳：

| 模型 | 每日免费额度 | 最适合 |
| --------------------- | ------------------ | --------------------------------------------- |
| `openai/gpt-4.1-nano` | 每天 150 次请求 | 快速问题和简单经文解释 |
| `openai/gpt-4.1-mini` | 每天 150 次请求 | 工具支持良好的通用学习 |
| `openai/gpt-4.1` | 每天 50 次请求 | 深入学习和复杂多步骤问题 |
| `openai/gpt-4o` | 每天 50 次请求 | 多才多艺，工具支持出色 |

建议从 **`openai/gpt-4.1-mini`** 开始——它快速、可靠，并且每日请求额度更高。

## 第四步：配置 Theodia

1. 打开 **Theodia**。
2. 前往 **设置 → AI 助手**。
3. 确保选择的是 **远程模型**。
4. 点击 **提供商** 下拉框，选择 **GitHub Models**。
   - 如果列表中没有 GitHub Models，选择 **自定义** 并手动输入基础 URL：`https://models.github.ai`
5. 把你的 GitHub 个人访问令牌粘贴到 **API 密钥** 字段。
6. 在 **模型** 字段中输入所选模型 ID（例如：`openai/gpt-4.1-mini`）。
7. 点击 **测试连接**。
8. 等待检查完成。你应该看到：
   - **✓ 连接成功**
   - **✓ 支持工具**

如果看到 **✗ 不支持工具**，请尝试上表中的其他模型 ID。

## 第五步：开始聊天

1. 点击屏幕底部的 **AI** 标签。
2. 输入问题并点击 **发送**。
3. 或者在阅读任何圣经章节时，点击经文号并选择 **AI 注释**，开始针对该经文的聊天。

## 故障排除

### “连接失败”或“HTTP 401”

- 确保你复制了令牌的**完整**内容。它是一个以 `ghp_` 开头的长字符串。
- 令牌如果长期未使用可能会过期。返回 GitHub 生成一个新令牌。
- 创建令牌时确保选择了 **models:read**。

### “不支持工具”

- GitHub Models 上的某些模型不接受工具调用。请改用 **`openai/gpt-4o`** 或 **`openai/gpt-4.1-mini`**。
- 确保模型 ID 拼写与所示完全一致，包括 `openai/` 前缀。

### 速率限制错误

- 如果你达到每日上限，切换到每日额度更高的模型（例如 `openai/gpt-4.1-nano`，每天 150 次请求）。
- 限额每 24 小时重置。

## 总结

- GitHub Models 是在 Theodia 中**开始探索 AI 的推荐方式**。
- 你需要一个**免费 GitHub 账户**和具有 `models:read` 权限的**个人访问令牌**。
- 最佳入门模型是 **`openai/gpt-4.1-mini`**。
- 在 **设置 → AI 助手** 中输入令牌和模型，点击 **测试连接**，然后开始聊天。
