---
title: 开发插件
categories: plugins
level: advanced
summary: Theodia 插件包包含什么，以及如何编写插件清单。
---

# 开发插件

Theodia 插件是一个自包含的包，可为应用添加 UI 界面、内容或事件处理。插件在主应用之外编写，用户通过 **设置 → 插件** 安装。

## 插件包结构

插件包是一个扩展名为 `.plugin.zip` 的 ZIP 压缩文件。内部文件位于顶层——不在嵌套文件夹中。

典型包结构：

```
my-plugin.plugin.zip
├── plugin.json       （必需）
├── data.sqlite       （可选，用于内容/UI 插件）
├── template.html     （可选）
├── style.css         （可选）
└── logo.png          （可选）
```

必需文件：

- `plugin.json` — 插件清单（见下文）。

可选文件：

- 用于存储内容或 UI 数据的 SQLite 数据库。
- HTML、Markdown、图片或 JSON 资源，由清单引用。

`plugin.json` 中的所有资源引用必须使用精确的扁平文件名，不带路径。例如使用 `template.html`，而不是 `templates/template.html`。

## 清单基础

最小化的 `plugin.json` 如下：

```json
{
  "id": "org.example.myplugin",
  "name": "Example Plugin",
  "version": "0.1.0",
  "type": "ui",
  "description": "A short description of what the plugin does.",
  "extensions": [
    {
      "surface": "bible-verse-menu",
      "config": {
        "label": "Example",
        "icon": "🔌",
        "screenType": "template",
        "templateFile": "template.html"
      }
    }
  ]
}
```

### 常用清单字段

| 字段 | 是否必需 | 说明 |
| --------------- | --------------------------------- | -------------------------------------------------------------------- |
| `id` | 是 | 反向域名风格标识符，例如 `org.example.myplugin`。 |
| `name` | 是 | 向用户显示的名称。 |
| `version` | 是 | 插件的语义化版本。 |
| `type` | 是 | `ui`、`content` 或 `composite`。 |
| `description` | 否 | 插件作用的简短摘要。 |
| `minAppVersion` | 否 | 所需的最低 Theodia 应用版本。 |
| `apiVersion` | 否 | 目标插件 API 版本。 |
| `extensions` | `ui` 和 `composite` 必需 | 界面声明数组（见下文）。 |

### 界面

每个 `extensions` 条目声明插件出现的位置和行为：

```json
{
  "surface": "home-screen",
  "config": {
    "title": "My Plugin",
    "icon": "📝",
    "screenType": "list",
    "dbTable": "Articles",
    "titleColumn": "Title"
  }
}
```

支持的界面：

- `bottom-toolbar` — 底部插件标签中的条目。
- `home-screen` — 主屏幕上的卡片。
- `hamburger-menu` — 主菜单中的项目。
- `bible-verse-menu` — 圣经阅读器中的长按经文操作。
- `bible-chapter-toolbar` — 圣经阅读器中的章节工具栏操作。
- `book-chapter-toolbar` — 书籍阅读器中的工具栏操作。
- `ai-verse-action` — 经文上的 AI 操作（需要启用 AI）。
- `ai-chapter-action` — 章节上的 AI 操作（需要启用 AI）。
- `event` — 应用生命周期事件处理程序。

### 屏幕类型

界面配置中的 `screenType` 告诉应用如何渲染插件屏幕：

- `list` — 可滚动的数据库行列表。
- `data-list` — 可增删改的列表。
- `detail` — 单行或经文内容。
- `markdown` — 静态 Markdown 文件渲染为 HTML。
- `html` — 使用 `react-native-render-html` 渲染的静态 HTML 文件。
- `template` — 使用 `{{key}}` 占位符替换的 HTML 文件。
- `flashcard` — 使用两列数据库内容的翻卡 UI。

## 分发

打包为 `.plugin.zip` 文件后，插件可以：

- 由用户直接从文件导入。
- 从目录仓库提供。

## 提示

- 保持 `plugin.json` 为有效 JSON。应用会在安装时拒绝无效清单。
- 所有引用资源使用精确文件名。
- 插件 ID 应采用反向域名风格，以避免冲突。
- 离线测试插件内容，因为用户可能没有网络连接。
