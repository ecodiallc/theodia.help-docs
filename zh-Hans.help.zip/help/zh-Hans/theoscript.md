---
title: Theoscript
level: everyday
categories: theoscript
summary: 使用简单的 Theoscript 命令自动化读经、朗读、书签等操作。
---

# Theoscript

**Theoscript** 是可以在 Theodia 内部自动化操作的小脚本。脚本可以朗读经文、打开章节、设置书签、显示消息、运行其他命令等。它们是构建个人快捷方式或小型灵修助手的快捷方式，无需离开应用。

## Theoscript 在哪里

从主屏幕或主菜单打开 **Theoscript**。只有至少存在一个 Theoscript 时，该屏幕才会显示。

库中显示：

- **脚本** — 你创建或导入的每个脚本。
- **分类** — 用于分组相关脚本的可选文件夹。

点击脚本即可运行。长按脚本可编辑、复制或删除。

## 创建新脚本

1. 前往 **Theoscript**。
2. 点击 **+ 添加脚本**。
3. 给脚本命名。
4. 在 **脚本内容** 字段中输入命令。
5. 点击 **保存**。

每条命令占一行。块内的行缩进两个空格。

## 常用命令

| 命令 | 作用 | 示例 |
| ---------------------- | -------------------------------------- | --------------------------------------------- |
| `speak` | 朗读文本或经文 | `speak "Good morning"` 或 `speak John 3:16` |
| `open`、`read`、`show` | 在阅读器中打开经文 | `open Psalm 23` |
| `bookmark` | 将当前经文保存到书签 | `bookmark` |
| `highlight` | 高亮当前经文 | `highlight yellow` |
| `message` | 显示弹出消息 | `message "Done reading"` |
| `set` | 更改设置或值 | `set theme dark` |
| `return` | 提前停止脚本 | `return` |
| `with playlist` | 向播放列表添加曲目 | `with playlist "Morning" track John 3:16 end` |
| `start playlist` | 播放播放列表 | `start playlist "Morning"` |
| `with note` | 创建笔记 | `with note "John 3:16" "My thoughts" end` |

## 流程控制

使用 `if` 仅在条件为真时运行命令：

```text
if chapter == 1 {
  message "Starting a new book!"
}
```

使用 `repeat` 重复执行命令块：

```text
repeat 3 {
  speak "Peace be with you"
}
```

使用 `for` 循环遍历列表：

```text
for $ref in ["John 3:16", "Psalm 23:1", "Romans 8:28"] {
  open $ref
  speak $ref
}
```

使用 `function` 和 `call` 复用代码块：

```text
function greet $name {
  message "Hello, " + $name
}
call greet "friend"
```

## 变量

使用 `let` 将值存入变量：

```text
let $name = "Theophilus"
message "Welcome, " + $name
```

右侧的字面字符串必须用单引号或双引号包裹。这样可以避免把字面值与命令或变量名混淆。数字、变量和命令表达式不需要引号：

```text
let $count = 42
let $text = $last.passageText
let $words = count words in $text
let $greeting = "Hello, " + $name
```

变量在循环、函数和播放列表定义中很有用。

## 示例脚本

### 问候与一节经文

```text
speak "Good morning. Here is your verse for today."
open John 3:16
speak John 3:16
```

### 收藏三处 favorite 经文

```text
open John 3:16
bookmark
open Psalm 23:1
bookmark
open Romans 8:28
bookmark
message "Favorites saved."
```

### 构建朗读播放列表

```text
with playlist "Commute" {
  track John 3:16
  track Psalm 23
  track Romans 8:28
}
start playlist "Commute"
```

### 条件消息

```text
open Genesis 1:1
if book == "Genesis" {
  message "In the beginning..."
}
```

## 整理脚本

点击 **管理分类** 创建分类。编辑脚本时，选择你想把它放入的分类。分类有助于把个人脚本、示例脚本和朗读脚本分开。

## 导出与导入

点击 Theoscript 库中的菜单可：

- **导出 Theoscript** — 将所有脚本保存到文件。
- **导出此分类** — 仅保存所选分类。
- **导入 Theoscript** — 加载之前导出的文件。

导出文件是纯文本，可以分享给其他 Theodia 用户。

## 从命令运行脚本

Theoscript 也可以按名称从 **启动菜单** 运行，或通过命令请求。例如，说或输入 `run My Morning Script` 会查找并运行名为 _My Morning Script_ 的脚本（如果存在）。

## 故障排除

- **点击运行后没反应。** 检查脚本内容是否为空，以及每条命令拼写是否正确。
- **朗读不读任何内容。** 确保已打开经文，或直接把带引号的文本传给 `speak`。
- **某条命令高亮显示错误。** Theoscript 会在命令未知或引用无效时显示错误。编辑脚本后重试。
