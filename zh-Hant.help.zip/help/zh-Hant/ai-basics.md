---
title: AI 基礎
level: advanced
categories: ai
summary: 如何使用 AI 助手來理解經文。
---

# AI 基礎

> **模式：** AI 助手需要 **學者模式**。您可以在 **設定** → **應用程式使用者模式** 中切換模式。

Theodia 內建 AI 助手。它可以幫助您理解經文、回答問題，或探討聖經主題。

## 如何開啟 AI

AI 預設為關閉。若要開啟：

1. 開啟 **設定**。
2. 點選 **AI 助手**。
3. 點選開關將它開啟。

## 如何開啟 AI 畫面

點選螢幕底部的 **AI** 頁籤。聊天視窗隨即開啟。

## 如何提問

點選底部的輸入框，輸入您的問題，然後點選 **傳送**。

您可以問的問題例如：

- "What does John 3:16 mean?"
- "Tell me about the book of Romans."
- "What is the fruit of the Spirit?"
- "Compare the Sermon on the Mount in Matthew and Luke."

## 如何詢問特定經文

1. 開啟一章聖經。
2. 點選一節經文，開啟經文選單。
3. 點選 **AI 註釋**。

該節經文會傳送給 AI。AI 面板會自動填入該節經文並開啟。您可以追加問題，例如 "What does this mean?" 或 "How should I apply this?"

## 重要須知

- AI 是工具，不是真人。它可能會出錯。
- 請務必將 AI 的回答與聖經本身對照查驗。
- AI 可能需要網際網路，離線時無法運作。
- 當您使用 AI 時，您的問題、經文上下文與 API 金鑰會傳送到您選擇的端點。首次使用時，應用程式會徵詢您的同意，並清楚顯示會傳送哪些內容。您可以稍後在 **設定 → AI 助手 → 遠端 AI 資料分享** 中變更或撤銷此權限。
- 部分地區（例如中國大陸 App Store 版本）不提供 AI 助手，該版本僅提供離線聖經功能。

## 如何管理對話

AI 畫面會保留過去的對話列表。您可以從列表中開啟舊對話、開始新對話，或刪除不需要的對話。

## 深入使用 AI

本頁只涵蓋基礎操作。Theodia 的 AI 能做的遠不止聊天。以下是進階指南：

- **[AI 功能](theodia://help/ai-features)** — 探索 Theophilus 的所有能力：一鍵希臘文／希伯來文經文研究、交叉引用鏈、講道大綱、禱文生成、原文型態學、詞典查詢，以及免持操作應用程式。這份指南會教您如何把 AI 從聊天機器人變成完整的研究夥伴。
- **[寫出更好的 AI 提示](theodia://help/ai-prompts)** — 學習如何提問才能獲得豐富且準確的回答。只要稍微調整措詞，就能大幅改善 AI 的回應深度。
- **[選擇 AI 模型](theodia://help/choosing-a-model)** — 並非所有 AI 模型都一樣。了解哪些模型支援 Theodia 內建工具（例如開啟經文、搜尋聖經），以及哪些模型能讓 AI 成為真正的免持聖經研究助手。
- **[GitHub Models](theodia://help/github-models)** — Theodia 推薦的免費供應商。使用免費 GitHub 帳號即可取得 API 金鑰，每天有慷慨的免費額度。無需信用卡、無需訂閱。
- **[API 金鑰與費用](theodia://help/ai-keys-and-costs)** — 了解不同供應商的 API 計價方式，以及如何讓費用接近零。
