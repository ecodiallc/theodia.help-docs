---
title: AI 功能
categories: ai
level: advanced
summary: 探索 Theodia AI 的一切能力——從逐節研究、講道預備、原文探索到免持導航。
---

# AI 功能

> **模式：** AI 助手需要 **學者模式**。您可以在 **設定** → **應用程式使用者模式** 中切換模式。

Theodia 的 AI 助手 Theophilus 不只是一個聊天機器人。它是能與您一起讀經的研究夥伴，可以查閱註釋、搜尋聖經、管理筆記，甚至透過語音或文字導航應用程式。

在 Theophilus 首次將資料傳送到 AI 端點之前，應用程式會顯示同意提示，說明會傳送哪些內容並請求您的許可。您可以隨時在 **設定 → AI 助手 → 遠端 AI 資料分享** 中變更或撤銷該許可。

## AI 經文聊天：深入查考一節經文

**AI 經文聊天** 是 Theodia AI 體驗的核心。在閱讀任何一章時，點選經文編號（或長按經文文字）並選擇 **AI 註釋**。聊天面板會隨即開啟，並已載入該節經文。AI 清楚知道您正在讀什麼，並準備好和您一起探索。

### 一鍵啟動建議

不知道問什麼？面板會顯示八個快速啟動選項：

- **解釋這節經文** — 獲得清楚、深思熟慮的意義與重要性分析。
- **原文** — 查看英文背後的希臘文或希伯來文單字、音譯與詞彙定義。
- **歷史文化背景** — 了解該節經文周圍的文化、政治與事件。
- **文本上下文** — 了解這節經文如何融入所在段落、章節與書卷。
- **主要主題** — 發掘這節經文對聖經神學的貢獻。
- **如何應用這節經文** — 獲得今天可以實際行動的個人應用。
- **生成禱文** — 根據這節經文的語言與真理，轉化為禱告。
- **生成講道大綱** — 獲得包含引言與結論的三點式大綱，可直接講道。

點選任何一個啟動選項，AI 就會立即開始。您可以接著追問、請求澄清，或帶領對話朝新方向發展。

### 像真實對話一樣追問

AI 會記住聊天中的最近幾則訊息，因此您可以自然地深入挖掘：

- "Can you say that more simply?"
- "What does the original Greek say here?"
- "Show me cross-references that connect to this."
- "Compare this verse in three different translations."
- "What would this look like in a modern workplace?"
- "Give me three more applications for a parent."

對話會緊貼該節經文，因此每個回答都扎根於您正在閱讀的經文。

### 點選任何聖經引用

當 AI 提到另一節經文時，例如 "This mirrors Romans 8:28"，該引用會顯示為 **可點選的連結**。點選它，應用程式就會跳到聖經閱讀器的該段經文。您無需離開對話即可探索引用鏈。

## AI 除了經文聊天還能做什麼

Theophilus 可以存取 Theodia 中的所有內容——聖經、註釋、詞典、字典、書籍、靈修、您的筆記、書籤與高亮。以下是實際應用。

### 閱讀與導航經文

- **朗讀任何經文或章節** — "Read John 3:16 in the WEB" 或 "Read Psalm 23 aloud."
- **在閱讀器中開啟經文** — "Take me to Genesis 1" 或 "Open Romans 8:28."
- **比較版本** — "Show me John 3:16 in all my Bibles."
- **搜尋聖經** — "Find verses about forgiveness" 或 "Search for 'peace that passes understanding.'"
- **取得交叉引用** — "What other verses relate to Isaiah 53:5?"
- **查看章節標題** — "What are the subheadings in Matthew 5?"

### 探索原文

- **詞典查詢** — "What does the Greek word 'agape' mean in John 3:16?" 或 "Look up Strong's G26."
- **型態學** — "Parse the Greek verbs in Romans 8:28" 或 "What does morphology code V-PAI-3S mean?"
- **詞語資訊** — AI 可以看到您在應用程式中看到的逐字分解：音譯、簡要釋義、文法與 Strong's 編號。

### 閱讀註釋與研經書籍

- **逐節註釋** — "What does Matthew Henry say about Ephesians 2:8?"
- **章節註釋** — "Give me the chapter overview for Romans 8."
- **書卷註釋** — "Summarize the book-level commentary on Revelation."
- **研經書籍** — "Read me a chapter from Hymn Lyrics English" 或 "Search my books for 'patience.'"
- **靈修** — "Read today's devotional" 或 "Find a devotional about anxiety."

### 搜尋字典

- "Who was Melchizedek?"
- "What does the Bible dictionary say about Gilgal?"
- "Look up 'propitiation' in Easton's."

### 管理您的研經生活

AI 可以操作您的個人資料——所有資料都儲存在您裝置的本機端：

- **書籤** — "Bookmark this verse in my Sermon Prep folder" 或 "List my bookmarks."
- **高亮** — "Highlight John 3:16 in yellow" 或 "Show me all my highlights."
- **筆記** — "Create a Bible note on this verse" 或 "Read my notes for Genesis 1."
- **學習筆記** — "Save this conversation as a study note" 或 "Create a new study notebook called Romans Study."
- **資料夾** — "Create a folder called Morning Devotion" 或 "Move my John 3:16 bookmark to the Prayer folder."

### 變更應用程式設定

- "Switch to dark mode."
- "Make the BSB my default Bible."
- "Turn on parallel Bibles with the NET."
- "Increase the font size."

### 朗讀出聲

- "Read Psalm 23 aloud" — AI 可以為任何經文、書籍或筆記觸發文字轉語音朗讀。
- "Stop reading" — 隨時暫停朗讀。

## 儲存對話

每次 AI 經文聊天都可以儲存。點選聊天面板中的選單，選擇：

- **儲存為聖經筆記** — 將整段對話附加到聖經閱讀器的經文筆記中。
- **儲存為學習筆記** — 將對話儲存在您的學習筆記書中，以便日後查閱。

這能把一次快速的 AI 探索轉化為永久的研經材料，您可以回顧、編輯或以此建構講章。

## 完整的 AI 頁籤

除了經文聊天面板之外，Theodia 在底部導航中還有專屬的 **AI** 頁籤。這是自由對話區，沒有預選經文。適合用於：

- 跨整本聖經的主題研究
- 講章研究與大綱撰寫
- 比較不同書卷間的神學主題
- 每日靈修與禱告提示
- 聖經問答與讀經計畫
- 應用程式協助 — "How do parallel Bibles work?"

您的對話會自動儲存。您可以返回過去的聊天、開始新對話，或刪除舊對話。

## 入門點子

以下是一些令人興奮的使用方式。選一個今天就試試看。

**個人成長**

- "Explain Philippians 4:6–7 and give me a prayer for when I feel anxious."
- "What does the Bible say about rest? Find me five verses and explain each."

**家庭與教養**

- "How should Ephesians 6:4 guide modern parenting? Give me three practical rules."
- "Find verses about raising children and read them aloud to me."

**講道與教學預備**

- "Outline a 25-minute sermon on Romans 8:28 with an introduction, three points, and a conclusion."
- "What do my commentaries say about the 'armor of God' in Ephesians 6?"
- "Compare the Sermon on the Mount in Matthew with Luke's version. What are the differences?"

**原文研究**

- "Show me the morphology for every word in John 1:1."
- "What is the difference between 'agape' and 'philia' in the New Testament?"

**靈修深度**

- "Read today's devotional and connect it to a verse in Psalms."
- "Give me a seven-day devotional outline on the fruit of the Spirit."

**交叉引用鏈**

- "Start with Isaiah 53:5 and trace the 'wounds' and 'healing' theme through the New Testament."
- "Where does the concept of 'covenant' appear from Genesis to Hebrews?"

**記憶與複習**

- "Quiz me on the books of the Bible in order."
- "Create a study note summarizing the main point of every chapter in Romans."

## 幾點重要提醒

- AI 是 **工具**，不能取代聖經或牧者指導。請務必將其回答與聖經對照。
- 使用 AI 時，您的問題會透過網際網路傳送到供應商伺服器。大多數供應商不會用您的資料訓練模型，但文字確實會離開您的裝置。
- AI 可能出錯。請以註釋、詞典與聖經經文本身作為最終權威。

## 總結

Theodia 的 AI 設計目的是讓聖經研究更快、更深入、更個人化。無論您需要一句話解釋難懂的經文、完整的講道大綱、希臘文單字研究，還是跨越整本聖經的交叉引用鏈，Theophilus 都準備好協助您。點選一節經文，提出問題，看看對話會帶您到哪裡。
