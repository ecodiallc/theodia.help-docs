---
title: API 金鑰與費用
level: advanced
categories: ai
summary: 為什麼需要 API 金鑰、如何取得，以及使用遠端 AI 模型通常需要多少費用。
---

# API 金鑰與費用

> **模式：** AI 助手需要 **學者模式**。您可以在 **設定** → **應用程式使用者模式** 中切換模式。

AI 助手會連線到遠端 AI 模型。若要使用，您需要 API 金鑰。本頁說明為什麼需要、如何取得，以及通常的費用。

## 為什麼需要 API 金鑰

遠端 AI 模型位於網際網路上的伺服器。API 金鑰就像密碼，告訴伺服器「這位使用者有權提問」。沒有金鑰，伺服器不會回應。

應用程式不提供內建金鑰。您必須向供應商建立帳號，然後將金鑰貼到應用程式中。

## 如何取得 API 金鑰

1. 在 Theodia 中開啟 **設定**。
2. 點選 **AI 助手**。
3. 選擇 **遠端模型**。
4. 從列表中選擇供應商，或選擇 **自訂** 並輸入基礎網址。
5. 點選連到供應商金鑰頁面的連結。若尚未有帳號，請建立帳號。
6. 在供應商網站上產生新的 API 金鑰。
7. 複製金鑰並貼到 Theodia。
8. 點選 **測試連線** 確認是否可用。

## 支援的供應商

Theodia 可以連接任何使用 OpenAI 相容 API 的供應商。以下是應用程式內有預設連結的供應商：

- **GitHub Models** — github.com/marketplace/models（免費每日額度，推薦）
- **OpenAI** — platform.openai.com
- **OpenRouter** — openrouter.ai
- **Anthropic** — console.anthropic.com
- **Groq** — console.groq.com
- **Mistral** — console.mistral.ai
- **Together AI** — api.together.xyz

如果您使用自己的伺服器或其他服務，也可以使用 **自訂** 基礎網址。

## 費用是多少？

大多數供應商按 **token** 計費。token 大約等於一個字或字的一部分。您需為送出的 token（您的問題）與 AI 回傳的 token（回答）付費。

### 大致價格

價格會變動，以下是 2026 年中期的粗略參考：

- **小型快速模型**（如較便宜的 GPT-3.5 等級端點）每千個 token 不到一美分。
- **中階模型**（如 GPT-4o 或 Claude Sonnet）每千個 token 通常幾美分。
- **大型推理模型**（如 GPT-4.5 或 Claude Opus）每千個 token 可能十到二十美分。

在 Theodia 中，一個典型的聖經問題總共可能使用數百到兩千個 token。也就是說，大多數問題的費用從 **不到一美分到幾美分** 不等。

### 降低費用的訣竅

- 從較便宜的模型開始。大多數聖經問題不需要最貴的模型。
- 若想試用不同模型並比較價格，可使用 Groq 或 OpenRouter。
- 在供應商網站的使用量面板中留意用量。

## GitHub Models

[GitHub Models](https://github.com/marketplace/models) 提供免費層級，無需訂閱。只需要免費 GitHub 帳號，以及一組具有讀取模型權限的個人存取權杖。

**設定方式：**

1. 前往 [github.com/settings/tokens](https://github.com/settings/tokens) 建立 **Personal access token (classic)**。
2. 賦予 `models:read` 範圍（或直接選取 models 權限）。
3. 在 Theodia 中選擇 **GitHub Models** 作為供應商，並貼上您的權杖。

**免費層級模型：**

- `openai/gpt-4.1-nano` — **每分鐘 15 次請求，每天 150 次請求**
- `openai/gpt-4.1-mini` — **每分鐘 15 次請求，每天 150 次請求**
- `openai/gpt-4.1` — **每分鐘 10 次請求，每天 50 次請求**
- `openai/gpt-4o` — **每分鐘 10 次請求，每天 50 次請求**

這些限制每日重置，對日常聖經研究來說相當充裕。

完整的圖文逐步教學，請參閱 [GitHub Models](theodia://help/github-models) 專屬指南。

## 隱私聲明

當您使用遠端 AI 模型時，應用程式會先顯示同意提示，說明會傳送哪些內容：您的訊息、經文或章節上下文、工具呼叫與結果、設定的模型名稱，以及請求標頭中的 API 金鑰。請求會直接傳送到您設定的端點，不會經過 Theodia。大多數供應商不會用您的資料訓練模型，但文字確實會離開您的裝置。您可以隨時在 **設定 → AI 助手 → 遠端 AI 資料分享** 中變更或撤銷權限。

## 總結

- 使用 AI 助手需要 API 金鑰。
- 向供應商建立帳號、產生金鑰，並貼到 Theodia。
- 大多數問題只需幾美分或更低。
