---
title: AI 助手
level: advanced
category: ai
summary: 如何使用 AI 助手來理解經文。
---

# AI 助手

Theodia 內建 AI 助手。它可以幫助您理解經文、回答問題，或探討聖經主題。

## 如何開啟 AI

AI 預設為關閉。若要開啟：

1. 開啟 **設定**。
2. 點選 **AI 助手**。
3. 點選開關將它開啟。

您可能需要設定帳號或金鑰。應用程式會引導您完成。

## 如何開啟 AI 畫面

點選螢幕底部的 **AI** 頁籤。聊天視窗隨即開啟。

## 如何提問

點選底部的輸入框，輸入您的問題，然後點選 **傳送**。

您可以問的問題例如：

- "What does John 3:16 mean?"
- "Tell me about the book of Romans."
- "What is the fruit of the Spirit?"
- "Compare the Sermon on the Mount in Matthew and Luke."

## 如何詢問特定經文

1. 開啟一章聖經。
2. 點選一節經文，開啟經文選單。
3. 點選 **AI 註釋**。

該節經文會傳送給 AI。AI 面板會自動填入該節經文並開啟。您可以追加問題，例如 "What does this mean?" 或 "How should I apply this?"

## 重要須知

- AI 是工具，不是真人。它可能會出錯。
- 請務必將 AI 的回答與聖經本身對照查驗。
- AI 可能需要網際網路，離線時無法運作。
- 當您使用 AI 時，您的問題、經文上下文與 API 金鑰會傳送到您選擇的端點。首次使用時，應用程式會徵詢您的同意，並清楚顯示會傳送哪些內容。您可以稍後在 **設定 → AI 助手 → 遠端 AI 資料分享** 中變更或撤銷此權限。
- 部分地區（例如中國大陸 App Store 版本）不提供 AI 助手，該版本僅提供離線聖經功能。

## 如何管理對話

AI 畫面會保留過去的對話列表。您可以從列表中開啟舊對話、開始新對話，或刪除不需要的對話。

更多進階技巧，請參閱 [寫出更好的 AI 提示](theodia://help/ai-prompts) 指南。
