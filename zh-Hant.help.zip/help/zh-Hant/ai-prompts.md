---
title: 寫出更好的 AI 提示
level: advanced
categories: ai
summary: 如何向 AI 助手提問，以獲得優質回答。
---

# 寫出更好的 AI 提示

> **模式：** AI 助手需要 **學者模式**。您可以在 **設定** → **應用程式使用者模式** 中切換模式。

「提示」就是您給 AI 的問題或指令。提示越好，回答越好。本指南教您如何寫出好提示。

## 具體明確

不好："Tell me about love."
較好："In 1 Corinthians 13, what kind of love does Paul describe, and how is it different from romantic love?"

給的細節越多，回答越實用。

## 提供上下文

不好："What does this verse mean?"
較好："I'm reading Romans 8 with a small group. What does 'no condemnation' mean in this chapter, and how does it connect to the rest of the chapter?"

上下文能幫助 AI 根據您的處境調整回答。

## 一次問一件事

不好："Tell me about prayer, faith, and healing."
較好："Tell me about prayer first. After that, I'll ask about faith."

一次問一件事能讓回答保持聚焦。

## 請 AI 扮演某個角色

您可以請 AI 用特定語氣回答。例如：

- "Answer as if you were teaching a new Christian."
- "Answer as a Bible scholar."
- "Answer for a 10-year-old."

AI 會根據角色調整回答。

## 使用追問問題

如果第一次回答不夠理想，可以追問：

- "Can you say that more simply?"
- "Can you give me an example?"
- "What does the original Greek say?"
- "Where else in the Bible does this come up?"

良好的對話是來回進行的。AI 會記住最近幾則訊息。

## 查驗 AI 的回答

AI 可能會出錯。它是工具，不是老師。

- 將 AI 的回答與它指向的經文對照。
- 使用應用程式中的註釋與詞典取得第二意見。
- 如果回答涉及教義，請詢問牧者或值得信賴的朋友。

## 常見的優秀提示範本

以下幾個範本效果很好：

- "Explain this verse to me like I am a new Christian."
- "What is the main point of this chapter in one sentence?"
- "List three applications for my daily life from this passage."
- "What questions should I ask about this verse before I preach it?"
