---
title: 快速命令
level: everyday
categories: [layout, study]
summary: 快速命令讓您輸入簡短指令即可跳到任何功能。了解支援的格式與範例。
---

# 快速命令

**快速命令** 輸入框讓您輸入簡短指令，即可跳到 Theodia 的幾乎任何部分。您可以從首頁頁籤，或從 **快速選單**（標題列的 **▼** 圖示）使用它。

## 運作方式

1. 點選命令輸入框。
2. 輸入指令。
3. 點選鍵盤上的確認鍵。

應用程式會讀取指令，並直接帶您到正確的畫面。

## 不需要斜線前綴

指令 **不** 使用 `/` 前綴，直接輸入純文字即可：

```
john 3:16
search love
backup
```

若您輸入 `/settings`，開頭的 `/` 會讓它無法被辨識。

## 聖經引用

輸入任何聖經引用，即可在閱讀器中開啟。

```
psalms 23
john 3:16
matthew 5:1
1 cor 15:10
```

書卷名稱可以使用全名或縮寫。在非英文介面語言中，您也可以用目前作用中的語言輸入書卷名稱。

## 搜尋

```
search abraham
search love
search faith not works
```

## 書籤、比較、註釋、交叉引用與詞語資訊

```
bookmark john 3:16
compare genesis 1:1
commentary john 1
aicommentary eph 2:8
xref 1 cor 15:10
word info john 1:1
```

這些指令會為給定的經文開啟對應工具。

## 詞典

輸入 Strong's 編號即可開啟詞典條目。

```
g1161
h7225
```

## 靈修

```
devotional
devotional smith
devotional daily
```

不輸入名稱時，會開啟靈修列表。

## 導航捷徑

```
notes
highlights
bookmarks
flashcards
playlist
theoscript
resources
read john 3:16
```

這些會直接跳到對應畫面，或在閱讀器中開啟一段經文。

## 切換譯本

輸入譯本縮寫即可切換。

```
kjv
web
trlit
ohgb
```

在閱讀器畫面上，譯本會原地切換。在其他地方，則會以您最近的經文開啟該譯本。

## 本地化命令動詞

公開的命令動詞可以用目前介面語言 **或** 英文輸入。英文永遠可以作為備援。隱藏命令（設定捷徑、安裝指令、彩蛋）仍只保留英文語法。

## 說明

在命令輸入框中輸入 `help` 或 `commands`，可隨時開啟應用程式內命令參考。
