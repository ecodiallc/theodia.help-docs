---
title: 建立自己的資源
level: advanced
categories: resources
summary: 如何建立自訂聖經、註釋、書籍、靈修與詞典，並匯入 Theodia。
---

# 建立自己的資源

Theodia 支援 Unique Bible App 格式的自訂資源。每項資源都是具有特定表格結構的 SQLite 檔案。您可以在電腦上建立這些檔案，然後匯入應用程式。

## 檔案類型與必要表格

### 聖經（`.bible`）

聖經檔案是 SQLite 資料庫，至少要有以下其中一個表格：

- **`Verses`** — 欄位：`Book`（整數，1-66）、`Chapter`（整數）、`Verse`（整數）、`Scripture`（文字）
- **`Bible`** — 欄位：`Book`（整數）、`Chapter`（整數）、`Verse`（整數）、`Scripture`（文字）

您也可以加入 **`Details`** 表格來存放詮釋資料，例如 `Description`、`Abbreviation`、`Version`。

SQL 範例：

```sql
-- 主文字表格
CREATE TABLE Verses (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Verses VALUES (1, 1, 1, 'In the beginning God created the heaven and the earth.');

-- 可選的詮釋資料表格
CREATE TABLE Details (
  Title TEXT,
  Abbreviation TEXT,
  Information TEXT,
  Version INTEGER,
  OldTestament INTEGER,
  NewTestament INTEGER,
  Apocrypha INTEGER,
  Strongs INTEGER
);

INSERT INTO Details VALUES ('King James Version', 'KJV', 'Translated in 1611', 1, 1, 1, 0, 1);
```

### 註釋（`.commentary`）

註釋分為三種類型：**書卷**、**章節** 與 **逐節**。類型由**檔案名稱的第一個字母**決定。

#### 書卷註釋 — 檔案名稱以 `b` 開頭

書卷註釋以單一條目涵蓋整卷聖經。`Commentary` 表格需要 `Book` 與 `Scripture`（或 `Content`）欄位，不需要 `Chapter` 或 `Verse` 欄位。

- **`Commentary`** — 欄位：`Book`（整數）、`Scripture`（文字）或 `Content`（文字）

SQL 範例：

```sql
CREATE TABLE Commentary (Book INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 'The Gospel of John is a profound exploration of the deity of Christ...');
```

檔案名稱範例：`bMyCommentary.commentary`

#### 章節註釋 — 檔案名稱以 `c` 開頭

章節註釋涵蓋聖經書卷的每一章。

- **`Commentary`** — 欄位：`Book`（整數）、`Chapter`（整數）、`Scripture`（文字）或 `Content`（文字）

SQL 範例：

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 'Chapter 3 continues the conversation between Jesus and Nicodemus...');
```

檔案名稱範例：`cMyCommentary.commentary`

#### 逐節註釋 — 檔案名稱以 `v` 開頭

逐節註釋涵蓋個別經文。`Commentary` 表格需要 `Book`、`Chapter`、`Verse` 與 `Scripture`（或 `Content`）欄位。

- **`Commentary`** — 欄位：`Book`（整數）、`Chapter`（整數）、`Verse`（整數）、`Scripture`（文字）或 `Content`（文字）

SQL 範例：

```sql
CREATE TABLE Commentary (Book INTEGER, Chapter INTEGER, Verse INTEGER, Scripture TEXT);

INSERT INTO Commentary VALUES (43, 3, 16, 'This verse shows the depth of God\'s love...');
```

檔案名稱範例：`vMyCommentary.commentary`

### 書籍（`.book`）

書籍檔案是帶有 `Reference` 表格的 SQLite 資料庫。

- **`Reference`** — 欄位：`id`（整數）、`Chapter`（文字）、`Content`（文字）

每一列是一章。`Chapter` 欄位是章節標題。`Content` 欄位是章節內文，可包含 HTML（如 `<b>`、<i>`、<br>` 等）。

SQL 範例：

```sql
CREATE TABLE Reference (id INTEGER, Chapter TEXT, Content TEXT);

INSERT INTO Reference VALUES (1, 'Chapter 1', '<b>Introduction</b><br>This is the first chapter.');
```

您也可以從 Markdown 檔案建立書籍。應用程式可以匯入 `.md` 檔案，其中 `#` 是書名，`##` 標記章節。Markdown 會自動轉換為 HTML。

### 靈修（`.devotional`）

靈修檔案是帶有 `devotional` 表格的 SQLite 資料庫。

- **`devotional`** — 欄位：`month`（整數，1-12）、`day`（整數，1-31）、`devotion`（文字）

每一列是一天的內容。應用程式會根據今天的月份與日期來查詢條目。

SQL 範例：

```sql
CREATE TABLE devotional (month INTEGER, day INTEGER, devotion TEXT);

INSERT INTO devotional VALUES (1, 1, 'Start the year with prayer and reflection...');

INSERT INTO devotional VALUES (12, 25, 'Remember the reason for the season...');
```

### 詞典（`.lexicon`）

詞典檔案是帶有 `Lexicon` 表格的 SQLite 資料庫。

- **`Lexicon`** — 欄位：`Topic`（文字，Strong's 編號）、`Definition`（文字，詞典條目）

`Topic` 欄位存放 Strong's 編號（例如 `G1161` 或 `H7225`）。`Definition` 欄位存放完整條目文字，可包含 HTML。

SQL 範例：

```sql
CREATE TABLE Lexicon (Topic TEXT, Definition TEXT);

INSERT INTO Lexicon VALUES ('G25', '<b>agapaō</b> — to love, to have affection for...');

INSERT INTO Lexicon VALUES ('H7225', '<b>rēshīth</b> — beginning, first, chief...');
```

詞典驅動詞語資訊工具。當您在逐字對照聖經中點選單字時，應用程式會在已安裝的詞典中查詢 Strong's 編號。

## 在電腦上建立檔案

1. 安裝 SQLite 編輯器（DB Browser for SQLite、SQLiteStudio，或 `sqlite3` 命令列工具）。
2. 建立新的資料庫檔案。
3. 建立必要表格並插入資料。
4. 以正確的副檔名儲存檔案（`.bible`、`.commentary`、`.book`、`.devotional` 或 `.lexicon`）。

## 匯入 Theodia

1. 將檔案傳送到您的裝置（AirDrop、電子郵件、雲端儲存或 USB）。
2. 開啟 **Theodia**。
3. 前往 **設定** → **管理資源**。
4. 點選 **從檔案匯入**。
5. 選擇您的檔案。

應用程式會驗證檔案（檢查必要表格），將它複製到應用程式的資料夾，並自動啟用。若檔案無效，您會看到錯誤訊息說明問題所在。

## 限制

- 您無法覆蓋內建資源。若嘗試匯入與內建聖經、註釋或書籍同名的檔案，匯入會失敗。
- 聖經檔案需要 `Verses` 或 `Bible` 表格。若兩者皆無，匯入會失敗。
- 註釋檔案需要 `Commentary` 表格。
  - 書卷註釋需要 `Book` 與 `Scripture`（或 `Content`）欄位。
  - 章節註釋需要 `Book`、`Chapter` 與 `Scripture`（或 `Content`）欄位。
  - 逐節註釋需要 `Book`、`Chapter`、`Verse` 與 `Scripture`（或 `Content`）欄位。
- 書籍檔案需要 `Reference` 表格。
- 詞典檔案需要 `Lexicon` 表格。
- 靈修檔案需要 `devotional` 表格。

## 訣竅

- 檔案大小請保持合理。過大的 SQLite 檔案可能會在較舊裝置上造成記憶體問題。
- 先在電腦上測試檔案。在 SQLite 瀏覽器中開啟它，並執行 `SELECT * FROM` 必要表格，確認資料看起來正確。
- 聖經的 `Book` 欄位請使用數字（1 = 創世記，66 = 啟示錄）。
- 註釋的內文欄位可以使用 `Scripture` 或 `Content`。
- 書籍的 `Content` 欄位中的 HTML 會在閱讀時渲染。請保持簡單：`<b>`、<i>`、<br>`、<hr>` 都是安全的。

## 哪裡可以找到現有資源

Theodia 可以讀取 [Unique Bible App](https://github.com/eliranwong/UniqueBible) 專案的資源。那裡有許多正確 SQLite 格式的聖經、註釋、書籍等資源。尋找與新增方式請參閱 [取得額外資源](theodia://help/getting-core-files) 指南。
