---
title: GitHub Models
categories: ai
level: advanced
summary: 設定 GitHub Models——無需現有 API 訂閱，即可免費開始在 Theodia 中探索 AI。
---

# GitHub Models

> **模式：** AI 助手需要 **學者模式**。您可以在 **設定** → **應用程式使用者模式** 中切換模式。

若您目前沒有付費使用任何 AI 服務，**GitHub Models** 是開始探索 Theodia AI 最簡單的方式。它可以免費開始，而且您只需要一個免費 GitHub 帳號。

## 什麼是 GitHub Models？

GitHub Models 是 GitHub 提供的服務，讓您透過 API 執行現代 AI 模型。它支援與 OpenAI 相同的格式，因此能與 Theodia 無縫搭配。

## 為什麼選擇 GitHub Models？

- **無需信用卡** — 只需要 GitHub 帳號。
- **高品質模型** — 您可以使用 GPT-4o、GPT-4.1 等可靠模型，它們支援 Theodia 的工具。
- **設定簡單** — 一組權杖、一個網址即可完成。

## 步驟 1：建立 GitHub 帳號

若您已有 GitHub 帳號，請跳到步驟 2。

1. 前往 [github.com](https://github.com)。
2. 點選 **Sign up**，按照提示建立免費帳號。
3. 當 GitHub 寄出確認信時，驗證您的電子郵件地址。

## 步驟 2：建立個人存取權杖

這組權杖就是您的 API 金鑰。當 Theodia 傳送問題時，它會告訴 GitHub 您是誰。

1. 前往 [github.com/settings/tokens](https://github.com/settings/tokens)。
2. 點選 **Generate new token**，然後選擇 **Generate new token (classic)**。
3. 為權杖取個名稱，例如 **Theodia AI**。
4. 在 **Select scopes** 下，勾選 **`models:read`** 核取方塊。
   - 這是 Theodia 唯一需要的權限。
5. 捲動到底部，點選 **Generate token**。
6. **立即複製權杖。** GitHub 只會顯示一次。請先將它貼到安全的地方（例如手機備忘錄），再新增到 Theodia。

## 步驟 3：選擇模型

GitHub Models 提供多種模型。對 Theodia 來說，以下是最佳選擇：

| 模型 | 每日免費額度 | 最適合用於 |
| --- | --- | --- |
| `openai/gpt-4.1-nano` | 150 次請求 / 天 | 快速問題與簡單經文解釋 |
| `openai/gpt-4.1-mini` | 150 次請求 / 天 | 一般研經，工具支援良好 |
| `openai/gpt-4.1` | 50 次請求 / 天 | 深入研究與複雜多步驟問題 |
| `openai/gpt-4o` | 50 次請求 / 天 | 多功能，工具支援優秀 |

建議從 **`openai/gpt-4.1-mini`** 開始——它快速、可靠，且每日請求額度較高。

## 步驟 4：設定 Theodia

1. 開啟 **Theodia**。
2. 前往 **設定** → **AI 助手**。
3. 確認已選擇 **遠端模型**。
4. 點選 **供應商** 下拉選單，選擇 **GitHub Models**。
   - 若列表中沒有 GitHub Models，請點選 **自訂**，並手動輸入基礎網址：`https://models.github.ai`
5. 將您的 GitHub 個人存取權杖貼到 **API 金鑰** 欄位。
6. 在 **模型** 欄位中輸入您選擇的模型 ID（例如：`openai/gpt-4.1-mini`）。
7. 點選 **測試連線**。
8. 等待檢查完成。您應該會看到：
   - **✓ 連線成功**
   - **✓ 支援工具**

若看到 **✗ 不支援工具**，請從上方表格中嘗試不同的模型 ID。

## 步驟 5：開始聊天

1. 點選螢幕底部的 **AI** 頁籤。
2. 輸入問題，然後點選 **傳送**。
3. 或者，閱讀任何聖經章節時，點選經文編號並選擇 **AI 註釋**，即可開始針對特定經文的聊天。

## 疑難排解

### "Connection failed" 或 "HTTP 401"

- 確認您複製了**完整**的權杖。它是一長串以 `ghp_` 開頭的字串。
- 權杖若長時間未使用可能會過期。請回到 GitHub 產生一組新的。
- 確認建立權杖時已選擇 **models:read**。

### "Tools not supported"

- GitHub Models 上的某些模型不接受工具呼叫。請改用 **`openai/gpt-4o`** 或 **`openai/gpt-4.1-mini`**。
- 確認模型 ID 拼寫與顯示完全一致，包含 `openai/` 前綴。

### 速率限制錯誤

- 若達到每日上限，請切換到額度較高的模型（例如 `openai/gpt-4.1-nano`，每天 150 次請求）。
- 限制每 24 小時重置一次。

## 總結

- GitHub Models 是在 Theodia 中**開始探索 AI 的推薦方式**。
- 您需要一個**免費 GitHub 帳號**，以及一組具有 `models:read` 權限的**個人存取權杖**。
- 最佳入門模型是 **`openai/gpt-4.1-mini`**。
- 在 **設定 → AI 助手** 中輸入權杖與模型，點選 **測試連線**，然後開始聊天。
