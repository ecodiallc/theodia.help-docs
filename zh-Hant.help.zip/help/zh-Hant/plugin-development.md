---
title: 開發外掛
categories: plugins
level: advanced
summary: Theodia 外掛套件包含哪些內容，以及如何撰寫外掛清單。
---

# 開發外掛

Theodia 外掛是一個自包含的套件，可為應用程式新增 UI 介面、內容或事件處理。外掛在主應用程式外部撰寫，使用者透過 **設定 → 外掛** 安裝。

## 外掛套件結構

外掛套件是副檔名為 `.plugin.zip` 的 ZIP 壓縮檔。內部檔案位於最上層，不在巢狀資料夾中。

典型套件包含：

```
my-plugin.plugin.zip
├── plugin.json       （必要）
├── data.sqlite       （選用，供內容/UI 外掛使用）
├── template.html     （選用）
├── style.css         （選用）
└── logo.png          （選用）
```

必要檔案：

- `plugin.json` — 外掛清單（見下文）。

選用檔案：

- 儲存內容或 UI 資料的 SQLite 資料庫。
- 清單引用的 HTML、Markdown、圖片或 JSON 素材。

`plugin.json` 中的所有素材引用都必須使用精確的單一檔名，不含路徑。例如，使用 `template.html` 而非 `templates/template.html`。

## 清單基礎

最精簡的 `plugin.json` 如下：

```json
{
  "id": "org.example.myplugin",
  "name": "Example Plugin",
  "version": "0.1.0",
  "type": "ui",
  "description": "A short description of what the plugin does.",
  "extensions": [
    {
      "surface": "bible-verse-menu",
      "config": {
        "label": "Example",
        "icon": "🔌",
        "screenType": "template",
        "templateFile": "template.html"
      }
    }
  ]
}
```

### 常見清單欄位

| 欄位 | 必要 | 說明 |
| --- | --- | --- |
| `id` | 是 | 反向網域風格識別碼，例如 `org.example.myplugin`。 |
| `name` | 是 | 顯示給使用者的名稱。 |
| `version` | 是 | 外掛的語意化版本。 |
| `type` | 是 | `ui`、`content` 或 `composite`。 |
| `description` | 否 | 外掛功能的簡短摘要。 |
| `minAppVersion` | 否 | 需要的最低 Theodia 應用程式版本。 |
| `apiVersion` | 否 | 目標外掛 API 版本。 |
| `extensions` | `ui` 與 `composite` 必要 | 介面宣告陣列（見下文）。 |

### 介面

每個 `extensions` 項目宣告外掛出現的位置與功能：

```json
{
  "surface": "home-screen",
  "config": {
    "title": "My Plugin",
    "icon": "📝",
    "screenType": "list",
    "dbTable": "Articles",
    "titleColumn": "Title"
  }
}
```

支援的介面：

- `bottom-toolbar` — 底部外掛頁籤的項目。
- `home-screen` — 首頁的圖格。
- `hamburger-menu` — 主選單中的項目。
- `bible-verse-menu` — 聖經閱讀器長按經文的動作。
- `bible-chapter-toolbar` — 聖經閱讀器的章節工具列動作。
- `book-chapter-toolbar` — 書籍閱讀器的工具列動作。
- `ai-verse-action` — 經文上的 AI 動作（需要啟用 AI）。
- `ai-chapter-action` — 章節上的 AI 動作（需要啟用 AI）。
- `event` — 應用程式生命週期事件處理器。

### 畫面類型

介面設定中的 `screenType` 告訴應用程式如何渲染外掛畫面：

- `list` — 資料庫列的可捲動列表。
- `data-list` — 可新增/編輯/刪除的列表。
- `detail` — 單一列或經文內容。
- `markdown` — 靜態 Markdown 檔案渲染為 HTML。
- `html` — 使用 `react-native-render-html` 渲染的靜態 HTML 檔案。
- `template` — 帶 `{{key}}` 佔位符替換的 HTML 檔案。
- `flashcard` — 使用兩個資料庫欄位的翻卡 UI。

## 發布

打包為 `.plugin.zip` 檔案後，外掛可以：

- 由使用者直接從檔案匯入。
- 從目錄資源庫提供。

## 訣竅

- 保持 `plugin.json` 為有效 JSON。安裝期間無效清單會被應用程式拒絕。
- 所有引用的素材都使用精確檔名。
- 外掛 ID 應採用反向網域風格，以避免衝突。
- 離線測試外掛內容，因為使用者可能沒有網路連線。
