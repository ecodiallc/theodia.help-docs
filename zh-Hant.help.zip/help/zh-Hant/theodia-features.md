---
title: Theodia 功能
level: beginner
categories: theodia
summary: Theodia 應用程式中主要功能的快速總覽。
---

# Theodia 功能

Theodia 是一款離線優先的聖經研究應用程式。以下是您開始使用時會看到的主要功能。

## 聖經閱讀

核心功能是閱讀聖經：

- 從一本聖經譯本切換到另一本。
- 依書卷、章節瀏覽。
- 搜尋字詞與經文參照。
- 聆聽文字轉語音（TTS）讀經。

請參閱 [瀏覽應用程式](theodia://help/navigating-the-app) 與 [搜尋聖經](theodia://help/search-the-bible)。

## 平行聖經

同時並排查看多個譯本。對於比較不同翻譯方式非常有用。請參閱 [比較譯本](theodia://help/compare-translations)。

## 註釋與詞典

查看已安裝的聖經註釋與詞典，深入理解經文。請參閱 [註釋與詞典](theodia://help/commentaries-and-lexicons)。

## 交叉引用

查看與您正在閱讀的經文相關的其他經文。請參閱 [交叉引用](theodia://help/cross-references)。

## 書籤、亮點與筆記

- **書籤** 儲存位置，方便日後返回。
- **亮點** 以顏色標示經文。
- **筆記** 為經文加入您自己的想法。

請參閱 [書籤](theodia://help/bookmarks) 與 [亮點](theodia://help/highlights)。

## 播放列表

建立包含聖經章節、講道或書籍章節的播放列表，以便連續聆聽。請參閱 [播放列表](theodia://help/playlists)。

## AI 助手

詢問關於經文的問題、產生摘要，或取得研究協助。AI 需要您自己的 API 金鑰。請參閱 [AI 總覽](theodia://help/ai-overview)。

## 祈禱工具

使用目標、例行與統計來建立代禱習慣。請參閱 [祈禱總覽](theodia://help/prayer-overview)。

## 外掛

安裝社群製作的外掛，新增資源與功能。請參閱 [什麼是外掛？](theodia://help/plugins-overview)。

## 離線優先

幾乎所有功能都不需要網際網路。資料庫與資源會儲存在您的裝置上。AI 與部分外掛可能例外。

## 使用者模式

選擇最適合您的介面複雜度：

- **普通模式** — 簡潔閱讀。
- **研讀模式** — 加入註釋與詞典。
- **學者模式** — 完整原文與形態學工具。

請參閱 [應用程式使用者模式](theodia://help/app-user-mode)。

## 自訂外觀

調整字型、字型大小、主題與行高。請參閱 [主題與字型](theodia://help/themes-and-fonts)。

## 相關指南

- [歡迎](theodia://help/welcome)
- [瀏覽應用程式](theodia://help/navigating-the-app)
- [什麼是資源？](theodia://help/what-are-resources)
