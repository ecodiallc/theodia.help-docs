---
title: Theoscript
level: advanced
categories: ai
summary: Theoscript 是一種結構化輸出格式，讓 AI 回應更容易在應用程式中使用。
---

# Theoscript

Theoscript 是 Theodia 用來從 AI 模型接收結構化資料的一種格式。它讓應用程式能將 AI 回應轉換為清單、表格、經文連結與其他介面元素。

## 為什麼使用 Theoscript？

純文字 AI 回應難以解析。Theoscript 提供簡單的標記法，讓 AI 能表達：

- 標題與區塊。
- 項目清單。
- 經文引用與連結。
- 表格。
- 反白或重點經文。

## Theoscript 語法

Theoscript 使用類似 Markdown 的輕量標記。

### 區塊

區塊用於將內容分組：

```
[block title="Summary"]
This section summarizes the passage.
[/block]
```

### 清單

```
[list]
- First point
- Second point
- Third point
[/list]
```

### 經文引用

```
[verse John 3:16]
For God so loved the world...
[/verse]
```

Theodia 會將經文引用轉換為可點選連結。

### 表格

```
[table]
| Theme | Reference |
| Love | John 3:16 |
| Faith | Hebrews 11:1 |
[/table]
```

### 重點

```
[highlight]
This is an important idea.
[/highlight]
```

## 如何查看 Theoscript

當 AI 功能傳回 Theoscript 時，Theodia 會自動將其轉換為原生 UI。您會看到：

- 摺疊區塊。
- 可點選經文連結。
- 格式化的表格。
- 項目清單。

## 編寫提示詞以產生 Theoscript

若您正在編寫 AI 提示詞，可以要求模型以 Theoscript 格式輸出。在提示詞中加入如下說明：

```
Please format your response using Theoscript tags.
Use [block], [list], [verse], and [table] where appropriate.
```

並非所有模型都能完美遵循此格式，因此您可能需要提供範例。

## 範例提示詞

```
Explain Romans 8:28 using Theoscript.
Include:
- A [block] titled "Main Idea".
- A [list] of three applications.
- A [verse] block quoting Romans 8:28.
- A [table] showing related verses.
```

## Theoscript 與提示範本

Theodia 的內建提示範本已使用 Theoscript 標記。您可以在 **設定** → **AI** → **提示範本** 中查看與編輯。請參閱 [AI 提示詞](theodia://help/ai-prompts)。

## 限制

- 並非所有模型都支援長結構化輸出。
- 複雜表格可能會超出模型能力。
- 您應該驗證模型引用的經文是否正確。

## 相關指南

- [AI 概述](theodia://help/ai-overview)
- [AI 提示詞](theodia://help/ai-prompts)
- [選擇模型](theodia://help/choosing-a-model)
