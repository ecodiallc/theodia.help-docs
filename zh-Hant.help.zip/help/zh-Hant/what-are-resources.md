---
title: 什麼是資源？
level: beginner
categories: resources
summary: Theodia 中的聖經、註釋、詞典、書籍與其他資料的說明。
---

# 什麼是資源？

在 Theodia 中，**資源** 是應用程式可以載入與顯示的任何資料集。資源是離線資料庫檔案，儲存在您裝置的 `assets/data/` 資料夾中。

## 資源類型

主要資源類型有：

- **聖經** — 聖經譯本。檔案副檔名為 `.bible`。
- **註釋** — 對經文的解釋與註解。檔案副檔名為 `.commentary`。
- **詞典** — 字詞定義與原文詞彙。檔案副檔名為 `.lexicon`。
- **書籍** — 一般書籍、詩歌集與靈修材料。檔案副檔名為 `.book`。
- **參考資料** — 交叉引用、形態學與索引資料庫。檔案副檔名為 `.sqlite`。

## 資源儲存在哪裡？

資源會從應用程式套件複製到您裝置的文件目錄：

```
<documentDirectory>/bibles/
<documentDirectory>/commentaries/
<documentDirectory>/lexicons/
<documentDirectory>/books/
<documentDirectory>/data/
```

這是應用程式第一次啟動時自動完成的。

## 每個資源都是獨立的 SQLite 檔案

與許多應用程式不同，Theodia 不會將所有內容合併到一個大型資料庫中。每個資源都是獨立的 SQLite 檔案。這帶來幾個好處：

- 您可以新增或移除資源，而無需重建整個資料庫。
- 不同來源的資源不會互相干擾。
- 應用程式只開啟它當下需要的檔案。

## 如何取得資源

資源來自兩個地方：

1. **內建** — 與應用程式一同打包的資源。
2. **安裝** — 您自行加入裝置的資源。

請參閱 [取得核心檔案](theodia://help/getting-core-files) 了解如何下載與放置檔案。

## 聖經資源結構

每個 `.bible` 檔案都有這些資料表：

- `Bible` — 譯本相關資訊。
- `Details` — 每本書的章節數量。
- `Verses` — 實際經文內容。

## 註釋資源結構

每個 `.commentary` 檔案都有一個 `Commentary` 資料表：

- `Book` — 書卷編號。
- `Chapter` — 章節編號。
- `Verse` — 節編號。
- `Scripture` — 註釋文字。

## 詞典資源結構

詞典使用 `.lexicon` 檔案。它們通常包含：

- Strong's 編號。
- 原文詞彙。
- 音譯。
- 定義。

## 書籍資源結構

`.book` 檔案儲存章節或段落。它們與聖經使用不同的結構，因為書籍不依書卷/章節/節組織。

## 如何查看已安裝的資源

開啟 **設定** → **資源** 可查看已安裝的聖經、註釋、詞典與書籍列表。從這裡，您可以看到版本名稱與檔案大小。

## 新增資源

若要新增資源：

1. 取得正確格式的檔案。
2. 將它放入對應的 `assets/data/` 子資料夾中。
3. 重新啟動應用程式，讓它複製新檔案。

請參閱 [安裝聖經](theodia://help/installing-bibles) 與 [建立資源](theodia://help/creating-resources) 了解詳情。

## 外掛也是資源

外掛是更進階的資源。一個外掛可以包含多種內容，以及新增 UI 元素的指令。請參閱 [什麼是外掛？](theodia://help/plugins-overview)。

## 相關指南

- [安裝聖經](theodia://help/installing-bibles)
- [取得核心檔案](theodia://help/getting-core-files)
- [建立資源](theodia://help/creating-resources)
- [什麼是外掛？](theodia://help/plugins-overview)
